% Run (SimBiology): build model + dose, simulate 0..31.0 h, plot.
p = Disopyramide_Bryson1978_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 31.0);
