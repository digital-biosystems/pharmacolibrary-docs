model Disopyramide_Thibonnier1984_PD_qt
  "linear exposure-response sweep — Thibonnier_1984 :: QT (QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 46   "[meter ** 3 * second / kilogram; s/μg/ml × 1000]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About disopyramide</h4><p>Disopyramide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation. It is an approved medicine, though not authorised in the European Union, and is used relatively little today.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425120\">Wikidata Q425120</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Disopyramide_Thibonnier1984_PD_qt</h4><p>The steady-state exposure-response curve of Thibonnier M et al., <i>Journal of pharmacokinetics and biopharmaceutics 12(6):559–573</i> 1984 (<a href=\"https://doi.org/10.1007/BF01059552\">doi:10.1007/BF01059552</a>) — QT interval [s] against disopyramide μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.046 s/μg/ml  change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg/ml of disopyramide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Disopyramide_Thibonnier1984_PD_qt;
