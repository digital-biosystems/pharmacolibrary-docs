function p = Disopyramide_Thibonnier1984_PD_qt_params()
% Disopyramide_Thibonnier1984_PD_qt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% disopyramide Thibonnier_1984::QT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response QT in s. Driver: disopyramide (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 46.00000000000001;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
