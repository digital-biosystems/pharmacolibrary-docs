function p = Disopyramide_Whiting1980_PD_qtms_params()
% Disopyramide_Whiting1980_PD_qtms_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% disopyramide Whiting_1980::QTms: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/ml per second, in SI inside (kg/m3, s). Response ΔQTms in ms. Driver: disopyramide (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 14.500000000000002;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
