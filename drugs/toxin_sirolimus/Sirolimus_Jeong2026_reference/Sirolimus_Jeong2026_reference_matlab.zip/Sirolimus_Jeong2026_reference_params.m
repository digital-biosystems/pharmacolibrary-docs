function p = Sirolimus_Jeong2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirolimus   source: Jeong_2026 / reference   route: oral
  p.name  = 'Sirolimus_Jeong2026_reference_params';
  p.drug  = 'sirolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 14.7;                % clearance [L/h]
  p.Vp = [725.0];             % peripheral volumes [L]
  p.Q  = [24.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.175;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
