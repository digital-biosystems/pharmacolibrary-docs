model Sirolimus_Jeong2026_reference
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9142,
    adminMass = 3e-06,
    ka = 4.861111111111111e-05,
    Tlag = 0.0,
    k12 = 6.726579520697167e-05,
    k21 = 9.463601532567049e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirolimus</td></tr><tr><td>population:</td><td>paediatric patients with vascular anomalies (prospective and retrospective cohorts)</td></tr><tr><td>source_paper:</td><td>Jeong_2026</td></tr><tr><td>measured_compound:</td><td>Sirolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70595-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sirolimus 914.2 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'RV (proportional)' routed out of structural estimates ('SIGMA')</li><li>table section residual_error: 'RV (proportional)' routed out of structural estimates ('SIGMA')</li><li>dropped PD-category row 'TM50 (week)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeong_2026_table_p6_1:row5:col1'])</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeong_2026_table_p6_1:row6:col1'])</li><li>dropped unlinked row (NIL): 'COVHGB' — extend the ontology if this is a real PK parameter (source ['Jeong_2026_table_p6_1:row7:col1', 'Jeong_2026_table_p6_1:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sirolimus</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Sirolimus_Jeong2026_reference;
