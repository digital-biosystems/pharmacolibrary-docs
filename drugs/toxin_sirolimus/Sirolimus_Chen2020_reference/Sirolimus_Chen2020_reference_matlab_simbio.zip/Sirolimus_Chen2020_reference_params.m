function p = Sirolimus_Chen2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirolimus   source: Chen_2020 / reference   route: oral
  p.name  = 'Sirolimus_Chen2020_reference_params';
  p.drug  = 'sirolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1840.0;                % central volume [L]
  p.CL = 7.55;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.485;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
