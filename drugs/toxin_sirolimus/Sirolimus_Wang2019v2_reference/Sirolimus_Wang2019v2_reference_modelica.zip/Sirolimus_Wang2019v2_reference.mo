model Sirolimus_Wang2019v2_reference
  parameter Real Cl_ref = 1.7500000000000002e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.294 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9142,
    adminMass = 3e-06,
    ka = 0.00013472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirolimus</td></tr><tr><td>population:</td><td>Chinese pediatric patients with kaposiform hemangioendothelioma</td></tr><tr><td>source_paper:</td><td>Wang_2019_2</td></tr><tr><td>measured_compound:</td><td>Sirolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tIV-ol-0-0-10562</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sirolimus 914.2 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped 'V/F (liters)' → Q76 = -3.64: a volume of -3.64 is not a parameter value (source ['Wang_2019_2_table_4:row1:col1', 'Wang_2019_2_table_4:row1:col5'])</li><li>kept covariate coefficient θAGE=-4.65 (covariate AGE) — not an ontology parameter</li><li>kept covariate coefficient θALT=2.78 (covariate ALT) — not an ontology parameter</li><li>kept covariate coefficient θSEX=-2.51 (covariate SEX) — not an ontology parameter</li><li>kept covariate coefficient θDTT=1.15 (covariate DTT) — not an ontology parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sirolimus</li><li>gap-filled Q76 (V/F) from Chen_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chen_2021 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Sirolimus_Wang2019v2_reference;
