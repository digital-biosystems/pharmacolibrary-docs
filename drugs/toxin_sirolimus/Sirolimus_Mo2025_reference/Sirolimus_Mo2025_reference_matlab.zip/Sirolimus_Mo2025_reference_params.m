function p = Sirolimus_Mo2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirolimus   source: Mo_2025 / reference   route: oral
  p.name  = 'Sirolimus_Mo2025_reference_params';
  p.drug  = 'sirolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 365.0;                % central volume [L]
  p.CL = 7.28;                % clearance [L/h]
  p.Vp = [205.94];             % peripheral volumes [L]
  p.Q  = [14.32];             % inter-compartmental clearances [L/h]
  p.ka = 9.48;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.63;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
