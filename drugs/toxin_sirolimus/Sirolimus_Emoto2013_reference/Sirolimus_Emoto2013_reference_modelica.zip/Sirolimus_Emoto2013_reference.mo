model Sirolimus_Emoto2013_reference
  parameter Real Cl_ref = 0.00011666666666666665 "Cl [m3/s]";
  parameter Real Vd_ref = 1.596 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9142,
    adminMass = 3e-06,
    ka = 0.00013472222222222222,
    Tlag = 2268.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirolimus</td></tr><tr><td>population:</td><td>healthy adults (virtual PBPK population and clinical dose escalation subjects)</td></tr><tr><td>source_paper:</td><td>Emoto_2013</td></tr><tr><td>measured_compound:</td><td>Sirolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sirolimus 914.2 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'μl/min/106 hepatocytes' (CLint)</li><li>dropped unlinked row (NIL): 'SWRS' — extend the ontology if this is a real PK parameter (source ['Emoto_2013_table_1:row0:col5', 'Emoto_2013_table_1:row1:col5', 'Emoto_2013_table_1:row2:col5', 'Emoto_2013_table_1:row3:col5', 'Emoto_2013_table_1:row4:col5', 'Emoto_2013_table_1:row5:col5', 'Emoto_2013_table_1:row6:col5'])</li><li>salvaged Q22 ('hepatic intrinsic clearance'=100) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('contribution of this alternate route to the overall sirolimus oral clearance'=16) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('half-life'=81.5) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('apparent volume of distribution'=22.8) from results prose — parameter table was unreadable</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 6 column 4 (char 242)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sirolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Mo_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q3, Q27 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 1));
end Sirolimus_Emoto2013_reference;
