function p = Sirolimus_Golubovi2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirolimus   source: Golubović_2019 / reference   route: oral
  p.name  = 'Sirolimus_Golubovi2019_reference_params';
  p.drug  = 'sirolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 118.0;                % central volume [L]
  p.CL = 12.2;                % clearance [L/h]
  p.Vp = [609.0];             % peripheral volumes [L]
  p.Q  = [5.07];             % inter-compartmental clearances [L/h]
  p.ka = 2.19;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
