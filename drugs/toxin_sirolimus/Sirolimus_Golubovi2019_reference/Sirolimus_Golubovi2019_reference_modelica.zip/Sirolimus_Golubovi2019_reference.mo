model Sirolimus_Golubovi2019_reference
  parameter Real Cl_ref = 3.3888888888888884e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9142,
    adminMass = 3e-06,
    ka = 0.0006083333333333333,
    Tlag = 0.0,
    k12 = 1.1935028248587572e-05,
    k21 = 2.312534209085934e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirolimus</td></tr><tr><td>population:</td><td>renal transplant patients</td></tr><tr><td>source_paper:</td><td>Golubović_2019</td></tr><tr><td>measured_compound:</td><td>Sirolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>j_jomb-2018-0030_tab_004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sirolimus 914.2 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'volume of distribution (Vd/F)' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'absorption rate constant (ka)' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'ka' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'central volume of distribution (Vc/F)' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'volume distribution of peripheral compartment (Vp/F)' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'intercompartmental clearance (Q/F)' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'age' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>table section iiv: 'AST greater than 37 IU/L' routed out of structural estimates ('An additional criterion for the retention of a covariate in the model was reduction in unexplained interindividual variability (21, 26).')</li><li>dropped unlinked row (NIL): 'AST >37 IU/La' — extend the ontology if this is a real PK parameter (source ['j_jomb-2018-0030_tab_004:row7:col1'])</li><li>dropped unlinked row (NIL): 'AGEa' — extend the ontology if this is a real PK parameter (source ['j_jomb-2018-0030_tab_004:row8:col1'])</li><li>dropped unlinked row (NIL): 'Wpb' — extend the ontology if this is a real PK parameter (source ['j_jomb-2018-0030_tab_004:row10:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sirolimus</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Sirolimus_Golubovi2019_reference;
