model Sirolimus_Emoto2016_reference
  parameter Real Cl_ref = 1.975e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.302 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9142,
    adminMass = 3e-06,
    ka = 0.00013472222222222222,
    Tlag = 2268.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirolimus</td></tr><tr><td>population:</td><td>pediatric patients with vascular anomalies younger than 4 years old</td></tr><tr><td>source_paper:</td><td>Emoto_2016</td></tr><tr><td>measured_compound:</td><td>Sirolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412096-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sirolimus 914.2 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLmatured (L/h/70kg)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'TM50 (weeks)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Hill' routed out of structural estimates ('IIV (CV%)')</li><li>dropped PD-category row 'TM50 (weeks)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412096-tbl-0002:row3:col1'])</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412096-tbl-0002:row4:col1'])</li><li>covariate weight for allometric_exponent from footnote/prose kept as documentation only (['psp412096-tbl-0002:footnote', 'psp412096-tbl-0002:footnote'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sirolimus</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>gap-filled Q22 (CL) from Mo_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Park_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Mo_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Chen_2020, Mo_2025, Park_2023 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Sirolimus_Emoto2016_reference;
