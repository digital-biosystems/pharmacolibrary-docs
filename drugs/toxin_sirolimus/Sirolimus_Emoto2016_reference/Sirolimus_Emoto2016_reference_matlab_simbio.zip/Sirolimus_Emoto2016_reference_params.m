function p = Sirolimus_Emoto2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirolimus   source: Emoto_2016 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Sirolimus_Emoto2016_reference_params';
  p.drug  = 'sirolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 302.0;                % central volume [L]
  p.CL = 7.11;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.485;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.63;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
