% Run (SimBiology): build model + dose, simulate 0..2520.0 h, plot.
p = Miltefosine_Verrest2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2520.0);
