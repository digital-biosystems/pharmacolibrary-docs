function p = Miltefosine_Verrest2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: miltefosine   source: Verrest_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Miltefosine_Verrest2023_reference_params';
  p.drug  = 'miltefosine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.17;                % central volume [L]
  p.CL = 0.077083;                % clearance [L/h]
  p.Vp = [6.55];             % peripheral volumes [L]
  p.Q  = [0.007083];             % inter-compartmental clearances [L/h]
  p.ka = 0.001542;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
