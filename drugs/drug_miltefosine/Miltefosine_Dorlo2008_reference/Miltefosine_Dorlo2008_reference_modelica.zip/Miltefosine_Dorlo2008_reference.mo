model Miltefosine_Dorlo2008_reference
  parameter Real Cl_ref = 4.4791666666666666e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0396 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40757600000000005,
    adminMass = 0.0001,
    ka = 9.999999999999999e-05,
    Tlag = 0.0,
    k12 = 1.096029741863075e-08,
    k21 = 2.6304713804713803e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About miltefosine</h4><p>Miltefosine is a phospholipid drug used as an antiprotozoal agent against leishmaniasis and trypanosomiasis, and it also has antifungal, antibacterial and anticancer activity. It is an approved medicine, included on the WHO essential medicines list, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411787\">Wikidata Q411787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>miltefosine</td></tr><tr><td>population:</td><td>adults with cutaneous leishmaniasis</td></tr><tr><td>source_paper:</td><td>Dorlo_2008</td></tr><tr><td>measured_compound:</td><td>miltefosine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>miltefosine 407.576 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Absorption rate (ka) (h-1)' routed out of structural estimates ('% Interindividual variability (relative SE [%])^b')</li><li>table section iiv: 'Clearance (CL/F) (liters/day)' routed out of structural estimates ('% Interindividual variability (relative SE [%])^b')</li><li>table section iiv: 'Volume of central compartment (V2/F) (liters)' routed out of structural estimates ('% Interindividual variability (relative SE [%])^b')</li><li>table section iiv: 'Residual variability (%)' routed out of structural estimates ('% Interindividual variability (relative SE [%])^b')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=miltefosine</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Miltefosine_Dorlo2008_reference;
