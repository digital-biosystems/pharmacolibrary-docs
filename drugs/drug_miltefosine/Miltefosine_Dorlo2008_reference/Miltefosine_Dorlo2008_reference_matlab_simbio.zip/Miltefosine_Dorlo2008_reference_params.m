function p = Miltefosine_Dorlo2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: miltefosine   source: Dorlo_2008 / reference   route: oral
  p.name  = 'Miltefosine_Dorlo2008_reference_params';
  p.drug  = 'miltefosine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 39.6;                % central volume [L]
  p.CL = 0.16125;                % clearance [L/h]
  p.Vp = [1.65];             % peripheral volumes [L]
  p.Q  = [0.001562];             % inter-compartmental clearances [L/h]
  p.ka = 0.36;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
