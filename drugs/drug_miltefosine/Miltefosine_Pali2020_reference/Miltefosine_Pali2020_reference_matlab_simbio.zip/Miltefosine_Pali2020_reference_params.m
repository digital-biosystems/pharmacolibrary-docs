function p = Miltefosine_Pali2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: miltefosine   source: Palić_2020 / reference   route: oral
  p.name  = 'Miltefosine_Pali2020_reference_params';
  p.drug  = 'miltefosine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.9;                % central volume [L]
  p.CL = 0.101667;                % clearance [L/h]
  p.Vp = [2.27];             % peripheral volumes [L]
  p.Q  = [0.000971];             % inter-compartmental clearances [L/h]
  p.ka = 0.067083;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
