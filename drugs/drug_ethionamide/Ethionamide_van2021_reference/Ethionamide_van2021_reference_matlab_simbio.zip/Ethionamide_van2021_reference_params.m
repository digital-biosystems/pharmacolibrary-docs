function p = Ethionamide_van2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethionamide   source: van_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ethionamide_van2021_reference_params';
  p.drug  = 'ethionamide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26.5;                % central volume [L]
  p.CL = 10.8;                % clearance [L/h]
  p.Vp = [69.8];             % peripheral volumes [L]
  p.Q  = [2.25];             % inter-compartmental clearances [L/h]
  p.ka = 1.07;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 750.0;             % dose [mg]
end
