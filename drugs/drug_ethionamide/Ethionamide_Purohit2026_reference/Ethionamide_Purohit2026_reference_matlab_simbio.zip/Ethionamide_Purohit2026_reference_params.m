function p = Ethionamide_Purohit2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethionamide   source: Purohit_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ethionamide_Purohit2026_reference_params';
  p.drug  = 'ethionamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.7;                % central volume [L]
  p.CL = 6.01;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 750.0;             % dose [mg]
end
