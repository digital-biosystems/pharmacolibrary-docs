model Ethosuximide_Diezi2023_reference
  parameter Real Cl_ref = 1.5833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0313 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.14117,
    adminMass = 0.0007,
    ka = 0.0015527777777777777,
    Tlag = 0.0,
    k12 = 9.052183173588922e-05,
    k21 = 0.00020383693045563546
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Diezi_2023</td></tr><tr><td>measured_compound:</td><td>Ethosuximide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21032-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.17 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 67.2 (source ['prp21032-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'θ weight'</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['prp21032-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q22 ('CL'=0.57) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q'=10.2) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('VC'=31.3) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('VP'=13.9) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ethosuximide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Diezi_2023:other_prose, Diezi_2023:results_prose, prp21032-tbl-0002:footnote); populations final model estimate, granules (a), granules (b), syrup (zarontin®) (b) kept as separate records</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Ethosuximide_Diezi2023_reference;
