function p = Ethosuximide_Diezi2023_granules_b_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethosuximide   source: Diezi_2023 / granules_b   route: oral
  p.name  = 'Ethosuximide_Diezi2023_granules_b_params';
  p.drug  = 'ethosuximide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.65;                % central volume [L]
  p.CL = 0.623;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.59;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
