model Ethosuximide_Diezi2023_granules_b
  parameter Real Cl_ref = 1.7305555555555553e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04865 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.14117,
    adminMass = 0.0007,
    ka = 0.0015527777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Diezi_2023</td></tr><tr><td>measured_compound:</td><td>Ethosuximide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21032-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.17 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 't max [h] (range)' — extend the ontology if this is a real PK parameter (source ['Diezi_2023_table_1:row1:col1'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 67.2 (source ['prp21032-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'θ weight'</li><li>NIL: refused to back-fill base 'allometric_exponent' from footnote/prose loose number None (source ['prp21032-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Ethosuximide</li><li>population split: 'granules (b)' subgroup of Diezi_2023 (paper reports 4 populations: final model estimate, granules (a), granules (b), syrup (zarontin®) (b))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Ethosuximide_Diezi2023_granules_b;
