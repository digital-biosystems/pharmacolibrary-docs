// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ethosuximide_Diezi2023_syrup_zarontin_b
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {205560.0},
    MM = 0.14117,
    adminMass = 0.0007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Diezi_2023</td></tr><tr><td>measured_compound:</td><td>Ethosuximide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>prp21032-tbl-0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.17 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 't max [h] (range)' — extend the ontology if this is a real PK parameter (source ['Diezi_2023_table_1:row2:col1'])</li><li>NIL: refused to back-fill base 'equation variable' from footnote/prose loose number 67.2 (source ['prp21032-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'θ weight'</li><li>NIL: refused to back-fill base 'allometric_exponent' from footnote/prose loose number None (source ['prp21032-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Ethosuximide</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'syrup (zarontin®) (b)' subgroup of Diezi_2023 (paper reports 4 populations: final model estimate, granules (a), granules (b), syrup (zarontin®) (b))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end Ethosuximide_Diezi2023_syrup_zarontin_b;
