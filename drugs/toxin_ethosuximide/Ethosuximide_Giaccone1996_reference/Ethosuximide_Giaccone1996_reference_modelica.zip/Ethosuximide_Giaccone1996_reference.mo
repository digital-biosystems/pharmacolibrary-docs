model Ethosuximide_Giaccone1996_reference
  parameter Real Cl_ref = 2.9749999999999996e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.041999999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.14117,
    adminMass = 0.00125,
    ka = 0.0015527777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>healthy control subjects and epileptic patients receiving chronic therapy with phenobarbitone, phenytoin and/or carbamazepine</td></tr><tr><td>source_paper:</td><td>Giaccone_1996</td></tr><tr><td>measured_compound:</td><td>Ethosuximide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.17 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('controls half-lives', value 53.7) — already have one for this compound</li><li>dropped duplicate Q27 ('controls apparent oral clearance (CL/F)', value 9.2) — already have one for this compound</li><li>dropped duplicate Q76 ('controls apparent volume of distribution (V/F)', value 0.7) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Ethosuximide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Ethosuximide_Giaccone1996_reference;
