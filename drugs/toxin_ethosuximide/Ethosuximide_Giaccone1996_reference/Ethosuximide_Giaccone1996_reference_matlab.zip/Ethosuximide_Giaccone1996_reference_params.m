function p = Ethosuximide_Giaccone1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethosuximide   source: Giaccone_1996 / reference   route: oral
  p.name  = 'Ethosuximide_Giaccone1996_reference_params';
  p.drug  = 'ethosuximide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.0;                % central volume [L]
  p.CL = 1.071;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.59;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1250.0;             % dose [mg]
end
