// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ethosuximide_Marbury1981_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {198000.0},
    MM = 0.14117,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>patients with chronic renal disease</td></tr><tr><td>source_paper:</td><td>Marbury_1981</td></tr><tr><td>measured_compound:</td><td>Ethosuximide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.17 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for E_HD from footnote/prose kept as documentation only (['Marbury_1981:abstract', 'Marbury_1981:abstract'])</li><li>dropped duplicate Q57 ('elimination half-life of ethosuximide ... to an average of', value 3.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ethosuximide</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end Ethosuximide_Marbury1981_reference;
