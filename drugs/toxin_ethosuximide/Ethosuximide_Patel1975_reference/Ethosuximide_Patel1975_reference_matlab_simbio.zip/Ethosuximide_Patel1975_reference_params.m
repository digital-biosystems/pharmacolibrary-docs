function p = Ethosuximide_Patel1975_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethosuximide   source: Patel_1975 / reference   route: oral
  p.name  = 'Ethosuximide_Patel1975_reference_params';
  p.drug  = 'ethosuximide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 56.0;                % central volume [L]
  p.CL = 1.344;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.59;                % absorption rate [1/h]
  p.F  = 0.96;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1250.0;             % dose [mg]
end
