model Ethosuximide_Patel1975_reference
  parameter Real Cl_ref = 3.7333333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.056 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 96.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.14117,
    adminMass = 0.00125,
    ka = 0.0015527777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>6 chronically catheterized male rhesus monkeys</td></tr><tr><td>source_paper:</td><td>Patel_1975</td></tr><tr><td>measured_compound:</td><td>Ethosuximide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.17 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('The volume of distribution', value 0.8) — already have one for this compound</li><li>dropped duplicate Q57 ('The overall mean (+/- SD) elimination half-life', value 28.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ethosuximide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Ethosuximide_Patel1975_reference;
