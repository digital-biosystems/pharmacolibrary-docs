model Dapsone_Kotila2023_reference
  parameter Real Cl_ref = 3.6666666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08925 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24830000000000002,
    adminMass = 5e-05,
    ka = 0.0004944444444444445,
    Tlag = 1440.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dapsone</td></tr><tr><td>population:</td><td>healthy NIGERIANS</td></tr><tr><td>source_paper:</td><td>Kotila_2023</td></tr><tr><td>measured_compound:</td><td>Dapsone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dapsone 248.3 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Lh-1' (CL/F)</li><li>dropped value-less row: 'Sex'</li><li>dropped value-less row: 'Body weight'</li><li>implicit units: 'Cl/F' → L/h (from the popPK convention: 'For population pharmacokinetic clearance parameters (CL/F) with a value of 1.32, L/h is the standard unit consistent wit')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Dapsone</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Dapsone_Kotila2023_reference;
