function p = Dapsone_Kotila2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dapsone   source: Kotila_2023 / reference   route: oral
  p.name  = 'Dapsone_Kotila2023_reference_params';
  p.drug  = 'dapsone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 89.25;                % central volume [L]
  p.CL = 1.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.78;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.4;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
