model Camostat_Kosinsky2022_PD_viral_entry_rate
  "indirect_response_i exposure-response sweep — Kosinsky_2022 :: Viral entry rate (name)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 7.46,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 75, Interval = 0.15),
    Documentation(info = "<html><body><h4>Camostat_Kosinsky2022_PD_viral_entry_rate</h4><p>The steady-state exposure-response curve of Kosinsky Y et al., <i>Microbiology spectrum 10(2):e0216721</i> 2022 (<a href=\"https://doi.org/10.1128/spectrum.02167-21\">doi:10.1128/spectrum.02167-21</a>) — name [relative to control] against FOY-251 nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       7.46 nM       exposure at half of the maximal effect term (Ki, nM — R.S.E. (%), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of FOY-251 per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.46 nM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Camostat_Kosinsky2022_PD_viral_entry_rate;
