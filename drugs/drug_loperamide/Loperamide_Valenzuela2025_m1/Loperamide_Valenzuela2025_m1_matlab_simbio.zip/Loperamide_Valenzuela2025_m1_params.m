function p = Loperamide_Valenzuela2025_m1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: loperamide   source: Valenzuela_2025 / m1   route: oral
  % estimated (absent from source): dose
  p.name  = 'Loperamide_Valenzuela2025_m1_params';
  p.drug  = 'loperamide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1650.0;                % central volume [L]
  p.CL = 52.4;                % clearance [L/h]
  p.Vp = [805.0];             % peripheral volumes [L]
  p.Q  = [96.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.258;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
