model Loperamide_Valenzuela2025_loperamide
  parameter Real Cl_ref = 8.138888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.38 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.477038,
    adminMass = 8e-06,
    ka = 0.00033055555555555556,
    Tlag = 536.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About loperamide</h4><p>Loperamide is an antidiarrhoeal medicine used to treat diarrhoea, including in conditions such as shigellosis and irritable bowel syndrome. It is widely used and appears on the WHO list of essential medicines, and is also being investigated for other uses such as managing withdrawal symptoms.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423751\">Wikidata Q423751</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>loperamide</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Valenzuela_2025</td></tr><tr><td>measured_compound:</td><td>loperamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70114-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>loperamide 477.038 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q87 ('F 48 mg', value '1.20') — already have one for this compound</li><li>dropped duplicate Q49 ('k a 48 mg (h−1)', value '4.21') — already have one for this compound</li><li>dropped duplicate Q83 ('Alag 48 mg (h)', value '0.271') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=loperamide</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>status held at route_to_review — not promoted</li><li>population split: 'loperamide' subgroup of Valenzuela_2025 (paper reports 2 populations: loperamide, m1)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Loperamide_Valenzuela2025_loperamide;
