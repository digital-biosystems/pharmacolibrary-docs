function p = Loperamide_Valenzuela2025_PD_qtcf_params()
% Loperamide_Valenzuela2025_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% loperamide Valenzuela_2025::QTcF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ΔΔQTcF in msec. Driver: M1 (conc_no_pk).
p.E0 = -0.00166;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 544.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
