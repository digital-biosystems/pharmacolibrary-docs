model Loperamide_Valenzuela2025_PD_qtcf
  "linear exposure-response sweep — Valenzuela_2025 :: ΔΔQTcF (placebo-adjusted change from baseline in Fridericia-corrected QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = -0.00166,      // [s; msec × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 544   "[meter ** 3 * second / kilogram; msec/ng·mL × 1000]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // off_target_driver: driver compound 'M1' is not 'loperamide' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About loperamide</h4><p>Loperamide is an antidiarrhoeal medicine used to treat diarrhoea, including in conditions such as shigellosis and irritable bowel syndrome. It is widely used and appears on the WHO list of essential medicines, and is also being investigated for other uses such as managing withdrawal symptoms.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423751\">Wikidata Q423751</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Loperamide_Valenzuela2025_PD_qtcf</h4><p>The steady-state exposure-response curve of Valenzuela B et al., <i>Clinical and translational science 18(2):e70114</i> 2025 (<a href=\"https://doi.org/10.1111/cts.70114\">doi:10.1111/cts.70114</a>) — placebo-adjusted change from baseline in Fridericia-corrected QT interval [msec] against M1 ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      -1.66 msec     drug-free response (baseline) (Intercept, Q324)
  slope =      0.544 msec/ng·mL change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of M1 per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -0.00166   (drug-free)</pre></body></html>"));
end Loperamide_Valenzuela2025_PD_qtcf;
