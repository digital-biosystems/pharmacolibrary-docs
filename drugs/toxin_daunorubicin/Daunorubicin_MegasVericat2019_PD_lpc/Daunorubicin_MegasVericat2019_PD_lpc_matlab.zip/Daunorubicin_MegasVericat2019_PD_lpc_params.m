function p = Daunorubicin_MegasVericat2019_PD_lpc_params()
% Daunorubicin_MegasVericat2019_PD_lpc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% daunorubicin Megías-Vericat_2019::LPC: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response LPC in cells. Driver: daunorubicin (cited_pk).
p.E0 = 7926.0;
p.Emax = -1.0;
p.EC50 = 0.458;
p.gamma = 1.13;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 4.6;
p.form = 'E0 + Emax*frac';
end
