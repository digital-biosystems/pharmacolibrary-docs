// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_4Aminopyridine_Capacio1997_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3900.0},
    MM = 0.094117,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4_aminopyridine</td></tr><tr><td>population:</td><td>awake chronically instrumented and uninstrumented guinea pigs</td></tr><tr><td>source_paper:</td><td>Capacio_1997</td></tr><tr><td>measured_compound:</td><td>4-aminopyridine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>4-aminopyridine 94.117 g/mol (pubchem); 4_aminopyridine 94.117 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'half-life of elimination, IN animals' Q47 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('half-life of elimination, UN animals', value 71) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives', value '68') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-aminopyridine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_4Aminopyridine_Capacio1997_reference;
