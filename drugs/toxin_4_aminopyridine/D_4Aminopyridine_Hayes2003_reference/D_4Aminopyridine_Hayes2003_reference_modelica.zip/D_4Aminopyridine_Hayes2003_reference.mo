// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_4Aminopyridine_Hayes2003_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {12600.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4_aminopyridine</td></tr><tr><td>population:</td><td>healthy control subjects and patients with spinal cord injury</td></tr><tr><td>source_paper:</td><td>Hayes_2003</td></tr><tr><td>measured_compound:</td><td>4-Aminopyridine (Fampridine)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>4_aminopyridine 94.117 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-Aminopyridine (Fampridine)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: t 1/2 printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for '4-Aminopyridine (Fampridine)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_4Aminopyridine_Hayes2003_reference;
