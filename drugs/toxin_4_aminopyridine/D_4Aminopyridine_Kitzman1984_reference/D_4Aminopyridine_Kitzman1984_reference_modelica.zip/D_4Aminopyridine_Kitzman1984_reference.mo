model D_4Aminopyridine_Kitzman1984_reference
  parameter Real Cl_ref = 6.183333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0623 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.094117,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4_aminopyridine</td></tr><tr><td>population:</td><td>intact awake horses</td></tr><tr><td>source_paper:</td><td>Kitzman_1984</td></tr><tr><td>measured_compound:</td><td>4-aminopyridine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>4-aminopyridine 94.117 g/mol (pubchem); 4_aminopyridine 94.117 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-aminopyridine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_4Aminopyridine_Kitzman1984_reference;
