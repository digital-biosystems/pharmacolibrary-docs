function p = Dapsone_Kotila2023_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dapsone   source: Kotila_2023 / median   route: oral
  p.name  = 'Dapsone_Kotila2023_median_params';
  p.drug  = 'dapsone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 55.56;                % central volume [L]
  p.CL = 1.52;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.09;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
