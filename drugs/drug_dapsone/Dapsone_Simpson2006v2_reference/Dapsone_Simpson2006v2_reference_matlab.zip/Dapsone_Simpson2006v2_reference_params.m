function p = Dapsone_Simpson2006v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dapsone   source: Simpson_2006_2 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Dapsone_Simpson2006v2_reference_params';
  p.drug  = 'dapsone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 50.0;                % central volume [L]
  p.CL = 72.0;                % clearance [L/h]
  p.Vp = [1612.75];             % peripheral volumes [L]
  p.Q  = [54.67];             % inter-compartmental clearances [L/h]
  p.ka = 0.93;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
