function p = Dapsone_Mirochnick2001_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dapsone   source: Mirochnick_2001 / reference   route: oral
  p.name  = 'Dapsone_Mirochnick2001_reference_params';
  p.drug  = 'dapsone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 98.0;                % central volume [L]
  p.CL = 1.981;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.66;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
