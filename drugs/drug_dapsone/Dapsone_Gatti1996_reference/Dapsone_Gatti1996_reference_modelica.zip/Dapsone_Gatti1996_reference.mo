model Dapsone_Gatti1996_reference
  parameter Real Cl_ref = 5.083333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0696 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dapsone</td></tr><tr><td>population:</td><td>HIV-infected patients</td></tr><tr><td>source_paper:</td><td>Gatti_1996</td></tr><tr><td>measured_compound:</td><td>dapsone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['tab_1:row0:col1', 'tab_1:row0:col4', 'tab_1:row0:col5'])</li><li>dropped unlinked row (NIL): 'Mean' — extend the ontology if this is a real PK parameter (source ['tab_1:row1:col1', 'tab_1:row1:col2', 'tab_1:row1:col3', 'tab_1:row1:col4', 'tab_1:row1:col6', 'tab_1:row1:col7'])</li><li>salvaged Q27 ('CL/F'=1.83) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=69.6) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('decrease of clearance of dapsone by AZT'=25) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dapsone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>unit re-normalised: CL/F 'liters/h' now converts (value unchanged)</li><li>unit re-normalised: V/F 'liters' now converts (value unchanged)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dapsone_Gatti1996_reference;
