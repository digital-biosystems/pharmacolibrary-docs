// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Salmeterol_Sunwoo2017_fts_750_g_sm_150_g_ttp_54_g
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {170640.0},
    MM = 0.415574,
    adminMass = 1.8e-08,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salmeterol</td></tr><tr><td>population:</td><td>10 healthy male subjects</td></tr><tr><td>source_paper:</td><td>Sunwoo_2017</td></tr><tr><td>measured_compound:</td><td>Salmeterol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>salmeterol 415.574 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Fluticasone'; source reconciliation required</li><li>table representations disagree for 'Salmeterol'; source reconciliation required</li><li>table representations disagree for 'Tiotropium'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Fluticasone' — extend the ontology if this is a real PK parameter (source ['T1:row1:col4'])</li><li>dropped unlinked row (NIL): 'Salmeterol' — extend the ontology if this is a real PK parameter (source ['T1:row9:col4'])</li><li>dropped unlinked row (NIL): 'Tiotropium' — extend the ontology if this is a real PK parameter (source ['T1:row17:col4'])</li><li>salvaged Q57 ('TTP t1/2'=47.4) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Salmeterol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'fts 750 µg/sm 150 µg + ttp 54 µg (n=6)' subgroup of Sunwoo_2017 (paper reports 3 populations: fts 250 µg/sm 50 µg + ttp 18 µg (n=10), fts 500 µg/sm 100 µg + ttp 36 µg (n=10), fts 750 µg/sm 150 µg + ttp 54 µg (n=6))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1728.0));
end Salmeterol_Sunwoo2017_fts_750_g_sm_150_g_ttp_54_g;
