model Salmeterol_Himstedt2020_reference
  parameter Real Cl_ref = 7.505555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008610000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.415574,
    adminMass = 1e-05,
    k12 = 0.007317073170731706,
    k21 = 0.0002387267904509284
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salmeterol</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Himstedt_2020</td></tr><tr><td>measured_compound:</td><td>Salmeterol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-12-00408-t001</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>salmeterol 415.574 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>conflicting source units for 'Kp,T': [{'unit': '-', 'source': 'pharmaceutics-12-00408-t001:row5:col1', 'scope': 'unit_column'}, {'unit': 'T', 'source': 'pharmaceutics-12-00408-t001:row5:col0', 'scope': 'label'}]</li><li>conflicting source units for 'Kp,B': [{'unit': '-', 'source': 'pharmaceutics-12-00408-t001:row6:col1', 'scope': 'unit_column'}, {'unit': 'B', 'source': 'pharmaceutics-12-00408-t001:row6:col0', 'scope': 'label'}]</li><li>conflicting source units for 'Kp,A': [{'unit': '-', 'source': 'pharmaceutics-12-00408-t001:row7:col1', 'scope': 'unit_column'}, {'unit': 'A', 'source': 'pharmaceutics-12-00408-t001:row7:col0', 'scope': 'label'}]</li><li>dropped duplicate Q410 ('Kp,B', value '18.6') — already have one for this compound</li><li>dropped duplicate Q410 ('Kp,A', value '39.3') — already have one for this compound</li><li>dropped duplicate Q30 ('QT 1', value '0.054') — already have one for this compound</li><li>dropped duplicate Q30 ('QA 1', value '10.6') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Salmeterol</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salmeterol_Himstedt2020_reference;
