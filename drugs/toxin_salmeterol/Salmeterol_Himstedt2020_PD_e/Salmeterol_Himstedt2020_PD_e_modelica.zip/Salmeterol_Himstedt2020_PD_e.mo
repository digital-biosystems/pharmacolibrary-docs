model Salmeterol_Himstedt2020_PD_e
  "emax exposure-response sweep — Himstedt_2020 :: E (Effect)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 0.0271,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.28, Interval = 0.00056),
    Documentation(info = "<html><body><h4>Salmeterol_Himstedt2020_PD_e</h4><p>The steady-state exposure-response curve of Himstedt A et al., <i>Pharmaceutics 12(5):E408</i> 2020 (<a href=\"https://doi.org/10.3390/pharmaceutics12050408\">doi:10.3390/pharmaceutics12050408</a>) — Effect against salmeterol nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q320)
  EC50  =     0.0271 nM       exposure at half of the maximal effect term (EC50,free, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of salmeterol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0271 nM)  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Salmeterol_Himstedt2020_PD_e;
