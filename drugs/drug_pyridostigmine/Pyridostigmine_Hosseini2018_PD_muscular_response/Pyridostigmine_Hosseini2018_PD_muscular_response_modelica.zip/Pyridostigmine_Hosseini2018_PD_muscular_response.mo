model Pyridostigmine_Hosseini2018_PD_muscular_response
  "indirect_response_ii exposure-response sweep — Hosseini_2018 :: muscular response (percent gain of muscular response)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 58.6104218362,      // [% gain]
    Emax = 1,  // type II effect term
    EC50 = 2.9e-05,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (2362/40.3 = 58.61) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.29, Interval = 0.00058),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pyridostigmine</h4><p>Pyridostigmine is an acetylcholinesterase inhibitor used primarily for myasthenia gravis. It is typically taken by mouth or given by injection, though oral absorption is poor. It is widely used and appears on the WHO essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q419472\">Wikidata Q419472</a>, <a href=\"https://en.wikipedia.org/wiki/Pyridostigmine?oldid=1381274385\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pyridostigmine_Hosseini2018_PD_muscular_response</h4><p>The steady-state exposure-response curve of Hosseini I et al., <i>Journal of pharmacokinetics and pharmacodynamics 45(2):259-275</i> 2018 (<a href=\"https://doi.org/10.1007/s10928-017-9562-9\">doi:10.1007/s10928-017-9562-9</a>) — percent gain of muscular response [% gain] against pyridostigmine μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 58.6104218362 % gain   drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =      0.029 μg/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/mL of pyridostigmine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 58.61   (drug-free)
  exposure = EC50 (0.029 μg/mL)  response 117.2
  exposure -> infinity  response inf</pre></body></html>"));
end Pyridostigmine_Hosseini2018_PD_muscular_response;
