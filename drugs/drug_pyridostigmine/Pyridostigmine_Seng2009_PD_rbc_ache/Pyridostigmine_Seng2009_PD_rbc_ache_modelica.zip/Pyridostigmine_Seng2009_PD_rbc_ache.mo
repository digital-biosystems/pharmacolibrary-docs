model Pyridostigmine_Seng2009_PD_rbc_ache
  "emax exposure-response sweep — Seng_2009 :: RBC AChE (red blood cell acetylcholinesterase (AChE) activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -9.32,  // [AChE units per gram haemoglobin]
    EC50 = 5.19e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 520, Interval = 1.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pyridostigmine</h4><p>Pyridostigmine is an acetylcholinesterase inhibitor used primarily for myasthenia gravis. It is typically taken by mouth or given by injection, though oral absorption is poor. It is widely used and appears on the WHO essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q419472\">Wikidata Q419472</a>, <a href=\"https://en.wikipedia.org/wiki/Pyridostigmine?oldid=1381274385\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pyridostigmine_Seng2009_PD_rbc_ache</h4><p>The steady-state exposure-response curve of Seng KY et al., <i>The Journal of pharmacy and pharmacology 61(9):1187–1196</i> 2009 (<a href=\"https://doi.org/10.1211/jpp/61.09.0008\">doi:10.1211/jpp/61.09.0008</a>) — red blood cell acetylcholinesterase (AChE) activity [AChE units per gram haemoglobin] against pyridostigmine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       9.32 AChE units per gram haemoglobin maximal effect term (maximum red blood cell AChE activity decrease, Q323)
  EC50  =       51.9 ng/ml    exposure at half of the maximal effect term (plasma pyridostigmine concentration producing 50% of this reduction, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of pyridostigmine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (51.9 ng/ml)  response -4.66
  exposure -> infinity  response -9.32</pre></body></html>"));
end Pyridostigmine_Seng2009_PD_rbc_ache;
