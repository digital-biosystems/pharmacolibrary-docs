model Tiagabine_Jacob2016_reference
  parameter Real Cl_ref = 0.00012972442025062863 "Cl [m3/s]";
  parameter Real Vd_ref = 5.39 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375545,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tiagabine</td></tr><tr><td>population:</td><td>humans receiving newer antiepileptic drugs</td></tr><tr><td>source_paper:</td><td>Jacob_2016</td></tr><tr><td>measured_compound:</td><td>Tiagabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tiagabine 375.545 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tiagabine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=467.008 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end Tiagabine_Jacob2016_reference;
