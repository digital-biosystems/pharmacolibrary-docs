model Tiagabine_Cleton1999_reference
  parameter Real Cl_ref = 0.00012016666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 0.126 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tiagabine</td></tr><tr><td>population:</td><td>conscious rats</td></tr><tr><td>source_paper:</td><td>Cleton_1999</td></tr><tr><td>measured_compound:</td><td>tiagabine (R- and S-isomers)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tiagabine 375.545 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('clearance (S-isomer)', value 90) — already have one for this compound</li><li>dropped duplicate Q65 ('volume of distribution at steady-state (S-isomer)', value 1.6) — already have one for this compound</li><li>covariate category for ke0 from footnote/prose kept as documentation only (['Cleton_1999:abstract'])</li><li>covariate category for ke0 from footnote/prose kept as documentation only (['Cleton_1999:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tiagabine (R- and S-isomers)</li><li>molar mass: none found for 'tiagabine (R- and S-isomers)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tiagabine_Cleton1999_reference;
