// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tiagabine_Lau1997_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {25200.0},
    MM = 0.375545,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tiagabine</td></tr><tr><td>population:</td><td>subjects with mild and moderate hepatic impairment and matched normal controls</td></tr><tr><td>source_paper:</td><td>Lau_1997</td></tr><tr><td>measured_compound:</td><td>tiagabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>tiagabine 375.545 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('C(max) values (mean +/- SD) were 172 +/- 40', value 172) — already have one for this compound</li><li>dropped duplicate Q32 ('C(max) values (mean +/- SD) were 172 +/- 28', value 172) — already have one for this compound</li><li>dropped duplicate Q36 ('C(min) values were 27 +/- 4', value 27) — already have one for this compound</li><li>dropped duplicate Q36 ('C(min) values were 28 +/- 6', value 28) — already have one for this compound</li><li>dropped duplicate Q88 ('areas under the plasma concentration-time curve were 633 +/- 16', value 633) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-lives (harmonic means) were 12', value 12) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-lives (harmonic means) were 16', value 16) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tiagabine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 252.0));
end Tiagabine_Lau1997_reference;
