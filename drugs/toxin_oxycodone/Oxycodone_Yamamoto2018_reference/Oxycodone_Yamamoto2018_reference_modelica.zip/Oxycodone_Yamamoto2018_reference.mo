model Oxycodone_Yamamoto2018_reference
  parameter Real Cl_ref = 1.1666666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.315369,
    adminMass = 7.5e-05,
    ka = 0.00030000000000000003,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxycodone</td></tr><tr><td>population:</td><td>healthy adult humans</td></tr><tr><td>source_paper:</td><td>Yamamoto_2018</td></tr><tr><td>measured_compound:</td><td>Oxycodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>oxycodone 315.369 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>conflicting source units for 'QBBB,in': [{'unit': 'mL/min', 'source': 'Yamamoto_2018_table_4:row0:col1', 'scope': 'unit_column'}, {'unit': 'in', 'source': 'Yamamoto_2018_table_4:row0:col0', 'scope': 'label'}]</li><li>conflicting source units for 'QBCSFB1,in': [{'unit': 'mL/min', 'source': 'Yamamoto_2018_table_4:row5:col1', 'scope': 'unit_column'}, {'unit': 'in', 'source': 'Yamamoto_2018_table_4:row5:col0', 'scope': 'label'}]</li><li>conflicting source units for 'QBCSFB2,in': [{'unit': 'mL/min', 'source': 'Yamamoto_2018_table_4:row10:col1', 'scope': 'unit_column'}, {'unit': 'in', 'source': 'Yamamoto_2018_table_4:row10:col0', 'scope': 'label'}]</li><li>conflicting source units for 'QBCM,in': [{'unit': 'mL/min', 'source': 'Yamamoto_2018_table_4:row15:col1', 'scope': 'unit_column'}, {'unit': 'in', 'source': 'Yamamoto_2018_table_4:row15:col0', 'scope': 'label'}]</li><li>conflicting source units for 'QLYSO,in': [{'unit': 'mL/min', 'source': 'Yamamoto_2018_table_4:row19:col1', 'scope': 'unit_column'}, {'unit': 'in', 'source': 'Yamamoto_2018_table_4:row19:col0', 'scope': 'label'}]</li><li>dropped unlinked row (NIL): 'AF' — extend the ontology if this is a real PK parameter (source ['Yamamoto_2018_table_3:row3:col3', 'Yamamoto_2018_table_3:row4:col3', 'Yamamoto_2018_table_3:row5:col3', 'Yamamoto_2018_table_3:row6:col3', 'Yamamoto_2018_table_3:row7:col3', 'Yamamoto_2018_table_3:row8:col3'])</li><li>unit_dimension_unknown: 'acid' (Kp)</li><li>dropped duplicate Q410 ('pKa (acid)', value '13.6') — already have one for this compound</li><li>dropped unlinked row (NIL): 'pKa (base)' — extend the ontology if this is a real PK parameter (source ['Yamamoto_2018_table_3:row16:col3'])</li><li>dropped unlinked row (NIL): 'QBBB,in' — extend the ontology if this is a real PK parameter (source ['Yamamoto_2018_table_4:row0:col3'])</li><li>dropped duplicate Q30 ('QBBBB', value '47') — already have one for this compound</li><li>dropped unlinked row (NIL): 'PHF1' — extend the ontology if this is a real PK parameter (source ['Yamamoto_2018_table_4:row4:col3'])</li><li>dropped duplicate Q30 ('QBCSFB1,in', value '47') — already have one for this compound</li><li>dropped duplicate Q30 ('QBCSFB1,out', value '46') — already have one for this compound</li><li>dropped duplicate Q30 ('QIBCSFB1', value '6.6') — already have one for this compound</li><li>dropped duplicate Q30 ('Qp BCSFB1', value '39') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxycodone_Yamamoto2018_reference;
