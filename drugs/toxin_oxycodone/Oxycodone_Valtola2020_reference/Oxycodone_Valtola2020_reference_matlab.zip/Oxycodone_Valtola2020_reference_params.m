function p = Oxycodone_Valtola2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxycodone   source: Valtola_2020 / reference   route: oral
  p.name  = 'Oxycodone_Valtola2020_reference_params';
  p.drug  = 'oxycodone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 134.0;                % central volume [L]
  p.CL = 43.3;                % clearance [L/h]
  p.Vp = [81.9];             % peripheral volumes [L]
  p.Q  = [155.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.08;                % absorption rate [1/h]
  p.F  = 0.53;                 % bioavailability [0-1]
  p.Tlag = 0.27;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
