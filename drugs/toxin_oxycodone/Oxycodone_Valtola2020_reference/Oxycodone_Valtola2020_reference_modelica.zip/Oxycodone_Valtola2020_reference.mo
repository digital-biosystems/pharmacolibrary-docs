model Oxycodone_Valtola2020_reference
  parameter Real Cl_ref = 1.2027777777777777e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.134 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.53,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.315369,
    adminMass = 1e-05,
    ka = 0.00030000000000000003,
    Tlag = 972.0000000000001,
    k12 = 0.00032131011608623546,
    k21 = 0.0005257088590421924
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxycodone</td></tr><tr><td>population:</td><td>post coronary artery bypass surgery patients (CECC and OPCAB)</td></tr><tr><td>source_paper:</td><td>Valtola_2020</td></tr><tr><td>measured_compound:</td><td>oxycodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>oxycodone 315.369 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'V1 (L/70 kg)' routed out of structural estimates ('PPV (%) BSV')</li><li>table section iov: 'V1 (L/70 kg)' routed out of structural estimates ('PPV (%) BOV')</li><li>table section iiv: 'V2 (L/70 kg)' routed out of structural estimates ('PPV (%) BSV')</li><li>table section iiv: 'CL (L/h/70 kg)' routed out of structural estimates ('PPV (%) BSV')</li><li>table section iov: 'CL (L/h/70 kg)' routed out of structural estimates ('PPV (%) BOV')</li><li>table section iiv: 'Q (L/h/70 kg)' routed out of structural estimates ('PPV (%) BSV')</li><li>table section iiv: 'Relative bioavailability' routed out of structural estimates ('PPV (%) BSV')</li><li>dropped unlinked row (NIL): 'Flag' — extend the ontology if this is a real PK parameter (source ['Valtola_2020_table_4:row6:col1'])</li><li>dropped duplicate Q83 ('LagT (days)', value '1.25') — already have one for this compound</li><li>dropped unlinked row (NIL): 'tabs (hours)' — extend the ontology if this is a real PK parameter (source ['Valtola_2020_table_4:row8:col1'])</li><li>'Fabs' → Q40: printed without a unit and above 1 — read as a percentage</li><li>dropped value-less row: 'Table 4.. Oxycodone population pharmacokinetic parameter estimates.'</li><li>dropped value-less row: 'Parameter estimates are presented as the medians.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxycodone</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>gap-filled Q49 (kabs) from Franke_2015's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxycodone_Valtola2020_reference;
