function p = Oxycodone_Franke2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxycodone   source: Franke_2015 / reference   route: oral
  p.name  = 'Oxycodone_Franke2015_reference_params';
  p.drug  = 'oxycodone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 761.0;                % central volume [L]
  p.CL = 88.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.08;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
