// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Oxycodone_Ji2019_oral_oxycodone_10_mg_0_24_h
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.14},
    CLelim = {1.1666666666666666e-05},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxycodone</td></tr><tr><td>population:</td><td>virtual healthy adult volunteers (Sim-healthy volunteers)</td></tr><tr><td>source_paper:</td><td>Ji_2019</td></tr><tr><td>measured_compound:</td><td>Oxycodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>molar_masses:</td><td>oxycodone 315.369 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'AUC0–24h ± SD (ng·h/mL)'; source reconciliation required</li><li>table representations disagree for 'Cmax ± SD (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'tmax ± SD (h)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Oxycodone</li><li>topology: 1 first-order transfer(s) across 7 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>population split: 'oral oxycodone 10 mg (0–24 h)' subgroup of Ji_2019 (paper reports 3 populations: oral oxycodone 10 mg (0–24 h), oxycodone, oxycodonepo (s))</li><li>gap-filled Q22 (CL) from Li_2016's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Li_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Franke_2015's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Franke_2015, Li_2016 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxycodone_Ji2019_oral_oxycodone_10_mg_0_24_h;
