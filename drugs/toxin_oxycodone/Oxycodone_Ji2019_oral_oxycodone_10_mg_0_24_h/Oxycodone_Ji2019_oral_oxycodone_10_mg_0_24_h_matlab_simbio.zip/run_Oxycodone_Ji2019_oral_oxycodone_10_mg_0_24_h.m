% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Oxycodone_Ji2019_oral_oxycodone_10_mg_0_24_h_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
