model Oxycodone_Lamminsalo2019_reference
  parameter Real Cl_ref = 1.038888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0902 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.315369,
    adminMass = 7e-06,
    ka = 0.00030000000000000003,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxycodone</td></tr><tr><td>population:</td><td>female patients undergoing elective gynecological surgery with epidural analgesia</td></tr><tr><td>source_paper:</td><td>Lamminsalo_2019</td></tr><tr><td>measured_compound:</td><td>oxycodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>oxycodone 315.369 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ 1' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ 2' routed out of structural estimates ('Residual variability')</li><li>table section iiv: 'transfer rate constants from central compartment to CSF compartment compared with the opposite direction (range)' routed out of structural estimates ('A relatively high interindividual variability was seen in all parameters, especially in the central volume of distribution.')</li><li>dropped duplicate Q30 ('θ 6 (litre/h)', value '0.0537') — already have one for this compound</li><li>dropped duplicate Q30 ('θ 9 (litre/h)', value '0.00516') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxycodone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'θ 2 (litre)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Franke_2015's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxycodone_Lamminsalo2019_reference;
