function p = Oxycodone_Mehta2024_auc_pred_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxycodone   source: Mehta_2024 / auc_pred   route: oral
  % estimated (absent from source): F
  p.name  = 'Oxycodone_Mehta2024_auc_pred_params';
  p.drug  = 'oxycodone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 140.0;                % central volume [L]
  p.CL = 22.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.08;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
