function p = Fluorescein_Min2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorescein   source: Min_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Fluorescein_Min2015_reference_params';
  p.drug  = 'fluorescein';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.3;                % central volume [L]
  p.CL = 37.1;                % clearance [L/h]
  p.Vp = [18.2];             % peripheral volumes [L]
  p.Q  = [42.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
