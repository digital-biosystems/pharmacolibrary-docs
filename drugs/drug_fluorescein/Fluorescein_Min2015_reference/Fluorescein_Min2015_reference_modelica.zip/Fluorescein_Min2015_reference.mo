model Fluorescein_Min2015_reference
  parameter Real Cl_ref = 1.0305555555555558e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006299999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3323063,
    adminMass = 1e-05,
    k12 = 0.001851851851851852,
    k21 = 0.0006410256410256409
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fluorescein</h4><p>Fluorescein is a fluorescent dye used in eye examinations as a diagnostic colouring agent and contrast agent to help visualise structures of the eye. It is an approved diagnostic ophthalmological agent and is widely used in eye care, with some investigational uses as well.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410922\">Wikidata Q410922</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorescein</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Min_2015</td></tr><tr><td>measured_compound:</td><td>fluorescein</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fluorescein 332.306 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Min_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fluorescein_Min2015_reference;
