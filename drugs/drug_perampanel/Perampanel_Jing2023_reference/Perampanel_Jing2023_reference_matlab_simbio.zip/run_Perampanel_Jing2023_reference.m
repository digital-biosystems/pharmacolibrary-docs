% Run (SimBiology): build model + dose, simulate 0..672.0 h, plot.
p = Perampanel_Jing2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 672.0);
