function p = VestronidaseAlfa_Qi2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vestronidase_alfa   source: Qi_2019 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'VestronidaseAlfa_Qi2019_reference_params';
  p.drug  = 'vestronidase_alfa';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.49;                % central volume [L]
  p.CL = 1.99;                % clearance [L/h]
  p.Vp = [3.03];             % peripheral volumes [L]
  p.Q  = [0.94];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
