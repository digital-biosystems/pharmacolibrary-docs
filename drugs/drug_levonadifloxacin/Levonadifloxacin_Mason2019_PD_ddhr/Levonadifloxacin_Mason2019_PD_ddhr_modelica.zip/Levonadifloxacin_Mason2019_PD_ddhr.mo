model Levonadifloxacin_Mason2019_PD_ddhr
  "linear exposure-response sweep — Mason_2019 :: ddHR (Heart Rate)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0.9456,      // [bpm]
    slope = 393.7,  // [(1)/(kg/m3); bpm/(μg×mL−1) × 1000]
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // slope_unit_assumed: slope unit 'bpm/(μg×mL−1)' read as bpm per μg/mL
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levonadifloxacin</h4><p>Levonadifloxacin is an investigational fluoroquinolone antibacterial, related to nadifloxacin, studied as a treatment for bacterial infections. It is not an approved medicine; it remains under investigation and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27117310\">Wikidata Q27117310</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Levonadifloxacin_Mason2019_PD_ddhr</h4><p>The steady-state exposure-response curve of Mason JW et al., <i>Clinical and translational science 12(1):47–52</i> 2019 (<a href=\"https://doi.org/10.1111/cts.12594\">doi:10.1111/cts.12594</a>) — Heart Rate [bpm] against levonadifloxacin μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     0.9456 bpm      drug-free response (baseline) (intercept, Q324)
  slope =     0.3937 bpm/(μg×mL−1) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of levonadifloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.9456   (drug-free)</pre></body></html>"));
end Levonadifloxacin_Mason2019_PD_ddhr;
