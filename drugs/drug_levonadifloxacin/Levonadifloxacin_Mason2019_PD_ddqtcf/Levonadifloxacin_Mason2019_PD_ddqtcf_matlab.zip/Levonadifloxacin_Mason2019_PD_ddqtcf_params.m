function p = Levonadifloxacin_Mason2019_PD_ddqtcf_params()
% Levonadifloxacin_Mason2019_PD_ddqtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levonadifloxacin Mason_2019::ddQTcF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response ddQTcF in milliseconds. Driver: levonadifloxacin (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.017;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
