function p = Gentamicin_Abbasi2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gentamicin   source: Abbasi_2023 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Gentamicin_Abbasi2023_reference_params';
  p.drug  = 'gentamicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 23.1;                % central volume [L]
  p.CL = 4.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 240.0;             % dose [mg]
end
