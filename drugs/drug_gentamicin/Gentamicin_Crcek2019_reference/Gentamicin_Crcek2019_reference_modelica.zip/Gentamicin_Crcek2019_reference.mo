model Gentamicin_Crcek2019_reference
  parameter Real Cl_ref = 6.805555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.037380000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gentamicin</td></tr><tr><td>population:</td><td>paediatric patients</td></tr><tr><td>source_paper:</td><td>Crcek_2019</td></tr><tr><td>measured_compound:</td><td>gentamicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('Cl (L/h/kg)'=0.035) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd (L/kg)'=0.534) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=gentamicin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Gentamicin_Crcek2019_reference;
