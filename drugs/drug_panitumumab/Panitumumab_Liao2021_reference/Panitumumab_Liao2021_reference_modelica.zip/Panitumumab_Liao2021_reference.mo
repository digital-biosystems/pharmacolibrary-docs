model Panitumumab_Liao2021_reference
  parameter Real Cl_ref = 2.4074074074074074e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00322 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00042,
    k12 = 1.3658845180584312e-06,
    k21 = 1.766324557489216e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About panitumumab</h4><p>Panitumumab is a monoclonal antibody that blocks EGFR and is used to treat colorectal cancers, including colon and rectal cancer. It is authorised in the European Union for colorectal cancer and is an approved drug, though it also remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417775\">Wikidata Q417775</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>panitumumab</td></tr><tr><td>population:</td><td>patients with metastatic RAS wild-type colorectal cancer</td></tr><tr><td>source_paper:</td><td>Liao_2021</td></tr><tr><td>measured_compound:</td><td>panitumumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q63 ('panitumumab V1'=3.22) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=0.208) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('peripheral volume of distribution'=2.49) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('inter-compartmental clearance'=0.38) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=panitumumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'panitumumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Panitumumab_Liao2021_reference;
