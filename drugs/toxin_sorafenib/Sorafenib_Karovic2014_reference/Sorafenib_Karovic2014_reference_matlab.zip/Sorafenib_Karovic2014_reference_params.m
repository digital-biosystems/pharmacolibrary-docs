function p = Sorafenib_Karovic2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sorafenib   source: Karovic_2014 / reference   route: oral
  p.name  = 'Sorafenib_Karovic2014_reference_params';
  p.drug  = 'sorafenib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2900.0;                % central volume [L]
  p.CL = 11.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
