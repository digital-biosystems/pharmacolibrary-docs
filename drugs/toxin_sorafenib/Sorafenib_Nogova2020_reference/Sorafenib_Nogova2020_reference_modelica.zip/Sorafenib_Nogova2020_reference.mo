model Sorafenib_Nogova2020_reference
  parameter Real Cl_ref = 4.277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0466 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.46482799999999996,
    adminMass = 0.0008,
    ka = 0.00020555555555555556,
    Tlag = 0.0,
    k12 = 0.00037553648068669525,
    k21 = 2.8594771241830065e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sorafenib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Nogova_2020</td></tr><tr><td>measured_compound:</td><td>sorafenib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sorafenib 464.828 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Nogova_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sorafenib_Nogova2020_reference;
