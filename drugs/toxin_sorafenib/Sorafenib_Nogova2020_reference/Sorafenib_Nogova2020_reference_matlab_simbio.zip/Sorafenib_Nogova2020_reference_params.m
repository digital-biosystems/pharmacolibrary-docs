function p = Sorafenib_Nogova2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sorafenib   source: Nogova_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Sorafenib_Nogova2020_reference_params';
  p.drug  = 'sorafenib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.6;                % central volume [L]
  p.CL = 15.4;                % clearance [L/h]
  p.Vp = [612.0];             % peripheral volumes [L]
  p.Q  = [63.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.74;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
