model Azithromycin_Benn2017_PD_hr
  "sigmoid_emax exposure-response sweep — Benn_2017 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 92.9,      // [beats/min]
    Emax = -23.4,  // [beats/min]
    EC50 = 0.000105,  // [kg/m3; μg/L × 1e-06]
    gamma = 11,
    exposure_per_s = 1e-06);   // 1 μg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 1100, Interval = 2.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About azithromycin</h4><p>Azithromycin is a macrolide antibiotic used to treat many bacterial infections, including pneumonia, bronchitis, sinusitis, otitis media, chlamydia infection, and skin infections. It is widely used around the world and appears on the WHO list of essential medicines; it is also available as an eye drop for eye infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q165399\">Wikidata Q165399</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Azithromycin_Benn2017_PD_hr</h4><p>The steady-state exposure-response curve of Benn K et al., <i>The American journal of case reports 18:883–886</i> 2017 (<a href=\"https://doi.org/10.12659/ajcr.905400\">doi:10.12659/ajcr.905400</a>) — heart rate [beats/min] against azithromycin μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       92.9 beats/min drug-free response (baseline) (Baseline heart rate, Q324)
  Emax  =      -23.4 beats/min maximal effect term (Emax, Q323)
  EC50  =        105 μg/L     exposure at half of the maximal effect term (EC50, Q322)
  gamma =         11          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/L of azithromycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 92.9   (drug-free)
  exposure = EC50 (105 μg/L)  response 81.2
  exposure -> infinity  response 69.5</pre></body></html>"));
end Azithromycin_Benn2017_PD_hr;
