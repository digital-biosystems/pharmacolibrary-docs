function p = Azithromycin_Benn2017_PD_hr_params()
% Azithromycin_Benn2017_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% azithromycin Benn_2017::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response HR in beats/min. Driver: azithromycin (pk_record).
p.E0 = 92.9;
p.Emax = -23.4;
p.EC50 = 0.00010499999999999998;
p.gamma = 11.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1100.0;
p.form = 'E0 + Emax*frac';
end
