function p = Firmonertinib_Zou2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: firmonertinib   source: Zou_2022 / reference   route: oral
  p.name  = 'Firmonertinib_Zou2022_reference_params';
  p.drug  = 'firmonertinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2897.0;                % central volume [L]
  p.CL = 70.5;                % clearance [L/h]
  p.Vp = [1470.0];             % peripheral volumes [L]
  p.Q  = [12.4];             % inter-compartmental clearances [L/h]
  p.ka = 1.34;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
