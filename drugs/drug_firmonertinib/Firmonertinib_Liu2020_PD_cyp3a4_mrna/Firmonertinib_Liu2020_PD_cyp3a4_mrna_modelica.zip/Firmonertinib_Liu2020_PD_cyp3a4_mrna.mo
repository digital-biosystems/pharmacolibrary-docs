model Firmonertinib_Liu2020_PD_cyp3a4_mrna
  "emax exposure-response sweep — Liu_2020 :: CYP3A4 mRNA (CYP3A4 mRNA expression)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 9.24,  // [fold]
    EC50 = 0.25,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.5, Interval = 0.005),
    Documentation(info = "<html><body><!-- drug-about --><h4>About firmonertinib</h4><p>Firmonertinib is an epidermal growth factor receptor antagonist used to treat non-small cell lung cancer. It is approved in China and is currently being developed outside that region.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q140641519\">Wikidata Q140641519</a>, <a href=\"https://en.wikipedia.org/wiki/Firmonertinib?oldid=1375970303\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Firmonertinib_Liu2020_PD_cyp3a4_mrna</h4><p>The steady-state exposure-response curve of Liu XY et al., <i>Acta pharmacologica Sinica 41(10):1366–1376</i> 2020 (<a href=\"https://doi.org/10.1038/s41401-020-0389-3\">doi:10.1038/s41401-020-0389-3</a>) — CYP3A4 mRNA expression [fold] against Alflutinib μM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       9.24 fold     maximal effect term (Emax, Q320)
  EC50  =       0.25 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of Alflutinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.25 μM)  response 4.62
  exposure -> infinity  response 9.24</pre></body></html>"));
end Firmonertinib_Liu2020_PD_cyp3a4_mrna;
