function p = Firmonertinib_Liu2020_PD_cyp3a4_mrna_params()
% Firmonertinib_Liu2020_PD_cyp3a4_mrna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% firmonertinib Liu_2020::CYP3A4_mRNA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response CYP3A4 mRNA in fold. Driver: Alflutinib (conc_no_pk).
p.E0 = 0.0;
p.Emax = 9.24;
p.EC50 = 0.25;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2.5;
p.form = 'E0 + Emax*frac';
end
