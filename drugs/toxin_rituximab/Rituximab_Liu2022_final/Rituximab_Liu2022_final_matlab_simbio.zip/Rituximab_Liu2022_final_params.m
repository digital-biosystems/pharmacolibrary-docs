function p = Rituximab_Liu2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Liu_2022 / final   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Rituximab_Liu2022_final_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.39;                % central volume [L]
  p.CL = 0.187083;                % clearance [L/h]
  p.Vp = [13.03];             % peripheral volumes [L]
  p.Q  = [0.0075];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
