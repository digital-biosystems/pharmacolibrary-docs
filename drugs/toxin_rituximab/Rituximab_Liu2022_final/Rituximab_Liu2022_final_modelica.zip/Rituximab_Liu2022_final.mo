model Rituximab_Liu2022_final
  parameter Real Cl_ref = 5.1967592592592596e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00539 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 3.8651824366110077e-07,
    k21 = 1.5988743924277305e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>newly diagnosed DLBCL patients treated with triweekly R-CHOP</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>Rituximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13186-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ add+Mult' routed out of structural estimates ('Residual variability (CV%)')</li><li>dropped duplicate Q22 ('tvCI2 (L/d)', value '26.61') — already have one for this compound</li><li>dropped unlinked row (NIL): 'tvCMultStdev' — extend the ontology if this is a real PK parameter (source ['Liu_2022_table_p9_1:row4:col2'])</li><li>dropped unlinked row (NIL): 'dCI2-stage III' — extend the ontology if this is a real PK parameter (source ['Liu_2022_table_p9_1:row6:col2'])</li><li>dropped unlinked row (NIL): 'dCI2-stage IV' — extend the ontology if this is a real PK parameter (source ['Liu_2022_table_p9_1:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Rituximab</li><li>model-stage split: 'final model %res' is the final model of Liu_2022 (paper reports 2 stages: final model %res, final model estimate); same population, different model-building step</li><li>molar mass: none found for 'rituximab' — its concentrations stay mass-only</li><li>gap-filled Q30 (Q) from Chen_2021's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q23 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Rituximab_Liu2022_final;
