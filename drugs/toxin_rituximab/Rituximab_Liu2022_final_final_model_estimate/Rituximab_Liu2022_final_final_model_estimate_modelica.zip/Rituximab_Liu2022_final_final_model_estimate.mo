model Rituximab_Liu2022_final_final_model_estimate
  parameter Real Cl_ref = 3.703703703703704e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0034300000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.0003188775510204081,
    k21 = 0.00014840569877883308
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>newly diagnosed DLBCL patients treated with triweekly R-CHOP</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>Rituximab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13186-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ add+Mult' routed out of structural estimates ('Residual variability (CV%)')</li><li>table section iiv: 'ω²V' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω²V2' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω²CL' routed out of structural estimates ('Interindividual variability')</li><li>routed 'tvCMultStdev' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped duplicate Q22 ('dCI2-stage III', value '0.77') — already have one for this compound</li><li>dropped unlinked row (NIL): 'dCI2-stage IV' — extend the ontology if this is a real PK parameter (source ['Liu_2022_table_p9_1:row7:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Rituximab</li><li>model-stage split: 'final model estimate' is the final model of Liu_2022 (paper reports 2 stages: final model %res, final model estimate); same population, different model-building step</li><li>molar mass: none found for 'rituximab' — its concentrations stay mass-only</li><li>gap-filled Q69 (Q/F) from Zhao_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q355 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Rituximab_Liu2022_final_final_model_estimate;
