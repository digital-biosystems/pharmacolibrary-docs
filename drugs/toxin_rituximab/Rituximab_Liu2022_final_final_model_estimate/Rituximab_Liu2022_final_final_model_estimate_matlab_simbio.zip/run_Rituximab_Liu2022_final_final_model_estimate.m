% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Rituximab_Liu2022_final_final_model_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
