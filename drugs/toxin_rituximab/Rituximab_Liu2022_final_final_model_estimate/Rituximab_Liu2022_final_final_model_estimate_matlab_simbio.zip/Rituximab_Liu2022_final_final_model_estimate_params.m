function p = Rituximab_Liu2022_final_final_model_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Liu_2022 / final_final_model_estimate   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Rituximab_Liu2022_final_final_model_estimate_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.43;                % central volume [L]
  p.CL = 0.013333;                % clearance [L/h]
  p.Vp = [7.37];             % peripheral volumes [L]
  p.Q  = [3.9375];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
