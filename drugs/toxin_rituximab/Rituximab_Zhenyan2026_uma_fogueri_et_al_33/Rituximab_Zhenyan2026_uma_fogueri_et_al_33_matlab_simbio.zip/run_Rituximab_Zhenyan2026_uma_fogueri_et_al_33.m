% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Rituximab_Zhenyan2026_uma_fogueri_et_al_33_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
