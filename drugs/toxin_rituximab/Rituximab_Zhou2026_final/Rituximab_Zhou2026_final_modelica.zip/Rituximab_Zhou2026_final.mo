model Rituximab_Zhou2026_final
  parameter Real Cl_ref = 5.027777777777779e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008119999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0005,
    k12 = 7.286535303776684e-07,
    k21 = 2.026255707762557e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>treatment-naive Chinese patients with diffuse large B-cell lymphoma</td></tr><tr><td>source_paper:</td><td>Zhou_2026</td></tr><tr><td>measured_compound:</td><td>Rituximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70683-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'A/G Ratio' — extend the ontology if this is a real PK parameter (source ['Zhou_2026_table_p5_1:row5:col1'])</li><li>routed 'RV (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Rituximab</li><li>model-stage split: 'final model estimate' is the final model of Zhou_2026 (paper reports 2 stages: final model estimate, final model shr./%); same population, different model-building step</li><li>molar mass: none found for 'rituximab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Rituximab_Zhou2026_final;
