function p = Rituximab_Zhenyan2026_florent_puisset_et_al_60_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Zhenyan_2026 / florent_puisset_et_al_60   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Rituximab_Zhenyan2026_florent_puisset_et_al_60_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.54;                % central volume [L]
  p.CL = 0.00248;                % clearance [L/h]
  p.Vp = [39.18];             % peripheral volumes [L]
  p.Q  = [0.0075];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
