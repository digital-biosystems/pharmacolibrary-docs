function p = Rituximab_Gibiansky2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Gibiansky_2021 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Rituximab_Gibiansky2021_reference_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.99;                % central volume [L]
  p.CL = 0.064583;                % clearance [L/h]
  p.Vp = [3.7];             % peripheral volumes [L]
  p.Q  = [0.0175];             % inter-compartmental clearances [L/h]
  p.ka = 0.0155;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
