model Rituximab_Gibiansky2021_reference
  parameter Real Cl_ref = 1.7939814814814816e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00499 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 4.305555555555555e-06,
    Tlag = 0.0,
    k12 = 9.7417056334892e-07,
    k21 = 1.3138138138138138e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>patients with chronic lymphocytic leukemia</td></tr><tr><td>source_paper:</td><td>Gibiansky_2021</td></tr><tr><td>measured_compound:</td><td>Rituximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412665-tbl-0003</td></tr><tr><td>input:</td><td>PK_3C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'kdes (1/day)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412665-tbl-0003:row1:col2'])</li><li>dropped duplicate Q22 ('CLinf (ml/day)', value '207') — already have one for this compound</li><li>dropped duplicate Q30 ('CLBSA = QBSA', value '1.37') — already have one for this compound</li><li>dropped duplicate Q63 ('VC,BSA = V P,BSA', value '0.8') — already have one for this compound</li><li>dropped duplicate Q22 ('CLT,WBC', value '0.223') — already have one for this compound</li><li>dropped 'k a,BMI' → Q49 = -1.01: a rate of -1.01 is not a parameter value (source ['psp412665-tbl-0003:row13:col2'])</li><li>dropped duplicate Q22 ('CLT,BSIZ', value '0.261') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Rituximab</li><li>structure disagreement: deterministic 3C vs LLM 2C — review compartment count</li><li>molar mass: none found for 'rituximab' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q61 — no SI value to build from; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Rituximab_Gibiansky2021_reference;
