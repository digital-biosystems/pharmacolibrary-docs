function p = Rituximab_Zhenyan2026_h_l_ne_blasco_et_al_52_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Zhenyan_2026 / h_l_ne_blasco_et_al_52   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Rituximab_Zhenyan2026_h_l_ne_blasco_et_al_52_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.52;                % central volume [L]
  p.CL = 0.00487;                % clearance [L/h]
  p.Vp = [12.0];             % peripheral volumes [L]
  p.Q  = [0.0248];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
