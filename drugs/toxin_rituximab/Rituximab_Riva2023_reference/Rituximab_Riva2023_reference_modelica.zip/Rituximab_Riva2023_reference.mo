// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Rituximab_Riva2023_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {998131.9400063213},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>paediatric patients with neurological and autoimmune diseases</td></tr><tr><td>source_paper:</td><td>Riva_2023</td></tr><tr><td>measured_compound:</td><td>CD19+ B lymphocytes</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-02534-t002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'CD19+0 (106 cells/L)' → Q336 (R0, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pharmaceutics-15-02534-t002:row2:col1'])</li><li>dropped PD-category row 'Kdeg (days−1)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pharmaceutics-15-02534-t002:row3:col1'])</li><li>dropped PD-category row 'EMAX' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pharmaceutics-15-02534-t002:row4:col1'])</li><li>dropped PD-category row 'ED50 (mg)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pharmaceutics-15-02534-t002:row5:col1'])</li><li>dropped value-less row: 'REGION'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=CD19+ B lymphocytes</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'rituximab' — its concentrations stay mass-only</li><li>molar mass: none found for 'CD19+ B lymphocytes' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'CD19+ B lymphocytes', not rituximab — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 10886.4));
end Rituximab_Riva2023_reference;
