function p = Rituximab_Zhenyan2026_chee_m_ng_et_al_58_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Zhenyan_2026 / chee_m_ng_et_al_58   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Rituximab_Zhenyan2026_chee_m_ng_et_al_58_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.6422;                % central volume [L]
  p.CL = 0.00298;                % clearance [L/h]
  p.Vp = [27.32];             % peripheral volumes [L]
  p.Q  = [0.0075];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
