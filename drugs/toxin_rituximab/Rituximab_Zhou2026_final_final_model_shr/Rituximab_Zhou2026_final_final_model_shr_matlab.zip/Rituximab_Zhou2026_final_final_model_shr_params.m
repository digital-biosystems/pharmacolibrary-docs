function p = Rituximab_Zhou2026_final_final_model_shr_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Zhou_2026 / final_final_model_shr   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Rituximab_Zhou2026_final_final_model_shr_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.12;                % central volume [L]
  p.CL = 0.028;                % clearance [L/h]
  p.Vp = [29.2];             % peripheral volumes [L]
  p.Q  = [0.0213];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
