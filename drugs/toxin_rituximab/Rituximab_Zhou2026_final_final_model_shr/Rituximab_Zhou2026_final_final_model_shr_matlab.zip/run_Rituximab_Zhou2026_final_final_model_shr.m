% Run: build params, simulate 0..1008.0 h, plot + save Rituximab_Zhou2026_final_final_model_shr.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Rituximab_Zhou2026_final_final_model_shr.m
here = fileparts(mfilename('fullpath'));
p = Rituximab_Zhou2026_final_final_model_shr_params();
out = simulate_pk(p, 0:0.05:1008.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('rituximab — Zhou_2026 (iv_bolus)');
print(fig, fullfile(here, 'Rituximab_Zhou2026_final_final_model_shr.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Rituximab_Zhou2026_final_final_model_shr.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Rituximab_Zhou2026_final_final_model_shr.json'), 'w');
try
  s.model = 'Rituximab_Zhou2026_final_final_model_shr'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Rituximab_Zhou2026_final_final_model_shr","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Rituximab_Zhou2026_final_final_model_shr.png, Rituximab_Zhou2026_final_final_model_shr.csv, Rituximab_Zhou2026_final_final_model_shr.json\n');
