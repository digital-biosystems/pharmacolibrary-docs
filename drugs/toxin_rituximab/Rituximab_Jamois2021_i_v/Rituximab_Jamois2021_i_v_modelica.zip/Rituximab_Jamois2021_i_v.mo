model Rituximab_Jamois2021_i_v
  parameter Real Cl_ref = 1.25e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00248 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>patients with FL, CLL or DLBCL</td></tr><tr><td>source_paper:</td><td>Jamois_2021</td></tr><tr><td>measured_compound:</td><td>rituximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt2308-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q37 ('Postdose Ctrough a (µg/mL)', value '84') — already have one for this compound</li><li>dropped duplicate Q37 ('Postdose Ctrough b (µg/mL)', value '80.7') — already have one for this compound</li><li>dropped value-less row: 'FSC'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=rituximab</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'i.v.' subgroup of Jamois_2021 (paper reports 3 populations: estimate, i.v., s.c.)</li><li>molar mass: none found for 'rituximab' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Bender_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Liang_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bender_2024, Liang_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Rituximab_Jamois2021_i_v;
