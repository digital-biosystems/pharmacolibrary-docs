function p = Rituximab_Zhenyan2026_mira_tout_et_al_56_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rituximab   source: Zhenyan_2026 / mira_tout_et_al_56   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Rituximab_Zhenyan2026_mira_tout_et_al_56_params';
  p.drug  = 'rituximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.32;                % central volume [L]
  p.CL = 0.00396;                % clearance [L/h]
  p.Vp = [86.25];             % peripheral volumes [L]
  p.Q  = [0.0075];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
