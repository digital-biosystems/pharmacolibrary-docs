% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Rituximab_Zhenyan2026_mira_tout_et_al_56_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
