model Levetiracetam_Schoemaker2018_reference
  parameter Real Cl_ref = 7e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0931 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0008277777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>adults and children with focal seizures</td></tr><tr><td>source_paper:</td><td>Schoemaker_2018</td></tr><tr><td>measured_compound:</td><td>levetiracetam</td></tr><tr><td>parameterization:</td><td>apparent_wrt_Fm</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>40262_2017_597_MOESM1_ESM.docx</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>control_stream: no THETA→param binding found in $PK — route_to_review</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(1) has no $PK binding — index may be misassigned</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Schoemaker2018_reference;
