function p = Levetiracetam_Li2023_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Li_2023 / base   route: oral
  p.name  = 'Levetiracetam_Li2023_base_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 40.9;                % central volume [L]
  p.CL = 4.26;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.98;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
