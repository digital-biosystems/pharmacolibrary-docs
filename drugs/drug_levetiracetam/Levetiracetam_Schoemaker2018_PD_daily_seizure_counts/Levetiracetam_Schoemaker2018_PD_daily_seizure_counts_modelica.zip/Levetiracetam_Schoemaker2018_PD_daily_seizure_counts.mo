model Levetiracetam_Schoemaker2018_PD_daily_seizure_counts
  "emax exposure-response sweep — Schoemaker_2018 :: daily seizure counts (daily seizure counts)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.90046296296e-06,      // [1/s; day−1 × 1.15741e-05]
    Emax = -260.2,  // [% increase]
    EC50 = 2.75,  // [seizures]
    gamma = 1,
    exposure_per_s = 1);   // 1 seizures per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'seizures' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 28, Interval = 0.056),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levetiracetam</h4><p>Levetiracetam is an antiepileptic medicine used to treat epilepsy and various types of seizures, including focal, temporal lobe, frontal lobe, and tonic–clonic seizures. It is an approved drug widely used, with several products authorised in the European Union for epilepsy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417227\">Wikidata Q417227</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Levetiracetam_Schoemaker2018_PD_daily_seizure_counts</h4><p>The steady-state exposure-response curve of Schoemaker R et al., <i>Clinical pharmacokinetics 57(7):843–854</i> 2018 (<a href=\"https://doi.org/10.1007/s40262-017-0597-2\">doi:10.1007/s40262-017-0597-2</a>) — daily seizure counts against levetiracetam seizures — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.337 day−1    drug-free response (baseline) (S 0 adults, Q324)
  Emax  =      260.2 % increase maximal effect term (Smax, Q323)
  EC50  =       2.75 seizures exposure at half of the maximal effect term (ES50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one seizures of levetiracetam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.9e-06   (drug-free)
  exposure = EC50 (2.75 seizures)  response -130.1
  exposure -> infinity  response -260.2</pre></body></html>"));
end Levetiracetam_Schoemaker2018_PD_daily_seizure_counts;
