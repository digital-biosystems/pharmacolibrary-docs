function p = Levetiracetam_Schoemaker2018_PD_daily_seizure_counts_params()
% Levetiracetam_Schoemaker2018_PD_daily_seizure_counts_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levetiracetam Schoemaker_2018::daily_seizure_counts: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one seizures per second, in SI inside (kg/m3, s). Response daily seizure counts in its own unit. Driver: levetiracetam (pk_record).
p.E0 = 3.900462962962963e-06;
p.Emax = -260.2;
p.EC50 = 2.75;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 28.0;
p.form = 'E0 + Emax*frac';
end
