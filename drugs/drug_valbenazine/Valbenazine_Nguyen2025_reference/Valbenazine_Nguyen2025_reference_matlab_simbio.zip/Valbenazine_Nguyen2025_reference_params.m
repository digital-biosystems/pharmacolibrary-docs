function p = Valbenazine_Nguyen2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valbenazine   source: Nguyen_2025 / reference   route: oral
  p.name  = 'Valbenazine_Nguyen2025_reference_params';
  p.drug  = 'valbenazine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 226.0;                % central volume [L]
  p.CL = 31.0;                % clearance [L/h]
  p.Vp = [97.8];             % peripheral volumes [L]
  p.Q  = [1.27];             % inter-compartmental clearances [L/h]
  p.ka = 8.43;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
