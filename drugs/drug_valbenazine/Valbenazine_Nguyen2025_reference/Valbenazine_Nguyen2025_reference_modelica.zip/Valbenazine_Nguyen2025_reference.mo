model Valbenazine_Nguyen2025_reference
  parameter Real Cl_ref = 6.444444444444444e-06 "Cl [m3/s]";
  parameter Real cov_fed_0 = 0 "fed covariate";
  parameter Real cov_poor_metabolizer_1 = 0 "poor metabolizer covariate";
  parameter Real cov_wt_2 = 0 "wt covariate";
  parameter Real cov_wt_3 = 0 "wt covariate";
  parameter Real Vd_ref = 0.226 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.0646)*cov_fed_0)*(1 + (-0.516)*cov_poor_metabolizer_1)*(1 + (0.602)*cov_wt_2)*(1 + (1.04)*cov_wt_3),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41857799999999995,
    adminMass = 4e-05,
    ka = 0.0023416666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About valbenazine</h4><p>Valbenazine is a vesicular monoamine transporter inhibitor used to treat tardive dyskinesia. It is given by mouth in capsule form. The drug is approved for medical use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q27089118\">Wikidata Q27089118</a>, <a href=\"https://en.wikipedia.org/wiki/Valbenazine?oldid=1357688439\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>valbenazine</td></tr><tr><td>population:</td><td>patients with Huntington's disease</td></tr><tr><td>source_paper:</td><td>Nguyen_2025</td></tr><tr><td>measured_compound:</td><td>valbenazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70092-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>[+]‐α‐dihydrotetrabenazine 319.445 g/mol (pubchem); valbenazine 418.578 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>PK_3M template not built: [+]‐α‐dihydrotetrabenazine has no central volume</li><li>PK_3M template not built: [+]‐α‐dihydrotetrabenazine has no central volume</li><li>table section residual_error: '11 Log additive (parent, rich)' routed out of structural estimates ('Residual variability (%)')</li><li>table section residual_error: '12 Log additive (parent, sparse)' routed out of structural estimates ('Residual variability (%)')</li><li>table section residual_error: '19 Log additive (metabolite, rich)' routed out of structural estimates ('Residual variability (%)')</li><li>table section residual_error: '20 Log additive (metabolite, sparse)' routed out of structural estimates ('Residual variability (%)')</li><li>unit_dimension_unknown: 'relative to 1 mg' (Frel)</li><li>dropped PD-category row '7 ED50 (mg)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['jcph70092-tbl-0001:row7:col1'])</li><li>dropped unlinked row (NIL): '8 Solution on KA' — extend the ontology if this is a real PK parameter (source ['jcph70092-tbl-0001:row8:col1'])</li><li>covariate level '10 Fed status on F1' → Q900:10_fed_status_on_f1 = -0.0646 (linear_fractional on Q27)</li><li>covariate level '17 Poor metabolizer a on CLM' → Q900:17_poor_metabolizer_a_on_clm = -0.516 (linear_fractional on Q27)</li><li>covariate level '21 WT on CLP' → Q900:21_wt_on_clp = 0.602 (linear_fractional on Q27)</li><li>covariate level '22 WT on VCP' → Q900:22_wt_on_vcp = 1.04 (linear_fractional on Q27)</li><li>covariate effect for Q351 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=valbenazine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end Valbenazine_Nguyen2025_reference;
