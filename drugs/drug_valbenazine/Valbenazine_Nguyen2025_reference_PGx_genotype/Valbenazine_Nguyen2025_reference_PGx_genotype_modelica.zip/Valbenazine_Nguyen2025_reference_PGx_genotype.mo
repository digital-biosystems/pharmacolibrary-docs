model Valbenazine_Nguyen2025_reference_PGx_genotype
  "Valbenazine_Nguyen2025_reference with the genotype phenotype as a parameter (Nguyen_2025)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "genotype phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {8.61111111111e-06, 5.14000143692e-06, 8.61111111111e-06, 8.61111111111e-06, 8.61111111111e-06, 8.61111111111e-06};
  extends Valbenazine_Nguyen2025_reference(Cl = Cl_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About valbenazine</h4><p>Valbenazine is a nervous system drug used to treat tardive dyskinesia. It is an approved medicine, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27089118\">Wikidata Q27089118</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Valbenazine_Nguyen2025_reference_PGx_genotype;
