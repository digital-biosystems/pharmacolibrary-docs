function p = Flecainide_McQuinn1988_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flecainide   source: McQuinn_1988 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Flecainide_McQuinn1988_reference_params';
  p.drug  = 'flecainide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 525.0;                % central volume [L]
  p.CL = 38.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
