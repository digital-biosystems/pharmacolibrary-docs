model Flecainide_McQuinn1988_reference
  parameter Real Cl_ref = 1.0616666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.525 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.414346,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flecainide</td></tr><tr><td>population:</td><td>patients with cirrhosis of the liver and healthy subjects</td></tr><tr><td>source_paper:</td><td>McQuinn_1988</td></tr><tr><td>measured_compound:</td><td>Flecainide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flecainide 414.346 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['McQuinn_1988:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['McQuinn_1988:abstract'])</li><li>dropped value-less row: 'Renal clearance'</li><li>covariate renal for CL_ratio from footnote/prose kept as documentation only (['McQuinn_1988:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flecainide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Flecainide_McQuinn1988_reference;
