model Carmustine_Russo1981_reference
  parameter Real Cl_ref = 1.948333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1813 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carmustine</td></tr><tr><td>population:</td><td>patients with lung cancer</td></tr><tr><td>source_paper:</td><td>Russo_1981</td></tr><tr><td>measured_compound:</td><td>BCNU</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life of the drug', value 1.4) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=BCNU</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carmustine_Russo1981_reference;
