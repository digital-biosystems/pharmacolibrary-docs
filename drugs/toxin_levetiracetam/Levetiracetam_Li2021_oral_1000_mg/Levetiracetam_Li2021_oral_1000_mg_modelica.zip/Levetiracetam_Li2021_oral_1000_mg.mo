model Levetiracetam_Li2021_oral_1000_mg
  parameter Real Cl_ref = 1.1199999999999999e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0378 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 1e-05,
    ka = 0.0003805555555555556,
    Tlag = 7056.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>Chinese children and adults (simulated); dogs (in vivo)</td></tr><tr><td>source_paper:</td><td>Li_2021</td></tr><tr><td>measured_compound:</td><td>Levetiracetam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00020-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('clearance rate for the adult model'=0.96) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('half-life of LEV in vivo'=3.2) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('steady-state volume of distribution (Vss)'=0.54) from results prose — parameter table was unreadable</li><li>implicit units: 'Cmax' → μg/mL (from the paper text: &quot;Table 5 caption explicitly states: '(Cmax: μg/mL; ...)&quot;)</li><li>implicit units: 'AUC0-t' → μg × h/mL (from the paper text: &quot;Table 5 caption explicitly states: '(... AUC0-t: μg × h/mL; ...)&quot;)</li><li>implicit units: 'AUC0-inf' → μg × h/mL (from the paper text: &quot;Table 5 caption explicitly states: '(... AUC0-inf: μg × h/mL; ...)&quot;)</li><li>implicit units: 'Tmax' → h (from the paper text: &quot;Table 5 caption explicitly states: '(... Tmax: h).&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levetiracetam</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'oral 1000 mg' subgroup of Li_2021 (paper reports 12 populations: iv 1500 mg, lev-idts-1000 mg, lev-idts-250 mg, lev-idts-500 mg, lev-idts-750 mg, oral 1000 mg, oral 1500 mg, oral 250 mg, oral 500 mg, oral 750 mg, spritam®, values)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Birbeck_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Birbeck_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Li2021_oral_1000_mg;
