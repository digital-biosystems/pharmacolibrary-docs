model Levetiracetam_Schoemaker2018_PD_seizure_count
  "emax exposure-response sweep — Schoemaker_2018 :: Seizure count (Seizure count)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.90046296296e-06,      // [1/s; day-1 × 1.15741e-05]
    Emax = -95.6,  // [% change]
    EC50 = 0.0314,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 320, Interval = 0.64),
    Documentation(info = "<html><body><h4>Levetiracetam_Schoemaker2018_PD_seizure_count</h4><p>The steady-state exposure-response curve of Schoemaker R et al., <i>Clinical pharmacokinetics 57(7):843–854</i> 2018 (<a href=\"https://doi.org/10.1007/s40262-017-0597-2\">doi:10.1007/s40262-017-0597-2</a>) — Seizure count [count/day] against levetiracetam mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.337 day-1    drug-free response (baseline) (S0 adults, Q324)
  Emax  =      -95.6 % change maximal effect term (Emax, Q323)
  EC50  =       31.4 mg/L     exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of levetiracetam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.9e-06   (drug-free)
  exposure = EC50 (31.4 mg/L)  response -47.8
  exposure -> infinity  response -95.6</pre></body></html>"));
end Levetiracetam_Schoemaker2018_PD_seizure_count;
