model Levetiracetam_Chykharivska2025_reference
  parameter Real Cl_ref = 3.4e-08 "Cl [m3/s]";
  parameter Real cov_crcl_0 = 0 "CRCL covariate";
  parameter Real Vd_ref = 0.0294 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.42)*cov_crcl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 0.00025,
    ka = 0.0006416666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>adults with a seizure history receiving LEV during hospital admission</td></tr><tr><td>source_paper:</td><td>Chykharivska_2025</td></tr><tr><td>measured_compound:</td><td>Levetiracetam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>fcp13059-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Cc' routed out of structural estimates ('Residual error')</li><li>'β_ V_BSA' is a β covariate effect on _ V_, not Q900 (llm link set aside)</li><li>covariate level 'β_ V_BSA' → Q900:v_bsa = 0.46 (linear_fractional on the model)</li><li>'β_CL_CRCL' is a β covariate effect on _CL_, not Q26 (llm link set aside)</li><li>covariate level 'β_CL_CRCL' → Q900:cl_crcl = 0.42 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Levetiracetam</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Chykharivska2025_reference;
