function p = Levetiracetam_Kharouba2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Kharouba_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Levetiracetam_Kharouba2025_reference_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 67.987004;                % central volume [L]
  p.CL = 6.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
