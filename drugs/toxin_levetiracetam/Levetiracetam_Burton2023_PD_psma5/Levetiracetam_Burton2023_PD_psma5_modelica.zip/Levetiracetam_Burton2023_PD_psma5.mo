model Levetiracetam_Burton2023_PD_psma5
  "linear exposure-response sweep — Burton_2023 :: Psma5 (Psma5 expression)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -0.0036,  // [1]
    exposure_per_s = 1);   // 1 AUC per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Levetiracetam_Burton2023_PD_psma5</h4><p>The steady-state exposure-response curve of Burton CP et al., <i>Frontiers in neuroscience 17:1336026</i> 2023 (<a href=\"https://doi.org/10.3389/fnins.2023.1336026\">doi:10.3389/fnins.2023.1336026</a>) — Psma5 expression [Log2 intensity] against Levetiracetam AUC — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    -0.0036          change in response per unit of exposure (AUC beta, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one AUC of Levetiracetam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Levetiracetam_Burton2023_PD_psma5;
