% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Levetiracetam_Johnson2025_sharpe_et_al_20247_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
