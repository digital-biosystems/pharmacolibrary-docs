model Levetiracetam_Mimram2026_reference
  parameter Real Cl_ref = 1.186111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0465 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 0.0015,
    ka = 0.0003805555555555556,
    Tlag = 7056.0,
    k12 = 1.045400238948626e-05,
    k21 = 7.96903460837887e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>term neonates with hypoxic-ischemic encephalopathy</td></tr><tr><td>source_paper:</td><td>Mimram_2026</td></tr><tr><td>measured_compound:</td><td>Levetiracetam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CLcr'</li><li>dropped value-less row: 'natremia'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levetiracetam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Birbeck_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Birbeck_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Mimram2026_reference;
