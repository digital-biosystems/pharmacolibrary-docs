function p = Levetiracetam_Mimram2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Mimram_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Levetiracetam_Mimram2026_reference_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.5;                % central volume [L]
  p.CL = 4.27;                % clearance [L/h]
  p.Vp = [6.1];             % peripheral volumes [L]
  p.Q  = [1.75];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
