function p = Levetiracetam_Kharouba2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Kharouba_2025_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Levetiracetam_Kharouba2025v2_reference_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 39.2;                % central volume [L]
  p.CL = 4.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
