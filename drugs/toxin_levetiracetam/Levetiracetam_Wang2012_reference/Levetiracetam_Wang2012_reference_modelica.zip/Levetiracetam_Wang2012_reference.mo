model Levetiracetam_Wang2012_reference
  parameter Real Cl_ref = 2.744444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 0.0015,
    ka = 0.0003805555555555556,
    Tlag = 7056.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>Chinese children with epilepsy</td></tr><tr><td>source_paper:</td><td>Wang_2012</td></tr><tr><td>measured_compound:</td><td>Levetiracetam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'MPE' — extend the ontology if this is a real PK parameter (source ['Wang_2012:abstract'])</li><li>dropped unlinked row (NIL): 'MSPE' — extend the ontology if this is a real PK parameter (source ['Wang_2012:abstract'])</li><li>dropped unlinked row (NIL): 'RMSPE' — extend the ontology if this is a real PK parameter (source ['Wang_2012:abstract'])</li><li>dropped unlinked row (NIL): 'WRES' — extend the ontology if this is a real PK parameter (source ['Wang_2012:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Levetiracetam</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Birbeck_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Birbeck_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Wang2012_reference;
