function p = Levetiracetam_Wang2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Wang_2012 / reference   route: oral
  p.name  = 'Levetiracetam_Wang2012_reference_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.3;                % central volume [L]
  p.CL = 0.988;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
