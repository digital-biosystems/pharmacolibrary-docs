function p = Levetiracetam_Burton2023_PD_stat3_params()
% Levetiracetam_Burton2023_PD_stat3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levetiracetam Burton_2023::Stat3: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC per second, in SI inside (kg/m3, s). Response Stat3 in Log2 intensity. Driver: Levetiracetam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.001;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
