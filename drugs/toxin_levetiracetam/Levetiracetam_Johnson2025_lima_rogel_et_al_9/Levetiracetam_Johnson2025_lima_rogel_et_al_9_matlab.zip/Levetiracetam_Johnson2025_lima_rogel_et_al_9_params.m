function p = Levetiracetam_Johnson2025_lima_rogel_et_al_9_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Johnson_2025 / lima_rogel_et_al_9   route: oral
  % estimated (absent from source): F
  p.name  = 'Levetiracetam_Johnson2025_lima_rogel_et_al_9_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 94.5;                % central volume [L]
  p.CL = 2.856;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 4200.0;             % dose [mg]
end
