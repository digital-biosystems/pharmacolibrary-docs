function p = Levetiracetam_Li2021_oral_500_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Li_2021 / oral_500_mg   route: oral
  % estimated (absent from source): F
  p.name  = 'Levetiracetam_Li2021_oral_500_mg_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 37.8;                % central volume [L]
  p.CL = 4.032;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
