% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Levetiracetam_Johnson2025_sharpe_et_al_2012b_6_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
