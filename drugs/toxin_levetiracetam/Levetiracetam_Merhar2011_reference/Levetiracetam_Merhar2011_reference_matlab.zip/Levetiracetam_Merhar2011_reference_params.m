function p = Levetiracetam_Merhar2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Merhar_2011 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Levetiracetam_Merhar2011_reference_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.96;                % central volume [L]
  p.CL = 0.097;                % clearance [L/h]
  p.Vp = [0.89];             % peripheral volumes [L]
  p.Q  = [1.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 1008.0;             % dose [mg]
end
