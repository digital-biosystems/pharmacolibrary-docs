model Levetiracetam_Merhar2011_reference
  parameter Real Cl_ref = 2.6944444444444443e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00196 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 0.001008,
    ka = 0.0003805555555555556,
    Tlag = 7056.0,
    k12 = 0.00015589569160997735,
    k21 = 0.00034332084893882645
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>neonates with seizures</td></tr><tr><td>source_paper:</td><td>Merhar_2011</td></tr><tr><td>measured_compound:</td><td>Levetiracetam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability CV%')</li><li>table section iiv: 'V1' routed out of structural estimates ('Inter-individual variability CV%')</li><li>table section iiv: 'Q (fixed)' routed out of structural estimates ('Inter-individual variability CV%')</li><li>table section iiv: 'V2' routed out of structural estimates ('Inter-individual variability CV%')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error (SD)' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q22 ('CL θ5 creatinine CL', value '0.04') — already have one for this compound</li><li>dropped duplicate Q63 ('V1 θ6 weight', value '3.83') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levetiracetam</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>gap-filled Q49 (kabs) from Birbeck_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Birbeck_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Merhar2011_reference;
