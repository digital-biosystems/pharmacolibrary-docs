model TrastuzumabDeruxtecan_Yin2021_final
  parameter Real Cl_ref = 4.872685185185185e-09 "Cl [m3/s]";
  parameter Real cov_albumin_0 = 0 "albumin covariate";
  parameter Real cov_country_1 = 0 "country covariate";
  parameter Real cov_sex_2 = 0 "sex covariate";
  parameter Real cov_body_weight_3 = 0 "body weight covariate";
  parameter Real cov_sex_4 = 0 "sex covariate";
  parameter Real cov_country_5 = 0 "country covariate";
  parameter Real Vd_ref = 0.00277 "Vd [m3]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.533)*cov_albumin_0)*(1 + (-0.097)*cov_country_1)*(1 + (0.174)*cov_sex_2)*(1 + (0.37)*cov_body_weight_3)*(1 + (0.197)*cov_sex_4)*(1 + (-0.262)*cov_country_5),
    Vd = Vd_ref*(1 + (0.489)*cov_body_weight_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5.6e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trastuzumab_deruxtecan</h4><p>Trastuzumab deruxtecan is an antibody-drug conjugate used to treat breast cancer. It is an approved medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q80109553\">Wikidata Q80109553</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trastuzumab_deruxtecan</td></tr><tr><td>population:</td><td>patients with HER2-positive breast cancer and other solid tumors</td></tr><tr><td>source_paper:</td><td>Yin_2021</td></tr><tr><td>measured_compound:</td><td>trastuzumab_deruxtecan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt2096-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>released drug 493.491 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional residual error SD' routed out of structural estimates ('Residual variability e')</li><li>table section residual_error: 'Proportional residual error SD' routed out of structural estimates ('Residual variability e')</li><li>table section residual_error: 'Additive residual error SD (ng/mL)' routed out of structural estimates ('Residual variability e')</li><li>table section residual_error: 'Additive residual error SD (ng/mL)' routed out of structural estimates ('Residual variability e')</li><li>covariate level 'Albumin on CLintact' → Q900:albumin_on_clintact = -0.533 (linear_fractional on Q22)</li><li>covariate level 'Country (Japan) on CLintact d' → Q900:country_japan_on_clintact_d = -0.0970 (linear_fractional on Q22)</li><li>covariate level 'Sex (male) on CLintact' → Q900:sex_male_on_clintact = 0.174 (linear_fractional on Q22)</li><li>dropped unlinked row (NIL): 'Tumor size on CLintact' — extend the ontology if this is a real PK parameter (source ['cpt2096-tbl-0001:row10:col1', 'cpt2096-tbl-0001:row10:col2'])</li><li>covariate level 'Body weight on CLintact' → Q900:body_weight_on_clintact = 0.370 (linear_fractional on Q22)</li><li>covariate level 'Sex (male) on V1,intact' → Q900:sex_male_on_v1_intact = 0.197 (linear_fractional on Q22)</li><li>covariate level 'Country (Japan) on V2,intact d' → Q900:country_japan_on_v2_intact_d = -0.262 (linear_fractional on Q22)</li><li>routed 'Variance of CLintact' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q63 ('Variance of V1,intact', value '0.0250') — already have one for this compound</li><li>routed 'Variance of Qintact' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q64 ('Variance of V2,intact', value '0.430') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trastuzumab_deruxtecan</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end TrastuzumabDeruxtecan_Yin2021_final;
