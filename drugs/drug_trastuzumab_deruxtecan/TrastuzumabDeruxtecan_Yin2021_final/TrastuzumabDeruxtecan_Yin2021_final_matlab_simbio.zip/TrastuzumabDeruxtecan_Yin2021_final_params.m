function p = TrastuzumabDeruxtecan_Yin2021_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trastuzumab_deruxtecan   source: Yin_2021 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'TrastuzumabDeruxtecan_Yin2021_final_params';
  p.drug  = 'trastuzumab_deruxtecan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.77;                % central volume [L]
  p.CL = 0.017542;                % clearance [L/h]
  p.Vp = [5.16];             % peripheral volumes [L]
  p.Q  = [0.008292];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 56.0;             % dose [mg]
end
