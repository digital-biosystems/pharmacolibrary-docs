function p = TrastuzumabDeruxtecan_Yin2021_final_final_released_drug_mode_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trastuzumab_deruxtecan   source: Yin_2021 / final_final_released_drug_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'TrastuzumabDeruxtecan_Yin2021_final_final_released_drug_mode_params';
  p.drug  = 'trastuzumab_deruxtecan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 42.0;                % central volume [L]
  p.CL = 19.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 56.0;             % dose [mg]
end
