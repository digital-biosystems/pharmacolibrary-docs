% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = TrastuzumabDeruxtecan_Yin2021_final_final_released_drug_mode_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
