function p = Oxymorphone_Sadiq2013_PD_tail_flick_latency_params()
% Oxymorphone_Sadiq2013_PD_tail_flick_latency_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxymorphone Sadiq_2013::tail_flick_latency: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response tail-flick latency in s. Driver: unbound oxymorphone (conc_no_pk).
p.E0 = 5.27;
p.Emax = 55.1;
p.EC50 = 6.26e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 630.0;
p.form = 'E0 + Emax*frac';
end
