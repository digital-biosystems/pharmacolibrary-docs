model Oxymorphone_Sadiq2013_PD_tail_flick_latency
  "emax exposure-response sweep — Sadiq_2013 :: tail-flick latency (tail-flick latency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 5.27,      // [s; s × 1]
    Emax = 55.1,  // [s; s × 1]
    EC50 = 6.26e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 630, Interval = 1.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxymorphone</h4><p>Oxymorphone is an opioid painkiller used to treat moderate to severe pain. It is an approved medicine, also approved for veterinary use, and is used mainly in North America rather than the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423380\">Wikidata Q423380</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxymorphone_Sadiq2013_PD_tail_flick_latency</h4><p>The steady-state exposure-response curve of Sadiq MW et al., <i>Journal of pharmaceutical sciences 102(9):3320–3331</i> 2013 (<a href=\"https://doi.org/10.1002/jps.23492\">doi:10.1002/jps.23492</a>) — tail-flick latency [s] against unbound oxymorphone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       5.27 s        drug-free response (baseline) (Baseline effect, Q324)
  Emax  =       55.1 s        maximal effect term (E max, Q320)
  EC50  =       62.6 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of unbound oxymorphone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5.27   (drug-free)
  exposure = EC50 (62.6 ng/mL)  response 32.82
  exposure -> infinity  response 60.37</pre></body></html>"));
end Oxymorphone_Sadiq2013_PD_tail_flick_latency;
