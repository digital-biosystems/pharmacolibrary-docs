function p = Oxymorphone_Sadiq2013_original_data_set_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxymorphone   source: Sadiq_2013 / original_data_set   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Oxymorphone_Sadiq2013_original_data_set_params';
  p.drug  = 'oxymorphone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.17;                % central volume [L]
  p.CL = 3.27;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
