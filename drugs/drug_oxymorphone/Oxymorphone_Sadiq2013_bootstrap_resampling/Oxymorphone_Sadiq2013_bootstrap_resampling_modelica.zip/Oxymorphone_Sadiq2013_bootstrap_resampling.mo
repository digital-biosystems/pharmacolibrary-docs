model Oxymorphone_Sadiq2013_bootstrap_resampling
  parameter Real Cl_ref = 7.966666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 1.4099999999999999e-05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxymorphone</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Sadiq_2013</td></tr><tr><td>measured_compound:</td><td>oxymorphone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'bootstrap resampling' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap resampling' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap resampling' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap resampling' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap resampling' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q30 ('Q av (mL/min)', value '39.4') — already have one for this compound</li><li>dropped unlinked row (NIL): 'REC blood (%)' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col2', 'tab_1:row7:col3', 'tab_1:row7:col4'])</li><li>dropped unlinked row (NIL): 'REC brain (%)' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col2', 'tab_1:row8:col3', 'tab_1:row8:col4'])</li><li>dropped duplicate Q22 ('CL in (mL/min)', value '10.5') — already have one for this compound</li><li>dropped unlinked row (NIL): 'K p,uu' — extend the ontology if this is a real PK parameter (source ['tab_1:row10:col2', 'tab_1:row10:col4'])</li><li>dropped PD-category row 'Baseline effect (s)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row11:col2', 'tab_1:row11:col4'])</li><li>dropped PD-category row 'E max (s)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row12:col4'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxymorphone_Sadiq2013_bootstrap_resampling;
