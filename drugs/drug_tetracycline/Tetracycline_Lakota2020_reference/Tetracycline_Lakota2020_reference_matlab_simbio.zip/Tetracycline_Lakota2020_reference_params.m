function p = Tetracycline_Lakota2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetracycline   source: Lakota_2020 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Tetracycline_Lakota2020_reference_params';
  p.drug  = 'tetracycline';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.1;                % central volume [L]
  p.CL = 10.3;                % clearance [L/h]
  p.Vp = [79.9];             % peripheral volumes [L]
  p.Q  = [21.3];             % inter-compartmental clearances [L/h]
  p.ka = 1.74;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
