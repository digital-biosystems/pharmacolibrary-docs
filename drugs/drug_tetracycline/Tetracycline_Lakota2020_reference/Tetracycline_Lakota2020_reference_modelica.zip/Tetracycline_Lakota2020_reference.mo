model Tetracycline_Lakota2020_reference
  parameter Real Cl_ref = 2.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00048333333333333334,
    Tlag = 0.0,
    k12 = 0.0002804107424960505,
    k21 = 7.405089695452648e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetracycline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Lakota_2020</td></tr><tr><td>measured_compound:</td><td>tetracycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Lakota_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tetracycline_Lakota2020_reference;
