function p = Tetracycline_Anadn1985_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetracycline   source: Anadón_1985 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Tetracycline_Anadn1985_reference_params';
  p.drug  = 'tetracycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 59.5;                % central volume [L]
  p.CL = 18.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.45;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
