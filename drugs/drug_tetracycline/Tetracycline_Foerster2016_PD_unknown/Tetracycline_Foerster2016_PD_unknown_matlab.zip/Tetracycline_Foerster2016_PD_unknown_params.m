function p = Tetracycline_Foerster2016_PD_unknown_params()
% Tetracycline_Foerster2016_PD_unknown_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tetracycline Foerster_2016::resp: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response ψ in h−1. Driver: tetracycline (cited_pk).
p.E0 = 0.0;
p.Emax = -0.00022222222222222223;
p.EC50 = 0.0004999999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.0;
p.form = 'E0 + Emax*frac';
end
