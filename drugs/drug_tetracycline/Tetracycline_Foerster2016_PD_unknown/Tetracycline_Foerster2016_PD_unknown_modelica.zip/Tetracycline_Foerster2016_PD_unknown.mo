model Tetracycline_Foerster2016_PD_unknown
  "sigmoid_emax exposure-response sweep — Foerster_2016 :: ψ (bacterial growth rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000222222222222,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.0005,  // [kg/m3; μg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 5, Interval = 0.01),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tetracycline</h4><p>Tetracycline is an antibiotic used against bacterial infections such as acne, gonorrhea, chlamydia, rickettsial infections and bronchitis. It remains an approved medicine, including veterinary use, and is listed among WHO essential medicines, though some products have been withdrawn in places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q193045\">Wikidata Q193045</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tetracycline_Foerster2016_PD_unknown</h4><p>The steady-state exposure-response curve of Foerster S et al., <i>BMC microbiology 16:216</i> 2016 (<a href=\"https://doi.org/10.1186/s12866-016-0838-9\">doi:10.1186/s12866-016-0838-9</a>) — bacterial growth rate [h−1] against tetracycline μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        0.8 h−1      maximal effect term (maximal bacterial growth rate, Q323)
  EC50  =        0.5 μg/ml    exposure at half of the maximal effect term (pharmacodynamic MIC, Q322)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/ml of tetracycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.5 μg/ml)  response -0.0001111
  exposure -> infinity  response -0.0002222</pre></body></html>"));
end Tetracycline_Foerster2016_PD_unknown;
