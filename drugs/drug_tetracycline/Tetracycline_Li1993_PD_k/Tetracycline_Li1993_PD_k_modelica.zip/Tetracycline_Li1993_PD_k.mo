model Tetracycline_Li1993_PD_k
  "sigmoid_emax exposure-response sweep — Li_1993 :: K' (initial bactericidal rate constant)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.000944444444444,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.00096,  // [kg/m3; μg/ml × 0.001]
    gamma = 1.02,
    exposure_per_s = 0.001);   // 1 μg/ml per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 9.6, Interval = 0.0192),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tetracycline</h4><p>Tetracycline is an antibiotic used against bacterial infections such as acne, gonorrhea, chlamydia, rickettsial infections and bronchitis. It remains an approved medicine, including veterinary use, and is listed among WHO essential medicines, though some products have been withdrawn in places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q193045\">Wikidata Q193045</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tetracycline_Li1993_PD_k</h4><p>The steady-state exposure-response curve of Li RC et al., <i>Antimicrobial agents and chemotherapy</i> 1993 (<a href=\"https://doi.org/10.1128/AAC.37.3.523\">doi:10.1128/AAC.37.3.523</a>) — initial bactericidal rate constant [h-1] against tetracycline μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        3.4 h-1      maximal effect term (K'max, Q320)
  EC50  =       0.96 μg/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.02          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/ml of tetracycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.96 μg/ml)  response 0.0004722
  exposure -> infinity  response 0.0009444</pre></body></html>"));
end Tetracycline_Li1993_PD_k;
