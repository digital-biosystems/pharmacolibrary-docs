function p = PentaerythritolTetranitrate_King1986_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentaerythritol_tetranitrate   source: King_1986 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'PentaerythritolTetranitrate_King1986_reference_params';
  p.drug  = 'pentaerythritol_tetranitrate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 294.0;                % central volume [L]
  p.CL = 2562.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
