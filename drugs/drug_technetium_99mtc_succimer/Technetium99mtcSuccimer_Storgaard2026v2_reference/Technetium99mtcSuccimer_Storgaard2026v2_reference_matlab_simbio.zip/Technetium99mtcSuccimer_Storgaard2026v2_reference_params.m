function p = Technetium99mtcSuccimer_Storgaard2026v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: technetium_99mtc_succimer   source: Storgaard_2026_2 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Technetium99mtcSuccimer_Storgaard2026v2_reference_params';
  p.drug  = 'technetium_99mtc_succimer';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1669.0;                % central volume [L]
  p.CL = 162.0;                % clearance [L/h]
  p.Vp = [539.0];             % peripheral volumes [L]
  p.Q  = [183.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
