model Technetium99mtcSuccimer_Storgaard2026v2_reference
  parameter Real Cl_ref = 4.5e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.669 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47741500000000003,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.0457359696425006e-05,
    k21 = 9.431045145330858e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About technetium_99mtc_succimer</h4><p>Technetium (99mTc) succimer is a diagnostic radiopharmaceutical used for imaging of the kidneys. It is an approved diagnostic agent, classified under technetium compounds for the renal system.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>technetium_99mtc_succimer</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Storgaard_2026_2</td></tr><tr><td>measured_compound:</td><td>technetium_99mtc_succimer</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>technetium_99mtc_succimer 477.415 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Storgaard_2026_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Technetium99mtcSuccimer_Storgaard2026v2_reference;
