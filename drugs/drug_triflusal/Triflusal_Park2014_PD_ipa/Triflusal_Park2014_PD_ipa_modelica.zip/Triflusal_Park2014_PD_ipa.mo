model Triflusal_Park2014_PD_ipa
  "sigmoid_emax exposure-response sweep — Park_2014 :: IPA (inhibition of platelet aggregation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; 1 × 1]
    EC50 = 0.0849,  // [kg/m3; μg/mL × 0.001]
    gamma = 19.2,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 850, Interval = 1.7),
    Documentation(info = "<html><body><!-- drug-about --><h4>About triflusal</h4><p>Triflusal is an antiplatelet drug that was used to prevent blood clots in conditions such as stroke. It was approved in some countries but has since been withdrawn and is no longer in general use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1758668\">Wikidata Q1758668</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Triflusal_Park2014_PD_ipa</h4><p>The steady-state exposure-response curve of Park SM et al., <i>BMC pharmacology &amp; toxicology 15:75</i> 2014 (<a href=\"https://doi.org/10.1186/2050-6511-15-75\">doi:10.1186/2050-6511-15-75</a>) — inhibition of platelet aggregation against HTB μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1 1        maximal effect term (Emax, Q320)
  EC50  =       84.9 μg/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       19.2          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of HTB per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (84.9 μg/mL)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Triflusal_Park2014_PD_ipa;
