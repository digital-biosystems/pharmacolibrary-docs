function p = Triflusal_Park2014_PD_ipa_params()
% Triflusal_Park2014_PD_ipa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% triflusal Park_2014::IPA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response IPA in its own unit. Driver: HTB (pk_record).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.08489999999999999;
p.gamma = 19.2;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 850.0;
p.form = 'E0 + Emax*frac';
end
