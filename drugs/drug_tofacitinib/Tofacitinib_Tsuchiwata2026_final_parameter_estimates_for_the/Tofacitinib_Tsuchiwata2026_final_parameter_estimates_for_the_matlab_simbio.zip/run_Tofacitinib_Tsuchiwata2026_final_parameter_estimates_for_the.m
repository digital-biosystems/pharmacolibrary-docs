% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Tofacitinib_Tsuchiwata2026_final_parameter_estimates_for_the_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
