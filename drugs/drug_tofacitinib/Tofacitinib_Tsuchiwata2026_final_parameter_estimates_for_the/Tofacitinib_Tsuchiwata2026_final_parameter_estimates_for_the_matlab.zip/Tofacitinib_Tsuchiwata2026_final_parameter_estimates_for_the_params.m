function p = Tofacitinib_Tsuchiwata2026_final_parameter_estimates_for_the_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tofacitinib   source: Tsuchiwata_2026 / final_parameter_estimates_for_the_final_full_model_iiv_rse   route: oral
  % estimated (absent from source): ka
  p.name  = 'Tofacitinib_Tsuchiwata2026_final_parameter_estimates_for_the_params';
  p.drug  = 'tofacitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 124.0;                % central volume [L]
  p.CL = 26.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
