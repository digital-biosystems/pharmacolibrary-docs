model Tofacitinib_Vong2021_reference
  parameter Real Cl_ref = 6.944444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.111 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31236959999999997,
    adminMass = 5e-06,
    ka = 0.002736111111111111,
    Tlag = 849.5999999999999
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tofacitinib</td></tr><tr><td>population:</td><td>adults with moderate to severe ulcerative colitis</td></tr><tr><td>source_paper:</td><td>Vong_2021</td></tr><tr><td>measured_compound:</td><td>tofacitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpdd899-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tofacitinib 312.37 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('The typical estimates of CL/F'=25.0) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('and V/F'=111) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka'=9.85) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('lag time'=0.236) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tofacitinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tofacitinib_Vong2021_reference;
