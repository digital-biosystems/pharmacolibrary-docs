function p = Tofacitinib_Vong2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tofacitinib   source: Vong_2021 / reference   route: oral
  p.name  = 'Tofacitinib_Vong2021_reference_params';
  p.drug  = 'tofacitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 115.8;                % central volume [L]
  p.CL = 26.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 191.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.236;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
