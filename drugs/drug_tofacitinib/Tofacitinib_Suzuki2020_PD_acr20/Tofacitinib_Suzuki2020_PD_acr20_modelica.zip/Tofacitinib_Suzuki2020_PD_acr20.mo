model Tofacitinib_Suzuki2020_PD_acr20
  "emax exposure-response sweep — Suzuki_2020 :: ACR20 (ACR20 response rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -1.3,      // [1]
    Emax = 3.2,  // [1]
    EC50 = 4.2e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 42, Interval = 0.084),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tofacitinib_Suzuki2020_PD_acr20</h4><p>The steady-state exposure-response curve of Suzuki M et al., <i>Journal of clinical pharmacology 60(2):198–208</i> 2020 (<a href=\"https://doi.org/10.1002/jcph.1514\">doi:10.1002/jcph.1514</a>) — ACR20 response rate against tofacitinib mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       -1.3          drug-free response (baseline) (E0, Q324)
  Emax  =        3.2          maximal effect term (Emax, Q320)
  EC50  =        4.2 mg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of tofacitinib per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -1.3   (drug-free)
  exposure = EC50 (4.2 mg)  response 0.3
  exposure -> infinity  response 1.9</pre></body></html>"));
end Tofacitinib_Suzuki2020_PD_acr20;
