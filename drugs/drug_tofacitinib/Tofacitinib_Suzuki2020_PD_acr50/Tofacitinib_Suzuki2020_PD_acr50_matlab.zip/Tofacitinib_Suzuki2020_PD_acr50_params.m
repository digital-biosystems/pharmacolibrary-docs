function p = Tofacitinib_Suzuki2020_PD_acr50_params()
% Tofacitinib_Suzuki2020_PD_acr50_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tofacitinib Suzuki_2020::ACR50: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response ACR50 in its own unit. Driver: tofacitinib (dose_only).
p.E0 = -2.3;
p.Emax = 3.7;
p.EC50 = 6.099999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 61.0;
p.form = 'E0 + Emax*frac';
end
