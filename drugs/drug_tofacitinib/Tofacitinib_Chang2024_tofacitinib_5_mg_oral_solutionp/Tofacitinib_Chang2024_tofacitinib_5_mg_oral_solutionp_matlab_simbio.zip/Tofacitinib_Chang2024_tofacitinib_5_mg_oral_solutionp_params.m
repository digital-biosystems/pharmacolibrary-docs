function p = Tofacitinib_Chang2024_tofacitinib_5_mg_oral_solutionp_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tofacitinib   source: Chang_2024 / tofacitinib_5_mg_oral_solutionp   route: oral
  p.name  = 'Tofacitinib_Chang2024_tofacitinib_5_mg_oral_solutionp_params';
  p.drug  = 'tofacitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 89.22;                % central volume [L]
  p.CL = 26.05;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.78;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.19;             % absorption lag [h]
  p.dose = 3.2;             % dose [mg]
end
