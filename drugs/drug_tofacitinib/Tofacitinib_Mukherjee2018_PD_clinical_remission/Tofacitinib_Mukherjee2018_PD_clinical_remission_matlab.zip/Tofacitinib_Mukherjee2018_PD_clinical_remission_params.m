function p = Tofacitinib_Mukherjee2018_PD_clinical_remission_params()
% Tofacitinib_Mukherjee2018_PD_clinical_remission_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tofacitinib Mukherjee_2018::Clinical_remission: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml−1 per second, in SI inside (kg/m3, s). Response Clinical remission in its own unit. Driver: Tofacitinib (pk_record).
p.E0 = 0.0;
p.Emax = 2.35;
p.EC50 = 3.8599999999999995e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 39.0;
p.form = 'E0 + Emax*frac';
end
