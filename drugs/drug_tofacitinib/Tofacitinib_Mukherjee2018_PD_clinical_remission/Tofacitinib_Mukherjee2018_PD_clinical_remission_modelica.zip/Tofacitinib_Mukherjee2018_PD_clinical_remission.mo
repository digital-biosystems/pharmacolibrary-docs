model Tofacitinib_Mukherjee2018_PD_clinical_remission
  "emax exposure-response sweep — Mukherjee_2018 :: Clinical remission (Clinical remission)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.35,  // [1]
    EC50 = 3.86e-06,  // [kg/m3; ng ml−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml−1 per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 39, Interval = 0.078),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tofacitinib_Mukherjee2018_PD_clinical_remission</h4><p>The steady-state exposure-response curve of Mukherjee A et al., <i>British journal of clinical pharmacology 84(6):1136–1145</i> 2018 (<a href=\"https://doi.org/10.1111/bcp.13523\">doi:10.1111/bcp.13523</a>) — Clinical remission against Tofacitinib ng ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.35          maximal effect term (Emax, Q320)
  EC50  =       3.86 ng ml−1  exposure at half of the maximal effect term (E50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml−1 of Tofacitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.86 ng ml−1)  response 1.175
  exposure -> infinity  response 2.35</pre></body></html>"));
end Tofacitinib_Mukherjee2018_PD_clinical_remission;
