// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model NickelTrioxide_Shinohara2017_nio_c
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4990659.7000316065},
    MM = 0.058692999999999995,
    adminMass = 4.69e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nickel_trioxide</td></tr><tr><td>population:</td><td>male F344 rats</td></tr><tr><td>source_paper:</td><td>Shinohara_2017</td></tr><tr><td>measured_compound:</td><td>Nickel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Nickel 58.693 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Shinohara_2017_table_6: rows are variants (NiO A, NiO B, NiO C, NiO D), the parameters are the column headers (Clearance rate constants k Lung (1/day)) — read one record per variant</li><li>column 'detail' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Volume of samples and acid' — extend the ontology if this is a real PK parameter (source ['Shinohara_2017_table_2:row6:col2', 'Shinohara_2017_table_2:row10:col2'])</li><li>dropped unlinked row (NIL): 'ICP-MS' — extend the ontology if this is a real PK parameter (source ['Shinohara_2017_table_2:row15:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nickel</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>estimate-method split: 'NiO C' is one of 4 estimates of Shinohara_2017's substance matrix (NiO A, NiO B, NiO C, NiO D); same population, different estimation method</li><li>row roles: 4 per-group rows of Nickel oxide nanomaterials other but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=compartmental; 7/7 row label(s) assigned, 4 linked by role</li><li>molar mass: no plausible PubChem entry for 'Nickel oxide nanomaterials' ('Nickel oxide nanomaterials') — left in mass units</li><li>molar mass: none found for 'Nickel oxide nanomaterials' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end NickelTrioxide_Shinohara2017_nio_c;
