// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Selegiline_Barrett1996v3_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {30960.0},
    MM = 0.187286,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>selegiline</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Barrett_1996_3</td></tr><tr><td>measured_compound:</td><td>Selegiline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>L-amphetamine 149.237 g/mol (pubchem); L-methamphetamine 149.237 g/mol (pubchem); N-desmethylselegiline 173.259 g/mol (pubchem); Selegiline 187.286 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life in single-dose experiments selegiline', value 1.5) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life in single-dose experiments N-desmethylselegiline', value 3.8) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Selegiline</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 0 linked by role; re-tagged Selegiline→parent ×2, Selegiline→N-desmethylselegiline ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 309.6));
end Selegiline_Barrett1996v3_reference;
