function p = Mefloquine_Rufener2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mefloquine   source: Rufener_2018 / reference   route: oral
  p.name  = 'Mefloquine_Rufener2018_reference_params';
  p.drug  = 'mefloquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.04;                % central volume [L]
  p.CL = 0.014;                % clearance [L/h]
  p.Vp = [7.39];             % peripheral volumes [L]
  p.Q  = [0.027];             % inter-compartmental clearances [L/h]
  p.ka = 0.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7000.0;             % dose [mg]
end
