model Tarlatamab_Kong2025_reference
  parameter Real Cl_ref = 7.511574074074075e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00344 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tarlatamab</h4><p>Tarlatamab is a bispecific monoclonal antibody used to treat small cell lung cancer. It is an approved anticancer medicine and is authorised in the European Union, with further uses still under investigation.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tarlatamab</td></tr><tr><td>population:</td><td>patients with previously treated small cell lung cancer</td></tr><tr><td>source_paper:</td><td>Kong_2025</td></tr><tr><td>measured_compound:</td><td>tarlatamab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tarlatamab</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution (VC)' is the general volume)</li><li>molar mass: none found for 'tarlatamab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Tarlatamab_Kong2025_reference;
