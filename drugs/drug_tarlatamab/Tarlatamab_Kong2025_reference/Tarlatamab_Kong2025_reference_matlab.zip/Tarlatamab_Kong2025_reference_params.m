function p = Tarlatamab_Kong2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tarlatamab   source: Kong_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Tarlatamab_Kong2025_reference_params';
  p.drug  = 'tarlatamab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.44;                % central volume [L]
  p.CL = 0.027042;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
