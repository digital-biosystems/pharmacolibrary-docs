model Biperiden_Bakker2021_PD_at
  "linear exposure-response sweep — Bakker_2021 :: AT (adaptive tracking)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -980000,  // [(1)/(kg/m3); percentage point/ng/mL × 1e+06]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // slope_unit_assumed: slope unit 'percentage point/ng/mL' read as response per ng/mL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Biperiden_Bakker2021_PD_at</h4><p>The steady-state exposure-response curve of Bakker C et al., <i>Journal of clinical pharmacology 61(11):1466-1478</i> 2021 (<a href=\"https://doi.org/10.1002/jcph.1913\">doi:10.1002/jcph.1913</a>) — adaptive tracking [percentage point] against biperiden ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -0.98 percentage point/ng/mL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of biperiden per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Biperiden_Bakker2021_PD_at;
