function p = Biperiden_Bakker2021_PD_nback_rt_0_params()
% Biperiden_Bakker2021_PD_nback_rt_0_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% biperiden Bakker_2021::nback_RT_0: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response nback_RT_0 in milliseconds. Driver: biperiden (pk_record).
p.E0 = 0.0;
p.Emax = 0.2885;
p.EC50 = 6.719999999999999e-06;
p.gamma = 2.25;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 68.0;
p.form = 'E0 + Emax*frac';
end
