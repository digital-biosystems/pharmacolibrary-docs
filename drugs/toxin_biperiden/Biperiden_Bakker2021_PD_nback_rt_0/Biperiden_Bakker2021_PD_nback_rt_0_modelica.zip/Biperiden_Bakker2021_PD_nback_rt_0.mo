model Biperiden_Bakker2021_PD_nback_rt_0
  "sigmoid_emax exposure-response sweep — Bakker_2021 :: nback_RT_0 (n-back reaction time 0-back condition)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.2885,  // [s; milliseconds × 0.001]
    EC50 = 6.72e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.25,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 68, Interval = 0.136),
    Documentation(info = "<html><body><h4>Biperiden_Bakker2021_PD_nback_rt_0</h4><p>The steady-state exposure-response curve of Bakker C et al., <i>Journal of clinical pharmacology 61(11):1466-1478</i> 2021 (<a href=\"https://doi.org/10.1002/jcph.1913\">doi:10.1002/jcph.1913</a>) — n-back reaction time 0-back condition [milliseconds] against biperiden ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      288.5 milliseconds maximal effect term (Emax, Q320)
  EC50  =       6.72 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.25          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of biperiden per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.72 ng/mL)  response 0.1442
  exposure -> infinity  response 0.2885</pre></body></html>"));
end Biperiden_Bakker2021_PD_nback_rt_0;
