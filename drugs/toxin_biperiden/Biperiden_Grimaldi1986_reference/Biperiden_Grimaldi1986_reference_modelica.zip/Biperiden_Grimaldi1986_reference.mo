model Biperiden_Grimaldi1986_reference
  parameter Real Cl_ref = 0.00021564578950753851 "Cl [m3/s]";
  parameter Real Vd_ref = 1.68 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.311469,
    adminMass = 1e-05,
    ka = 0.0007583333333333333,
    Tlag = 1944.0000000000002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>biperiden</td></tr><tr><td>population:</td><td>normal subjects</td></tr><tr><td>source_paper:</td><td>Grimaldi_1986</td></tr><tr><td>measured_compound:</td><td>Biperiden</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>biperiden 311.469 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml X min-1 X kg-1' (CL)</li><li>implicit units: 'Clearance' → L/h (from the popPK convention: 'No unit stated in the paper text or footnotes. For population pharmacokinetics, total clearance (CL) is conventionally e')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Biperiden</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bakker_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Bakker_2021's review values (primary lacked it)</li><li>derived CL/F=776.325 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Biperiden_Grimaldi1986_reference;
