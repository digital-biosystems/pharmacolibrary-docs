function p = Biperiden_Bakker2021_PD_nback_acc_2_params()
% Biperiden_Bakker2021_PD_nback_acc_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% biperiden Bakker_2021::nback_Acc_2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response nback_Acc_2 in its own unit. Driver: biperiden (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -200000.00000000003;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
