model Biperiden_Bakker2021_PD_nback_rt_1
  "linear exposure-response sweep — Bakker_2021 :: nback_RT_1 (n-back reaction time 1-back condition)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 16180,  // [meter ** 3 * second / kilogram; ms/ng/mL × 1000]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Biperiden_Bakker2021_PD_nback_rt_1</h4><p>The steady-state exposure-response curve of Bakker C et al., <i>Journal of clinical pharmacology 61(11):1466-1478</i> 2021 (<a href=\"https://doi.org/10.1002/jcph.1913\">doi:10.1002/jcph.1913</a>) — n-back reaction time 1-back condition [milliseconds] against biperiden ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      16.18 ms/ng/mL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of biperiden per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Biperiden_Bakker2021_PD_nback_rt_1;
