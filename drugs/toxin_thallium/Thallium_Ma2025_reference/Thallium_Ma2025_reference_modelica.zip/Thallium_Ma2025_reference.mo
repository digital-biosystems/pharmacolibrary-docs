// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Thallium_Ma2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {28792.26750018234},
    MM = 0.20438,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thallium</td></tr><tr><td>population:</td><td>Intertidal snail Reishia clavigera</td></tr><tr><td>source_paper:</td><td>Ma_2025</td></tr><tr><td>measured_compound:</td><td>Thallium (Tl)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Thallium (Tl) 204.38 g/mol (pubchem); thallium 239.83 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped 'ku' → Q24: the uptake rate from the exposure medium (bioaccumulation), not a body toxicokinetic parameter</li><li>unit_dimension_unknown: 'L kg-1 dry weight' (Kp)</li><li>dropped 'uptake rate' → Q349: a water-uptake rate in 'L g-1 day-1' (bioaccumulation from the medium), not a body toxicokinetic parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Thallium (Tl)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: ke printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 288.0));
end Thallium_Ma2025_reference;
