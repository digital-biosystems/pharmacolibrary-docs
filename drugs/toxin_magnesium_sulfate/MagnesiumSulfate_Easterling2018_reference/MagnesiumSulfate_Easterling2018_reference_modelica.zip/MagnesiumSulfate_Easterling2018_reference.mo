model MagnesiumSulfate_Easterling2018_reference
  parameter Real Cl_ref = 9.383333333333332e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0653 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.024305,
    adminMass = 0.001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>Women with severe preeclampsia</td></tr><tr><td>source_paper:</td><td>Easterling_2018</td></tr><tr><td>measured_compound:</td><td>Magnesium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Magnesium 24.305 g/mol (pubchem); Magnesium Sulfate 120.361 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is magnesium_sulfate; the compartment is Magnesium. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Magnesium, not magnesium_sulfate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>magnesium_sulfate's own concentration-time course is not produced by this model</li><li>column 'clearance (ml/min)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): '(mg/dL)' — extend the ontology if this is a real PK parameter (source ['Tab4:row3:col1'])</li><li>salvaged Q22 ('Clearance'=56.3) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Volume of distribution'=65.3) from results prose — parameter table was unreadable</li><li>metabolite magnesium: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite magnesium: Q61→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Magnesium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 1/1 row label(s) assigned, 0 linked by role; re-tagged parent→Magnesium ×1</li><li>review gap-fill skipped: this record measures 'Magnesium', not magnesium_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_Easterling2018_reference;
