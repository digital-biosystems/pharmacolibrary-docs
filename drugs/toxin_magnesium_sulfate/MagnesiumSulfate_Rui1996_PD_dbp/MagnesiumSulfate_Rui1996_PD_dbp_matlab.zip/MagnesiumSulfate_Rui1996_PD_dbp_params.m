function p = MagnesiumSulfate_Rui1996_PD_dbp_params()
% MagnesiumSulfate_Rui1996_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% magnesium_sulfate Rui_1996::DBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microgram.ml-1 per second, in SI inside (kg/m3, s). Response DBP in %. Driver: magnesium_sulfate (cited_pk).
p.E0 = 0.0;
p.Emax = -0.2873;
p.EC50 = 0.028389999999999995;
p.gamma = 4.22;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 290.0;
p.form = 'E0 + Emax*frac';
end
