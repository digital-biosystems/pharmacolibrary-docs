model MagnesiumSulfate_Rui1996_PD_dbp
  "sigmoid_emax exposure-response sweep — Rui_1996 :: DBP (diastolic blood pressure lowering effect)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.2873,  // [1; % × 0.01]
    EC50 = 0.02839,  // [kg/m3; microgram.ml-1 × 0.001]
    gamma = 4.22,
    exposure_per_s = 0.001);   // 1 microgram.ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 290, Interval = 0.58),
    Documentation(info = "<html><body><h4>MagnesiumSulfate_Rui1996_PD_dbp</h4><p>The steady-state exposure-response curve of Rui JZ et al., <i>Yao xue xue bao = Acta pharmaceutica Sinica 31(2):81-85</i> 1996 — diastolic blood pressure lowering effect [%] against magnesium_sulfate microgram.ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      28.73 %        maximal effect term (Emax, Q323)
  EC50  =      28.39 microgram.ml-1 exposure at half of the maximal effect term (Ce(50), Q321)
  gamma =       4.22          Hill coefficient (upsilon, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microgram.ml-1 of magnesium_sulfate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (28.39 microgram.ml-1)  response -0.1436
  exposure -> infinity  response -0.2873</pre></body></html>"));
end MagnesiumSulfate_Rui1996_PD_dbp;
