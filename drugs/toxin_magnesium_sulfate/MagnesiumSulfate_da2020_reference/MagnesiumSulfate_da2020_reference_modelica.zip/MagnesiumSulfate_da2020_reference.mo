model MagnesiumSulfate_da2020_reference
  parameter Real Cl_ref = 3.833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.024305,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>pregnant women with preeclampsia</td></tr><tr><td>source_paper:</td><td>da_2020</td></tr><tr><td>measured_compound:</td><td>Magnesium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Magnesium 24.305 g/mol (pubchem); magnesium_sulfate 120.361 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Beta_CL_creatinine_mg_dL' — extend the ontology if this is a real PK parameter (source ['Tab3:row3:col2'])</li><li>dropped unlinked row (NIL): 'Beta_V_Weith_kg' — extend the ontology if this is a real PK parameter (source ['Tab3:row4:col2'])</li><li>implicit units: 'V_pop' → L (from the paper text: &quot;The paper text explicitly states: 'for V, it was 13.3 L'.&quot;)</li><li>implicit units: 'CL_pop' → L/h (from the paper text: &quot;The paper text explicitly states: 'The model estimate of the population CL was 1.38 L/h'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Magnesium</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>review gap-fill skipped: this record measures 'Magnesium', not magnesium_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_da2020_reference;
