model MagnesiumSulfate_Brookfield2021_reference
  parameter Real Cl_ref = 1.0333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0154 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.91,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.024305,
    adminMass = 0.004,
    ka = 0.00012527777777777778,
    Tlag = 0.0,
    k21 = 5.980392156862745e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>women with severe preeclampsia</td></tr><tr><td>source_paper:</td><td>Brookfield_2021</td></tr><tr><td>measured_compound:</td><td>Magnesium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Magnesium 24.305 g/mol (pubchem); magnesium_sulfate 120.361 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional (CV%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional (CV%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('Residual error')</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Magnesium</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>review gap-fill skipped: this record measures 'Magnesium', not magnesium_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_Brookfield2021_reference;
