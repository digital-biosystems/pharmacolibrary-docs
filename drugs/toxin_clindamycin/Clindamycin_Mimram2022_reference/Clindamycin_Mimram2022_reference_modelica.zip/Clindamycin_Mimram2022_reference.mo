model Clindamycin_Mimram2022_reference
  parameter Real Cl_ref = 6.3888888888888885e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.425,
    adminMass = 0.0012,
    ka = 0.0009805555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clindamycin</td></tr><tr><td>population:</td><td>patients with prosthetic joint infections</td></tr><tr><td>source_paper:</td><td>Mimram_2022</td></tr><tr><td>measured_compound:</td><td>Clindamycin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-11-01462-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clindamycin 425 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω² CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω² V/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω² Ka' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Clindamycin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clindamycin_Mimram2022_reference;
