function p = Clindamycin_Wang2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clindamycin   source: Wang_2023 / reference   route: oral
  p.name  = 'Clindamycin_Wang2023_reference_params';
  p.drug  = 'clindamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 76.74;                % central volume [L]
  p.CL = 30.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.69;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
