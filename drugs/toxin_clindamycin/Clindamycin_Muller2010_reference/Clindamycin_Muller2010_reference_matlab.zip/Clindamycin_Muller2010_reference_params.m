function p = Clindamycin_Muller2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clindamycin   source: Muller_2010 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Clindamycin_Muller2010_reference_params';
  p.drug  = 'clindamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 63.6;                % central volume [L]
  p.CL = 10.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.53;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.105;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
