model Clindamycin_Magrault2025_reference
  parameter Real Cl_ref = 1.0833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0636 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 56.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.425,
    adminMass = 0.0012,
    ka = 0.0009805555555555555,
    Tlag = 378.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clindamycin</td></tr><tr><td>population:</td><td>patients treated for bone and joint infections</td></tr><tr><td>source_paper:</td><td>Magréault_2025</td></tr><tr><td>measured_compound:</td><td>clindamycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clindamycin 425 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'plasma samples' — extend the ontology if this is a real PK parameter (source ['Magréault_2025:abstract'])</li><li>dropped unlinked row (NIL): 'patients' — extend the ontology if this is a real PK parameter (source ['Magréault_2025:abstract'])</li><li>dropped unlinked row (NIL): 'daily i.v. dose' — extend the ontology if this is a real PK parameter (source ['Magréault_2025:abstract'])</li><li>dropped unlinked row (NIL): 'dose needed for MIC equal to the 0.25 mg/L EUCAST clinical breakpoint for Staphylococcus aureus' — extend the ontology if this is a real PK parameter (source ['Magréault_2025:abstract'])</li><li>dropped unlinked row (NIL): 'EUCAST clinical breakpoint for Staphylococcus aureus' — extend the ontology if this is a real PK parameter (source ['Magréault_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clindamycin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Gerhart_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Gonzalez_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Mimram_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Pfaffendorf_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Gerhart_2022, Gonzalez_2016, Mimram_2022, Pfaffendorf_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Clindamycin_Magrault2025_reference;
