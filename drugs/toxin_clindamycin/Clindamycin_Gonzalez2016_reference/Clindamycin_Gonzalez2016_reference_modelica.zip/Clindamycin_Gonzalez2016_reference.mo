model Clindamycin_Gonzalez2016_reference
  parameter Real Cl_ref = 3.0555555555555556e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.425,
    adminMass = 0.0012,
    ka = 0.0009805555555555555,
    Tlag = 378.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clindamycin</td></tr><tr><td>population:</td><td>preterm and term infants (PNA <121 days) with pooled pediatric trial data</td></tr><tr><td>source_paper:</td><td>Gonzalez_2016</td></tr><tr><td>measured_compound:</td><td>Clindamycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clindamycin 425 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL (liters/h/kg)', value '0.14') — already have one for this compound</li><li>dropped duplicate Q22 ('CL (liters/h/70 kg)', value '3.31') — already have one for this compound</li><li>dropped duplicate Q61 ('V (liters/kg)', value '1.20') — already have one for this compound</li><li>dropped duplicate Q61 ('V (liters/kg/70 kg)', value '83.50') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Clindamycin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Mimram_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Pfaffendorf_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Clindamycin_Gonzalez2016_reference;
