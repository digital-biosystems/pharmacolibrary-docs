model DFructose_Takahashi2014_reference
  parameter Real Cl_ref = 1.9444444444444442e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6988414778066138 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180156,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>d_fructose</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Takahashi_2014</td></tr><tr><td>measured_compound:</td><td>d_fructose</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>d_fructose 180.156 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Takahashi_2014) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end DFructose_Takahashi2014_reference;
