function p = DFructose_Takahashi2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: d_fructose   source: Takahashi_2014 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'DFructose_Takahashi2014_reference_params';
  p.drug  = 'd_fructose';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 698.841478;                % central volume [L]
  p.CL = 70.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
