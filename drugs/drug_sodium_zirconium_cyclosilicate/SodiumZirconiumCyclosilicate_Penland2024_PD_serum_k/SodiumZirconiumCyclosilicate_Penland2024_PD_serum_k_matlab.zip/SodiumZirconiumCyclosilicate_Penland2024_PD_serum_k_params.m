function p = SodiumZirconiumCyclosilicate_Penland2024_PD_serum_k_params()
% SodiumZirconiumCyclosilicate_Penland2024_PD_serum_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sodium_zirconium_cyclosilicate Penland_2024::serum_K: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one g per second, in SI inside (kg/m3, s). Response serum K+ in mmol/L. Driver: sodium zirconium cyclosilicate (virtual exposure) (dose_only).
p.E0 = 1.6843065693430657;
p.Emax = 63.3;
p.EC50 = 0.032799999999999996;
p.gamma = 1.36;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 50.0;
p.form = 'E0/(1 + Emax*frac)';
end
