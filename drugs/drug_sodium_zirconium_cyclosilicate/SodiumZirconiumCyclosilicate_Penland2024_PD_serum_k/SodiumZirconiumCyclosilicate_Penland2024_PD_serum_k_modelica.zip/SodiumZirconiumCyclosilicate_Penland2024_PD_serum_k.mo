model SodiumZirconiumCyclosilicate_Penland2024_PD_serum_k
  "indirect_response_i exposure-response sweep — Penland_2024 :: serum K+ (serum potassium concentration)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 1.68430656934,      // [mmol/L]
    Emax = 63.3,  // type IV effect term
    EC50 = 0.0328,  // [kg; g × 0.001]
    gamma = 1.36,
    exposure_per_s = 0.001);   // 1 g per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.923/0.548 = 1.684) — the paper's stated baseline may differ
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 63.3; bound as the reciprocal stimulation form (IV) the paper fitted
  annotation(experiment(StartTime = 0, StopTime = 50, Interval = 0.1),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sodium_zirconium_cyclosilicate</h4><p>Sodium zirconium cyclosilicate is a potassium binder used to treat hyperkalemia (high blood potassium). It is authorised in the European Union and is an approved medicine, used for the treatment of hyperkalemia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17091153\">Wikidata Q17091153</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>SodiumZirconiumCyclosilicate_Penland2024_PD_serum_k</h4><p>The steady-state exposure-response curve of Penland RC et al., <i>Clinical pharmacokinetics 63(4):551–560</i> 2024 (<a href=\"https://doi.org/10.1007/s40262-024-01360-9\">doi:10.1007/s40262-024-01360-9</a>) — serum potassium concentration [mmol/L] against sodium zirconium cyclosilicate (virtual exposure) g — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 1.68430656934 mmol/L   drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       63.3          maximal effect term (Emax, Q323)
  EC50  =       32.8 g        exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.36          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one g of sodium zirconium cyclosilicate (virtual exposure) per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.684   (drug-free)
  exposure = EC50 (32.8 g)  response 0.05159
  exposure -> infinity  response 0.02619</pre></body></html>"));
end SodiumZirconiumCyclosilicate_Penland2024_PD_serum_k;
