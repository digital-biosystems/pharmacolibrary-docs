model Sertraline_Xia2025_reference
  parameter Real Cl_ref = 1.827777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.57 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>adolescent patients with depression</td></tr><tr><td>source_paper:</td><td>Xia_2025</td></tr><tr><td>measured_compound:</td><td>sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PRO (%)' — extend the ontology if this is a real PK parameter (source ['t0002:row5:col1', 't0002:row5:col4', 't0002:row5:col5'])</li><li>routed 'ADD (%)' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sertraline</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Sertraline_Xia2025_reference;
