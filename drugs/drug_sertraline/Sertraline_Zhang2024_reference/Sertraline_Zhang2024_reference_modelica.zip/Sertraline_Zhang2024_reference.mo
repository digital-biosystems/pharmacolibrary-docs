model Sertraline_Zhang2024_reference
  parameter Real Cl_ref = 2.113888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.803 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sertraline</h4><p>Sertraline is a selective serotonin reuptake inhibitor used to treat depression, anxiety disorders, obsessive-compulsive disorder, and panic disorder. It is given orally in forms such as tablets and capsules. It is widely used and available as a generic medication, ranking among the most prescribed drugs in countries like the United States and Australia.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q407617\">Wikidata Q407617</a>, <a href=\"https://en.wikipedia.org/wiki/Sertraline?oldid=1384677624\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>Chinese patients with psychiatric disorders</td></tr><tr><td>source_paper:</td><td>Zhang_2024</td></tr><tr><td>measured_compound:</td><td>sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'θCL-AGE' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'PRO (CV%)' — extend the ontology if this is a real PK parameter (source ['Zhang_2024_table_p4_1:row5:col1'])</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'The paper does not explicitly state the unit for CL/F. Based on the magnitude of the value (76.1) and standard populatio')</li><li>implicit units: 'V/F' → L (from the popPK convention: 'The paper does not explicitly state the unit for V/F. Based on the magnitude of the value (803) and standard population ')</li><li>implicit units: 'K' → 1/h (from the popPK convention: 'The paper does not explicitly state the unit for K (elimination rate constant). Based on the magnitude of the value (0.0')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sertraline</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Sertraline_Zhang2024_reference;
