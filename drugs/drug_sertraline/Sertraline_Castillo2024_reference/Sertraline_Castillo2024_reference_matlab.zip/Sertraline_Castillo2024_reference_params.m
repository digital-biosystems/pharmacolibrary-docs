function p = Sertraline_Castillo2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sertraline   source: Castillo_2024 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Sertraline_Castillo2024_reference_params';
  p.drug  = 'sertraline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1414.0;                % central volume [L]
  p.CL = 66.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.855;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
