model Sertraline_Castillo2024_reference
  parameter Real Cl_ref = 1.8333333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.414 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002375,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>patients with psychiatric and substance use disorders</td></tr><tr><td>source_paper:</td><td>Castillo_2024</td></tr><tr><td>measured_compound:</td><td>sertraline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'interindividual variability in sertraline clearance' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (sertraline clearance); Q61 (volume of distribution)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sertraline</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Sertraline_Castillo2024_reference;
