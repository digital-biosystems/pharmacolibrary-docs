model Daclizumab_Othman2014_reference
  parameter Real Cl_ref = 2.7777777777777776e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0038900000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About daclizumab</h4><p>Daclizumab, a monoclonal antibody immunosuppressant, was used to treat multiple sclerosis and to prevent graft rejection in kidney transplantation. It has been withdrawn from the market, including its authorised products in the European Union, and is no longer in use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412920\">Wikidata Q412920</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>daclizumab</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Othman_2014</td></tr><tr><td>measured_compound:</td><td>daclizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=daclizumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central ... volumes of distribution' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'daclizumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Daclizumab_Othman2014_reference;
