function p = Daclizumab_Othman2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daclizumab   source: Othman_2014 / reference   route: iv_bolus
  p.name  = 'Daclizumab_Othman2014_reference_params';
  p.drug  = 'daclizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.89;                % central volume [L]
  p.CL = 0.01;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.84;                 % bioavailability [0-1]
  p.Tlag = 2.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
