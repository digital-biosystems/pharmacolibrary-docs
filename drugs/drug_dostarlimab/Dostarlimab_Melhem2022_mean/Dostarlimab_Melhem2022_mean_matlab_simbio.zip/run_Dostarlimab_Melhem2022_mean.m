% Run (SimBiology): build model + dose, simulate 0..2520.0 h, plot.
p = Dostarlimab_Melhem2022_mean_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2520.0);
