function p = Oprelvekin_Kheifetz2014_3_comp_pe_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oprelvekin   source: Kheifetz_2014 / 3_comp_pe_model   route: oral
  % estimated (absent from source): F
  p.name  = 'Oprelvekin_Kheifetz2014_3_comp_pe_model_params';
  p.drug  = 'oprelvekin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.91;                % central volume [L]
  p.CL = 14.6;                % clearance [L/h]
  p.Vp = [11.5];             % peripheral volumes [L]
  p.Q  = [0.465];             % inter-compartmental clearances [L/h]
  p.ka = 0.152;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.5;             % dose [mg]
end
