model Beauvericin_Yuan2022_reference
  parameter Real Cl_ref = 2.788333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.3729999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7838999999999999,
    adminMass = 3.5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>beauvericin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Yuan_2022</td></tr><tr><td>measured_compound:</td><td>Beauvericin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>toxins-14-00477-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>beauvericin 783.9 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Clint'</li><li>salvaged Q57 ('The T1/2 of BEA in the plasma of the five species'=5) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance ... after intravenous injection'=23.9) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Beauvericin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Yuan_2022:discussion_prose, Yuan_2022:other_prose, toxins-14-00477-t003:footnote); populations clm / bea, dlm / bea, hlm / bea, i.v., mlm / bea, p.o., rlm / bea kept as separate records</li><li>gap-filled Q61 (V) from Behr_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Behr_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Beauvericin_Yuan2022_reference;
