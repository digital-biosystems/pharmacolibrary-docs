function p = Beauvericin_Yuan2022_i_v_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: beauvericin   source: Yuan_2022 / i_v   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Beauvericin_Yuan2022_i_v_params';
  p.drug  = 'beauvericin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 413.0;                % central volume [L]
  p.CL = 100.38;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 35.0;             % dose [mg]
end
