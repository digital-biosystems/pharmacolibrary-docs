model Beauvericin_Yuan2022_i_v
  parameter Real Cl_ref = 2.788333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.41300000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7838999999999999,
    adminMass = 3.5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>beauvericin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Yuan_2022</td></tr><tr><td>measured_compound:</td><td>Beauvericin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>toxins-14-00477-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>beauvericin 783.9 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Dosed (mg/kg)' — extend the ontology if this is a real PK parameter (source ['Yuan_2022_table_7:row0:col1'])</li><li>dropped value-less row: 'Clint'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Beauvericin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'i.v.' subgroup of Yuan_2022 (paper reports 7 populations: clm / bea, dlm / bea, hlm / bea, i.v., mlm / bea, p.o., rlm / bea)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Beauvericin_Yuan2022_i_v;
