// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Beauvericin_Yuan2022_dlm_bea
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {366.0},
    MM = 0.7838999999999999,
    adminMass = 3.5e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>beauvericin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Yuan_2022</td></tr><tr><td>measured_compound:</td><td>Beauvericin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>toxins-14-00477-t003</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>beauvericin 783.9 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'CLint(liver) (mL/min/kg)' → Q3 (unit '[length] ** 3 / [time]' vs ontology '[length] ** 3 / [time] / [mass]') — route to review</li><li>dropped duplicate Q3 ('CLint(liver) (mL/min/kg)', value '329.4') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Remaining % (T = 60 min)' — extend the ontology if this is a real PK parameter (source ['toxins-14-00477-t003:row5:col8'])</li><li>dropped value-less row: 'Clint'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Beauvericin</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'dlm / bea' subgroup of Yuan_2022 (paper reports 7 populations: clm / bea, dlm / bea, hlm / bea, i.v., mlm / bea, p.o., rlm / bea)</li><li>skipped review gap-fill of CL from Fraeyman_2017: its label names a different analyte ('enn') — 'Cl of ENN B1 after iv administration'</li><li>gap-filled Q61 (V) from Behr_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Beauvericin_Yuan2022_dlm_bea;
