model Vaborbactam_Fornari2024_reference
  parameter Real Cl_ref = 2.733333333333333e-06 "Cl [m3/s]";
  parameter Real cov_cr_cl_0 = 0 "cr_CL covariate";
  parameter Real Vd_ref = 0.014400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.83)*cov_cr_cl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29713,
    adminMass = 1e-05,
    k21 = 0.0002126736111111111
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vaborbactam</h4><p>Vaborbactam is a beta-lactamase inhibitor used in combination with a carbapenem antibiotic to treat urinary tract infections caused by resistant bacteria. It is an approved drug, used mainly in hospital settings for serious gram-negative infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27252228\">Wikidata Q27252228</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vaborbactam</td></tr><tr><td>population:</td><td>paediatric patients with Gram-negative bacterial infections</td></tr><tr><td>source_paper:</td><td>Fornari_2024</td></tr><tr><td>measured_compound:</td><td>vaborbactam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vaborbactam 297.13 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12.</p><h4>Interpretation flags</h4><ul><li>covariate level 'βCLcr_CL' → Q900:theta_cl_cr_cl = 0.83 (linear_fractional on Q22)</li><li>dropped duplicate Q22 ('βBW_CL', value '0.75') — already have one for this compound</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_2:row7:col4', 'tab_2:row31:col4'])</li><li>dropped unlinked row (NIL): 'PMA50 (weeks)' — extend the ontology if this is a real PK parameter (source ['tab_2:row8:col4', 'tab_2:row32:col4'])</li><li>dropped duplicate Q63 ('βBW_V1', value '1') — already have one for this compound</li><li>dropped unlinked row (NIL): 'βBW_Q' — extend the ontology if this is a real PK parameter (source ['tab_2:row12:col1', 'tab_2:row12:col4', 'tab_2:row36:col1', 'tab_2:row36:col4'])</li><li>dropped duplicate Q64 ('βBW_V2', value '1') — already have one for this compound</li><li>dropped unlinked row (NIL): 'b' — extend the ontology if this is a real PK parameter (source ['tab_2:row23:col1', 'tab_2:row23:col2', 'tab_2:row23:col4', 'tab_2:row23:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vaborbactam</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vaborbactam_Fornari2024_reference;
