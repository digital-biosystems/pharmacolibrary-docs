function p = Vaborbactam_Fornari2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vaborbactam   source: Fornari_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vaborbactam_Fornari2024_reference_params';
  p.drug  = 'vaborbactam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 14.4;                % central volume [L]
  p.CL = 9.84;                % clearance [L/h]
  p.Vp = [2.56];             % peripheral volumes [L]
  p.Q  = [1.96];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
