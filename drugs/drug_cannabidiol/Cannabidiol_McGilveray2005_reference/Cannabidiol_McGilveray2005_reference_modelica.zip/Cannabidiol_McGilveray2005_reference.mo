model Cannabidiol_McGilveray2005_reference
  parameter Real Cl_ref = 3.88888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7000000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.314469,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cannabidiol</h4><p>Cannabidiol is a cannabinoid antiepileptic used to treat rare forms of childhood epilepsy. It is given orally, sublingually, or topically. It is used in the European Union for specific epilepsy syndromes and is approved in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422917\">Wikidata Q422917</a>, <a href=\"https://en.wikipedia.org/wiki/Cannabidiol?oldid=1385792146\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cannabidiol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>McGilveray_2005</td></tr><tr><td>measured_compound:</td><td>cannabidiol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cannabidiol 314.469 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (McGilveray_2005) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Cannabidiol_McGilveray2005_reference;
