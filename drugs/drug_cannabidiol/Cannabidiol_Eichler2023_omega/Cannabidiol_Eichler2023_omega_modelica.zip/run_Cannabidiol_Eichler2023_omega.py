#!/usr/bin/env python3
"""Run Cannabidiol_Eichler2023_omega.mo with OpenModelica/OMPython over 0..86400s (= 24 h) and write
results of the central-compartment concentration (C_central).

Headless-friendly: writes Cannabidiol_Eichler2023_omega.png, Cannabidiol_Eichler2023_omega.csv (time_s, central_conc) and Cannabidiol_Eichler2023_omega.json
next to this script (no interactive window). Requires OpenModelica + `pip install OMPython`.
The model's base-class library (Pharmacolibrary) must be on the PHARMACOLIBRARY_MO env
var (os.pathsep-separated) or edited into LIBS below.
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
from OMPython import ModelicaSystem

HERE   = os.path.dirname(os.path.abspath(__file__))
BASE   = os.path.join(HERE, "Cannabidiol_Eichler2023_omega")
MODEL  = "Cannabidiol_Eichler2023_omega"
RESULT = "C_central"
STOP   = 86400
POINTS = 500

LIBS = [p for p in os.environ.get("PHARMACOLIBRARY_MO", "/home/vagrant/Pharmacolibrary/Pharmacolibrary/package.mo").split(os.pathsep) if p]
if not LIBS:
    print("WARNING: no Modelica library on PHARMACOLIBRARY_MO — the base class may not resolve")

# OpenModelica compiles into the cwd; run inside this script's dir to contain artifacts.
cwd = os.getcwd()
try:
    os.chdir(HERE)
    mod = ModelicaSystem(BASE + ".mo", MODEL, LIBS or None)
    step = STOP / max(POINTS - 1, 1)
    mod.simulate(simargs={"startTime": 0, "stopTime": STOP, "stepSize": step, "tolerance": 1e-6})
    t = [float(x) for x in mod.getSolutions("time")[0]]
    C = [float(x) for x in mod.getSolutions(RESULT)[0]]
finally:
    os.chdir(cwd)

with open(BASE + ".csv", "w") as f:
    f.write("time_s,central_conc\n")
    for ti, ci in zip(t, C):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": MODEL, "variable": RESULT, "stop_time_s": STOP,
               "time_s": t, "central_concentration": C}, f, indent=2)

plt.figure()
plt.plot([ti / 3600.0 for ti in t], C, linewidth=1.5)   # x axis in hours
plt.xlabel("time [h]"); plt.ylabel("central concentration (%s)" % RESULT)
plt.title(MODEL); plt.grid(True); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
