function p = Glimepiride_Mele2014_PD_katp_channel_current_in_edl_params()
% Glimepiride_Mele2014_PD_katp_channel_current_in_edl_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glimepiride Mele_2014::KATP_channel_current_in_EDL: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one 10−6 mol/L per second, in SI inside (kg/m3, s). Response KATP channel current in EDL in %. Driver: glimepiride (cited_pk).
p.E0 = -0.019;
p.Emax = -0.804;
p.EC50 = 48.8;
p.gamma = 0.91;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 490.0;
p.form = 'E0 + Emax*frac';
end
