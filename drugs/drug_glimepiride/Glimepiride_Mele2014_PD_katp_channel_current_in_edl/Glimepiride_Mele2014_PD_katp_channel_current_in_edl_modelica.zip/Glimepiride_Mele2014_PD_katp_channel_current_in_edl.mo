model Glimepiride_Mele2014_PD_katp_channel_current_in_edl
  "sigmoid_emax exposure-response sweep — Mele_2014 :: KATP channel current in EDL (KATP channel current in EDL)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -0.019,      // [1; % × 0.01]
    Emax = -0.804,  // [1; % × 0.01]
    EC50 = 48.8,  // [10−6 mol/L]
    gamma = 0.91,
    exposure_per_s = 1);   // 1 10−6 mol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '10−6 mol/L' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 490, Interval = 0.98),
    Documentation(info = "<html><body><!-- drug-about --><h4>About glimepiride</h4><p>Glimepiride is a sulfonylurea medicine used to lower blood sugar in people with diabetes. It is an approved drug, widely used as an oral diabetes treatment, and is also available in combination products with other glucose-lowering medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106029845\">Wikidata Q106029845</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Glimepiride_Mele2014_PD_katp_channel_current_in_edl</h4><p>The steady-state exposure-response curve of Mele A et al., <i>Pharmacology research &amp; perspectives 2(1):e00028</i> 2014 (<a href=\"https://doi.org/10.1002/prp2.28\">doi:10.1002/prp2.28</a>) — KATP channel current in EDL [%] against glimepiride 10−6 mol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       -1.9 %        drug-free response (baseline) (Emin (%), Q324)
  Emax  =      -80.4 %        maximal effect term (Emax (%), Q323)
  EC50  =       48.8 10−6 mol/L exposure at half of the maximal effect term (EC50 (10−6 mol/L), Q322)
  gamma =       0.91          Hill coefficient (Slope factor n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one 10−6 mol/L of glimepiride per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -0.019   (drug-free)
  exposure = EC50 (48.8 10−6 mol/L)  response -0.421
  exposure -> infinity  response -0.823</pre></body></html>"));
end Glimepiride_Mele2014_PD_katp_channel_current_in_edl;
