function p = Glimepiride_Mele2014_PD_katp_channel_current_in_sol_params()
% Glimepiride_Mele2014_PD_katp_channel_current_in_sol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glimepiride Mele_2014::KATP_channel_current_in_SOL: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one 10−6 mol/L per second, in SI inside (kg/m3, s). Response KATP channel current in SOL in %. Driver: glimepiride (cited_pk).
p.E0 = -0.021;
p.Emax = -0.753;
p.EC50 = 55.1;
p.gamma = 0.9;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 560.0;
p.form = 'E0 + Emax*frac';
end
