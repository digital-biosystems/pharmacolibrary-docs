#!/usr/bin/env python3
"""Sweep Glimepiride_Mele2014_PD_katp_channel_current_in_sol.sbml with Tellurium/libRoadRunner: response against exposure.

Simulated time is the swept exposure (exposure = exposure_per_s * time), so the x axis of the
plot is `exposure`, not time. Writes Glimepiride_Mele2014_PD_katp_channel_current_in_sol.csv/.json/.png next to this script.
"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Glimepiride_Mele2014_PD_katp_channel_current_in_sol")
r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 560.0, 500, ["time", "exposure", "response"])
x = [float(v) for v in res[:, 1]]; y = [float(v) for v in res[:, 2]]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Glimepiride_Mele2014_PD_katp_channel_current_in_sol", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [10−6 mol/L]"); plt.ylabel("response [%]")
plt.title("Glimepiride_Mele2014_PD_katp_channel_current_in_sol"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
