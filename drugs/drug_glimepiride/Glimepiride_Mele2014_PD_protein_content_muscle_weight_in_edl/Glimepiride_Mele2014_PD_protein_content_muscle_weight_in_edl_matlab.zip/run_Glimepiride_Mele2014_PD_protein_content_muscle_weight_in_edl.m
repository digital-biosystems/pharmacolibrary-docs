% run_Glimepiride_Mele2014_PD_protein_content_muscle_weight_in_edl  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Glimepiride_Mele2014_PD_protein_content_muscle_weight_in_edl_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [10−6 mol/L]'); ylabel('response [%]'); title('Glimepiride_Mele2014_PD_protein_content_muscle_weight_in_edl', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Glimepiride_Mele2014_PD_protein_content_muscle_weight_in_edl.csv');
