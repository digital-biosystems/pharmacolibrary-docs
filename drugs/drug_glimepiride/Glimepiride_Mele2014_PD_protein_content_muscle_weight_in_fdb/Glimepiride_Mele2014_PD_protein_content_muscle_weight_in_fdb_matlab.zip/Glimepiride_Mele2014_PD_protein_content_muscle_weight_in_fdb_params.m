function p = Glimepiride_Mele2014_PD_protein_content_muscle_weight_in_fdb_params()
% Glimepiride_Mele2014_PD_protein_content_muscle_weight_in_fdb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glimepiride Mele_2014::protein_content_muscle_weight_in_FDB: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one 10−6 mol/L per second, in SI inside (kg/m3, s). Response protein content/muscle weight in FDB in %. Driver: glimepiride (cited_pk).
p.E0 = -0.0239;
p.Emax = -0.4042;
p.EC50 = 29.3;
p.gamma = 0.45;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 300.0;
p.form = 'E0 + Emax*frac';
end
