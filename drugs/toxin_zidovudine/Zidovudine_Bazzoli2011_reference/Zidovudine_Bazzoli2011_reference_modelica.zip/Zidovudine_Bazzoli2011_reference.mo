// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Zidovudine_Bazzoli2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {76176.0},
    MM = 0.267245,
    adminMass = 0.0006,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zidovudine</td></tr><tr><td>population:</td><td>naïve HIV-infected patients</td></tr><tr><td>source_paper:</td><td>Bazzoli_2011</td></tr><tr><td>measured_compound:</td><td>Zidovudine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Zidovudine 267.245 g/mol (pubchem); Zidovudine triphosphate 507.182 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zidovudine</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role; re-tagged Zidovudine→parent ×1, Zidovudine→Lamivudine ×1, Zidovudine→Zidovudine triphosphate ×1, Zidovudine→Lamivudine triphosphate ×1</li><li>molar mass: none of 2 PubChem candidate(s) is 'Lamivudine triphosphate' (LLM) — left in mass units</li><li>molar mass: none found for 'Lamivudine triphosphate' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Ishida_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Zidovudine_Bazzoli2011_reference;
