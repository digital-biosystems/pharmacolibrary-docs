function p = Zidovudine_Velasque2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zidovudine   source: Velasque_2007 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Zidovudine_Velasque2007_reference_params';
  p.drug  = 'zidovudine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 183.424247;                % central volume [L]
  p.CL = 97.8;                % clearance [L/h]
  p.Vp = [9.82];             % peripheral volumes [L]
  p.Q  = [40.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
