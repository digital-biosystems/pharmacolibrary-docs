model Zidovudine_Velasque2007_reference
  parameter Real Cl_ref = 2.7166666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.18342424749862282 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.267245,
    adminMass = 0.0006,
    k12 = 6.193898171067274e-05,
    k21 = 0.00115693595836162
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zidovudine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Velasque_2007</td></tr><tr><td>measured_compound:</td><td>zidovudine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zidovudine 267.245 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Velasque_2007) — secondary source</li><li>central volume derived from CL·t½/ln2</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zidovudine_Velasque2007_reference;
