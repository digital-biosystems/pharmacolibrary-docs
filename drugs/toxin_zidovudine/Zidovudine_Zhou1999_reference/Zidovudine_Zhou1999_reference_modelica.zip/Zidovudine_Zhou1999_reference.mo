model Zidovudine_Zhou1999_reference
  parameter Real Cl_ref = 1.4805555555555555e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0819 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.267245,
    adminMass = 0.0006
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zidovudine</td></tr><tr><td>population:</td><td>human immunodeficiency virus-infected patients</td></tr><tr><td>source_paper:</td><td>Zhou_1999</td></tr><tr><td>measured_compound:</td><td>Zidovudine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zidovudine 267.245 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'liters/h/kg of body weight' (CL)</li><li>dropped duplicate Q22 ('Individual mean oral CL', value 1.84) — already have one for this compound</li><li>dropped duplicate Q61 ('V', value 2.67) — already have one for this compound</li><li>dropped value-less row: 'body weight'</li><li>dropped value-less row: 'age'</li><li>dropped duplicate Q22 ('average individual oral CL', value 1.64) — already have one for this compound</li><li>dropped duplicate Q65 ('VSS', value 3.56) — already have one for this compound</li><li>implicit units: 'Individual oral clearance (CL)' → L/h (from the popPK convention: 'No unit is stated in the provided text or captions. The magnitude 0.0533 is consistent with clearance values typically e')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zidovudine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Zidovudine_Zhou1999_reference;
