model Zidovudine_Fauchet2013_reference
  parameter Real Cl_ref = 2.4916666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.267245,
    adminMass = 0.0006,
    ka = 0.0007944444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zidovudine</td></tr><tr><td>population:</td><td>HIV-1-infected children</td></tr><tr><td>source_paper:</td><td>Fauchet_2013</td></tr><tr><td>measured_compound:</td><td>Zidovudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Zidovudine 267.245 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'between-subject variability' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Zidovudine</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 5 linked by role; re-tagged Zidovudine→parent ×3, Zidovudine→3*-azido-3*-deoxy-5*-glucuronylthymidine ×2</li><li>molar mass: no plausible PubChem entry for '3*-azido-3*-deoxy-5*-glucuronylthymidine' (&quot;3'-azido-3'-deoxy-5'-glucuronylthymidine&quot;) — left in mass units</li><li>molar mass: none found for '3*-azido-3*-deoxy-5*-glucuronylthymidine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zidovudine_Fauchet2013_reference;
