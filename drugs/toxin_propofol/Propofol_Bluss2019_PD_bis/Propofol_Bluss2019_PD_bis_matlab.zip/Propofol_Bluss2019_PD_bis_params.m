function p = Propofol_Bluss2019_PD_bis_params()
% Propofol_Bluss2019_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Blussé_2019::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: propofol (pk_record).
p.E0 = 100.0;
p.Emax = -100.0;
p.EC50 = 0.0035099999999999992;
p.gamma = 1.43;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
