function p = Propofol_GarrazaObaldia2024_PD_map_params()
% Propofol_GarrazaObaldia2024_PD_map_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Garraza-Obaldia_2024::MAP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg∙mL−1 per second, in SI inside (kg/m3, s). Response MAP in mmHg. Driver: propofol (cited_pk).
p.E0 = 88.2;
p.Emax = 0.88;
p.EC50 = 0.008789999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 88.0;
p.form = 'E0*(1 - Emax*frac)';
end
