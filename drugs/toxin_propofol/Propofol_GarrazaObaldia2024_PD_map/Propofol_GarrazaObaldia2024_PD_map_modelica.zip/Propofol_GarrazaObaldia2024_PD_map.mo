model Propofol_GarrazaObaldia2024_PD_map
  "indirect_response_i exposure-response sweep — Garraza-Obaldia_2024 :: MAP (mean arterial pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 88.2,      // [mmHg]
    Emax = 0.88,  // type I effect term
    EC50 = 0.00879,  // [kg/m3; µg∙mL−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg∙mL−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 88, Interval = 0.176),
    Documentation(info = "<html><body><h4>Propofol_GarrazaObaldia2024_PD_map</h4><p>The steady-state exposure-response curve of Garraza-Obaldia M et al., <i>Pharmaceutics 16(12):1615</i> 2024 (<a href=\"https://doi.org/10.3390/pharmaceutics16121615\">doi:10.3390/pharmaceutics16121615</a>) — mean arterial pressure [mmHg] against propofol µg∙mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       88.2 mmHg     drug-free response (baseline) (MAP0, Q324)
  Emax  =       0.88          maximal effect term (EmaxPropo, Q323)
  EC50  =       8.79 µg∙mL−1  exposure at half of the maximal effect term (C50Propo, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one µg∙mL−1 of propofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 88.2   (drug-free)
  exposure = EC50 (8.79 µg∙mL−1)  response 49.39
  exposure -> infinity  response 10.58</pre></body></html>"));
end Propofol_GarrazaObaldia2024_PD_map;
