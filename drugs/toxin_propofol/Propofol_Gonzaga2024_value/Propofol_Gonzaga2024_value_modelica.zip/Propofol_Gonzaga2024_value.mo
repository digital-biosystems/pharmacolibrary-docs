model Propofol_Gonzaga2024_value
  parameter Real Cl_ref = 1.888888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0317 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17827500000000002,
    adminMass = 0.00035
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>canines (healthy and with hepatic impairment)</td></tr><tr><td>source_paper:</td><td>Gonzaga_2024</td></tr><tr><td>measured_compound:</td><td>Propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-17-01720-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propofol 178.275 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'pKa (acid)' — extend the ontology if this is a real PK parameter (source ['pharmaceuticals-17-01720-t003:row3:col1'])</li><li>dropped unlinked row (NIL): 'logP' — extend the ontology if this is a real PK parameter (source ['pharmaceuticals-17-01720-t003:row4:col1'])</li><li>dropped unlinked row (NIL): 'SolpH' — extend the ontology if this is a real PK parameter (source ['pharmaceuticals-17-01720-t003:row5:col1'])</li><li>dropped unlinked row (NIL): 'B:P ratio' — extend the ontology if this is a real PK parameter (source ['pharmaceuticals-17-01720-t003:row7:col1'])</li><li>'fu' → Q46: printed without a unit and above 1 — read as a percentage</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propofol</li><li>population split: 'value' subgroup of Gonzaga_2024 (paper reports 2 populations: literature values, value)</li><li>gap-filled Q22 (CL) from Bertin_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Blussé_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Li_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bertin_2026, Blussé_2019, Li_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propofol_Gonzaga2024_value;
