// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Propofol_Dutta1998_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {102.0},
    MM = 0.17827500000000002,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Dutta_1998</td></tr><tr><td>measured_compound:</td><td>Propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>propofol 178.275 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'expected value of at least 8 min' — extend the ontology if this is a real PK parameter (source ['Dutta_1998:abstract'])</li><li>dropped duplicate Q410 ('Brain:plasma partition coefficient', value 8.2) — already have one for this compound</li><li>dropped duplicate Q410 ('brain:blood partition coefficient', value 3.0) — already have one for this compound</li><li>dropped duplicate Q57 ('T1/2', value '2.3') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propofol</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Bertin_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Blussé_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Li_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Propofol_Dutta1998_reference;
