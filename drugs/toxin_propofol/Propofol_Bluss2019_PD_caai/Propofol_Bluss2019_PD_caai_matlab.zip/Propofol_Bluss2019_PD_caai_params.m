function p = Propofol_Bluss2019_PD_caai_params()
% Propofol_Bluss2019_PD_caai_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Blussé_2019::cAAI: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response cAAI in its own unit. Driver: propofol (pk_record).
p.E0 = 63.4;
p.Emax = -49.8;
p.EC50 = 0.0021399999999999995;
p.gamma = 6.85;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 22.0;
p.form = 'E0 + Emax*frac';
end
