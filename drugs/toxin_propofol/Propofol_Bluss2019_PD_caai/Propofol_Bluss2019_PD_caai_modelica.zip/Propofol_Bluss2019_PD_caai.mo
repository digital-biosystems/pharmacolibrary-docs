model Propofol_Bluss2019_PD_caai
  "sigmoid_emax exposure-response sweep — Blussé_2019 :: cAAI (composite A-line ARX index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 63.4,      // [1]
    Emax = -49.8,  // [1]
    EC50 = 0.00214,  // [kg/m3; mg/l × 0.001]
    gamma = 6.85,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 22, Interval = 0.044),
    Documentation(info = "<html><body><h4>Propofol_Bluss2019_PD_caai</h4><p>The steady-state exposure-response curve of Blussé van Oud-Alblas HJ et al., <i>BMC anesthesiology 19(1):15</i> 2019 (<a href=\"https://doi.org/10.1186/s12871-019-0684-z\">doi:10.1186/s12871-019-0684-z</a>) — composite A-line ARX index against propofol mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       63.4          drug-free response (baseline) (E0, Q324)
  Emax  =       49.8          maximal effect term (Emax, Q323)
  EC50  =       2.14 mg/l     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       6.85          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of propofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 63.4   (drug-free)
  exposure = EC50 (2.14 mg/l)  response 38.5
  exposure -> infinity  response 13.6</pre></body></html>"));
end Propofol_Bluss2019_PD_caai;
