function p = Propofol_Su2022_PD_tpr_params()
% Propofol_Su2022_PD_tpr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Su_2022::TPR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg ml-1 per second, in SI inside (kg/m3, s). Response TPR in its own unit. Driver: propofol (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.0029599999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 30.0;
p.form = 'E0*(1 - Emax*frac)';
end
