function p = Propofol_Bluss2019_bs_pk_model_mean_cv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propofol   source: Blussé_2019 / bs_pk_model_mean_cv   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Propofol_Bluss2019_bs_pk_model_mean_cv_params';
  p.drug  = 'propofol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.45;                % central volume [L]
  p.CL = 82.8;                % clearance [L/h]
  p.Vp = [77.3];             % peripheral volumes [L]
  p.Q  = [69.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.003806;             % absorption lag [h]
  p.dose = 280.0;             % dose [mg]
end
