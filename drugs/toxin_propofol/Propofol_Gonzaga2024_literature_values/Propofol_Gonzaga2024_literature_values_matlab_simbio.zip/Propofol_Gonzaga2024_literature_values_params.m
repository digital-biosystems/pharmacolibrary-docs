function p = Propofol_Gonzaga2024_literature_values_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propofol   source: Gonzaga_2024 / literature_values   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Propofol_Gonzaga2024_literature_values_params';
  p.drug  = 'propofol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 31.7;                % central volume [L]
  p.CL = 68.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.003806;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
