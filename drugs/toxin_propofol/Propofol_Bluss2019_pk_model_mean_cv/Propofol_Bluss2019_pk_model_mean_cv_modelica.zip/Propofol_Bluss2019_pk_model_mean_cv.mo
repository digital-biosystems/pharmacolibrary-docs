model Propofol_Bluss2019_pk_model_mean_cv
  parameter Real Cl_ref = 2.2833333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0036000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17827500000000002,
    adminMass = 0.00028,
    k12 = 0.005324074074074074,
    k21 = 0.00024956597222222226
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>adolescents undergoing idiopathic scoliosis surgery</td></tr><tr><td>source_paper:</td><td>Blussé_2019</td></tr><tr><td>measured_compound:</td><td>Propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propofol 178.275 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 of CL in %' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'σ2' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propofol</li><li>population split: 'pk model / mean (cv%)' subgroup of Blussé_2019 (paper reports 2 populations: bs pk model / mean (cv%), pk model / mean (cv%))</li><li>gap-filled Q83 (tlag) from Li_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propofol_Bluss2019_pk_model_mean_cv;
