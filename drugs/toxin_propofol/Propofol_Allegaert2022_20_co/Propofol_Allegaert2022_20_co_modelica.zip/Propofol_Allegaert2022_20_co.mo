model Propofol_Allegaert2022_20_co
  parameter Real Cl_ref = 1.888888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0317 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17827500000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>virtual adults and pediatric population groups</td></tr><tr><td>source_paper:</td><td>Allegaert_2022</td></tr><tr><td>measured_compound:</td><td>Propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propofol 178.275 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Allegaert_2022_table_1: rows are variants (Normal CO, 20% ↓CO, 30% ↓CO, 40% ↓CO, 50% ↓CO), the parameters are the column headers (Relative (%)) — read one record per variant</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propofol</li><li>estimate-method split: '20% ↓CO' is one of 4 estimates of Allegaert_2022's substance matrix (20% ↓CO, 30% ↓CO, 40% ↓CO, 50% ↓CO); same population, different estimation method</li><li>gap-filled Q22 (CL) from Bertin_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Blussé_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Li_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bertin_2026, Blussé_2019, Li_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propofol_Allegaert2022_20_co;
