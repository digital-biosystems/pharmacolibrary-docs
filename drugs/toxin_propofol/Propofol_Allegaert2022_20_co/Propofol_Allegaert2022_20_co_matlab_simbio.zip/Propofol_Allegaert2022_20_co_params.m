function p = Propofol_Allegaert2022_20_co_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propofol   source: Allegaert_2022 / 20_co   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Propofol_Allegaert2022_20_co_params';
  p.drug  = 'propofol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 31.7;                % central volume [L]
  p.CL = 68.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.003806;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
