function p = Propofol_Kawata2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propofol   source: Kawata_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Propofol_Kawata2024_reference_params';
  p.drug  = 'propofol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15.96;                % central volume [L]
  p.CL = 106.8;                % clearance [L/h]
  p.Vp = [123.0];             % peripheral volumes [L]
  p.Q  = [48.36];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.003806;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
