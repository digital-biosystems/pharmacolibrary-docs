model Propofol_Kawata2024_reference
  parameter Real Cl_ref = 2.966666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.015960000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17827500000000002,
    adminMass = 1e-05,
    k12 = 0.000841687552213868,
    k21 = 0.00010921409214092141
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>patients with brain tumors or brain lesions undergoing awake craniotomy</td></tr><tr><td>source_paper:</td><td>Kawata_2024</td></tr><tr><td>measured_compound:</td><td>Propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propofol 178.275 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'k10 (min−1)'; source reconciliation required</li><li>table representations disagree for 'k12 (min−1)'; source reconciliation required</li><li>table representations disagree for 'k13 (min−1)'; source reconciliation required</li><li>table representations disagree for 'k21 (min−1)'; source reconciliation required</li><li>table representations disagree for 'k31 (min−1)'; source reconciliation required</li><li>table representations disagree for 'V1 (L kg−1)'; source reconciliation required</li><li>table representations disagree for 'k1e (min−1)'; source reconciliation required</li><li>table representations disagree for 'Kp'; source reconciliation required</li><li>dropped duplicate Q63 ('V1 (L)', value '41.1') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propofol</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q83 (tlag) from Li_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propofol_Kawata2024_reference;
