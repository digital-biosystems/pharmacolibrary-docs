model Propofol_Su2022_PD_sv
  "indirect_response_i exposure-response sweep — Su_2022 :: SV (stroke volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00034,  // [kg/m3; μg ml-1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg ml-1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.4, Interval = 0.0068),
    Documentation(info = "<html><body><h4>Propofol_Su2022_PD_sv</h4><p>The steady-state exposure-response curve of Su H et al., <i>British journal of anaesthesia 128(5):806–816</i> 2022 (<a href=\"https://doi.org/10.1016/j.bja.2022.01.022\">doi:10.1016/j.bja.2022.01.022</a>) — stroke volume against propofol μg ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       0.34 μg ml-1  exposure at half of the maximal effect term (EC50 for propofol-induced changes in SV, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg ml-1 of propofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.34 μg ml-1)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Propofol_Su2022_PD_sv;
