model Ondansetron_Chiang2021_estimate
  parameter Real Cl_ref = 6.833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0633 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.000925925925925926,
    k21 = 0.0005426954732510288
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ondansetron</td></tr><tr><td>population:</td><td>adults undergoing elective hip or knee arthroplasty</td></tr><tr><td>source_paper:</td><td>Chiang_2021</td></tr><tr><td>measured_compound:</td><td>ondansetron</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 4</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'B for (VC, AGE)' — extend the ontology if this is a real PK parameter (source ['Chiang_2021_table_4:row6:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ondansetron</li><li>population split: 'estimate' subgroup of Chiang_2021 (paper reports 2 populations: estimate, shrinkage (%))</li><li>gap-filled Q64 (V2) from Lee_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ondansetron_Chiang2021_estimate;
