function p = Ondansetron_Chiang2021_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ondansetron   source: Chiang_2021 / estimate   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Ondansetron_Chiang2021_estimate_params';
  p.drug  = 'ondansetron';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 63.3;                % central volume [L]
  p.CL = 24.6;                % clearance [L/h]
  p.Vp = [108.0];             % peripheral volumes [L]
  p.Q  = [211.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
