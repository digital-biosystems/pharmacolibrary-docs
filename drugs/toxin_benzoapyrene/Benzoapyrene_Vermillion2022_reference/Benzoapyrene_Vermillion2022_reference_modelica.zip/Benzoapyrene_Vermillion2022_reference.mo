model Benzoapyrene_Vermillion2022_reference
  parameter Real Cl_ref = 6.210996241576571e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.015 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.252316,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>benzoapyrene</td></tr><tr><td>population:</td><td>human volunteers</td></tr><tr><td>source_paper:</td><td>Vermillion_2022</td></tr><tr><td>measured_compound:</td><td>Benzo[a]pyrene</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Benzo[a]pyrene 252.316 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q76 ('Mean non-compartmental apparent volume of distributions'=15) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('average half-life across doses'=46.5) from results prose — parameter table was unreadable</li><li>implicit units: 'Mean non-compartmental apparent volume of distributions' → L (from the paper text: &quot;The text states: 'The concentration of the central compartment (C1) was calculated by normalizing the amount with the ap&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Benzo[a]pyrene</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_3C — first-pass formation; parent 1 + hepatic, metabolites [0] (site presystemic: 'The extensive metabolism of [14C]-BaP, as reflected in the time course of plasma levels, is presumably a consequence of ')</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'Benzo[a]pyrene metabolites' ('benzo[a]pyrene metabolites') — left in mass units</li><li>molar mass: none found for 'Benzo[a]pyrene metabolites' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL/F=0.223596 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Benzoapyrene_Vermillion2022_reference;
