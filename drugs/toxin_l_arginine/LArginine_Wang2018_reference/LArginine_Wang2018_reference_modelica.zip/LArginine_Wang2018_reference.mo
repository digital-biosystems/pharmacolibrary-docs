model LArginine_Wang2018_reference
  parameter Real Cl_ref = 8.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.023100000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_arginine</td></tr><tr><td>population:</td><td>healthy Chinese volunteers</td></tr><tr><td>source_paper:</td><td>Wang_2018</td></tr><tr><td>measured_compound:</td><td>L-Arginine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>l_arginine 174.204 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'dose'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=L-Arginine</li><li>molar mass: none of 2 PubChem candidate(s) is 'L-Arginine' (LLM) — left in mass units</li><li>molar mass: none found for 'L-Arginine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Brussee_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end LArginine_Wang2018_reference;
