model LArginine_Yeo2013_severemalaria
  parameter Real Cl_ref = 1.7166666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17521199999999998,
    adminMass = 0.012,
    k12 = 5.169082125603864e-05,
    k21 = 8.384265789061274e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_arginine</td></tr><tr><td>population:</td><td>adults with severe malaria</td></tr><tr><td>source_paper:</td><td>Yeo_2013</td></tr><tr><td>measured_compound:</td><td>L-Arginine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone-0069587-t003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>L-Arginine 175.212 g/mol (pubchem); l_arginine 174.204 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ (proportional)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Base' — extend the ontology if this is a real PK parameter (source ['pone-0069587-t003:row7:col2'])</li><li>dropped unlinked row (NIL): 'Gradient 1' — extend the ontology if this is a real PK parameter (source ['pone-0069587-t003:row8:col2'])</li><li>dropped unlinked row (NIL): 'Gradient 2' — extend the ontology if this is a real PK parameter (source ['pone-0069587-t003:row9:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=L-Arginine</li><li>population split: 'severemalaria' subgroup of Yeo_2013 (paper reports 2 populations: moderately severemalaria (ref [15]), severemalaria)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end LArginine_Yeo2013_severemalaria;
