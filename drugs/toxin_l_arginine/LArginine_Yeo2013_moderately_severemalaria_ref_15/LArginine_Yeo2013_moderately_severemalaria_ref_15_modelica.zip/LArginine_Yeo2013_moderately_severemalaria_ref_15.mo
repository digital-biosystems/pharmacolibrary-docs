model LArginine_Yeo2013_moderately_severemalaria_ref_15
  parameter Real Cl_ref = 8.611111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.012,
    k12 = 0.0007613168724279835,
    k21 = 0.0009788359788359788
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_arginine</td></tr><tr><td>population:</td><td>adults with severe malaria</td></tr><tr><td>source_paper:</td><td>Yeo_2013</td></tr><tr><td>measured_compound:</td><td>L-Arginine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone-0069587-t003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>l_arginine 174.204 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ (proportional)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Base' — extend the ontology if this is a real PK parameter (source ['pone-0069587-t003:row7:col1'])</li><li>dropped unlinked row (NIL): 'Gradient 1' — extend the ontology if this is a real PK parameter (source ['pone-0069587-t003:row8:col1'])</li><li>dropped unlinked row (NIL): 'Gradient 2' — extend the ontology if this is a real PK parameter (source ['pone-0069587-t003:row9:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=L-Arginine</li><li>population split: 'moderately severemalaria (ref [15])' subgroup of Yeo_2013 (paper reports 2 populations: moderately severemalaria (ref [15]), severemalaria)</li><li>molar mass: none of 2 PubChem candidate(s) is 'L-Arginine' (LLM) — left in mass units</li><li>molar mass: none found for 'L-Arginine' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end LArginine_Yeo2013_moderately_severemalaria_ref_15;
