function p = LArginine_Brussee2016_PD_no_params()
% LArginine_Brussee2016_PD_no_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% l_arginine Brussee_2016::NO: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response NO in ppb. Driver: L-arginine (cited_pk).
p.E0 = 18.2;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0243;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
