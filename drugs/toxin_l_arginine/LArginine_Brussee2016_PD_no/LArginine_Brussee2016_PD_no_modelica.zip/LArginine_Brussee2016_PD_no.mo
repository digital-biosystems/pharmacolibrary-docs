model LArginine_Brussee2016_PD_no
  "linear exposure-response sweep — Brussee_2016 :: NO (nitric oxide)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 18.2,      // [ppb]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.0243   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>LArginine_Brussee2016_PD_no</h4><p>The steady-state exposure-response curve of Brussee JM et al., <i>Antimicrobial agents and chemotherapy 60(1):198-205</i> 2016 (<a href=\"https://doi.org/10.1128/aac.01479-15\">doi:10.1128/aac.01479-15</a>) — nitric oxide [ppb] against L-arginine mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       18.2 ppb      drug-free response (baseline) (BL NO, Q324)
  slope =     0.0243          change in response per unit of exposure (SL NO, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/liter of L-arginine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 18.2   (drug-free)</pre></body></html>"));
end LArginine_Brussee2016_PD_no;
