function p = Alogliptin_Dudkowski2017_final_parameter_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alogliptin   source: Dudkowski_2017 / final_parameter_estimate   route: oral
  p.name  = 'Alogliptin_Dudkowski2017_final_parameter_estimate_params';
  p.drug  = 'alogliptin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 125.0;                % central volume [L]
  p.CL = 14.4;                % clearance [L/h]
  p.Vp = [117.0];             % peripheral volumes [L]
  p.Q  = [11.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.59;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.5;             % dose [mg]
end
