model Alogliptin_Dudkowski2017_final_parameter_estimate
  parameter Real Cl_ref = 4.000000000000001e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.125 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33939159999999996,
    adminMass = 1.25e-05,
    ka = 0.00016388888888888887,
    Tlag = 0.0,
    k12 = 2.6000000000000002e-05,
    k21 = 2.777777777777778e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alogliptin</h4><p>Alogliptin is a DPP-4 inhibitor used to lower blood glucose in adults with type 2 diabetes. It is authorised in the European Union and used as an oral anti-diabetic medicine, including in fixed-dose combinations with other glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4734170\">Wikidata Q4734170</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alogliptin</td></tr><tr><td>population:</td><td>children, adolescents, and adults with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Dudkowski_2017</td></tr><tr><td>measured_compound:</td><td>alogliptin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>alogliptin 339.392 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Baseline response [E0] (%)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dudkowski_2017_table_S1:row6:col1'])</li><li>dropped PD-category row 'Maximal response [Emax] (%)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dudkowski_2017_table_S1:row7:col1'])</li><li>dropped PD-category row 'Concentration at half-maximal response [EC50] in pediatric subjects (ng/mL)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dudkowski_2017_table_S1:row8:col1', 'Dudkowski_2017_table_S1:row8:col4'])</li><li>dropped PD-category row 'Shape factor [γ]' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dudkowski_2017_table_S1:row9:col1'])</li><li>dropped PD-category row 'Concentration at half-maximal response [EC50] in adult subjects (ng/mL)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dudkowski_2017_table_S1:row10:col1', 'Dudkowski_2017_table_S1:row10:col4'])</li><li>dropped duplicate Q27 ('Oral clearance [CL/F] in adult subjects (L/hr)', value '13.0') — already have one for this compound</li><li>dropped duplicate Q49 ('Absorption rate constant [KA] in adult subjects (1/hr)', value '1.66') — already have one for this compound</li><li>implicit units: 'Absorption rate constant [KA] in pediatric subjects (1/hr)' → 1/h (from the popPK convention: &quot;The paper text mentions 'absorption rate constant' as a covariate but does not explicitly state its unit in the provided&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=alogliptin</li><li>population split: 'final parameter estimate' subgroup of Dudkowski_2017 (paper reports 5 populations: 14 to <18 years, adults, alo 12.5 mg, alo 25 mg, final parameter estimate)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Alogliptin_Dudkowski2017_final_parameter_estimate;
