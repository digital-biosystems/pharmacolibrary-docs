// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Hexabromocyclododecane_Letcher2015_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {272217801819905.78},
    MM = 0.6417,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hexabromocyclododecane</td></tr><tr><td>population:</td><td>captive American kestrels (Falco sparverius)</td></tr><tr><td>source_paper:</td><td>Letcher_2015</td></tr><tr><td>measured_compound:</td><td>Hexabromocyclododecane (sum and isomers)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Hexabromocyclododecane (sum and isomers) 641.7 g/mol (pubchem); hexabromocyclododecane 641.7 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'n' — extend the ontology if this is a real PK parameter (source ['Letcher_2015:abstract', 'Letcher_2015:abstract'])</li><li>dropped unlinked row (NIL): 'exposure duration' — extend the ontology if this is a real PK parameter (source ['Letcher_2015:abstract'])</li><li>dropped unlinked row (NIL): 'HBCDD-TM concentration' — extend the ontology if this is a real PK parameter (source ['Letcher_2015:abstract'])</li><li>dropped unlinked row (NIL): 'depuration period' — extend the ontology if this is a real PK parameter (source ['Letcher_2015:abstract'])</li><li>relinked 'mean ΣHBCDD depletion rate in plasma' Q100 → Q47: a rate constant in 'ng/g/d' (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'α-HBCDD fraction' — extend the ontology if this is a real PK parameter (source ['Letcher_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hexabromocyclododecane (sum and isomers)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Hexabromocyclododecane_Letcher2015_reference;
