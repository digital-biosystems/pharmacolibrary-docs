% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = CadmiumChloride_Houpert1997_ewe_7_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
