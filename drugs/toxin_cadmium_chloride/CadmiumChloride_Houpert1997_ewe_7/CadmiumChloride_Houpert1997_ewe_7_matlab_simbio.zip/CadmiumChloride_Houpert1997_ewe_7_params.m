function p = CadmiumChloride_Houpert1997_ewe_7_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cadmium_chloride   source: Houpert_1997 / ewe_7   route: iv_bolus
  p.name  = 'CadmiumChloride_Houpert1997_ewe_7_params';
  p.drug  = 'cadmium_chloride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.1;                % central volume [L]
  p.CL = 1.020833;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.05;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
