model CadmiumChloride_Houpert1997_ewe_7
  parameter Real Cl_ref = 2.835648148148148e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0021 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cadmium_chloride</td></tr><tr><td>population:</td><td>lactating and nonlactating ewes</td></tr><tr><td>source_paper:</td><td>Houpert_1997</td></tr><tr><td>measured_compound:</td><td>Cadmium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cadmium_chloride 183.31 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'k13/k31' — extend the ontology if this is a real PK parameter (source ['Houpert_1997_table_2:row1:col3'])</li><li>dropped duplicate Q53 ('MRTc (days)', value '0.08') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cadmium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc (liter/kg)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>population split: 'ewe 7' subgroup of Houpert_1997 (paper reports 3 populations: ewe 7, lactating (n = 6), nonlactating (n = 4))</li><li>molar mass: none of 2 PubChem candidate(s) is 'Cadmium' (LLM) — left in mass units</li><li>molar mass: none found for 'Cadmium' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Cadmium', not cadmium_chloride — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CadmiumChloride_Houpert1997_ewe_7;
