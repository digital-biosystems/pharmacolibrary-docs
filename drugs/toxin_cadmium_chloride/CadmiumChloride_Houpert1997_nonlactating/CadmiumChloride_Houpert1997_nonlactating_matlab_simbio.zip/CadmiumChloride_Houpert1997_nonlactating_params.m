function p = CadmiumChloride_Houpert1997_nonlactating_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cadmium_chloride   source: Houpert_1997 / nonlactating   route: iv_bolus
  p.name  = 'CadmiumChloride_Houpert1997_nonlactating_params';
  p.drug  = 'cadmium_chloride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.68;                % central volume [L]
  p.CL = 0.583333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.18;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
