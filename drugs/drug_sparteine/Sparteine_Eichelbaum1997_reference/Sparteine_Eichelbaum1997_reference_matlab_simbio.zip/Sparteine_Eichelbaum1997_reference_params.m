function p = Sparteine_Eichelbaum1997_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sparteine   source: Eichelbaum_1997 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Sparteine_Eichelbaum1997_reference_params';
  p.drug  = 'sparteine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.433462;                % central volume [L]
  p.CL = 0.432;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
