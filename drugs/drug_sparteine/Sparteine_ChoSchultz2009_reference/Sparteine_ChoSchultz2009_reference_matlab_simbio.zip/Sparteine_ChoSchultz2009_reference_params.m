function p = Sparteine_ChoSchultz2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sparteine   source: Cho-Schultz_2009 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Sparteine_ChoSchultz2009_reference_params';
  p.drug  = 'sparteine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 19.773578;                % central volume [L]
  p.CL = 37.38;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
