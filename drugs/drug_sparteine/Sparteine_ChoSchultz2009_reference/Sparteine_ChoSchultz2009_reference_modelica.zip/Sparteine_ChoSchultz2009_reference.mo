model Sparteine_ChoSchultz2009_reference
  parameter Real Cl_ref = 1.0383333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01977357823042413 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.234387,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sparteine</h4><p>Sparteine is an alkaloid that was used as a class Ia antiarrhythmic to treat heart rhythm disorders, and also as an oxytocic agent. It has been withdrawn and is no longer in clinical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419552\">Wikidata Q419552</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sparteine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cho-Schultz_2009</td></tr><tr><td>measured_compound:</td><td>sparteine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sparteine 234.387 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cho-Schultz_2009) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sparteine_ChoSchultz2009_reference;
