function p = Temozolomide_Panetta2003_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: temozolomide   source: Panetta_2003 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Temozolomide_Panetta2003_reference_params';
  p.drug  = 'temozolomide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.0;                % central volume [L]
  p.CL = 5.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
