// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model HydrogenCyanide_Breen2019_value
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1266.6648984851793},
    MM = 0.058078000000000005,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydrogen_cyanide</td></tr><tr><td>population:</td><td>Marine fish Amphiprion ocellaris</td></tr><tr><td>source_paper:</td><td>Breen_2019</td></tr><tr><td>measured_compound:</td><td>Thiocyanate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table-1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): coefficients in ppm normalised to their sum — the pools describe the measured curve's shape, C(t)/C(0), not a share of the intake</td></tr><tr><td>molar_masses:</td><td>Hydrogen cyanide 27.026 g/mol (pubchem); Thiocyanate 58.078 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Y0 (ppm)' — extend the ontology if this is a real PK parameter (source ['Breen_2019_table_2:row1:col1'])</li><li>dropped duplicate Q900 ('r2', value '0.84') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Thiocyanate</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'value' subgroup of Breen_2019 (paper reports 3 populations: 20-s exposure, 45-s exposure, value)</li><li>row roles (LLM): model_class=noncompartmental; 9/9 row label(s) assigned, 0 linked by role</li><li>review gap-fill skipped: this record measures 'Thiocyanate', not hydrogen_cyanide — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end HydrogenCyanide_Breen2019_value;
