// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Clobazam_Mensah2024_double_clb_vpa
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5508.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clobazam</td></tr><tr><td>population:</td><td>Scn1aWT/WT mice</td></tr><tr><td>source_paper:</td><td>Mensah_2024</td></tr><tr><td>measured_compound:</td><td>Clobazam (with N-desmethylclobazam metabolite)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>clobazam 300.742 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'Brain AUC (μg*hr/g)' → Q88 (unit '[time]' vs ontology '[mass] * [time] / [length] ** 3') — route to review</li><li>dropped duplicate Q88 ('Brain AUC (μg*hr/g)', value '0.637') — already have one for this compound</li><li>unit_dimension_mismatch: 'Brain Cmax (μg/g)' → Q32 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q32 ('Brain Cmax (μg/g)', value '0.76') — already have one for this compound</li><li>dropped duplicate Q57 ('Brain t1/2 (hr)', value '0.904') — already have one for this compound</li><li>dropped value-less row: 'AUC'</li><li>dropped value-less row: 'CLB'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'CBD'</li><li>dropped value-less row: 'n/a'</li><li>dropped value-less row: 'N-CLB'</li><li>dropped value-less row: 'PK'</li><li>dropped value-less row: '7-OH-CBD'</li><li>dropped value-less row: 'STP'</li><li>dropped value-less row: 't1/2'</li><li>dropped value-less row: 'VPA'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Clobazam_Mensah2024_double_clb_vpa;
