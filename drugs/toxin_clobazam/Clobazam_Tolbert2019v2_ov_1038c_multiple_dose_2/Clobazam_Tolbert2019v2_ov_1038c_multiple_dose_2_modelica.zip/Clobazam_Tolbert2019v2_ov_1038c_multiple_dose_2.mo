model Clobazam_Tolbert2019v2_ov_1038c_multiple_dose_2
  parameter Real Cl_ref = 5.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clobazam</td></tr><tr><td>population:</td><td>healthy subjects and patients with Lennox-Gastaut syndrome or epilepsy</td></tr><tr><td>source_paper:</td><td>Tolbert_2019_2</td></tr><tr><td>measured_compound:</td><td>Clobazam (with N-desmethylclobazam)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1313-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Clobazam 300.742 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CYP2C19'</li><li>dropped value-less row: 'EM'</li><li>dropped value-less row: 'IM'</li><li>dropped value-less row: 'PM'</li><li>dropped value-less row: 'LGS'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Clobazam (with N-desmethylclobazam)</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'ov‐1038c (multiple dose‐2)' subgroup of Tolbert_2019_2 (paper reports 10 populations: auc0‐inf, mean (% cv), ng•h/ml, cl/f, mean (% cv), l/hr, cmax, mean (% cv), ng/ml, ov‐101611 (bioequivalence), ov‐101732 (relative ba), ov‐101839, 41 (food effect), ov‐102234 (multiple dose‐1), ov‐1038c (multiple dose‐2), t½, mean (% cv), h, vd/f, mean (% cv), l)</li><li>row roles (LLM): model_class=noncompartmental; 0/17 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'N-desmethylclobazam' — its concentrations stay mass-only</li><li>molar mass: none found for 'Clobazam (with N-desmethylclobazam)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q19 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Clobazam_Tolbert2019v2_ov_1038c_multiple_dose_2;
