model Clobazam_Tolbert2019v2_cmax_mean_cv_ng_ml
  parameter Real Cl_ref = 5.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clobazam</td></tr><tr><td>population:</td><td>healthy subjects and patients with Lennox-Gastaut syndrome or epilepsy</td></tr><tr><td>source_paper:</td><td>Tolbert_2019_2</td></tr><tr><td>measured_compound:</td><td>Clobazam (with N-desmethylclobazam)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1313-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Clobazam 300.742 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'cmax, mean (% cv), ng/ml' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'cmax, mean (% cv), ng/ml' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>dropped unlinked row (NIL): 'OV‐102363 (effect of CLB on CYP probe substrates)' — extend the ontology if this is a real PK parameter (source ['Tolbert_2019_2_table_2:row8:col3'])</li><li>dropped value-less row: 'CYP2C19'</li><li>dropped value-less row: 'EM'</li><li>dropped value-less row: 'IM'</li><li>dropped value-less row: 'PM'</li><li>dropped value-less row: 'LGS'</li><li>covariate effect for Q31 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Clobazam (with N-desmethylclobazam)</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>pharmacogenetic covariate 'theta_q31_cyp2c19' (cyp2c19) — PGx domain</li><li>population split: 'cmax, mean (% cv), ng/ml' subgroup of Tolbert_2019_2 (paper reports 10 populations: auc0‐inf, mean (% cv), ng•h/ml, cl/f, mean (% cv), l/hr, cmax, mean (% cv), ng/ml, ov‐101611 (bioequivalence), ov‐101732 (relative ba), ov‐101839, 41 (food effect), ov‐102234 (multiple dose‐1), ov‐1038c (multiple dose‐2), t½, mean (% cv), h, vd/f, mean (% cv), l)</li><li>row roles (LLM): model_class=noncompartmental; 0/17 row label(s) assigned, 0 linked by role</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Clobazam_Tolbert2019v2_cmax_mean_cv_ng_ml;
