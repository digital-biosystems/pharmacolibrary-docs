% Run (SimBiology): build model + dose, simulate 0..312.0 h, plot.
p = Clobazam_Tolbert2019v2_cmax_mean_cv_ng_ml_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 312.0);
