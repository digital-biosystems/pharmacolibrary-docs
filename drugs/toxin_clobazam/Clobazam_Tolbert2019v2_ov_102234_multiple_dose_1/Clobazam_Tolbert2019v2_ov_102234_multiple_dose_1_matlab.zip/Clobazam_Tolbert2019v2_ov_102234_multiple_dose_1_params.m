function p = Clobazam_Tolbert2019v2_ov_102234_multiple_dose_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clobazam   source: Tolbert_2019_2 / ov_102234_multiple_dose_1   route: oral
  % estimated (absent from source): ka
  p.name  = 'Clobazam_Tolbert2019v2_ov_102234_multiple_dose_1_params';
  p.drug  = 'clobazam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 100.0;                % central volume [L]
  p.CL = 1.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
