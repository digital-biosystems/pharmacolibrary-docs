% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Clobazam_Tolbert2019v2_ov_101611_bioequivalence_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
