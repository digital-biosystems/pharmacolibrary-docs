model Oseltamivir_Lin2012_reference
  parameter Real Cl_ref = 0.0001866666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 1.89 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3124045,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oseltamivir</h4><p>Oseltamivir is an antiviral medicine used to treat and help prevent influenza, including severe cases. It is authorised in the European Union and is on the WHO list of essential medicines, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q211509\">Wikidata Q211509</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oseltamivir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Lin_2012</td></tr><tr><td>measured_compound:</td><td>oseltamivir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oseltamivir 312.404 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Lin_2012) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oseltamivir_Lin2012_reference;
