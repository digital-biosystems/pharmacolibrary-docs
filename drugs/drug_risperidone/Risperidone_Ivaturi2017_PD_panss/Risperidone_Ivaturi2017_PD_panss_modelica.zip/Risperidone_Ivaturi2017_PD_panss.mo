model Risperidone_Ivaturi2017_PD_panss
  "emax exposure-response sweep — Ivaturi_2017 :: PANSS (PANSS total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 94.9,      // [1]
    Emax = -0.054,  // [1]
    EC50 = 4.6e-06,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><!-- drug-about --><h4>About risperidone</h4><p>Risperidone is an atypical antipsychotic used to treat conditions such as schizophrenia, bipolar disorder, and autism spectrum disorder. It is taken by mouth, which is well-absorbed, or by subcutaneous and intramuscular injection for long-acting treatment. It is widely used, is listed as an essential medicine, and is authorised in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412443\">Wikidata Q412443</a>, <a href=\"https://en.wikipedia.org/wiki/Risperidone?oldid=1386085543\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Risperidone_Ivaturi2017_PD_panss</h4><p>The steady-state exposure-response curve of Ivaturi V et al., <i>British journal of clinical pharmacology 83(7):1476–1498</i> 2017 (<a href=\"https://doi.org/10.1111/bcp.13246\">doi:10.1111/bcp.13246</a>) — PANSS total score against total active moiety ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       94.9          drug-free response (baseline) (BSL, Q324)
  Emax  =      0.054          maximal effect term (Emax, Q323)
  EC50  =        4.6 ng ml-1  exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of total active moiety per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 94.9   (drug-free)
  exposure = EC50 (4.6 ng ml-1)  response 94.87
  exposure -> infinity  response 94.85</pre></body></html>"));
end Risperidone_Ivaturi2017_PD_panss;
