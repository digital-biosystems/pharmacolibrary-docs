// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Mandelonitrile_Dirikolu2003_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.1547},
    CLelim = {3.538888888888889e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mandelonitrile</td></tr><tr><td>population:</td><td>four horses</td></tr><tr><td>source_paper:</td><td>Dirikolu_2003</td></tr><tr><td>measured_compound:</td><td>Cyanide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>Mandelonitrile 133.15 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is mandelonitrile; the compartment is Cyanide. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Cyanide, not mandelonitrile</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>mandelonitrile's own concentration-time course is not produced by this model</li><li>dropped duplicate Q57 ('terminal half-lives', value '14') — already have one for this compound</li><li>metabolite cyanide: Q22→Q375 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyanide</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 8/8 row label(s) assigned, 0 linked by role</li><li>molar mass: no plausible PubChem entry for 'Cyanide' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'Cyanide' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Cyanide', not mandelonitrile — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Mandelonitrile_Dirikolu2003_reference;
