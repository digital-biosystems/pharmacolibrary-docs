function p = Tamoxifen_Croxtall1994_PD_a549_cell_proliferation_params()
% Tamoxifen_Croxtall1994_PD_a549_cell_proliferation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tamoxifen Croxtall_1994::A549_cell_proliferation: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response A549 cell proliferation in %. Driver: tamoxifen (cited_pk).
p.E0 = 0.0;
p.Emax = -0.75;
p.EC50 = 10.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 100.0;
p.form = 'E0 + Emax*frac';
end
