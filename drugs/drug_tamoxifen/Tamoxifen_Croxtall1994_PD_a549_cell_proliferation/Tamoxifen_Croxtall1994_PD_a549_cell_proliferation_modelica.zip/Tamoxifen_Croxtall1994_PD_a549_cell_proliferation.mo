model Tamoxifen_Croxtall1994_PD_a549_cell_proliferation
  "sigmoid_emax exposure-response sweep — Croxtall_1994 :: A549 cell proliferation (A549 cell proliferation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.75,  // [1; % × 0.01]
    EC50 = 10,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 100, Interval = 0.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tamoxifen</h4><p>Tamoxifen is an anti-estrogen medicine used to treat breast cancer, and it has also been used for pancreatic cancer and infant gynecomastia. It is an approved drug that is widely used, mainly in the hormonal treatment of breast cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412178\">Wikidata Q412178</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tamoxifen_Croxtall1994_PD_a549_cell_proliferation</h4><p>The steady-state exposure-response curve of Croxtall JD et al., <i>Biochemical pharmacology 47(2):197–202</i> 1994 (<a href=\"https://doi.org/10.1016/0006-2952(94)90006-x\">doi:10.1016/0006-2952(94)90006-x</a>) — A549 cell proliferation [%] against tamoxifen nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         75 %        maximal effect term (Emax, Q323)
  EC50  =         10 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of tamoxifen per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (10 nM)  response -0.375
  exposure -> infinity  response -0.75</pre></body></html>"));
end Tamoxifen_Croxtall1994_PD_a549_cell_proliferation;
