// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Tamoxifen_Dilli2022_model_structure
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.724},
    CLelim = {8.333333333333332e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = {}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tamoxifen</td></tr><tr><td>population:</td><td>adult breast cancer patients</td></tr><tr><td>source_paper:</td><td>Dilli_2022</td></tr><tr><td>measured_compound:</td><td>tamoxifen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>biology-12-00051-t003</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'model structure' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'model structure' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Effect of CYP3A4*22 genotype: 0.773' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row45:col1'])</li><li>dropped unlinked row (NIL): 'Effect of age: −0.298' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row46:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tamoxifen</li><li>topology: 4 first-order transfer(s) across 5 compounds → general_linear</li><li>population split: 'model structure' subgroup of Dilli_2022 (paper reports 2 populations: model structure, parameter estimates)</li><li>gap-filled Q22 (CL) from Bosch_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Dilli_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tamoxifen_Dilli2022_model_structure;
