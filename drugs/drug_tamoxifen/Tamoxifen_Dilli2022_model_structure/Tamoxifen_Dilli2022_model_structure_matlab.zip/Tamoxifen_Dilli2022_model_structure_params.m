function p = Tamoxifen_Dilli2022_model_structure_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tamoxifen   source: Dilli_2022 / model_structure   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Tamoxifen_Dilli2022_model_structure_params';
  p.drug  = 'tamoxifen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 724.0;                % central volume [L]
  p.CL = 3.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
