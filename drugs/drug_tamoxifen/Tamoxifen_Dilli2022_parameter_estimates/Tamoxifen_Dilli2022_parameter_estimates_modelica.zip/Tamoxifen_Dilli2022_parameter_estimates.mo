// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Tamoxifen_Dilli2022_parameter_estimates
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.724},
    CLelim = {8.333333333333332e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tamoxifen</td></tr><tr><td>population:</td><td>adult breast cancer patients</td></tr><tr><td>source_paper:</td><td>Dilli_2022</td></tr><tr><td>measured_compound:</td><td>tamoxifen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>biology-12-00051-t003</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Ter Heine et al. 2014 [15]' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row1:col4'])</li><li>dropped unlinked row (NIL): 'Schoell et al. 2020 [32]' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row11:col4'])</li><li>dropped unlinked row (NIL): 'Schulze et al. 2020 [33]' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row25:col4'])</li><li>dropped unlinked row (NIL): 'Puszkiel et al. 2021 [34]' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row42:col4'])</li><li>dropped unlinked row (NIL): 'Dahmane et al. [35]' — extend the ontology if this is a real PK parameter (source ['biology-12-00051-t003:row74:col4'])</li><li>table mostly unlinked (5/5 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tamoxifen</li><li>topology: 4 first-order transfer(s) across 5 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>population split: 'parameter estimates' subgroup of Dilli_2022 (paper reports 2 populations: model structure, parameter estimates)</li><li>gap-filled Q22 (CL) from Bosch_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Dilli_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tamoxifen_Dilli2022_parameter_estimates;
