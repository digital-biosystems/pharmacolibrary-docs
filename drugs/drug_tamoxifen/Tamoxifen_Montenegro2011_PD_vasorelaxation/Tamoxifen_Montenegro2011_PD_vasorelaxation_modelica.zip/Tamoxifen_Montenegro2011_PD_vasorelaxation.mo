model Tamoxifen_Montenegro2011_PD_vasorelaxation
  "emax exposure-response sweep — Montenegro_2011 :: vasorelaxation (vasorelaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.926,  // [1; % × 0.01]
    EC50 = 8800,  // [mol/m3; mole/L × 1000]
    gamma = 1,
    exposure_per_s = 1000);   // 1 mole/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 88, Interval = 0.176),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tamoxifen</h4><p>Tamoxifen is an anti-estrogen medicine used to treat breast cancer, and it has also been used for pancreatic cancer and infant gynecomastia. It is an approved drug that is widely used, mainly in the hormonal treatment of breast cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412178\">Wikidata Q412178</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tamoxifen_Montenegro2011_PD_vasorelaxation</h4><p>The steady-state exposure-response curve of Montenegro MF et al., <i>Journal of cardiovascular pharmacology 58(6):647–653</i> 2011 (<a href=\"https://doi.org/10.1097/FJC.0b013e31823171ba\">doi:10.1097/FJC.0b013e31823171ba</a>) — vasorelaxation [%] against Tamoxifen mole/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       92.6 %        maximal effect term (E max, Q320)
  EC50  =        8.8 mole/L   exposure at half of the maximal effect term (pD 2, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mole/L of Tamoxifen per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (8.8 mole/L)  response 0.463
  exposure -> infinity  response 0.926</pre></body></html>"));
end Tamoxifen_Montenegro2011_PD_vasorelaxation;
