function p = Tamoxifen_Montenegro2011_PD_vasorelaxation_params()
% Tamoxifen_Montenegro2011_PD_vasorelaxation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tamoxifen Montenegro_2011::vasorelaxation: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mole/L per second, in SI inside (kg/m3, s). Response vasorelaxation in %. Driver: Tamoxifen (cited_pk).
p.E0 = 0.0;
p.Emax = 0.9259999999999999;
p.EC50 = 8800.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1000.0;
p.stop_time = 88.0;
p.form = 'E0 + Emax*frac';
end
