function p = Eflornithine_Boberg2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eflornithine   source: Boberg_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Eflornithine_Boberg2025_reference_params';
  p.drug  = 'eflornithine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 55.0;                % central volume [L]
  p.CL = 17.2;                % clearance [L/h]
  p.Vp = [66.3];             % peripheral volumes [L]
  p.Q  = [8.01];             % inter-compartmental clearances [L/h]
  p.ka = 1.16;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.447;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
