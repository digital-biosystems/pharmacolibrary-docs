function p = Gatifloxacin_Tasso2011_PD_bactericidal_activity_params()
% Gatifloxacin_Tasso2011_PD_bactericidal_activity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gatifloxacin Tasso_2011::bactericidal_activity: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response bactericidal activity in its own unit. Driver: gatifloxacin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.00013333333333333334;
p.EC50 = 0.0009499999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 9.5;
p.form = 'E0 + Emax*frac';
end
