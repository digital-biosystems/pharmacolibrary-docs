model Gatifloxacin_Tasso2011_PD_bactericidal_activity
  "emax exposure-response sweep — Tasso_2011 :: bactericidal activity (bactericidal activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000133333333333,  // [1/s; h(-1) × 0.000277778]
    EC50 = 0.00095,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 9.5, Interval = 0.019),
    Documentation(info = "<html><body><!-- drug-about --><h4>About gatifloxacin</h4><p>Gatifloxacin is a fluoroquinolone antibiotic used against bacterial infections such as pneumonia, sinusitis, urinary tract infections, gonorrhea, and conjunctivitis. It has been withdrawn for systemic use because of serious side effects, though ophthalmic preparations may still be available in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2365016\">Wikidata Q2365016</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Gatifloxacin_Tasso2011_PD_bactericidal_activity</h4><p>The steady-state exposure-response curve of Tasso L et al., <i>International journal of antimicrobial agents 38(4):307–313</i> 2011 (<a href=\"https://doi.org/10.1016/j.ijantimicag.2011.05.015\">doi:10.1016/j.ijantimicag.2011.05.015</a>) — bactericidal activity against gatifloxacin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.48 h(-1)    maximal effect term (k(max), Q323)
  EC50  =       0.95 mg/L     exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of gatifloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.95 mg/L)  response -6.667e-05
  exposure -> infinity  response -0.0001333</pre></body></html>"));
end Gatifloxacin_Tasso2011_PD_bactericidal_activity;
