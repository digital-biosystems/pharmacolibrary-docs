// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Fumagillin_Laurn1989_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {466560.00000000006},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fumagillin</td></tr><tr><td>population:</td><td>yearling rainbow trout</td></tr><tr><td>source_paper:</td><td>Laurén_1989</td></tr><tr><td>measured_compound:</td><td>FDCH</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>fumagillin 458.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'clearance microconstants'</li><li>dropped unlinked row (NIL): 'highest doses' — extend the ontology if this is a real PK parameter (source ['Laurén_1989:abstract'])</li><li>dropped value-less row: 'lethal within'</li><li>dropped value-less row: 'Plasma clearance'</li><li>dropped unlinked row (NIL): 'doses fitting two-compartment model' — extend the ontology if this is a real PK parameter (source ['Laurén_1989:abstract'])</li><li>dropped value-less row: 'rapid alpha phase'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=FDCH</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: no plausible PubChem entry for 'FDCH' ('fumagillicyclohexylamine ester') — left in mass units</li><li>molar mass: none found for 'FDCH' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'FDCH', not fumagillin — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 4838.4));
end Fumagillin_Laurn1989_reference;
