function p = NickelChloride_Li2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nickel_chloride   source: Li_2008 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'NickelChloride_Li2008_reference_params';
  p.drug  = 'nickel_chloride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.12;                % central volume [L]
  p.CL = 0.0294;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.18;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
