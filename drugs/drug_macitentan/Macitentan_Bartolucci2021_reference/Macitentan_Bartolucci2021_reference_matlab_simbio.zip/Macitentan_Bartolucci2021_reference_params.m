function p = Macitentan_Bartolucci2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: macitentan   source: Bartolucci_2021 / reference   route: oral
  p.name  = 'Macitentan_Bartolucci2021_reference_params';
  p.drug  = 'macitentan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.0;                % central volume [L]
  p.CL = 1.39;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 13.92;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
