function p = Pegcetacoplan_Crass2025_transformed_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pegcetacoplan   source: Crass_2025 / transformed_estimate   route: oral
  p.name  = 'Pegcetacoplan_Crass2025_transformed_estimate_params';
  p.drug  = 'pegcetacoplan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.83;                % central volume [L]
  p.CL = 0.013542;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0022;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
