function p = Cephalosporin_Cojutti2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cephalosporin   source: Cojutti_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cephalosporin_Cojutti2023_reference_params';
  p.drug  = 'cephalosporin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.29;                % central volume [L]
  p.CL = 3.43;                % clearance [L/h]
  p.Vp = [35.79];             % peripheral volumes [L]
  p.Q  = [7.12];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
