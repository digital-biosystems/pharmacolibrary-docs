function p = Desipramine_Gueorguieva2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: desipramine   source: Gueorguieva_2010 / reference   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Desipramine_Gueorguieva2010_reference_params';
  p.drug  = 'desipramine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2950.0;                % central volume [L]
  p.CL = 111.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.15;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
