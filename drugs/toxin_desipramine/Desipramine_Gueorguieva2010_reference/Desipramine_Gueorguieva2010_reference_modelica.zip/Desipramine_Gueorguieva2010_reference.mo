model Desipramine_Gueorguieva2010_reference
  parameter Real Cl_ref = 3.0833333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.95 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26638799999999996,
    adminMass = 0.0001,
    ka = 4.1666666666666665e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>desipramine</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Gueorguieva_2010</td></tr><tr><td>measured_compound:</td><td>Desipramine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>desipramine 266.388 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'lh(-1)' (CL/F)</li><li>unit_dimension_unknown: 'lh(-1)' (CLint)</li><li>routed 'between-subject variability' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>implicit units: 'apparent clearance (CL/F)' → L/h (from the popPK convention: 'Population PK standard for apparent clearance (CL/F) of this magnitude (111) is L/h.')</li><li>implicit units: 'mean population desipramine hepatic intrinsic clearance' — the LLM proposed 'L/h', whose dimension does not fit Q3; left unset</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Desipramine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q3 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Desipramine_Gueorguieva2010_reference;
