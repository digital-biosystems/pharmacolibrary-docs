function p = Lorazepam_Berton2023_ratio_predicted_observed_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorazepam   source: Berton_2023 / ratio_predicted_observed_mean   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Lorazepam_Berton2023_ratio_predicted_observed_mean_params';
  p.drug  = 'lorazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.0;                % central volume [L]
  p.CL = 1.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
