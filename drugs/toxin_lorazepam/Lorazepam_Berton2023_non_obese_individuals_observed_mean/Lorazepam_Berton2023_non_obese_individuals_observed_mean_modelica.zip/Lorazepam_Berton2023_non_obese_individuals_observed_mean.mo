// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Lorazepam_Berton2023_non_obese_individuals_observed_mean
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {9720.0},
    MM = 0.32115699999999997,
    adminMass = 5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lorazepam</td></tr><tr><td>population:</td><td>Obese individuals (BMI ≥ 30 kg/m²) and non-obese individuals (BMI ≤ 30 kg/m²)</td></tr><tr><td>source_paper:</td><td>Berton_2023</td></tr><tr><td>measured_compound:</td><td>Lorazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>lorazepam 321.157 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'BMI' — extend the ontology if this is a real PK parameter (source ['Berton_2023_table_2:row0:col3', 'Berton_2023_table_2:row4:col3', 'Berton_2023_table_2:row8:col3', 'Berton_2023_table_2:row12:col3', 'Berton_2023_table_2:row16:col3', 'Berton_2023_table_2:row20:col3', 'Berton_2023_table_2:row24:col3', 'Berton_2023_table_2:row28:col3'])</li><li>dropped value-less row: 'CYP'</li><li>dropped value-less row: 'GFR'</li><li>dropped value-less row: 'IVB'</li><li>dropped value-less row: 'IVF'</li><li>dropped value-less row: 'PO'</li><li>dropped value-less row: 'SD'</li><li>dropped value-less row: 'S.D.'</li><li>dropped value-less row: 'UGT'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lorazepam</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'non-obese individuals observed mean' subgroup of Berton_2023 (paper reports 6 populations: non-obese individuals observed mean, non-obese individuals predicted mean, obese individuals observed mean, obese individuals predicted mean, observed / mean, ratio predicted / observed / mean)</li><li>gap-filled Q22 (CL) from Bianconi_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Lorazepam_Berton2023_non_obese_individuals_observed_mean;
