model Lorazepam_Berton2023_reference
  parameter Real Cl_ref = 4.444444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32115699999999997,
    adminMass = 5e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lorazepam</td></tr><tr><td>population:</td><td>Obese individuals (BMI ≥ 30 kg/m²) and non-obese individuals (BMI ≤ 30 kg/m²)</td></tr><tr><td>source_paper:</td><td>Berton_2023</td></tr><tr><td>measured_compound:</td><td>Lorazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lorazepam 321.157 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUCinf'</li><li>dropped value-less row: 'CYP'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'GFR'</li><li>dropped value-less row: 'IVB'</li><li>dropped value-less row: 'IVF'</li><li>dropped value-less row: 'PO'</li><li>dropped value-less row: 'SD'</li><li>dropped value-less row: 'S.D.'</li><li>dropped value-less row: 't1/2'</li><li>dropped value-less row: 'UGT'</li><li>salvaged Q57 ('t1/2 (overpredicted in non-obese subjects)'=1.49) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=3) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Clearance'=1.6) from results prose — parameter table was unreadable</li><li>implicit units: 't1/2 (overpredicted in non-obese subjects)' → h (from the paper text: &quot;In the text, parameters are listed as 'elimination half-life (t1/2)'. In Table 2, the unit for t1/2 is explicitly shown &quot;)</li><li>implicit units: 'volume of distribution' → L (from the popPK convention: 'The paper does not state a specific unit for the absolute volume of distribution V in the provided text for the general ')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lorazepam_Berton2023_reference;
