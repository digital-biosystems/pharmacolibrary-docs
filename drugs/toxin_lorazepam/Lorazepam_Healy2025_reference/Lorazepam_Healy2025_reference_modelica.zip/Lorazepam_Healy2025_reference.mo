model Lorazepam_Healy2025_reference
  parameter Real Cl_ref = 4.511111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32115699999999997,
    adminMass = 2.1000000000000002e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lorazepam</td></tr><tr><td>population:</td><td>mechanically-ventilated pediatric patients</td></tr><tr><td>source_paper:</td><td>Healy_2025</td></tr><tr><td>measured_compound:</td><td>Lorazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lorazepam 321.157 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>competing summary columns for 'Cmax'; not population strata</li><li>table representations disagree for 'Cmax'; source reconciliation required</li><li>competing summary columns for 'Cmax'; not population strata</li><li>table representations disagree for 'Cmax'; source reconciliation required</li><li>competing summary columns for 'AUC'; not population strata</li><li>table representations disagree for 'AUC'; source reconciliation required</li><li>competing summary columns for 'AUC'; not population strata</li><li>table representations disagree for 'AUC'; source reconciliation required</li><li>competing summary columns for 'Cmax'; not population strata</li><li>table representations disagree for 'Cmax'; source reconciliation required</li><li>competing summary columns for 'Cmax'; not population strata</li><li>table representations disagree for 'Cmax'; source reconciliation required</li><li>competing summary columns for 'AUC'; not population strata</li><li>table representations disagree for 'AUC'; source reconciliation required</li><li>competing summary columns for 'AUC'; not population strata</li><li>table representations disagree for 'AUC'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lorazepam_Healy2025_reference;
