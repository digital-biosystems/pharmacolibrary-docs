model Lorazepam_Greenblatt1983_reference
  parameter Real Cl_ref = 1.3833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 9.31 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32115699999999997,
    adminMass = 2.5e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lorazepam</td></tr><tr><td>population:</td><td>Eight healthy volunteers</td></tr><tr><td>source_paper:</td><td>Greenblatt_1983</td></tr><tr><td>measured_compound:</td><td>Lorazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lorazepam 321.157 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Greenblatt_1983:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Greenblatt_1983:abstract'])</li><li>covariate category for fu from footnote/prose kept as documentation only (['Greenblatt_1983:abstract'])</li><li>covariate category for fu from footnote/prose kept as documentation only (['Greenblatt_1983:abstract'])</li><li>dropped duplicate Q61 ('volume of distribution of unbound lorazepam', value 12) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lorazepam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Bianconi_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Bianconi_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Lorazepam_Greenblatt1983_reference;
