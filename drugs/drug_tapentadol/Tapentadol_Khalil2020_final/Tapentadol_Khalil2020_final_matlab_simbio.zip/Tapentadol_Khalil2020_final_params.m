function p = Tapentadol_Khalil2020_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tapentadol   source: Khalil_2020 / final   route: oral
  p.name  = 'Tapentadol_Khalil2020_final_params';
  p.drug  = 'tapentadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 188.0;                % central volume [L]
  p.CL = 45.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.64;                % absorption rate [1/h]
  p.F  = 0.195;                 % bioavailability [0-1]
  p.Tlag = 0.257;             % absorption lag [h]
  p.dose = 21.0;             % dose [mg]
end
