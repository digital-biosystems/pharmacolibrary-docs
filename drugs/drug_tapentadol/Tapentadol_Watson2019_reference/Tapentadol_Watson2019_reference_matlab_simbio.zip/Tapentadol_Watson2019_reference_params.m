function p = Tapentadol_Watson2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tapentadol   source: Watson_2019 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Tapentadol_Watson2019_reference_params';
  p.drug  = 'tapentadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 685.0;                % central volume [L]
  p.CL = 170.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.03;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.247;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
