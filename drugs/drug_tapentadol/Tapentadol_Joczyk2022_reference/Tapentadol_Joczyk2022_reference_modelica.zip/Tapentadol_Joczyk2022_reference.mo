// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Tapentadol_Joczyk2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {1.203},
    CLelim = {2.602777777777778e-05},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tapentadol</td></tr><tr><td>population:</td><td>children aged 2 to <7 years with acute pain</td></tr><tr><td>source_paper:</td><td>Jończyk_2022</td></tr><tr><td>measured_compound:</td><td>tapentadol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h•ng/mL' (AUCt)</li><li>dropped duplicate Q32 ('Cmax,ss (ng/mL)', value '201.2') — already have one for this compound</li><li>dropped duplicate Q36 ('Cmin,ss (ng/mL)', value '29.3') — already have one for this compound</li><li>unit_dimension_unknown: 'h•ng/mL' (AUCSS)</li><li>dropped unlinked row (NIL): 'AF' — extend the ontology if this is a real PK parameter (source ['t0003:row6:col3', 't0003:row6:col4', 't0003:row6:col5', 't0003:row6:col6', 't0003:row6:col8', 't0003:row6:col9', 't0003:row6:col10', 't0003:row6:col11', 't0003:row6:col13', 't0003:row6:col14', 't0003:row6:col15', 't0003:row6:col16'])</li><li>salvaged Q22 ('Tapentadol mature CL'=93.7) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=272) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=1203) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tapentadol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tapentadol_Joczyk2022_reference;
