function p = Bilastine_Jauregizar2009_PD_flare_params()
% Bilastine_Jauregizar2009_PD_flare_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bilastine Jauregizar_2009::flare: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response flare in its own unit. Driver: bilastine (cited_pk).
p.E0 = 10.776699029126213;
p.Emax = 1.0;
p.EC50 = 1.2499999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 13.0;
p.form = 'E0*(1 - Emax*frac)';
end
