model Bilastine_Jauregizar2009_PD_wheal
  "indirect_response_i exposure-response sweep — Jauregizar_2009 :: wheal (wheal area)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.403669724771,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 5.15e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.44/1.09 = 0.4037) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 52, Interval = 0.104),
    Documentation(info = "<html><body><!-- drug-about --><h4>About bilastine</h4><p>Bilastine is an antihistamine used to treat allergic conditions such as allergic rhinitis and urticaria. It is an approved medicine and is widely used, including as eye drops for allergic eye symptoms.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2902977\">Wikidata Q2902977</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Bilastine_Jauregizar2009_PD_wheal</h4><p>The steady-state exposure-response curve of Jauregizar N et al., <i>Clinical pharmacokinetics 48(8):543–554</i> 2009 (<a href=\"https://doi.org/10.2165/11317180-000000000-00000\">doi:10.2165/11317180-000000000-00000</a>) — wheal area against bilastine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 0.403669724771          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       5.15 ng/mL    exposure at half of the maximal effect term (bilastine IC(50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of bilastine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.4037   (drug-free)
  exposure = EC50 (5.15 ng/mL)  response 0.2018
  exposure -> infinity  response 0</pre></body></html>"));
end Bilastine_Jauregizar2009_PD_wheal;
