function p = Bilastine_Jauregizar2009_PD_wheal_params()
% Bilastine_Jauregizar2009_PD_wheal_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bilastine Jauregizar_2009::wheal: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response wheal in its own unit. Driver: bilastine (cited_pk).
p.E0 = 0.40366972477064217;
p.Emax = 1.0;
p.EC50 = 5.15e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 52.0;
p.form = 'E0*(1 - Emax*frac)';
end
