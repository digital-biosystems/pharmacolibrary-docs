model Bilastine_Togawa2016_caucasianb_5
  parameter Real Cl_ref = 5.027777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0592 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.46362200000000003,
    adminMass = 1e-05,
    ka = 0.00041666666666666664,
    Tlag = 0.0,
    k12 = 7.460585585585586e-06,
    k21 = 1.4624724061810156e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bilastine</h4><p>Bilastine is an antihistamine used to treat allergic conditions such as allergic rhinitis and urticaria. It is an approved medicine and is widely used, including as eye drops for allergic eye symptoms.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2902977\">Wikidata Q2902977</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bilastine</td></tr><tr><td>population:</td><td>healthy Japanese adults</td></tr><tr><td>source_paper:</td><td>Togawa_2016</td></tr><tr><td>measured_compound:</td><td>bilastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bilastine 463.622 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωVc (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωQ (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωVp (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q63 (Vc (L)); Q30 (Q (L/h)); Q64 (Vp (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bilastine</li><li>population split: 'caucasianb [5]' subgroup of Togawa_2016 (paper reports 2 populations: caucasianb [5], japanesea)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bilastine_Togawa2016_caucasianb_5;
