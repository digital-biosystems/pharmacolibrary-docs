function p = Bilastine_Togawa2016_caucasianb_5_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bilastine   source: Togawa_2016 / caucasianb_5   route: oral
  % estimated (absent from source): F
  p.name  = 'Bilastine_Togawa2016_caucasianb_5_params';
  p.drug  = 'bilastine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 59.2;                % central volume [L]
  p.CL = 18.1;                % clearance [L/h]
  p.Vp = [30.2];             % peripheral volumes [L]
  p.Q  = [1.59];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
