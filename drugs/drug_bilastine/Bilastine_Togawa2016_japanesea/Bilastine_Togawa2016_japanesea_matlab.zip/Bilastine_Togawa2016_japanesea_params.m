function p = Bilastine_Togawa2016_japanesea_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bilastine   source: Togawa_2016 / japanesea   route: oral
  % estimated (absent from source): F
  p.name  = 'Bilastine_Togawa2016_japanesea_params';
  p.drug  = 'bilastine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 51.2;                % central volume [L]
  p.CL = 14.4;                % clearance [L/h]
  p.Vp = [20.2];             % peripheral volumes [L]
  p.Q  = [1.55];             % inter-compartmental clearances [L/h]
  p.ka = 1.7;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
