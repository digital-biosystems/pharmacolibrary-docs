model Olaratumab_Mo2018_base
  parameter Real Cl_ref = 6.6944444444444446e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00419 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00105,
    k12 = 2.09493503049589e-06,
    k21 = 2.4518932340161394e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olaratumab</h4><p>Olaratumab is a monoclonal antibody anticancer drug that was used to treat soft-tissue sarcoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7083108\">Wikidata Q7083108</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olaratumab</td></tr><tr><td>population:</td><td>patients with advanced and/or metastatic cancer</td></tr><tr><td>source_paper:</td><td>Mo_2018</td></tr><tr><td>measured_compound:</td><td>olaratumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Additive (µg/mL)' routed out of structural estimates ('Residual error model')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=olaratumab</li><li>model-stage split: 'base pk model' is the base model of Mo_2018 (paper reports 2 stages: base pk model, final pk model); same population, different model-building step</li><li>molar mass: none found for 'olaratumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Olaratumab_Mo2018_base;
