function p = Olaratumab_Mo2018_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: olaratumab   source: Mo_2018 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Olaratumab_Mo2018_base_params';
  p.drug  = 'olaratumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.19;                % central volume [L]
  p.CL = 0.0241;                % clearance [L/h]
  p.Vp = [3.58];             % peripheral volumes [L]
  p.Q  = [0.0316];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
