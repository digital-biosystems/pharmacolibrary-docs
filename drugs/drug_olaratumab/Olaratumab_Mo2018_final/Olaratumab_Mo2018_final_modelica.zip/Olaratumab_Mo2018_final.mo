model Olaratumab_Mo2018_final
  parameter Real Cl_ref = 6.4722222222222226e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0041600000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00105,
    k12 = 2.1033653846153845e-06,
    k21 = 2.4441340782122904e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olaratumab</h4><p>Olaratumab is a monoclonal antibody anticancer drug that was used to treat soft-tissue sarcoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7083108\">Wikidata Q7083108</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olaratumab</td></tr><tr><td>population:</td><td>patients with advanced and/or metastatic cancer</td></tr><tr><td>source_paper:</td><td>Mo_2018</td></tr><tr><td>measured_compound:</td><td>olaratumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Additive (µg/mL)' routed out of structural estimates ('Residual error model')</li><li>dropped unlinked row (NIL): 'WTECL a' — extend the ontology if this is a real PK parameter (source ['Tab3:row11:col3'])</li><li>dropped unlinked row (NIL): '\\documentclass[12pt]{minimal} \\usepackage{amsmath} \\usepackage{wasysym} \\usepackage{amsfonts} \\usepackage{amssymb} \\usepackage{amsbsy} \\usepackage{mathrsfs} \\usepackage{upgreek} \\setlength{\\oddsidemargin}{-69pt} \\begin{document}$$ {\\text{WTE}}_{{V_{ 1} }} $$\\end{document}WTEV1 b' — extend the ontology if this is a real PK parameter (source ['Tab3:row12:col3'])</li><li>dropped unlinked row (NIL): 'TUMRCL a' — extend the ontology if this is a real PK parameter (source ['Tab3:row13:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=olaratumab</li><li>model-stage split: 'final pk model' is the final model of Mo_2018 (paper reports 2 stages: base pk model, final pk model); same population, different model-building step</li><li>molar mass: none found for 'olaratumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Olaratumab_Mo2018_final;
