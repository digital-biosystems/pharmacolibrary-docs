// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SodiumSelenite_Xing2019_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {179.64},
    MM = 0.078971,
    adminMass = 1.4e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_selenite</td></tr><tr><td>population:</td><td>Healthy piglets</td></tr><tr><td>source_paper:</td><td>Xing_2019</td></tr><tr><td>measured_compound:</td><td>Selenium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Selenium 78.971 g/mol (pubchem); sodium_selenite 172.948 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('absorption half-life of Se'=0.0499) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Selenium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>review gap-fill skipped: this record measures 'Selenium', not sodium_selenite — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end SodiumSelenite_Xing2019_reference;
