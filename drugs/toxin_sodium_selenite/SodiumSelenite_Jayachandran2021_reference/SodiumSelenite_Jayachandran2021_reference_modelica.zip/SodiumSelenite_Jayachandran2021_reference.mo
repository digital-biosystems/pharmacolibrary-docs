model SodiumSelenite_Jayachandran2021_reference
  parameter Real Cl_ref = 4.416666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0425 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.078971,
    adminMass = 5.5e-06,
    ka = 0.00017833333333333335,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_selenite</td></tr><tr><td>population:</td><td>patients with metastatic cancer</td></tr><tr><td>source_paper:</td><td>Jayachandran_2021</td></tr><tr><td>measured_compound:</td><td>Selenium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Selenium 78.971 g/mol (pubchem); sodium_selenite 172.948 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BASE, μg' routed out of structural estimates ('Interindividual variability%CV (RSE, %)')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Selenium</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>review gap-fill skipped: this record measures 'Selenium', not sodium_selenite — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end SodiumSelenite_Jayachandran2021_reference;
