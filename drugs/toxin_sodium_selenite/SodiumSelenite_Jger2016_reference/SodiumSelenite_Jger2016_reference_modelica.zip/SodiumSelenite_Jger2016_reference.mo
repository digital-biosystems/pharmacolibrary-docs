// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SodiumSelenite_Jger2016_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {53280.0},
    MM = 0.07895999999999999,
    adminMass = 1.0000000000000001e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_selenite</td></tr><tr><td>population:</td><td>Nine healthy human volunteers (TMSe eliminators and non-eliminators)</td></tr><tr><td>source_paper:</td><td>Jäger_2016</td></tr><tr><td>measured_compound:</td><td>Total selenium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Methyl-2-acetamido-2-deoxy-1-seleno-β-d-galactopyranoside (SeSug1) 249.1 g/mol (paper); Methyl-2-amino-2-desoxy-1-seleno-β-d-galactopyranoside (SeSug3) 235.06 g/mol (paper); Selenate (SeVI) 139.96 g/mol (paper); Sodium selenite 159.97 g/mol (paper); Total selenium 78.96 g/mol (paper); Trimethylselenium ion (TMSe) 123.05 g/mol (paper)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('elimination half-life'=14.8) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Total selenium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 4 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>review gap-fill skipped: this record measures 'Total selenium', not sodium_selenite — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end SodiumSelenite_Jger2016_reference;
