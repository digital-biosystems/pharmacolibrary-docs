// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_4Aminophenol_Dressler2006_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {21420.0},
    MM = 0.109128,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4_aminophenol</td></tr><tr><td>population:</td><td>rat and pig</td></tr><tr><td>source_paper:</td><td>Dressler_2006</td></tr><tr><td>measured_compound:</td><td>4-Aminophenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>4-Aminophenol 109.128 g/mol (pubchem); 4_aminophenol 109.128 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'microg-equivalentsh/ml' (AUC)</li><li>implicit units: 'AUC(0-infinity)' → mg*h/L (from the popPK convention: 'AUC is the Area Under the Curve of concentration vs. time. The standard unit for concentration is mg/L (or μg/mL) and fo')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-Aminophenol</li><li>toxin: 4 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 216.0));
end D_4Aminophenol_Dressler2006_reference;
