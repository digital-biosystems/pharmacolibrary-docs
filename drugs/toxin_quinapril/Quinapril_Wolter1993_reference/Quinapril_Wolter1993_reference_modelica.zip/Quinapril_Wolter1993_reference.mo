// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Quinapril_Wolter1993_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {108000.0},
    MM = 0.41047,
    adminMass = 1.5e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinapril</td></tr><tr><td>population:</td><td>patients with terminal renal failure (hemodialysis and CAPD)</td></tr><tr><td>source_paper:</td><td>Wolter_1993</td></tr><tr><td>measured_compound:</td><td>Quinaprilat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Quinapril 438.524 g/mol (pubchem); Quinaprilat 410.47 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Elimination half lives (CAPD)', value 34) — already have one for this compound</li><li>dropped duplicate Q358 ('dose removed within 24 h by CAPD', value 0.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Quinaprilat</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles: 3 per-group rows of Quinapril summary_statistic but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 1 linked by role; re-tagged Quinaprilat→parent ×4</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end Quinapril_Wolter1993_reference;
