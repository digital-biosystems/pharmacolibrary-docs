function p = SodiumIodide131i_Ly2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_iodide_131i   source: Ly_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'SodiumIodide131i_Ly2023_reference_params';
  p.drug  = 'sodium_iodide_131i';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 98.8;                % central volume [L]
  p.CL = 2.05;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.39;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
