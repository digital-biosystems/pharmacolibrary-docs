model SodiumIodide131i_Ly2023_reference
  parameter Real Cl_ref = 5.694444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0988 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1309067,
    adminMass = 0.0001,
    ka = 0.0009416666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sodium_iodide_131i</h4><p>Iodide I-131 is a radioactive form of iodine used both diagnostically and therapeutically for thyroid conditions. It is an approved radiopharmaceutical, used in nuclear medicine for thyroid imaging and treatment, and also has investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27259563\">Wikidata Q27259563</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_iodide_131i</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ly_2023</td></tr><tr><td>measured_compound:</td><td>sodium_iodide_131i</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sodium_iodide_131i 130.907 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ly_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end SodiumIodide131i_Ly2023_reference;
