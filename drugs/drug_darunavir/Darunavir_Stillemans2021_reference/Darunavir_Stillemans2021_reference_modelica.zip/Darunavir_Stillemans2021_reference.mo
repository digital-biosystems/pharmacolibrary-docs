model Darunavir_Stillemans2021_reference
  parameter Real Cl_ref = 3.5833333333333335e-06 "Cl [m3/s]";
  parameter Real cov_slco3a1_0 = 0 "slco3a1 covariate";
  parameter Real Vd_ref = 0.152 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.81)*cov_slco3a1_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.547664,
    adminMass = 0.0006,
    ka = 0.0001888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About darunavir</h4><p>Darunavir is an antiviral protease inhibitor used to treat HIV infection. It is authorised in the European Union and is included on the WHO list of essential medicines, so it is widely used in HIV treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3765251\">Wikidata Q3765251</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>darunavir</td></tr><tr><td>population:</td><td>adult patients with HIV</td></tr><tr><td>source_paper:</td><td>Stillemans_2021</td></tr><tr><td>measured_compound:</td><td>darunavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>darunavir 547.664 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σexponential (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σexponential (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σexponential (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σadditive (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σadditive (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σadditive (SD)' routed out of structural estimates ('Residual variability')</li><li>dropped value-less row: 'AAG on CL'</li><li>dropped value-less row: 'AAG on V'</li><li>dropped value-less row: 'Female sex on CL'</li><li>covariate level 'SLCO3A1 G > T on V' → Q900:slco3a1_g_gt_t_on_v = 0.81 (linear_fractional on Q27)</li><li>dropped value-less row: 'CYP3A5*3 on CL'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=darunavir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Darunavir_Stillemans2021_reference;
