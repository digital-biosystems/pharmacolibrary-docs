model Darunavir_Stillemans2021_reference
  parameter Real Cl_ref = 3.5833333333333335e-06 "Cl [m3/s]";
  parameter Real cov_slco3a1_0 = 0 "slco3a1 covariate";
  parameter Real Vd_ref = 0.152 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.81)*cov_slco3a1_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.547664,
    adminMass = 0.0006,
    ka = 0.0001888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About darunavir</h4><p>Darunavir is a protease inhibitor used to treat and prevent HIV and AIDS. It is taken orally, usually as tablets or a suspension, often combined with other agents to boost its levels. It is widely used and included in the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q3765251\">Wikidata Q3765251</a>, <a href=\"https://en.wikipedia.org/wiki/Darunavir?oldid=1368876372\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>darunavir</td></tr><tr><td>population:</td><td>adults with HIV-1 infection</td></tr><tr><td>source_paper:</td><td>Stillemans_2021</td></tr><tr><td>measured_compound:</td><td>darunavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>darunavir 547.664 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σexponential (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σexponential (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σexponential (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σadditive (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σadditive (SD)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σadditive (SD)' routed out of structural estimates ('Residual variability')</li><li>dropped value-less row: 'AAG on CL'</li><li>dropped value-less row: 'AAG on V'</li><li>dropped value-less row: 'Female sex on CL'</li><li>covariate level 'SLCO3A1 G > T on V' → Q900:slco3a1_g_gt_t_on_v = 0.81 (linear_fractional on Q27)</li><li>dropped value-less row: 'CYP3A5*3 on CL'</li><li>dropped value-less row: 'AAG'</li><li>dropped value-less row: 'α1-acid glycoprotein'</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'confidence interval'</li><li>dropped value-less row: 'CL'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Darunavir_Stillemans2021_reference;
