function p = Darunavir_Abdalla2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: darunavir   source: Abdalla_2024 / reference   route: oral
  p.name  = 'Darunavir_Abdalla2024_reference_params';
  p.drug  = 'darunavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2601.0;                % central volume [L]
  p.CL = 169.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.43;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
