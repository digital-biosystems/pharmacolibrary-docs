model Darunavir_Abdalla2024_reference
  parameter Real Cl_ref = 4.6944444444444446e-05 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real Vd_ref = 2.601 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.0)*cov_weight_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.547664,
    adminMass = 0.0008,
    ka = 0.00011944444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About darunavir</h4><p>Darunavir is an antiviral protease inhibitor used to treat HIV infection. It is authorised in the European Union and is included on the WHO list of essential medicines, so it is widely used in HIV treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3765251\">Wikidata Q3765251</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>darunavir</td></tr><tr><td>population:</td><td>adolescents with HIV</td></tr><tr><td>source_paper:</td><td>Abdalla_2024</td></tr><tr><td>measured_compound:</td><td>darunavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>darunavir 547.664 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F DRV,u' routed out of structural estimates ('Inter-individual variability (CV%)')</li><li>table section iiv: 'CL/F DRV,u' routed out of structural estimates ('Inter-individual variability (CV%)')</li><li>table section iiv: 'V/F DRV,u' routed out of structural estimates ('Inter-individual variability (CV%)')</li><li>table section iiv: 'V/F DRV,u' routed out of structural estimates ('Inter-individual variability (CV%)')</li><li>table section iiv: 'CL/F RTV' routed out of structural estimates ('Inter-individual variability (CV%)')</li><li>table section iiv: 'CL/F RTV' routed out of structural estimates ('Inter-individual variability (CV%)')</li><li>unit_dimension_mismatch: 'AUC RTV effect on CL/F DRV, u' → Q27 (unit '[mass]' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('AUC RTV effect on CL/F DRV, u', value '-0.5') — already have one for this compound</li><li>dropped unlinked row (NIL): 'N AAG' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1'])</li><li>dropped unlinked row (NIL): 'K d, AAG (×10 -3 mmol/L)' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col1', 'tab_1:row8:col2'])</li><li>dropped duplicate Q49 ('ka RTV (h -1 )', value '0.18') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F RTV (L/h)', value '21.6') — already have one for this compound</li><li>covariate level 'Weight effect on' → Q900:weight_effect_on = 1 (linear_fractional on Q27)</li><li>dropped duplicate Q76 ('V/F RTV (L)', value '105.7') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Unbound DRV concentrations' — extend the ontology if this is a real PK parameter (source ['tab_1:row23:col1', 'tab_1:row23:col2'])</li><li>dropped unlinked row (NIL): 'Total DRV concentrations' — extend the ontology if this is a real PK parameter (source ['tab_1:row24:col1', 'tab_1:row24:col2'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Darunavir_Abdalla2024_reference;
