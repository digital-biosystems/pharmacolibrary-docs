function p = SacituzumabGovitecan_Sathe2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sacituzumab_govitecan   source: Sathe_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'SacituzumabGovitecan_Sathe2025_reference_params';
  p.drug  = 'sacituzumab_govitecan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.65;                % central volume [L]
  p.CL = 0.128;                % clearance [L/h]
  p.Vp = [0.929];             % peripheral volumes [L]
  p.Q  = [0.00513];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
