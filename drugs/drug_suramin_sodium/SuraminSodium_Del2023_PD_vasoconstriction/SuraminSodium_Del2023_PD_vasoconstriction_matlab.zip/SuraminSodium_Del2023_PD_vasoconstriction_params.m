function p = SuraminSodium_Del2023_PD_vasoconstriction_params()
% SuraminSodium_Del2023_PD_vasoconstriction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% suramin_sodium Del_2023::vasoconstriction: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response vasoconstriction in its own unit. Driver: suramin (cited_pk).
p.E0 = 0.0;
p.Emax = -25.0;
p.EC50 = 825.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 8300.0;
p.form = 'E0 + Emax*frac';
end
