model SuraminSodium_Del2023_PD_vasoconstriction
  "sigmoid_emax exposure-response sweep — Del_2023 :: vasoconstriction (αβme-ATP-evoked vasoconstriction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -25,  // [% 60 mM K + response for intact rings]
    EC50 = 825,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8300, Interval = 16.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About suramin_sodium</h4><p>Suramin is an antiprotozoal drug used against trypanosomiasis, and has also been studied as an antineoplastic and antinematodal agent. It is listed as investigational in DrugBank and has no European Union authorisation, though it appears on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425946\">Wikidata Q425946</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>SuraminSodium_Del2023_PD_vasoconstriction</h4><p>The steady-state exposure-response curve of Del Carmen Gonzalez-Montelongo M et al., <i>Vascular pharmacology 151:107192</i> 2023 (<a href=\"https://doi.org/10.1016/j.vph.2023.107192\">doi:10.1016/j.vph.2023.107192</a>) — αβme-ATP-evoked vasoconstriction against suramin nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         25 % 60 mM K + response for intact rings maximal effect term (magnitude of response at maximal NPY concentrations, Q320)
  EC50  =        825 nM       exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of suramin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (825 nM)  response -12.5
  exposure -> infinity  response -25</pre></body></html>"));
end SuraminSodium_Del2023_PD_vasoconstriction;
