function p = Clomipramine_King2000v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clomipramine   source: King_2000_2 / reference   route: iv_bolus
  p.name  = 'Clomipramine_King2000v2_reference_params';
  p.drug  = 'clomipramine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 107.1;                % central volume [L]
  p.CL = 98.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.2;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
