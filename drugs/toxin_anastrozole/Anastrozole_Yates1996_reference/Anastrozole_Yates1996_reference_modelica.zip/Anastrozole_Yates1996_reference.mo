// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Anastrozole_Yates1996_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {182520.0},
    adminMass = 5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>anastrozole</td></tr><tr><td>population:</td><td>healthy post-menopausal female volunteers</td></tr><tr><td>source_paper:</td><td>Yates_1996</td></tr><tr><td>measured_compound:</td><td>Anastrozole (ZD1033)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>anastrozole 293.374 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Percentage reduction' — extend the ontology if this is a real PK parameter (source ['Yates_1996_table_1:row0:col1', 'Yates_1996_table_1:row0:col2', 'Yates_1996_table_1:row0:col3', 'Yates_1996_table_1:row0:col4', 'Yates_1996_table_1:row0:col5', 'Yates_1996_table_1:row0:col6', 'Yates_1996_table_1:row0:col7'])</li><li>salvaged Q59 ('Mean half-life after first dose of 3 mg'=50.7) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('Mean half-life after last dose of 3 mg'=45.4) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Anastrozole (ZD1033)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'Anastrozole (ZD1033)' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from van_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from van_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1900.8));
end Anastrozole_Yates1996_reference;
