model Anastrozole_Miyajima2013_reference
  parameter Real Cl_ref = 5.116666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0324 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.293374,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>anastrozole</td></tr><tr><td>population:</td><td>mice (wild-type and Mdr1a/b/Bcrp knockout)</td></tr><tr><td>source_paper:</td><td>Miyajima_2013</td></tr><tr><td>measured_compound:</td><td>anastrozole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>anastrozole 293.374 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'min·g brain' (kuptake)</li><li>unit_dimension_unknown: 'min·g brain' (kuptake)</li><li>dropped duplicate Q349 ('uptake clearance of letrozole by the brain', value 0.422) — already have one for this compound</li><li>unit_dimension_unknown: 'min·g brain' (kuptake)</li><li>dropped duplicate Q349 ('uptake clearance of vorozole by the brain', value 0.91) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=anastrozole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from van_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from van_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): van_2023 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q349 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Anastrozole_Miyajima2013_reference;
