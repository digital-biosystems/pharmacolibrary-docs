function p = Methionine_Lignet2023_PD_met_ef1_params()
% Methionine_Lignet2023_PD_met_ef1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methionine Lignet_2023::Met_EF1: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Met-EF1α in µg/mg protein. Driver: M8891 (effect compartment concentration Ce) (conc_no_pk).
p.E0 = 20.06896551724138;
p.Emax = 0.91;
p.EC50 = 0.00033999999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 38000.0;
p.form = 'E0/(1 - Emax*frac)';
end
