model Methionine_Lignet2023_PD_met_ef1
  "indirect_response_ii exposure-response sweep — Lignet_2023 :: Met-EF1α (Met-EF1α (uncleaved N-terminal methionine elongation factor 1α) in tumor tissue, normalized to total protein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 20.0689655172,      // [µg/mg protein]
    Emax = 0.91,  // type II effect term
    EC50 = 0.00034,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // off_target_driver: driver compound 'M8891 (effect compartment concentration Ce)' is not 'methionine' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (29.1/1.45 = 20.07) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 38000, Interval = 76),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methionine</h4><p>Methionine is an essential amino acid used as an antidote, for example in poisoning, and also as a nutritional supplement. It is an approved, widely available nutrient and medicine, though it is not an EMA-authorised drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q22124685\">Wikidata Q22124685</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Methionine_Lignet2023_PD_met_ef1</h4><p>The steady-state exposure-response curve of Lignet F et al., <i>Pharmaceutical research 40(12):3011–3023</i> 2023 (<a href=\"https://doi.org/10.1007/s11095-023-03611-z\">doi:10.1007/s11095-023-03611-z</a>) — Met-EF1α (uncleaved N-terminal methionine elongation factor 1α) in tumor tissue, normalized to total protein [µg/mg protein] against M8891 (effect compartment concentration Ce) ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 20.0689655172 µg/mg protein drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       0.91          maximal effect term (Imax, Q323)
  EC50  =        340 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of M8891 (effect compartment concentration Ce) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 20.07   (drug-free)
  exposure = EC50 (340 ng/mL)  response 36.82
  exposure -> infinity  response 223</pre></body></html>"));
end Methionine_Lignet2023_PD_met_ef1;
