model Methionine_Kim2025_reference
  parameter Real Cl_ref = 7.151666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13681235769204536 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.149211,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methionine</h4><p>Methionine is an essential amino acid used as an antidote, for example in poisoning, and also as a nutritional supplement. It is an approved, widely available nutrient and medicine, though it is not an EMA-authorised drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q22124685\">Wikidata Q22124685</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methionine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kim_2025</td></tr><tr><td>measured_compound:</td><td>methionine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>methionine 149.211 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kim_2025) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methionine_Kim2025_reference;
