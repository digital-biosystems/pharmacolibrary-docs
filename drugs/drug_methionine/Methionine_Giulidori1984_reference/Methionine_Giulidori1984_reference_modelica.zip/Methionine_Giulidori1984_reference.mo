model Methionine_Giulidori1984_reference
  parameter Real Cl_ref = 1.0277777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.028489999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399446,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methionine</h4><p>Methionine is an essential amino acid used as an antidote, for example in poisoning, and also as a nutritional supplement. It is an approved, widely available nutrient and medicine, though it is not an EMA-authorised drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q22124685\">Wikidata Q22124685</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methionine</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Giulidori_1984</td></tr><tr><td>measured_compound:</td><td>S-adenosyl-L-methionine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>S-adenosyl-L-methionine 399.446 g/mol (pubchem); methionine 149.211 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q76 ('apparent volume of distribution (500 mg dose)', value 443) — already have one for this compound</li><li>dropped duplicate Q57 ('terminal half-life (500 mg dose)', value 101) — already have one for this compound</li><li>unit_dimension_unknown: 'ml/min per kg' (CLb)</li><li>unit_dimension_unknown: 'ml/min per kg' (CLb)</li><li>dropped duplicate Q23 ('body clearance (500 mg dose)', value 3.1) — already have one for this compound</li><li>implicit units: 'body clearance (100 mg dose)' → L/h (from the popPK convention: 'No unit stated in text or footnotes. Blood clearance in population PK is conventionally expressed in L/h; the value 3.7 ')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=S-adenosyl-L-methionine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methionine_Giulidori1984_reference;
