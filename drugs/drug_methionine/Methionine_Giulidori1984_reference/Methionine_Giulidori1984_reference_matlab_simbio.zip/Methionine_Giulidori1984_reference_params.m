function p = Methionine_Giulidori1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methionine   source: Giulidori_1984 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Methionine_Giulidori1984_reference_params';
  p.drug  = 'methionine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.49;                % central volume [L]
  p.CL = 3.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
