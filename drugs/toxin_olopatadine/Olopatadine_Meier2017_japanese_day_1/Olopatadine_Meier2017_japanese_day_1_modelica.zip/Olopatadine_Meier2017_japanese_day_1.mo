// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Olopatadine_Meier2017_japanese_day_1
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {10044.0},
    MM = 0.33741899999999997,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>olopatadine</td></tr><tr><td>population:</td><td>healthy subjects with asymptomatic eyes (adults and pediatric subjects)</td></tr><tr><td>source_paper:</td><td>Meier_2017</td></tr><tr><td>measured_compound:</td><td>olopatadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>ts4-opth-11-669</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>olopatadine 337.419 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 19 (source ['ts4-opth-11-669:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 4 (source ['ts4-opth-11-669:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=olopatadine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'japanese (n=12) day 1' subgroup of Meier_2017 (paper reports 14 populations: japanese (n=12) day 1, japanese (n=12) day 7*, multiple dose (day 7) (n=22), multiple-dose / 10 mg olopatadine oral tablet (n=8)1, multiple-dose / olopatadine 0.77%(n=22), multiple-dose 10 mg olopatadine oral tablet (n=8)¹, multiple-dose olopatadine 0.77% (n=22), non-japanese (n=12) day 1, non-japanese (n=12) day 7, single dose (day 1) (n=24), single-dose / 10 mg olopatadine oral tablet (n=8)1, single-dose / olopatadine 0.77%(n=24), single-dose 10 mg olopatadine oral tablet (n=8)¹, single-dose olopatadine 0.77% (n=24))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Olopatadine_Meier2017_japanese_day_1;
