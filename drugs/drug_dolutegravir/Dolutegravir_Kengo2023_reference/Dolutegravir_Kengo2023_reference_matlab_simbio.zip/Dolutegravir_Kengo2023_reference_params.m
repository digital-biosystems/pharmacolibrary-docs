function p = Dolutegravir_Kengo2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dolutegravir   source: Kengo_2023 / reference   route: oral
  p.name  = 'Dolutegravir_Kengo2023_reference_params';
  p.drug  = 'dolutegravir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.4;                % central volume [L]
  p.CL = 1.87;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.42;                % absorption rate [1/h]
  p.F  = 0.023;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
