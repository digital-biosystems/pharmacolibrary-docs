model Methotrexate_Suzuoka2026_reference
  parameter Real Cl_ref = 1.0055555555555558e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.009949999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 2.2054718034617534e-06,
    k21 = 1.9949494949494948e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>Japanese pediatric patients with acute lymphoblastic leukemia</td></tr><tr><td>source_paper:</td><td>Suzuoka_2026</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (CV%)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ωCL (CV%)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ωVp (CV%)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ωVp (CV%)' routed out of structural estimates ('IIV')</li><li>table section residual_error: 'σ (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ (CV%)' routed out of structural estimates ('Residual variability')</li><li>column 'base / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'base / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'base / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'base / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final / estimates (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Suzuoka2026_reference;
