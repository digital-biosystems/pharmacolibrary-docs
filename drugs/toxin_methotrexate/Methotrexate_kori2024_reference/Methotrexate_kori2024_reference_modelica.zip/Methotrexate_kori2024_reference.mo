model Methotrexate_kori2024_reference
  parameter Real Cl_ref = 1.5972222222222221e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0213 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 1.134585289514867e-06,
    k21 = 2.947154471544716e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>pediatric patients with acute lymphoblastic leukemia (ALL) and non-Hodgkin's lymphoma (NHL)</td></tr><tr><td>source_paper:</td><td>Škorić_2024</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/m<sup>2</sup>' (CL)</li><li>unit_dimension_unknown: 'L/m<sup>2</sup>' (V1)</li><li>unit_dimension_unknown: 'L/m<sup>2</sup>' (V2)</li><li>unit_dimension_unknown: 'L/h/m<sup>2</sup>' (Q)</li><li>implicit units: 'clearance (CL)' → L/h (from the popPK convention: 'No units specified in text or table. Population PK convention for total clearance (CL) is L/h. The value 5.75 is consist')</li><li>implicit units: 'volume of the central compartment (V1)' → L (from the popPK convention: 'No units specified in text or table. Population PK convention for volume of distribution (V1) is L. The value 21.3 is co')</li><li>implicit units: 'volume of the peripheral compartment (V2)' → L (from the popPK convention: 'No units specified in text or table. Population PK convention for volume of distribution (V2) is L. The value 8.2 is con')</li><li>implicit units: 'intercompartmental clearance (Q)' → L/h (from the popPK convention: 'No units specified in text or table. Population PK convention for intercompartmental clearance (Q) is L/h. The value 0.0')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methotrexate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Saleh_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_kori2024_reference;
