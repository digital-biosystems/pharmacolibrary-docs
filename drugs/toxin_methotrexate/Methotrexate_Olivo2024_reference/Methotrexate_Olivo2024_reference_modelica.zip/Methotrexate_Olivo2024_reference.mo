model Methotrexate_Olivo2024_reference
  parameter Real Cl_ref = 4.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0825 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 5.993265993265992e-07,
    k21 = 8.644133644133643e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>Brazilian pediatric patients with osteosarcoma</td></tr><tr><td>source_paper:</td><td>Olivo_2024</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-01180-t003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proporcional Error' routed out of structural estimates ('Residual Variability')</li><li>table representations disagree for 'Clearance (CL)'; source reconciliation required</li><li>table representations disagree for 'Central Volume (Vc)'; source reconciliation required</li><li>table representations disagree for 'Correlation CL–Vc'; source reconciliation required</li><li>table representations disagree for 'Peripheral Volume (Vp)'; source reconciliation required</li><li>table representations disagree for 'Inter-compartmental Clearance (Q)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methotrexate</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q49 (kabs) from Saleh_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Olivo2024_reference;
