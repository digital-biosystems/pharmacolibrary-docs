function p = Methotrexate_Mao2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Mao_2022 / final   route: oral
  % estimated (absent from source): ka
  p.name  = 'Methotrexate_Mao2022_final_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.4;                % central volume [L]
  p.CL = 4.91;                % clearance [L/h]
  p.Vp = [2.18];             % peripheral volumes [L]
  p.Q  = [0.063];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
