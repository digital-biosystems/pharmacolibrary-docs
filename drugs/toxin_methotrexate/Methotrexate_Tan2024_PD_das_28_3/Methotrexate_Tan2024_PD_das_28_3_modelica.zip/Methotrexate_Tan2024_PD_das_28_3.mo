model Methotrexate_Tan2024_PD_das_28_3
  "linear exposure-response sweep — Tan_2024 :: DAS-28-3 (modified 28-joint Disease Activity Score incorporating erythrocyte sedimentation rate)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -0.025,  // [candela * meter / mole; units/(nmol/L) × 1]
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Methotrexate_Tan2024_PD_das_28_3</h4><p>The steady-state exposure-response curve of Tan JM et al., <i>British journal of clinical pharmacology 90(11):2763-2780</i> 2024 (<a href=\"https://doi.org/10.1111/bcp.16158\">doi:10.1111/bcp.16158</a>) — modified 28-joint Disease Activity Score incorporating erythrocyte sedimentation rate [units] against methotrexate polyglutamates nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -0.025 units/(nmol/L) change in response per unit of exposure (Effect of ery-MTX-PG3-5 on DAS-28-3, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of methotrexate polyglutamates per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Methotrexate_Tan2024_PD_das_28_3;
