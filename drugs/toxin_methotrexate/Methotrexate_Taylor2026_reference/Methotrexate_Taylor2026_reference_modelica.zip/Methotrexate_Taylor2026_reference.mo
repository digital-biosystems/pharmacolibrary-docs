model Methotrexate_Taylor2026_reference
  parameter Real Cl_ref = 3.277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0422 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 2.303844128488678e-06,
    k21 = 1.4576045310677996e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>adult patients with lymphoma receiving high-dose methotrexate</td></tr><tr><td>source_paper:</td><td>Taylor_2026</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>kept covariate coefficient ΘeGFR=0.80 (covariate eGFR) — not an ontology parameter</li><li>kept covariate coefficient ΘAlbumin=0.69 (covariate Albumin) — not an ontology parameter</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'eGFR'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'V1'</li><li>dropped value-less row: 'V2'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methotrexate</li><li>gap-filled Q49 (kabs) from Saleh_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Taylor2026_reference;
