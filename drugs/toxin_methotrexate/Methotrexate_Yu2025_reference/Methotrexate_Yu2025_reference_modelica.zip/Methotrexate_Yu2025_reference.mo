model Methotrexate_Yu2025_reference
  parameter Real Cl_ref = 1.238888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0159 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 2.6030747728860935e-06,
    k21 = 5.724604272322114e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>pediatric patients with ALL</td></tr><tr><td>source_paper:</td><td>Yu_2025</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('θCL age ≤1 (L/h)', value '1.69') — already have one for this compound</li><li>kept covariate coefficient θGFR=0.537 (covariate GFR) — not an ontology parameter</li><li>kept covariate coefficient θBUN=-0.0823 (covariate BUN) — not an ontology parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methotrexate</li><li>gap-filled Q49 (kabs) from Saleh_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Yu2025_reference;
