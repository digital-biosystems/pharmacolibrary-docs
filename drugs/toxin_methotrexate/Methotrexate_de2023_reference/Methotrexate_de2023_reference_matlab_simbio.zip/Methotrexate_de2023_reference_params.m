function p = Methotrexate_de2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: de_2023 / reference   route: oral
  % estimated (absent from source): ka, F
  p.name  = 'Methotrexate_de2023_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26.8;                % central volume [L]
  p.CL = 7.63;                % clearance [L/h]
  p.Vp = [8.47];             % peripheral volumes [L]
  p.Q  = [0.218];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
