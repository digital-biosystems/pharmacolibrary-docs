model Methotrexate_Taylor2023_reference
  parameter Real Cl_ref = 3.9597777777777795e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03823300000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 2.8280542986425343e-06,
    k21 = 2.853881278538813e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>pediatric and AYA patients</td></tr><tr><td>source_paper:</td><td>Taylor_2023</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13600-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Clearance (L/h/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'Serum creatinine'; source reconciliation required</li><li>table representations disagree for 'Short infusion'; source reconciliation required</li><li>table representations disagree for 'Down syndrome'; source reconciliation required</li><li>table representations disagree for 'V1 (L/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'Pleural effusion'; source reconciliation required</li><li>table representations disagree for 'Q2 (L/h/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'Hypoalbuminemia'; source reconciliation required</li><li>table representations disagree for 'V2 (L/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'Pleural effusion'; source reconciliation required</li><li>table representations disagree for 'Q3 (L/h/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'Hypoalbuminemia'; source reconciliation required</li><li>table representations disagree for 'V3 (L/1.73 m2)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Serum creatinine' — extend the ontology if this is a real PK parameter (source ['cts13600-tbl-0002:row2:col1'])</li><li>dropped unlinked row (NIL): 'Short infusion' — extend the ontology if this is a real PK parameter (source ['cts13600-tbl-0002:row3:col1'])</li><li>dropped unlinked row (NIL): 'Down syndrome' — extend the ontology if this is a real PK parameter (source ['cts13600-tbl-0002:row4:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Taylor2023_reference;
