function p = Methotrexate_Taylor2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Taylor_2023 / reference   route: oral
  % estimated (absent from source): ka, F
  p.name  = 'Methotrexate_Taylor2023_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.233;                % central volume [L]
  p.CL = 14.2552;                % clearance [L/h]
  p.Vp = [3.7887];             % peripheral volumes [L]
  p.Q  = [0.38925];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
