function p = Methotrexate_JUNG2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: JUNG_2023 / reference   route: oral
  % estimated (absent from source): ka, F
  p.name  = 'Methotrexate_JUNG2023_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.99;                % central volume [L]
  p.CL = 12.9;                % clearance [L/h]
  p.Vp = [18.76];             % peripheral volumes [L]
  p.Q  = [0.646];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
