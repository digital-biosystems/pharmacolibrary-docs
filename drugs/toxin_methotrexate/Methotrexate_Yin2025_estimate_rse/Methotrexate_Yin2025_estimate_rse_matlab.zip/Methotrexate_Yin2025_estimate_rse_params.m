function p = Methotrexate_Yin2025_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Yin_2025 / estimate_rse   route: oral
  % estimated (absent from source): ka, F
  p.name  = 'Methotrexate_Yin2025_estimate_rse_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 125.0;                % central volume [L]
  p.CL = 21.2;                % clearance [L/h]
  p.Vp = [36.7];             % peripheral volumes [L]
  p.Q  = [0.593];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
