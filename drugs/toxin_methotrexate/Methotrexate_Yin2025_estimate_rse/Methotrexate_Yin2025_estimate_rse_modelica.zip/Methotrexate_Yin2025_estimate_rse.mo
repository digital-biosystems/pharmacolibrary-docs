model Methotrexate_Yin2025_estimate_rse
  parameter Real Cl_ref = 5.888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.125 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 2.5e-06,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 1.3177777777777777e-06,
    k21 = 4.488343929760823e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>patients with central nervous system lymphoma</td></tr><tr><td>source_paper:</td><td>Yin_2025</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Prop. (CV%)' routed out of structural estimates ('Residual errors')</li><li>table section residual_error: 'Add. (SD, \\mu g/L)' routed out of structural estimates ('Residual errors')</li><li>dropped unlinked row (NIL): '\\theta_{eGFR}' — extend the ontology if this is a real PK parameter (source ['Yin_2025_table_p7_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'MATRIX' — extend the ontology if this is a real PK parameter (source ['Yin_2025_table_p7_1:row3:col1'])</li><li>dropped unlinked row (NIL): 'RMP' — extend the ontology if this is a real PK parameter (source ['Yin_2025_table_p7_1:row4:col1'])</li><li>dropped duplicate Q900 ('\\theta_{ALB}', value '0.225') — already have one for this compound</li><li>dropped duplicate Q900 ('\\theta_{ALP}', value '-0.0624') — already have one for this compound</li><li>NIL: refused to back-fill base 'V1' from footnote/prose loose number 125 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number 21.2 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methotrexate</li><li>population split: 'estimate (rse)' subgroup of Yin_2025 (paper reports 2 populations: estimate (rse), final model / estimate)</li><li>gap-filled Q49 (kabs) from Saleh_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Yin2025_estimate_rse;
