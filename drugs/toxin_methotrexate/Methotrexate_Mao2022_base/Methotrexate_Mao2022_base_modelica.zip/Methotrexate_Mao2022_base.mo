model Methotrexate_Mao2022_base
  parameter Real Cl_ref = 1.3333333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0209 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454447,
    adminMass = 0.002,
    ka = 0.0,
    Tlag = 0.0,
    k12 = 1.1961722488038277e-06,
    k21 = 4.2372881355932194e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>adult patients with primary central nervous system lymphoma</td></tr><tr><td>source_paper:</td><td>Mao_2022</td></tr><tr><td>measured_compound:</td><td>Methotrexate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.447 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'Vc/F (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'Q/F (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'Vp/F (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Proportional (%)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Objective function value' — extend the ontology if this is a real PK parameter (source ['T3:row2:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Methotrexate</li><li>model-stage split: 'base model / estimate' is the base model of Mao_2022 (paper reports 2 stages: base model / estimate, final model / estimate); same population, different model-building step</li><li>gap-filled Q49 (kabs) from Saleh_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Mao2022_base;
