model Methotrexate_Taylor2026_PD_aki
  "log_linear exposure-response sweep — Taylor_2026 :: AKI (Acute kidney injury (any stage))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 1020   "[(1)/(mol/m3); per µmol/L × 1000]";
equation
  response = E0 + slope*log(exposure);
  // slope_unit_assumed: slope unit 'per µmol/L' read as response per µmol/L
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Methotrexate_Taylor2026_PD_aki</h4><p>The steady-state exposure-response curve of Taylor ZL et al., <i>Clinical pharmacokinetics 65(3):465-477</i> 2026 (<a href=\"https://doi.org/10.1007/s40262-026-01618-4\">doi:10.1007/s40262-026-01618-4</a>) — Acute kidney injury (any stage) against Methotrexate µmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       1.02 per µmol/L change in response per unit of exposure (Odds Ratio (4-h MTX concentration), Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one µmol/L of Methotrexate per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Methotrexate_Taylor2026_PD_aki;
