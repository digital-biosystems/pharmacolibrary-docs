function p = Methotrexate_Taylor2026_PD_aki_params()
% Methotrexate_Taylor2026_PD_aki_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methotrexate Taylor_2026::AKI: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µmol/L per second, in SI inside (kg/m3, s). Response AKI in its own unit. Driver: Methotrexate (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1020.0000000000002;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
