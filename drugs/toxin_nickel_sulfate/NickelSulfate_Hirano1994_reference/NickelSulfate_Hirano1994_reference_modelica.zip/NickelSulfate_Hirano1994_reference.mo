// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model NickelSulfate_Hirano1994_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {115200.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nickel_sulfate</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Hirano_1994</td></tr><tr><td>measured_compound:</td><td>Nickel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>nickel_sulfate 154.749 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'initial lung burden' — extend the ontology if this is a real PK parameter (source ['Hirano_1994:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nickel</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none of 1 PubChem candidate(s) is 'Nickel' (LLM) — left in mass units</li><li>molar mass: none found for 'Nickel' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Nickel', not nickel_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end NickelSulfate_Hirano1994_reference;
