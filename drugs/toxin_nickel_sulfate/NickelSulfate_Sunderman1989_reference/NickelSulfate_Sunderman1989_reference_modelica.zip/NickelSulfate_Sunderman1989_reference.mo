// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model NickelSulfate_Sunderman1989_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {100800.0},
    MM = 0.058692999999999995,
    adminMass = 8.4e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nickel_sulfate</td></tr><tr><td>population:</td><td>healthy human volunteers</td></tr><tr><td>source_paper:</td><td>Sunderman_1989</td></tr><tr><td>measured_compound:</td><td>Nickel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Nickel 58.693 g/mol (pubchem); nickel_sulfate 154.749 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'C,,, ml/min/l.73 m2' (CLR)</li><li>covariate effect for Q49 has no base parameter row (kept as unattached equation-variable)</li><li>salvaged Q57 ('The elimination half-time (tl,J for absorbed nickel'=28) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nickel</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>review gap-fill skipped: this record measures 'Nickel', not nickel_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end NickelSulfate_Sunderman1989_reference;
