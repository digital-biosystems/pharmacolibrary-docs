function p = Morphine_Bardol2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: morphine   source: Bardol_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Morphine_Bardol2025_reference_params';
  p.drug  = 'morphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 358.076909;                % central volume [L]
  p.CL = 14.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
