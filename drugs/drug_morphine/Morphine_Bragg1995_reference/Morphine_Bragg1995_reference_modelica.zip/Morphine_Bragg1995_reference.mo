model Morphine_Bragg1995_reference
  parameter Real Cl_ref = 9.38e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01701 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28533769999999997,
    adminMass = 3e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About morphine</h4><p>Morphine is an opioid painkiller used to treat pain, and also dyspnea and fibromyalgia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q81225\">Wikidata Q81225</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>neonatal dogs</td></tr><tr><td>source_paper:</td><td>Bragg_1995</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>morphine 285.338 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Clrapid, ml·kg-1·min-1' — extend the ontology if this is a real PK parameter (source ['Bragg_1995_table_1:row2:col1'])</li><li>dropped duplicate Q22 ('Clslow, ml·kg-1·min-1', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=morphine</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Morphine_Bragg1995_reference;
