model Morphine_Andersen1986_j
  parameter Real Cl_ref = 7.034999999999999e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0462 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28533769999999997,
    adminMass = 5.0000000000000004e-08,
    k21 = 3.036576949620428e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About morphine</h4><p>Morphine is an opioid painkiller used to treat pain, and also dyspnea and fibromyalgia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q81225\">Wikidata Q81225</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>goats</td></tr><tr><td>source_paper:</td><td>Andersen_1986</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>morphine 285.338 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12.</p><h4>Interpretation flags</h4><ul><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'j' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=morphine</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'j' subgroup of Andersen_1986 (paper reports 5 populations: f, j, k, n, o)</li><li>gap-filled Q30 (Q) from Elkomy_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Morphine_Andersen1986_j;
