function p = Morphine_Franken2016_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: morphine   source: Franken_2016 / final   route: iv_bolus
  p.name  = 'Morphine_Franken2016_final_params';
  p.drug  = 'morphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.24;                % central volume [L]
  p.CL = 1.78;                % clearance [L/h]
  p.Vp = [243.0];             % peripheral volumes [L]
  p.Q  = [76.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.3;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
