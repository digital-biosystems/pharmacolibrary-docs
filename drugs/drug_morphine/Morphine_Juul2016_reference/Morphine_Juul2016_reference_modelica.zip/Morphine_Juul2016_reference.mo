model Morphine_Juul2016_reference
  parameter Real Cl_ref = 1.8250000000000003e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006500000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28533769999999997,
    adminMass = 0.0001,
    ka = 0.00036666666666666667,
    Tlag = 846.0,
    k12 = 0.0032478632478632474,
    k21 = 0.0002936176788749807
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About morphine</h4><p>Morphine is an opioid painkiller used to treat pain, and also dyspnea and fibromyalgia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q81225\">Wikidata Q81225</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>patients receiving morphine on request after hip surgery</td></tr><tr><td>source_paper:</td><td>Juul_2016</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>morphine 285.338 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'FIR' — extend the ontology if this is a real PK parameter (source ['Juul_2016_table_2:row6:col2'])</li><li>dropped duplicate Q49 ('ka,CR', value '0.207') — already have one for this compound</li><li>dropped duplicate Q83 ('tlag,CR', value '0.25') — already have one for this compound</li><li>dropped unlinked row (NIL): 'FCR' — extend the ontology if this is a real PK parameter (source ['Juul_2016_table_2:row9:col2'])</li><li>routed 'PropErrIV' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'AddErrIV' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'PropErrIR' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'PropErrCR' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CI); Q61 (V); Q30 (Q); Q64 (V2)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=morphine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Morphine_Juul2016_reference;
