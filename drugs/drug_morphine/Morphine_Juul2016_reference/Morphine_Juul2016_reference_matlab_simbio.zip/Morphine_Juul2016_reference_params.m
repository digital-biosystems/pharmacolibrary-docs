function p = Morphine_Juul2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: morphine   source: Juul_2016 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Morphine_Juul2016_reference_params';
  p.drug  = 'morphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.5;                % central volume [L]
  p.CL = 65.7;                % clearance [L/h]
  p.Vp = [71.9];             % peripheral volumes [L]
  p.Q  = [76.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.32;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.235;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
