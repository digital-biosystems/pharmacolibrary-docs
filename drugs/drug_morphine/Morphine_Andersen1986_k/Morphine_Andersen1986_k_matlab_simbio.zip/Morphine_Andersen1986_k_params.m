function p = Morphine_Andersen1986_k_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: morphine   source: Andersen_1986 / k   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Morphine_Andersen1986_k_params';
  p.drug  = 'morphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 32.2;                % central volume [L]
  p.CL = 272.16;                % clearance [L/h]
  p.Vp = [113.4];             % peripheral volumes [L]
  p.Q  = [0.88];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.05;             % dose [mg]
end
