function p = Morphine_Ihmsen2021_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: morphine   source: Ihmsen_2021 / reference   PK_3M_9C parent + 1 metabolite(s), 5 compartments, IV bolus
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=285.338 g/mol C_M1=461.5 g/mol
  p.name  = 'Morphine_Ihmsen2021_reference_params';
  p.drug  = 'morphine';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'peripheral2', 'central_M1', 'peripheral_M1'};
  p.V = [8.1, 18.4, 165.0, 5.5, 10.3];          % compartment volumes [L]
  p.K = [-18.592592592592595, 3.782608695652174, 0.0, 0.0, 0.0;
         8.592592592592592, -3.782608695652174, 0.0, 0.0, 0.0;
         0.0, 0.0, 0.0, 0.0, 0.0;
         1.6173817900684, 0.0, 0.0, -1.8109090909090915, 0.396116504854369;
         0.0, 0.0, 0.0, 0.741818181818182, -0.396116504854369];
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;
  p.dose_into = 1;   % central
  p.ka = 60.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 30.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 4.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'morphine', 'morphine-6-glucuronide'};
end
