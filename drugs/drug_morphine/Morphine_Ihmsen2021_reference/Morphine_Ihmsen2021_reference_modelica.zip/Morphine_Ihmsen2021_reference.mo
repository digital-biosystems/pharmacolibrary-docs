// parent + metabolites (morphine-6-glucuronide): PK_3M_9C — formed from central; parent 3, metabolites [2]
model Morphine_Ihmsen2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0081,
    Vd2 = 0.0184,
    Vd3 = 0.165,
    q12 = 1.9333333333333333e-05,
    q21 = 1.9333333333333333e-05,
    q1_m11 = 2.25e-06,
    CL1 = 2.025e-05,
    Vd1m1 = 0.0055,
    CLm1 = 1.6333333333333335e-06,
    Vd2m1 = 0.0103,
    qm11_m12 = 1.1333333333333336e-06,
    qm12_m11 = 1.1333333333333336e-06,
    MW = 0.28533769999999997,
    MW_m1 = 0.4615,
    F = 1,
    adminMass = 0,
    infusionMass = 3e-05,
    infusionDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About morphine</h4><p>Morphine is an opioid painkiller used to treat pain, and also dyspnea and fibromyalgia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q81225\">Wikidata Q81225</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>adults undergoing cardiac surgery</td></tr><tr><td>source_paper:</td><td>Ihmsen_2021</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_3M_9C: IV / parenteral into the parent central compartment; formation of morphine-6-glucuronide: fm=0.1 × CL; dose 30 mg (WHO ATC DDD 30 mg parenteral (N02AA01))</td></tr><tr><td>molar_masses:</td><td>morphine 285.338 g/mol (drugbank); morphine-6-glucuronide 461.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>compound tags: 4 row(s) → morphine-6-glucuronide (m_suffix 4)</li><li>table section iiv: 'CL (L/min)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'Q₂ (L/min)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'Q₃ (L/min)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'V₁ (L)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'V₂ (L)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'V₃ (L)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'K_M (1/min)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'CL_M (L/min)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'Q_2M (L/min)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'V_1M (L)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>table section iiv: 'V_2M (L)' routed out of structural estimates ('Model fit BSV (%CV)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=morphine</li><li>template fit: PK_3M_9C — formed from central; parent 3, metabolites [2]</li><li>row roles (LLM): model_class=compartmental; 15/15 row label(s) assigned, 23 linked by role; re-tagged parent→morphine-6-glucuronide ×13</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Morphine_Ihmsen2021_reference;
