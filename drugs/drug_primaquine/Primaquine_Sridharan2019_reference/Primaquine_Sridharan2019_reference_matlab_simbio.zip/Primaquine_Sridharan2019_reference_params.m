function p = Primaquine_Sridharan2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: primaquine   source: Sridharan_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Primaquine_Sridharan2019_reference_params';
  p.drug  = 'primaquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.9;                % central volume [L]
  p.CL = 10.34;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 18.08;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
