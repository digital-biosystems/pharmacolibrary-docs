function p = Benralizumab_Yan2019_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: benralizumab   source: Yan_2019 / final   route: iv_bolus
  p.name  = 'Benralizumab_Yan2019_final_params';
  p.drug  = 'benralizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.13;                % central volume [L]
  p.CL = 0.012125;                % clearance [L/h]
  p.Vp = [2.52];             % peripheral volumes [L]
  p.Q  = [0.03075];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.589;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
