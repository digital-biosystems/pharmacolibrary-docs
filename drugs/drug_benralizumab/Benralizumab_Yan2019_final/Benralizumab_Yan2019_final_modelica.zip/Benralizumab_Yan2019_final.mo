model Benralizumab_Yan2019_final
  parameter Real Cl_ref = 3.3680555555555554e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00313 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-06,
    k12 = 2.7289669861554847e-06,
    k21 = 3.3895502645502645e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About benralizumab</h4><p>Benralizumab is a monoclonal antibody used as an antiasthmatic drug for obstructive airway disease, and has also been studied for chronic spontaneous urticaria. It is authorised in the European Union for asthma and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3638304\">Wikidata Q3638304</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>benralizumab</td></tr><tr><td>population:</td><td>adult and adolescent patients with asthma</td></tr><tr><td>source_paper:</td><td>Yan_2019</td></tr><tr><td>measured_compound:</td><td>benralizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ηCL, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηCL, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηVc, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηVc, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηQ, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηVp, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηVp, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηka (half-life), %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηka (half-life), %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηF, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηF, %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηF (study CP220), %CV' routed out of structural estimates ('IIV')</li><li>table section iiv: 'ηF (study CP220), %CV' routed out of structural estimates ('IIV')</li><li>table section residual_error: 'Proportional error, %CV' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error, %CV' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (study CP220), %CV' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Benralizumab_Yan2019_final;
