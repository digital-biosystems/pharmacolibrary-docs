function p = Buspirone_Li2012_PD_pfc_dopamine_params()
% Buspirone_Li2012_PD_pfc_dopamine_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buspirone Li_2012::PFC_dopamine: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PFC dopamine in nM. Driver: buspirone (cited_pk).
p.E0 = 10.5;
p.Emax = 56.9;
p.EC50 = 0.000147;
p.gamma = 1.06;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 230.0;
p.form = 'E0/(1 + Emax*frac)';
end
