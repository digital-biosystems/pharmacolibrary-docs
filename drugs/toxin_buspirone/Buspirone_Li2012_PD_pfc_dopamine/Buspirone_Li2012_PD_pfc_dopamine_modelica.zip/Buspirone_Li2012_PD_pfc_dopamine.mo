model Buspirone_Li2012_PD_pfc_dopamine
  "indirect_response_i exposure-response sweep — Li_2012 :: PFC dopamine (Prefrontal cortex dopamine levels)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 10.5,      // [nM]
    Emax = 56.9,  // type IV effect term
    EC50 = 0.000147,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.06,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 56.9; bound as the reciprocal stimulation form (IV) the paper fitted
  annotation(experiment(StartTime = 0, StopTime = 230, Interval = 0.46),
    Documentation(info = "<html><body><h4>Buspirone_Li2012_PD_pfc_dopamine</h4><p>The steady-state exposure-response curve of Li CS et al., <i>The AAPS journal 14(2):365–376</i> 2012 (<a href=\"https://doi.org/10.1208/s12248-012-9343-8\">doi:10.1208/s12248-012-9343-8</a>) — Prefrontal cortex dopamine levels [nM] against buspirone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       10.5 nM       drug-free response (baseline) (Baseline Dopamine (E0), Q324)
  Emax  =       56.9          maximal effect term (Smax (Buspirone), Q323)
  EC50  =        147 ng/mL    exposure at half of the maximal effect term (SC50 (Buspirone), Q321)
  gamma =       1.06          Hill coefficient (Gamma (Buspirone/5-HT1A), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of buspirone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 10.5   (drug-free)
  exposure = EC50 (147 ng/mL)  response 0.3565
  exposure -> infinity  response 0.1813</pre></body></html>"));
end Buspirone_Li2012_PD_pfc_dopamine;
