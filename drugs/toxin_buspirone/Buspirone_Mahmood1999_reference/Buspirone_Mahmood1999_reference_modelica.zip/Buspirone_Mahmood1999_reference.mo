model Buspirone_Mahmood1999_reference
  parameter Real Cl_ref = 3.3055555555555553e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.371 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.385512,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>buspirone</td></tr><tr><td>population:</td><td>healthy volunteers, patients with renal impairment, patients with hep impairment</td></tr><tr><td>source_paper:</td><td>Mahmood_1999</td></tr><tr><td>measured_compound:</td><td>Buspirone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>1-pyrimidinylpiperazine (1-PP) 164.212 g/mol (pubchem); Buspirone 385.512 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'dose range' — extend the ontology if this is a real PK parameter (source ['Mahmood_1999:abstract'])</li><li>unit_dimension_unknown: 'times' (t1/2z)</li><li>dropped duplicate Q57 ('half-life of buspirone in patients with hepatic impairment', value 2) — already have one for this compound</li><li>unit_dimension_unknown: 'fold' (Cmax)</li><li>unit_dimension_unknown: 'fold' (AUC)</li><li>implicit units: 'Cmax' → ng/mL (from the popPK convention: 'No unit specified in text. Cmax magnitude of 15 is most consistent with ng/mL or µg/mL for typical drugs. ng/mL is a ver')</li><li>implicit units: 'AUC' → ng*h/mL (from the popPK convention: 'No unit specified in text. AUC is the area under the concentration-time curve. If Cmax is assumed to be in ng/mL, AUC is')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Buspirone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles: 2 per-group rows of Buspirone other but 2 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=noncompartmental; 7/7 row label(s) assigned, 4 linked by role; re-tagged Buspirone→parent ×6</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Buspirone_Mahmood1999_reference;
