function p = Fluvoxamine_Geldof2008v2_PD_5_ht_params()
% Fluvoxamine_Geldof2008v2_PD_5_ht_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluvoxamine Geldof_2008_2::5_HT: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response 5-HT in its own unit. Driver: fluvoxamine (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.1e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 11.0;
p.form = 'E0*(1 - Emax*frac)';
end
