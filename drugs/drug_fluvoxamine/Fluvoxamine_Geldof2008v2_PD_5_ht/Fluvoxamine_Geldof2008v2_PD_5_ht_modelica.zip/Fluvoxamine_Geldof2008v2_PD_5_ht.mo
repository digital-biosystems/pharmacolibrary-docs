model Fluvoxamine_Geldof2008v2_PD_5_ht
  "indirect_response_i exposure-response sweep — Geldof_2008_2 :: 5-HT (5-HT)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.1e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluvoxamine</h4><p>Fluvoxamine is a selective serotonin reuptake inhibitor used to treat major depressive disorder and obsessive-compulsive disorder. It is given by mouth in various solid dosage forms. This medication is a standard option in psychiatric care and appears on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q409236\">Wikidata Q409236</a>, <a href=\"https://en.wikipedia.org/wiki/Fluvoxamine?oldid=1382841354\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluvoxamine_Geldof2008v2_PD_5_ht</h4><p>The steady-state exposure-response curve of Geldof M et al., <i>European journal of pharmaceutical sciences : official journal of the European Federation for Pharmaceutical Sciences 33(3):217–229</i> 2008 (<a href=\"https://doi.org/10.1016/j.ejps.2007.12.001\">doi:10.1016/j.ejps.2007.12.001</a>) — 5-HT against fluvoxamine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =        1.1 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of fluvoxamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.1 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Fluvoxamine_Geldof2008v2_PD_5_ht;
