function p = Fluvoxamine_Eugene2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluvoxamine   source: Eugene_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Fluvoxamine_Eugene2021_reference_params';
  p.drug  = 'fluvoxamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1480.0;                % central volume [L]
  p.CL = 29.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.67;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
