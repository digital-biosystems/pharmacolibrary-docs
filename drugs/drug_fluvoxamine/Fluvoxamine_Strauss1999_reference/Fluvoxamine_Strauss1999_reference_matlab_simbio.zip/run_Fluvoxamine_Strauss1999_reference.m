% Run (SimBiology): build model + dose, simulate 0..288.0 h, plot.
p = Fluvoxamine_Strauss1999_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 288.0);
