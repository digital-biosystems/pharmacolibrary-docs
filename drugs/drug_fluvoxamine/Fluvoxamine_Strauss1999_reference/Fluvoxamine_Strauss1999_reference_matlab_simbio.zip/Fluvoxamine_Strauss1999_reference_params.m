function p = Fluvoxamine_Strauss1999_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluvoxamine   source: Strauss_1999 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Fluvoxamine_Strauss1999_reference_params';
  p.drug  = 'fluvoxamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 78.4;                % central volume [L]
  p.CL = 1.01;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.0185;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
