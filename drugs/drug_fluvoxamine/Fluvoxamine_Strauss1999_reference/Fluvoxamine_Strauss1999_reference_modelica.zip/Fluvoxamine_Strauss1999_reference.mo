model Fluvoxamine_Strauss1999_reference
  parameter Real Cl_ref = 2.8055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07840000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31833999999999996,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fluvoxamine</h4><p>Fluvoxamine is a selective serotonin reuptake inhibitor used to treat major depressive disorder and obsessive-compulsive disorder. It is given by mouth in various solid dosage forms. This medication is a standard option in psychiatric care and appears on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q409236\">Wikidata Q409236</a>, <a href=\"https://en.wikipedia.org/wiki/Fluvoxamine?oldid=1382841354\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluvoxamine</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Strauss_1999</td></tr><tr><td>measured_compound:</td><td>fluvoxamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fluvoxamine 318.34 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fluvoxamine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Fluvoxamine_Strauss1999_reference;
