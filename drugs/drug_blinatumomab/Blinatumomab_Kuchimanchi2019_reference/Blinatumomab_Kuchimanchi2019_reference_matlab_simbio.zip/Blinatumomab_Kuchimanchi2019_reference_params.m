function p = Blinatumomab_Kuchimanchi2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: blinatumomab   source: Kuchimanchi_2019 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Blinatumomab_Kuchimanchi2019_reference_params';
  p.drug  = 'blinatumomab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.35;                % central volume [L]
  p.CL = 3.11;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.0187;             % dose [mg]
end
