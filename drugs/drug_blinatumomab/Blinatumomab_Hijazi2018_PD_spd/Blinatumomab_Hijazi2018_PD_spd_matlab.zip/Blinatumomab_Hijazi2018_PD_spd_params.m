function p = Blinatumomab_Hijazi2018_PD_spd_params()
% Blinatumomab_Hijazi2018_PD_spd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% blinatumomab Hijazi_2018::SPD: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h×µg/L per second, in SI inside (kg/m3, s). Response SPD in fold. Driver: Blinatumomab (pk_record).
p.E0 = 0.0;
p.Emax = -1.15;
p.EC50 = 1000.0;
p.gamma = 1.5;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 10000.0;
p.form = 'E0 + Emax*frac';
end
