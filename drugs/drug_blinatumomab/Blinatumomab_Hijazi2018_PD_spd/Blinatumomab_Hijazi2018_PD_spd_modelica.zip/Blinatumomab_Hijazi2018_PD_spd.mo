model Blinatumomab_Hijazi2018_PD_spd
  "sigmoid_emax exposure-response sweep — Hijazi_2018 :: SPD (Sum of Longest Perpendicular Dimensions (SPD))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.15,  // [fold]
    EC50 = 1000,  // [h×µg/L]
    gamma = 1.5,
    exposure_per_s = 1);   // 1 h×µg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'h×µg/L' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 10000, Interval = 20),
    Documentation(info = "<html><body><!-- drug-about --><h4>About blinatumomab</h4><p>Blinatumomab is a monoclonal antibody anticancer medicine used to treat a form of lymphoblastic leukaemia-lymphoma. It is authorised in the European Union and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410189\">Wikidata Q410189</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Blinatumomab_Hijazi2018_PD_spd</h4><p>The steady-state exposure-response curve of Hijazi Y et al., <i>Current clinical pharmacology 13(1):55–64</i> 2018 (<a href=\"https://doi.org/10.2174/1574884713666180518102514\">doi:10.2174/1574884713666180518102514</a>) — Sum of Longest Perpendicular Dimensions (SPD) [fold] against Blinatumomab h×µg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.15 fold     maximal effect term (Emax, Q323)
  EC50  =       1000 h×µg/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.5          Hill coefficient (ɣ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one h×µg/L of Blinatumomab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1000 h×µg/L)  response -0.575
  exposure -> infinity  response -1.15</pre></body></html>"));
end Blinatumomab_Hijazi2018_PD_spd;
