model Blinatumomab_Hijazi2018_reference
  parameter Real Cl_ref = 6.25e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.007920395774480409 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.8700000000000002e-08
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About blinatumomab</h4><p>Blinatumomab is a monoclonal antibody anticancer medicine used to treat a form of lymphoblastic leukaemia-lymphoma. It is authorised in the European Union and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410189\">Wikidata Q410189</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>blinatumomab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Hijazi_2018</td></tr><tr><td>measured_compound:</td><td>blinatumomab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Hijazi_2018) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Blinatumomab_Hijazi2018_reference;
