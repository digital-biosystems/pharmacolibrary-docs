function p = Blinatumomab_Hijazi2018_PD_kdep_params()
% Blinatumomab_Hijazi2018_PD_kdep_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% blinatumomab Hijazi_2018::kdep: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/mL per second, in SI inside (kg/m3, s). Response kdep in %/hour. Driver: Blinatumomab (pk_record).
p.E0 = 0.0;
p.Emax = -0.00022500000000000002;
p.EC50 = 1.4560000000000001e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 15000.0;
p.form = 'E0 + Emax*frac';
end
