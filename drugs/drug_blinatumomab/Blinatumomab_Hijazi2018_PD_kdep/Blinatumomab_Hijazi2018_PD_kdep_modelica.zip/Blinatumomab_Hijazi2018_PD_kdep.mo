model Blinatumomab_Hijazi2018_PD_kdep
  "emax exposure-response sweep — Hijazi_2018 :: kdep (B-cell-specific depletion rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000225,  // [1/s; %/hour × 2.77778e-06]
    EC50 = 1.456e-06,  // [kg/m3; pg/mL × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 15000, Interval = 30),
    Documentation(info = "<html><body><!-- drug-about --><h4>About blinatumomab</h4><p>Blinatumomab is a monoclonal antibody anticancer medicine used to treat a form of lymphoblastic leukaemia-lymphoma. It is authorised in the European Union and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410189\">Wikidata Q410189</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Blinatumomab_Hijazi2018_PD_kdep</h4><p>The steady-state exposure-response curve of Hijazi Y et al., <i>Current clinical pharmacology 13(1):55–64</i> 2018 (<a href=\"https://doi.org/10.2174/1574884713666180518102514\">doi:10.2174/1574884713666180518102514</a>) — B-cell-specific depletion rate [%/hour] against Blinatumomab pg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         81 %/hour   maximal effect term (kdep,max, Q323)
  EC50  =       1456 pg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pg/mL of Blinatumomab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1456 pg/mL)  response -0.0001125
  exposure -> infinity  response -0.000225</pre></body></html>"));
end Blinatumomab_Hijazi2018_PD_kdep;
