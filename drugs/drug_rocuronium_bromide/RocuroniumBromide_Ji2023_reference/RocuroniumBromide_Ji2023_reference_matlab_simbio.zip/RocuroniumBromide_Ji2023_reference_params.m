function p = RocuroniumBromide_Ji2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rocuronium_bromide   source: Ji_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'RocuroniumBromide_Ji2023_reference_params';
  p.drug  = 'rocuronium_bromide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.49;                % central volume [L]
  p.CL = 4.2;                % clearance [L/h]
  p.Vp = [2.26];             % peripheral volumes [L]
  p.Q  = [11.28];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
