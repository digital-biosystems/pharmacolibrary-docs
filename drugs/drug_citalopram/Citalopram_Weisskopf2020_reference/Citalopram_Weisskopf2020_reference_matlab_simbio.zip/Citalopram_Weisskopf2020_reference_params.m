function p = Citalopram_Weisskopf2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: citalopram   source: Weisskopf_2020 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Citalopram_Weisskopf2020_reference_params';
  p.drug  = 'citalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1310.0;                % central volume [L]
  p.CL = 28.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
