function p = Fexofenadine_Molimard2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fexofenadine   source: Molimard_2004 / reference   route: oral
  p.name  = 'Fexofenadine_Molimard2004_reference_params';
  p.drug  = 'fexofenadine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.0;                % central volume [L]
  p.CL = 114.64;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.282;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
