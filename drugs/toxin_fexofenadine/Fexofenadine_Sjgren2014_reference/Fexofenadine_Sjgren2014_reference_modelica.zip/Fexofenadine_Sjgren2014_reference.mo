// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Fexofenadine_Sjgren2014_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6120.0},
    MM = 0.501667,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fexofenadine</td></tr><tr><td>population:</td><td>pigs</td></tr><tr><td>source_paper:</td><td>Sjögren_2014</td></tr><tr><td>measured_compound:</td><td>Fexofenadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>fexofenadine 501.667 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for AUC from footnote/prose kept as documentation only (['Sjögren_2014:abstract'])</li><li>covariate renal for CLR from footnote/prose kept as documentation only (['Sjögren_2014:abstract'])</li><li>dropped 'biliary clearance' → Q23 = -53: a clearance of -53 is not a parameter value (source ['Sjögren_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fexofenadine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Mahajan_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Mahajan_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gaspar_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Fexofenadine_Sjgren2014_reference;
