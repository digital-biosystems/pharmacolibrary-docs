model Gemfibrozil_Kobuchi2025_gemfibrozil_cerivastatin
  parameter Real Cl_ref = 1.647294225404808e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.38499999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.250338,
    adminMass = 0.0012,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gemfibrozil</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kobuchi_2025</td></tr><tr><td>measured_compound:</td><td>Gemfibrozil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Gemfibrozil 250.338 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 't1/2 (h)'; source reconciliation required</li><li>table representations disagree for 'Tmax (h)'; source reconciliation required</li><li>table representations disagree for 'Cmax (μg/mL)'; source reconciliation required</li><li>table representations disagree for 'Vd/F (L/kg)'; source reconciliation required</li><li>table representations disagree for 'CLtot/F (L/h/kg)'; source reconciliation required</li><li>table representations disagree for 'AUC0-∞ (μg∙h/mL)'; source reconciliation required</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 8 (source ['T4:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'Each value represents the mean ± S.D. (n=5-10)' (captured trailing unit 'n=5-10' for child rows)</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 0.05 (source ['T4:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Gemfibrozil</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'gemfibrozil / + cerivastatin' subgroup of Kobuchi_2025 (paper reports 2 populations: gemfibrozil / + cerivastatin, gemfibrozil / mono)</li><li>row roles (LLM): model_class=noncompartmental; 0/9 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Gemfibrozil_Kobuchi2025_gemfibrozil_cerivastatin;
