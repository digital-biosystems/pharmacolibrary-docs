function p = Rutoside_Domnguez2024_extract_equivalent_to_7_4_mg_kg_of_rut_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rutoside   source: Domínguez_2024 / extract_equivalent_to_7_4_mg_kg_of_rutin   route: iv_bolus
  p.name  = 'Rutoside_Domnguez2024_extract_equivalent_to_7_4_mg_kg_of_rut_params';
  p.drug  = 'rutoside';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.88;                % central volume [L]
  p.CL = 5.53;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.12;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.9;             % dose [mg]
end
