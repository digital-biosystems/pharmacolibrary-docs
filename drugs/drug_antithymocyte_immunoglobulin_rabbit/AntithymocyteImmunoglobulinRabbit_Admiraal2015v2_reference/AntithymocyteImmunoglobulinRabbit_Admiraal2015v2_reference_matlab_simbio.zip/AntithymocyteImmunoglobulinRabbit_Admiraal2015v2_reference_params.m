function p = AntithymocyteImmunoglobulinRabbit_Admiraal2015v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: antithymocyte_immunoglobulin_rabbit   source: Admiraal_2015_2 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'AntithymocyteImmunoglobulinRabbit_Admiraal2015v2_reference_params';
  p.drug  = 'antithymocyte_immunoglobulin_rabbit';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.84;                % central volume [L]
  p.CL = 2.12;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
