model Azathioprine_Odlind1986_reference
  parameter Real Cl_ref = 0.00011500000000000003 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004019999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.277262,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>azathioprine</td></tr><tr><td>population:</td><td>uremic patients</td></tr><tr><td>source_paper:</td><td>Odlind_1986</td></tr><tr><td>measured_compound:</td><td>Azathioprine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>6-mercaptopurine 152.175 g/mol (pubchem); Azathioprine 277.262 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 't1/2 alpha' Q47 → Q59: a half-life by its label (the unit decides, not the label)</li><li>relinked 't1/2 beta' Q47 → Q60: a half-life by its label (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'minimum effective concentration of 6-MP' — extend the ontology if this is a real PK parameter (source ['Odlind_1986:abstract'])</li><li>implicit units: 'AUC' → mg*h/L (from the popPK convention: 'No unit is provided in the paper. The magnitude 18 is consistent with typical AUC values expressed in mass-concentration')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Azathioprine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 6 linked by role; re-tagged Azathioprine→parent ×8, Azathioprine→6-mercaptopurine ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Rosario_2017's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Rosario_2017 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Azathioprine_Odlind1986_reference;
