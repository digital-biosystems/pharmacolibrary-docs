model Azathioprine_Rosario2017_reference
  parameter Real Cl_ref = 4.768518518518518e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004019999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.277262,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>azathioprine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Rosario_2017</td></tr><tr><td>measured_compound:</td><td>azathioprine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>azathioprine 277.262 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Rosario_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Azathioprine_Rosario2017_reference;
