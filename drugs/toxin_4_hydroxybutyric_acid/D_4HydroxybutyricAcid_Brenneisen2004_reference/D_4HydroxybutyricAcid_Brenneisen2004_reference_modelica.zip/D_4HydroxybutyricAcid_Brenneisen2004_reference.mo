model D_4HydroxybutyricAcid_Brenneisen2004_reference
  parameter Real Cl_ref = 2.046666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.052700000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.104105,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4_hydroxybutyric_acid</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Brenneisen_2004</td></tr><tr><td>measured_compound:</td><td>4-Hydroxybutyric acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>4-Hydroxybutyric acid 104.105 g/mol (pubchem); 4_hydroxybutyric_acid 103.097 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-Hydroxybutyric acid</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_4HydroxybutyricAcid_Brenneisen2004_reference;
