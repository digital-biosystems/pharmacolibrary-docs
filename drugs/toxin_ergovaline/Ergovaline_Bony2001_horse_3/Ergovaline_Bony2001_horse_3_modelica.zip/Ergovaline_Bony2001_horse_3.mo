model Ergovaline_Bony2001_horse_3
  parameter Real Cl_ref = 3.033333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00595 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.533629,
    adminMass = 1.0500000000000001e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ergovaline</td></tr><tr><td>population:</td><td>four gelding horses</td></tr><tr><td>source_paper:</td><td>Bony_2001</td></tr><tr><td>measured_compound:</td><td>Ergovaline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ergovaline 533.629 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ergovaline</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc (L/kg)' is the general volume)</li><li>population split: 'horse 3' subgroup of Bony_2001 (paper reports 4 populations: horse 1, horse 2, horse 3, horse 4)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ergovaline_Bony2001_horse_3;
