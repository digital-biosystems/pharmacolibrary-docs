function p = Ergovaline_Bony2001_horse_4_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ergovaline   source: Bony_2001 / horse_4   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ergovaline_Bony2001_horse_4_params';
  p.drug  = 'ergovaline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.46;                % central volume [L]
  p.CL = 75.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.05;             % dose [mg]
end
