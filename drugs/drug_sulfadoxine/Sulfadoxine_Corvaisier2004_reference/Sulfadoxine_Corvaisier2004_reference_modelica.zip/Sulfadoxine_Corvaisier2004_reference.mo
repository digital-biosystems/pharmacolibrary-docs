model Sulfadoxine_Corvaisier2004_reference
  parameter Real Cl_ref = 7.143851944444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.30653 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002541666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadoxine</h4><p>Sulfadoxine is a long-acting sulfonamide used to treat malaria and pneumocystosis. It is administered orally in tablet or suspension form. It is widely used to prevent or treat infections in livestock.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411557\">Wikidata Q411557</a>, <a href=\"https://en.wikipedia.org/wiki/Sulfadoxine?oldid=1306736143\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadoxine</td></tr><tr><td>population:</td><td>children with congenital toxoplasmosis</td></tr><tr><td>source_paper:</td><td>Corvaisier_2004</td></tr><tr><td>measured_compound:</td><td>sulfadoxine, pyrimethamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulfadoxine 310.329 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volumes of distribution)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulfadoxine, pyrimethamine</li><li>molar mass: none of 1 PubChem candidate(s) is 'sulfadoxine, pyrimethamine' (LLM) — left in mass units</li><li>molar mass: none found for 'sulfadoxine, pyrimethamine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL=2.57179 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Sulfadoxine_Corvaisier2004_reference;
