% Run (SimBiology): build model + dose, simulate 0..1680.0 h, plot.
p = Sulfadoxine_de2017_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1680.0);
