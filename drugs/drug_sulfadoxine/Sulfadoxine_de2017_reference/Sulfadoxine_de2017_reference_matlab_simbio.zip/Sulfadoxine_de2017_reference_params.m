function p = Sulfadoxine_de2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulfadoxine   source: de_2017 / reference   route: oral
  p.name  = 'Sulfadoxine_de2017_reference_params';
  p.drug  = 'sulfadoxine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.1;                % central volume [L]
  p.CL = 0.0303;                % clearance [L/h]
  p.Vp = [179.0];             % peripheral volumes [L]
  p.Q  = [0.0252];             % inter-compartmental clearances [L/h]
  p.ka = 0.531;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
