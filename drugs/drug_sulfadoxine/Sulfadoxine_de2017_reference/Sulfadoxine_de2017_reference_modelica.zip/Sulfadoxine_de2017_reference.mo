model Sulfadoxine_de2017_reference
  parameter Real Cl_ref = 8.416666666666668e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0141 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.310329,
    adminMass = 0.0015,
    ka = 0.0001475,
    Tlag = 0.0,
    k12 = 4.964539007092198e-07,
    k21 = 3.910614525139665e-08
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadoxine</h4><p>Sulfadoxine is a long-acting sulfonamide used to treat malaria and pneumocystosis. It is administered orally in tablet or suspension form. It is widely used to prevent or treat infections in livestock.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411557\">Wikidata Q411557</a>, <a href=\"https://en.wikipedia.org/wiki/Sulfadoxine?oldid=1306736143\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadoxine</td></tr><tr><td>population:</td><td>pregnant and postpartum women</td></tr><tr><td>source_paper:</td><td>de_2017</td></tr><tr><td>measured_compound:</td><td>sulfadoxine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412181-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulfadoxine 310.329 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'γ – shape factor' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412181-tbl-0002:row13:col1'])</li><li>routed 'Site effect (scaling on observations) in Mozambique [%]' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Site effect (scaling on observations) in Sudan [%]' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Site effect (scaling on observations) in Zambia [%]' — extend the ontology if this is a real PK parameter (source ['psp412181-tbl-0002:row17:col1'])</li><li>dropped unlinked row (NIL): 'Mali' — extend the ontology if this is a real PK parameter (source ['de_2017_table_3:row1:col4', 'de_2017_table_3:row1:col5'])</li><li>dropped unlinked row (NIL): 'Mozambique' — extend the ontology if this is a real PK parameter (source ['de_2017_table_3:row6:col4', 'de_2017_table_3:row6:col5'])</li><li>dropped unlinked row (NIL): 'Sudan' — extend the ontology if this is a real PK parameter (source ['de_2017_table_3:row11:col4', 'de_2017_table_3:row11:col5'])</li><li>dropped unlinked row (NIL): 'Zambia' — extend the ontology if this is a real PK parameter (source ['de_2017_table_3:row16:col4', 'de_2017_table_3:row16:col5'])</li><li>dropped unlinked row (NIL): 'Total' — extend the ontology if this is a real PK parameter (source ['de_2017_table_3:row21:col4', 'de_2017_table_3:row21:col5'])</li><li>implicit units: 'Change in CL when non‐pregnant [%]' — the LLM proposed '%', whose dimension does not fit Q31; left unset</li><li>implicit units: 'T50 [weeks]' → weeks (from the paper text: &quot;Parameter listed as 'T50 [weeks] = 6.35'; text states the postpartum clearance decline occurs over '13 weeks'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sulfadoxine</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Sulfadoxine_de2017_reference;
