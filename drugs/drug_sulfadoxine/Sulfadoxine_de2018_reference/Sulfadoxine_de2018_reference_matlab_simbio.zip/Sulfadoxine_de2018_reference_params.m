function p = Sulfadoxine_de2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulfadoxine   source: de_2018 / reference   route: oral
  p.name  = 'Sulfadoxine_de2018_reference_params';
  p.drug  = 'sulfadoxine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.29;                % central volume [L]
  p.CL = 0.0264;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.521;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 87.5;             % dose [mg]
end
