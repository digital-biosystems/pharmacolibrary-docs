model Sulfadoxine_Trenque2004_reference
  parameter Real Cl_ref = 6.365740740740741e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.036000000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadoxine</h4><p>Sulfadoxine is a long-acting sulfonamide used to treat malaria and pneumocystosis. It is administered orally in tablet or suspension form. It is widely used to prevent or treat infections in livestock.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411557\">Wikidata Q411557</a>, <a href=\"https://en.wikipedia.org/wiki/Sulfadoxine?oldid=1306736143\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadoxine</td></tr><tr><td>population:</td><td>children with congenital toxoplasmosis</td></tr><tr><td>source_paper:</td><td>Trenque_2004</td></tr><tr><td>measured_compound:</td><td>pyrimethamine and sulfadoxine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sulfadoxine 310.329 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pyrimethamine and sulfadoxine</li><li>molar mass: no plausible PubChem entry for 'pyrimethamine and sulfadoxine' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'pyrimethamine and sulfadoxine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Sulfadoxine_Trenque2004_reference;
