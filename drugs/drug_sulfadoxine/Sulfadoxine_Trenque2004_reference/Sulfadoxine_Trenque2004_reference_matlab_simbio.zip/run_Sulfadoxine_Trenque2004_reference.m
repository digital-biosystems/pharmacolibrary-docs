% Run (SimBiology): build model + dose, simulate 0..672.0 h, plot.
p = Sulfadoxine_Trenque2004_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 672.0);
