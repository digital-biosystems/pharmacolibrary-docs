// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Enterolactone_Setchell2014_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {17280.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>enterolactone</td></tr><tr><td>population:</td><td>healthy postmenopausal women</td></tr><tr><td>source_paper:</td><td>Setchell_2014</td></tr><tr><td>measured_compound:</td><td>Secoisolariciresinol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Enterolactone 298.338 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'peaking after' — extend the ontology if this is a real PK parameter (source ['Setchell_2014:abstract'])</li><li>dropped unlinked row (NIL): 'attained after (enterodiol)' — extend the ontology if this is a real PK parameter (source ['Setchell_2014:abstract'])</li><li>dropped unlinked row (NIL): 'attained after (enterolactone)' — extend the ontology if this is a real PK parameter (source ['Setchell_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Secoisolariciresinol</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 6/6 row label(s) assigned, 0 linked by role; re-tagged Secoisolariciresinol→parent ×2, Secoisolariciresinol→Enterodiol ×2, Secoisolariciresinol→Enterolactone ×2</li><li>molar mass: none found for 'Secoisolariciresinol-diglycoside' — its concentrations stay mass-only</li><li>molar mass: none found for 'Secoisolariciresinol' — its concentrations stay mass-only</li><li>molar mass: none found for 'Enterodiol' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Secoisolariciresinol', not enterolactone — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Enterolactone_Setchell2014_reference;
