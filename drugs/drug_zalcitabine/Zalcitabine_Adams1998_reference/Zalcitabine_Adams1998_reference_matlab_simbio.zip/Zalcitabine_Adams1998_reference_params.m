function p = Zalcitabine_Adams1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zalcitabine   source: Adams_1998 / reference   route: oral
  p.name  = 'Zalcitabine_Adams1998_reference_params';
  p.drug  = 'zalcitabine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 87.6;                % central volume [L]
  p.CL = 14.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 50.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.25;             % dose [mg]
end
