model Alemtuzumab_Dong2022_PD_alc
  "emax exposure-response sweep — Dong_2022 :: ALC (absolute lymphocyte count)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.18,  // [× 103 /μL]
    EC50 = 4.5e-05,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.45, Interval = 0.0009),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alemtuzumab</h4><p>Alemtuzumab is a monoclonal antibody used to treat multiple sclerosis and certain leukemias, including chronic lymphocytic leukemia and T-cell prolymphocytic leukemia. It remains authorised in the European Union, though one EU product has been withdrawn, and it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420164\">Wikidata Q420164</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Alemtuzumab_Dong2022_PD_alc</h4><p>The steady-state exposure-response curve of Dong M et al., <i>British journal of clinical pharmacology 88(1):248–259</i> 2022 (<a href=\"https://doi.org/10.1111/bcp.14955\">doi:10.1111/bcp.14955</a>) — absolute lymphocyte count [/μL] against alemtuzumab μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.18 × 103 /μL maximal effect term (Emax, Q323)
  EC50  =      0.045 μg/mL    exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of alemtuzumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.045 μg/mL)  response -0.59
  exposure -> infinity  response -1.18</pre></body></html>"));
end Alemtuzumab_Dong2022_PD_alc;
