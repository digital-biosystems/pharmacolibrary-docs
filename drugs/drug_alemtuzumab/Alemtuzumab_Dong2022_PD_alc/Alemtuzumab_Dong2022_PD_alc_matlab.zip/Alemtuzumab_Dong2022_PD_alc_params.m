function p = Alemtuzumab_Dong2022_PD_alc_params()
% Alemtuzumab_Dong2022_PD_alc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alemtuzumab Dong_2022::ALC: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response ALC in /μL. Driver: alemtuzumab (pk_record).
p.E0 = 0.0;
p.Emax = -1.18;
p.EC50 = 4.499999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.45;
p.form = 'E0 + Emax*frac';
end
