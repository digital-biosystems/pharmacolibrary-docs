model Alemtuzumab_Dong2022_reference
  parameter Real Cl_ref = 2.2222222222222224e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0174 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.3e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alemtuzumab</h4><p>Alemtuzumab is a monoclonal antibody used to treat multiple sclerosis and certain leukemias, including chronic lymphocytic leukemia and T-cell prolymphocytic leukemia. It remains authorised in the European Union, though one EU product has been withdrawn, and it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420164\">Wikidata Q420164</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alemtuzumab</td></tr><tr><td>population:</td><td>paediatric and young adult patients undergoing allogeneic haematopoietic cell transplantation</td></tr><tr><td>source_paper:</td><td>Dong_2022</td></tr><tr><td>measured_compound:</td><td>alemtuzumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Emax' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dong_2022:abstract', 'Dong_2022:abstract'])</li><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Dong_2022:abstract', 'Dong_2022:abstract'])</li><li>dropped unlinked row (NIL): 'allometry-based dose' — extend the ontology if this is a real PK parameter (source ['Dong_2022:abstract'])</li><li>dropped unlinked row (NIL): 'body surface area-based dose' — extend the ontology if this is a real PK parameter (source ['Dong_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alemtuzumab</li><li>molar mass: none found for 'alemtuzumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Alemtuzumab_Dong2022_reference;
