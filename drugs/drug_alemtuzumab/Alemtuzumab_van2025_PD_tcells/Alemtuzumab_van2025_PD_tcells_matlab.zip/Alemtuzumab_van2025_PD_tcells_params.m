function p = Alemtuzumab_van2025_PD_tcells_params()
% Alemtuzumab_van2025_PD_tcells_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alemtuzumab van_2025::Tcells: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response Tcells in cells/μL. Driver: alemtuzumab (cited_pk).
p.E0 = 0.0;
p.Emax = 2.41;
p.EC50 = 7.859999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.79;
p.form = 'E0/(1 + Emax*frac)';
end
