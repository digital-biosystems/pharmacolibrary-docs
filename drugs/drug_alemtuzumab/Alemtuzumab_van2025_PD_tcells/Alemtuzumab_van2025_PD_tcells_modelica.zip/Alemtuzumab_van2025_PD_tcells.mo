model Alemtuzumab_van2025_PD_tcells
  "indirect_response_iv exposure-response sweep — van_2025 :: Tcells (T cells)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 2.41,  // type IV effect term
    EC50 = 7.86e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.79, Interval = 0.00158),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alemtuzumab</h4><p>Alemtuzumab is a monoclonal antibody used to treat multiple sclerosis and certain leukemias, including chronic lymphocytic leukemia and T-cell prolymphocytic leukemia. It remains authorised in the European Union, though one EU product has been withdrawn, and it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420164\">Wikidata Q420164</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Alemtuzumab_van2025_PD_tcells</h4><p>The steady-state exposure-response curve of van Vugt LK et al., <i>Clinical pharmacology and therapeutics 118(3):662–672</i> 2025 (<a href=\"https://doi.org/10.1002/cpt.3714\">doi:10.1002/cpt.3714</a>) — T cells [cells/μL] against alemtuzumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.41          maximal effect term (E max, Q320)
  EC50  =     0.0786 mg/L     exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg/L of alemtuzumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0786 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Alemtuzumab_van2025_PD_tcells;
