model Alemtuzumab_Mould2007_PD_wbc
  "indirect_response_iii exposure-response sweep — Mould_2007 :: WBC (white blood cell (WBC) count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 18.2,  // type III effect term
    EC50 = 0.000306,  // [kg/m3; microg l(-1) × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 microg l(-1) per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3100, Interval = 6.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alemtuzumab</h4><p>Alemtuzumab is a monoclonal antibody used to treat multiple sclerosis and certain leukemias, including chronic lymphocytic leukemia and T-cell prolymphocytic leukemia. It remains authorised in the European Union, though one EU product has been withdrawn, and it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420164\">Wikidata Q420164</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Alemtuzumab_Mould2007_PD_wbc</h4><p>The steady-state exposure-response curve of Mould DR et al., <i>British journal of clinical pharmacology 64(3):278–291</i> 2007 (<a href=\"https://doi.org/10.1111/j.1365-2125.2007.02914.x\">doi:10.1111/j.1365-2125.2007.02914.x</a>) — white blood cell (WBC) count [cells l(-1)] against alemtuzumab microg l(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       18.2          maximal effect term (E(max), Q320)
  EC50  =        306 microg l(-1) exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one microg l(-1) of alemtuzumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (306 microg l(-1))  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Alemtuzumab_Mould2007_PD_wbc;
