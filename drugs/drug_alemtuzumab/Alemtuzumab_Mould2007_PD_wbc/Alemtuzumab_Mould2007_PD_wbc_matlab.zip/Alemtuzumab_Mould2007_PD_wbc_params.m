function p = Alemtuzumab_Mould2007_PD_wbc_params()
% Alemtuzumab_Mould2007_PD_wbc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alemtuzumab Mould_2007::WBC: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg l(-1) per second, in SI inside (kg/m3, s). Response WBC in cells l(-1). Driver: alemtuzumab (pk_record).
p.E0 = 0.0;
p.Emax = 18.2;
p.EC50 = 0.0003059999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3100.0;
p.form = 'E0*(1 + Emax*frac)';
end
