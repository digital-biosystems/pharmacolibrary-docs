% run_Alemtuzumab_Mould2007_PD_wbc  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Alemtuzumab_Mould2007_PD_wbc_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0.*(1 + Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [microg l(-1)]'); ylabel('response [cells l(-1)]'); title('Alemtuzumab_Mould2007_PD_wbc', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Alemtuzumab_Mould2007_PD_wbc.csv');
