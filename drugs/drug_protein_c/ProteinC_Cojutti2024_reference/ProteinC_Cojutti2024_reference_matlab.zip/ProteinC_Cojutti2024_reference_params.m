function p = ProteinC_Cojutti2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: protein_c   source: Cojutti_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'ProteinC_Cojutti2024_reference_params';
  p.drug  = 'protein_c';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.93;                % central volume [L]
  p.CL = 0.031;                % clearance [L/h]
  p.Vp = [9.55];             % peripheral volumes [L]
  p.Q  = [0.038];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
