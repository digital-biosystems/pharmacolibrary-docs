function p = ProteinC_Li2025_adolescents_12_to_16_y_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: protein_c   source: Li_2025 / adolescents_12_to_16_y   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'ProteinC_Li2025_adolescents_12_to_16_y_params';
  p.drug  = 'protein_c';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.0;                % central volume [L]
  p.CL = 0.3577;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
