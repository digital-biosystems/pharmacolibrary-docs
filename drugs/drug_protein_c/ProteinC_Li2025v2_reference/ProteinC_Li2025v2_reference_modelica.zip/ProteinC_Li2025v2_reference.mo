model ProteinC_Li2025v2_reference
  parameter Real Cl_ref = 1.9833333333333332e-07 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real Vd_ref = 0.006070000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.79,
    Cl = Cl_ref*(1 + (0.589)*cov_age_0),
    Vd = Vd_ref*(1 + (-0.112)*cov_age_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.0527777777777778e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About protein_c</h4><p>Protein C concentrate is used to treat purpura fulminans and protein C deficiency, acting as an antithrombotic agent. It is authorised in the European Union but appears to be a niche product, used only in these rare conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28852357\">Wikidata Q28852357</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>protein_c</td></tr><tr><td>population:</td><td>patients with severe congenital protein C deficiency (SCPCD)</td></tr><tr><td>source_paper:</td><td>Li_2025_2</td></tr><tr><td>measured_compound:</td><td>protein C</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>TB25050017-3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Rate of endogenous protein C production (IU/h)' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['TB25050017-3:row4:col1'])</li><li>covariate level 'Effect of age on the rate of endogenous protein C production' → Q900:effect_of_age_on_the_rate_of_endogenous_protein_c_production = 0.589 (linear_fractional on Q22)</li><li>dropped unlinked row (NIL): 'Effect of SCPCD indication on clearance' — extend the ontology if this is a real PK parameter (source ['TB25050017-3:row8:col1'])</li><li>dropped unlinked row (NIL): 'Effect of SCPCD indication on rate of endogenous protein C production' — extend the ontology if this is a real PK parameter (source ['TB25050017-3:row9:col1'])</li><li>dropped unlinked row (NIL): 'Duration of administration (h) b' — extend the ontology if this is a real PK parameter (source ['TB25050017-3:row15:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=protein C</li><li>molar mass: none found for 'protein_c' — its concentrations stay mass-only</li><li>molar mass: none found for 'protein C' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end ProteinC_Li2025v2_reference;
