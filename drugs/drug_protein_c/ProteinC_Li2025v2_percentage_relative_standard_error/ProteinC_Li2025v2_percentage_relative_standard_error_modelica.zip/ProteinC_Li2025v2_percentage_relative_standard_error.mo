model ProteinC_Li2025v2_percentage_relative_standard_error
  parameter Real Cl_ref = 8.611111111111111e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>protein_c</td></tr><tr><td>population:</td><td>patients with severe congenital protein C deficiency</td></tr><tr><td>source_paper:</td><td>Li_2025_2</td></tr><tr><td>measured_compound:</td><td>protein C</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>TB25050017-3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'First-order absorption rate constant (1/h)' (captured trailing unit '1/h' for child rows)</li><li>dropped value-less row: 'Duration of administration (h) b'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=protein C</li><li>population split: 'percentage relative standard error' subgroup of Li_2025_2 (paper reports 3 populations: percentage relative standard error, population estimate, standard error)</li><li>gap-filled Q22 (CL) from Cojutti_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Troisi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end ProteinC_Li2025v2_percentage_relative_standard_error;
