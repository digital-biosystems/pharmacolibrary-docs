function p = ProteinC_Li2025v2_percentage_relative_standard_error_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: protein_c   source: Li_2025_2 / percentage_relative_standard_error   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'ProteinC_Li2025v2_percentage_relative_standard_error_params';
  p.drug  = 'protein_c';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.0;                % central volume [L]
  p.CL = 0.031;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
