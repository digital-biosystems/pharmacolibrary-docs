% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = ProteinC_Li2025v2_percentage_relative_standard_error_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
