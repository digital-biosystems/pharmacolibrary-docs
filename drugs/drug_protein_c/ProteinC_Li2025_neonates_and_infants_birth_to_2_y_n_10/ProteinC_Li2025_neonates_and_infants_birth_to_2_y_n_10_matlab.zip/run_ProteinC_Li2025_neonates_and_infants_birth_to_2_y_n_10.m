% Run: build params, simulate 0..24.0 h, plot + save ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.m
here = fileparts(mfilename('fullpath'));
p = ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10_params();
out = simulate_pk(p, 0:0.05:24.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('protein_c — Li_2025 (iv_bolus)');
print(fig, fullfile(here, 'ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.json'), 'w');
try
  s.model = 'ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.png, ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.csv, ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10.json\n');
