model ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10
  parameter Real Cl_ref = 1.0791666666666669e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>protein_c</td></tr><tr><td>population:</td><td>patients with severe congenital or acquired protein C deficiency</td></tr><tr><td>source_paper:</td><td>Li_2025</td></tr><tr><td>measured_compound:</td><td>protein C</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl4</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'IR, IU/dL per IU/kg' — extend the ontology if this is a real PK parameter (source ['Li_2025_table_2:row3:col1'])</li><li>dropped unlinked row (NIL): 'IVR, %' — extend the ontology if this is a real PK parameter (source ['Li_2025_table_2:row4:col1'])</li><li>salvaged Q22 ('CL, d'=0.555) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=protein C</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'neonates and infants (birth to <2 y) (n = 10)' subgroup of Li_2025 (paper reports 4 populations: adolescents (≥12 to <16 y) (n = 3), adults (≥16 y)(n = 9), neonates and infants (birth to <2 y) (n = 10), population estimate)</li><li>gap-filled Q61 (V) from Troisi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10;
