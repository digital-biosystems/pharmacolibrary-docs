% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = ProteinC_Li2025_neonates_and_infants_birth_to_2_y_n_10_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
