model PolymyxinB_Hanafin2025_PD_scr
  "indirect_response_ii exposure-response sweep — Hanafin_2025 :: SCr (Serum creatinine)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0124,      // [kg/m3; mg/dL × 0.01]
    Emax = 1,  // type II effect term
    EC50 = 0.00277,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 28, Interval = 0.056),
    Documentation(info = "<html><body><!-- drug-about --><h4>About polymyxin_b</h4><p>Polymyxin B is an antibiotic used to treat infections caused by susceptible bacteria such as Escherichia coli and Bacteroides, and is also applied as an intestinal antiinfective and in eye and ear preparations. It remains in use, with approved and veterinary-approved status, though it is not an EU-authorised product according to the available data.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1088175\">Wikidata Q1088175</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>PolymyxinB_Hanafin2025_PD_scr</h4><p>The steady-state exposure-response curve of Hanafin PO et al., <i>Clinical pharmacology and therapeutics 118(4):841–852</i> 2025 (<a href=\"https://doi.org/10.1002/cpt.3729\">doi:10.1002/cpt.3729</a>) — Serum creatinine [mg/dL] against polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.24 mg/dL    drug-free response (baseline) (SCr0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =       2.77 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0124   (drug-free)
  exposure = EC50 (2.77 mg/L)  response 0.0248
  exposure -> infinity  response inf</pre></body></html>"));
end PolymyxinB_Hanafin2025_PD_scr;
