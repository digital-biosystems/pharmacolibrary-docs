function p = PolymyxinB_Akrong2022_PD_viable_bacterial_burden_params()
% PolymyxinB_Akrong2022_PD_viable_bacterial_burden_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Akrong_2022::viable_bacterial_burden: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response viable bacterial burden in CFU/mL. Driver: Polymyxin B (conc_no_pk).
p.E0 = 0.0;
p.Emax = -8.96;
p.EC50 = 0.0014599999999999997;
p.gamma = 0.656;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 14.6;
p.form = 'E0 + Emax*frac';
end
