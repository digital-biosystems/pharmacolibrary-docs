model PolymyxinB_Akrong2022_PD_viable_bacterial_burden
  "sigmoid_emax exposure-response sweep — Akrong_2022 :: viable bacterial burden (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -8.96,  // [CFU/mL]
    EC50 = 0.0014599999999999997,  // [kg/m3; mg/L × 0.001]
    gamma = 0.656,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 14.6, Interval = 0.0292));
end PolymyxinB_Akrong2022_PD_viable_bacterial_burden;
