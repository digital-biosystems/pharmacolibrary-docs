model PolymyxinB_Mahadevan2026_PD_log10_cfu_ml
  "sigmoid_emax exposure-response sweep — Mahadevan_2026 :: log10 CFU/mL (log10 CFU/mL)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.00372222222222,  // [1/s; h⁻¹ × 0.000277778]
    EC50 = 0.00082,  // [kg/m3; mg/L × 0.001]
    gamma = 0.64,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 8.2, Interval = 0.0164),
    Documentation(info = "<html><body><!-- drug-about --><h4>About polymyxin_b</h4><p>Polymyxin B is an antibiotic used to treat infections caused by susceptible bacteria such as Escherichia coli and Bacteroides, and is also applied as an intestinal antiinfective and in eye and ear preparations. It remains in use, with approved and veterinary-approved status, though it is not an EU-authorised product according to the available data.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1088175\">Wikidata Q1088175</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>PolymyxinB_Mahadevan2026_PD_log10_cfu_ml</h4><p>The steady-state exposure-response curve of Mahadevan R et al., <i>Antimicrobial agents and chemotherapy 70(2):e0078225</i> 2026 (<a href=\"https://doi.org/10.1128/aac.00782-25\">doi:10.1128/aac.00782-25</a>) — log10 CFU/mL [log10 CFU/mL] against polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       13.4 h⁻¹      maximal effect term (Maximum killing rate constant of polymyxin B (KmaxPMB), Q323)
  EC50  =       0.82 mg/L     exposure at half of the maximal effect term (Polymyxin B concentration causing 50% of KmaxPMB in I (KC50,PMB,I), Q321)
  gamma =       0.64          Hill coefficient (Hill coefficient of polymyxin B, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.82 mg/L)  response -0.001861
  exposure -> infinity  response -0.003722</pre></body></html>"));
end PolymyxinB_Mahadevan2026_PD_log10_cfu_ml;
