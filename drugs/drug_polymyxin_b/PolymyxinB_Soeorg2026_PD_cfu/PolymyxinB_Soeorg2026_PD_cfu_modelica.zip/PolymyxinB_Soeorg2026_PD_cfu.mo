model PolymyxinB_Soeorg2026_PD_cfu
  "sigmoid_emax exposure-response sweep — Soeorg_2026 :: cfu (colony-forming unit)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -3.62,  // [log10 cfu/mL]
    EC50 = 0.00033,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.3, Interval = 0.0066),
    Documentation(info = "<html><body><!-- drug-about --><h4>About polymyxin_b</h4><p>Polymyxin B is an antibiotic used to treat infections caused by susceptible bacteria such as Escherichia coli and Bacteroides, and is also applied as an intestinal antiinfective and in eye and ear preparations. It remains in use, with approved and veterinary-approved status, though it is not an EU-authorised product according to the available data.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1088175\">Wikidata Q1088175</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>PolymyxinB_Soeorg2026_PD_cfu</h4><p>The steady-state exposure-response curve of Soeorg H et al., <i>Antimicrobial agents and chemotherapy:e0027426</i> 2026 (<a href=\"https://doi.org/10.1128/aac.00274-26\">doi:10.1128/aac.00274-26</a>) — colony-forming unit [log10 cfu/mL] against colistin/polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       3.62 log10 cfu/mL maximal effect term (EmaxCOLPMB, Q323)
  EC50  =       0.33 mg/L     exposure at half of the maximal effect term (EC50COLPMB, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of colistin/polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.33 mg/L)  response -1.81
  exposure -> infinity  response -3.62</pre></body></html>"));
end PolymyxinB_Soeorg2026_PD_cfu;
