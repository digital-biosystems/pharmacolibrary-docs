function p = PolymyxinB_Soeorg2026_PD_cfu_params()
% PolymyxinB_Soeorg2026_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Soeorg_2026::cfu: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response cfu in log10 cfu/mL. Driver: colistin/polymyxin B (conc_no_pk).
p.E0 = 0.0;
p.Emax = -3.62;
p.EC50 = 0.00032999999999999994;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.3;
p.form = 'E0 + Emax*frac';
end
