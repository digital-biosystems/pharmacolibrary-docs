model PolymyxinB_Mahadevan2026_PD_bacterial_load
  "sigmoid_emax exposure-response sweep — Mahadevan_2026 :: bacterial load (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -0.84,  // [ImaxM,PMB]
    EC50 = 0.024699999999999993,  // [kg/m3; mg/L × 0.001]
    gamma = 1.0,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 247, Interval = 0.494));
end PolymyxinB_Mahadevan2026_PD_bacterial_load;
