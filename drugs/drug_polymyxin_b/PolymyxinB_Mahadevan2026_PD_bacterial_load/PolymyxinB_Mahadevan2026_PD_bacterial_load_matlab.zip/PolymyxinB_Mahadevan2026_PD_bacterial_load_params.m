function p = PolymyxinB_Mahadevan2026_PD_bacterial_load_params()
% PolymyxinB_Mahadevan2026_PD_bacterial_load_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Mahadevan_2026::bacterial_load: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response bacterial load in log10 CFU/mL. Driver: polymyxin B (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.84;
p.EC50 = 0.024699999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 247.0;
p.form = 'E0 + Emax*frac';
end
