model PolymyxinB_Akrong2022_PD_cfu
  "sigmoid_emax exposure-response sweep — Akrong_2022 :: CFU (viable bacterial burden)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -8.96,  // [h 21]
    EC50 = 0.00146,  // [kg/m3; mg/L × 0.001]
    gamma = 0.656,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><!-- drug-about --><h4>About polymyxin_b</h4><p>Polymyxin B is an antibiotic used to treat infections caused by susceptible bacteria such as Escherichia coli and Bacteroides, and is also applied as an intestinal antiinfective and in eye and ear preparations. It remains in use, with approved and veterinary-approved status, though it is not an EU-authorised product according to the available data.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1088175\">Wikidata Q1088175</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>PolymyxinB_Akrong2022_PD_cfu</h4><p>The steady-state exposure-response curve of Akrong G et al., <i>Antimicrobial agents and chemotherapy 66(1):e0178921</i> 2022 (<a href=\"https://doi.org/10.1128/AAC.01789-21\">doi:10.1128/AAC.01789-21</a>) — viable bacterial burden [CFU/mL] against polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       8.96 h 21     maximal effect term (E max(0), Q323)
  EC50  =       1.46 mg/L     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =      0.656          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.46 mg/L)  response -4.48
  exposure -> infinity  response -8.96</pre></body></html>"));
end PolymyxinB_Akrong2022_PD_cfu;
