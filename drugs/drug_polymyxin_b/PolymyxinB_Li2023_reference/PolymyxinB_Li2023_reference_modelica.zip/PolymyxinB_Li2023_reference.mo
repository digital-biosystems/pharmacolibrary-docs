model PolymyxinB_Li2023_reference
  parameter Real Cl_ref = 6.750000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02311 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About polymyxin_b</h4><p>Polymyxin B is an antibiotic used to treat infections caused by susceptible bacteria such as Escherichia coli and Bacteroides, and is also applied as an intestinal antiinfective and in eye and ear preparations. It remains in use, with approved and veterinary-approved status, though it is not an EU-authorised product according to the available data.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1088175\">Wikidata Q1088175</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b</td></tr><tr><td>population:</td><td>adults with liver dysfunction</td></tr><tr><td>source_paper:</td><td>Li_2023</td></tr><tr><td>measured_compound:</td><td>polymyxin_b</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=polymyxin_b</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end PolymyxinB_Li2023_reference;
