model Rolapitant_Wang2019_reference
  parameter Real Cl_ref = 2.672222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.214 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5004850000000001,
    adminMass = 0.00018,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rolapitant</h4><p>Rolapitant is an antiemetic used to prevent nausea and vomiting associated with cancer treatment. It has been approved as a medicine, though its marketing authorisation in the European Union has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76415423\">Wikidata Q76415423</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rolapitant</td></tr><tr><td>population:</td><td>patients with chemotherapy-induced nausea and vomiting</td></tr><tr><td>source_paper:</td><td>Wang_2019</td></tr><tr><td>measured_compound:</td><td>rolapitant</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>M19 516.482 g/mol (pubchem); rolapitant 500.485 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rolapitant</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 5/5 row label(s) assigned, 5 linked by role; re-tagged rolapitant→parent ×4, rolapitant→M19 ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Rolapitant_Wang2019_reference;
