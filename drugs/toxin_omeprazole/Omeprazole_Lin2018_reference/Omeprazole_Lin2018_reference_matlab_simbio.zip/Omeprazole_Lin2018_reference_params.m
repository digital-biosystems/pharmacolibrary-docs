function p = Omeprazole_Lin2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Lin_2018 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Omeprazole_Lin2018_reference_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.6;                % central volume [L]
  p.CL = 1.21;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.26;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
