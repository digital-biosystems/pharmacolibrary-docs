model Omeprazole_Soliman2025_reference
  parameter Real Cl_ref = 3.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0776 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345417,
    adminMass = 1e-05,
    ka = 0.00026388888888888886,
    Tlag = 936.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>adults and pediatric patients</td></tr><tr><td>source_paper:</td><td>Soliman_2025</td></tr><tr><td>measured_compound:</td><td>Omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-00373-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5'-O-desmethylomeprazole 331.39 g/mol (pubchem); Hydroxy-omeprazole 361.416 g/mol (pubchem); Omeprazole 345.417 g/mol (pubchem); Omeprazole sulphone 361.416 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'logP' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row2:col1'])</li><li>dropped unlinked row (NIL): 'Diffusion coefficient' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row3:col1'])</li><li>dropped unlinked row (NIL): 'Reference solubility' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row5:col1'])</li><li>dropped unlinked row (NIL): 'Solubility Factor' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row6:col1'])</li><li>dropped unlinked row (NIL): 'FaSSIF solubility' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row7:col1'])</li><li>dropped unlinked row (NIL): 'FeSSIF solubility' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row8:col1'])</li><li>dropped unlinked row (NIL): 'Human effective permeability (Peff)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row9:col1'])</li><li>dropped unlinked row (NIL): 'Drug particle density' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row12:col1'])</li><li>dropped unlinked row (NIL): 'Mean precipitation time' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row13:col1'])</li><li>dropped unlinked row (NIL): 'Blood–plasma concentration ratio (Rbp)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-00373-t002:row14:col1'])</li><li>'Fraction unbound in plasma (Fup)%' → Q46: printed without a unit and above 1 — read as a percentage</li><li>covariate effect for Q1 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q66 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q1 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q66 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q1 has no base parameter row (kept as unattached equation-variable)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Omeprazole_Soliman2025_reference;
