model Omeprazole_Ozbey2023_child_pugh_a_pbpk
  parameter Real Cl_ref = 3.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0776 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345417,
    adminMass = 2e-06,
    ka = 0.00026388888888888886,
    Tlag = 936.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>patients with liver cirrhosis (Child-Pugh A/B/C) and healthy controls</td></tr><tr><td>source_paper:</td><td>Ozbey_2023</td></tr><tr><td>measured_compound:</td><td>Omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>omeprazole 345.417 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Corrected dose (mg)' — extend the ontology if this is a real PK parameter (source ['Ozbey_2023_table_4:row2:col4', 'Ozbey_2023_table_4:row6:col4', 'Ozbey_2023_table_4:row10:col4', 'Ozbey_2023_table_4:row14:col4', 'Ozbey_2023_table_4:row18:col4', 'Ozbey_2023_table_4:row22:col4'])</li><li>unit_dimension_unknown: 'μg×h/L' (AUC)</li><li>dropped duplicate Q88 ('Corrected AUC (μg×h/L)', value '83.2') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Omeprazole</li><li>population split: 'child-pugh a (n = 16) pbpk' subgroup of Ozbey_2023 (paper reports 4 populations: child-pugh a (n = 16) pbpk, child-pugh b (n = 15) pbpk, child-pugh c (n = 5) pbpk, con (n = 12) pbpk)</li><li>gap-filled Q22 (CL) from Ishida_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Jiang_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chung_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chung_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Chung_2022, Ishida_2026, Jiang_2026 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q88 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Omeprazole_Ozbey2023_child_pugh_a_pbpk;
