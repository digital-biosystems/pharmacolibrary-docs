% Run: build params, simulate 0..240.0 h, plot + save Omeprazole_Ozbey2023_child_pugh_c_pbpk.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Omeprazole_Ozbey2023_child_pugh_c_pbpk.m
here = fileparts(mfilename('fullpath'));
p = Omeprazole_Ozbey2023_child_pugh_c_pbpk_params();
out = simulate_pk(p, 0:0.05:240.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('omeprazole — Ozbey_2023 (oral)');
print(fig, fullfile(here, 'Omeprazole_Ozbey2023_child_pugh_c_pbpk.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Omeprazole_Ozbey2023_child_pugh_c_pbpk.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Omeprazole_Ozbey2023_child_pugh_c_pbpk.json'), 'w');
try
  s.model = 'Omeprazole_Ozbey2023_child_pugh_c_pbpk'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Omeprazole_Ozbey2023_child_pugh_c_pbpk","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Omeprazole_Ozbey2023_child_pugh_c_pbpk.png, Omeprazole_Ozbey2023_child_pugh_c_pbpk.csv, Omeprazole_Ozbey2023_child_pugh_c_pbpk.json\n');
