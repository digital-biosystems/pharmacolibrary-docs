function p = Omeprazole_Ozbey2023_child_pugh_c_pbpk_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Ozbey_2023 / child_pugh_c_pbpk   route: oral
  % estimated (absent from source): F
  p.name  = 'Omeprazole_Ozbey2023_child_pugh_c_pbpk_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.6;                % central volume [L]
  p.CL = 1.21;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.26;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
