// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Naftidrofuryl_Hulot1998_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {13284.0},
    MM = 0.383532,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naftidrofuryl</td></tr><tr><td>population:</td><td>healthy volunteers (young and elderly)</td></tr><tr><td>source_paper:</td><td>Hulot_1998</td></tr><tr><td>measured_compound:</td><td>Naftidrofuryl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>naftidrofuryl 383.532 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h (median)' (tmax)</li><li>dropped duplicate Q32 ('Cmax (group 2)', value 282) — already have one for this compound</li><li>unit_dimension_unknown: 'h (median)' (tmax)</li><li>dropped duplicate Q56 ('tmax (group 2)', value 2.75) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 (group 2)', value 3.03) — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0-t (group 2)', value 1783) — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0-inf (group 2)', value 1856) — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (group 3)', value 271) — already have one for this compound</li><li>unit_dimension_unknown: 'h (median)' (tmax)</li><li>dropped duplicate Q56 ('tmax (group 3)', value 2.5) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 (group 3)', value 3.5) — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0-t (group 3)', value 1742) — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0-inf (group 3)', value 1834) — already have one for this compound</li><li>unit_dimension_unknown: 'h (median)' (tmax)</li><li>dropped duplicate Q56 ('tmax (whole population)', value 2.75) — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (whole population)', value 279) — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Naftidrofuryl_Hulot1998_reference;
