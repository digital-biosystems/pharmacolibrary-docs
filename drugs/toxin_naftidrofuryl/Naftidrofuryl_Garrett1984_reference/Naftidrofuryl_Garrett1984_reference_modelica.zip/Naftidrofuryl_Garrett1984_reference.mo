model Naftidrofuryl_Garrett1984_reference
  parameter Real Cl_ref = 2.158333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0022 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0006,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naftidrofuryl</td></tr><tr><td>population:</td><td>dogs (beagle, bile-cannulated in part)</td></tr><tr><td>source_paper:</td><td>Garrett_1984</td></tr><tr><td>measured_compound:</td><td>Naftidrofuryl (nafronyl)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>naftidrofuryl 383.532 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is naftidrofuryl; the compartment is Naftidrofuryl (nafronyl). Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Naftidrofuryl (nafronyl), not naftidrofuryl</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>naftidrofuryl's own concentration-time course is not produced by this model</li><li>covariate category for Kp from footnote/prose kept as documentation only (['Garrett_1984:abstract'])</li><li>covariate category for Kp from footnote/prose kept as documentation only (['Garrett_1984:abstract'])</li><li>covariate category for Kp from footnote/prose kept as documentation only (['Garrett_1984:abstract'])</li><li>covariate renal for CLR from footnote/prose kept as documentation only (['Garrett_1984:abstract'])</li><li>covariate renal for CLR from footnote/prose kept as documentation only (['Garrett_1984:abstract'])</li><li>dropped duplicate Q22 ('total body clearance of intravenously administered II', value 225) — already have one for this compound</li><li>dropped duplicate Q59 ('plasma half-lives of II (intravenous), first', value 2.5) — already have one for this compound</li><li>dropped duplicate Q60 ('plasma half-lives of II (intravenous), second', value 10.9) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Naftidrofuryl (nafronyl)</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>toxin: plasma half-lives printed only as a range — the value is the range's midpoint; route to review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Naftidrofuryl_Garrett1984_reference;
