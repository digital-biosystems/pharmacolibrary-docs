// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model CyproteroneAcetate_Speck1976v2_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {28440.0},
    MM = 0.41694200000000003,
    adminMass = 0.0001,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyproterone_acetate</td></tr><tr><td>population:</td><td>Male volunteers</td></tr><tr><td>source_paper:</td><td>Speck_1976_2</td></tr><tr><td>measured_compound:</td><td>Cyproterone acetate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cyproterone acetate 416.942 g/mol (pubchem); cyproterone_acetate 416.942 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life of 1,8 +/- 0,2 days', value 1.8) — already have one for this compound</li><li>dropped duplicate Q57 ('eliminated with a half-life of 1,6 +/- 0,1 days', value 1.6) — already have one for this compound</li><li>covariate category for t1/2ka  from footnote/prose kept as documentation only (['Speck_1976_2:abstract'])</li><li>dropped duplicate Q57 ('plasma level ... half-life of 2,3 +/- 0,1 days', value 2.3) — already have one for this compound</li><li>relinked 'urinary elimination with half-life of 2,1 +/- 0,2 days' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('urinary elimination with half-life of 2,1 +/- 0,2 days', value 2.1) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyproterone acetate</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 288.0));
end CyproteroneAcetate_Speck1976v2_reference;
