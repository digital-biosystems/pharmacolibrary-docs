model CyproteroneAcetate_Kuhnz1993_reference
  parameter Real Cl_ref = 1.0000000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.986 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41694200000000003,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyproterone_acetate</td></tr><tr><td>population:</td><td>15 healthy women (age 19 to 34 years)</td></tr><tr><td>source_paper:</td><td>Kuhnz_1993</td></tr><tr><td>measured_compound:</td><td>Cyproterone acetate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Cyproterone acetate 416.942 g/mol (pubchem); cyproterone_acetate 416.942 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml x min-1 x kg-1' (CL/F)</li><li>dropped duplicate Q57 ('terminal half-life of CPA', value '78.6') — already have one for this compound</li><li>dropped duplicate Q61 ('volume of distribution', value '1304') — already have one for this compound</li><li>implicit units: 'apparent clearance' → L/h (from the popPK convention: 'The parameter is apparent clearance (CL/F). Population PK convention for clearance is L/h. The value 3.6 is consistent w')</li><li>implicit units: 'volume of distribution (Vz)' → L (from the popPK convention: 'The parameter is volume of distribution (Vz or Vd). Population PK convention for volume is L. The value 986 is consisten')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyproterone acetate</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CyproteroneAcetate_Kuhnz1993_reference;
