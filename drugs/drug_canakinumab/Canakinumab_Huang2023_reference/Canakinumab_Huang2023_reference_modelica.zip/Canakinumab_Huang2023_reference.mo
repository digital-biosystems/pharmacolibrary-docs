model Canakinumab_Huang2023_reference
  parameter Real Cl_ref = 9.25925925925926e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0017312340490667564 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.7e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About canakinumab</h4><p>Canakinumab is a monoclonal antibody that blocks interleukin signalling and is used to treat Cryopyrin-Associated Periodic Syndromes and juvenile idiopathic arthritis, with investigational use in gouty arthritis and cardiovascular conditions such as acute coronary syndrome. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3655009\">Wikidata Q3655009</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>canakinumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Huang_2023</td></tr><tr><td>measured_compound:</td><td>canakinumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Huang_2023) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Canakinumab_Huang2023_reference;
