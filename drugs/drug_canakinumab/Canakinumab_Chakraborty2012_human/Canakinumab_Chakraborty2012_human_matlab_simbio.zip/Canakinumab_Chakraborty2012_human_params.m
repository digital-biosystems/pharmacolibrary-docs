function p = Canakinumab_Chakraborty2012_human_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canakinumab   source: Chakraborty_2012 / human   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Canakinumab_Chakraborty2012_human_params';
  p.drug  = 'canakinumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.08;                % central volume [L]
  p.CL = 0.007583;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 0.665;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
