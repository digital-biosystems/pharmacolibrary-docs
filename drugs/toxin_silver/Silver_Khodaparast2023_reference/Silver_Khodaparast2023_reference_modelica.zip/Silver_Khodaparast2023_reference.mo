// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Silver_Khodaparast2023_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1996263.8800126426},
    MM = 0.10787000000000001,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>silver</td></tr><tr><td>population:</td><td>Tenebrio molitor larvae and Porcellio scaber adult woodlice</td></tr><tr><td>source_paper:</td><td>Khodaparast_2023</td></tr><tr><td>measured_compound:</td><td>Ag</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Ag 107.87 g/mol (pubchem); silver 107.87 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Control' — extend the ontology if this is a real PK parameter (source ['Khodaparast_2023_table_p4_1:row1:col1', 'Khodaparast_2023_table_p4_1:row1:col3', 'Khodaparast_2023_table_p4_1:row1:col5'])</li><li>dropped unlinked row (NIL): 'AgNO3' — extend the ontology if this is a real PK parameter (source ['Khodaparast_2023_table_p4_1:row2:col1', 'Khodaparast_2023_table_p4_1:row2:col2', 'Khodaparast_2023_table_p4_1:row2:col3', 'Khodaparast_2023_table_p4_1:row2:col4', 'Khodaparast_2023_table_p4_1:row2:col5'])</li><li>dropped unlinked row (NIL): 'Ag2S NPs' — extend the ontology if this is a real PK parameter (source ['Khodaparast_2023_table_p4_1:row3:col1', 'Khodaparast_2023_table_p4_1:row3:col2', 'Khodaparast_2023_table_p4_1:row3:col3', 'Khodaparast_2023_table_p4_1:row3:col5'])</li><li>salvaged Q47 ('decrease rate of Ag in the control group'=0.03) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ag</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>review gap-fill skipped: this record measures 'Ag', not silver — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 10281600, Tolerance = 1e-9, Interval = 20563.2));
end Silver_Khodaparast2023_reference;
