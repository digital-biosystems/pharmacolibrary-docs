// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Silver_Lee2013_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {8548416.0},
    MM = 0.10787000000000001,
    adminMass = 0.007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>silver</td></tr><tr><td>population:</td><td>Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Lee_2013</td></tr><tr><td>measured_compound:</td><td>Silver</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>silver 107.87 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>substance matrix T1 ('Table 1. Clearance T1/2 of silver after 28 days of oral administration (superscript 0, 0-o'): no row names this substance — its 7 row(s) (Blood0, Brain1, Kidneys1, Liver1, Spleen1, Testes/ovaries1, Liver0) are other substances' values; none taken</li><li>salvaged Q57 ('blood silver t1/2'=98.94) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Silver</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Silver_Lee2013_reference;
