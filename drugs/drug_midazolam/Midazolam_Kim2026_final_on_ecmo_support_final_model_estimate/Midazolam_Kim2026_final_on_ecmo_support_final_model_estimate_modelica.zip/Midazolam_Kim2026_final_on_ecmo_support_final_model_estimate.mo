// parent + metabolites (1-hydroxymidazolam): PK_3M_9C — formed from central; parent 2, metabolites [2]
model Midazolam_Kim2026_final_on_ecmo_support_final_model_estimate
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0367,
    Vd2 = 0.057100000000000005,
    q12 = 8.611111111111112e-07,
    q21 = 8.611111111111112e-07,
    q1_m11 = 9.055555555555556e-07,
    CL1 = 0.0,
    Vd1m1 = 0.00642,
    CLm1 = 1.3805555555555556e-05,
    Vd2m1 = 0.127,
    qm11_m12 = 1.2305555555555556e-07,
    qm12_m11 = 1.2305555555555556e-07,
    MW = 0.325767,
    MW_m1 = 0.34176999999999996,
    F = 0.9,
    ka = 3.888888888888889e-05,
    Tlag = 6840.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>adults with venoarterial ECMO</td></tr><tr><td>source_paper:</td><td>Kim_2026</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; parent clearance = Σ formation clearances (no other elimination route); formation of 1-hydroxymidazolam: CLfm; dose 15 mg (WHO ATC DDD 15 mg oral (N05CD08))</td></tr><tr><td>molar_masses:</td><td>1-hydroxymidazolam 341.77 g/mol (pubchem); midazolam 325.767 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ2 Parent' routed out of structural estimates ('Residual variability†')</li><li>table section residual_error: 'σ2 Metabolite' routed out of structural estimates ('Residual variability†')</li><li>dropped unlinked row (NIL): 'θECMO flow rate on CL1-OH MDZ' — extend the ontology if this is a real PK parameter (source ['T1:row11:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [2]</li><li>model-stage split: 'on ecmo support / final model estimate(rse or cv %)' is the final model of Kim_2026 (paper reports 2 stages: after ecmo support / final model estimate(rse or cv %), on ecmo support / final model estimate(rse or cv %)); same population, different model-building step</li><li>row roles (LLM): model_class=compartmental; 17/17 row label(s) assigned, 16 linked by role; re-tagged parent→1-hydroxymidazolam ×19</li><li>gap-filled Q49 (kabs) from Jia_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Heizmann_1983's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Kim2026_final_on_ecmo_support_final_model_estimate;
