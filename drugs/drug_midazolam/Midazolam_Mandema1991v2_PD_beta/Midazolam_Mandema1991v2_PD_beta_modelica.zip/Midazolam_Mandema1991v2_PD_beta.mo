model Midazolam_Mandema1991v2_PD_beta
  "sigmoid_emax exposure-response sweep — Mandema_1991_2 :: beta (amplitudes in the 11.5-30 Hz (beta) frequency band)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 61,      // [µV s-1]
    Emax = 85,  // [µV s-1]
    EC50 = 4e-05,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 0.84,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  annotation(experiment(StartTime = 0, StopTime = 400, Interval = 0.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Midazolam_Mandema1991v2_PD_beta</h4><p>The steady-state exposure-response curve of Mandema JW et al., <i>British journal of pharmacology 102(3):663–668</i> 1991 (<a href=\"https://doi.org/10.1111/j.1476-5381.1991.tb12230.x\">doi:10.1111/j.1476-5381.1991.tb12230.x</a>) — amplitudes in the 11.5-30 Hz (beta) frequency band [µV s-1] against midazolam ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         61 µV s-1   drug-free response (baseline) (Eo, Q324)
  Emax  =         85 µV s-1   maximal effect term (Emax, Q320)
  EC50  =         40 ng ml-1  exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.84          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 61   (drug-free)
  exposure = EC50 (40 ng ml-1)  response 103.5
  exposure -> infinity  response 146</pre></body></html>"));
end Midazolam_Mandema1991v2_PD_beta;
