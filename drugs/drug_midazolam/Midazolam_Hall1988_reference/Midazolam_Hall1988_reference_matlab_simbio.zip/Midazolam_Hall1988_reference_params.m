function p = Midazolam_Hall1988_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Hall_1988 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Midazolam_Hall1988_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.98;                % central volume [L]
  p.CL = 1338.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
