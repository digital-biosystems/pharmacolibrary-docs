model Midazolam_HoyoVadillo1995_PD_amplitudes_in_the_11_5_30_hz_2
  "sigmoid_emax exposure-response sweep — Hoyo-Vadillo_1995 :: amplitudes in the 11.5-30 Hz (beta) frequency band (amplitudes in the 11.5-30 Hz (beta) frequency band)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 77,      // [µV/S]
    Emax = 138,  // [µV/S]
    EC50 = 4.6e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1.2,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  annotation(experiment(StartTime = 0, StopTime = 460, Interval = 0.92),
    Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Midazolam_HoyoVadillo1995_PD_amplitudes_in_the_11_5_30_hz_2</h4><p>The steady-state exposure-response curve of Hoyo-Vadillo C et al., <i>Life sciences 57(4):325–333</i> 1995 (<a href=\"https://doi.org/10.1016/0024-3205(95)00291-d\">doi:10.1016/0024-3205(95)00291-d</a>) — amplitudes in the 11.5-30 Hz (beta) frequency band [µV/s] against midazolam ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         77 µV/S     drug-free response (baseline) (E0, Q324)
  Emax  =        138 µV/S     maximal effect term (Emax, Q320)
  EC50  =         46 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.2          Hill coefficient (Hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 77   (drug-free)
  exposure = EC50 (46 ng/ml)  response 146
  exposure -> infinity  response 215</pre></body></html>"));
end Midazolam_HoyoVadillo1995_PD_amplitudes_in_the_11_5_30_hz_2;
