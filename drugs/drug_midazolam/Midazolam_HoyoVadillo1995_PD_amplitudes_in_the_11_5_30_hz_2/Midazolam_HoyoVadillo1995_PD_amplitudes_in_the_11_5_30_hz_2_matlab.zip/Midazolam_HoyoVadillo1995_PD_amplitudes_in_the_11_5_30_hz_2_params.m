function p = Midazolam_HoyoVadillo1995_PD_amplitudes_in_the_11_5_30_hz_2_params()
% Midazolam_HoyoVadillo1995_PD_amplitudes_in_the_11_5_30_hz_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Hoyo-Vadillo_1995::amplitudes_in_the_11_5_30_Hz_beta_frequency_band::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response amplitudes in the 11.5-30 Hz (beta) frequency band in µV/s. Driver: midazolam (cited_pk).
p.E0 = 77.0;
p.Emax = 138.0;
p.EC50 = 4.6e-05;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 460.0;
p.form = 'E0 + Emax*frac';
end
