model Midazolam_Mandema1991v2_PD_eeg_beta
  "sigmoid_emax exposure-response sweep — Mandema_1991_2 :: EEG beta (amplitudes in the 11.5-30 Hz (beta) frequency band)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 61,      // [uV s-1]
    Emax = 85,  // [Vs 1]
    EC50 = 40,  // [ngmlP-1]
    gamma = 0.84,
    exposure_per_s = 1);   // 1 ngmlP-1 per second
  // exposure_unit_unresolved: 'ngmlP-1' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 400, Interval = 0.8),
    Documentation(info = "<html><body><h4>Midazolam_Mandema1991v2_PD_eeg_beta</h4><p>The steady-state exposure-response curve of Mandema JW et al., <i>British journal of pharmacology 102(3):663–668</i> 1991 (<a href=\"https://doi.org/10.1111/j.1476-5381.1991.tb12230.x\">doi:10.1111/j.1476-5381.1991.tb12230.x</a>) — amplitudes in the 11.5-30 Hz (beta) frequency band [uV s-1] against midazolam ngmlP-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         61 uV s-1   drug-free response (baseline) (Eo, Q324)
  Emax  =         85 Vs 1     maximal effect term (Emax, Q320)
  EC50  =         40 ngmlP-1  exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.84          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ngmlP-1 of midazolam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 61   (drug-free)
  exposure = EC50 (40 ngmlP-1)  response 103.5
  exposure -> infinity  response 146</pre></body></html>"));
end Midazolam_Mandema1991v2_PD_eeg_beta;
