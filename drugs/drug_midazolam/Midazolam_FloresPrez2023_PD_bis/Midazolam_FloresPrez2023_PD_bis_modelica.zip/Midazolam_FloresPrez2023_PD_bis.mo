model Midazolam_FloresPrez2023_PD_bis
  "sigmoid_emax exposure-response sweep — Flores-Pérez_2023 :: BIS (Bispectral Index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 57.63,      // [1]
    Emax = -0.088,  // [1]
    EC50 = 1.3569999999999999e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 135.7, Interval = 0.2714));
end Midazolam_FloresPrez2023_PD_bis;
