#!/usr/bin/env python3
"""Sweep Midazolam_FloresPrez2023_PD_bis.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Midazolam_FloresPrez2023_PD_bis.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Midazolam_FloresPrez2023_PD_bis")
E0, Emax, EC50, gamma, slope, exposure_per_s = 57.63, -0.088, 1.3569999999999999e-05, 1.0, 0.0, 1e-06
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma))
x = [exposure_per_s * 135.7 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Midazolam_FloresPrez2023_PD_bis", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [ng/mL]"); plt.ylabel("response []")
plt.title("Midazolam_FloresPrez2023_PD_bis"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
