function p = Midazolam_Seng2014_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Seng_2014 / base   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Midazolam_Seng2014_base_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.2;                % central volume [L]
  p.CL = 13.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
