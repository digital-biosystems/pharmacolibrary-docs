function p = Midazolam_Zhou2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Zhou_2014 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Zhou2014_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 133.0;                % central volume [L]
  p.CL = 36.0;                % clearance [L/h]
  p.Vp = [146.0];             % peripheral volumes [L]
  p.Q  = [26.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.77;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
