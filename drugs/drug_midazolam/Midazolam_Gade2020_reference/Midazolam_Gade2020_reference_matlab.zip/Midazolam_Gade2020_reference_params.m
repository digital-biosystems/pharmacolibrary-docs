function p = Midazolam_Gade2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Gade_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Gade2020_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26.0;                % central volume [L]
  p.CL = 12.0;                % clearance [L/h]
  p.Vp = [61.0];             % peripheral volumes [L]
  p.Q  = [16.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.9;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
