model Midazolam_Lu1994_PD_tnw12_30
  "sigmoid_emax exposure-response sweep — Lu_1994 :: TNW12-30 (total number of waves per second within the frequency range of 12-30 Hz (TNW12-30) in the central-occipital (C1-O1) lead EEG)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.4,      // [TNW12-30]
    Emax = -11.4,  // [TNW12-30]
    EC50 = 0.000254,  // [kg/m3; micrograms.L-1 × 1e-06]
    gamma = 2.9,
    exposure_per_s = 1e-06);   // 1 micrograms.L-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 2600, Interval = 5.2),
    Documentation(info = "<html><body><h4>Midazolam_Lu1994_PD_tnw12_30</h4><p>The steady-state exposure-response curve of Lu JF et al., <i>Zhongguo yao li xue bao = Acta pharmacologica Sinica 15(5):399–403</i> 1994 — total number of waves per second within the frequency range of 12-30 Hz (TNW12-30) in the central-occipital (C1-O1) lead EEG against midazolam micrograms.L-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        3.4 TNW12-30 drug-free response (baseline) (E0, Q324)
  Emax  =       11.4 TNW12-30 maximal effect term (Emax, Q323)
  EC50  =        254 micrograms.L-1 exposure at half of the maximal effect term (EC50, Q321)
  gamma =        2.9          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micrograms.L-1 of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.4   (drug-free)
  exposure = EC50 (254 micrograms.L-1)  response -2.3
  exposure -> infinity  response -8</pre></body></html>"));
end Midazolam_Lu1994_PD_tnw12_30;
