model Midazolam_van2019_reference
  parameter Real Cl_ref = 5.722222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0858 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.325767,
    adminMass = 1.5e-05,
    ka = 3.888888888888889e-05,
    Tlag = 6840.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>preterm to 2-year-old infants in intensive care</td></tr><tr><td>source_paper:</td><td>van_2019</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp14047-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>midazolam 325.767 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 CL' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additional error' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): '- k1' — extend the ontology if this is a real PK parameter (source ['bcp14047-tbl-0003:row8:col1'])</li><li>dropped duplicate Q64 ('V2 (L)', value '3.19') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>gap-filled Q61 (V) from Bardol_2025's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Jia_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Heizmann_1983's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Midazolam_van2019_reference;
