function p = Midazolam_van2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: van_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_van2019_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 85.8;                % central volume [L]
  p.CL = 2.06;                % clearance [L/h]
  p.Vp = [3.81];             % peripheral volumes [L]
  p.Q  = [0.79];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.9;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
