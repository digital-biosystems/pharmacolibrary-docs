% Run: build params, simulate 0..26.0 h, plot every molecule + save Midazolam_Kim2026_final.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Midazolam_Kim2026_final.m
here = fileparts(mfilename('fullpath'));
p = Midazolam_Kim2026_final_params();
out = simulate_network(p, 0:0.05:26.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('concentration [mg/L]');
title('midazolam — Kim_2026 (parent + metabolites)');
print(fig, fullfile(here, 'Midazolam_Kim2026_final.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Midazolam_Kim2026_final.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg_per_L', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Midazolam_Kim2026_final.json'), 'w');
try
  s.model = 'Midazolam_Kim2026_final'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg_per_L']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Midazolam_Kim2026_final"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): Cmax=%.4g mg/L  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Midazolam_Kim2026_final.png, Midazolam_Kim2026_final.csv, Midazolam_Kim2026_final.json\n');
