function p = Midazolam_Sathe2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Sathe_2021 / reference   route: oral
  p.name  = 'Midazolam_Sathe2021_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 115.5;                % central volume [L]
  p.CL = 73.9;                % clearance [L/h]
  p.Vp = [130.0];             % peripheral volumes [L]
  p.Q  = [26.6];             % inter-compartmental clearances [L/h]
  p.ka = 1.77;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
