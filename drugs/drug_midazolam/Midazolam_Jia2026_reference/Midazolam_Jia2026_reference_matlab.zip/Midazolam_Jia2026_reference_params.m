function p = Midazolam_Jia2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Jia_2026 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Midazolam_Jia2026_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.75;                % central volume [L]
  p.CL = 7.48;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
