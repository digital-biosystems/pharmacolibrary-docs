// parent + metabolites (1-hydroxymidazolam): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Midazolam_Xie2025_final
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.016,
    q1_m11 = 3.766666666666667e-06,
    CL1 = 2.5111111111111114e-06,
    Vd1m1 = 0.0862,
    CLm1 = 1.8638888888888886e-05,
    MW = 0.325767,
    MW_m1 = 0.34176999999999996,
    F = 0.9,
    ka = 3.888888888888889e-05,
    Tlag = 6840.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>mechanically ventilated ICU patients</td></tr><tr><td>source_paper:</td><td>Xie_2025</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of 1-hydroxymidazolam: fm=0.6 × CL; dose 15 mg (WHO ATC DDD 15 mg oral (N05CD08))</td></tr><tr><td>molar_masses:</td><td>1-hydroxymidazolam 341.77 g/mol (paper); midazolam 325.767 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLMDZ (CV%)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'CL1-OH-MDZ (CV%)' routed out of structural estimates ('IIV')</li><li>table representations disagree for 'CLMDZ (L/h)'; source reconciliation required</li><li>table representations disagree for 'VMDZ (L)'; source reconciliation required</li><li>table representations disagree for 'CL1-OH-MDZ (L/h)'; source reconciliation required</li><li>table representations disagree for 'V1-OH-MDZ (L)'; source reconciliation required</li><li>table representations disagree for 'FMET'; source reconciliation required</li><li>table representations disagree for 'AST on CLMDZ'; source reconciliation required</li><li>table representations disagree for 'rs2461817 on CLMDZ'; source reconciliation required</li><li>table representations disagree for 'BW on CL1-OH-MDZ'; source reconciliation required</li><li>table representations disagree for 'Proportional (CV%)'; source reconciliation required</li><li>table representations disagree for 'Additive (ng/mL)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'AST on CLMDZ' — extend the ontology if this is a real PK parameter (source ['t0002:row10:col3'])</li><li>dropped unlinked row (NIL): 'rs2461817 on CLMDZ' — extend the ontology if this is a real PK parameter (source ['t0002:row11:col3'])</li><li>dropped unlinked row (NIL): 'BW on CL1-OH-MDZ' — extend the ontology if this is a real PK parameter (source ['t0002:row12:col3'])</li><li>dropped unlinked row (NIL): 'Proportional (CV%)' — extend the ontology if this is a real PK parameter (source ['t0002:row18:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Xie2025_final;
