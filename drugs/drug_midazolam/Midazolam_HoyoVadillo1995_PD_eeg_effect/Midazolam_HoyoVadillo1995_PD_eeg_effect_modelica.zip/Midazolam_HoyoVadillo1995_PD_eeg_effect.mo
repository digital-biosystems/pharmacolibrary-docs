model Midazolam_HoyoVadillo1995_PD_eeg_effect
  "sigmoid_emax exposure-response sweep — Hoyo-Vadillo_1995 :: EEG effect (Amplitudes in the 11.5-30 Hz (beta) frequency band of the EEG)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 75,      // [pV/s]
    Emax = 142,  // [pV/s]
    EC50 = 8.5e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1.2,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  annotation(experiment(StartTime = 0, StopTime = 850, Interval = 1.7),
    Documentation(info = "<html><body><h4>Midazolam_HoyoVadillo1995_PD_eeg_effect</h4><p>The steady-state exposure-response curve of Hoyo-Vadillo C et al., <i>Life sciences 57(4):325–333</i> 1995 (<a href=\"https://doi.org/10.1016/0024-3205(95)00291-d\">doi:10.1016/0024-3205(95)00291-d</a>) — Amplitudes in the 11.5-30 Hz (beta) frequency band of the EEG [pV/s] against midazolam ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         75 pV/s     drug-free response (baseline) (E0, Q324)
  Emax  =        142 pV/s     maximal effect term (Emax, Q320)
  EC50  =         85 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.2          Hill coefficient (Hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 75   (drug-free)
  exposure = EC50 (85 ng/ml)  response 146
  exposure -> infinity  response 217</pre></body></html>"));
end Midazolam_HoyoVadillo1995_PD_eeg_effect;
