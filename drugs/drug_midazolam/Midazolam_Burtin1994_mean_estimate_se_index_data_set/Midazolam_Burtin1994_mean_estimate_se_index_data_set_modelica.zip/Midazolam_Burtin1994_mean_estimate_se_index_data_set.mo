model Midazolam_Burtin1994_mean_estimate_se_index_data_set
  parameter Real Cl_ref = 2.566666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.034929999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.888888888888889e-05,
    Tlag = 4428.0,
    k12 = 8.827178165855523e-06,
    k21 = 0.0005079626578802857
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>critically ill neonates</td></tr><tr><td>source_paper:</td><td>Burtin_1994</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table iv</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'If GA ≥ 39 weeks'</li><li>dropped unlinked row (NIL): 'If C < 200 ng/ml' — extend the ontology if this is a real PK parameter (source ['Burtin_1994_table_p9_1:row10:col1'])</li><li>dropped unlinked row (NIL): 'If C ≥ 200 ng/ml' — extend the ontology if this is a real PK parameter (source ['Burtin_1994_table_p9_1:row11:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>population split: 'mean estimate ± se index data set' subgroup of Burtin_1994 (paper reports 2 populations: mean estimate ± se index data set, mean estimate ± se whole data set)</li><li>gap-filled Q49 (kabs) from Jia_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Jia_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Burtin1994_mean_estimate_se_index_data_set;
