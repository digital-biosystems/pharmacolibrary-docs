% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Midazolam_Burtin1994_mean_estimate_se_index_data_set_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
