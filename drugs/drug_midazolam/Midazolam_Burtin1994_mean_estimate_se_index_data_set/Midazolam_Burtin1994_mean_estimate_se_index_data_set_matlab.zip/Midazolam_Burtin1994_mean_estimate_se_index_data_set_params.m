function p = Midazolam_Burtin1994_mean_estimate_se_index_data_set_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Burtin_1994 / mean_estimate_se_index_data_set   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Midazolam_Burtin1994_mean_estimate_se_index_data_set_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.93;                % central volume [L]
  p.CL = 9.24;                % clearance [L/h]
  p.Vp = [0.607];             % peripheral volumes [L]
  p.Q  = [1.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
