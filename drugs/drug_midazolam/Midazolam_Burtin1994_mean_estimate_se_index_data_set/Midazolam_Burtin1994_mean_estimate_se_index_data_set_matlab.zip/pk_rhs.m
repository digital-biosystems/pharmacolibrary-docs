function dA = pk_rhs(t, A, p)
% Generic linear PK ODE right-hand side for a 1..N-compartment model.
%   State A = [A_depot(if oral); A_central; A_peripheral_1 ... A_peripheral_{ncmt-1}]
%   Micro-constants from clinical params: k10 = CL/Vc, k1j = Q(j)/Vc, kj1 = Q(j)/Vp(j).
  dA = zeros(numel(A), 1);
  ic = double(p.depot) + 1;                 % index of the central compartment
  if p.depot                                % first-order oral absorption
     dA(1)  = -p.ka * A(1);
     dA(ic) =  p.ka * A(1);
  end
  dA(ic) = dA(ic) - (p.CL / p.Vc) * A(ic);  % elimination from central
  for j = 1:(p.ncmt - 1)                     % peripheral exchanges
     cj  = ic + j;
     k1j = p.Q(j) / p.Vc;
     kj1 = p.Q(j) / p.Vp(j);
     dA(ic) = dA(ic) - k1j * A(ic) + kj1 * A(cj);
     dA(cj) =          k1j * A(ic) - kj1 * A(cj);
  end
end
