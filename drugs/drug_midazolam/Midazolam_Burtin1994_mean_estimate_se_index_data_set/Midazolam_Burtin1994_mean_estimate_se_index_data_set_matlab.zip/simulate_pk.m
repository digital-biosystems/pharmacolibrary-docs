function out = simulate_pk(p, tspan)
% Simulate a PK model built from a parameter struct p (see *_params.m).
%   tspan: e.g. 0:0.1:24 (hours). Returns out.t, out.C (central conc [mg/L]),
%   out.Cmax, out.Tmax, out.AUC.
  nstate = double(p.depot) + p.ncmt;        % depot? + central + peripherals
  A0 = zeros(nstate, 1);
  ic = double(p.depot) + 1;
  switch p.route
    case 'iv_bolus'
      A0(ic) = p.dose;                       % straight into central
    case 'oral'
      A0(1)  = p.F * p.dose;                 % F*dose into the depot
    otherwise
      error('unknown route: %s', p.route);
  end
  % No 'NonNegative' mask: it makes Octave's ode15s (IDA) fail at t=0; the linear PK
  % ODEs stay non-negative anyway. ode15s handles stiff (multi-compartment) cases;
  % fall back to ode45 if ode15s is unavailable/unhappy (portable MATLAB + Octave).
  opts = odeset('RelTol', 1e-6, 'AbsTol', 1e-6);
  odef = @(t,A) pk_rhs(t, A, p);
  try
    [t, A] = ode15s(odef, tspan, A0, opts);
  catch
    [t, A] = ode45(odef, tspan, A0, opts);
  end
  C = A(:, ic) / p.Vc;                        % plasma concentration [mg/L]
  out.t = t; out.C = C;
  [out.Cmax, imax] = max(C);
  out.Tmax = t(imax);
  out.AUC = trapz(t, C);
end
