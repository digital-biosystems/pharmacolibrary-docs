function p = Midazolam_Maitre1991_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Maitre_1991 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Midazolam_Maitre1991_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 85.8;                % central volume [L]
  p.CL = 28.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
