model Midazolam_Maitre1991_reference
  parameter Real Cl_ref = 7.777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0858 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.888888888888889e-05,
    Tlag = 4428.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Maitre_1991</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'V₁'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'Vss'</li><li>dropped value-less row: 'ΘCL'</li><li>kept covariate coefficient Θage=0.036 (covariate age) — not an ontology parameter</li><li>kept covariate coefficient Θliver=0.68 (covariate liver) — not an ontology parameter</li><li>dropped value-less row: 'V1'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>gap-filled Q22 (CL) from Bardol_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Bardol_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Jia_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Jia_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Maitre1991_reference;
