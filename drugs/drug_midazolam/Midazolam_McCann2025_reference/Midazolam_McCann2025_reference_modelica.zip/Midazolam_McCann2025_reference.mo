model Midazolam_McCann2025_reference
  parameter Real Cl_ref = 4.077777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00709 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.888888888888889e-05,
    Tlag = 4428.0,
    k12 = 0.001751684688920232,
    k21 = 0.00036452728043570424
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>children with and without obesity</td></tr><tr><td>source_paper:</td><td>McCann_2025</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70247-tbl-0002</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL', value '187.8') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>gap-filled Q49 (kabs) from Jia_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Jia_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_McCann2025_reference;
