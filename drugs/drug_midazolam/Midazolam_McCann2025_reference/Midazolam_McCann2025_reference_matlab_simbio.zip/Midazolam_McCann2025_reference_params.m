function p = Midazolam_McCann2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: McCann_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Midazolam_McCann2025_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.09;                % central volume [L]
  p.CL = 14.68;                % clearance [L/h]
  p.Vp = [34.07];             % peripheral volumes [L]
  p.Q  = [44.71];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
