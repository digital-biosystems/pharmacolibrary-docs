model Levofloxacin_Setiawan2022_median
  parameter Real Cl_ref = 2.5000000000000004e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0264 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3613675,
    adminMass = 0.00025,
    k12 = 0.0003493265993265993,
    k21 = 0.0003305455993628037
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levofloxacin</h4><p>Levofloxacin is a fluoroquinolone antibiotic used to treat a range of bacterial infections, including pneumonia, sinusitis, urinary tract infections, and tuberculosis, and it is also used to help eradicate Helicobacter pylori. It is widely used and appears on the WHO essential medicines list; in the European Union an authorised product exists mainly for respiratory tract infections and cystic fibrosis, and it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424193\">Wikidata Q424193</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levofloxacin</td></tr><tr><td>population:</td><td>hospitalized adult patients</td></tr><tr><td>source_paper:</td><td>Setiawan_2022</td></tr><tr><td>measured_compound:</td><td>levofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>levofloxacin 361.368 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=levofloxacin</li><li>population split: 'median' subgroup of Setiawan_2022 (paper reports 2 populations: mean, median)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Levofloxacin_Setiawan2022_median;
