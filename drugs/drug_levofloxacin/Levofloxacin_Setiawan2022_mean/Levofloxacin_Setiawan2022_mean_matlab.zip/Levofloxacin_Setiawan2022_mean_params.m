function p = Levofloxacin_Setiawan2022_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levofloxacin   source: Setiawan_2022 / mean   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Levofloxacin_Setiawan2022_mean_params';
  p.drug  = 'levofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.6;                % central volume [L]
  p.CL = 1.12;                % clearance [L/h]
  p.Vp = [28.2];             % peripheral volumes [L]
  p.Q  = [30.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
