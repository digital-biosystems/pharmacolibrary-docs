model Levofloxacin_Setiawan2022_mean
  parameter Real Cl_ref = 3.111111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.0003109903381642512,
    k21 = 0.00030437352245862886
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levofloxacin</td></tr><tr><td>population:</td><td>hospitalized adult patients</td></tr><tr><td>source_paper:</td><td>Setiawan_2022</td></tr><tr><td>measured_compound:</td><td>levofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=levofloxacin</li><li>population split: 'mean' subgroup of Setiawan_2022 (paper reports 3 populations: mean, median, shrink (%))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levofloxacin_Setiawan2022_mean;
