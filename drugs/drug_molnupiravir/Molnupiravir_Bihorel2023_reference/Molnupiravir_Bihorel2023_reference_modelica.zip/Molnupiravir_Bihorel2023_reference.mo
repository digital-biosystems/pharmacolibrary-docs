model Molnupiravir_Bihorel2023_reference
  parameter Real Cl_ref = 1.961111111111111e-05 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Boolean cov_category_2 = false "category level 2";
  parameter Real Vd_ref = 0.0639 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref + (-9.166666666666668e-08)*(if cov_category_0 then 1 else 0) + (1.1722222222222224e-06)*(if cov_category_1 then 1 else 0) + (-1.7111111111111114e-07)*(if cov_category_2 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2592,
    adminMass = 5e-05,
    ka = 0.0002213888888888889,
    Tlag = 0.0,
    k12 = 1.2997739523561122e-05,
    k21 = 1.2160403448836832e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About molnupiravir</h4><p>Molnupiravir is an antiviral medication used to treat severe respiratory illness caused by certain RNA viruses. It is administered orally in capsule form, which is its standard method of delivery. Regulatory status is complex, with approvals in specific jurisdictions while applications elsewhere have been withdrawn.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q96376832\">Wikidata Q96376832</a>, <a href=\"https://en.wikipedia.org/wiki/Molnupiravir?oldid=1378360857\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>molnupiravir</td></tr><tr><td>population:</td><td>adults with COVID-19</td></tr><tr><td>source_paper:</td><td>Bihorel_2023</td></tr><tr><td>measured_compound:</td><td>NHC</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413031-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>molnupiravir 329.309 g/mol (drugbank); NHC 259.2 g/mol (paper)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Phase I trials' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Phase II/III trials' routed out of structural estimates ('Residual variability')</li><li>covariate level 'Proportional shift in female participants' → Q900:proportional_shift_in_female_participants = -0.330 (additive_shift on Q22)</li><li>covariate level 'Proportional shift due to high-fat meal' → Q900:proportional_shift_due_to_high_fat_meal = 4.22 (additive_shift on Q22)</li><li>covariate level 'Proportional shift in oral solution' → Q900:proportional_shift_in_oral_solution = -0.616 (additive_shift on Q22)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=NHC</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Molnupiravir_Bihorel2023_reference;
