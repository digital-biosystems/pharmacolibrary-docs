model Molnupiravir_Bihorel2023_reference
  parameter Real Cl_ref = 5.472222222222222e-07 "Cl [m3/s]";
  parameter Real cov_body_weight = 1.0 "body weight covariate (reference 1.0)";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Real Vd_ref = 0.005070000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_body_weight/1.0)^(14.0) + (1.525e-06)*(if cov_category_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2592,
    adminMass = 0.0008,
    ka = 0.0007138888888888888,
    Tlag = 0.0,
    k12 = 0.0003122945430637738,
    k21 = 0.00010844748858447488
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About molnupiravir</h4><p>Molnupiravir is an antiviral drug that was developed for the treatment of COVID-19 infection. Its marketing authorisation application in the European Union was withdrawn, and it remains investigational rather than an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q96376832\">Wikidata Q96376832</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>molnupiravir</td></tr><tr><td>population:</td><td>adults with COVID-19 and healthy participants</td></tr><tr><td>source_paper:</td><td>Bihorel_2023</td></tr><tr><td>measured_compound:</td><td>NHC</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413031-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>NHC 259.2 g/mol (paper); NHC (β-D-N4-hydroxycytidine) 259.2 g/mol (paper); molnupiravir (MK-4482, EIDD-2801) 329.31 g/mol (paper)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Phase I trials' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Phase I trials' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Phase II/III trials' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Phase II/III trials' routed out of structural estimates ('Residual variability')</li><li>covariate level 'Power of body weight effect' → Q900:power_of_body_weight_effect = 14.0 (power on Q27)</li><li>covariate level 'Proportional shift in oral solution' → Q900:proportional_shift_in_oral_solution = 5.49 (additive_shift on Q27)</li><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=NHC</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 16/16 row label(s) assigned, 14 linked by role; re-tagged NHC (β-D-N4-hydroxycytidine)→NHC ×32</li><li>review gap-fill skipped: this record measures 'NHC', not molnupiravir — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Molnupiravir_Bihorel2023_reference;
