function p = Molnupiravir_Bihorel2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: molnupiravir   source: Bihorel_2023 / reference   route: oral
  p.name  = 'Molnupiravir_Bihorel2023_reference_params';
  p.drug  = 'molnupiravir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.07;                % central volume [L]
  p.CL = 1.97;                % clearance [L/h]
  p.Vp = [14.6];             % peripheral volumes [L]
  p.Q  = [5.7];             % inter-compartmental clearances [L/h]
  p.ka = 2.57;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
