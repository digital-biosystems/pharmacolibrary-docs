function p = Molnupiravir_Bihorel2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: molnupiravir   source: Bihorel_2023 / reference   route: oral
  p.name  = 'Molnupiravir_Bihorel2023_reference_params';
  p.drug  = 'molnupiravir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 63.9;                % central volume [L]
  p.CL = 70.6;                % clearance [L/h]
  p.Vp = [68.3];             % peripheral volumes [L]
  p.Q  = [2.99];             % inter-compartmental clearances [L/h]
  p.ka = 0.797;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
