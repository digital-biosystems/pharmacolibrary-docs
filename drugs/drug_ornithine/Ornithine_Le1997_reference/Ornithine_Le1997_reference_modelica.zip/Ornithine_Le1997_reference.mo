model Ornithine_Le1997_reference
  parameter Real Cl_ref = 3.75e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00786 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00046666666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ornithine</td></tr><tr><td>population:</td><td>burn patients</td></tr><tr><td>source_paper:</td><td>Le_1997</td></tr><tr><td>measured_compound:</td><td>ornithine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'proline' — extend the ontology if this is a real PK parameter (source ['Le_1997:abstract'])</li><li>dropped unlinked row (NIL): 'glutamine' — extend the ontology if this is a real PK parameter (source ['Le_1997:abstract'])</li><li>dropped unlinked row (NIL): 'arginine' — extend the ontology if this is a real PK parameter (source ['Le_1997:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ornithine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Kwack_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kwack_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ornithine_Le1997_reference;
