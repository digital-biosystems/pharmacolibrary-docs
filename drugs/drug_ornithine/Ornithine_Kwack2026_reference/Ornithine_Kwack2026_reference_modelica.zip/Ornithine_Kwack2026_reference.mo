model Ornithine_Kwack2026_reference
  parameter Real Cl_ref = 3.75e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00786 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0003194444444444444,
    Tlag = 2970.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ornithine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kwack_2026</td></tr><tr><td>measured_compound:</td><td>ornithine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kwack_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ornithine_Kwack2026_reference;
