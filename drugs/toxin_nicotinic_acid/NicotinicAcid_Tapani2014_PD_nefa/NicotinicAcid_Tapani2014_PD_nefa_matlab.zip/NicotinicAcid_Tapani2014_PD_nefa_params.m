function p = NicotinicAcid_Tapani2014_PD_nefa_params()
% NicotinicAcid_Tapani2014_PD_nefa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nicotinic_acid Tapani_2014::NEFA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmol L-1 per second, in SI inside (kg/m3, s). Response NEFA in mmol L-1. Driver: Nicotinic acid (pk_record).
p.E0 = 0.7409999999999999;
p.Emax = 1.0;
p.EC50 = 8.199999999999999e-05;
p.gamma = 2.16;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.82;
p.form = 'E0*(1 - Emax*frac)';
end
