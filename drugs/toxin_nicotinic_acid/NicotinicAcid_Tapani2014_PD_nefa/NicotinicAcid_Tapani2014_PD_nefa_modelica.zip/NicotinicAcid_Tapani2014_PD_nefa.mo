model NicotinicAcid_Tapani2014_PD_nefa
  "indirect_response_i exposure-response sweep — Tapani_2014 :: NEFA (NEFA)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.741,      // [mol/m3; mmol L-1 × 1]
    Emax = 1,  // type I effect term
    EC50 = 8.2e-05,  // [mol/m3; μmol L-1 × 0.001]
    gamma = 2.16,
    exposure_per_s = 0.001);   // 1 μmol L-1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 0.82, Interval = 0.00164),
    Documentation(info = "<html><body><h4>NicotinicAcid_Tapani2014_PD_nefa</h4><p>The steady-state exposure-response curve of Tapani S et al., <i>Journal of pharmaceutical sciences 103(8):2571-2584</i> 2014 (<a href=\"https://doi.org/10.1002/jps.24077\">doi:10.1002/jps.24077</a>) — NEFA [mmol L-1] against Nicotinic acid μmol L-1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.741 mmol L-1 drug-free response (baseline) (R0 Normal, Q324)
  Emax  =          1          maximal effect term (Imax, Q323)
  EC50  =      0.082 μmol L-1 exposure at half of the maximal effect term (IC50, Q322)
  gamma =       2.16          Hill coefficient (gamma Normal, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μmol L-1 of Nicotinic acid per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.741   (drug-free)
  exposure = EC50 (0.082 μmol L-1)  response 0.3705
  exposure -> infinity  response 0</pre></body></html>"));
end NicotinicAcid_Tapani2014_PD_nefa;
