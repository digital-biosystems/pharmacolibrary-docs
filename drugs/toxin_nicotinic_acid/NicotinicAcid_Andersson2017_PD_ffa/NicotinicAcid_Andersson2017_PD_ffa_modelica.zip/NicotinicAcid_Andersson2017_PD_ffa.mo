model NicotinicAcid_Andersson2017_PD_ffa
  "indirect_response_i exposure-response sweep — Andersson_2017 :: FFA (Free Fatty Acid)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.707,      // [mM]
    Emax = 1,  // type I effect term
    EC50 = 0.436,  // [μM]
    gamma = 1.24,
    exposure_per_s = 1);   // 1 μM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 4.4, Interval = 0.0088),
    Documentation(info = "<html><body><h4>NicotinicAcid_Andersson2017_PD_ffa</h4><p>The steady-state exposure-response curve of Andersson R et al., <i>Journal of pharmacokinetics and pharmacodynamics 44(3):203–222</i> 2017 (<a href=\"https://doi.org/10.1007/s10928-017-9512-6\">doi:10.1007/s10928-017-9512-6</a>) — Free Fatty Acid [mM] against Nicotinic acid μM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.707 mM       drug-free response (baseline) (Baseline FFA conc. (Lean), Q324)
  Emax  =          1          maximal effect term (Efficacy - NiAc on FFA (Lean), Q323)
  EC50  =      0.436 μM       exposure at half of the maximal effect term (Potency - NiAc on FFA (Lean), Q322)
  gamma =       1.24          Hill coefficient (Hill coefficient - NiAc on FFA (Lean), Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μM of Nicotinic acid per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.707   (drug-free)
  exposure = EC50 (0.436 μM)  response 0.3535
  exposure -> infinity  response 0</pre></body></html>"));
end NicotinicAcid_Andersson2017_PD_ffa;
