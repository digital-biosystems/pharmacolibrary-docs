function p = NicotinicAcid_Andersson2017_PD_ffa_params()
% NicotinicAcid_Andersson2017_PD_ffa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nicotinic_acid Andersson_2017::FFA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response FFA in mM. Driver: Nicotinic acid (cited_pk).
p.E0 = 0.707;
p.Emax = 1.0;
p.EC50 = 0.436;
p.gamma = 1.24;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 4.4;
p.form = 'E0*(1 - Emax*frac)';
end
