function p = NicotinicAcid_Garrett1985_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nicotinic_acid   source: Garrett_1985 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'NicotinicAcid_Garrett1985_reference_params';
  p.drug  = 'nicotinic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.04;                % central volume [L]
  p.CL = 3.6462;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.27;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
