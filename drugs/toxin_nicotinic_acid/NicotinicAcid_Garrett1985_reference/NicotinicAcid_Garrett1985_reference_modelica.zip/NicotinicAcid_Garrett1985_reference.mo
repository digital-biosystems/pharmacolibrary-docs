model NicotinicAcid_Garrett1985_reference
  parameter Real Cl_ref = 1.1666666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.012039999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.123111,
    adminMass = 0.0001,
    ka = 0.001186111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nicotinic_acid</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Garrett_1985</td></tr><tr><td>measured_compound:</td><td>Nicotinic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Clofibric acid 214.645 g/mol (pubchem); Etofibrate 363.794 g/mol (pubchem); Nicotinic acid 123.111 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is nicotinic_acid; the compartment is Nicotinic acid. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Nicotinic acid, not nicotinic_acid</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>nicotinic_acid's own concentration-time course is not produced by this model</li><li>dropped duplicate Q57 ('terminal half-lives', value 4.6) — already have one for this compound</li><li>dropped unlinked row (NIL): 'concentrations' — extend the ontology if this is a real PK parameter (source ['Garrett_1985:abstract'])</li><li>'Nicotinic acid is excreted ... unchanged' → Q44: printed without a unit and above 1 — read as a percentage</li><li>metabolite nicotinic acid: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Nicotinic acid</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 1 linked by role; re-tagged Nicotinic acid→parent ×6</li><li>molar mass: no plausible PubChem entry for 'Nicotinate intermediate half-ester' ('Nicotinate intermediate half-ester') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'Clofibrate intermediate half-ester' ('Clofibrate intermediate half-ester') — left in mass units</li><li>molar mass: none found for 'Nicotinate intermediate half-ester' — its concentrations stay mass-only</li><li>molar mass: none found for 'Clofibrate intermediate half-ester' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end NicotinicAcid_Garrett1985_reference;
