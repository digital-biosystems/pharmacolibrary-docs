model NicotinicAcid_Andersson2017_PD_i
  "indirect_response_i exposure-response sweep — Andersson_2017 :: I (Insulin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.188,      // [nM]
    Emax = 0.793,  // type I effect term
    EC50 = 0.338,  // [μM]
    gamma = 3.54,
    exposure_per_s = 1);   // 1 μM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 3.4, Interval = 0.0068),
    Documentation(info = "<html><body><h4>NicotinicAcid_Andersson2017_PD_i</h4><p>The steady-state exposure-response curve of Andersson R et al., <i>Journal of pharmacokinetics and pharmacodynamics 44(3):203–222</i> 2017 (<a href=\"https://doi.org/10.1007/s10928-017-9512-6\">doi:10.1007/s10928-017-9512-6</a>) — Insulin [nM] against Nicotinic acid μM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.188 nM       drug-free response (baseline) (Baseline insulin conc. (Lean), Q324)
  Emax  =      0.793          maximal effect term (Efficacy - NiAc on insulin (Lean), Q323)
  EC50  =      0.338 μM       exposure at half of the maximal effect term (Potency - NiAc on insulin (Lean), Q322)
  gamma =       3.54          Hill coefficient (Hill coefficient - NiAc on insulin (Lean), Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μM of Nicotinic acid per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.188   (drug-free)
  exposure = EC50 (0.338 μM)  response 0.1135
  exposure -> infinity  response 0.03892</pre></body></html>"));
end NicotinicAcid_Andersson2017_PD_i;
