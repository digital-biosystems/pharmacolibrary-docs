function p = NicotinicAcid_Ahlstrm2011_PD_nefa_params()
% NicotinicAcid_Ahlstrm2011_PD_nefa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nicotinic_acid Ahlström_2011::NEFA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmol L−1 per second, in SI inside (kg/m3, s). Response NEFA in mmol L−1. Driver: nicotinic acid (pk_record).
p.E0 = 0.6059999999999999;
p.Emax = 1.0;
p.EC50 = 4.459999999999999e-05;
p.gamma = 1.48;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.45;
p.form = 'E0*(1 - Emax*frac)';
end
