model NicotinicAcid_Ahlstrm2011_PD_nefa
  "indirect_response_i exposure-response sweep — Ahlström_2011 :: NEFA (non-esterified fatty acids)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.606,      // [mol/m3; mmol L−1 × 1]
    Emax = 1,  // type I effect term
    EC50 = 4.46e-05,  // [mol/m3; μmol L−1 × 0.001]
    gamma = 1.48,
    exposure_per_s = 0.001);   // 1 μmol L−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // family_inferred: the record's model family is transduction; read from the parameters: kin, kout and Imax 1.0 (≤ 1, an inhibition fraction) — indirect response I
  annotation(experiment(StartTime = 0, StopTime = 0.45, Interval = 0.0009),
    Documentation(info = "<html><body><h4>NicotinicAcid_Ahlstrm2011_PD_nefa</h4><p>The steady-state exposure-response curve of Ahlström C et al., <i>Journal of pharmacokinetics and pharmacodynamics 38(1):1-24</i> 2011 (<a href=\"https://doi.org/10.1007/s10928-010-9172-2\">doi:10.1007/s10928-010-9172-2</a>) — non-esterified fatty acids [mmol L−1] against nicotinic acid μmol L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.606 mmol L−1 drug-free response (baseline) (Baseline NEFA concentration, Q324)
  Emax  =          1          maximal effect term (Efficacy, Q323)
  EC50  =     0.0446 μmol L−1 exposure at half of the maximal effect term (Potency, Q322)
  gamma =       1.48          Hill coefficient (Sigmoidicity factor, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μmol L−1 of nicotinic acid per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.606   (drug-free)
  exposure = EC50 (0.0446 μmol L−1)  response 0.303
  exposure -> infinity  response 0</pre></body></html>"));
end NicotinicAcid_Ahlstrm2011_PD_nefa;
