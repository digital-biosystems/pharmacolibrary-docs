model NicotinicAcid_Ahlstrm20132_PD_nefa
  "indirect_response_i exposure-response sweep — Ahlström_2013_2 :: NEFA (NEFA (R))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 6.8e-05,  // [mol/m3; nmol L(-1) × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol L(-1) per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 680, Interval = 1.36),
    Documentation(info = "<html><body><h4>NicotinicAcid_Ahlstrm20132_PD_nefa</h4><p>The steady-state exposure-response curve of Ahlström C et al., <i>Journal of pharmacokinetics and pharmacodynamics 40(4):497-512</i> 2013 (<a href=\"https://doi.org/10.1007/s10928-013-9325-1\">doi:10.1007/s10928-013-9325-1</a>) — NEFA (R) against NiAc nmol L(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =         68 nmol L(-1) exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nmol L(-1) of NiAc per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (68 nmol L(-1))  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end NicotinicAcid_Ahlstrm20132_PD_nefa;
