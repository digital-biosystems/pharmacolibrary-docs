function p = NicotinicAcid_Ahlstrm20132_PD_nefa_params()
% NicotinicAcid_Ahlstrm20132_PD_nefa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nicotinic_acid Ahlström_2013_2::NEFA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol L(-1) per second, in SI inside (kg/m3, s). Response NEFA in its own unit. Driver: NiAc (not_resolved).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 6.8e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 680.0;
p.form = 'E0*(1 - Emax*frac)';
end
