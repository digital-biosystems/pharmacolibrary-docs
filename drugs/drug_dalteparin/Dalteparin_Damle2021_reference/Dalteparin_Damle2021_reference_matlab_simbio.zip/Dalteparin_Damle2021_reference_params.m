function p = Dalteparin_Damle2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dalteparin   source: Damle_2021 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Dalteparin_Damle2021_reference_params';
  p.drug  = 'dalteparin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.18;                % central volume [L]
  p.CL = 0.929;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.04;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
