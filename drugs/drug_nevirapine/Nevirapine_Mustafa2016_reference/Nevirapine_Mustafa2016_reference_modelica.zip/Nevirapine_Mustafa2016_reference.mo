model Nevirapine_Mustafa2016_reference
  parameter Real Cl_ref = 8.11111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07823000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26629790000000003,
    adminMass = 0.0004,
    ka = 0.0007083333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nevirapine</h4><p>This antiviral agent belongs to the non-nucleoside reverse transcriptase inhibitor class and is used to treat HIV infections. It is administered orally in tablet or suspension forms. The medication is widely available as a generic and is listed as an essential medicine by the World Health Organization.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q263713\">Wikidata Q263713</a>, <a href=\"https://en.wikipedia.org/wiki/Nevirapine?oldid=1328920477\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nevirapine</td></tr><tr><td>population:</td><td>HIV-infected Malaysian patients</td></tr><tr><td>source_paper:</td><td>Mustafa_2016</td></tr><tr><td>measured_compound:</td><td>nevirapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nevirapine 266.298 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (median nevirapine clearance); Q61 (volume of distribution)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nevirapine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Nevirapine_Mustafa2016_reference;
