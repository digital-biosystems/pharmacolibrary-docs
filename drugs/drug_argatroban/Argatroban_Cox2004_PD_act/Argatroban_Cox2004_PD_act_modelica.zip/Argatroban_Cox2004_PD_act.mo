model Argatroban_Cox2004_PD_act
  "sigmoid_emax exposure-response sweep — Cox_2004 :: ACT (activated clotting time)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 148,      // [s; sec × 1]
    Emax = 316,  // [s; sec × 1]
    EC50 = 0.00192,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 20000, Interval = 40),
    Documentation(info = "<html><body><h4>Argatroban_Cox2004_PD_act</h4><p>The steady-state exposure-response curve of Cox DS et al., <i>Journal of clinical pharmacology 44(9):981–990</i> 2004 (<a href=\"https://doi.org/10.1177/0091270004267651\">doi:10.1177/0091270004267651</a>) — activated clotting time [sec] against argatroban ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        148 sec      drug-free response (baseline) (E 0 (sec), Q324)
  Emax  =        316 sec      maximal effect term (E max (sec), Q320)
  EC50  =       1920 ng/mL    exposure at half of the maximal effect term (EC 50 (ng/mL), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of argatroban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 148   (drug-free)
  exposure = EC50 (1920 ng/mL)  response 306
  exposure -> infinity  response 464</pre></body></html>"));
end Argatroban_Cox2004_PD_act;
