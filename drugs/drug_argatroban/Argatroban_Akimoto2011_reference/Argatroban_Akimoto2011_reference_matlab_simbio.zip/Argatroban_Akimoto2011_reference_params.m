function p = Argatroban_Akimoto2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: argatroban   source: Akimoto_2011 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Argatroban_Akimoto2011_reference_params';
  p.drug  = 'argatroban';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9.2;                % central volume [L]
  p.CL = 21.0;                % clearance [L/h]
  p.Vp = [6.6];             % peripheral volumes [L]
  p.Q  = [9.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.05;             % dose [mg]
end
