function p = PropionicAcid_Adachi2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propionic_acid   source: Adachi_2021 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'PropionicAcid_Adachi2021_reference_params';
  p.drug  = 'propionic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.4;                % central volume [L]
  p.CL = 76.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
