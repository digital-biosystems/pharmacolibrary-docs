model Pegfilgrastim_Brekkan2018_PD_anc
  "indirect_response_iii exposure-response sweep — Brekkan_2018 :: ANC (absolute neutrophil count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.7,      // [10 9 cells/L]
    Emax = 102,  // type III effect term
    EC50 = 9.24e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 93, Interval = 0.186),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pegfilgrastim</h4><p>Pegfilgrastim is a long-acting granulocyte colony-stimulating factor used to prevent or treat neutropenia, including chemotherapy-induced febrile neutropenia, in cancer patients such as those with lymphoma. It is an approved medicine with several products authorised in the European Union, and it is widely used in oncology care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1592932\">Wikidata Q1592932</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pegfilgrastim_Brekkan2018_PD_anc</h4><p>The steady-state exposure-response curve of Brekkan A et al., <i>The AAPS journal 20(5):91</i> 2018 (<a href=\"https://doi.org/10.1208/s12248-018-0249-y\">doi:10.1208/s12248-018-0249-y</a>) — absolute neutrophil count [10^9 cells/L] against pegfilgrastim ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.7 10 9 cells/L drug-free response (baseline) (Base neutrophil count, Q324)
  Emax  =        102          maximal effect term (Maximum effect of PG on ANC maturation rate, Q320)
  EC50  =       9.24 ng/mL    exposure at half of the maximal effect term (Concentration eliciting half of the maximum effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of pegfilgrastim per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.7   (drug-free)
  exposure = EC50 (9.24 ng/mL)  response 140.4
  exposure -> infinity  response 278.1</pre></body></html>"));
end Pegfilgrastim_Brekkan2018_PD_anc;
