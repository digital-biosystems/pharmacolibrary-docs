function p = Pegfilgrastim_Brekkan2018_PD_anc_params()
% Pegfilgrastim_Brekkan2018_PD_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pegfilgrastim Brekkan_2018::ANC: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ANC in 10^9 cells/L. Driver: pegfilgrastim (conc_no_pk).
p.E0 = 2.7;
p.Emax = 102.0;
p.EC50 = 9.24e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 93.0;
p.form = 'E0*(1 + Emax*frac)';
end
