function p = Donidalorsen_Diep2026_PD_pkk_params()
% Donidalorsen_Diep2026_PD_pkk_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% donidalorsen Diep_2026::PKK: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response PKK in mg/L. Driver: donidalorsen (pk_record).
p.E0 = 0.0;
p.Emax = 0.992;
p.EC50 = 0.158;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.6;
p.form = 'E0*(1 - Emax*frac)';
end
