model Donidalorsen_Diep2026_PD_pkk
  "indirect_response_i exposure-response sweep — Diep_2026 :: PKK (prekallikrein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.992,  // type I effect term
    EC50 = 0.158,  // [unknown]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'unknown' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.6, Interval = 0.0032),
    Documentation(info = "<html><body><h4>Donidalorsen_Diep2026_PD_pkk</h4><p>The steady-state exposure-response curve of Diep JK et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(2):e70206</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70206\">doi:10.1002/psp4.70206</a>) — prekallikrein [mg/L] against donidalorsen — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.992          maximal effect term (I max — Estimate, Q323)
  EC50  =      0.158 unknown  exposure at half of the maximal effect term (IC50 (ng/mL) b — Estimate, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one  of donidalorsen per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.158 )  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Donidalorsen_Diep2026_PD_pkk;
