function p = Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont_params()
% Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dibromomethane Posman_2025::CH4_produced_proportion_of_control: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µmol l-1 per second, in SI inside (kg/m3, s). Response CH4 produced (proportion of control) in its own unit. Driver: dibromomethane (pk_record).
p.E0 = 763.0;
p.Emax = -146.0;
p.EC50 = 0.0013599999999999999;
p.gamma = 7.46;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
