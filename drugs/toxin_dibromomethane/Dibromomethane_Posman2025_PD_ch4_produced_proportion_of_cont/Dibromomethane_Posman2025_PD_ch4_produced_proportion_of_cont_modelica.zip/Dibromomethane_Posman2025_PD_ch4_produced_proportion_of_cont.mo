model Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont
  "sigmoid_emax exposure-response sweep — Posman_2025 :: CH4 produced (proportion of control) (CH4 produced (proportion of control))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 763,      // [µmol]
    Emax = -146,  // [µmol]
    EC50 = 0.00136,  // [mol/m3; µmol l-1 × 0.001]
    gamma = 7.46,
    exposure_per_s = 0.001);   // 1 µmol l-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 14, Interval = 0.028),
    Documentation(info = "<html><body><h4>Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont</h4><p>The steady-state exposure-response curve of Posman KM et al., <i>Scientific reports 15(1):25171</i> 2025 (<a href=\"https://doi.org/10.1038/s41598-025-10936-9\">doi:10.1038/s41598-025-10936-9</a>) — CH4 produced (proportion of control) against dibromomethane µmol l-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        763 µmol     drug-free response (baseline) (Maximum value, Q324)
  Emax  =        146 µmol     maximal effect term (Minimum value, Q323)
  EC50  =       1.36 µmol l-1 exposure at half of the maximal effect term (EC50, Q321)
  gamma =       7.46          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µmol l-1 of dibromomethane per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 763   (drug-free)
  exposure = EC50 (1.36 µmol l-1)  response 690
  exposure -> infinity  response 617</pre></body></html>"));
end Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont;
