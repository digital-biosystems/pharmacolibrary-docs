#!/usr/bin/env python3
"""Sweep Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont")
E0, Emax, EC50, gamma, slope, exposure_per_s = 763.0, -146.0, 0.0013599999999999999, 7.46, 0.0, 0.001
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma))
x = [exposure_per_s * 14.0 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [µmol l-1]"); plt.ylabel("response []")
plt.title("Dibromomethane_Posman2025_PD_ch4_produced_proportion_of_cont"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
