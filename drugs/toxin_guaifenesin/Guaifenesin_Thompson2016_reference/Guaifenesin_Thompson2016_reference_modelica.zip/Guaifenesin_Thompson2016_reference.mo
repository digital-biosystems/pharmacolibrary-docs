model Guaifenesin_Thompson2016_reference
  parameter Real Cl_ref = 1.606753672714651e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05007 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.19821799999999998,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>guaifenesin</td></tr><tr><td>population:</td><td>Children aged 2 to 17 years</td></tr><tr><td>source_paper:</td><td>Thompson_2016</td></tr><tr><td>measured_compound:</td><td>Guaifenesin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>guaifenesin 198.218 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PK Parameter' — extend the ontology if this is a real PK parameter (source ['Thompson_2016_table_2:row0:col1', 'Thompson_2016_table_2:row0:col2', 'Thompson_2016_table_2:row0:col3', 'Thompson_2016_table_2:row0:col4'])</li><li>unit_dimension_unknown: 'L/h; normalized to 70 kg' (CLnorm)</li><li>implicit units: 'CLo,scaled (L/h; normalized to 70 kg)' → L/h (from the paper text: 'The parameter name explicitly includes the unit: &quot;CLo,scaled (L/h; normalized to 70 kg)&quot;.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Guaifenesin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL/F=57.8431 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Guaifenesin_Thompson2016_reference;
