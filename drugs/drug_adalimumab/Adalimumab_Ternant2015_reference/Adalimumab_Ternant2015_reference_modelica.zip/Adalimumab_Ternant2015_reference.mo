model Adalimumab_Ternant2015_reference
  parameter Real Cl_ref = 3.703703703703704e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0108 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.240740740740741e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About adalimumab</h4><p>Adalimumab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and other arthritis, psoriasis, ankylosing spondylitis, uveitis, ulcerative colitis, Crohn's disease, and hidradenitis suppurativa. It is widely used and authorised in the European Union, where several products are approved, though some have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q348260\">Wikidata Q348260</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>adalimumab</td></tr><tr><td>population:</td><td>adults with rheumatoid arthritis</td></tr><tr><td>source_paper:</td><td>Ternant_2015</td></tr><tr><td>measured_compound:</td><td>adalimumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'CRP input (kin )' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ternant_2015:abstract'])</li><li>dropped PD-category row 'adalimumab concentration leading to a 50% decrease in kin (C50 )' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ternant_2015:abstract'])</li><li>dropped PD-category row 'baseline DAS28 (DAS0 )' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ternant_2015:abstract'])</li><li>dropped PD-category row 'adalimumab concentration leading to 50% decrease of DAS0 (IC50 )' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ternant_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=adalimumab</li><li>molar mass: none found for 'adalimumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 11491200, Tolerance = 1e-9, Interval = 1));
end Adalimumab_Ternant2015_reference;
