function p = Adalimumab_Ternant2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: adalimumab   source: Ternant_2015 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Adalimumab_Ternant2015_reference_params';
  p.drug  = 'adalimumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.8;                % central volume [L]
  p.CL = 0.013333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.011667;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
