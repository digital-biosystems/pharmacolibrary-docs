% Run (SimBiology): build model + dose, simulate 0..3192.0 h, plot.
p = Adalimumab_Ternant2015_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3192.0);
