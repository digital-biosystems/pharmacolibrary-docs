function p = Levobupivacaine_Vincent2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levobupivacaine   source: Vincent_2020 / reference   route: oral
  p.name  = 'Levobupivacaine_Vincent2020_reference_params';
  p.drug  = 'levobupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.0;                % central volume [L]
  p.CL = 9.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 10.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 28.0;             % dose [mg]
end
