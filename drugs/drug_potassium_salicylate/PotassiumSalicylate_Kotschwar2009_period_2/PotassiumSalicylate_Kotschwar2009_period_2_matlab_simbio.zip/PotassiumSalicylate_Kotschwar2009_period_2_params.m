function p = PotassiumSalicylate_Kotschwar2009_period_2_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium_salicylate   source: Kotschwar_2009 / period_2   route: oral
  % estimated (absent from source): F
  p.name  = 'PotassiumSalicylate_Kotschwar2009_period_2_params';
  p.drug  = 'potassium_salicylate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.0;                % central volume [L]
  p.CL = 18.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.22;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.81;             % absorption lag [h]
  p.dose = 3500.0;             % dose [mg]
end
