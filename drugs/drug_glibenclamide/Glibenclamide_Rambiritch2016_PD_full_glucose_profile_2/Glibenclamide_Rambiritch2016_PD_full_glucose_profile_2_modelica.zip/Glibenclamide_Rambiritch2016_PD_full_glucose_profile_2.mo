model Glibenclamide_Rambiritch2016_PD_full_glucose_profile_2
  "emax exposure-response sweep — Rambiritch_2016 :: full glucose profile (full glucose profile)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 15.4,      // [mol/m3; mmol/L × 1]
    Emax = -0.31,  // [mol/m3; mmol/L × 1]
    EC50 = 0.0436,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 440, Interval = 0.88),
    Documentation(info = "<html><body><h4>Glibenclamide_Rambiritch2016_PD_full_glucose_profile_2</h4><p>The steady-state exposure-response curve of Rambiritch V et al., <i>Clinical pharmacology : advances and applications 8:141–153</i> 2016 (<a href=\"https://doi.org/10.2147/CPAA.S102674\">doi:10.2147/CPAA.S102674</a>) — full glucose profile [mmol/L] against glibenclamide mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       15.4 mmol/L   drug-free response (baseline) (A0, Q324)
  Emax  =       0.31 mmol/L   maximal effect term (Emax, Q323)
  EC50  =       43.6 mg/L     exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of glibenclamide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 15.4   (drug-free)
  exposure = EC50 (43.6 mg/L)  response 15.24
  exposure -> infinity  response 15.09</pre></body></html>"));
end Glibenclamide_Rambiritch2016_PD_full_glucose_profile_2;
