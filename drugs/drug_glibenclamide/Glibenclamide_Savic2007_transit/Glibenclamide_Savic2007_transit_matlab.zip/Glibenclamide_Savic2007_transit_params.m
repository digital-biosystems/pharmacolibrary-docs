function p = Glibenclamide_Savic2007_transit_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glibenclamide   source: Savic_2007 / transit   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'Glibenclamide_Savic2007_transit_params';
  p.drug  = 'glibenclamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.39;                % central volume [L]
  p.CL = 10.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
