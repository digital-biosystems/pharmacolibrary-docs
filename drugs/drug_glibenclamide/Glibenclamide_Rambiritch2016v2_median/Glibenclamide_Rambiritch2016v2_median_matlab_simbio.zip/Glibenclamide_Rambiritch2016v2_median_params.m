function p = Glibenclamide_Rambiritch2016v2_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glibenclamide   source: Rambiritch_2016_2 / median   route: oral
  % estimated (absent from source): ka
  p.name  = 'Glibenclamide_Rambiritch2016v2_median_params';
  p.drug  = 'glibenclamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.61;                % central volume [L]
  p.CL = 1.71;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
