model Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2
  "emax exposure-response sweep — Rambiritch_2016 :: mean glucose concentration (mean glucose concentration)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 16.7,      // [mol/m3; mmol/L × 1]
    Emax = -0.34,  // [1]
    EC50 = 0.036,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 360, Interval = 0.72),
    Documentation(info = "<html><body><!-- drug-about --><h4>About glibenclamide</h4><p>Glibenclamide (glyburide) is a sulfonylurea anti-diabetic medicine used to lower blood sugar in diabetes, including a form of maturity-onset diabetes of the young. It is an approved medicine, appears on the WHO essential medicines list, and is authorised in the European Union for diabetes.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420626\">Wikidata Q420626</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2</h4><p>The steady-state exposure-response curve of Rambiritch V et al., <i>Clinical pharmacology : advances and applications 8:141–153</i> 2016 (<a href=\"https://doi.org/10.2147/CPAA.S102674\">doi:10.2147/CPAA.S102674</a>) — mean glucose concentration against glibenclamide mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       16.7 mmol/L   drug-free response (baseline) (E0, Q324)
  Emax  =       0.34          maximal effect term (Emax, Q323)
  EC50  =         36 mg/L     exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of glibenclamide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 16.7   (drug-free)
  exposure = EC50 (36 mg/L)  response 16.53
  exposure -> infinity  response 16.36</pre></body></html>"));
end Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2;
