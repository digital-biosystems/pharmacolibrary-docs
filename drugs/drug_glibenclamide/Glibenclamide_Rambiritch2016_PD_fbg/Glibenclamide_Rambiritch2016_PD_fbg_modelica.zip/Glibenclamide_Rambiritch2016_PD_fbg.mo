model Glibenclamide_Rambiritch2016_PD_fbg
  "emax exposure-response sweep — Rambiritch_2016 :: FBG (fasting blood glucose)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 14.1,      // [mol/m3; mmol/L × 1]
    Emax = -0.37,  // [mol/m3; mmol/L × 1]
    EC50 = 4.56e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><h4>Glibenclamide_Rambiritch2016_PD_fbg</h4><p>The steady-state exposure-response curve of Rambiritch V et al., <i>Clinical pharmacology : advances and applications 8:141–153</i> 2016 (<a href=\"https://doi.org/10.2147/CPAA.S102674\">doi:10.2147/CPAA.S102674</a>) — fasting blood glucose [mmol/L] against glibenclamide mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       14.1 mmol/L   drug-free response (baseline) (E0, Q324)
  Emax  =       0.37 mmol/L   maximal effect term (Emax, Q323)
  EC50  =       4.56 mg       exposure at half of the maximal effect term (ED50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of glibenclamide per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 14.1   (drug-free)
  exposure = EC50 (4.56 mg)  response 13.91
  exposure -> infinity  response 13.73</pre></body></html>"));
end Glibenclamide_Rambiritch2016_PD_fbg;
