model Trospium_Oefelein2013_reference
  parameter Real Cl_ref = 3.527777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.3082070091772944 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392518,
    adminMass = 4e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trospium</h4><p>Trospium is a muscarinic antagonist used as an antispasmodic and to treat urinary frequency and incontinence. It is an approved drug, used mainly for overactive bladder and gastrointestinal spasms.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q513396\">Wikidata Q513396</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trospium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Oefelein_2013</td></tr><tr><td>measured_compound:</td><td>trospium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>trospium 392.518 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Oefelein_2013) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Trospium_Oefelein2013_reference;
