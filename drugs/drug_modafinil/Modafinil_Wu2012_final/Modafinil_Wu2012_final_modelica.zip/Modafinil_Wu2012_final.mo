model Modafinil_Wu2012_final
  parameter Real Cl_ref = 1.3722222222222224e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0027300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.274334,
    adminMass = 0.0002,
    ka = 0.00020972222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About modafinil</h4><p>It is taken by mouth in the form of tablets or liquid-filled capsules. The medication is a prescription item in most countries and serves as a first-line therapy in the United States and Europe.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q410441\">Wikidata Q410441</a>, <a href=\"https://en.wikipedia.org/wiki/Modafinil?oldid=1379256062\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>modafinil</td></tr><tr><td>population:</td><td>healthy volunteers from 5 major ethnic groups of China</td></tr><tr><td>source_paper:</td><td>Wu_2012</td></tr><tr><td>measured_compound:</td><td>modafinil acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_M1</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>modafinil 273.35 g/mol (drugbank); modafinil acid 274.334 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is modafinil; the compartment is modafinil acid. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is modafinil acid, not modafinil</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>modafinil's own concentration-time course is not produced by this model</li><li>PK_3M template not built: the parent has no clearance</li><li>PK_3M template not built: the parent has no clearance</li><li>dropped duplicate Q22 ('CL1/F1 (l/h) Female', value '3.14') — already have one for this compound</li><li>dropped duplicate Q30 ('CL2/F1 (l/h) Female', value '4.84') — already have one for this compound</li><li>dropped duplicate Q64 ('V2/F1 (l) Female', value '20.41') — already have one for this compound</li><li>dropped value-less row: 'F 1'</li><li>dropped value-less row: 'F 2'</li><li>NIL: refused to back-fill base 'omega_cov' from footnote/prose loose number 1 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 1 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>metabolite modafinil acid: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite modafinil acid: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite volume: '(l)' Q63→Q61 for modafinil acid — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=modafinil acid</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Modafinil_Wu2012_final;
