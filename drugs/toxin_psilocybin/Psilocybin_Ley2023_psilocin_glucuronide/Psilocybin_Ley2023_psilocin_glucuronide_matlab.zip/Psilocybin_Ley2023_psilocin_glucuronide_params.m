function p = Psilocybin_Ley2023_psilocin_glucuronide_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: psilocybin   source: Ley_2023 / psilocin_glucuronide   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Psilocybin_Ley2023_psilocin_glucuronide_params';
  p.drug  = 'psilocybin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 190.0;                % central volume [L]
  p.CL = 41.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
