model Psilocybin_Ley2023_psilocin
  parameter Real Cl_ref = 4.305555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.505 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.284252,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>psilocybin</td></tr><tr><td>population:</td><td>healthy participants</td></tr><tr><td>source_paper:</td><td>Ley_2023</td></tr><tr><td>measured_compound:</td><td>Psilocybin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Psilocin 204.273 g/mol (pubchem); Psilocybin 284.252 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Psilocybin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'psilocin' subgroup of Ley_2023 (paper reports 5 populations: 4-hiaa, nam, psilocin, psilocin glucuronide, tmpaa)</li><li>row roles: 7 per-group rows of Mescaline summary_statistic but 0 reference group(s) — kept as printed</li><li>row roles: 70 row(s) kept on the molecule their table section names, against the LLM's assignment</li><li>row roles (LLM): model_class=noncompartmental; 7/7 row label(s) assigned, 0 linked by role; re-tagged Psilocin→Mescaline ×42, Psilocin→LSD ×14, Psilocin→parent ×21</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Ludbrook_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Psilocybin_Ley2023_psilocin;
