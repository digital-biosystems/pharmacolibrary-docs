// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Psilocybin_Meshkat2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7200.0},
    MM = 0.20427299999999998,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>psilocybin</td></tr><tr><td>population:</td><td>healthy human participants and animal models</td></tr><tr><td>source_paper:</td><td>Meshkat_2025</td></tr><tr><td>measured_compound:</td><td>Psilocin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Psilocin 204.273 g/mol (pubchem); Psilocybin 284.252 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is psilocybin; the compartment is Psilocin. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Psilocin, not psilocybin</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>psilocybin's own concentration-time course is not produced by this model</li><li>salvaged Q61 ('volume of distribution'=1016) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('half-life of psilocin'=2) from results prose — parameter table was unreadable</li><li>metabolite psilocin: Q61→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Psilocin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>review gap-fill skipped: this record measures 'Psilocin', not psilocybin — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Psilocybin_Meshkat2025_reference;
