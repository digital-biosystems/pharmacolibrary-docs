// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Psilocybin_Holze2022_15_mg_psilocybin
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {15480.0},
    MM = 0.284252,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>psilocybin</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Holze_2022</td></tr><tr><td>measured_compound:</td><td>Psilocybin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>psilocybin 284.252 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Time to onset (h)' — extend the ontology if this is a real PK parameter (source ['Tab1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Time to offset (h)' — extend the ontology if this is a real PK parameter (source ['Tab1:row2:col1'])</li><li>dropped unlinked row (NIL): 'Effect duration (h)' — extend the ontology if this is a real PK parameter (source ['Tab1:row4:col1'])</li><li>dropped PD-category row 'Maximal effect (%)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab1:row5:col1'])</li><li>salvaged Q57 ('Elimination half-lives (t1/2) were 4.3 (2.5–6.0) h'=4.3) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Psilocybin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: '15 mg psilocybin' subgroup of Holze_2022 (paper reports 2 populations: 15 mg psilocybin, 30 mg psilocybin)</li><li>gap-filled Q22 (CL) from Hampsey_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Oster_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Ludbrook_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Psilocybin_Holze2022_15_mg_psilocybin;
