// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Psilocybin_Becker2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7200.0},
    MM = 0.20427299999999998,
    adminMass = 2.5e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>psilocybin</td></tr><tr><td>population:</td><td>Healthy subjects</td></tr><tr><td>source_paper:</td><td>Becker_2022</td></tr><tr><td>measured_compound:</td><td>Psilocin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>cpt2487-tbl-0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Psilocin 204.273 g/mol (pubchem); Psilocybin 284.252 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'T max, hour'; source reconciliation required</li><li>table representations disagree for 't 1/2, hour'; source reconciliation required</li><li>table representations disagree for 'AUC7, ng·hour/mL'; source reconciliation required</li><li>table representations disagree for 'AUC∞, ng·hour/mL'; source reconciliation required</li><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'T max, hour'; source reconciliation required</li><li>table representations disagree for 't 1/2, hour'; source reconciliation required</li><li>table representations disagree for 'AUC7, ng·hour/mL'; source reconciliation required</li><li>table representations disagree for 'AUC∞, ng·hour/mL'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Psilocin</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 0 linked by role</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Psilocybin_Becker2022_reference;
