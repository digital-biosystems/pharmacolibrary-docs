function p = Psilocybin_Dahmane2021_PD_qtcf_params()
% Psilocybin_Dahmane2021_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% psilocybin Dahmane_2021::QTcF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ΔQTcF in ms. Driver: psilocin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1470.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
