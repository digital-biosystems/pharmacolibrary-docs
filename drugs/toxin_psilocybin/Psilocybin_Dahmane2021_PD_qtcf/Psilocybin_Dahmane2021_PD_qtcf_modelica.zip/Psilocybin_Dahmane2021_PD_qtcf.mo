model Psilocybin_Dahmane2021_PD_qtcf
  "linear exposure-response sweep — Dahmane_2021 :: ΔQTcF (QTcF change)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1470,  // [meter ** 3 * second / kilogram; ms/(ng/mL) × 1000]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Psilocybin_Dahmane2021_PD_qtcf</h4><p>The steady-state exposure-response curve of Dahmane E et al., <i>Clinical pharmacology in drug development 10(1):78–85</i> 2021 (<a href=\"https://doi.org/10.1002/cpdd.796\">doi:10.1002/cpdd.796</a>) — QTcF change [ms] against psilocin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       1.47 ms/(ng/mL) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of psilocin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Psilocybin_Dahmane2021_PD_qtcf;
