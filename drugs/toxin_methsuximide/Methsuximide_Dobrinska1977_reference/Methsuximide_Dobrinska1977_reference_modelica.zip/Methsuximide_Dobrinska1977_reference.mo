// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Methsuximide_Dobrinska1977_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {54000.0},
    MM = 0.203241,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methsuximide</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Dobrinska_1977</td></tr><tr><td>measured_compound:</td><td>Methsuximide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Methsuximide 203.241 g/mol (pubchem); 2-methyl-2-phenylsuccinimide 189.214 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for fm from footnote/prose kept as documentation only (['Dobrinska_1977:abstract'])</li><li>dropped unlinked row (NIL): 'that of the parent drug' — extend the ontology if this is a real PK parameter (source ['Dobrinska_1977:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methsuximide</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 1 linked by role; re-tagged Methsuximide→2-methyl-2-phenylsuccinimide ×2, Methsuximide→parent ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Methsuximide_Dobrinska1977_reference;
