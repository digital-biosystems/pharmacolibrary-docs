model Rosuvastatin_Macpherson2016_full
  parameter Real Cl_ref = 4.1666666666666665e-05 "Cl [m3/s]";
  parameter Real cov_weight = 42.0 "weight covariate (reference 42.0)";
  parameter Real Vd_ref = 0.308 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_weight/42.0)^(0.398),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.0833333333333333e-05,
    Tlag = 0.0,
    k12 = 8.234126984126983e-05,
    k21 = 4.730667993119028e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rosuvastatin</td></tr><tr><td>population:</td><td>pediatric patients with heterozygous familial hypercholesterolemia</td></tr><tr><td>source_paper:</td><td>Macpherson_2016</td></tr><tr><td>measured_compound:</td><td>rosuvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['Macpherson_2016_table_p6_1:row12:col2'])</li><li>dropped unlinked row (NIL): 'Δ OFV' — extend the ontology if this is a real PK parameter (source ['Macpherson_2016_table_p6_1:row13:col2'])</li><li>dropped unlinked row (NIL): 'Condition no.' — extend the ontology if this is a real PK parameter (source ['Macpherson_2016_table_p6_1:row14:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rosuvastatin</li><li>model-stage split: 'covariate model 1' is the full model of Macpherson_2016 (paper reports 3 stages: covariate model 1, final base model, final model); same population, different model-building step</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rosuvastatin_Macpherson2016_full;
