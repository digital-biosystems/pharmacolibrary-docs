function p = Rosuvastatin_Macpherson2016_full_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rosuvastatin   source: Macpherson_2016 / full   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rosuvastatin_Macpherson2016_full_params';
  p.drug  = 'rosuvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 308.0;                % central volume [L]
  p.CL = 150.0;                % clearance [L/h]
  p.Vp = [5361.0];             % peripheral volumes [L]
  p.Q  = [91.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.183;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
