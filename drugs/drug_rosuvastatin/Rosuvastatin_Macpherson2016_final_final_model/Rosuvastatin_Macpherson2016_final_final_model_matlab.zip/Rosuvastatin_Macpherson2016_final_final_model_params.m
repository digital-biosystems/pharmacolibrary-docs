function p = Rosuvastatin_Macpherson2016_final_final_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rosuvastatin   source: Macpherson_2016 / final_final_model   route: oral
  p.name  = 'Rosuvastatin_Macpherson2016_final_final_model_params';
  p.drug  = 'rosuvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 303.0;                % central volume [L]
  p.CL = 129.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.183;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
