% Run: build params, simulate 0..25.0 h, plot + save Rosuvastatin_Macpherson2016_final_final_model.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Rosuvastatin_Macpherson2016_final_final_model.m
here = fileparts(mfilename('fullpath'));
p = Rosuvastatin_Macpherson2016_final_final_model_params();
out = simulate_pk(p, 0:0.05:25.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('rosuvastatin — Macpherson_2016 (oral)');
print(fig, fullfile(here, 'Rosuvastatin_Macpherson2016_final_final_model.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Rosuvastatin_Macpherson2016_final_final_model.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Rosuvastatin_Macpherson2016_final_final_model.json'), 'w');
try
  s.model = 'Rosuvastatin_Macpherson2016_final_final_model'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Rosuvastatin_Macpherson2016_final_final_model","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Rosuvastatin_Macpherson2016_final_final_model.png, Rosuvastatin_Macpherson2016_final_final_model.csv, Rosuvastatin_Macpherson2016_final_final_model.json\n');
