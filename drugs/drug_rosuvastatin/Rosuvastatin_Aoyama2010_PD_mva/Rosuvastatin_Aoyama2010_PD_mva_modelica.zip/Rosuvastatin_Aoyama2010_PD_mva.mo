model Rosuvastatin_Aoyama2010_PD_mva
  "indirect_response_i exposure-response sweep — Aoyama_2010 :: MVA (plasma mevalonic acid)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.97e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1.65,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 20, Interval = 0.04),
    Documentation(info = "<html><body><h4>Rosuvastatin_Aoyama2010_PD_mva</h4><p>The steady-state exposure-response curve of Aoyama T et al., <i>Biological &amp; pharmaceutical bulletin 33(6):1082–1087</i> 2010 (<a href=\"https://doi.org/10.1248/bpb.33.1082\">doi:10.1248/bpb.33.1082</a>) — plasma mevalonic acid [ng/ml] against rosuvastatin ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       1.97 ng/ml    exposure at half of the maximal effect term (IC 50, Q322)
  gamma =       1.65          Hill coefficient (g, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of rosuvastatin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.97 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Rosuvastatin_Aoyama2010_PD_mva;
