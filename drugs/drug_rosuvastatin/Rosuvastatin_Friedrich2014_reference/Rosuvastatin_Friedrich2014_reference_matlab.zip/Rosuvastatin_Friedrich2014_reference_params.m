function p = Rosuvastatin_Friedrich2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rosuvastatin   source: Friedrich_2014 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rosuvastatin_Friedrich2014_reference_params';
  p.drug  = 'rosuvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 755.972201;                % central volume [L]
  p.CL = 13.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
