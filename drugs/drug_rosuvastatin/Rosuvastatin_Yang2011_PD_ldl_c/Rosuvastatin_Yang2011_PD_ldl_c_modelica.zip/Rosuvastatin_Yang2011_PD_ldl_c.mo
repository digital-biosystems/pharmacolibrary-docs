model Rosuvastatin_Yang2011_PD_ldl_c
  "emax exposure-response sweep — Yang_2011 :: LDL-C (LDL-C reduction (%))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -0.00802,      // [1; % × 0.01]
    Emax = -0.57,  // [1; % × 0.01]
    EC50 = 1.74e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 18, Interval = 0.036),
    Documentation(info = "<html><body><h4>Rosuvastatin_Yang2011_PD_ldl_c</h4><p>The steady-state exposure-response curve of Yang J et al., <i>Acta pharmacologica Sinica 32(1):116–125</i> 2011 (<a href=\"https://doi.org/10.1038/aps.2010.169\">doi:10.1038/aps.2010.169</a>) — LDL-C reduction (%) [%] against rosuvastatin mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     -0.802 %        drug-free response (baseline) (E 0, Q324)
  Emax  =         57 %        maximal effect term (E max, Q320)
  EC50  =       1.74 mg       exposure at half of the maximal effect term (ED 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of rosuvastatin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -0.00802   (drug-free)
  exposure = EC50 (1.74 mg)  response -0.293
  exposure -> infinity  response -0.578</pre></body></html>"));
end Rosuvastatin_Yang2011_PD_ldl_c;
