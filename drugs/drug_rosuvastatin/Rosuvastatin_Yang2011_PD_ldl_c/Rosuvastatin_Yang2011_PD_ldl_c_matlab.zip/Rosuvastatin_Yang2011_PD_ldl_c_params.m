function p = Rosuvastatin_Yang2011_PD_ldl_c_params()
% Rosuvastatin_Yang2011_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rosuvastatin Yang_2011::LDL_C: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response LDL-C in %. Driver: rosuvastatin (dose_only).
p.E0 = -0.008020000000000001;
p.Emax = -0.5700000000000001;
p.EC50 = 1.7399999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 18.0;
p.form = 'E0 + Emax*frac';
end
