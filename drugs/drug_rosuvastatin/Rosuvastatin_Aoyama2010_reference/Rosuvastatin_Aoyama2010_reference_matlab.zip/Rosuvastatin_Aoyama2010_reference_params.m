function p = Rosuvastatin_Aoyama2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rosuvastatin   source: Aoyama_2010 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rosuvastatin_Aoyama2010_reference_params';
  p.drug  = 'rosuvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1170.0;                % central volume [L]
  p.CL = 264.0;                % clearance [L/h]
  p.Vp = [3700.0];             % peripheral volumes [L]
  p.Q  = [148.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.368;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
