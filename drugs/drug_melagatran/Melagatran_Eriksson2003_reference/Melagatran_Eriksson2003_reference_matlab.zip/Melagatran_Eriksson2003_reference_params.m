function p = Melagatran_Eriksson2003_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: melagatran   source: Eriksson_2003 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Melagatran_Eriksson2003_reference_params';
  p.drug  = 'melagatran';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.5;                % central volume [L]
  p.CL = 5.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
