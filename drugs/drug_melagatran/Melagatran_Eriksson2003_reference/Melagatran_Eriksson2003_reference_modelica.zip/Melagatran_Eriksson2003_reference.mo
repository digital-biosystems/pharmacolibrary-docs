model Melagatran_Eriksson2003_reference
  parameter Real Cl_ref = 1.4722222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0155 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4295126,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About melagatran</h4><p>Melagatran is a direct thrombin inhibitor that was investigated as an antithrombotic drug for preventing or treating blood clots. It remained an investigational compound and was never authorised for general use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27084209\">Wikidata Q27084209</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>melagatran</td></tr><tr><td>population:</td><td>orthopaedic surgery patients</td></tr><tr><td>source_paper:</td><td>Eriksson_2003</td></tr><tr><td>measured_compound:</td><td>melagatran</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>melagatran 429.513 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('median population clearance (creatinine clearance 70 mL/min) ... oral', value 22.9) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=melagatran</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Melagatran_Eriksson2003_reference;
