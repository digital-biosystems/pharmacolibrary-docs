model Carbamazepine_Milovanovic2016_reference
  parameter Real Cl_ref = 5.972222222222223e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.236274,
    adminMass = 0.00026,
    ka = 0.0002425,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbamazepine</td></tr><tr><td>population:</td><td>epileptic pediatric patients</td></tr><tr><td>source_paper:</td><td>Milovanovic_2016</td></tr><tr><td>measured_compound:</td><td>Carbamazepine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>j_bjmg-2016-0003_tab_002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>carbamazepine 236.274 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Sex' — extend the ontology if this is a real PK parameter (source ['j_bjmg-2016-0003_tab_002:row3:col1'])</li><li>dropped unlinked row (NIL): 'Daily dose of carbamazepine (mg/L)' — extend the ontology if this is a real PK parameter (source ['j_bjmg-2016-0003_tab_002:row4:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Carbamazepine</li><li>gap-filled Q61 (V) from Steulet_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chan_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chan_2023, Steulet_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Carbamazepine_Milovanovic2016_reference;
