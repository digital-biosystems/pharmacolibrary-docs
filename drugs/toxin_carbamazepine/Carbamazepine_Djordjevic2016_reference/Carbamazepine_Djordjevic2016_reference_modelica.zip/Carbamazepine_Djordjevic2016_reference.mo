model Carbamazepine_Djordjevic2016_reference
  parameter Real Cl_ref = 4.888888888888889e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.236274,
    adminMass = 0.001,
    ka = 0.0002425,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbamazepine</td></tr><tr><td>population:</td><td>Serbian pediatric epileptic patients</td></tr><tr><td>source_paper:</td><td>Djordjevic_2016</td></tr><tr><td>measured_compound:</td><td>Carbamazepine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>carbamazepine 236.274 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'SEX' — extend the ontology if this is a real PK parameter (source ['Djordjevic_2016:abstract'])</li><li>dropped unlinked row (NIL): 'CYP1A2' — extend the ontology if this is a real PK parameter (source ['Djordjevic_2016:abstract'])</li><li>dropped unlinked row (NIL): 'DD' — extend the ontology if this is a real PK parameter (source ['Djordjevic_2016:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Carbamazepine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Steulet_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chan_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chan_2023, Steulet_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Carbamazepine_Djordjevic2016_reference;
