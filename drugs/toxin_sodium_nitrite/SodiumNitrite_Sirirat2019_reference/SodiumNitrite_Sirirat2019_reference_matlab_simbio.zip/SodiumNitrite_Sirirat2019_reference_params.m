function p = SodiumNitrite_Sirirat2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_nitrite   source: Sirirat_2019 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'SodiumNitrite_Sirirat2019_reference_params';
  p.drug  = 'sodium_nitrite';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 91.0;                % central volume [L]
  p.CL = 105.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.18;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
