function p = Sunitinib_Wang2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sunitinib   source: Wang_2020 / reference   route: oral
  p.name  = 'Sunitinib_Wang2020_reference_params';
  p.drug  = 'sunitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1070.0;                % central volume [L]
  p.CL = 24.1;                % clearance [L/h]
  p.Vp = [63.8];             % peripheral volumes [L]
  p.Q  = [0.28];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 33.0;             % dose [mg]
end
