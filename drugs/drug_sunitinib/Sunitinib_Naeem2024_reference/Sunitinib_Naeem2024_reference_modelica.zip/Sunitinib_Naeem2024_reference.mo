model Sunitinib_Naeem2024_reference
  parameter Real Cl_ref = 1.3611111111111113e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0044 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3984738,
    adminMass = 3.3e-05,
    ka = 6.111111111111111e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sunitinib</h4><p>Sunitinib is a small-molecule protein kinase inhibitor used to treat renal cell carcinoma and gastrointestinal stromal tumor. It is given orally in capsule form.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417542\">Wikidata Q417542</a>, <a href=\"https://en.wikipedia.org/wiki/Sunitinib?oldid=1384696078\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sunitinib</td></tr><tr><td>population:</td><td>renal cell cancer patients</td></tr><tr><td>source_paper:</td><td>Naeem_2024</td></tr><tr><td>measured_compound:</td><td>sunitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sunitinib 398.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (V); Q22 (Cl)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sunitinib</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Sunitinib_Naeem2024_reference;
