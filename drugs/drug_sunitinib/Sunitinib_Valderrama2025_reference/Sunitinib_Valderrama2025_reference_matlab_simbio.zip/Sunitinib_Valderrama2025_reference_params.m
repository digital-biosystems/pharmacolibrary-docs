function p = Sunitinib_Valderrama2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sunitinib   source: Valderrama_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Sunitinib_Valderrama2025_reference_params';
  p.drug  = 'sunitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.1;                % central volume [L]
  p.CL = 223.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 13.92;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 37.5;             % dose [mg]
end
