% Run (SimBiology): build model + dose, simulate 0..3024.0 h, plot.
p = Tildrakizumab_Jauslin2019_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3024.0);
