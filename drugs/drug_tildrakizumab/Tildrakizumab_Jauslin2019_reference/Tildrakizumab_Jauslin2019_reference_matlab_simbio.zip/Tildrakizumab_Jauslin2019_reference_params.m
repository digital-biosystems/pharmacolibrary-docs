function p = Tildrakizumab_Jauslin2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tildrakizumab   source: Jauslin_2019 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Tildrakizumab_Jauslin2019_reference_params';
  p.drug  = 'tildrakizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.8;                % central volume [L]
  p.CL = 0.013333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.037833;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.2;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
