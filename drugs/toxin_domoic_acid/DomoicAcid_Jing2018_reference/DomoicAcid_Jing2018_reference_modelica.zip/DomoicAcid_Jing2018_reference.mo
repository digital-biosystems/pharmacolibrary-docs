model DomoicAcid_Jing2018_reference
  parameter Real Cl_ref = 2.4111111111111115e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00917 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.311334,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>domoic_acid</td></tr><tr><td>population:</td><td>cynomolgus monkeys</td></tr><tr><td>source_paper:</td><td>Jing_2018</td></tr><tr><td>measured_compound:</td><td>Domoic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Domoic acid 311.334 g/mol (pubchem); domoic_acid 311.33 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('average terminal half-life of DA', value 11.3) — already have one for this compound</li><li>implicit units: 'of the intravenous DA dose recovered in urine' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Domoic acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end DomoicAcid_Jing2018_reference;
