model Aspirin_Zhang2016_PD_rr
  "linear exposure-response sweep — Zhang_2016 :: RR (ovarian cancer risk)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.94,  // [1]
    exposure_per_s = 1);   // 1 frequency of use per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Aspirin_Zhang2016_PD_rr</h4><p>The steady-state exposure-response curve of Zhang D et al., <i>Gynecologic oncology 142(2):368–377</i> 2016 (<a href=\"https://doi.org/10.1016/j.ygyno.2016.04.543\">doi:10.1016/j.ygyno.2016.04.543</a>) — ovarian cancer risk against aspirin frequency of use — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.94          change in response per unit of exposure (slope (RR per 1 time/wk), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one frequency of use of aspirin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Aspirin_Zhang2016_PD_rr;
