function p = Aspirin_Koh2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aspirin   source: Koh_2025 / reference   route: oral
  p.name  = 'Aspirin_Koh2025_reference_params';
  p.drug  = 'aspirin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 23.51;                % central volume [L]
  p.CL = 2.76;                % clearance [L/h]
  p.Vp = [1.98];             % peripheral volumes [L]
  p.Q  = [0.08];             % inter-compartmental clearances [L/h]
  p.ka = 0.22;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
