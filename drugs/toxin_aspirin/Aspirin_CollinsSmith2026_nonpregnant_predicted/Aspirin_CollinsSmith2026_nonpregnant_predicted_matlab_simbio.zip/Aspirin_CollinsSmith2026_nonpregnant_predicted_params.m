function p = Aspirin_CollinsSmith2026_nonpregnant_predicted_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aspirin   source: Collins-Smith_2026 / nonpregnant_predicted   route: oral
  % estimated (absent from source): F
  p.name  = 'Aspirin_CollinsSmith2026_nonpregnant_predicted_params';
  p.drug  = 'aspirin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 3.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 8.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0475;             % absorption lag [h]
  p.dose = 81.0;             % dose [mg]
end
