function p = Aspirin_Yellepeddi2020_human_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aspirin   source: Yellepeddi_2020 / human   route: oral
  % estimated (absent from source): F
  p.name  = 'Aspirin_Yellepeddi2020_human_params';
  p.drug  = 'aspirin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 58.884;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 8.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0475;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
