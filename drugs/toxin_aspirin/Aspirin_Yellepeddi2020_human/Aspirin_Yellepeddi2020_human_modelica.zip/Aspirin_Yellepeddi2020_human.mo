model Aspirin_Yellepeddi2020_human
  parameter Real Cl_ref = 1.6356666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-06,
    ka = 0.0022500000000000003,
    Tlag = 171.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aspirin</td></tr><tr><td>population:</td><td>NOD/ShiLtJ mice and virtual human population (30-year-old Caucasian American)</td></tr><tr><td>source_paper:</td><td>Yellepeddi_2020</td></tr><tr><td>measured_compound:</td><td>aspirin-triggered resolvin D1 (AT-RvD1)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cre2260-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>aspirin 180.159 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=aspirin-triggered resolvin D1 (AT-RvD1)</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'human' subgroup of Yellepeddi_2020 (paper reports 2 populations: human, nod/shltj mice)</li><li>molar mass: no plausible PubChem entry for 'aspirin-triggered resolvin D1 (AT-RvD1)' ('aspirin-triggered resolvin D1') — left in mass units</li><li>molar mass: none found for 'aspirin-triggered resolvin D1 (AT-RvD1)' — its concentrations stay mass-only</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Kereiakes_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kereiakes_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Aspirin_Yellepeddi2020_human;
