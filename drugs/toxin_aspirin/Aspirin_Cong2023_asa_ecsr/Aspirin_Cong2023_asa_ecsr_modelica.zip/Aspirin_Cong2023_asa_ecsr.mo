// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Aspirin_Cong2023_asa_ecsr
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1548.0},
    MM = 0.18015899999999999,
    adminMass = 0.0001,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aspirin</td></tr><tr><td>population:</td><td>healthy Chinese participants</td></tr><tr><td>source_paper:</td><td>Cong_2023</td></tr><tr><td>measured_compound:</td><td>Acetylsalicylic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Acetylsalicylic acid 180.159 g/mol (pubchem); Salicylic acid 138.122 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'a.c. (n=16a)'; source reconciliation required</li><li>table representations disagree for 'a.c. (n=16a)'; source reconciliation required</li><li>table representations disagree for 'Tmax (h)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'a.c. (n=16a)' — extend the ontology if this is a real PK parameter (source ['t0002:row2:col2', 't0002:row2:col3'])</li><li>salvaged Q57 ('mean t1/2'=0.43) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Acetylsalicylic acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'asa / ecsr' subgroup of Cong_2023 (paper reports 4 populations: asa / ec, asa / ecsr, sa / ec, sa / ecsr)</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 0 linked by role</li><li>gap-filled Q22 (CL) from Calderin_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Aspirin_Cong2023_asa_ecsr;
