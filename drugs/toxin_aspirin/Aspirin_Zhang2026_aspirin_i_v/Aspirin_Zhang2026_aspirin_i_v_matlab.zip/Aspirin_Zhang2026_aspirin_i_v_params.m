function p = Aspirin_Zhang2026_aspirin_i_v_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aspirin   source: Zhang_2026 / aspirin_i_v   route: oral
  % estimated (absent from source): ka
  p.name  = 'Aspirin_Zhang2026_aspirin_i_v_params';
  p.drug  = 'aspirin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.13;                % central volume [L]
  p.CL = 4.97;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
