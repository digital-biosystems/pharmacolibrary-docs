model Aspirin_Zhang2026_reference
  parameter Real Cl_ref = 1.4583333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01792 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.13812200000000002,
    adminMass = 0.0007,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aspirin</td></tr><tr><td>population:</td><td>rats and mice (pregnant ICR mice for efficacy, rats for PK)</td></tr><tr><td>source_paper:</td><td>Zhang_2026</td></tr><tr><td>measured_compound:</td><td>Salicylic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Salicylic acid 138.122 g/mol (pubchem); aspirin 180.159 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 1.'</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['t0005:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['t0005:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q57 ('t1/2'=5.025) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Vz/F (L/kg)'=0.256) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F (L/h/kg)'=0.075) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Salicylic acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Zhang_2026:other_prose, t0005:footnote); populations aspirin (i.g.), aspirin (i.v.) kept as separate records</li><li>review gap-fill skipped: this record measures 'Salicylic acid', not aspirin — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Aspirin_Zhang2026_reference;
