// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Aspirin_Oh2023_aspirin_500_mg_fexuprazan_80_mg
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1476.0},
    MM = 0.18015899999999999,
    adminMass = 8e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aspirin</td></tr><tr><td>population:</td><td>Healthy Koreans</td></tr><tr><td>source_paper:</td><td>Oh_2023</td></tr><tr><td>measured_compound:</td><td>Aspirin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-00549-t001</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Aspirin 180.159 g/mol (pubchem); Salicylic acid 138.122 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Aspirin</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'aspirin 500 mg + fexuprazan 80 mg(n = 11)' subgroup of Oh_2023 (paper reports 4 populations: aspirin 500 mg + fexuprazan 80 mg(n = 11), aspirin 500 mg only(n = 11), fexuprazan 80 mg + aspirin 500 mg(n = 11), fexuprazan 80 mg only(n = 11))</li><li>row roles (LLM): model_class=noncompartmental; 9/9 row label(s) assigned, 0 linked by role; re-tagged Aspirin→parent ×10, Aspirin→Fexuprazan ×4, parent→Fexuprazan ×2</li><li>molar mass: no plausible PubChem entry for 'M14' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'M14' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Calderin_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kereiakes_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kereiakes_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Aspirin_Oh2023_aspirin_500_mg_fexuprazan_80_mg;
