function p = Aspirin_Kereiakes2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aspirin   source: Kereiakes_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Aspirin_Kereiakes2020_reference_params';
  p.drug  = 'aspirin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.4;                % central volume [L]
  p.CL = 29.1;                % clearance [L/h]
  p.Vp = [221.0];             % peripheral volumes [L]
  p.Q  = [31.62];             % inter-compartmental clearances [L/h]
  p.ka = 8.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0475;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
