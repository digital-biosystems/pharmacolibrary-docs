model Aspirin_CollinsSmith2026_fetal_plasma_30weeks
  parameter Real Cl_ref = 1.5833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 8.1e-05,
    ka = 0.0022500000000000003,
    Tlag = 171.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aspirin</td></tr><tr><td>population:</td><td>nonpregnant and pregnant healthy adults (first, second, and third trimester)</td></tr><tr><td>source_paper:</td><td>Collins-Smith_2026</td></tr><tr><td>measured_compound:</td><td>Aspirin; Salicylic Acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470130-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Aspirin 180.159 g/mol (pubchem); Salicylic Acid 138.122 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('clearance'=5.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Aspirin; Salicylic Acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'fetal plasma 30weeks' subgroup of Collins-Smith_2026 (paper reports 8 populations: aspirin, fetal plasma 10weeks, fetal plasma 20weeks, fetal plasma 30weeks, fetal plasma 40weeks, nonpregnant predicted, pregnant predicted, salicylic acid)</li><li>row roles (LLM): model_class=pbpk; 25/25 row label(s) assigned, 12 linked by role; re-tagged Salicylic Acid→parent ×35</li><li>molar mass: none of 2 PubChem candidate(s) is 'Aspirin; Salicylic Acid' (LLM) — left in mass units</li><li>molar mass: none found for 'Aspirin; Salicylic Acid' — its concentrations stay mass-only</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kereiakes_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kereiakes_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Calderin_2025, Kereiakes_2020 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Aspirin_CollinsSmith2026_fetal_plasma_30weeks;
