model Aspirin_Koh2025_PD_txb2
  "indirect_response_i exposure-response sweep — Koh_2025 :: TXB2 (Thromboxane B2)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 3.6,  // [mol/m3; mol/L × 1000]
    gamma = 1,
    exposure_per_s = 1000);   // 1 mol/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.036, Interval = 7.2e-05),
    Documentation(info = "<html><body><h4>Aspirin_Koh2025_PD_txb2</h4><p>The steady-state exposure-response curve of Koh J et al., <i>Drug design, development and therapy 19:7853-7863</i> 2025 (<a href=\"https://doi.org/10.2147/dddt.s533428\">doi:10.2147/dddt.s533428</a>) — Thromboxane B2 [μg/L] against acetylsalicylic acid mol/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (Imax, Q323)
  EC50  =     0.0036 mol/L    exposure at half of the maximal effect term (IC50, Q322)
  gamma =          1          Hill coefficient (Gamma, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mol/L of acetylsalicylic acid per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0036 mol/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Aspirin_Koh2025_PD_txb2;
