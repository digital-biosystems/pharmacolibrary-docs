function p = Gallamine_Ramzan1980_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gallamine   source: Ramzan_1980 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Gallamine_Ramzan1980_reference_params';
  p.drug  = 'gallamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.7696;                % central volume [L]
  p.CL = 5.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
