// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model UraniumTrioxide_Kalkwarf1983_calciner_discharge
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5184000.0},
    MM = 0.23803,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_trioxide</td></tr><tr><td>population:</td><td>Simulated lung fluid</td></tr><tr><td>source_paper:</td><td>Kalkwarf_1983</td></tr><tr><td>measured_compound:</td><td>Uranium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Uranium 238.03 g/mol (pubchem); uranium_trioxide 274.06 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Kalkwarf_1983_table_3: rows are variants (1, 2, 3), the parameters are the column headers (f1) — read one record per variant</li><li>transposed table Kalkwarf_1983_table_2: rows are variants (1 to 3 μm, 7 to 13, 18 to 44), the parameters are the column headers (f₁) — read one record per variant</li><li>transposed table Kalkwarf_1983_table_4: rows are variants (<0.5 um, 0.5 to 1.0, 1.0 to 3.0, 3.0 to 10, 10 to 15), the parameters are the column headers (f1) — read one record per variant</li><li>transposed table Kalkwarf_1983_table_5: rows are variants (Vaporizer/dissolver, Calciner entrance, Calciner discharge, Pellet press, Pellet grinder), the parameters are the column headers (f₁) — read one record per variant</li><li>salvaged Q57 ('dissolution half-time'=60) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'Calciner discharge' is one of 16 estimates of Kalkwarf_1983's substance matrix (1, 2, 3, 1 to 3 μm, 7 to 13, 18 to 44, <0.5 um, 0.5 to 1.0, 1.0 to 3.0, 3.0 to 10, 10 to 15, Vaporizer/dissolver, Calciner entrance, Calciner discharge, Pellet press, Pellet grinder); same population, different estimation method</li><li>review gap-fill skipped: this record measures 'Uranium', not uranium_trioxide — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end UraniumTrioxide_Kalkwarf1983_calciner_discharge;
