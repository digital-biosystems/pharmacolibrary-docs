% Run: build params, simulate 0..4320.0 h, plot every molecule + save UraniumTrioxide_Eidson1994_human_case_1.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_UraniumTrioxide_Eidson1994_human_case_1.m
here = fileparts(mfilename('fullpath'));
p = UraniumTrioxide_Eidson1994_human_case_1_params();
out = simulate_network(p, 0:0.05:4320.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('uranium_trioxide — Eidson_1994 (retention function)');
print(fig, fullfile(here, 'UraniumTrioxide_Eidson1994_human_case_1.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'UraniumTrioxide_Eidson1994_human_case_1.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'UraniumTrioxide_Eidson1994_human_case_1.json'), 'w');
try
  s.model = 'UraniumTrioxide_Eidson1994_human_case_1'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"UraniumTrioxide_Eidson1994_human_case_1"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote UraniumTrioxide_Eidson1994_human_case_1.png, UraniumTrioxide_Eidson1994_human_case_1.csv, UraniumTrioxide_Eidson1994_human_case_1.json\n');
