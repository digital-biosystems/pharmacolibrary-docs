// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model UraniumTrioxide_Eidson1994_human_case_2
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {142992000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_trioxide</td></tr><tr><td>population:</td><td>mammalian species (animals and humans)</td></tr><tr><td>source_paper:</td><td>Eidson_1994</td></tr><tr><td>measured_compound:</td><td>Uranium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_7</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>uranium_trioxide 274.06 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Eidson_1994_table_p10_1: rows are variants (Human case 1, Human case 2, Human case 3, 9 human cases, Beagle dog, Monkey), the parameters are the column headers (Clearance half time (d)) — read one record per variant</li><li>transposed table Eidson_1994_table_5: rows are variants (Beagle dog, Rat), the parameters are the column headers (Clearance) — read one record per variant</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>estimate-method split: 'Human case 2' is one of 7 estimates of Eidson_1994's substance matrix (Human case 1, Human case 2, Human case 3, 9 human cases, Beagle dog, Monkey, Rat); same population, different estimation method</li><li>molar mass: none of 1 PubChem candidate(s) is 'Uranium' (LLM) — left in mass units</li><li>molar mass: none found for 'Uranium' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Uranium', not uranium_trioxide — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end UraniumTrioxide_Eidson1994_human_case_2;
