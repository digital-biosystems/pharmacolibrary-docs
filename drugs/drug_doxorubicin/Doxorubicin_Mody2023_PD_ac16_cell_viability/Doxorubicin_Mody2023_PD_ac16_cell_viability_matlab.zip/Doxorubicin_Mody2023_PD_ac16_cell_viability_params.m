function p = Doxorubicin_Mody2023_PD_ac16_cell_viability_params()
% Doxorubicin_Mody2023_PD_ac16_cell_viability_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Mody_2023::AC16_cell_viability: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response AC16 cell viability in %. Driver: doxorubicin (pk_record).
p.E0 = 1.01;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 167000.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
