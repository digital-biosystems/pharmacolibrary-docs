model Doxorubicin_Mohmaed2024_reference
  parameter Real Cl_ref = 1.2277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0116 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>patients across all age groups</td></tr><tr><td>source_paper:</td><td>Mohmaed_2024</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'V2 (L)' (captured trailing unit 'L' for child rows)</li><li>dropped value-less row: 'HILL'</li><li>dropped value-less row: 'TM 50(elderly) on V3 (years)' (captured trailing unit 'years' for child rows)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxorubicin</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Bérczi_1993's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Mohmaed2024_reference;
