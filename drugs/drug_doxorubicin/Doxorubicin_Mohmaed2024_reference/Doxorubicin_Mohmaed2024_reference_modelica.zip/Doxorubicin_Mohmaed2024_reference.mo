model Doxorubicin_Mohmaed2024_reference
  parameter Real Cl_ref = 1.3416666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0131 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 1e-05,
    k12 = 0.00023960983884648007,
    k21 = 0.00013244256915142993
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>patients with cancer (all age groups)</td></tr><tr><td>source_paper:</td><td>Mohmaed_2024</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'HILL' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Mohmaed_2024_table_p7_1:row6:col1'])</li><li>dropped unlinked row (NIL): 'TM50(infants) on V1 and V2 (weeks)' — extend the ontology if this is a real PK parameter (source ['Mohmaed_2024_table_p7_1:row7:col1'])</li><li>unit_dimension_mismatch: 'TM50(elderly) on V3 (years)' → Q77 (unit '[time]' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q77 ('TM50(elderly) on V3 (years)', value '57.3') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxorubicin</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Mohmaed2024_reference;
