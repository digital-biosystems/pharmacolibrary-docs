model Doxorubicin_Kunarajah2017_reference
  parameter Real Cl_ref = 1.6305555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032200000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>patients</td></tr><tr><td>source_paper:</td><td>Kunarajah_2017</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('CL'=58.7) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V1'=32.2) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q2'=35.8) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2'=3810) from results prose — parameter table was unreadable</li><li>implicit units: 'CL' → L/h (from the popPK convention: 'CL is a clearance parameter. The text defines K10 as CL/V1, and V1 is a volume (L). While K10 is a rate constant (1/h) b')</li><li>implicit units: 'V1' → L (from the popPK convention: 'V1 is the volume of distribution of the central compartment. Volumes are standardly reported in Liters (L), and the valu')</li><li>implicit units: 'Q2' → L/h (from the popPK convention: 'Q2 is an intercompartmental clearance. The text defines it as Q2, and in the PK equations it is used to derive rate cons')</li><li>implicit units: 'V2' → L (from the popPK convention: 'V2 is the volume of distribution of the peripheral compartment. Volumes are standardly reported in Liters (L). Although ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxorubicin</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>molar mass: none found for 'doxorubicinol' — its concentrations stay mass-only</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Kunarajah2017_reference;
