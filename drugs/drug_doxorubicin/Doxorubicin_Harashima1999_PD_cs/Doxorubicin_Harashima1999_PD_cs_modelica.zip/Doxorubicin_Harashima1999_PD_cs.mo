model Doxorubicin_Harashima1999_PD_cs
  "linear exposure-response sweep — Harashima_1999 :: Cs (number of tumor cells)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 58320   "[meter ** 3 * second / kilogram; h/(mg/ml) × 3600]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Doxorubicin_Harashima1999_PD_cs</h4><p>The steady-state exposure-response curve of Harashima H et al., <i>Advanced drug delivery reviews 40(1-2):39–61</i> 1999 (<a href=\"https://doi.org/10.1016/s0169-409x(99)00039-3\">doi:10.1016/s0169-409x(99)00039-3</a>) — number of tumor cells against free doxorubicin mg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       16.2 h/(mg/ml) change in response per unit of exposure (k, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/ml of free doxorubicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Doxorubicin_Harashima1999_PD_cs;
