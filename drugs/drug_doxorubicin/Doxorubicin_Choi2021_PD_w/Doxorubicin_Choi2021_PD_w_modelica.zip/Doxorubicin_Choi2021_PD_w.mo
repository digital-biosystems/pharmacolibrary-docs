model Doxorubicin_Choi2021_PD_w
  "linear exposure-response sweep — Choi_2021 :: w (tumor volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0386,      // [cm 3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 13.8   "[l/mg per day]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Doxorubicin_Choi2021_PD_w</h4><p>The steady-state exposure-response curve of Choi YH et al., <i>The Journal of pharmacology and experimental therapeutics 377(3):305–315</i> 2021 (<a href=\"https://doi.org/10.1124/jpet.121.000584\">doi:10.1124/jpet.121.000584</a>) — tumor volume [cm 3] against doxorubicin mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     0.0386 cm 3     drug-free response (baseline) (w 0, Q336)
  slope =       13.8 l/mg per day change in response per unit of exposure (k 2, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/l of doxorubicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0386   (drug-free)</pre></body></html>"));
end Doxorubicin_Choi2021_PD_w;
