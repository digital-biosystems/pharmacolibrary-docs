model Doxorubicin_Choi2021_PD_w
  "linear exposure-response sweep — Choi_2021 :: w (tumor volume)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.159722222222,  // [meter ** 3 / kilogram / second; l/mg per day × 0.0115741]
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Doxorubicin_Choi2021_PD_w</h4><p>The steady-state exposure-response curve of Choi YH et al., <i>The Journal of pharmacology and experimental therapeutics 377(3):305–315</i> 2021 (<a href=\"https://doi.org/10.1124/jpet.121.000584\">doi:10.1124/jpet.121.000584</a>) — tumor volume [cm 3] against Dox mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       13.8 l/mg per day change in response per unit of exposure (k 2, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/L of Dox per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Doxorubicin_Choi2021_PD_w;
