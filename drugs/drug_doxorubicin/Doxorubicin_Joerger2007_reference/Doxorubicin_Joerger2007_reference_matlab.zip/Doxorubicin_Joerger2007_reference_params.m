function p = Doxorubicin_Joerger2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxorubicin   source: Joerger_2007 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Doxorubicin_Joerger2007_reference_params';
  p.drug  = 'doxorubicin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.3;                % central volume [L]
  p.CL = 47.6;                % clearance [L/h]
  p.Vp = [421.0];             % peripheral volumes [L]
  p.Q  = [60.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
