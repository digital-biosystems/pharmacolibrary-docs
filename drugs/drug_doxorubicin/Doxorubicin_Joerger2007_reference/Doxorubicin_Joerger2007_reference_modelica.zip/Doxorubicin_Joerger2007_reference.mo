model Doxorubicin_Joerger2007_reference
  parameter Real Cl_ref = 1.3222222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>breast cancer patients</td></tr><tr><td>source_paper:</td><td>Joerger_2007</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table VI</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank); doxorubicinol 545.541 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>compound tags: 1 row(s) → doxorubicinol (name 1)</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V1 (%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Q (%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V2 (%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CLDOL/fm (%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V3 (%)' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'doxorubicin (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'doxorubicinol (%)' routed out of structural estimates ('Residual variability')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Interindividual variability')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=doxorubicin</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>row roles: 8 row(s) kept on the molecule their table section names, against the LLM's assignment</li><li>row roles (LLM): model_class=compartmental; 15/15 row label(s) assigned, 8 linked by role; re-tagged parent→doxorubicinol ×3, parent→cyclophosphamide ×3</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Joerger2007_reference;
