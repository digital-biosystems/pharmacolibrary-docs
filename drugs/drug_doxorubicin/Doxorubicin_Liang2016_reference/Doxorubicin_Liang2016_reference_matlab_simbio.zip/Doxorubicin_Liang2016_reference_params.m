function p = Doxorubicin_Liang2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxorubicin   source: Liang_2016 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Doxorubicin_Liang2016_reference_params';
  p.drug  = 'doxorubicin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 16.9;                % central volume [L]
  p.CL = 54.2;                % clearance [L/h]
  p.Vp = [1650.0];             % peripheral volumes [L]
  p.Q  = [66.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
