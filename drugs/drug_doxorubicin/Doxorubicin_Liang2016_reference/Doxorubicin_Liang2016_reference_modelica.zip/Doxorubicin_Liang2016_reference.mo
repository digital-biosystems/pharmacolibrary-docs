model Doxorubicin_Liang2016_reference
  parameter Real Cl_ref = 1.5055555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0169 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>adult women with breast cancer</td></tr><tr><td>source_paper:</td><td>Liang_2016</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank); doxorubicinol 545.541 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV-CL dox (% CV)' routed out of structural estimates ('BSV')</li><li>table section iiv: 'BSV-V C-dox (% CV)' routed out of structural estimates ('BSV')</li><li>table section iiv: 'BSV-Q 2-dox (% CV)' routed out of structural estimates ('BSV')</li><li>table section iiv: 'BSV-V 2-dox (% CV)' routed out of structural estimates ('BSV')</li><li>table section iov: 'IOV-CL C-dox (% CV)' routed out of structural estimates ('IOV')</li><li>table section residual_error: 'RUV-proportional-dox (% CV)' routed out of structural estimates ('RUV')</li><li>table section residual_error: 'RUV-additive-dox (SD)' routed out of structural estimates ('RUV')</li><li>table section residual_error: &quot;CL doxo'ol /fm (l h&quot; routed out of structural estimates ('RUV')</li><li>table section residual_error: &quot;V C-doxo'ol /fm (l)&quot; routed out of structural estimates ('RUV')</li><li>table section iiv: &quot;BSV-CL doxo'ol /fm (% CV)&quot; routed out of structural estimates ('BSV')</li><li>table section iiv: &quot;BSV-V doxo'ol /fm (% CV)&quot; routed out of structural estimates ('BSV')</li><li>table section iov: &quot;IOV-CL doxo'ol /fm (% CV)&quot; routed out of structural estimates ('IOV')</li><li>table section iov: &quot;IOV-V doxo'ol /fm (% CV)&quot; routed out of structural estimates ('IOV')</li><li>table section residual_error: &quot;RUV-proportional-doxo'ol (% CV)&quot; routed out of structural estimates ('RUV')</li><li>unit_dimension_unknown: 'l h' (CL)</li><li>unit_dimension_unknown: 'l h' (Q)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Liang2016_reference;
