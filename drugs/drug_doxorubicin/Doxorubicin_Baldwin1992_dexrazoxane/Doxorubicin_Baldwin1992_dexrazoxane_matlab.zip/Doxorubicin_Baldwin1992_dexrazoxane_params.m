function p = Doxorubicin_Baldwin1992_dexrazoxane_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxorubicin   source: Baldwin_1992 / dexrazoxane   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doxorubicin_Baldwin1992_dexrazoxane_params';
  p.drug  = 'doxorubicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3304.0;                % central volume [L]
  p.CL = 75.18;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 105.0;             % dose [mg]
end
