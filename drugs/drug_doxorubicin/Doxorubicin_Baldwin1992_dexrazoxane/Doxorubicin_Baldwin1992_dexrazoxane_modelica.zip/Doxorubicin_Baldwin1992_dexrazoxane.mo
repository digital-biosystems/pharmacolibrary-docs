model Doxorubicin_Baldwin1992_dexrazoxane
  parameter Real Cl_ref = 2.0883333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.3040000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 0.000105
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Baldwin_1992</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml min-1 kg-1' (CL)</li><li>unit_dimension_unknown: 'ml min-1 kg-1' (CLR)</li><li>implicit units: 'CLs (ml min-1 kg-1)' → ml/min/kg (from the paper text: &quot;The parameter description provided in the input for item 1 explicitly states the unit: 'CLs (ml min-1 kg-1)'. The paper &quot;)</li><li>implicit units: 'CLr (ml min-1 kg-1)' → ml/min/kg (from the paper text: &quot;The parameter description provided in the input for item 2 explicitly states the unit: 'CLr (ml min-1 kg-1)'. The paper &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxorubicin</li><li>population split: 'dexrazoxane*' subgroup of Baldwin_1992 (paper reports 2 populations: dexrazoxane*, saline)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Baldwin1992_dexrazoxane;
