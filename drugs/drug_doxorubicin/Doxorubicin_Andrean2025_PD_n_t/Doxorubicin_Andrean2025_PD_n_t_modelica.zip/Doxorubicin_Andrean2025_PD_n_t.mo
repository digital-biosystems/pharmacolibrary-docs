model Doxorubicin_Andrean2025_PD_n_t
  "emax exposure-response sweep — Andrean_2025 :: N(t) (number of living cells)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 10370,      // [1; dimensionless × 1]
    Emax = 1.20833333333e-05,  // [1/s; 1/h × 0.000277778]
    EC50 = 47.5,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // off_target_driver: driver compound 'DNA-bound DOXO' is not 'doxorubicin' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 480, Interval = 0.96),
    Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Doxorubicin_Andrean2025_PD_n_t</h4><p>The steady-state exposure-response curve of Andrean D et al., <i>Biology direct 20(1):33</i> 2025 (<a href=\"https://doi.org/10.1186/s13062-025-00626-x\">doi:10.1186/s13062-025-00626-x</a>) — number of living cells against DNA-bound DOXO nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      10370 dimensionless drug-free response (baseline) (N 0 (ctrl), Q324)
  Emax  =     0.0435 1/h      maximal effect term (K dmax, Q320)
  EC50  =       47.5 nM       exposure at half of the maximal effect term (X BHS, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of DNA-bound DOXO per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.037e+04   (drug-free)
  exposure = EC50 (47.5 nM)  response 1.037e+04
  exposure -> infinity  response 1.037e+04</pre></body></html>"));
end Doxorubicin_Andrean2025_PD_n_t;
