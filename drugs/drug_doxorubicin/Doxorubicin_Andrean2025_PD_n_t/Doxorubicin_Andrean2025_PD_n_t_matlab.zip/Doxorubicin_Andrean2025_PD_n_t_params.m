function p = Doxorubicin_Andrean2025_PD_n_t_params()
% Doxorubicin_Andrean2025_PD_n_t_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Andrean_2025::N_t: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response N(t) in its own unit. Driver: DNA-bound DOXO (conc_no_pk).
p.E0 = 10370.0;
p.Emax = 1.2083333333333332e-05;
p.EC50 = 47.5;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 480.0;
p.form = 'E0 + Emax*frac';
end
