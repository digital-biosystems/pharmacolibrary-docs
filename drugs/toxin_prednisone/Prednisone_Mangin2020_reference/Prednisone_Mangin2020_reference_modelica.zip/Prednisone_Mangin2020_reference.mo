model Prednisone_Mangin2020_reference
  parameter Real Cl_ref = 7.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0943 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.36045,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>patients with inflammatory/immunologic conditions</td></tr><tr><td>source_paper:</td><td>Mangin_2020</td></tr><tr><td>measured_compound:</td><td>Prednisolone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Prednisolone 360.45 g/mol (pubchem); Prednisone 358.434 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is prednisone; the compartment is Prednisolone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Prednisolone, not prednisone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>prednisone's own concentration-time course is not produced by this model</li><li>metabolite prednisolone: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Prednisolone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V<sub>U</sub> /F' is the general volume)</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 2 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Prednisolone', not prednisone — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisone_Mangin2020_reference;
