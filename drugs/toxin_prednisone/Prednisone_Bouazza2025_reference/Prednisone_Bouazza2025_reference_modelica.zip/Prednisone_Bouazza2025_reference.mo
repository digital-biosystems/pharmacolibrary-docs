model Prednisone_Bouazza2025_reference
  parameter Real Cl_ref = 1.5083333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23500000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.36045,
    adminMass = 1e-05,
    ka = 0.00033055555555555556,
    Tlag = 612.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>patients with systemic lupus erythematosus (adults and children)</td></tr><tr><td>source_paper:</td><td>Bouazza_2025</td></tr><tr><td>measured_compound:</td><td>Prednisolone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70103-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Prednisolone 360.45 g/mol (pubchem); Prednisone 358.434 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is prednisone; the compartment is Prednisolone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Prednisolone, not prednisone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>prednisone's own concentration-time course is not produced by this model</li><li>'βFdose' is a β covariate effect on F, not Q40 (llm_confirmed link set aside)</li><li>covariate level 'βFdose' → Q900:theta_fab_dose = -0.28 (linear_fractional on Q40)</li><li>dropped PD-category row 'K1 (L/nmol)' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp70103-tbl-0002:row8:col2'])</li><li>dropped unlinked row (NIL): 'Kns' — extend the ontology if this is a real PK parameter (source ['bcp70103-tbl-0002:row9:col2'])</li><li>dropped value-less row: '% rse'</li><li>dropped value-less row: 'ω'</li><li>dropped value-less row: 'Dose'</li><li>dropped value-less row: 'CLU'</li><li>dropped value-less row: 'VU'</li><li>metabolite prednisolone: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Prednisolone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisone_Bouazza2025_reference;
