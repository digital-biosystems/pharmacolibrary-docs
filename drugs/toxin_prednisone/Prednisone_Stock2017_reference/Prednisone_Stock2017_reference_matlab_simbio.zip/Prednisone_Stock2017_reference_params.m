function p = Prednisone_Stock2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: prednisone   source: Stock_2017 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Prednisone_Stock2017_reference_params';
  p.drug  = 'prednisone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 239.343107;                % central volume [L]
  p.CL = 4.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
