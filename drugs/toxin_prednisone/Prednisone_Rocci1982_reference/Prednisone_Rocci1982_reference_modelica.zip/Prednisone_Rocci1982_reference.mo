model Prednisone_Rocci1982_reference
  parameter Real Cl_ref = 1.3833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.238 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>children with nephrotic syndrome</td></tr><tr><td>source_paper:</td><td>Rocci_1982</td></tr><tr><td>measured_compound:</td><td>Prednisolone, Prednisone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Prednisolone 360.45 g/mol (pubchem); Prednisone 358.434 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Prednisolone, Prednisone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 0 linked by role</li><li>molar mass: none of 1 PubChem candidate(s) is 'Prednisolone, Prednisone' (LLM) — left in mass units</li><li>molar mass: none found for 'Prednisolone, Prednisone' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Bianconi_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V from Schijvens_2019: its label names a different analyte ('prednisolone') — 'volume of distribution of prednisolone'</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Bianconi_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Prednisone_Rocci1982_reference;
