model Linerixibat_Carreo2025_PD_c4
  "indirect_response_iii exposure-response sweep — Carreño_2025 :: C4 (C4)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.19e-05,      // [kg/m3; ng/mL × 1e-06]
    Emax = 5.55,  // type III effect term
    EC50 = 8.41666666667e-10,  // [kg/s; mg/h × 2.77778e-10]
    gamma = 1,
    exposure_per_s = 2.77777777778e-10);   // 1 mg/h per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 31, Interval = 0.062),
    Documentation(info = "<html><body><!-- drug-about --><h4>About linerixibat</h4><p>Linerixibat is an investigational bile acid inhibitor being studied for cholestatic itching associated with liver disease. It is not yet approved and remains under clinical investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27256749\">Wikidata Q27256749</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Linerixibat_Carreo2025_PD_c4</h4><p>The steady-state exposure-response curve of Carreño F et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(3):596–605</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.13300\">doi:10.1002/psp4.13300</a>) — C4 [ng/mL] against linerixibat mg/h — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       11.9 ng/mL    drug-free response (baseline) (Baseline, Q324)
  Emax  =       5.55          maximal effect term (E max, Q320)
  EC50  =       3.03 mg/h     exposure at half of the maximal effect term (EDK50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/h of linerixibat per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.19e-05   (drug-free)
  exposure = EC50 (3.03 mg/h)  response 4.492e-05
  exposure -> infinity  response 7.794e-05</pre></body></html>"));
end Linerixibat_Carreo2025_PD_c4;
