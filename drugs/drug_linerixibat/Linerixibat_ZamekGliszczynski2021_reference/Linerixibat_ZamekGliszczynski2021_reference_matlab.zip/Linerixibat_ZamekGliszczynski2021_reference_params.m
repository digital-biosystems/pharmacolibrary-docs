function p = Linerixibat_ZamekGliszczynski2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linerixibat   source: Zamek-Gliszczynski_2021 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Linerixibat_ZamekGliszczynski2021_reference_params';
  p.drug  = 'linerixibat';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 16.3;                % central volume [L]
  p.CL = 61.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.05;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
