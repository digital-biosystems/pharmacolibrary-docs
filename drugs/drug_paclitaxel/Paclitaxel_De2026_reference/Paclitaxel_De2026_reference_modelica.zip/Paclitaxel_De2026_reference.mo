model Paclitaxel_De2026_reference
  parameter Real Cl_ref = 2.425e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.299 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8539061,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paclitaxel</h4><p>Paclitaxel is a taxane chemotherapy drug used to treat several cancers, including breast, ovarian, lung, and pancreatic cancer, melanoma, and Kaposi's sarcoma. It is widely used worldwide, is included on the WHO essential medicines list, and several paclitaxel products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423762\">Wikidata Q423762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paclitaxel</td></tr><tr><td>population:</td><td>patients with peritoneal metastasis</td></tr><tr><td>source_paper:</td><td>De_2026</td></tr><tr><td>measured_compound:</td><td>paclitaxel</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>paclitaxel 853.906 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'estimated absorption duration' — extend the ontology if this is a real PK parameter (source ['De_2026:abstract'])</li><li>routed 'variability between subjects' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'variability between occasions' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>dropped value-less row: 'Body surface area'</li><li>dropped value-less row: 'Rate constants of metabolite formation and elimination'</li><li>dropped diagnostic row 'variability' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped unlinked row (NIL): 'risk' — extend the ontology if this is a real PK parameter (source ['De_2026:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=paclitaxel</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Paclitaxel_De2026_reference;
