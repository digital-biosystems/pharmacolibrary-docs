function p = Paclitaxel_Sun2025_PD_cipn8_params()
% Paclitaxel_Sun2025_PD_cipn8_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% paclitaxel Sun_2025::CIPN8: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response CIPN8 in its own unit. Driver: paclitaxel (cited_pk).
p.E0 = 0.3;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 21.65;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
