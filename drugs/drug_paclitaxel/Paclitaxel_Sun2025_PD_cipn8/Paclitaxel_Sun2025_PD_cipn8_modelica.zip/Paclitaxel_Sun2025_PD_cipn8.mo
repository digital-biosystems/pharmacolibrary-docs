model Paclitaxel_Sun2025_PD_cipn8
  "linear exposure-response sweep — Sun_2025 :: CIPN8 (CIPN8)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.3,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 21.65   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About paclitaxel</h4><p>Paclitaxel is a taxane chemotherapy drug used to treat several cancers, including breast, ovarian, lung, and pancreatic cancer, melanoma, and Kaposi's sarcoma. It is widely used worldwide, is included on the WHO essential medicines list, and several paclitaxel products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423762\">Wikidata Q423762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Paclitaxel_Sun2025_PD_cipn8</h4><p>The steady-state exposure-response curve of Sun Y et al., <i>Clinical and translational science 18(11):e70404</i> 2025 (<a href=\"https://doi.org/10.1111/cts.70404\">doi:10.1111/cts.70404</a>) — CIPN8 against paclitaxel ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        0.3          drug-free response (baseline) (R0_pop, Q324)
  slope =      21.65          change in response per unit of exposure (k_pop, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of paclitaxel per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.3   (drug-free)</pre></body></html>"));
end Paclitaxel_Sun2025_PD_cipn8;
