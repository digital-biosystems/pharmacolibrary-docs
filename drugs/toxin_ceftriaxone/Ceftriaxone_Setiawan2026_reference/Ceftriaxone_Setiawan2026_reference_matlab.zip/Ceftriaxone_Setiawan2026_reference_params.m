function p = Ceftriaxone_Setiawan2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ceftriaxone   source: Setiawan_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ceftriaxone_Setiawan2026_reference_params';
  p.drug  = 'ceftriaxone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.64;                % central volume [L]
  p.CL = 4.99;                % clearance [L/h]
  p.Vp = [26.75];             % peripheral volumes [L]
  p.Q  = [16.33];             % inter-compartmental clearances [L/h]
  p.ka = 0.764;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
