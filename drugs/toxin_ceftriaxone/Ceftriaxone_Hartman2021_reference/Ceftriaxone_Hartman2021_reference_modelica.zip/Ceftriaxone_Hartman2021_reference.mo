model Ceftriaxone_Hartman2021_reference
  parameter Real Cl_ref = 1.9666666666666665e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0028 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.554571,
    adminMass = 0.0001,
    ka = 0.00021222222222222223,
    Tlag = 0.0,
    k12 = 0.0001755952380952381,
    k21 = 0.0001695402298850575
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>critically ill children aged 0-18 years</td></tr><tr><td>source_paper:</td><td>Hartman_2021</td></tr><tr><td>measured_compound:</td><td>Ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Θ1', value '0.67') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Θ2' — extend the ontology if this is a real PK parameter (source ['Hartman_2021_table_p7_1:row2:col1'])</li><li>dropped unlinked row (NIL): 'Θ3' — extend the ontology if this is a real PK parameter (source ['Hartman_2021_table_p7_1:row4:col1'])</li><li>dropped unlinked row (NIL): 'Block matrix' — extend the ontology if this is a real PK parameter (source ['Hartman_2021_table_p7_1:row10:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ceftriaxone</li><li>gap-filled Q49 (kabs) from Nel_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C1_half_life_beta failed (ratio 6.215))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_Hartman2021_reference;
