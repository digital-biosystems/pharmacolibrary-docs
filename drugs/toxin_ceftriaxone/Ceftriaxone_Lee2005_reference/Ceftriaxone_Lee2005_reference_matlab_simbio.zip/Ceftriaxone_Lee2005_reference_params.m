function p = Ceftriaxone_Lee2005_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ceftriaxone   source: Lee_2005 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Ceftriaxone_Lee2005_reference_params';
  p.drug  = 'ceftriaxone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.93;                % central volume [L]
  p.CL = 6.53;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.764;                % absorption rate [1/h]
  p.F  = 0.7;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
