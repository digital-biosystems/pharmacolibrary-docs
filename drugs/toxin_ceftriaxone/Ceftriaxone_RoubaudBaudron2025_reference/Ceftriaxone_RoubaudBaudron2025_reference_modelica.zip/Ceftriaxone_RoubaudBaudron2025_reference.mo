model Ceftriaxone_RoubaudBaudron2025_reference
  parameter Real Cl_ref = 9.722222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00713 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.554571,
    adminMass = 0.0001,
    ka = 0.00045277777777777775,
    Tlag = 0.0,
    k12 = 0.0003560853981611345,
    k21 = 0.0003062592145824957
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>older patients (≥65 years) treated with ceftriaxone</td></tr><tr><td>source_paper:</td><td>Roubaud-Baudron_2025</td></tr><tr><td>measured_compound:</td><td>Ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ofaf313-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'β Cockcroft'</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (Vc, L); Q64 (Vp, L); Q30 (Q, L/h); Q22 (CL, L/h)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ceftriaxone</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q60 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_RoubaudBaudron2025_reference;
