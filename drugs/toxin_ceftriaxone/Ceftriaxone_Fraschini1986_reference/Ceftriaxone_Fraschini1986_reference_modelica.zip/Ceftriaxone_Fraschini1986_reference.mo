// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ceftriaxone_Fraschini1986_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {24840.0},
    MM = 0.554571,
    adminMass = 0.002,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>patients with bronchopneumonia and surgical patients given intramuscular ceftriaxone</td></tr><tr><td>source_paper:</td><td>Fraschini_1986</td></tr><tr><td>measured_compound:</td><td>Ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life of ceftriaxone in sputum', value 5.9) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ceftriaxone</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Boast_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hartman_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Nel_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 280.8));
end Ceftriaxone_Fraschini1986_reference;
