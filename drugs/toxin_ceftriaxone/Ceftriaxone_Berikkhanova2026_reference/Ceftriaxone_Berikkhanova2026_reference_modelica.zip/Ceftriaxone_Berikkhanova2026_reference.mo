// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ceftriaxone_Berikkhanova2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {15984.000000000002},
    MM = 0.554571,
    adminMass = 0.002,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>adult male Wistar rats</td></tr><tr><td>source_paper:</td><td>Berikkhanova_2026</td></tr><tr><td>measured_compound:</td><td>Ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>array1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('T½'=4.44) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ceftriaxone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Boast_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hartman_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Nel_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 194.4));
end Ceftriaxone_Berikkhanova2026_reference;
