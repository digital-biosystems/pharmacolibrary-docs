model Ceftriaxone_Alasmari2023_reference
  parameter Real Cl_ref = 1.3166666666666665e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027930000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.554571,
    adminMass = 0.0001,
    ka = 0.00021222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>adult healthy and chronic kidney disease (mild, moderate, severe) populations</td></tr><tr><td>source_paper:</td><td>Alasmari_2023</td></tr><tr><td>measured_compound:</td><td>ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'pk parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'pk parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q32 ('C_max [μg/mL]', value '1.08') — already have one for this compound</li><li>dropped unlinked row (NIL): 'MFE' — extend the ontology if this is a real PK parameter (source ['Alasmari_2023_table_4:row37:col1', 'Alasmari_2023_table_4:row37:col2', 'Alasmari_2023_table_4:row37:col3', 'Alasmari_2023_table_4:row37:col4'])</li><li>dropped unlinked row (NIL): 'RMSE' — extend the ontology if this is a real PK parameter (source ['Alasmari_2023_table_4:row38:col1', 'Alasmari_2023_table_4:row38:col2', 'Alasmari_2023_table_4:row38:col3', 'Alasmari_2023_table_4:row38:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ceftriaxone</li><li>base model from table(s) without population columns (Alasmari_2023:discussion_prose, Alasmari_2023:other_prose, Alasmari_2023_table_4); populations ckd / mild, ckd / moderate, ckd / severe, healthy, input value, reported value kept as separate records</li><li>gap-filled Q61 (V) from Hartman_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Nel_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Hartman_2021, Nel_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_Alasmari2023_reference;
