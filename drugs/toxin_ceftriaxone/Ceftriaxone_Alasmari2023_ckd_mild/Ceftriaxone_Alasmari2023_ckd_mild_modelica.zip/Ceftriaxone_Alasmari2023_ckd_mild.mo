model Ceftriaxone_Alasmari2023_ckd_mild
  parameter Real Cl_ref = 1.9083333333333331e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027930000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.554571,
    adminMass = 0.0001,
    ka = 0.00021222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>adult healthy and chronic kidney disease (mild, moderate, severe) populations</td></tr><tr><td>source_paper:</td><td>Alasmari_2023</td></tr><tr><td>measured_compound:</td><td>ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Observed' — extend the ontology if this is a real PK parameter (source ['Alasmari_2023_table_6:row2:col3', 'Alasmari_2023_table_6:row5:col3', 'Alasmari_2023_table_6:row8:col3'])</li><li>dropped unlinked row (NIL): 'Fold error' — extend the ontology if this is a real PK parameter (source ['Alasmari_2023_table_6:row3:col3', 'Alasmari_2023_table_6:row6:col3', 'Alasmari_2023_table_6:row9:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ceftriaxone</li><li>population split: 'ckd / mild' subgroup of Alasmari_2023 (paper reports 6 populations: ckd / mild, ckd / moderate, ckd / severe, healthy, input value, reported value)</li><li>gap-filled Q61 (V) from Hartman_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Nel_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Hartman_2021, Nel_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_Alasmari2023_ckd_mild;
