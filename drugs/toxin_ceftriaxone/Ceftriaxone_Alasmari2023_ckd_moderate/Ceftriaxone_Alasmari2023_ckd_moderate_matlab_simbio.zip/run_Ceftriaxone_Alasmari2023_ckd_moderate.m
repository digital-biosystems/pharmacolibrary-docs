% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Ceftriaxone_Alasmari2023_ckd_moderate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
