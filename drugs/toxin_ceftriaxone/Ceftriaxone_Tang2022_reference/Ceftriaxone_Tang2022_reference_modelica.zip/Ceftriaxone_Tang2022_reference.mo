model Ceftriaxone_Tang2022_reference
  parameter Real Cl_ref = 1.813888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0254 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00021222222222222223,
    Tlag = 0.0,
    k12 = 1.7607174103237097e-06,
    k21 = 2.2817460317460314e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>critically ill children admitted to a pediatric intensive care unit (PICU) and young adults</td></tr><tr><td>source_paper:</td><td>Tang_2022</td></tr><tr><td>measured_compound:</td><td>Ceftriaxone (total and free)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.571 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ceftriaxone (total and free)</li><li>molar mass: none found for 'Ceftriaxone (total and free)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Boast_2024's review values (primary lacked it)</li><li>gap-filled Q30 (Q) from Boast_2024's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Nel_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Boast_2024, Nel_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_Tang2022_reference;
