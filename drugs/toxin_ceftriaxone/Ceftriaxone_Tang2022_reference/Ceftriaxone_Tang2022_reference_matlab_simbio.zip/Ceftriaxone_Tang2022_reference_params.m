function p = Ceftriaxone_Tang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ceftriaxone   source: Tang_2022 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ceftriaxone_Tang2022_reference_params';
  p.drug  = 'ceftriaxone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.4;                % central volume [L]
  p.CL = 6.53;                % clearance [L/h]
  p.Vp = [19.6];             % peripheral volumes [L]
  p.Q  = [0.161];             % inter-compartmental clearances [L/h]
  p.ka = 0.764;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
