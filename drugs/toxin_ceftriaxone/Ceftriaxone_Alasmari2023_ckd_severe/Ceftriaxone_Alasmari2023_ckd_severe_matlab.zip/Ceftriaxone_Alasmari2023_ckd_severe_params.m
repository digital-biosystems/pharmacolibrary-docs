function p = Ceftriaxone_Alasmari2023_ckd_severe_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ceftriaxone   source: Alasmari_2023 / ckd_severe   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ceftriaxone_Alasmari2023_ckd_severe_params';
  p.drug  = 'ceftriaxone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.93;                % central volume [L]
  p.CL = 0.4524;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.764;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
