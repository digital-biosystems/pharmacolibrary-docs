function p = Sotatercept_AitOudhia2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sotatercept   source: Ait-Oudhia_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Sotatercept_AitOudhia2024_reference_params';
  p.drug  = 'sotatercept';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.5;                % central volume [L]
  p.CL = 0.259167;                % clearance [L/h]
  p.Vp = [15.8];             % peripheral volumes [L]
  p.Q  = [0.854167];             % inter-compartmental clearances [L/h]
  p.ka = 0.666667;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.7;             % dose [mg]
end
