// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Tioguanine_Jharap2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0182},
    CLelim = {7.037037037037037e-09},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tioguanine</td></tr><tr><td>population:</td><td>IBD patients</td></tr><tr><td>source_paper:</td><td>Jharap_2011</td></tr><tr><td>measured_compound:</td><td>6-thioguanine nucleotides (6-TGN)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>6-thioguanine 167.19 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'pmol·h (8 × 10(8) RBC)(-1)' (AUC/dose)</li><li>unit_dimension_unknown: 'pmol·h (8 × 10(8) RBC)(-1)' (AUC/dose)</li><li>dropped duplicate Q189 ('median AUC per mg 6-TG (i.v.)', value 7184) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=6-thioguanine nucleotides (6-TGN)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/2 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for '6-thioguanine nucleotides (6-TGN)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Wiersma_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Wiersma_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Wiersma_2022 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q189 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Tioguanine_Jharap2011_reference;
