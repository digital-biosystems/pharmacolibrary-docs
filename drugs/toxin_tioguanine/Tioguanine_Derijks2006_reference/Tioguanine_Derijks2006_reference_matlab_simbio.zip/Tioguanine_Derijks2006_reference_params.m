function p = Tioguanine_Derijks2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tioguanine   source: Derijks_2006 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Tioguanine_Derijks2006_reference_params';
  p.drug  = 'tioguanine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 18.2;                % central volume [L]
  p.CL = 0.025333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
