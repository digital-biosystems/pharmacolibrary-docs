model Tioguanine_Derijks2006_reference
  parameter Real Cl_ref = 7.037037037037037e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0182 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tioguanine</td></tr><tr><td>population:</td><td>IBD patients treated with 6-TG</td></tr><tr><td>source_paper:</td><td>Derijks_2006</td></tr><tr><td>measured_compound:</td><td>6-thioguanine nucleotides (6-TGN) in RBCs</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>6-thioguanine 167.19 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'pmol/8 x 10 RBCs' (Css)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=6-thioguanine nucleotides (6-TGN) in RBCs</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/2 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for '6-thioguanine nucleotides (6-TGN)' — its concentrations stay mass-only</li><li>molar mass: none found for '6-thioguanine nucleotides (6-TGN) in RBCs' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Wiersma_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Wiersma_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Wiersma_2022 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q34 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Tioguanine_Derijks2006_reference;
