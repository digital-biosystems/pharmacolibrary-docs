// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Benzobfluoranthene_Liu2026v3_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {36421.200000000004},
    MM = 0.252316,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>benzobfluoranthene</td></tr><tr><td>population:</td><td>bEnd.3 cells</td></tr><tr><td>source_paper:</td><td>Liu_2026_3</td></tr><tr><td>measured_compound:</td><td>Benzo[b]fluoranthene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Benzo[b]fluoranthene 252.316 g/mol (pubchem); benzobfluoranthene 252.316 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q349 ('uptake of BbF', value 17.9) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life of BaP to', value 17.696) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life of BbF from', value 7.418) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life of BbF to', value 14.964) — already have one for this compound</li><li>implicit units: 'uptake of BaP' → 1/h (from the popPK convention: &quot;The parameter is explicitly described as a 'First-order rate constant'. In population pharmacokinetics, first-order rate&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Benzo[b]fluoranthene</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Benzobfluoranthene_Liu2026v3_reference;
