% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Bictegravir_Sun2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
