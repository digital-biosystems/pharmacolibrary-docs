model Bictegravir_Sun2026_reference
  parameter Real Cl_ref = 1.6944444444444446e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.449386,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bictegravir</h4><p>It is given by mouth as a tablet and is well absorbed. It is widely used as a first-line treatment and is authorised in regions including the European Union, United States, and United Kingdom.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q27270406\">Wikidata Q27270406</a>, <a href=\"https://en.wikipedia.org/wiki/Bictegravir?oldid=1370835882\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bictegravir</td></tr><tr><td>population:</td><td>pregnant and postpartum women</td></tr><tr><td>source_paper:</td><td>Sun_2026</td></tr><tr><td>measured_compound:</td><td>bictegravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>bictegravir 449.386 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F', value 43) — already have one for this compound</li><li>dropped duplicate Q76 ('Vd/F', value 120) — already have one for this compound</li><li>dropped unlinked row (NIL): 'virtual subjects with concentrations below pharmacodynamic target' — extend the ontology if this is a real PK parameter (source ['Sun_2026:abstract'])</li><li>dropped unlinked row (NIL): 'virtual subjects with concentrations below target' — extend the ontology if this is a real PK parameter (source ['Sun_2026:abstract'])</li><li>implicit units: 'apparent clearance (CL/F)' → L/h (from the popPK convention: 'Apparent clearance (CL/F) in population PK for a value of 61 is standardly expressed in L/h.')</li><li>implicit units: 'apparent volume of distribution (Vd/F)' → L (from the popPK convention: 'Apparent volume of distribution (Vd/F) in population PK for a value of 32 is standardly expressed in L.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bictegravir</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bictegravir_Sun2026_reference;
