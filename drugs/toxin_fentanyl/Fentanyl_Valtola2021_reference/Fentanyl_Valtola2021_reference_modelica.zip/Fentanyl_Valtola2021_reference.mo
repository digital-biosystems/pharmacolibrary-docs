model Fentanyl_Valtola2021_reference
  parameter Real Cl_ref = 8.616666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0312 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.336479,
    adminMass = 1.0000000000000001e-07,
    k12 = 0.0005662393162393163,
    k21 = 0.0008789386401326699
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>patients after cardiac bypass surgery</td></tr><tr><td>source_paper:</td><td>Valtola_2021</td></tr><tr><td>measured_compound:</td><td>Fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fentanyl 336.479 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (L/min/70 kg)' routed out of structural estimates ('%BSV')</li><li>table section iov: 'CL (L/min/70 kg)' routed out of structural estimates ('%BOV')</li><li>table section iiv: 'Q₂ (L/min/70 kg)' routed out of structural estimates ('%BSV')</li><li>table section iiv: 'Q₃ (L/min/70 kg)' routed out of structural estimates ('%BSV')</li><li>table section iiv: 'V₁ (L/70 kg)' routed out of structural estimates ('%BSV')</li><li>table section iov: 'V₁ (L/70 kg)' routed out of structural estimates ('%BOV')</li><li>table section iiv: 'V₂ (L/70 kg)' routed out of structural estimates ('%BSV')</li><li>table section iiv: 'V₃ (L/70 kg)' routed out of structural estimates ('%BSV')</li><li>table section iiv: 'T_{abs1/2} (min)' routed out of structural estimates ('%BSV')</li><li>table section iiv: 'F_{NASAL}' routed out of structural estimates ('%BSV')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fentanyl</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Valtola2021_reference;
