function p = Fentanyl_Valtola2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Valtola_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Fentanyl_Valtola2021_reference_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 31.2;                % central volume [L]
  p.CL = 31.02;                % clearance [L/h]
  p.Vp = [20.1];             % peripheral volumes [L]
  p.Q  = [63.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.1;             % dose [mg]
end
