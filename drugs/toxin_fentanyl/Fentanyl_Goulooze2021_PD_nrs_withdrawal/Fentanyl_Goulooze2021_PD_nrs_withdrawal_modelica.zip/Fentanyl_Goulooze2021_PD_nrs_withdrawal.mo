model Fentanyl_Goulooze2021_PD_nrs_withdrawal
  "linear exposure-response sweep — Goulooze_2021 :: NRS_withdrawal (NRS_withdrawal)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0.564,      // [1]
    slope = 5930000,  // [meter ** 3 / kilogram; ml ng-1 × 1e+06]
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // family_inferred: the record's model family is unknown; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Fentanyl_Goulooze2021_PD_nrs_withdrawal</h4><p>The steady-state exposure-response curve of Goulooze SC et al., <i>The AAPS journal 23(4):71</i> 2021 (<a href=\"https://doi.org/10.1208/s12248-021-00586-w\">doi:10.1208/s12248-021-00586-w</a>) — NRS_withdrawal against fentanyl ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.564          drug-free response (baseline) (Baseline NRS_withdrawal (Typical baseline), Q324)
  slope =       5.93 ml ng-1  change in response per unit of exposure (Slope (fentanyl), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of fentanyl per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.564   (drug-free)</pre></body></html>"));
end Fentanyl_Goulooze2021_PD_nrs_withdrawal;
