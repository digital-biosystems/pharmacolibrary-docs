model Fentanyl_Mahdy2025_reference
  parameter Real Cl_ref = 1.7266666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0024500000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.336479,
    adminMass = 3.5e-08
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>neonates (term and preterm)</td></tr><tr><td>source_paper:</td><td>Mahdy_2025</td></tr><tr><td>measured_compound:</td><td>Fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1; Table 2; Table S1; Table S2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fentanyl 336.479 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'method/ comment/ reference' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'method/ comment/ reference' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'method/ comment/ reference' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Log P o:w' — extend the ontology if this is a real PK parameter (source ['Mahdy_2025_table_S1:row2:col1'])</li><li>dropped unlinked row (NIL): 'pKa' — extend the ontology if this is a real PK parameter (source ['Mahdy_2025_table_S1:row3:col1'])</li><li>dropped unlinked row (NIL): 'B/P ratio' — extend the ontology if this is a real PK parameter (source ['Mahdy_2025_table_S1:row4:col1'])</li><li>dropped duplicate Q65 ('Vdss – Pediatric and Preterm populations (L/kg)', value '12.45') — already have one for this compound</li><li>unit_dimension_unknown: 'Adult population' (Kp)</li><li>unit_dimension_unknown: 'Pediatric and Preterm populations' (Kp)</li><li>dropped duplicate Q410 ('Kp scalar (Pediatric and Preterm populations)', value '1.00') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Enzyme kinetics' — extend the ontology if this is a real PK parameter (source ['Mahdy_2025_table_S1:row15:col1', 'Mahdy_2025_table_S1:row15:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fentanyl</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Bienert_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Mahdy2025_reference;
