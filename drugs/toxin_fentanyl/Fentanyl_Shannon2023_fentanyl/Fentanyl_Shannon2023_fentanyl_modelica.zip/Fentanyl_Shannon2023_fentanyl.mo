model Fentanyl_Shannon2023_fentanyl
  parameter Real Cl_ref = 2.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0024500000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.336479,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Shannon_2023</td></tr><tr><td>measured_compound:</td><td>Fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fentanyl 336.479 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Age (months)' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row0:col2'])</li><li>dropped unlinked row (NIL): 'Weight (kg)' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row1:col2'])</li><li>dropped unlinked row (NIL): 'Male sex' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row2:col2'])</li><li>dropped unlinked row (NIL): 'Self‐reported white race' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row3:col2'])</li><li>dropped unlinked row (NIL): 'Length of ICU stay (days)' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row4:col2'])</li><li>dropped unlinked row (NIL): 'Cardiac bypass time (h)' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row5:col2'])</li><li>dropped unlinked row (NIL): 'STAT score' — extend the ontology if this is a real PK parameter (source ['Shannon_2023_table_1:row6:col2'])</li><li>table mostly unlinked (7/8 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fentanyl</li><li>status held at route_to_review — not promoted</li><li>population split: 'fentanyl (n = 346)' subgroup of Shannon_2023 (paper reports 5 populations: beta coefficient, fentanyl (n = 346), minor allele frequency (maf), number of genes, percentage of gene list)</li><li>gap-filled Q61 (V) from Bienert_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Bienert_2020 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Shannon2023_fentanyl;
