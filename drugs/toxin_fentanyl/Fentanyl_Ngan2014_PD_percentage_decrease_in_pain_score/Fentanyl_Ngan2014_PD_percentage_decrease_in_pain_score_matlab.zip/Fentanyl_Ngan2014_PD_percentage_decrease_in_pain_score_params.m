function p = Fentanyl_Ngan2014_PD_percentage_decrease_in_pain_score_params()
% Fentanyl_Ngan2014_PD_percentage_decrease_in_pain_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fentanyl Ngan_2014::percentage_decrease_in_pain_score: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms per second, in SI inside (kg/m3, s). Response percentage decrease in pain score in %. Driver: fentanyl (dose_only).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 1.382e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 140.0;
p.form = 'E0 + Emax*frac';
end
