% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Fentanyl_Shannon2023_minor_allele_frequency_maf_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
