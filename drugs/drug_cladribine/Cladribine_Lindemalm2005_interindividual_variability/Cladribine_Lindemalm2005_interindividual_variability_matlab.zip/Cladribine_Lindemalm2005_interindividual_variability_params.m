function p = Cladribine_Lindemalm2005_interindividual_variability_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cladribine   source: Lindemalm_2005 / interindividual_variability   route: oral
  % estimated (absent from source): dose
  p.name  = 'Cladribine_Lindemalm2005_interindividual_variability_params';
  p.drug  = 'cladribine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.0;                % central volume [L]
  p.CL = 54.0;                % clearance [L/h]
  p.Vp = [70.0];             % peripheral volumes [L]
  p.Q  = [61.0];             % inter-compartmental clearances [L/h]
  p.ka = 75.0;                % absorption rate [1/h]
  p.F  = 4.1;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
