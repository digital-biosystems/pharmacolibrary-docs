% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Cladribine_Lindemalm2005_interindividual_variability_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
