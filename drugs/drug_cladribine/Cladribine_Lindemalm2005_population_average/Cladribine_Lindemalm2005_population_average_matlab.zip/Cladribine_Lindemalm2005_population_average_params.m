function p = Cladribine_Lindemalm2005_population_average_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cladribine   source: Lindemalm_2005 / population_average   route: oral
  % estimated (absent from source): dose
  p.name  = 'Cladribine_Lindemalm2005_population_average_params';
  p.drug  = 'cladribine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 71.7;                % central volume [L]
  p.CL = 39.3;                % clearance [L/h]
  p.Vp = [475.0];             % peripheral volumes [L]
  p.Q  = [51.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.31;                % absorption rate [1/h]
  p.F  = 0.353;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
