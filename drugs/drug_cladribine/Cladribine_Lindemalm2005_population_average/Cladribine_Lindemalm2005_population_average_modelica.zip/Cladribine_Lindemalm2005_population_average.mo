model Cladribine_Lindemalm2005_population_average
  parameter Real Cl_ref = 1.0916666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0717 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.353,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0003638888888888889,
    Tlag = 0.0,
    k12 = 0.00019796993646366032,
    k21 = 2.9883040935672514e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cladribine</td></tr><tr><td>population:</td><td>patients with indolent B- and T-cell lymphoid malignancies</td></tr><tr><td>source_paper:</td><td>Lindemalm_2005</td></tr><tr><td>measured_compound:</td><td>cladribine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('Subcutaneous Ka (h-1)', value '2.48') — already have one for this compound</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cladribine</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'population average' subgroup of Lindemalm_2005 (paper reports 2 populations: interindividual variability, population average)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cladribine_Lindemalm2005_population_average;
