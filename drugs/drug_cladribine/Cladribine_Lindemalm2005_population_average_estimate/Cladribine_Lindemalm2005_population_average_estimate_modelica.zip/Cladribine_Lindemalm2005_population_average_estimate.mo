model Cladribine_Lindemalm2005_population_average_estimate
  parameter Real Cl_ref = 1.0916666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0717 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.353,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.285687,
    adminMass = 3.4000000000000003e-07,
    ka = 0.0003638888888888889,
    Tlag = 0.0,
    k12 = 0.00019796993646366032,
    k21 = 2.9883040935672514e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cladribine</h4><p>Cladribine is a purine analogue medicine used to treat hairy cell leukemia and multiple sclerosis, and has also been used for other leukemias and lymphomas. It is approved and authorised in the European Union, where it is used for multiple sclerosis and hairy cell leukemia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414030\">Wikidata Q414030</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cladribine</td></tr><tr><td>population:</td><td>patients with indolent B- and T-cell lymphoid malignancies</td></tr><tr><td>source_paper:</td><td>Lindemalm_2005</td></tr><tr><td>measured_compound:</td><td>cladribine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cladribine 285.687 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error2')</li><li>dropped duplicate Q49 ('Subcutaneous Ka (h-1)', value '2.48') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cladribine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: 'population average / estimate' subgroup of Lindemalm_2005 (paper reports 2 populations: interindividual variability / estimate %, population average / estimate)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cladribine_Lindemalm2005_population_average_estimate;
