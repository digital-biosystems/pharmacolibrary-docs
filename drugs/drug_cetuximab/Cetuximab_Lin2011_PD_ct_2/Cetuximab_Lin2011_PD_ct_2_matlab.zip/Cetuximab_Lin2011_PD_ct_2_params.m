function p = Cetuximab_Lin2011_PD_ct_2_params()
% Cetuximab_Lin2011_PD_ct_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cetuximab Lin_2011::Ct::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response Ct in its own unit. Driver: cetuximab (cited_pk).
p.E0 = 0.0;
p.Emax = -0.13;
p.EC50 = 0.003299999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 33.0;
p.form = 'E0 + Emax*frac';
end
