model Cetuximab_Lin2011_PD_ct_2
  "emax exposure-response sweep — Lin_2011 :: Ct (cell counts)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.13,  // [1]
    EC50 = 0.0033,  // [kg/m3; µg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 33, Interval = 0.066),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cetuximab</h4><p>Cetuximab is a monoclonal antibody used to treat several cancers, mainly head and neck cancers and colorectal cancers. It is approved and authorised in the European Union, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420296\">Wikidata Q420296</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cetuximab_Lin2011_PD_ct_2</h4><p>The steady-state exposure-response curve of Lin HY et al., <i>PLoS computational biology 7(2):e1001073</i> 2011 (<a href=\"https://doi.org/10.1371/journal.pcbi.1001073\">doi:10.1371/journal.pcbi.1001073</a>) — cell counts against cetuximab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.13          maximal effect term (ImaxR, Q323)
  EC50  =        3.3 µg/mL    exposure at half of the maximal effect term (IC50R, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of cetuximab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.3 µg/mL)  response -0.065
  exposure -> infinity  response -0.13</pre></body></html>"));
end Cetuximab_Lin2011_PD_ct_2;
