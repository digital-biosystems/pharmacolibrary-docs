model Cetuximab_Grisic2020_tvarcl
  parameter Real Cl_ref = 7.277777777777779e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00367 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 2.1344232515894642e-06,
    k21 = 4.747474747474748e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cetuximab</h4><p>Cetuximab is a monoclonal antibody used to treat several cancers, mainly head and neck cancers and colorectal cancers. It is approved and authorised in the European Union, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420296\">Wikidata Q420296</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cetuximab</td></tr><tr><td>population:</td><td>adults with metastatic colorectal cancer</td></tr><tr><td>source_paper:</td><td>Grisic_2020</td></tr><tr><td>measured_compound:</td><td>cetuximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412558-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'RSE%' (CL)</li><li>unit_dimension_unknown: 'RSE%' (V1)</li><li>unit_dimension_unknown: 'RSE%' (Q)</li><li>unit_dimension_unknown: 'RSE%' (V2)</li><li>dropped PD-category row 'I max, % (RSE%)' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412558-tbl-0002:row7:col2'])</li><li>unit_dimension_unknown: 'RSE%' (equation variable)</li><li>dropped unlinked row (NIL): 'AIC (SAEM‐IMP)' — extend the ontology if this is a real PK parameter (source ['psp412558-tbl-0002:row19:col2'])</li><li>implicit units: 'LCL, L/h (RSE%)' → L/h (from the paper text: 'The text reports “baseline linear CL (0.0647 vs. 0.0174 L/h, respectively),” explicitly giving the unit for linear clear')</li><li>implicit units: 'V 1, L (RSE%)' → L (from the popPK convention: 'V1 is the central-compartment volume; compartment volumes in population PK are conventionally reported in L, consistent ')</li><li>implicit units: 'Q, L/h (RSE%)' → L/h (from the popPK convention: 'Table 2 defines Q as the “intercompartmental exchange rate.” Intercompartmental clearance is conventionally reported in ')</li><li>implicit units: 'V 2, L (RSE%)' → L (from the popPK convention: 'V2 is the peripheral-compartment volume; compartment volumes in population PK are conventionally reported in L, consiste')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cetuximab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'tvarcl' subgroup of Grisic_2020 (paper reports 5 populations: lcl, mmcl, mmcl + lcl, mmcl + tvarcl, tvarcl)</li><li>molar mass: none found for 'cetuximab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1814400, Tolerance = 1e-9, Interval = 1));
end Cetuximab_Grisic2020_tvarcl;
