function p = Cetuximab_Grisic2020_tvarcl_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cetuximab   source: Grisic_2020 / tvarcl   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cetuximab_Grisic2020_tvarcl_params';
  p.drug  = 'cetuximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.67;                % central volume [L]
  p.CL = 0.0262;                % clearance [L/h]
  p.Vp = [1.65];             % peripheral volumes [L]
  p.Q  = [0.0282];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
