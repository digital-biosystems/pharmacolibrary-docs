function p = Lovastatin_Guan2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lovastatin   source: Guan_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Lovastatin_Guan2015_reference_params';
  p.drug  = 'lovastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.711374;                % central volume [L]
  p.CL = 7.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
