function p = D_2378TetrachlorodibenzoPDioxin_Steenland2001_PD_all_cancer_params()
% D_2378TetrachlorodibenzoPDioxin_Steenland2001_PD_all_cancer_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% 2378_tetrachlorodibenzo_p_dioxin Steenland_2001::all_cancer_mortality: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ppt-years per second, in SI inside (kg/m3, s). Response all cancer mortality in rate. Driver: 2,3,7,8-tetrachlorodibenzo-p-dioxin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.097;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
