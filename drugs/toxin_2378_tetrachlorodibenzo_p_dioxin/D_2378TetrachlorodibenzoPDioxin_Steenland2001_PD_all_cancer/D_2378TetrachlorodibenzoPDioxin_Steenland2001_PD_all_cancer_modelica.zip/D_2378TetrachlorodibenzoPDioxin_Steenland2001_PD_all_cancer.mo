model D_2378TetrachlorodibenzoPDioxin_Steenland2001_PD_all_cancer
  "log_linear exposure-response sweep — Steenland_2001 :: all cancer mortality (cancer mortality)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.097   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>D_2378TetrachlorodibenzoPDioxin_Steenland2001_PD_all_cancer</h4><p>The steady-state exposure-response curve of Steenland K et al., <i>American journal of epidemiology 154(5):451–458</i> 2001 (<a href=\"https://doi.org/10.1093/aje/154.5.451\">doi:10.1093/aje/154.5.451</a>) — cancer mortality [rate] against 2,3,7,8-tetrachlorodibenzo-p-dioxin ppt-years — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.097          change in response per unit of exposure (exposure-response coefficient, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one ppt-years of 2,3,7,8-tetrachlorodibenzo-p-dioxin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end D_2378TetrachlorodibenzoPDioxin_Steenland2001_PD_all_cancer;
