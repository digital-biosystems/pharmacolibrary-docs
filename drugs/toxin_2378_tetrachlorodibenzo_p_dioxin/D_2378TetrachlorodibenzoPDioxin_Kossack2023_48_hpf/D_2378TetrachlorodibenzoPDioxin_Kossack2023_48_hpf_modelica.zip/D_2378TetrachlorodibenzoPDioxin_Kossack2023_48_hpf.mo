// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2378TetrachlorodibenzoPDioxin_Kossack2023_48_hpf
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {117756.0},
    MM = 0.32196199999999997,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2378_tetrachlorodibenzo_p_dioxin</td></tr><tr><td>population:</td><td>zebrafish embryos</td></tr><tr><td>source_paper:</td><td>Kossack_2023</td></tr><tr><td>measured_compound:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin 321.962 g/mol (pubchem); 2378_tetrachlorodibenzo_p_dioxin 321.962 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'EXPOSURE / 50 ppt' — extend the ontology if this is a real PK parameter (source ['Kossack_2023_table_1:row3:col1'])</li><li>dropped unlinked row (NIL): 'EXPOSURE / 1 ppb' — extend the ontology if this is a real PK parameter (source ['Kossack_2023_table_1:row3:col3'])</li><li>dropped unlinked row (NIL): 'EXPOSURE / 10 ppb' — extend the ontology if this is a real PK parameter (source ['Kossack_2023_table_1:row3:col5'])</li><li>salvaged Q57 ('half-life of TCDD in the zebrafish embryos following a 1 ppb exposure'=32.71) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,3,7,8-Tetrachlorodibenzo-p-dioxin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: '48 hpf' subgroup of Kossack_2023 (paper reports 3 populations: 24 hpf, 48 hpf, 72 hpf)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end D_2378TetrachlorodibenzoPDioxin_Kossack2023_48_hpf;
