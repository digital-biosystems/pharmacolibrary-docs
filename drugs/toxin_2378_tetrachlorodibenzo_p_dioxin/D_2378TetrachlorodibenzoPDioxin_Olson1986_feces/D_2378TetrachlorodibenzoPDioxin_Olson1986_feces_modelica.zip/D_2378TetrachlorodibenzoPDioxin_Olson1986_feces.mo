// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2378TetrachlorodibenzoPDioxin_Olson1986_feces
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {8156160.000000001},
    MM = 0.32196199999999997,
    adminMass = 3.92e-08,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2378_tetrachlorodibenzo_p_dioxin</td></tr><tr><td>population:</td><td>male Hartley guinea pigs</td></tr><tr><td>source_paper:</td><td>Olson_1986</td></tr><tr><td>measured_compound:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin 321.962 g/mol (pubchem); 2378_tetrachlorodibenzo_p_dioxin 321.962 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Olson_1986_table_3: rows are variants (Urine, Feces, Urine and feces), the parameters are the column headers (Half-life (days)) — read one record per variant</li><li>transposed table Olson_1986_table_4: rows are variants (Urine TCDD metabolites, Feces TCDD metabolites, Feces Unchanged TCDD, Feces Total, Urine and feces), the parameters are the column headers (Half-life (days)) — read one record per variant</li><li>column 'feces' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,3,7,8-Tetrachlorodibenzo-p-dioxin</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>estimate-method split: 'Feces' is one of 7 estimates of Olson_1986's substance matrix (Urine, Feces, Urine and feces, Urine TCDD metabolites, Feces TCDD metabolites, Feces Unchanged TCDD, Feces Total); same population, different estimation method</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end D_2378TetrachlorodibenzoPDioxin_Olson1986_feces;
