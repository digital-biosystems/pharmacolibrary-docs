// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2378TetrachlorodibenzoPDioxin_Koch1995_tcdd_50
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1814400.0},
    MM = 0.32196199999999997,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2378_tetrachlorodibenzo_p_dioxin</td></tr><tr><td>population:</td><td>Wistar rats (Bor: spf, TNO)</td></tr><tr><td>source_paper:</td><td>Koch_1995</td></tr><tr><td>measured_compound:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin 321.962 g/mol (pubchem); 2378_tetrachlorodibenzo_p_dioxin 321.962 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Koch_1995_table_1: rows are variants (TCDD-50, TCDD-120, TCDD-250), the parameters are the column headers (F0 and F1 generation) — read one record per variant</li><li>dropped unlinked row (NIL): 'F0 and F1 generation' — extend the ontology if this is a real PK parameter (source ['Koch_1995_table_1:row0:col2'])</li><li>salvaged Q57 ('elimination half-life'=3) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,3,7,8-Tetrachlorodibenzo-p-dioxin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'TCDD-50' is one of 3 estimates of Koch_1995's substance matrix (TCDD-50, TCDD-120, TCDD-250); same population, different estimation method</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 18144.0));
end D_2378TetrachlorodibenzoPDioxin_Koch1995_tcdd_50;
