model D_2378TetrachlorodibenzoPDioxin_Dong2016_PD_rr_smr
  "linear exposure-response sweep — Dong_2016 :: RR, SMR (cancer risk)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 13.3   "[×10 -6 per ppt-years]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>D_2378TetrachlorodibenzoPDioxin_Dong2016_PD_rr_smr</h4><p>The steady-state exposure-response curve of Dong Z et al., <i>Environment international 88:53–59</i> 2016 (<a href=\"https://doi.org/10.1016/j.envint.2015.12.010\">doi:10.1016/j.envint.2015.12.010</a>) — cancer risk against 2,3,7,8-tetrachlorodibenzo-p-dioxin ppt-years — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       13.3 ×10 -6 per ppt-years change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ppt-years of 2,3,7,8-tetrachlorodibenzo-p-dioxin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end D_2378TetrachlorodibenzoPDioxin_Dong2016_PD_rr_smr;
