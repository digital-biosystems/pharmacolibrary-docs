function p = D_2378TetrachlorodibenzoPDioxin_Dong2016_PD_rr_smr_params()
% D_2378TetrachlorodibenzoPDioxin_Dong2016_PD_rr_smr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% 2378_tetrachlorodibenzo_p_dioxin Dong_2016::RR_SMR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ppt-years per second, in SI inside (kg/m3, s). Response RR, SMR in its own unit. Driver: 2,3,7,8-tetrachlorodibenzo-p-dioxin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 13.3;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
