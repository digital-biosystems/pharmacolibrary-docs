// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2378TetrachlorodibenzoPDioxin_Aylward2013_estimated_intrin
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {205124400.0},
    MM = 0.32196199999999997,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2378_tetrachlorodibenzo_p_dioxin</td></tr><tr><td>population:</td><td>former chlorophenol workers</td></tr><tr><td>source_paper:</td><td>Aylward_2013</td></tr><tr><td>measured_compound:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,3,7,8-Tetrachlorodibenzo-p-dioxin 321.962 g/mol (pubchem); 2378_tetrachlorodibenzo_p_dioxin 321.962 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>substance matrix Aylward_2013_table_4: the caption names the parameter (t1/2z, Q57: 'Table 4. Estimated half-lives of elimination (years) for selected dioxin congeners from se'); row 'TCDD' is this substance; rows of other substances not taken: PeCDD, 14HxCDD, 16HxCDD, 19HxCDD, HpCDD, OCDD, TEQ</li><li>substance matrix Aylward_2013_table_4: column(s) 'Flesch-Janys et al. 1996 (median)', 'Rohde et al. 1999 (mean)' reprint another study's estimate for comparison — not this paper's, not taken</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,3,7,8-Tetrachlorodibenzo-p-dioxin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>estimate-method split: 'Estimated intrinsic' is one of 3 estimates of Aylward_2013's substance matrix (Apparent, concentration based, Apparent, mass based, Estimated intrinsic); same population, different estimation method</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end D_2378TetrachlorodibenzoPDioxin_Aylward2013_estimated_intrin;
