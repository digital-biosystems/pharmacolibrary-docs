model Hydrazine_Wei2022_reference
  parameter Real Cl_ref = 3.5277777777777775e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.032046,
    adminMass = 0.0001,
    ka = 0.00010833333333333334,
    Tlag = 0.0,
    k12 = 2.968253968253968e-05,
    k21 = 0.00021871345029239768
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydrazine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wei_2022</td></tr><tr><td>measured_compound:</td><td>hydrazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydrazine 32.046 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wei_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydrazine_Wei2022_reference;
