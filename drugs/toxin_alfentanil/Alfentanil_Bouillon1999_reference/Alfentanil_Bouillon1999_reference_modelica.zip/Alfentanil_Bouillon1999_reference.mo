// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Alfentanil_Bouillon1999_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {472.6003503817809},
    MM = 0.416526,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfentanil</td></tr><tr><td>population:</td><td>adult male surgical patients (ASA I-II, preoperative urologic surgery)</td></tr><tr><td>source_paper:</td><td>Bouillon_1999</td></tr><tr><td>measured_compound:</td><td>alfentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>alfentanil 416.526 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Bouillon_1999:abstract'])</li><li>dropped PD-category row 'the gain in the carbon dioxide response' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Bouillon_1999:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alfentanil</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Alfentanil_Bouillon1999_reference;
