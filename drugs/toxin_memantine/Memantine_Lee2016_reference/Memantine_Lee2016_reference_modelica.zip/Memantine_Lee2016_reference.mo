model Memantine_Lee2016_reference
  parameter Real Cl_ref = 3.2000000000000003e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.157 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 41.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.179307,
    adminMass = 2e-05,
    ka = 0.0003666666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>memantine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Lee_2016</td></tr><tr><td>measured_compound:</td><td>Memantine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>memantine 179.307 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'oral dose' — extend the ontology if this is a real PK parameter (source ['Lee_2016:abstract'])</li><li>dropped unlinked row (NIL): 'IV dose' — extend the ontology if this is a real PK parameter (source ['Lee_2016:abstract'])</li><li>dropped unlinked row (NIL): 'patch dose' — extend the ontology if this is a real PK parameter (source ['Lee_2016:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Memantine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Saleh_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Saleh_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Saleh_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Saleh_2022 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Memantine_Lee2016_reference;
