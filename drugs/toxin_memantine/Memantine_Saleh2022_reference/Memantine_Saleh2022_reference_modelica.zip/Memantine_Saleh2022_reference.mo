model Memantine_Saleh2022_reference
  parameter Real Cl_ref = 3.2000000000000003e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.39099999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.179307,
    adminMass = 2e-05,
    ka = 0.0003666666666666666,
    Tlag = 0.0,
    k12 = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>memantine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Saleh_2022</td></tr><tr><td>measured_compound:</td><td>memantine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>memantine 179.307 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Saleh_2022) — secondary source</li><li>volume reported by review</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Memantine_Saleh2022_reference;
