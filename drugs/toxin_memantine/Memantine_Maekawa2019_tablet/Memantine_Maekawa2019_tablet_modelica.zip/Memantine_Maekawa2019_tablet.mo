// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Memantine_Maekawa2019_tablet
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {217080.0},
    MM = 0.179307,
    adminMass = 2e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>memantine</td></tr><tr><td>population:</td><td>Healthy Japanese Males</td></tr><tr><td>source_paper:</td><td>Maekawa_2019</td></tr><tr><td>measured_compound:</td><td>Memantine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>memantine 179.307 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Study I (n = 19)'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'AUCall (ng h/mL)'; source reconciliation required</li><li>table representations disagree for 'AUCinf (ng h/mL)'; source reconciliation required</li><li>table representations disagree for 'Tmax (h)a'; source reconciliation required</li><li>table representations disagree for 'T½ (h)'; source reconciliation required</li><li>table representations disagree for 'Study II (n = 22)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Study I (n = 19)' — extend the ontology if this is a real PK parameter (source ['Tab2:row1:col2'])</li><li>dropped unlinked row (NIL): 'Study II (n = 22)' — extend the ontology if this is a real PK parameter (source ['Tab2:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Memantine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'tablet' subgroup of Maekawa_2019 (paper reports 2 populations: dry syrup, tablet)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 2246.4));
end Memantine_Maekawa2019_tablet;
