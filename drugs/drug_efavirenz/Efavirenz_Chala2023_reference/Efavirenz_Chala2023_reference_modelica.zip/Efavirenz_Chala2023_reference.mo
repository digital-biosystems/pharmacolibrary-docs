model Efavirenz_Chala2023_reference
  parameter Real Cl_ref = 1.1944444444444443e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1238 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>efavirenz</td></tr><tr><td>population:</td><td>HIV-1-infected children in Ethiopia</td></tr><tr><td>source_paper:</td><td>Chala_2023</td></tr><tr><td>measured_compound:</td><td>efavirenz</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Model conditional number'</li><li>dropped value-less row: 'ETA shrinkage for CL (%)'</li><li>salvaged Q22 ('CL (L/h)'=4.3) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('Vc (L)'=123.8) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=efavirenz</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Efavirenz_Chala2023_reference;
