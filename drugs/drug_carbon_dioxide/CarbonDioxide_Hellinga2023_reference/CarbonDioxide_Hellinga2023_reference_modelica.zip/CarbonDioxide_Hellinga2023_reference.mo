model CarbonDioxide_Hellinga2023_reference
  parameter Real Cl_ref = 2.111111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.037 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.0440095,
    adminMass = 1e-05,
    k12 = 0.003828828828828829,
    k21 = 0.0003446877534468775
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carbon_dioxide</h4><p>Carbon dioxide is a medical gas used in healthcare, for example to stimulate breathing and as a vasodilator. It is an approved medical gas and is also approved for veterinary use, with some investigational applications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1997\">Wikidata Q1997</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbon_dioxide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Hellinga_2023</td></tr><tr><td>measured_compound:</td><td>carbon_dioxide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carbon_dioxide 44.0095 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Hellinga_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CarbonDioxide_Hellinga2023_reference;
