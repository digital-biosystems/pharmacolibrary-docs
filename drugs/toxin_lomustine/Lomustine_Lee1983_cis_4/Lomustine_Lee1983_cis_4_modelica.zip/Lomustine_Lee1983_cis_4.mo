// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Lomustine_Lee1983_cis_4
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5502.0},
    MM = 0.233696,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lomustine</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Lee_1983</td></tr><tr><td>measured_compound:</td><td>Lomustine (CCNU)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Lomustine (CCNU) 233.696 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'μgm l⁻¹ min' (AUC∞)</li><li>implicit units: 'AUC₀₋∞ (μgm l⁻¹ min)' → μg ml⁻¹ min (from the paper text: &quot;The parameter label in the prompt explicitly states the unit: 'AUC₀₋∞ (μgm l⁻¹ min)'. Additionally, the abstract mention&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lomustine (CCNU)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'cis-4' subgroup of Lee_1983 (paper reports 5 populations: cis-3, cis-4, control*†, trans-3, trans-4)</li><li>row roles (LLM): model_class=noncompartmental; 11/11 row label(s) assigned, 6 linked by role; re-tagged Lomustine (CCNU)→parent ×18, Lomustine (CCNU)→Monohydroxylated metabolites of CCNU ×20</li><li>molar mass: no plausible PubChem entry for 'Monohydroxylated metabolites of CCNU' ('monohydroxylated metabolites of CCNU') — left in mass units</li><li>molar mass: none found for 'Monohydroxylated metabolites of CCNU' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Lomustine_Lee1983_cis_4;
