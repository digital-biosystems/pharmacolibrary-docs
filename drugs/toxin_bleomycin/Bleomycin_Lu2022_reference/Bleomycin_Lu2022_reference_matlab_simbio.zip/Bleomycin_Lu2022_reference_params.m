function p = Bleomycin_Lu2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bleomycin   source: Lu_2022 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Bleomycin_Lu2022_reference_params';
  p.drug  = 'bleomycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 393.4;                % central volume [L]
  p.CL = 174.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
