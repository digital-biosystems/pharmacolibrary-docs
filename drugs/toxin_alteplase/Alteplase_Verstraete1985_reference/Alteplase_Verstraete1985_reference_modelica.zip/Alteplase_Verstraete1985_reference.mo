// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Alteplase_Verstraete1985_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {360.0},
    adminMass = 0.0001,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alteplase</td></tr><tr><td>population:</td><td>20 subjects</td></tr><tr><td>source_paper:</td><td>Verstraete_1985</td></tr><tr><td>measured_compound:</td><td>Alteplase</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'fractional catabolic rate constant' Q100 → Q47: a rate constant in 'per min' (the unit decides, not the label)</li><li>dropped duplicate Q47 ('fractional catabolic rate constant', value 0.02) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Alteplase</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'alteplase' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Yang_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Alteplase_Verstraete1985_reference;
