model Brexpiprazole_Frederiksen2023v3_reference
  parameter Real Cl_ref = 6.222222222222222e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08120000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43357,
    adminMass = 1.5e-07,
    ka = 0.00028333333333333335,
    Tlag = 1479.6,
    k12 = 2.4425287356321835e-06,
    k21 = 4.945968412302576e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brexpiprazole</h4><p>Brexpiprazole is an antipsychotic used to treat schizophrenia, and has also been studied for conditions such as anxiety, psychosis and schizoaffective disorder. It is an approved medicine, authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2924764\">Wikidata Q2924764</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexpiprazole</td></tr><tr><td>population:</td><td>healthy subjects and patients</td></tr><tr><td>source_paper:</td><td>Frederiksen_2023_3</td></tr><tr><td>measured_compound:</td><td>brexpiprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt2791-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>brexpiprazole 433.57 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is brexpiprazole; the compartment is brexpiprazole. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is brexpiprazole, not brexpiprazole</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>brexpiprazole's own concentration-time course is not produced by this model</li><li>table section iiv: 'Absorption rate constant fasted' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Absorption rate constant fed' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, brexpiprazole central compartment (V2)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, brexpiprazole peripheral compartment (V3)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from brexpiprazole to DM‐3412 (CLM1)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from brexpiprazole to DM‐3411 (CLM2)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, DM‐3412 central compartment (V4)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from DM‐3412 central compartment (CLMET1)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, DM‐3411 central compartment (V6)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from DM‐3411 central compartment (CLMET2)' routed out of structural estimates ('IIV (%RSE)')</li><li>dropped duplicate Q49 ('Absorption rate constant fed', value '0.535') — already have one for this compound</li><li>unit_dimension_unknown: 'V2' (V1)</li><li>unit_dimension_unknown: 'V3' (V2)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Brexpiprazole_Frederiksen2023v3_reference;
