function out = simulate_network(p, tspan)
% Simulate a parent-metabolite network model (see *_params.m with p.kind = 'network').
%   tspan in hours. Returns out.t, out.C (one column per reported compartment [mg/L]),
%   out.names, out.Cmax, out.Tmax (per column).
  off = double(p.depot);
  A = zeros(off + numel(p.V), 1);
  % integrate piecewise between the dose pulse's edges, so no solver can step across it
  t1 = p.dose_start; t2 = p.dose_start + p.dose_duration;
  edges = unique([tspan(1), min(max([t1, t2], tspan(1)), tspan(end)), tspan(end)]);
  opts = odeset('RelTol', 1e-8, 'AbsTol', 1e-12);
  t = []; Y = [];
  for s = 1:numel(edges) - 1
    a = edges(s); b = edges(s + 1);
    ts = unique([a, tspan(tspan > a & tspan < b), b]);
    dosing = (a >= t1) && (b <= t2);
    odef = @(tt, AA) network_rhs(tt, AA, p, dosing);
    if numel(ts) == 2, ts = linspace(a, b, 3); end
    try
      [tt, AA] = ode15s(odef, ts, A(:, end), opts);
    catch
      [tt, AA] = ode45(odef, ts, A(:, end), opts);
    end
    if numel(ts) == 3 && ~any(tspan == ts(2)), tt = tt([1 end]); AA = AA([1 end], :); end
    keep = ismember(tt, tspan);
    if s > 1, keep(1) = false; end
    t = [t; tt(keep)]; Y = [Y; AA(keep, :)];
    A = AA(end, :).';
  end
  C = Y(:, off + p.out_idx) ./ p.V(p.out_idx);
  out.t = t; out.C = C; out.names = p.out_names;
  [out.Cmax, imax] = max(C, [], 1);
  out.Tmax = t(imax).';
end
