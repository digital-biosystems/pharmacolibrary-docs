function p = Brexpiprazole_Frederiksen2023v3_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brexpiprazole   source: Frederiksen_2023_3 / reference   route: oral
  p.name  = 'Brexpiprazole_Frederiksen2023v3_reference_params';
  p.drug  = 'brexpiprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 81.2;                % central volume [L]
  p.CL = 1.12;                % clearance [L/h]
  p.Vp = [40.1];             % peripheral volumes [L]
  p.Q  = [0.714];             % inter-compartmental clearances [L/h]
  p.ka = 1.02;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.411;             % absorption lag [h]
  p.dose = 0.15;             % dose [mg]
end
