function p = Brexpiprazole_Frederiksen2023v3_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: brexpiprazole   source: Frederiksen_2023_3 / reference   PK_3M_9C parent + 2 metabolite(s), 5 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=433.57 g/mol C_M1=449.569 g/mol C_M2=467.584 g/mol
  p.name  = 'Brexpiprazole_Frederiksen2023v3_reference_params';
  p.drug  = 'brexpiprazole';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'central_M1', 'central_M2', 'peripheral_M2'};
  p.V = [81.2, 40.1, 2.44, 0.447, 20.4];          % compartment volumes [L]
  p.K = [-0.022862068965517242, 0.017805486284289275, 0.0, 0.0, 0.0;
         0.008793103448275861, -0.017805486284289275, 0.0, 0.0, 0.0;
         0.014302077459551931, 0.0, -1.3647540983606559, 0.0, 0.0;
         0.000297503724093393, 0.0, 0.0, -5.771812080536912, 0.10588235294117647;
         0.0, 0.0, 0.0, 4.83221476510067, -0.10588235294117647];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 1.02;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.411;             % absorption lag [h] (in dose_start)
  p.dose = 100.0;             % dose [mg]
  p.dose_start = 0.42766666666666664;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 3.0, 4.0];
  p.out_names = {'C_central', 'C_M1', 'C_M2'};
  p.out_labels = {'brexpiprazole', 'DM-3411', 'DM-3412'};
end
