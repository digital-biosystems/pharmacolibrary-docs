function p = Brexpiprazole_Bruno2022_extensive_metabolizer_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brexpiprazole   source: Bruno_2022 / extensive_metabolizer   route: oral
  % estimated (absent from source): ka
  p.name  = 'Brexpiprazole_Bruno2022_extensive_metabolizer_params';
  p.drug  = 'brexpiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 121.9;                % central volume [L]
  p.CL = 1.4731;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
