function p = Brexpiprazole_Sasabe2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brexpiprazole   source: Sasabe_2021_2 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Brexpiprazole_Sasabe2021v2_reference_params';
  p.drug  = 'brexpiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 863.452982;                % central volume [L]
  p.CL = 199.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
