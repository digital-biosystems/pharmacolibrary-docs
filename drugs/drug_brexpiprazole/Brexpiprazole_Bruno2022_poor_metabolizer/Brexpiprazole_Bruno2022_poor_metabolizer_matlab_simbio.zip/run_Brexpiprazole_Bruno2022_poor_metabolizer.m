% Run (SimBiology): build model + dose, simulate 0..432.0 h, plot.
p = Brexpiprazole_Bruno2022_poor_metabolizer_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 432.0);
