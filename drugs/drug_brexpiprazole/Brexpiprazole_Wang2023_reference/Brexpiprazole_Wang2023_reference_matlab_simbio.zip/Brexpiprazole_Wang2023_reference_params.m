function p = Brexpiprazole_Wang2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brexpiprazole   source: Wang_2023 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Brexpiprazole_Wang2023_reference_params';
  p.drug  = 'brexpiprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 78.0;                % central volume [L]
  p.CL = 1.34;                % clearance [L/h]
  p.Vp = [27.5];             % peripheral volumes [L]
  p.Q  = [0.844];             % inter-compartmental clearances [L/h]
  p.ka = 1.49;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
