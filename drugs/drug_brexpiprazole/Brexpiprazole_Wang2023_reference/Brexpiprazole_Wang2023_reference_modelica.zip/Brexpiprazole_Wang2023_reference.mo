model Brexpiprazole_Wang2023_reference
  parameter Real Cl_ref = 3.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.078 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexpiprazole</td></tr><tr><td>population:</td><td>adults, adolescents, and children with CNS disorders</td></tr><tr><td>source_paper:</td><td>Wang_2023</td></tr><tr><td>measured_compound:</td><td>brexpiprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('V p (L)', value '27.5') — already have one for this compound</li><li>dropped duplicate Q22 ('CL_weight', value '0.75') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V_weight' — extend the ontology if this is a real PK parameter (source ['tab_1:row12:col1', 'tab_1:row12:col2'])</li><li>dropped unlinked row (NIL): 'Error 1' — extend the ontology if this is a real PK parameter (source ['tab_1:row20:col2', 'tab_1:row20:col3', 'tab_1:row20:col4'])</li><li>dropped unlinked row (NIL): 'Error 2' — extend the ontology if this is a real PK parameter (source ['tab_1:row21:col2', 'tab_1:row21:col3', 'tab_1:row21:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=brexpiprazole</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Brexpiprazole_Wang2023_reference;
