model Flurbiprofen_Wang2010_reference
  parameter Real Cl_ref = 3.555555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005030000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24426499999999998,
    adminMass = 1e-05,
    k12 = 0.00046940578749723875,
    k21 = 0.0005378385218931916
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>general anaesthesia patients undergoing dentofacial or otorhinolaryngological surgery</td></tr><tr><td>source_paper:</td><td>Wang_2010</td></tr><tr><td>measured_compound:</td><td>flurbiprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flurbiprofen 244.265 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flurbiprofen</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q83 (tlag) from Srinivas_2013's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flurbiprofen_Wang2010_reference;
