function p = Flurbiprofen_Wang2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flurbiprofen   source: Wang_2010 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Flurbiprofen_Wang2010_reference_params';
  p.drug  = 'flurbiprofen';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.03;                % central volume [L]
  p.CL = 1.28;                % clearance [L/h]
  p.Vp = [4.39];             % peripheral volumes [L]
  p.Q  = [8.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
