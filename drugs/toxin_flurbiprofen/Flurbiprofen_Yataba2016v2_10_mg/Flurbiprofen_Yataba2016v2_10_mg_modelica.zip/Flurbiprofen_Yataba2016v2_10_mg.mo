// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flurbiprofen_Yataba2016v2_10_mg
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {28080.0},
    MM = 0.24426499999999998,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Yataba_2016_2</td></tr><tr><td>measured_compound:</td><td>S-flurbiprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>S-flurbiprofen 244.265 g/mol (pubchem); flurbiprofen 244.265 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'topical application of the SFPP (24 h)' (captured trailing unit '24 h' for child rows)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=S-flurbiprofen</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: '10 mg (n = 7)' subgroup of Yataba_2016_2 (paper reports 6 populations: 10 mg (n = 7), 2 mg (n = 7), 20 mg (n = 6), 40 mg (n = 7), 5 mg (n = 7), 60 mg (n = 7))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 280.8));
end Flurbiprofen_Yataba2016v2_10_mg;
