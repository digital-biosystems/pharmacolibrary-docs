% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Flurbiprofen_Hussain2020_standard_flb_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
