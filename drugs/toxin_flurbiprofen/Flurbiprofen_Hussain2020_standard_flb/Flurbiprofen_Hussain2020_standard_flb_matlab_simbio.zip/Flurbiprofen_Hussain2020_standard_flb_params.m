function p = Flurbiprofen_Hussain2020_standard_flb_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flurbiprofen   source: Hussain_2020 / standard_flb   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Flurbiprofen_Hussain2020_standard_flb_params';
  p.drug  = 'flurbiprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.3;                % central volume [L]
  p.CL = 0.014;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 180.6;             % dose [mg]
end
