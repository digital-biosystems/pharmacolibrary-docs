// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flurbiprofen_Sodano2022_flugal
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {86400.0},
    MM = 0.24426499999999998,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>rat intestinal segments (ex vivo) and mice (in vivo)</td></tr><tr><td>source_paper:</td><td>Sodano_2022</td></tr><tr><td>measured_compound:</td><td>flurbiprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>flurbiprofen 244.265 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'flugal' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'flugal' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'flugal' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q40 ('Fraction Absorbed (Fa) ± SE / Jejunum', value '0.031') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Fraction Absorbed (Fa) ± SE / Ileum' — extend the ontology if this is a real PK parameter (source ['Sodano_2022_table_3:row7:col3'])</li><li>salvaged Q57 ('IbuGAL half-life'=24) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flurbiprofen</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'flugal' subgroup of Sodano_2022 (paper reports 3 populations: flugal, flurbiprofen, flurbiprofen (flugal))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Flurbiprofen_Sodano2022_flugal;
