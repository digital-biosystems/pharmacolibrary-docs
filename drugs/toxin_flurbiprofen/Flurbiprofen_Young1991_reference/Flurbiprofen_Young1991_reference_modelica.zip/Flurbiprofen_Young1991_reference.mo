model Flurbiprofen_Young1991_reference
  parameter Real Cl_ref = 1.2499999999999999e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01247 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4.4e-05,
    ka = 0.0001388888888888889,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>patients with rheumatoid arthritis</td></tr><tr><td>source_paper:</td><td>Young_1991</td></tr><tr><td>measured_compound:</td><td>R(-)-flurbiprofen and S(+)-flurbiprofen enantiomers</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>flurbiprofen 244.265 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('volume of distribution (S(+)-flurbiprofen)', value 12.81) — already have one for this compound</li><li>relinked 'elimination half-life (S(+)-flurbiprofen)' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('elimination half-life (S(+)-flurbiprofen)', value 155) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=R(-)-flurbiprofen and S(+)-flurbiprofen enantiomers</li><li>molar mass: none found for 'R(-)-flurbiprofen and S(+)-flurbiprofen enantiomers' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Srinivas_2013's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flurbiprofen_Young1991_reference;
