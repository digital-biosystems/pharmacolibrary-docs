% Run (SimBiology): build model + dose, simulate 0..39.0 h, plot.
p = Flurbiprofen_Hussain2020_hpc_flb_conjugate_3_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 39.0);
