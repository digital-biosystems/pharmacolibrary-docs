model Flurbiprofen_Hussain2020_hpc_flb_conjugate_3
  parameter Real Cl_ref = 2.777777777777778e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005600000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24426499999999998,
    adminMass = 0.0001806
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>rabbits</td></tr><tr><td>source_paper:</td><td>Hussain_2020</td></tr><tr><td>measured_compound:</td><td>Flurbiprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0010</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flurbiprofen 244.265 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'µgmL−1' (Cmax)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flurbiprofen</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'hpc-flb conjugate 3' subgroup of Hussain_2020 (paper reports 2 populations: hpc-flb conjugate 3, standard flb)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q83 (tlag) from Srinivas_2013's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q32 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Flurbiprofen_Hussain2020_hpc_flb_conjugate_3;
