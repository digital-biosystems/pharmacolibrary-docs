% Run: build params, simulate 0..39.0 h, plot + save Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.m
here = fileparts(mfilename('fullpath'));
p = Flurbiprofen_Hussain2020_hpc_flb_conjugate_3_params();
out = simulate_pk(p, 0:0.05:39.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('flurbiprofen — Hussain_2020 (iv_bolus)');
print(fig, fullfile(here, 'Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.json'), 'w');
try
  s.model = 'Flurbiprofen_Hussain2020_hpc_flb_conjugate_3'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Flurbiprofen_Hussain2020_hpc_flb_conjugate_3","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.png, Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.csv, Flurbiprofen_Hussain2020_hpc_flb_conjugate_3.json\n');
