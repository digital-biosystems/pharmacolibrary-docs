model Flurbiprofen_Duthaler2022_child_a
  parameter Real Cl_ref = 8.694444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6980000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24426499999999998,
    adminMass = 4.4e-05,
    ka = 0.0001388888888888889,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>patients with liver cirrhosis (Child A-C) and matched control subjects</td></tr><tr><td>source_paper:</td><td>Duthaler_2022</td></tr><tr><td>measured_compound:</td><td>Flurbiprofen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Flurbiprofen 244.265 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'ke (1/h)'; source reconciliation required</li><li>table representations disagree for 't1/2 (h)'; source reconciliation required</li><li>table representations disagree for 'Cmax (µg/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC0–24h (µg × h/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC0–inf (µg × h/mL)'; source reconciliation required</li><li>table representations disagree for 'MR0–24h'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC0–24h (ng × h/mL)'; source reconciliation required</li><li>table representations disagree for 'Vz/F (L)'; source reconciliation required</li><li>table representations disagree for 'Cl/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'AUC0–inf (ng × h/mL)'; source reconciliation required</li><li>dropped duplicate Q32 ('Cmax (ng/mL)', value '93.0') — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0–24h (ng × h/mL)', value '960') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0–inf (ng × h/mL)', value '8477') — already have one for this compound</li><li>dropped duplicate Q47 ('ke', value '0.131') — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2', value '5.28') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Flurbiprofen_Duthaler2022_child_a;
