function p = Flurbiprofen_Duthaler2022_child_a_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flurbiprofen   source: Duthaler_2022 / child_a   route: oral
  % estimated (absent from source): ka
  p.name  = 'Flurbiprofen_Duthaler2022_child_a_params';
  p.drug  = 'flurbiprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 698.0;                % central volume [L]
  p.CL = 31.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 44.0;             % dose [mg]
end
