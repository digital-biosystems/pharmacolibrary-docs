model BempedoicAcid_Amore2023_reference
  parameter Real Cl_ref = 2.2500000000000002e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02454024264552127 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.344492,
    adminMass = 1e-05,
    k12 = 1.018734833274464e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bempedoic_acid</h4><p>Bempedoic acid is a lipid-lowering medicine used to treat high cholesterol and other dyslipidaemias. It is authorised in the European Union and is used, alone or in combination with other lipid-modifying agents, to lower blood cholesterol.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27075007\">Wikidata Q27075007</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bempedoic_acid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Amore_2023</td></tr><tr><td>measured_compound:</td><td>bempedoic_acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bempedoic_acid 344.492 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Amore_2023) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end BempedoicAcid_Amore2023_reference;
