model BempedoicAcid_Jadhav2023_reference
  parameter Real Cl_ref = 2.0972222222222223e-07 "Cl [m3/s]";
  parameter Real cov_race_0 = 0 "race covariate";
  parameter Real cov_egfr = 1.0 "egfr covariate (reference 1.0)";
  parameter Real cov_age = 1.0 "age covariate (reference 1.0)";
  parameter Real Vd_ref = 0.019100000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (18.0)*cov_race_0)*(cov_egfr/1.0)^(0.574)*(cov_age/1.0)^(0.743),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.344492,
    adminMass = 0.00018,
    ka = 0.00039166666666666663,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bempedoic_acid</h4><p>Bempedoic acid is a lipid-lowering medicine used to treat high cholesterol and other dyslipidaemias. It is authorised in the European Union and is used, alone or in combination with other lipid-modifying agents, to lower blood cholesterol.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27075007\">Wikidata Q27075007</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bempedoic_acid</td></tr><tr><td>population:</td><td>healthy subjects and patients with dyslipidemia</td></tr><tr><td>source_paper:</td><td>Jadhav_2023</td></tr><tr><td>measured_compound:</td><td>bempedoic_acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bempedoic_acid 344.492 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'PD proportional, %' routed out of structural estimates ('Residual errora')</li><li>table section residual_error: 'PD additive, g/dL' routed out of structural estimates ('Residual errora')</li><li>table section iiv: 'Imax' routed out of structural estimates ('IIV, %CV')</li><li>table section iiv: 'Baseline LDL-C' routed out of structural estimates ('IIV, %CV')</li><li>table section residual_error: 'Serial PK sampling' routed out of structural estimates ('Residual errora, %')</li><li>table section residual_error: 'Serial PK sampling' routed out of structural estimates ('Residual errora, %')</li><li>table section residual_error: 'Sparse PK sampling' routed out of structural estimates ('Residual errora, %')</li><li>table section residual_error: 'Sparse PK sampling' routed out of structural estimates ('Residual errora, %')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV, %CV')</li><li>table section iiv: 'Vc/F' routed out of structural estimates ('IIV, %CV')</li><li>table section iiv: 'Ka' routed out of structural estimates ('IIV, %CV')</li><li>table representations disagree for 'Imax'; source reconciliation required</li><li>table representations disagree for 'IC50, µg/mL'; source reconciliation required</li><li>table representations disagree for 'Baseline LDL-C, mg/dL'; source reconciliation required</li><li>table representations disagree for 'TURN, h'; source reconciliation required</li><li>table representations disagree for 'Ezetimibe'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end BempedoicAcid_Jadhav2023_reference;
