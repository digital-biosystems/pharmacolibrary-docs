function p = Chlordiazepoxide_Sellers1979_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chlordiazepoxide   source: Sellers_1979 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Chlordiazepoxide_Sellers1979_reference_params';
  p.drug  = 'chlordiazepoxide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 26.6;                % central volume [L]
  p.CL = 2.268;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
