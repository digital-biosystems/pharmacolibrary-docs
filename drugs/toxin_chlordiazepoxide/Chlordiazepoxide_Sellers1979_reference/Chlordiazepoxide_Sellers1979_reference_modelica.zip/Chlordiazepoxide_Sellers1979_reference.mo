model Chlordiazepoxide_Sellers1979_reference
  parameter Real Cl_ref = 6.3e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29975799999999997,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chlordiazepoxide</td></tr><tr><td>population:</td><td>normal subjects and patients with biopsy-proven cirrhosis</td></tr><tr><td>source_paper:</td><td>Sellers_1979</td></tr><tr><td>measured_compound:</td><td>Chlordiazepoxide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>chlordiazepoxide 299.758 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped 'clearance (r)' → Q22 = -0.63: a clearance of -0.63 is not a parameter value (source ['Sellers_1979:abstract'])</li><li>dropped duplicate Q60 ('t 1/2 beta (cirrhotic)', value 34.9) — already have one for this compound</li><li>unit_dimension_mismatch: 'Vd (cirrhotic)' → Q61 (unit 'dimensionless' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q61 ('Vd (cirrhotic)', value 0.34) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance (cirrhotic)', value 0.185) — already have one for this compound</li><li>covariate category for t1/2β from footnote/prose kept as documentation only (['Sellers_1979:abstract'])</li><li>covariate category for t1/2β from footnote/prose kept as documentation only (['Sellers_1979:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chlordiazepoxide</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Chlordiazepoxide_Sellers1979_reference;
