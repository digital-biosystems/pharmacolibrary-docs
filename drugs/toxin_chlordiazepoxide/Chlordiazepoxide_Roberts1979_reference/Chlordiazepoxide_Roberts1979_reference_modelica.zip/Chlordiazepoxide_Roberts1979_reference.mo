model Chlordiazepoxide_Roberts1979_reference
  parameter Real Cl_ref = 3.438796026097579e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0434 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29975799999999997,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chlordiazepoxide</td></tr><tr><td>population:</td><td>healthy young men and women, and women on oral contraceptive steroids</td></tr><tr><td>source_paper:</td><td>Roberts_1979</td></tr><tr><td>measured_compound:</td><td>Chlordiazepoxide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>chlordiazepoxide 299.758 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q60 ('elimination half-life (t1/2(beta)) in women', value 14.8) — already have one for this compound</li><li>'protein binding in men' → Q46: printed without a unit and above 1 — read as a percentage</li><li>'protein binding in women' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q46 ('protein binding in women', value 95.5) — already have one for this compound</li><li>dropped duplicate Q24 ('clearance of unbound drug in women', value 8.7) — already have one for this compound</li><li>'plasma binding women on OC steroids' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q46 ('plasma binding women on OC steroids', value 93.6) — already have one for this compound</li><li>'plasma binding women not on OC steroids' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q46 ('plasma binding women not on OC steroids', value 95.5) — already have one for this compound</li><li>dropped duplicate Q61 ('volume of distribution women not on OC steroids', value 0.4) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination t1/2 women not on OC steroids', value 14.8) — already have one for this compound</li><li>dropped duplicate Q24 ('clearance of unbound drug women on OC steroids', value 5.7) — already have one for this compound</li><li>dropped duplicate Q24 ('clearance of unbound drug women not on OC steroids', value 8.7) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chlordiazepoxide</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Chlordiazepoxide_Roberts1979_reference;
