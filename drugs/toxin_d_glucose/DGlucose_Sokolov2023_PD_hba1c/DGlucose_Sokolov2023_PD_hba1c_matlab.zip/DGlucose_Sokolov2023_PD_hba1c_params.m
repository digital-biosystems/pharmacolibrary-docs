function p = DGlucose_Sokolov2023_PD_hba1c_params()
% DGlucose_Sokolov2023_PD_hba1c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% d_glucose Sokolov_2023::HbA1c: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/dL per second, in SI inside (kg/m3, s). Response HbA1c in %. Driver: plasma glucose (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.000421;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.165;
p.exposure_per_s = 0.01;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
