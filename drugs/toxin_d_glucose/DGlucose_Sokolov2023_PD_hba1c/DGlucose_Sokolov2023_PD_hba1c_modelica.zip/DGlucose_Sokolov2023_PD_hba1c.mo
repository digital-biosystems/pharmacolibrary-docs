model DGlucose_Sokolov2023_PD_hba1c
  "linear exposure-response sweep — Sokolov_2023 :: HbA1c (HbA1c)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.01);
  parameter Real slope = 0.165   "[1]";
equation
  response = E0 + slope*exposure;
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>DGlucose_Sokolov2023_PD_hba1c</h4><p>The steady-state exposure-response curve of Sokolov V et al., <i>Frontiers in pharmacology 14:1229255</i> 2023 (<a href=\"https://doi.org/10.3389/fphar.2023.1229255\">doi:10.3389/fphar.2023.1229255</a>) — HbA1c [%] against plasma glucose mg/dL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0421 %        maximal effect term (Imaxhba1c, Q323)
  slope =      0.165          change in response per unit of exposure (k2, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/dL of plasma glucose per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end DGlucose_Sokolov2023_PD_hba1c;
