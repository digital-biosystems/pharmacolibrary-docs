function p = DGlucose_Saito2020_PD_fpg_params()
% DGlucose_Saito2020_PD_fpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% d_glucose Saito_2020::FPG: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one g per 24 h per second, in SI inside (kg/m3, s). Response FPG in mg/dL. Driver: urinary glucose excretion (dose_only).
p.E0 = 0.0;
p.Emax = -0.4529999999999999;
p.EC50 = 39.4;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 400.0;
p.form = 'E0 + Emax*frac';
end
