model DGlucose_Saito2020_PD_hba1c
  "emax exposure-response sweep — Saito_2020 :: HbA1c (hemoglobin A1c)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0156,  // [1; % × 0.01]
    EC50 = 24.1,  // [g/24h]
    gamma = 1,
    exposure_per_s = 1);   // 1 g/24h per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'g/24h' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 250, Interval = 0.5),
    Documentation(info = "<html><body><h4>DGlucose_Saito2020_PD_hba1c</h4><p>The steady-state exposure-response curve of Saito M et al., <i>Diabetes therapy : research, treatment and education of diabetes and related disorders 11(4):951–964</i> 2020 (<a href=\"https://doi.org/10.1007/s13300-020-00785-2\">doi:10.1007/s13300-020-00785-2</a>) — hemoglobin A1c [%] against urinary glucose excretion g/24h — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.56 %        maximal effect term (Emax, Q323)
  EC50  =       24.1 g/24h    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one g/24h of urinary glucose excretion per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (24.1 g/24h)  response -0.0078
  exposure -> infinity  response -0.0156</pre></body></html>"));
end DGlucose_Saito2020_PD_hba1c;
