function p = DGlucose_Saito2020_PD_hba1c_params()
% DGlucose_Saito2020_PD_hba1c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% d_glucose Saito_2020::HbA1c: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one g/24h per second, in SI inside (kg/m3, s). Response HbA1c in %. Driver: urinary glucose excretion (dose_only).
p.E0 = 0.0;
p.Emax = -0.015600000000000001;
p.EC50 = 24.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 250.0;
p.form = 'E0 + Emax*frac';
end
