model Desvenlafaxine_MangasSanjun2023_reference
  parameter Real Cl_ref = 3.1722222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06531 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.006111111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>desvenlafaxine</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Mangas-Sanjuán_2023</td></tr><tr><td>measured_compound:</td><td>desvenlafaxine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_4</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q306 ('k tr (%)', value '19') — already have one for this compound</li><li>dropped duplicate Q22 ('CL (%)', value '8') — already have one for this compound</li><li>dropped duplicate Q63 ('V 1 (%)', value '30') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Plasma (%)' — extend the ontology if this is a real PK parameter (source ['tab_4:row16:col1', 'tab_4:row16:col2', 'tab_4:row16:col3', 'tab_4:row16:col4', 'tab_4:row16:col5', 'tab_4:row16:col6'])</li><li>dropped value-less row: 'k a'</li><li>dropped value-less row: 'k tr'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'V 1'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'CI'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=desvenlafaxine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Desvenlafaxine_MangasSanjun2023_reference;
