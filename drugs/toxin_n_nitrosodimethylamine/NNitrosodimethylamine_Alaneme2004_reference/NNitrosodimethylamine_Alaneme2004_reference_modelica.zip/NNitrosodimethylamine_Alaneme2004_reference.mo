// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model NNitrosodimethylamine_Alaneme2004_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {46167.064755149},
    MM = 0.074083,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>n_nitrosodimethylamine</td></tr><tr><td>population:</td><td>Albino Wistar rats (Rattus norvegius)</td></tr><tr><td>source_paper:</td><td>Alaneme_2004</td></tr><tr><td>measured_compound:</td><td>N-Nitrosodimethylamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>N-Nitrosodimethylamine 74.083 g/mol (pubchem); n_nitrosodimethylamine 74.083 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'culmulative excretions of NDMA' → mg (from the popPK convention: &quot;No unit is stated in the provided text or captions. The parameter 'culmulative excretions' (Ae) typically refers to the &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=N-Nitrosodimethylamine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Eisenbrand_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q83 (tlag) from Yang_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end NNitrosodimethylamine_Alaneme2004_reference;
