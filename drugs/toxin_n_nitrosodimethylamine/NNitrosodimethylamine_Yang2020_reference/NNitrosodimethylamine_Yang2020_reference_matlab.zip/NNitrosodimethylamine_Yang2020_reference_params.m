function p = NNitrosodimethylamine_Yang2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: n_nitrosodimethylamine   source: Yang_2020 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'NNitrosodimethylamine_Yang2020_reference_params';
  p.drug  = 'n_nitrosodimethylamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1706.6;                % central volume [L]
  p.CL = 194.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 5.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
