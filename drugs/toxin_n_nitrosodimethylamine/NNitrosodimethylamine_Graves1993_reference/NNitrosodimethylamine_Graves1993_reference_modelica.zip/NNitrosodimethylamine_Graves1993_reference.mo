model NNitrosodimethylamine_Graves1993_reference
  parameter Real Cl_ref = 5.75e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0648 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.074083,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>n_nitrosodimethylamine</td></tr><tr><td>population:</td><td>perfused rat liver</td></tr><tr><td>source_paper:</td><td>Graves_1993</td></tr><tr><td>measured_compound:</td><td>N-Nitrosodimethylamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>N-Nitrosodimethylamine 74.083 g/mol (pubchem); n_nitrosodimethylamine 74.083 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for Km from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>covariate category for Vmax from footnote/prose kept as documentation only (['Graves_1993:abstract', 'Graves_1993:abstract'])</li><li>covariate category for kic from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>covariate category for Km from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>covariate category for kic from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>unit_dimension_unknown: 'nmol/g liver/min' (Vmax)</li><li>unit_dimension_unknown: 'nmol/g liver/min' (Vmax)</li><li>dropped duplicate Q66 ('maximal rate of clearance of NDEA', value 8.9) — already have one for this compound</li><li>covariate category for Km from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>covariate category for Km from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>covariate category for Km from footnote/prose kept as documentation only (['Graves_1993:abstract'])</li><li>implicit units: 'maximal rate of clearance of NDMA' → mg/h (from the popPK convention: 'The parameter is Vmax, representing the maximal rate of metabolism (clearance in a Michaelis-Menten context). The magnit')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=N-Nitrosodimethylamine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Eisenbrand_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Eisenbrand_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end NNitrosodimethylamine_Graves1993_reference;
