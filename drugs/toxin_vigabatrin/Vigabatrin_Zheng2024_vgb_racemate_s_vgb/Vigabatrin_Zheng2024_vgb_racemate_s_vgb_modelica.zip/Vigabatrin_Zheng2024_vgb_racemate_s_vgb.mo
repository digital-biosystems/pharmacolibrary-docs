model Vigabatrin_Zheng2024_vgb_racemate_s_vgb
  parameter Real Cl_ref = 1.4602777777777779e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17108 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0035,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vigabatrin</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Zheng_2024</td></tr><tr><td>measured_compound:</td><td>R-Vigabatrin; S-Vigabatrin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0035</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>vigabatrin 129.159 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '200' — extend the ontology if this is a real PK parameter (source ['Zheng_2024_table_6:row1:col3'])</li><li>dropped unlinked row (NIL): '100' — extend the ontology if this is a real PK parameter (source ['Zheng_2024_table_6:row8:col3'])</li><li>dropped unlinked row (NIL): '50' — extend the ontology if this is a real PK parameter (source ['Zheng_2024_table_6:row15:col3'])</li><li>dropped value-less row: 't1/2'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'AUC/D'</li><li>dropped value-less row: 'Vz/F'</li><li>dropped value-less row: 'Cl/F'</li><li>dropped value-less row: 'MRT'</li><li>salvaged Q57 ('t1/2 (h)'=2.285) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Vz/F (L/kg)'=2.444) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('Cl/F(L/h/kg)'=0.751) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=R-Vigabatrin; S-Vigabatrin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vigabatrin_Zheng2024_vgb_racemate_s_vgb;
