function p = Vigabatrin_Zheng2024_vgb_racemate_r_vgb_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vigabatrin   source: Zheng_2024 / vgb_racemate_r_vgb   route: oral
  % estimated (absent from source): ka
  p.name  = 'Vigabatrin_Zheng2024_vgb_racemate_r_vgb_params';
  p.drug  = 'vigabatrin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 190.89;                % central volume [L]
  p.CL = 59.29;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3500.0;             % dose [mg]
end
