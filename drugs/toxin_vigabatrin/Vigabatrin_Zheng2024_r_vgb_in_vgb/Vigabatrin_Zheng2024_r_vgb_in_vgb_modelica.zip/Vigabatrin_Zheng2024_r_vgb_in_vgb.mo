model Vigabatrin_Zheng2024_r_vgb_in_vgb
  parameter Real Cl_ref = 1.075277777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09989 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0035,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vigabatrin</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Zheng_2024</td></tr><tr><td>measured_compound:</td><td>R-Vigabatrin; S-Vigabatrin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0035</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>vigabatrin 129.159 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'VGB racemate (200 mg/kg) vs. single enantiomer (100 mg/kg)' — extend the ontology if this is a real PK parameter (source ['Zheng_2024_table_8:row0:col2'])</li><li>dropped unlinked row (NIL): 'VGB racemate (100 mg/kg) vs. single enantiomer (50 mg/kg)' — extend the ontology if this is a real PK parameter (source ['Zheng_2024_table_8:row7:col2'])</li><li>dropped value-less row: 't1/2'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'AUC/D'</li><li>dropped value-less row: 'Vz/F'</li><li>dropped value-less row: 'Cl/F'</li><li>dropped value-less row: 'MRT'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=R-Vigabatrin; S-Vigabatrin</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'r-vgb in vgb' subgroup of Zheng_2024 (paper reports 7 populations: r-vgb in vgb, s-vgb in vgb, single enantiomer / r-vgb, single enantiomer / s-vgb, single enantiomer r-vgb, vgb racemate / r-vgb, vgb racemate / s-vgb)</li><li>molar mass: no plausible PubChem entry for 'R-Vigabatrin; S-Vigabatrin' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'R-Vigabatrin; S-Vigabatrin' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vigabatrin_Zheng2024_r_vgb_in_vgb;
