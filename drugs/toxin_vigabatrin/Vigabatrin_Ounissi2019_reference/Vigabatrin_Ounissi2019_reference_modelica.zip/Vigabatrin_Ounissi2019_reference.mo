model Vigabatrin_Ounissi2019_reference
  parameter Real Cl_ref = 6.555555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.017 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.002,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vigabatrin</td></tr><tr><td>population:</td><td>children (aged 0.4-5.7 years)</td></tr><tr><td>source_paper:</td><td>Ounissi_2019</td></tr><tr><td>measured_compound:</td><td>S(+)-enantiomer of vigabatrin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>vigabatrin 129.159 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'absorption duration' — extend the ontology if this is a real PK parameter (source ['Ounissi_2019:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=S(+)-enantiomer of vigabatrin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>molar mass: no plausible PubChem entry for 'S(+)-enantiomer of vigabatrin' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'S(+)-enantiomer of vigabatrin' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Vigabatrin_Ounissi2019_reference;
