model Vigabatrin_Rey1992_reference
  parameter Real Cl_ref = 1e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.056 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129159,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vigabatrin</td></tr><tr><td>population:</td><td>healthy volunteers, epileptic children, adults with epilepsy, elderly volunteers</td></tr><tr><td>source_paper:</td><td>Rey_1992</td></tr><tr><td>measured_compound:</td><td>Vigabatrin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vigabatrin 129.159 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('the half-life of the enantiomers ... S(+) ...', value 7.5) — already have one for this compound</li><li>dropped duplicate Q57 ('the half-life of the enantiomers ... R(-) ...', value 8.1) — already have one for this compound</li><li>dropped duplicate Q57 ('the half-life of the [R,S]-vigabatrin ... ranged from', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'Higher dosages up to ... were required in children' — extend the ontology if this is a real PK parameter (source ['Rey_1992:abstract'])</li><li>dropped duplicate Q57 ('half-life', value '6.35') — already have one for this compound</li><li>implicit units: 'urinary recovery of the [R,S]-vigabatrin' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vigabatrin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Jacob_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Jacob_2016 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q91, Q3 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Vigabatrin_Rey1992_reference;
