model Vigabatrin_Zheng2024_single_enantiomer_r_vgb
  parameter Real Cl_ref = 9.177777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13454 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129159,
    adminMass = 0.0035,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vigabatrin</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Zheng_2024</td></tr><tr><td>measured_compound:</td><td>R-Vigabatrin; S-Vigabatrin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0035</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>R-Vigabatrin; S-Vigabatrin 129.159 g/mol (pubchem); vigabatrin 129.159 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for '200'; source reconciliation required</li><li>table representations disagree for 'Tmax(h)'; source reconciliation required</li><li>table representations disagree for 'Cmax(mg/L)'; source reconciliation required</li><li>table representations disagree for 'AUC/D(h*kg*mg/L/mg)'; source reconciliation required</li><li>table representations disagree for 'Vz/F (L/kg)'; source reconciliation required</li><li>table representations disagree for 'Cl/F(L/h/kg)'; source reconciliation required</li><li>table representations disagree for 'MRT(h)'; source reconciliation required</li><li>table representations disagree for '100'; source reconciliation required</li><li>table representations disagree for '50'; source reconciliation required</li><li>dropped unlinked row (NIL): '200' — extend the ontology if this is a real PK parameter (source ['t0035:row2:col2'])</li><li>dropped unlinked row (NIL): '100' — extend the ontology if this is a real PK parameter (source ['t0035:row9:col2'])</li><li>dropped unlinked row (NIL): '50' — extend the ontology if this is a real PK parameter (source ['t0035:row16:col2'])</li><li>dropped value-less row: 't1/2'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'AUC/D'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vigabatrin_Zheng2024_single_enantiomer_r_vgb;
