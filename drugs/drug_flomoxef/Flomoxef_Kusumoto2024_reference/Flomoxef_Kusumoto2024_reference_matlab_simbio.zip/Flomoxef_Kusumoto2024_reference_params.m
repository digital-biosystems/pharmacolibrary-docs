function p = Flomoxef_Kusumoto2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flomoxef   source: Kusumoto_2024 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Flomoxef_Kusumoto2024_reference_params';
  p.drug  = 'flomoxef';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.27;                % central volume [L]
  p.CL = 2.97;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
