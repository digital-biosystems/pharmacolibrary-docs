function p = Dofetilide_Gotta2015_PD_qtc_params()
% Dofetilide_Gotta2015_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dofetilide Gotta_2015::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response QTc in ms. Driver: dofetilide (pk_record).
p.E0 = 0.248;
p.Emax = 0.0502;
p.EC50 = 9.5;
p.gamma = 1.4;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 95.0;
p.form = 'E0 + Emax*frac';
end
