model Dofetilide_Gotta2015_PD_qtc
  "sigmoid_emax exposure-response sweep — Gotta_2015 :: QTc (QTc)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.248,      // [s; ms × 0.001]
    Emax = 0.0502,  // [s; ms × 0.001]
    EC50 = 9.5,  // [nM]
    gamma = 1.4,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 95, Interval = 0.19),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dofetilide_Gotta2015_PD_qtc</h4><p>The steady-state exposure-response curve of Gotta V et al., <i>British journal of pharmacology 172(17):4364–4379</i> 2015 (<a href=\"https://doi.org/10.1111/bph.13218\">doi:10.1111/bph.13218</a>) — QTc [ms] against dofetilide nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        248 ms       drug-free response (baseline) (QTcBL60, Q324)
  Emax  =       50.2 ms       maximal effect term (Emax, Q320)
  EC50  =        9.5 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.4          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of dofetilide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.248   (drug-free)
  exposure = EC50 (9.5 nM)  response 0.2731
  exposure -> infinity  response 0.2982</pre></body></html>"));
end Dofetilide_Gotta2015_PD_qtc;
