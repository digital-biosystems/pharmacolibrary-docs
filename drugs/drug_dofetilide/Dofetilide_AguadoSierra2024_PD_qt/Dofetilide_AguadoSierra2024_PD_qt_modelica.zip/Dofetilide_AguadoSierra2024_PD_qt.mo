model Dofetilide_AguadoSierra2024_PD_qt
  "linear exposure-response sweep — Aguado-Sierra_2024 :: QT (QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 24.82   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dofetilide_AguadoSierra2024_PD_qt</h4><p>The steady-state exposure-response curve of Aguado-Sierra J et al., <i>Journal of pharmacological and toxicological methods 126:107498</i> 2024 (<a href=\"https://doi.org/10.1016/j.vascn.2024.107498\">doi:10.1016/j.vascn.2024.107498</a>) — QT interval [ms] against dofetilide ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      24.82          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of dofetilide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Dofetilide_AguadoSierra2024_PD_qt;
