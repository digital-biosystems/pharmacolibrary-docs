function p = Dofetilide_AguadoSierra2024_PD_qt_params()
% Dofetilide_AguadoSierra2024_PD_qt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dofetilide Aguado-Sierra_2024::QT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response QT in ms. Driver: dofetilide (cited_pk).
p.E0 = 0.00067;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 24820.000000000004;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
