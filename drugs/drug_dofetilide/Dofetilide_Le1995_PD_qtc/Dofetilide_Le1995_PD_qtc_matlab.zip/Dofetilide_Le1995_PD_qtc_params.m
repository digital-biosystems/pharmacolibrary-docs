function p = Dofetilide_Le1995_PD_qtc_params()
% Dofetilide_Le1995_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dofetilide Le_1995::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response QTc in msec. Driver: dofetilide (pk_record).
p.E0 = 0.368;
p.Emax = 0.121;
p.EC50 = 2.2e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 22.0;
p.form = 'E0 + Emax*frac';
end
