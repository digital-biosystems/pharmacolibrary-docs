model Dofetilide_Le1995_PD_qtc
  "sigmoid_emax exposure-response sweep — Le_1995 :: QTc (QT, interval duration)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.368,      // [s; msec × 0.001]
    Emax = 0.121,  // [s; msec × 0.001]
    EC50 = 2.2e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 22, Interval = 0.044),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dofetilide_Le1995_PD_qtc</h4><p>The steady-state exposure-response curve of Le Coz F et al., <i>Clinical pharmacology and therapeutics 57(5):533–542</i> 1995 (<a href=\"https://doi.org/10.1016/0009-9236(95)90038-1\">doi:10.1016/0009-9236(95)90038-1</a>) — QT, interval duration [msec] against dofetilide ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        368 msec     drug-free response (baseline) (E,,, fitted minimum QT interval (effect at zero dofetilide concentration), Q324)
  Emax  =        121 msec     maximal effect term (E max, Q320)
  EC50  =        2.2 ng/ml    exposure at half of the maximal effect term (EC,,, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of dofetilide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.368   (drug-free)
  exposure = EC50 (2.2 ng/ml)  response 0.4285
  exposure -> infinity  response 0.489</pre></body></html>"));
end Dofetilide_Le1995_PD_qtc;
