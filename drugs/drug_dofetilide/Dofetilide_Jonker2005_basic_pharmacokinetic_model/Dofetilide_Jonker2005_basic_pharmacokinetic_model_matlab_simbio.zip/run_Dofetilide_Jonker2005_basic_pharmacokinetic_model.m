% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Dofetilide_Jonker2005_basic_pharmacokinetic_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
