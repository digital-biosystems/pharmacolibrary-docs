function p = Dofetilide_Jonker2005_basic_pharmacokinetic_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dofetilide   source: Jonker_2005 / basic_pharmacokinetic_model   route: oral
  p.name  = 'Dofetilide_Jonker2005_basic_pharmacokinetic_model_params';
  p.drug  = 'dofetilide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.1;                % central volume [L]
  p.CL = 0.828;                % clearance [L/h]
  p.Vp = [505.0];             % peripheral volumes [L]
  p.Q  = [14.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.05;                % absorption rate [1/h]
  p.F  = 0.43;                 % bioavailability [0-1]
  p.Tlag = 0.894;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
