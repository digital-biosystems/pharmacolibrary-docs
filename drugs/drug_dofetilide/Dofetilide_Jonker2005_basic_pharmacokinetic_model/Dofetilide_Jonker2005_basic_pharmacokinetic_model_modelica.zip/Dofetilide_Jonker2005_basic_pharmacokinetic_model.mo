model Dofetilide_Jonker2005_basic_pharmacokinetic_model
  parameter Real Cl_ref = 2.3e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0171 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.43,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.441565,
    adminMass = 0.001,
    ka = 1.388888888888889e-05,
    Tlag = 3218.4,
    k12 = 0.00023229369720597793,
    k21 = 7.865786578657866e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dofetilide</td></tr><tr><td>population:</td><td>healthy volunteers and patients with ischemic heart disease</td></tr><tr><td>source_paper:</td><td>Jonker_2005</td></tr><tr><td>measured_compound:</td><td>dofetilide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dofetilide 441.565 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>'Q2 (L/h)' linked to Q99: a second intercompartmental clearance beside the Q30 already present</li><li>unit_dimension_mismatch: 'CLAGE (L · h-1 · y-1)' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('CLAGE (L · h-1 · y-1)', value '61.5') — already have one for this compound</li><li>routed 'εAdd (ng/mL)' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'εProp (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dofetilide</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'basic pharmacokinetic model' subgroup of Jonker_2005 (paper reports 2 populations: basic pharmacokinetic model, including covariates)</li><li>gap-filled Q49 (kabs) from Gotta_2015's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Dofetilide_Jonker2005_basic_pharmacokinetic_model;
