model Dofetilide_Tunblad2008_final
  parameter Real Cl_ref = 4.305555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23600000000000002 "Vd [m3]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (0.7)*cov_weight_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.441565,
    adminMass = 2.5e-07,
    ka = 0.00038888888888888887,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dofetilide</td></tr><tr><td>population:</td><td>patients with arrhythmia</td></tr><tr><td>source_paper:</td><td>Tunblad_2008</td></tr><tr><td>measured_compound:</td><td>dofetilide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_6</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dofetilide 441.565 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'Correlation CL/F-V/F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iov: 'CL/F' routed out of structural estimates ('Interoccasion variability (%)')</li><li>table section iov: 'Ka' routed out of structural estimates ('Interoccasion variability (%)')</li><li>table section iov: 'Correlation CL/F-Ka' routed out of structural estimates ('Interoccasion variability (%)')</li><li>table section residual_error: 'Additive on the Box-Cox transformed scale (0.6)' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'Creatinine clearance on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_6:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dofetilide</li><li>model-stage split: 'final model clinical' is the final model of Tunblad_2008 (paper reports 2 stages: base model (foce), final model clinical); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Dofetilide_Tunblad2008_final;
