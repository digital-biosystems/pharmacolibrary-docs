function p = Dofetilide_Tunblad2008_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dofetilide   source: Tunblad_2008 / final   route: oral
  p.name  = 'Dofetilide_Tunblad2008_final_params';
  p.drug  = 'dofetilide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 236.0;                % central volume [L]
  p.CL = 15.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
