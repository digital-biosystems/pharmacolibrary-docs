function p = Dofetilide_Ollerstam2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dofetilide   source: Ollerstam_2006 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Dofetilide_Ollerstam2006_reference_params';
  p.drug  = 'dofetilide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.5;                % central volume [L]
  p.CL = 42.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.05;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
