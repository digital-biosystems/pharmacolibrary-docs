model Dofetilide_Ollerstam2006_reference
  parameter Real Cl_ref = 1.1666666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0175 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.441565,
    adminMass = 0.0001,
    ka = 1.388888888888889e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dofetilide</td></tr><tr><td>population:</td><td>conscious beagle dogs</td></tr><tr><td>source_paper:</td><td>Ollerstam_2006</td></tr><tr><td>measured_compound:</td><td>dofetilide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dofetilide 441.565 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'pEC 50' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'E 0' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'k e0' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability %')</li><li>table section iiv: 'CLD' routed out of structural estimates ('Interindividual variability %')</li><li>table section iiv: 'Vc' routed out of structural estimates ('Interindividual variability %')</li><li>table section iiv: 'Vt' routed out of structural estimates ('Interindividual variability %')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dofetilide</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gotta_2015's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Dofetilide_Ollerstam2006_reference;
