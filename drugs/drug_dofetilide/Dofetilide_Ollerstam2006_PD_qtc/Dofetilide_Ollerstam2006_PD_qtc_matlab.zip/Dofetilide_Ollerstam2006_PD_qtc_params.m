function p = Dofetilide_Ollerstam2006_PD_qtc_params()
% Dofetilide_Ollerstam2006_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dofetilide Ollerstam_2006::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one log (nM) per second, in SI inside (kg/m3, s). Response QTc in ms. Driver: dofetilide (cited_pk).
p.E0 = 0.212;
p.Emax = 0.059000000000000004;
p.EC50 = 0.95;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 9.5;
p.form = 'E0 + Emax*frac';
end
