model Dofetilide_Ollerstam2006_PD_qtc
  "sigmoid_emax exposure-response sweep — Ollerstam_2006 :: QTc (QT c interval)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.212,      // [s; ms × 0.001]
    Emax = 0.059,  // [s; ms × 0.001]
    EC50 = 0.95,  // [log (nM)]
    gamma = 1.2,
    exposure_per_s = 1);   // 1 log (nM) per second
  // exposure_unit_unresolved: 'log (nM)' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 9.5, Interval = 0.019),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dofetilide</h4><p>Dofetilide is a class III antiarrhythmic used to treat heart rhythm problems, especially atrial fibrillation and atrial flutter. It is not authorised in the European Union, where its product was withdrawn; in the United States it is approved but restricted to hospital use because of a boxed warning for dangerous rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3712521\">Wikidata Q3712521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dofetilide_Ollerstam2006_PD_qtc</h4><p>The steady-state exposure-response curve of Ollerstam A et al., <i>Journal of pharmacological and toxicological methods 53(2):174–183</i> 2006 (<a href=\"https://doi.org/10.1016/j.vascn.2005.07.002\">doi:10.1016/j.vascn.2005.07.002</a>) — QT c interval [ms] against dofetilide log (nM) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        212 ms       drug-free response (baseline) (E 0, Q324)
  Emax  =         59 ms       maximal effect term (E max, Q320)
  EC50  =       0.95 log (nM) exposure at half of the maximal effect term (pEC 50, Q321)
  gamma =        1.2          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one log (nM) of dofetilide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.212   (drug-free)
  exposure = EC50 (0.95 log (nM))  response 0.2415
  exposure -> infinity  response 0.271</pre></body></html>"));
end Dofetilide_Ollerstam2006_PD_qtc;
