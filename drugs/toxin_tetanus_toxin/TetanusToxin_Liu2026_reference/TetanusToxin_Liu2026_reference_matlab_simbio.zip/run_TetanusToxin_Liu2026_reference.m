% Run (SimBiology): build model + dose, simulate 0..3360.0 h, plot.
p = TetanusToxin_Liu2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3360.0);
