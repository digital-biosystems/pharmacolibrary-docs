// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model TetanusToxin_Critchley1985_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {900.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetanus_toxin</td></tr><tr><td>population:</td><td>primary mouse spinal cord neuron cultures</td></tr><tr><td>source_paper:</td><td>Critchley_1985</td></tr><tr><td>measured_compound:</td><td>tetanus toxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'NCB20' — extend the ontology if this is a real PK parameter (source ['Critchley_1985_table_1:row0:col3', 'Critchley_1985_table_1:row0:col4', 'Critchley_1985_table_1:row1:col6', 'Critchley_1985_table_1:row2:col4', 'Critchley_1985_table_1:row2:col6'])</li><li>dropped unlinked row (NIL): 'Neurons' — extend the ontology if this is a real PK parameter (source ['Critchley_1985_table_1:row3:col6', 'Critchley_1985_table_1:row4:col6'])</li><li>salvaged Q57 ('half-life of this fraction of bound toxin'=15) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tetanus toxin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'tetanus_toxin' — its concentrations stay mass-only</li><li>molar mass: none found for 'tetanus toxin' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end TetanusToxin_Critchley1985_reference;
