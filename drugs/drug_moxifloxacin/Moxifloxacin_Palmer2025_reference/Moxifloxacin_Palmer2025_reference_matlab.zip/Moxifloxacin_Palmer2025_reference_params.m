function p = Moxifloxacin_Palmer2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxifloxacin   source: Palmer_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Moxifloxacin_Palmer2025_reference_params';
  p.drug  = 'moxifloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 61.1;                % central volume [L]
  p.CL = 6.9;                % clearance [L/h]
  p.Vp = [44.5];             % peripheral volumes [L]
  p.Q  = [0.86];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
