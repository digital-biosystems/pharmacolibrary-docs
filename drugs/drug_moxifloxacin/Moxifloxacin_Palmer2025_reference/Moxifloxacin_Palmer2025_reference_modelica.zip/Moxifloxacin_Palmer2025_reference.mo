model Moxifloxacin_Palmer2025_reference
  parameter Real Cl_ref = 1.916666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0611 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4014314,
    adminMass = 0.0004,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.909801782142208e-06,
    k21 = 5.36828963795256e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moxifloxacin</h4><p>Moxifloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as pneumonia, sinusitis, bronchitis, conjunctivitis, and urinary tract infections. It is an approved medicine, included on the WHO essential medicines list, and is used both systemically and as eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424940\">Wikidata Q424940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxifloxacin</td></tr><tr><td>population:</td><td>children with rifampicin-resistant tuberculosis</td></tr><tr><td>source_paper:</td><td>Palmer_2025</td></tr><tr><td>measured_compound:</td><td>moxifloxacin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70005-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>moxifloxacin 401.431 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV on CL (%CV) c' routed out of structural estimates ('IIV/IOV')</li><li>table section iiv: 'IOV on F (%CV) c' routed out of structural estimates ('IIV/IOV')</li><li>table section iiv: 'IOV on MAT (%CV) c' routed out of structural estimates ('IIV/IOV')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=moxifloxacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Moxifloxacin_Palmer2025_reference;
