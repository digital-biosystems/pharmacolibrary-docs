% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Moxifloxacin_Greenberg2022_standard_error_of_the_population_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
