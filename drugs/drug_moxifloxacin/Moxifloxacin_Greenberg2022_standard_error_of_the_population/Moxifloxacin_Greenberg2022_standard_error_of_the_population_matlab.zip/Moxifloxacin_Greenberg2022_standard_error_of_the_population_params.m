function p = Moxifloxacin_Greenberg2022_standard_error_of_the_population_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxifloxacin   source: Greenberg_2022 / standard_error_of_the_population_estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Moxifloxacin_Greenberg2022_standard_error_of_the_population_params';
  p.drug  = 'moxifloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.0;                % central volume [L]
  p.CL = 35.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 272.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
