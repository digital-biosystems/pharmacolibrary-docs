model Moxifloxacin_Yun2022_value
  parameter Real Cl_ref = 2.6166666666666665e-06 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Real Vd_ref = 0.14100000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 100.0,
    Cl = Cl_ref + (9.083333333333333e-08)*(if cov_category_0 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4014314,
    adminMass = 0.0004,
    ka = 0.0002972222222222222,
    Tlag = 0.0,
    k12 = 2.7777777777777775e-06,
    k21 = 4.420617005267118e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moxifloxacin</h4><p>Moxifloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as pneumonia, sinusitis, bronchitis, conjunctivitis, and urinary tract infections. It is an approved medicine, included on the WHO essential medicines list, and is used both systemically and as eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424940\">Wikidata Q424940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxifloxacin</td></tr><tr><td>population:</td><td>adults with multidrug-resistant tuberculosis (MDR-TB)</td></tr><tr><td>source_paper:</td><td>Yun_2022</td></tr><tr><td>measured_compound:</td><td>moxifloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>moxifloxacin 401.431 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV for V 1' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for CL' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for Q & V 2' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability (RV)')</li><li>table representations disagree for 'K a (hr−1)'; source reconciliation required</li><li>table representations disagree for 'V 1 (L)'; source reconciliation required</li><li>table representations disagree for 'CL (L/hr)'; source reconciliation required</li><li>table representations disagree for 'Q (L/hr)'; source reconciliation required</li><li>table representations disagree for 'V 2 (L)'; source reconciliation required</li><li>table representations disagree for 'F (%)a'; source reconciliation required</li><li>table representations disagree for 'Coefficient of CL for HIV-positiveb'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=moxifloxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'value' subgroup of Yun_2022 (paper reports 2 populations: population estimates, value)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Moxifloxacin_Yun2022_value;
