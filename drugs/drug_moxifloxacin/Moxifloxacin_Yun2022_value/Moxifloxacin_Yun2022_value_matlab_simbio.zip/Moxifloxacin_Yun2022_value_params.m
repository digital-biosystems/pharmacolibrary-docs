function p = Moxifloxacin_Yun2022_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxifloxacin   source: Yun_2022 / value   route: oral
  p.name  = 'Moxifloxacin_Yun2022_value_params';
  p.drug  = 'moxifloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 141.0;                % central volume [L]
  p.CL = 9.42;                % clearance [L/h]
  p.Vp = [886.0];             % peripheral volumes [L]
  p.Q  = [1.41];             % inter-compartmental clearances [L/h]
  p.ka = 1.07;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
