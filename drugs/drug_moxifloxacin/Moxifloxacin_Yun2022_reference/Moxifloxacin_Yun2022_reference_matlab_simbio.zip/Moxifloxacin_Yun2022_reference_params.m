function p = Moxifloxacin_Yun2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxifloxacin   source: Yun_2022 / reference   route: oral
  p.name  = 'Moxifloxacin_Yun2022_reference_params';
  p.drug  = 'moxifloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.1;                % central volume [L]
  p.CL = 7.3;                % clearance [L/h]
  p.Vp = [24.4];             % peripheral volumes [L]
  p.Q  = [20.9];             % inter-compartmental clearances [L/h]
  p.ka = 20.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
