model Moxifloxacin_Greenberg2022_population_estimate_or_median
  parameter Real Cl_ref = 5.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.167 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.76,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4014314,
    adminMass = 1e-05,
    ka = 0.0006138888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moxifloxacin</h4><p>Moxifloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as pneumonia, sinusitis, bronchitis, conjunctivitis, and urinary tract infections. It is an approved medicine, included on the WHO essential medicines list, and is used both systemically and as eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424940\">Wikidata Q424940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxifloxacin</td></tr><tr><td>population:</td><td>children</td></tr><tr><td>source_paper:</td><td>Greenberg_2022</td></tr><tr><td>measured_compound:</td><td>moxifloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>moxifloxacin 401.431 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CVCP' — extend the ontology if this is a real PK parameter (source ['T3:row6:col2'])</li><li>dropped unlinked row (NIL): 'SDCP' — extend the ontology if this is a real PK parameter (source ['T3:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=moxifloxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'population estimate or median' subgroup of Greenberg_2022 (paper reports 2 populations: population estimate or median, standard error of the population estimate)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end Moxifloxacin_Greenberg2022_population_estimate_or_median;
