model Teniposide_Sinkule1984_reference
  parameter Real Cl_ref = 3.838888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0079 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.656654,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About teniposide</h4><p>Teniposide is a podophyllotoxin derivative and topoisomerase II inhibitor used to treat childhood acute lymphocytic leukemia, Hodgkin's lymphoma, certain brain tumours, and lung oat cell carcinoma. It is given by intravenous injection. It is an approved chemotherapeutic medication used for cancer treatment.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417555\">Wikidata Q417555</a>, <a href=\"https://en.wikipedia.org/wiki/Teniposide?oldid=1329508020\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>teniposide</td></tr><tr><td>population:</td><td>children with acute lymphocytic leukemia</td></tr><tr><td>source_paper:</td><td>Sinkule_1984</td></tr><tr><td>measured_compound:</td><td>teniposide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>teniposide 656.654 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'dosage' — extend the ontology if this is a real PK parameter (source ['Sinkule_1984:abstract'])</li><li>unit_dimension_unknown: 'ml/min/sq m' (CL)</li><li>unit_dimension_unknown: 'liter/sq m' (Vss)</li><li>implicit units: 'Systemic clearance' → L/h (from the popPK convention: 'The paper text does not specify a unit. For population PK, systemic clearance is most commonly reported in L/h, which is')</li><li>implicit units: 'apparent volume of distribution of steady state' → L (from the popPK convention: 'The paper text does not specify a unit. For population PK, apparent volume of distribution is most commonly reported in ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=teniposide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Teniposide_Sinkule1984_reference;
