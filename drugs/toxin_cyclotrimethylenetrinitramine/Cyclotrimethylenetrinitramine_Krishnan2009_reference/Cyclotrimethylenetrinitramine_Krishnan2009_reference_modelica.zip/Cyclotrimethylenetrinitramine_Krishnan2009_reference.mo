// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cyclotrimethylenetrinitramine_Krishnan2009_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3327.106466687738},
    MM = 0.22211699999999998,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclotrimethylenetrinitramine</td></tr><tr><td>population:</td><td>male rats</td></tr><tr><td>source_paper:</td><td>Krishnan_2009</td></tr><tr><td>measured_compound:</td><td>Cyclotrimethylenetrinitramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cyclotrimethylenetrinitramine 222.117 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'logP' — extend the ontology if this is a real PK parameter (source ['Krishnan_2009:abstract'])</li><li>dropped unlinked row (NIL): 'brain' — extend the ontology if this is a real PK parameter (source ['Krishnan_2009:abstract'])</li><li>dropped unlinked row (NIL): 'muscle' — extend the ontology if this is a real PK parameter (source ['Krishnan_2009:abstract'])</li><li>dropped unlinked row (NIL): 'fat' — extend the ontology if this is a real PK parameter (source ['Krishnan_2009:abstract'])</li><li>dropped unlinked row (NIL): 'liver' — extend the ontology if this is a real PK parameter (source ['Krishnan_2009:abstract'])</li><li>unit_dimension_unknown: 'h(-1) kg(-1)' (CLfm)</li><li>implicit units: 'metabolic clearance of RDX' → L/h (from the popPK convention: 'For metabolic/formation clearance in population pharmacokinetics, the standard unit is volume per time. Given the magnit')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyclotrimethylenetrinitramine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Cyclotrimethylenetrinitramine_Krishnan2009_reference;
