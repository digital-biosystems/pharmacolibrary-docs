function p = Cefotaxime_Trang1985_noncompartmental_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefotaxime   source: Trang_1985 / noncompartmental   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Cefotaxime_Trang1985_noncompartmental_params';
  p.drug  = 'cefotaxime';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.27;                % central volume [L]
  p.CL = 20.23;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3500.0;             % dose [mg]
end
