function p = Cefotaxime_Branger2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefotaxime   source: Béranger_2018 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefotaxime_Branger2018_reference_params';
  p.drug  = 'cefotaxime';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.0;                % central volume [L]
  p.CL = 0.97;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4000.0;             % dose [mg]
end
