model Zolpidem_Tuk2002_PD_amplitude_in_the_11_5_30_hz_frequency_ba
  "sigmoid_emax exposure-response sweep — Tuk_2002 :: amplitude in the 11.5-30 Hz frequency band of the EEG (amplitude in the 11.5-30 Hz frequency band of the EEG)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 175,  // [microV/s]
    EC50 = 0.000512,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5200, Interval = 10.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zolpidem</h4><p>Zolpidem is a nonbenzodiazepine hypnotic used for the short-term treatment of insomnia and sleep disorders. It is administered orally via standard, extended-release, or sublingual tablets, which are well-absorbed by the body. The drug is widely used and is authorized for medical use in the United States, where it is a commonly prescribed medication.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q218842\">Wikidata Q218842</a>, <a href=\"https://en.wikipedia.org/wiki/Zolpidem?oldid=1384653142\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Zolpidem_Tuk2002_PD_amplitude_in_the_11_5_30_hz_frequency_ba</h4><p>The steady-state exposure-response curve of Tuk B et al., <i>Journal of pharmacokinetics and pharmacodynamics 29(3):235–250</i> 2002 (<a href=\"https://doi.org/10.1023/a:1020202806759\">doi:10.1023/a:1020202806759</a>) — amplitude in the 11.5-30 Hz frequency band of the EEG [microV/s] against zolpidem ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        175 microV/s maximal effect term (Emax, Q320)
  EC50  =        512 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of zolpidem per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (512 ng/ml)  response 87.5
  exposure -> infinity  response 175</pre></body></html>"));
end Zolpidem_Tuk2002_PD_amplitude_in_the_11_5_30_hz_frequency_ba;
