function p = Zolpidem_Tuk2002_PD_amplitude_in_the_11_5_30_hz_frequency_ba_params()
% Zolpidem_Tuk2002_PD_amplitude_in_the_11_5_30_hz_frequency_ba_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zolpidem Tuk_2002::amplitude_in_the_11_5_30_Hz_frequency_band_of_the_EEG: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response amplitude in the 11.5-30 Hz frequency band of the EEG in microV/s. Driver: zolpidem (cited_pk).
p.E0 = 0.0;
p.Emax = 175.0;
p.EC50 = 0.000512;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5200.0;
p.form = 'E0 + Emax*frac';
end
