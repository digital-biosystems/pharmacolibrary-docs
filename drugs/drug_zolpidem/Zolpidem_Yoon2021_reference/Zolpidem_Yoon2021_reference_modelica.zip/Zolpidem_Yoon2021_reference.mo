model Zolpidem_Yoon2021_reference
  parameter Real Cl_ref = 5.944444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0803 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3073895,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zolpidem</h4><p>Zolpidem is a nonbenzodiazepine hypnotic used for the short-term treatment of insomnia and sleep disorders. It is administered orally via standard, extended-release, or sublingual tablets, which are well-absorbed by the body. The drug is widely used and is authorized for medical use in the United States, where it is a commonly prescribed medication.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q218842\">Wikidata Q218842</a>, <a href=\"https://en.wikipedia.org/wiki/Zolpidem?oldid=1384653142\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zolpidem</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yoon_2021</td></tr><tr><td>measured_compound:</td><td>zolpidem</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>zolpidem 307.389 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yoon_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zolpidem_Yoon2021_reference;
