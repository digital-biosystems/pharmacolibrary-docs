model Zeranol_Qu2024_value
  parameter Real Cl_ref = 0.0018511111111111113 "Cl [m3/s]";
  parameter Real Vd_ref = 15.1319 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00014
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zeranol</td></tr><tr><td>population:</td><td>female Dezhou donkeys</td></tr><tr><td>source_paper:</td><td>Qu_2024</td></tr><tr><td>measured_compound:</td><td>Zearalenone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>toxins-16-00051-t004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zeranol 322.401 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Body weight (kg)' — extend the ontology if this is a real PK parameter (source ['Qu_2024_table_3:row0:col1'])</li><li>dropped unlinked row (NIL): 'ZEN (µg·kg·BW−1)' — extend the ontology if this is a real PK parameter (source ['Qu_2024_table_3:row1:col1'])</li><li>unit_dimension_unknown: 'L·kg·BW−1·h−1' (CL)</li><li>unit_dimension_unknown: 'L·kg·BW−1' (V)</li><li>implicit units: 'Cl (L·kg·BW−1·h−1)' → L/kg/h (from the paper text: 'L·kg·BW−1·h−1')</li><li>implicit units: 'Vd (L·kg·BW−1)' → L/kg (from the paper text: 'L/kg')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zearalenone</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'value' subgroup of Qu_2024 (paper reports 2 populations: mass value (mg), value)</li><li>molar mass: none of 1 PubChem candidate(s) is 'Zearalenone' (LLM) — left in mass units</li><li>molar mass: none found for 'Zearalenone' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Zearalenone', not zeranol — the review values are the parent's</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zeranol_Qu2024_value;
