function p = Zeranol_Qu2024_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zeranol   source: Qu_2024 / value   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Zeranol_Qu2024_value_params';
  p.drug  = 'zeranol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15131.9;                % central volume [L]
  p.CL = 6664.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
