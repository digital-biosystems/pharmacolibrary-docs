// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Fluoranthene_Ahrens2002_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {42293.72627145429},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluoranthene</td></tr><tr><td>population:</td><td>juvenile Macomona liliana (bivalvia, tellinacea) clams</td></tr><tr><td>source_paper:</td><td>Ahrens_2002</td></tr><tr><td>measured_compound:</td><td>(14)C-fluoranthene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>fluoranthene 202.256 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ng/clam' (body_burden)</li><li>unit_dimension_unknown: 'microg/g dry weight [dw]' (body_burden)</li><li>dropped duplicate Q414 ('critical body burden UV-exposed (or)', value 700) — already have one for this compound</li><li>unit_dimension_unknown: 'ng/clam' (body_burden)</li><li>dropped duplicate Q414 ('critical body burden UV-unexposed', value 21) — already have one for this compound</li><li>unit_dimension_unknown: 'microg/g dw' (body_burden)</li><li>dropped duplicate Q414 ('critical body burden UV-unexposed (or)', value 2300) — already have one for this compound</li><li>unit_dimension_unknown: 'Lg(-1) h(-1)' (kuptake)</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 7 column 4 (char 448)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=(14)C-fluoranthene</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for '(14)C-fluoranthene' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Fluoranthene_Ahrens2002_reference;
