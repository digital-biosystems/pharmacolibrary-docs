// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Phenanthrene_Choi2023_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7200.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenanthrene</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Choi_2023</td></tr><tr><td>measured_compound:</td><td>phenanthrene (and monohydroxy-phenanthrene metabolites)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>phenanthrene 178.234 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'Fue'</li><li>dropped value-less row: 'T1/2 (OH-PAHs)' (captured trailing unit 'OH-PAHs' for child rows)</li><li>dropped duplicate Q57 ('T1/2', value '7.2') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=phenanthrene (and monohydroxy-phenanthrene metabolites)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: biological half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/5 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'deuterium-labeled phenanthrene' — its concentrations stay mass-only</li><li>molar mass: none found for 'monohydroxy-phenanthrene (OH-Phe)' — its concentrations stay mass-only</li><li>molar mass: none found for 'monohydroxy-naphthalene (OH-Nap)' — its concentrations stay mass-only</li><li>molar mass: none found for 'monohydroxy-fluorene (OH-Flu)' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Phenanthrene_Choi2023_reference;
