// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Phenanthrene_Rossbach2020_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {23040.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenanthrene</td></tr><tr><td>population:</td><td>firefighting instructors during live fire training</td></tr><tr><td>source_paper:</td><td>Rossbach_2020</td></tr><tr><td>measured_compound:</td><td>mono-hydroxylated PAH metabolites (including hydroxyphenanthrenes)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>phenanthrene 178.234 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mono-hydroxylated PAH metabolites (including hydroxyphenanthrenes)</li><li>toxin: 4 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: half-lives printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/1 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'Naphthalene' — its concentrations stay mass-only</li><li>molar mass: none found for '1-hydroxynaphthalene' — its concentrations stay mass-only</li><li>molar mass: none found for '2-hydroxynaphthalene' — its concentrations stay mass-only</li><li>molar mass: none found for 'hydroxyfluorenes' — its concentrations stay mass-only</li><li>molar mass: none found for 'mono-hydroxyphenanthrenes' — its concentrations stay mass-only</li><li>molar mass: none found for '1-hydroxypyrene' — its concentrations stay mass-only</li><li>molar mass: none found for 'mono-hydroxylated PAH metabolites (including hydroxyphenanthrenes)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 230.4));
end Phenanthrene_Rossbach2020_reference;
