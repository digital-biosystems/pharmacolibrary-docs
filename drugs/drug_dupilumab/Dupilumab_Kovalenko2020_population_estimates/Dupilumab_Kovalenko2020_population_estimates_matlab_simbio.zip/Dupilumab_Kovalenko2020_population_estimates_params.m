function p = Dupilumab_Kovalenko2020_population_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dupilumab   source: Kovalenko_2020 / population_estimates   route: oral
  % estimated (absent from source): F
  p.name  = 'Dupilumab_Kovalenko2020_population_estimates_params';
  p.drug  = 'dupilumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.74;                % central volume [L]
  p.CL = 0.005417;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.022833;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
