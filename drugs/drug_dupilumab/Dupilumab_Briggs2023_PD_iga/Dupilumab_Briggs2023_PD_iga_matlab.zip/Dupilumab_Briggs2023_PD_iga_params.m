function p = Dupilumab_Briggs2023_PD_iga_params()
% Dupilumab_Briggs2023_PD_iga_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dupilumab Briggs_2023::IGA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response IGA in its own unit. Driver: dupilumab (cited_pk).
p.E0 = -3.35;
p.Emax = 1.0;
p.EC50 = 0.027099999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 280.0;
p.form = 'E0*(1 - Emax*frac)';
end
