// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SodiumBromate_Bull2012_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {600.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_bromate</td></tr><tr><td>population:</td><td>female F344 rats</td></tr><tr><td>source_paper:</td><td>Bull_2012</td></tr><tr><td>measured_compound:</td><td>Bromate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Bromide 79.904 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'IV dose' — extend the ontology if this is a real PK parameter (source ['Bull_2012:abstract'])</li><li>dropped unlinked row (NIL): 'IV doses' — extend the ontology if this is a real PK parameter (source ['Bull_2012:abstract', 'Bull_2012:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Bromate</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role</li><li>molar mass: no plausible PubChem entry for 'Bromate' ('Bromate') — left in mass units</li><li>molar mass: none found for 'Bromate' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end SodiumBromate_Bull2012_reference;
