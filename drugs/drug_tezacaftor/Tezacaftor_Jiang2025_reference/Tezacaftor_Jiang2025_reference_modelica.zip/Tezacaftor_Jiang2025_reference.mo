model Tezacaftor_Jiang2025_reference
  parameter Real Cl_ref = 6e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.520505,
    adminMass = 0.0001,
    ka = 0.00036111111111111115,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tezacaftor</h4><p>Tezacaftor is a CFTR corrector used, in combination with other cystic fibrosis drugs, to treat cystic fibrosis. It is an approved medicine used in combination therapy for eligible patients with cystic fibrosis, mainly in the United States and Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27270940\">Wikidata Q27270940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tezacaftor</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jiang_2025</td></tr><tr><td>measured_compound:</td><td>tezacaftor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tezacaftor 520.505 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jiang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Tezacaftor_Jiang2025_reference;
