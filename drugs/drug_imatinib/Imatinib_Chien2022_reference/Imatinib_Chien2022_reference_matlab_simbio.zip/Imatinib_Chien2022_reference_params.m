function p = Imatinib_Chien2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imatinib   source: Chien_2022 / reference   route: oral
  p.name  = 'Imatinib_Chien2022_reference_params';
  p.drug  = 'imatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 172.0;                % central volume [L]
  p.CL = 13.2;                % clearance [L/h]
  p.Vp = [43.6];             % peripheral volumes [L]
  p.Q  = [3.75];             % inter-compartmental clearances [L/h]
  p.ka = 1.22;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
