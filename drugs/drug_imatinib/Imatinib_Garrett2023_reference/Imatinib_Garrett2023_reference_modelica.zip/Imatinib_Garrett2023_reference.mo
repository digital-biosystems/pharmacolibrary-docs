model Imatinib_Garrett2023_reference
  parameter Real Cl_ref = 1.5638888888888888e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.3257 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4936027,
    adminMass = 0.0004,
    ka = 9.944444444444444e-05,
    Tlag = 1591.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About imatinib</h4><p>Imatinib is a protein kinase inhibitor used to treat cancers like chronic myelogenous leukemia, gastrointestinal stromal tumors, and dermatofibrosarcoma protuberans. It is given by mouth in tablet or capsule forms, and it is well absorbed from the digestive tract. Blood levels are measured in selected patients to help determine the correct dose. It is a widely used medicine authorized in the European Union and listed on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q177094\">Wikidata Q177094</a>, <a href=\"https://en.wikipedia.org/wiki/Imatinib?oldid=1369854920\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification, the EMA medicines list and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>imatinib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Garrett_2023</td></tr><tr><td>measured_compound:</td><td>imatinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>imatinib 493.603 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Garrett_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Imatinib_Garrett2023_reference;
