model Amsacrine_Paxton1986_reference
  parameter Real Cl_ref = 0.0009061111111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 8.469999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.393461,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amsacrine</td></tr><tr><td>population:</td><td>rabbits (balanced crossover, six rabbits)</td></tr><tr><td>source_paper:</td><td>Paxton_1986</td></tr><tr><td>measured_compound:</td><td>Amsacrine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>amsacrine 393.461 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q76 ('apparent volume of distribution (unbound amsacrine)', value 45) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance (unbound amsacrine)', value 16.3) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Amsacrine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amsacrine_Paxton1986_reference;
