model Naltrexone_Shenkoya2024_third_trimester_fetal
  parameter Real Cl_ref = 4.584999999999999e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10206 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34140699999999996,
    adminMass = 5e-05,
    ka = 0.008066666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naltrexone</td></tr><tr><td>population:</td><td>pregnant adult women with opioid use disorder (PBPK simulated virtual females)</td></tr><tr><td>source_paper:</td><td>Shenkoya_2024</td></tr><tr><td>measured_compound:</td><td>Naltrexone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413252-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>naltrexone 341.407 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q19 ('AUC0-7d (ng·d/mL)', value '8.85') — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0-28d (ng·d/mL)', value '21.4') — already have one for this compound</li><li>dropped duplicate Q32 ('380 mg Cmax (ng/mL)', value '49.9') — already have one for this compound</li><li>dropped duplicate Q19 ('380 mg AUC0-1d (ng.d/mL)', value '4.34') — already have one for this compound</li><li>dropped duplicate Q19 ('380 mg AUC0-7d (ng.d/mL)', value '138') — already have one for this compound</li><li>dropped duplicate Q19 ('380 mg AUC0-38d (ng.d/mL)', value '332') — already have one for this compound</li><li>dropped duplicate Q17 ('380 mg AUC0-inf (ng.d/mL)', value '347') — already have one for this compound</li><li>dropped duplicate Q32 ('285 mg Cmax (ng/mL)', value '40.5') — already have one for this compound</li><li>dropped unlinked row (NIL): '285 mg C2nd (ng/mL)' — extend the ontology if this is a real PK parameter (source ['Shenkoya_2024_table_2:row7:col12'])</li><li>dropped duplicate Q19 ('285 mg AUC0-1d (ng.d/mL)', value '3.6') — already have one for this compound</li><li>dropped duplicate Q19 ('285 mg AUC0-7d (ng.d/mL)', value '114') — already have one for this compound</li><li>dropped duplicate Q19 ('285 mg AUC0-38d (ng.d/mL)', value '273') — already have one for this compound</li><li>dropped duplicate Q17 ('285 mg AUC0-inf (ng.d/mL)', value '288') — already have one for this compound</li><li>dropped duplicate Q32 ('190 mg Cmax (ng/mL)', value '27.0') — already have one for this compound</li><li>dropped unlinked row (NIL): '190 mg C2nd (ng/mL)' — extend the ontology if this is a real PK parameter (source ['Shenkoya_2024_table_2:row13:col12'])</li><li>dropped duplicate Q19 ('190 mg AUC0-1d (ng.d/mL)', value '2.38') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Naltrexone_Shenkoya2024_third_trimester_fetal;
