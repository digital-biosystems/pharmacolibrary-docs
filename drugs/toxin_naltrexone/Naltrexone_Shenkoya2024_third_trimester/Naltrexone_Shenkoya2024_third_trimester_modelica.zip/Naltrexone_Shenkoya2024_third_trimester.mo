model Naltrexone_Shenkoya2024_third_trimester
  parameter Real Cl_ref = 4.584999999999999e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10206 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34140699999999996,
    adminMass = 5e-05,
    ka = 0.008066666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naltrexone</td></tr><tr><td>population:</td><td>pregnant adult women with opioid use disorder (PBPK simulated virtual females)</td></tr><tr><td>source_paper:</td><td>Shenkoya_2024</td></tr><tr><td>measured_compound:</td><td>Naltrexone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413252-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>naltrexone 341.407 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q19 ('AUC0-28d (ng⋅d/ml)', value '262') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Naltrexone</li><li>population split: 'third trimester' subgroup of Shenkoya_2024 (paper reports 11 populations: final model value, first trimester, first trimester fetal, first trimester maternal, pre-conception, second trimester, second trimester fetal, second trimester maternal, third trimester, third trimester fetal, third trimester maternal)</li><li>gap-filled Q22 (CL) from Christie_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Christie_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Christie_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Christie_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Naltrexone_Shenkoya2024_third_trimester;
