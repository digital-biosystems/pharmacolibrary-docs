function p = Naltrexone_Shenkoya2024_third_trimester_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: naltrexone   source: Shenkoya_2024 / third_trimester   route: oral
  % estimated (absent from source): F
  p.name  = 'Naltrexone_Shenkoya2024_third_trimester_params';
  p.drug  = 'naltrexone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.06;                % central volume [L]
  p.CL = 165.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 29.04;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
