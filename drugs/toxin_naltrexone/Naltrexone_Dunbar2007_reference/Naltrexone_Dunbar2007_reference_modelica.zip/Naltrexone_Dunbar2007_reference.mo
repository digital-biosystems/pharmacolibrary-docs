model Naltrexone_Dunbar2007_reference
  parameter Real Cl_ref = 3.888888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 38.300000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34140699999999996,
    adminMass = 5e-05,
    ka = 0.008066666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naltrexone</td></tr><tr><td>population:</td><td>patients with alcohol dependence (and healthy subjects)</td></tr><tr><td>source_paper:</td><td>Dunbar_2007</td></tr><tr><td>measured_compound:</td><td>naltrexone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Naltrexone 341.407 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('change in V with weight', value 0.655) — already have one for this compound</li><li>dropped duplicate Q22 ('higher CL in subjects with alcohol and/or opioid dependence', value 23) — already have one for this compound</li><li>dropped duplicate Q61 ('higher V in subjects with alcohol and/or opioid dependence', value 35) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=naltrexone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 0/6 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for '6-beta-naltrexol' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Christie_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Naltrexone_Dunbar2007_reference;
