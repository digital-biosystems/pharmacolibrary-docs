function p = Naltrexone_Dunbar2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: naltrexone   source: Dunbar_2007 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Naltrexone_Dunbar2007_reference_params';
  p.drug  = 'naltrexone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38300.0;                % central volume [L]
  p.CL = 140.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 29.04;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
