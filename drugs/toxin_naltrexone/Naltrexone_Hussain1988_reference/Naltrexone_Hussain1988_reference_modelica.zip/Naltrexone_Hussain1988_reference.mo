// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Naltrexone_Hussain1988_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1800.0},
    MM = 0.34140699999999996,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naltrexone</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Hussain_1988</td></tr><tr><td>measured_compound:</td><td>Naltrexone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>naltrexone 341.407 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'The plasma (dog and human) hydrolysis half-life of 3' Q51 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('t1/2', value 30) — already have one for this compound</li><li>dropped duplicate Q57 ('The half-life of naltrexone in dogs after oral administration of 3', value 1) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Naltrexone</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Christie_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Christie_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Christie_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Naltrexone_Hussain1988_reference;
