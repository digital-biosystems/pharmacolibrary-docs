model Naltrexone_Christie2025_reference
  parameter Real Cl_ref = 4.584999999999999e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006293 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34140699999999996,
    adminMass = 5e-05,
    ka = 0.008066666666666666,
    Tlag = 0.0,
    k12 = 0.008268446421950315,
    k21 = 0.001264172335600907
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naltrexone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Christie_2025</td></tr><tr><td>measured_compound:</td><td>naltrexone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>naltrexone 341.407 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Christie_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Naltrexone_Christie2025_reference;
