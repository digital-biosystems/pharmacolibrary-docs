function p = Ropivacaine_Mahmoud2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ropivacaine   source: Mahmoud_2020 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Ropivacaine_Mahmoud2020_reference_params';
  p.drug  = 'ropivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 105.0;                % central volume [L]
  p.CL = 60.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
