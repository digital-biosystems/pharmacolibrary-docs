model Chloroquine_Chotsiri2022_chloroquine_pharmacokinetics_typica
  parameter Real Cl_ref = 5.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0114 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.319877,
    adminMass = 0.0005,
    ka = 9.722222222222222e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroquine</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Chotsiri_2022</td></tr><tr><td>measured_compound:</td><td>Chloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt2665-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>chloroquine 319.877 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ' routed out of structural estimates ('Unexplained residual error')</li><li>table representations disagree for 'F (%)'; source reconciliation required</li><li>table representations disagree for 'Ka1 (hr−1)'; source reconciliation required</li><li>table representations disagree for 'Ka2 (hr−1)'; source reconciliation required</li><li>table representations disagree for 'CL/F (L∙hr−1)'; source reconciliation required</li><li>table representations disagree for 'Q1/F (L∙hr−1)'; source reconciliation required</li><li>table representations disagree for 'OCC on Q1/F'; source reconciliation required</li><li>table representations disagree for 'CL/F (L∙hr−1)'; source reconciliation required</li><li>table representations disagree for 'VC/F (L)'; source reconciliation required</li><li>conflicting source units for 'VC/F (L)': [{'unit': 'L', 'source': 'cpt2665-tbl-0001:row17:col0', 'scope': 'label'}, {'unit': '%', 'source': 'cpt2665-tbl-0001:row17:col1', 'scope': 'inline'}]</li><li>dropped duplicate Q49 ('Ka2 (hr−1)', value '0.169') — already have one for this compound</li><li>routed 'OCC on Q1/F' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 80.8 (source ['cpt2665-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Chloroquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Chloroquine_Chotsiri2022_chloroquine_pharmacokinetics_typica;
