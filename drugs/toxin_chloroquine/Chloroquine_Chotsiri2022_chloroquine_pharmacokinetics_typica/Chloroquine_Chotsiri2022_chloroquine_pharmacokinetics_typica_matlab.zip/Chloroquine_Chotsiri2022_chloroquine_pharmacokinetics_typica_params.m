function p = Chloroquine_Chotsiri2022_chloroquine_pharmacokinetics_typica_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloroquine   source: Chotsiri_2022 / chloroquine_pharmacokinetics_typical_valuea_rseb   route: oral
  p.name  = 'Chloroquine_Chotsiri2022_chloroquine_pharmacokinetics_typica_params';
  p.drug  = 'chloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.4;                % central volume [L]
  p.CL = 18.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.35;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
