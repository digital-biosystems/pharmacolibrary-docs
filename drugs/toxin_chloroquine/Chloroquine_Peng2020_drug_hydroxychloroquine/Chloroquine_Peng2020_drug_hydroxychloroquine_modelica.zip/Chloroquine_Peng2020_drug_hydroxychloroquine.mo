model Chloroquine_Peng2020_drug_hydroxychloroquine
  parameter Real Cl_ref = 1.3111111111111113e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.933 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 74.6,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.319877,
    adminMass = 0.0005,
    ka = 0.0002619444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroquine</td></tr><tr><td>population:</td><td>COVID-19 patients (humans)</td></tr><tr><td>source_paper:</td><td>Peng_2020</td></tr><tr><td>measured_compound:</td><td>Chloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>chloroquine 319.877 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chloroquine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'drug / hydroxychloroquine' subgroup of Peng_2020 (paper reports 2 populations: drug / dihydroartemisinin, drug / hydroxychloroquine)</li><li>gap-filled Q22 (CL) from Abd-Rahman_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Abd-Rahman_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Abd-Rahman_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Maiga_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Abd-Rahman_2020, Maiga_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Chloroquine_Peng2020_drug_hydroxychloroquine;
