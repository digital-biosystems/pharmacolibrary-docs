function p = Chloroquine_Peng2020_drug_hydroxychloroquine_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloroquine   source: Peng_2020 / drug_hydroxychloroquine   route: oral
  p.name  = 'Chloroquine_Peng2020_drug_hydroxychloroquine_params';
  p.drug  = 'chloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2933.0;                % central volume [L]
  p.CL = 47.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.943;                % absorption rate [1/h]
  p.F  = 0.746;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
