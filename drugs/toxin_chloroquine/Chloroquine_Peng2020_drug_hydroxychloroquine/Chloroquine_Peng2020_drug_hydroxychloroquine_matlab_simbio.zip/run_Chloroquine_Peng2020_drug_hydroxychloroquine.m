% Run (SimBiology): build model + dose, simulate 0..240.0 h, plot.
p = Chloroquine_Peng2020_drug_hydroxychloroquine_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 240.0);
