// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Chloroquine_Liu2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {86400.0},
    MM = 0.319877,
    adminMass = 0.0005,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroquine</td></tr><tr><td>population:</td><td>rats and humans</td></tr><tr><td>source_paper:</td><td>Liu_2021</td></tr><tr><td>measured_compound:</td><td>Chloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>chloroquine 319.877 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'oral-dose PK'</li><li>dropped duplicate Q57 ('half-life in humans', value 50) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chloroquine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Abd-Rahman_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Abd-Rahman_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Abd-Rahman_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Maiga_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q65 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end Chloroquine_Liu2021_reference;
