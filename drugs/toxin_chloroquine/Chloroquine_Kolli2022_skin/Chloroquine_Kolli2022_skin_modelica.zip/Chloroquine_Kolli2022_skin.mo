// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Chloroquine_Kolli2022_skin
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {271440.0},
    MM = 0.319877,
    adminMass = 0.0005,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroquine</td></tr><tr><td>population:</td><td>humans, rats, and mice (PBPK models qualified to rat, mouse, and human PK data)</td></tr><tr><td>source_paper:</td><td>Kolli_2022</td></tr><tr><td>measured_compound:</td><td>chloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>chloroquine 319.877 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Tissue[31]' — extend the ontology if this is a real PK parameter (source ['Kolli_2022_table_3:row4:col2'])</li><li>dropped unlinked row (NIL): 'Tissue volume (%V)' — extend the ontology if this is a real PK parameter (source ['Kolli_2022_table_3:row4:col3', 'Kolli_2022_table_3:row4:col6', 'Kolli_2022_table_3:row4:col9'])</li><li>unit_dimension_unknown: '%Q' (Qb)</li><li>dropped duplicate Q410 ('Partition coeficient (K_Tp,)[32]', value '0.1') — already have one for this compound</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>dropped value-less row: 'd'</li><li>salvaged Q57 ('terminal elimination half-life (CQ plasma)'=75.4) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=chloroquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'skin' subgroup of Kolli_2022 (paper reports 14 populations: arterial, brain, gi, heart, human (70 kg), kidney, liver, mouse (22 g), muscle, rat (250 g), remaining, skin, spleen, venous)</li><li>gap-filled Q22 (CL) from Abd-Rahman_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 2764.8));
end Chloroquine_Kolli2022_skin;
