model Linezolid_VeraYunca2025_PD_b
  "sigmoid_emax exposure-response sweep — Vera-Yunca_2025 :: B (Bacterial load (in vitro))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000547222222222,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.00056,  // [kg/m3; mg/L × 0.001]
    gamma = 2.19,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 5.6, Interval = 0.0112),
    Documentation(info = "<html><body><h4>Linezolid_VeraYunca2025_PD_b</h4><p>The steady-state exposure-response curve of Vera-Yunca D et al., <i>The Journal of antimicrobial chemotherapy 80(7):1860-1868</i> 2025 (<a href=\"https://doi.org/10.1093/jac/dkaf140\">doi:10.1093/jac/dkaf140</a>) — Bacterial load (in vitro) [log10 cfu/mL] against linezolid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.97 h-1      maximal effect term (Maximum LZD-mediated killing rate constant, Q323)
  EC50  =       0.56 mg/L     exposure at half of the maximal effect term (LZD concentration needed to reach 50% of Emax,LZD, Q321)
  gamma =       2.19          Hill coefficient (Hill coefficient (steepness of the concentration–LZD effect curve), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of linezolid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.56 mg/L)  response -0.0002736
  exposure -> infinity  response -0.0005472</pre></body></html>"));
end Linezolid_VeraYunca2025_PD_b;
