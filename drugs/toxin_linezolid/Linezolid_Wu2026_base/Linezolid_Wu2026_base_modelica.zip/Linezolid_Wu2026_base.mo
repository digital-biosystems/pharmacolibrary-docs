model Linezolid_Wu2026_base
  parameter Real Cl_ref = 1.933333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0309 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.0006,
    ka = 0.0003388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>critically ill adult patients</td></tr><tr><td>source_paper:</td><td>Wu_2026</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωV' routed out of structural estimates ('Between-subject variability (%CV)')</li><li>table section iiv: 'ωCL' routed out of structural estimates ('Between-subject variability (%CV)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Linezolid</li><li>model-stage split: 'base model / parameter estimates (%cv)' is the base model of Wu_2026 (paper reports 2 stages: base model / parameter estimates (%cv), final model / parameter estimates (%cv)); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bandín-Vilar_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Wu2026_base;
