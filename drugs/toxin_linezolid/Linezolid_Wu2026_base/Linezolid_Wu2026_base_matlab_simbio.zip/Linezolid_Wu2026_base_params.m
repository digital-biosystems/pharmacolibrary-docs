function p = Linezolid_Wu2026_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linezolid   source: Wu_2026 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'Linezolid_Wu2026_base_params';
  p.drug  = 'linezolid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 30.9;                % central volume [L]
  p.CL = 6.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.22;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
