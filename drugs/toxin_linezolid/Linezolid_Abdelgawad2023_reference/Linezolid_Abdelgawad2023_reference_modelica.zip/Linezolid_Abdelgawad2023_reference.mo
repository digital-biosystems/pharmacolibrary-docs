model Linezolid_Abdelgawad2023_reference
  parameter Real Cl_ref = 2.013888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.040799999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.0006,
    ka = 0.0003361111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>adults with HIV-associated tuberculous meningitis</td></tr><tr><td>source_paper:</td><td>Abdelgawad_2023</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (95% confidence interval) a' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Abdelgawad2023_reference;
