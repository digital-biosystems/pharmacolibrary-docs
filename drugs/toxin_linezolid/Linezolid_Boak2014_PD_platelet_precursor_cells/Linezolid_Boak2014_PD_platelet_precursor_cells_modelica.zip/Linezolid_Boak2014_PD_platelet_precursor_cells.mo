model Linezolid_Boak2014_PD_platelet_precursor_cells
  "indirect_response_i exposure-response sweep — Boak_2014 :: platelet precursor cells (platelet precursor cells)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00806,  // [kg/m3; mg/liter × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/liter per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 81, Interval = 0.162),
    Documentation(info = "<html><body><h4>Linezolid_Boak2014_PD_platelet_precursor_cells</h4><p>The steady-state exposure-response curve of Boak LM et al., <i>Antimicrobial agents and chemotherapy 58(4):2334–2343</i> 2014 (<a href=\"https://doi.org/10.1128/AAC.01885-13\">doi:10.1128/AAC.01885-13</a>) — platelet precursor cells against linezolid mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       8.06 mg/liter exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/liter of linezolid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (8.06 mg/liter)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Linezolid_Boak2014_PD_platelet_precursor_cells;
