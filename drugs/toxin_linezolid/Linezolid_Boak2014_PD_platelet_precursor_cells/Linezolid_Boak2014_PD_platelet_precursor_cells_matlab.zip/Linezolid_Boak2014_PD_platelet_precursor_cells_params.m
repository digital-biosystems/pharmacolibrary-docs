function p = Linezolid_Boak2014_PD_platelet_precursor_cells_params()
% Linezolid_Boak2014_PD_platelet_precursor_cells_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% linezolid Boak_2014::platelet_precursor_cells: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response platelet precursor cells in its own unit. Driver: linezolid (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.00806;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 81.0;
p.form = 'E0*(1 - Emax*frac)';
end
