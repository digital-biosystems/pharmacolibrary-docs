function p = Linezolid_Strydom2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linezolid   source: Strydom_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Linezolid_Strydom2024_reference_params';
  p.drug  = 'linezolid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 32.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.22;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2400.0;             % dose [mg]
end
