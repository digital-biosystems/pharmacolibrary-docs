function p = Linezolid_Liu2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linezolid   source: Liu_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Linezolid_Liu2026_reference_params';
  p.drug  = 'linezolid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.8;                % central volume [L]
  p.CL = 4.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.22;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
