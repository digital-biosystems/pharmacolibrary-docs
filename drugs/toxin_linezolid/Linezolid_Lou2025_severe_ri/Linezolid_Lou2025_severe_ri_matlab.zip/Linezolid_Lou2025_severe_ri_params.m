function p = Linezolid_Lou2025_severe_ri_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linezolid   source: Lou_2025 / severe_ri   route: oral
  % estimated (absent from source): F
  p.name  = 'Linezolid_Lou2025_severe_ri_params';
  p.drug  = 'linezolid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 8.76;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.22;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
