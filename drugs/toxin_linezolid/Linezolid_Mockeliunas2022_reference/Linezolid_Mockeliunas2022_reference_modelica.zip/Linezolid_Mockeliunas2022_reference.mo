model Linezolid_Mockeliunas2022_reference
  parameter Real Cl_ref = 1.75e-06 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real Vd_ref = 0.0506 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.95)*cov_sex_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.00015,
    ka = 0.0005,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>patients with multidrug- and extensively drug-resistant tuberculosis</td></tr><tr><td>source_paper:</td><td>Mockeliunas_2022</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00753-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIVCL/F (%CV) a' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIVMTT (%CV) a' routed out of structural estimates ('Inter-individual variability')</li><li>table section iov: 'IOVCL/F (%CV) b' routed out of structural estimates ('Inter-occasion variability')</li><li>table section iov: 'IOVV/F (%CV) b' routed out of structural estimates ('Inter-occasion variability')</li><li>table section iov: 'IOVka (%CV) b' routed out of structural estimates ('Inter-occasion variability')</li><li>table section iov: 'IOVMTT (%CV) b' routed out of structural estimates ('Inter-occasion variability')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error (mg/L)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'RCLF' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00753-t002:row7:col2'])</li><li>dropped duplicate Q27 ('HIV co-infection on CL/F', value '0.43') — already have one for this compound</li><li>covariate level 'Sex on ka' → Q900:sex_on_ka = 0.95 (linear_fractional on Q27)</li><li>dropped duplicate Q81 ('P-gp inhibitor on MTT', value '0.96') — already have one for this compound</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>dropped value-less row: 'd'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Linezolid_Mockeliunas2022_reference;
