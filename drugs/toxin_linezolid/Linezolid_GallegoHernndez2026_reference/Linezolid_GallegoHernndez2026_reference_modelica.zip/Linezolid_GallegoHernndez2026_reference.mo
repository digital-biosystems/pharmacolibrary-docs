model Linezolid_GallegoHernndez2026_reference
  parameter Real Cl_ref = 1.1805555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0256 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.0006,
    ka = 0.0003388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>elderly hospitalized patients (65–87 years)</td></tr><tr><td>source_paper:</td><td>Gallego-Hernández_2026</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00528-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'eGFR-CL' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-18-00528-t002:row3:col1'])</li><li>dropped 'DAY-CL' → Q22 = -0.18: a clearance of -0.18 is not a parameter value (source ['pharmaceutics-18-00528-t002:row4:col1'])</li><li>dropped PD-category row 'AGE-CL' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pharmaceutics-18-00528-t002:row5:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Linezolid</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bandín-Vilar_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_GallegoHernndez2026_reference;
