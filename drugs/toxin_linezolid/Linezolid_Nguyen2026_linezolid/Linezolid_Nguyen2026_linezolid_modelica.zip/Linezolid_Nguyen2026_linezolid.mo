// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Linezolid_Nguyen2026_linezolid
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.045},
    CLelim = {0.00245},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>virtual population (human)</td></tr><tr><td>source_paper:</td><td>Nguyen_2026</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70443-tbl-0001</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('protein‐normalized intrinsic efflux clearances (CL int ) for ABCB1'=2.1) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Linezolid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>population split: 'linezolid' subgroup of Nguyen_2026 (paper reports 8 populations: linezolid, linezolid + rifampin 10 mg/kg, linezolid + rifampin 20 mg/kg, linezolid + rifampin 25 mg/kg, linezolid + rifampin 30 mg/kg, linezolid + rifampin 35 mg/kg, linezolid + rifampin 40 mg/kg, value)</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bandín-Vilar_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Bandín-Vilar_2022, Calderin_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Nguyen2026_linezolid;
