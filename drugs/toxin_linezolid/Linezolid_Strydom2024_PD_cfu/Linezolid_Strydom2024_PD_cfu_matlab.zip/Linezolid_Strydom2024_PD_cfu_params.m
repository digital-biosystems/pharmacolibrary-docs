function p = Linezolid_Strydom2024_PD_cfu_params()
% Linezolid_Strydom2024_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% linezolid Strydom_2024::CFU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response CFU in log10 CFU. Driver: linezolid (pk_record).
p.E0 = 0.0;
p.Emax = -1.15625e-05;
p.EC50 = 0.0028699999999999997;
p.gamma = 0.215;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 29.0;
p.form = 'E0 + Emax*frac';
end
