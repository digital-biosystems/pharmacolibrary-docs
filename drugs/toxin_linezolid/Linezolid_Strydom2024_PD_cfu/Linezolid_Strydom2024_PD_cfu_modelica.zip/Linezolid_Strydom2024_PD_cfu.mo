model Linezolid_Strydom2024_PD_cfu
  "sigmoid_emax exposure-response sweep — Strydom_2024 :: CFU (CFU)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.15625e-05,  // [1/s; day⁻¹ × 1.15741e-05]
    EC50 = 0.00287,  // [kg/m3; mg/L × 0.001]
    gamma = 0.215,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 29, Interval = 0.058),
    Documentation(info = "<html><body><h4>Linezolid_Strydom2024_PD_cfu</h4><p>The steady-state exposure-response curve of Strydom N et al., <i>Nature communications 15(1):7311</i> 2024 (<a href=\"https://doi.org/10.1038/s41467-024-50781-4\">doi:10.1038/s41467-024-50781-4</a>) — CFU [log10 CFU] against linezolid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.999 day⁻¹    maximal effect term (Emax (Mono-therapy), Q323)
  EC50  =       2.87 mg/L     exposure at half of the maximal effect term (EC50 (Mono-therapy), Q321)
  gamma =      0.215          Hill coefficient (Gamma (Mono-therapy), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of linezolid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.87 mg/L)  response -5.781e-06
  exposure -> infinity  response -1.156e-05</pre></body></html>"));
end Linezolid_Strydom2024_PD_cfu;
