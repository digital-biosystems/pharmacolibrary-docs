model Linezolid_Fang2021_reference
  parameter Real Cl_ref = 8.527777777777777e-07 "Cl [m3/s]";
  parameter Real cov_crcl_0 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (2.37)*cov_crcl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.0012,
    ka = 0.00024166666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>Hospitalized adult patients</td></tr><tr><td>source_paper:</td><td>Fang_2021</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV_CL [%CV]' routed out of structural estimates ('Between-subject variability (BSV)')</li><li>table section iiv: 'BSV_V [%CV]' routed out of structural estimates ('Between-subject variability (BSV)')</li><li>table section residual_error: 'Proportional error [%CV]' routed out of structural estimates ('Residual variability (RV)')</li><li>dropped duplicate Q22 ('WBC on CL', value '0.559') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ALB on V' — extend the ontology if this is a real PK parameter (source ['T3:row8:col1'])</li><li>dropped value-less row: 'TVKA'</li><li>dropped value-less row: 'TVCL'</li><li>dropped value-less row: 'TVV'</li><li>dropped value-less row: 'CrCL'</li><li>dropped value-less row: 'WBC'</li><li>dropped value-less row: 'ALB'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Linezolid</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Linezolid_Fang2021_reference;
