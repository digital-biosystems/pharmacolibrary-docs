model Linezolid_Lou2025_paediatric_patients
  parameter Real Cl_ref = 2.4333333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.0012,
    ka = 0.0003388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>Pediatric patients with renal impairment; Healthy adults; Pediatric patients</td></tr><tr><td>source_paper:</td><td>Lou_2025</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Age' — extend the ontology if this is a real PK parameter (source ['Lou_2025_table_2:row1:col2'])</li><li>dropped duplicate Q19 ('AUC0-t (μg∙h/mL) / Predicted', value '77.691') — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0-t (μg∙h/mL) / FE', value '1.031') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (μg/mL) / Predicted', value '18.146') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (μg/mL) / FE', value '1.288') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (μg/mL) / GMFE', value '1.293') — already have one for this compound</li><li>salvaged Q22 ('mean total clearance following intravenous administration'=8.76) from results prose — parameter table was unreadable</li><li>implicit units: 'AUC0-t (μg∙h/mL) / Observed' → μg∙h/mL (from the paper text: &quot;Table 2 column header 'AUC0-t (μg∙h/mL)'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Linezolid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'paediatric patients' subgroup of Lou_2025 (paper reports 13 populations: 0.25–1yrs(n=10), 1-2 yrs(n=12), 3-6 yrs(n=14), 7-12 yrs(n=15), end-stage ri(n=6), healthy adult, i.v. 500mg (n=16), i.v.500mg bid (n=6), i.v.625mg bid (n=6), moderate ri(n=6), p.o.600mg (n=16), paediatric patients, severe ri(n=6))</li><li>gap-filled Q61 (V) from Calderin_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bandín-Vilar_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Lou2025_paediatric_patients;
