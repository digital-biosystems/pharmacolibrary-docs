function p = Linezolid_Ngara2025_PD_cfu_params()
% Linezolid_Ngara2025_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% linezolid Ngara_2025::CFU: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mgL-1 per second, in SI inside (kg/m3, s). Response CFU in log10 CFU lung-1. Driver: linezolid (cited_pk).
p.E0 = 1.4699074074074073e-05;
p.Emax = -1.1574074074074073e-05;
p.EC50 = 2.77;
p.gamma = 0.21;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 28.0;
p.form = 'E0 + Emax*frac';
end
