model Linezolid_Ngara2025_PD_cfu
  "emax exposure-response sweep — Ngara_2025 :: CFU (colony-forming units)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.46990740741e-05,      // [1/s; day−1 × 1.15741e-05]
    Emax = -1.15740740741e-05,  // [1/s; d-1 × 1.15741e-05]
    EC50 = 2.77,  // [mgL-1]
    gamma = 0.21,
    exposure_per_s = 1);   // 1 mgL-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mgL-1' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 28, Interval = 0.056),
    Documentation(info = "<html><body><h4>Linezolid_Ngara2025_PD_cfu</h4><p>The steady-state exposure-response curve of Ngara B et al., <i>The Journal of infectious diseases 231(5):e901-e911</i> 2025 (<a href=\"https://doi.org/10.1093/infdis/jiaf088\">doi:10.1093/infdis/jiaf088</a>) — colony-forming units [log10 CFU lung-1] against linezolid mgL-1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.27 day−1    drug-free response (baseline) (baseline empirical adjusted estimates of the bacterial growth parameters, Q324)
  Emax  =          1 d-1      maximal effect term (Emax, Q323)
  EC50  =       2.77 mgL-1    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.21          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mgL-1 of linezolid per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.47e-05   (drug-free)
  exposure = EC50 (2.77 mgL-1)  response 8.912e-06
  exposure -> infinity  response 3.125e-06</pre></body></html>"));
end Linezolid_Ngara2025_PD_cfu;
