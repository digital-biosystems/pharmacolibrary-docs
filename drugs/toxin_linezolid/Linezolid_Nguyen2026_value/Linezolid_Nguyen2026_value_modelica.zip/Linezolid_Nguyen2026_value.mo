// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Linezolid_Nguyen2026_value
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.045},
    CLelim = {0.00245},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>virtual population (human)</td></tr><tr><td>source_paper:</td><td>Nguyen_2026</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70443-tbl-0001</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Molecular weight'; source reconciliation required</li><li>table representations disagree for 'LogPo:w'; source reconciliation required</li><li>table representations disagree for 'pKa'; source reconciliation required</li><li>table representations disagree for 'Fraction unbound in plasma'; source reconciliation required</li><li>table representations disagree for 'Solubility (in water)'; source reconciliation required</li><li>table representations disagree for 'Intestinal permeability'; source reconciliation required</li><li>table representations disagree for 'Organ specified permeabilities'; source reconciliation required</li><li>table representations disagree for 'Plasma hepatic CL'; source reconciliation required</li><li>table representations disagree for 'ABCB1-Kcat'; source reconciliation required</li><li>table representations disagree for 'ABCB1-Km'; source reconciliation required</li><li>table representations disagree for 'ABCG2-Kcat'; source reconciliation required</li><li>table representations disagree for 'ABCG2-Km'; source reconciliation required</li><li>table representations disagree for 'ABCB1 reference concentration'; source reconciliation required</li><li>table representations disagree for 'ABCG2 reference concentration'; source reconciliation required</li><li>dropped unlinked row (NIL): 'LogPo:w' — extend the ontology if this is a real PK parameter (source ['Nguyen_2026_table_1:row2:col1'])</li><li>dropped unlinked row (NIL): 'pKa' — extend the ontology if this is a real PK parameter (source ['Nguyen_2026_table_1:row4:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Nguyen2026_value;
