function p = Linezolid_Nguyen2026v2_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linezolid   source: Nguyen_2026_2 / final   route: oral
  p.name  = 'Linezolid_Nguyen2026v2_final_params';
  p.drug  = 'linezolid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.7;                % central volume [L]
  p.CL = 3.88;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.53;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 450.0;             % dose [mg]
end
