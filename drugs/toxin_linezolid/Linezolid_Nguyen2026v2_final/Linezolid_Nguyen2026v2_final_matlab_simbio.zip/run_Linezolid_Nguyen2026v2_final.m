% Run (SimBiology): build model + dose, simulate 0..47.0 h, plot.
p = Linezolid_Nguyen2026v2_final_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 47.0);
