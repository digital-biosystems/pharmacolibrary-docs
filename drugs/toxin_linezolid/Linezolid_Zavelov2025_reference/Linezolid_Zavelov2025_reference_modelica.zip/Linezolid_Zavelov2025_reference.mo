model Linezolid_Zavelov2025_reference
  parameter Real Cl_ref = 1.3036111111111111e-05 "Cl [m3/s]";
  parameter Real cov_4th_day_if_4th_day_0 = 0 "4th day [if 4th day] covariate";
  parameter Real Vd_ref = 0.09944 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (-0.4)*cov_4th_day_if_4th_day_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.0006,
    ka = 0.0003388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>hematooncological patients with sepsis</td></tr><tr><td>source_paper:</td><td>Zavřelová_2025</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70346-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'β_Vd_Age (years)' — extend the ontology if this is a real PK parameter (source ['cts70346-tbl-0002:row4:col1'])</li><li>dropped unlinked row (NIL): 'β_CL_Age (years)' — extend the ontology if this is a real PK parameter (source ['cts70346-tbl-0002:row6:col1'])</li><li>'β_CL_4th day [if 4th day]' is a β covariate effect on _CL_, not Q319 (llm link set aside)</li><li>covariate level 'β_CL_4th day [if 4th day]' → Q900:theta_cl_4th_day_if_4th_day = -0.40 (linear_fractional on Q22)</li><li>dropped duplicate Q61 ('Ω_Vd', value '0.23') — already have one for this compound</li><li>routed 'Ω_CL' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Ω_ CL_4th day' — extend the ontology if this is a real PK parameter (source ['cts70346-tbl-0002:row11:col1'])</li><li>dropped unlinked row (NIL): 'Constant' — extend the ontology if this is a real PK parameter (source ['cts70346-tbl-0002:row13:col1'])</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Linezolid</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bandín-Vilar_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Zavelov2025_reference;
