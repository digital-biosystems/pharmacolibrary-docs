model Linezolid_Nguyen2026v2_base
  parameter Real Cl_ref = 1.188888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0451 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.337351,
    adminMass = 0.00045,
    ka = 0.00041944444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>adults treated with linezolid for multidrug-resistant tuberculosis</td></tr><tr><td>source_paper:</td><td>Nguyen_2026_2</td></tr><tr><td>measured_compound:</td><td>Linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>linezolid 337.351 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'CV%'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'Kabs'</li><li>dropped value-less row: 'Kel'</li><li>dropped value-less row: 'Kreabs'</li><li>dropped value-less row: 'M/m'</li><li>dropped value-less row: 'NA'</li><li>dropped value-less row: 'θCL'</li><li>dropped value-less row: 'θCOV'</li><li>dropped value-less row: 'OFV'</li><li>dropped value-less row: 'θV'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'V/F'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Linezolid_Nguyen2026v2_base;
