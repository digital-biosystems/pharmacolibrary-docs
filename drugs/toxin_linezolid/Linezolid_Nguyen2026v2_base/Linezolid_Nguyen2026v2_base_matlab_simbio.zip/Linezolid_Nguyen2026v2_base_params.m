function p = Linezolid_Nguyen2026v2_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linezolid   source: Nguyen_2026_2 / base   route: oral
  p.name  = 'Linezolid_Nguyen2026v2_base_params';
  p.drug  = 'linezolid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.1;                % central volume [L]
  p.CL = 4.28;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.51;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 450.0;             % dose [mg]
end
