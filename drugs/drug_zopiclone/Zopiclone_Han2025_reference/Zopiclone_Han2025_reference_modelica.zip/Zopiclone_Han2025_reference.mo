model Zopiclone_Han2025_reference
  parameter Real Cl_ref = 8.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.308 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.388808,
    adminMass = 7.5e-06,
    ka = 0.00036111111111111115,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zopiclone</h4><p>Zopiclone is a sedative drug from the benzodiazepine-related group used to treat insomnia. It is given by mouth as tablets and is well absorbed from the gut. It is widely prescribed for short-term sleep issues but is not sold commercially in the United States, where a related compound is used instead.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q220426\">Wikidata Q220426</a>, <a href=\"https://en.wikipedia.org/wiki/Zopiclone?oldid=1384859819\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zopiclone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Han_2025</td></tr><tr><td>measured_compound:</td><td>zopiclone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zopiclone 388.808 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Han_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Zopiclone_Han2025_reference;
