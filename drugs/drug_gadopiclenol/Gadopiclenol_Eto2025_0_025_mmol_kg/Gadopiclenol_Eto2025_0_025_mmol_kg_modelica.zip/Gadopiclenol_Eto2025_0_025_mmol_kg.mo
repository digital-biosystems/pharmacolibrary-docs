model Gadopiclenol_Eto2025_0_025_mmol_kg
  parameter Real Cl_ref = 1.5277777777777776e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0132 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9701000000000001,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About gadopiclenol</h4><p>Gadopiclenol is a gadolinium-based contrast agent used to improve images in magnetic resonance imaging. It is authorised in the European Union and is a newer agent, so it is not yet widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q114748523\">Wikidata Q114748523</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>gadopiclenol</td></tr><tr><td>population:</td><td>Japanese and non-Japanese subjects, including adults and pediatric patients</td></tr><tr><td>source_paper:</td><td>Eto_2025</td></tr><tr><td>measured_compound:</td><td>gadopiclenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>gadopiclenol 970.1 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'n subjects' — extend the ontology if this is a real PK parameter (source ['Eto_2025_table_2:row1:col2', 'Eto_2025_table_2:row1:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=gadopiclenol</li><li>population split: '0.025 mmol/kg' subgroup of Eto_2025 (paper reports 3 populations: 0.025 mmol/kg, 0.05 mmol/kg, 0.1 mmol/kg)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Gadopiclenol_Eto2025_0_025_mmol_kg;
