function p = Gadopiclenol_Eto2025_0_05_mmol_kg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gadopiclenol   source: Eto_2025 / 0_05_mmol_kg   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Gadopiclenol_Eto2025_0_05_mmol_kg_params';
  p.drug  = 'gadopiclenol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.0;                % central volume [L]
  p.CL = 6.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
