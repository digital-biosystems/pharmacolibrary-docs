model Dexmedetomidine_Li2022_reference
  parameter Real Cl_ref = 1.45e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0574 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2002795,
    adminMass = 1.4e-07,
    ka = 0.00041666666666666664,
    Tlag = 108.0,
    k12 = 0.0011783778552071236,
    k21 = 0.000963516935739158
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dexmedetomidine</h4><p>Dexmedetomidine is a sedative that acts as an adrenergic alpha-2 receptor agonist, used to treat pain and agitation. It is given as an intravenous solution or as a film for buccal or sublingual use. The drug is authorised in the European Union for conscious sedation and is also used in veterinary medicine.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412133\">Wikidata Q412133</a>, <a href=\"https://en.wikipedia.org/wiki/Dexmedetomidine?oldid=1374736005\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexmedetomidine</td></tr><tr><td>population:</td><td>infants and young children</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>dexmedetomidine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dexmedetomidine 200.28 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h/[WT/70]^0.75)†' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'V1/F (L/[WT/70])' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'Q/F (L/h/[WT/70]^0.75)' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'V2/F (L/[WT/70])' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'Ka (h−1)' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'TIag (h)' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'V1/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'V1/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Interindividual variability (ω2)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dexmedetomidine_Li2022_reference;
