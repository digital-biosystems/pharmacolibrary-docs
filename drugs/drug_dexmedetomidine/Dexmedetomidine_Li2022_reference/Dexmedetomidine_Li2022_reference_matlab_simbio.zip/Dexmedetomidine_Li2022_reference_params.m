function p = Dexmedetomidine_Li2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexmedetomidine   source: Li_2022 / reference   route: oral
  p.name  = 'Dexmedetomidine_Li2022_reference_params';
  p.drug  = 'dexmedetomidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 57.4;                % central volume [L]
  p.CL = 52.2;                % clearance [L/h]
  p.Vp = [70.2];             % peripheral volumes [L]
  p.Q  = [243.5];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.03;             % absorption lag [h]
  p.dose = 0.14;             % dose [mg]
end
