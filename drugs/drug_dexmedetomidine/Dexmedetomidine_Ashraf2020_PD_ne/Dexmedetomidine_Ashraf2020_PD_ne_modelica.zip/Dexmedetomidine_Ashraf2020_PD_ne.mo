model Dexmedetomidine_Ashraf2020_PD_ne
  "indirect_response_i exposure-response sweep — Ashraf_2020 :: NE (Plasma norepinephrine concentration)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.814,      // [nM]
    Emax = 1,  // type I effect term
    EC50 = 0.334,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.4, Interval = 0.0068),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dexmedetomidine</h4><p>Dexmedetomidine is a sedative that acts as an adrenergic alpha-2 receptor agonist, used to treat pain and agitation. It is given as an intravenous solution or as a film for buccal or sublingual use. The drug is authorised in the European Union for conscious sedation and is also used in veterinary medicine.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412133\">Wikidata Q412133</a>, <a href=\"https://en.wikipedia.org/wiki/Dexmedetomidine?oldid=1374736005\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dexmedetomidine_Ashraf2020_PD_ne</h4><p>The steady-state exposure-response curve of Ashraf MW et al., <i>Clinical pharmacokinetics 59(11):1467–1482</i> 2020 (<a href=\"https://doi.org/10.1007/s40262-020-00900-3\">doi:10.1007/s40262-020-00900-3</a>) — Plasma norepinephrine concentration [nM] against dexmedetomidine nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.814 nM       drug-free response (baseline) (CE0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      0.334 nM       exposure at half of the maximal effect term (EC50,NE, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of dexmedetomidine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.814   (drug-free)
  exposure = EC50 (0.334 nM)  response 0.407
  exposure -> infinity  response 0</pre></body></html>"));
end Dexmedetomidine_Ashraf2020_PD_ne;
