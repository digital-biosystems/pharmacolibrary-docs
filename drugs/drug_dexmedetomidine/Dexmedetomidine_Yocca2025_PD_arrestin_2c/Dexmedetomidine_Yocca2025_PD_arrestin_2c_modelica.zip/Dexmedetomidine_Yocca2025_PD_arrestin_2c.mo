model Dexmedetomidine_Yocca2025_PD_arrestin_2c
  "emax exposure-response sweep — Yocca_2025 :: β-arrestin α2C (β-arrestin recruitment at human α2C-AR)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.95,  // [1; % × 0.01]
    EC50 = 24,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 240, Interval = 0.48),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dexmedetomidine</h4><p>Dexmedetomidine is a sedative that acts as an adrenergic alpha-2 receptor agonist, used to treat pain and agitation. It is given as an intravenous solution or as a film for buccal or sublingual use. The drug is authorised in the European Union for conscious sedation and is also used in veterinary medicine.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412133\">Wikidata Q412133</a>, <a href=\"https://en.wikipedia.org/wiki/Dexmedetomidine?oldid=1374736005\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dexmedetomidine_Yocca2025_PD_arrestin_2c</h4><p>The steady-state exposure-response curve of Yocca FD et al., <i>Frontiers in pharmacology 16:1589075</i> 2025 (<a href=\"https://doi.org/10.3389/fphar.2025.1589075\">doi:10.3389/fphar.2025.1589075</a>) — β-arrestin recruitment at human α2C-AR [% of UK-14304 maximum] against dexmedetomidine nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         95 %        maximal effect term (Max activity, Q320)
  EC50  =         24 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of dexmedetomidine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (24 nM)  response 0.475
  exposure -> infinity  response 0.95</pre></body></html>"));
end Dexmedetomidine_Yocca2025_PD_arrestin_2c;
