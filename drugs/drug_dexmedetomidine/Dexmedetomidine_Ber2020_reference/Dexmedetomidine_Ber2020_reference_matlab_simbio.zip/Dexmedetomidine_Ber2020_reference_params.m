function p = Dexmedetomidine_Ber2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexmedetomidine   source: Ber_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Dexmedetomidine_Ber2020_reference_params';
  p.drug  = 'dexmedetomidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 22.5;                % central volume [L]
  p.CL = 34.7;                % clearance [L/h]
  p.Vp = [86.1];             % peripheral volumes [L]
  p.Q  = [40.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
