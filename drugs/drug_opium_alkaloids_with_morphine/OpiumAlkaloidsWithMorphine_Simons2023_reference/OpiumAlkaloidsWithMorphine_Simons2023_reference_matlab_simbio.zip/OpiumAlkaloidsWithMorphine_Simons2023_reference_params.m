function p = OpiumAlkaloidsWithMorphine_Simons2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: opium_alkaloids_with_morphine   source: Simons_2023 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'OpiumAlkaloidsWithMorphine_Simons2023_reference_params';
  p.drug  = 'opium_alkaloids_with_morphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.1;                % central volume [L]
  p.CL = 33.1;                % clearance [L/h]
  p.Vp = [5.6];             % peripheral volumes [L]
  p.Q  = [22.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
