function p = Romiplostim_PerezRuixo2012_PD_plt_params()
% Romiplostim_PerezRuixo2012_PD_plt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% romiplostim Perez-Ruixo_2012::PLT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/kg per second, in SI inside (kg/m3, s). Response PLT in 10(9)/L. Driver: romiplostim (dose_only).
p.E0 = 11.1;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 351.0;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
