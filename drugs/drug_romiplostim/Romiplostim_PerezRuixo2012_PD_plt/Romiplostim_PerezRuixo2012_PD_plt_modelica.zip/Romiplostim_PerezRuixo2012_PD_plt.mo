model Romiplostim_PerezRuixo2012_PD_plt
  "linear exposure-response sweep — Perez-Ruixo_2012 :: PLT (platelet counts)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 11.1,      // [10(9)/L]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-09);
  parameter Real slope = 351   "[%/100 µg/wk]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About romiplostim</h4><p>Romiplostim is used to treat low platelet counts (thrombocytopenia), including immune thrombocytopenic purpura, and has been studied in myelodysplastic syndrome. It is an approved medicine, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1235195\">Wikidata Q1235195</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Romiplostim_PerezRuixo2012_PD_plt</h4><p>The steady-state exposure-response curve of Perez-Ruixo JJ et al., <i>Journal of clinical pharmacology 52(10):1540–1551</i> 2012 (<a href=\"https://doi.org/10.1177/0091270011420843\">doi:10.1177/0091270011420843</a>) — platelet counts [10(9)/L] against romiplostim µg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       11.1 10(9)/L  drug-free response (baseline) (baseline platelet count, Q324)
  slope =        351 %/100 µg/wk change in response per unit of exposure (romiplostim stimulatory effect, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/kg of romiplostim per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 11.1   (drug-free)</pre></body></html>"));
end Romiplostim_PerezRuixo2012_PD_plt;
