function p = Romiplostim_Fan2023v2_PD_plt_params()
% Romiplostim_Fan2023v2_PD_plt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% romiplostim Fan_2023_2::PLT: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PLT in ×1012 cells/L. Driver: romiplostim (cited_pk).
p.E0 = 0.23;
p.Emax = 1.67;
p.EC50 = 1.19e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 120.0;
p.form = 'E0*(1 + Emax*frac)';
end
