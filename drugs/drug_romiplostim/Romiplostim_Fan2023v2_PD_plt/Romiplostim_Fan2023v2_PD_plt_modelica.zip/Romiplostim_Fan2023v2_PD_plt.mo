model Romiplostim_Fan2023v2_PD_plt
  "indirect_response_iii exposure-response sweep — Fan_2023_2 :: PLT (platelets)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.23,      // [×1012 cells/L]
    Emax = 1.67,  // type III effect term
    EC50 = 1.19e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 120, Interval = 0.24),
    Documentation(info = "<html><body><!-- drug-about --><h4>About romiplostim</h4><p>Romiplostim is used to treat low platelet counts (thrombocytopenia), including immune thrombocytopenic purpura, and has been studied in myelodysplastic syndrome. It is an approved medicine, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1235195\">Wikidata Q1235195</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Romiplostim_Fan2023v2_PD_plt</h4><p>The steady-state exposure-response curve of Fan X et al., <i>Pharmaceutics 15(2)</i> 2023 (<a href=\"https://doi.org/10.3390/pharmaceutics15020344\">doi:10.3390/pharmaceutics15020344</a>) — platelets [×1012 cells/L] against romiplostim ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.23 ×1012 cells/L drug-free response (baseline) (PLT0, Q324)
  Emax  =       1.67          maximal effect term (SmaxRM1, Q320)
  EC50  =       11.9 ng/mL    exposure at half of the maximal effect term (SC50RM, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of romiplostim per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.23   (drug-free)
  exposure = EC50 (11.9 ng/mL)  response 0.4221
  exposure -> infinity  response 0.6141</pre></body></html>"));
end Romiplostim_Fan2023v2_PD_plt;
