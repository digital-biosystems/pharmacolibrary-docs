function p = Romiplostim_Wang2010_PD_plt_params()
% Romiplostim_Wang2010_PD_plt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% romiplostim Wang_2010::PLT: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PLT in its own unit. Driver: romiplostim (cited_pk).
p.E0 = 0.0;
p.Emax = 11.2;
p.EC50 = 5.1999999999999996e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.52;
p.form = 'E0*(1 + Emax*frac)';
end
