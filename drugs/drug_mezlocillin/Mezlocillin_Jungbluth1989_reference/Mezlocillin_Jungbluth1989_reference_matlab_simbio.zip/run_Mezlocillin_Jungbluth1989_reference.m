% Run (SimBiology): build model + dose, simulate 0..312.0 h, plot.
p = Mezlocillin_Jungbluth1989_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 312.0);
