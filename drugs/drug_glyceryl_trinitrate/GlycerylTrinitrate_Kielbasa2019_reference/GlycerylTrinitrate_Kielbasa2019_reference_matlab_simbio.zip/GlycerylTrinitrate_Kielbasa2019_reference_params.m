function p = GlycerylTrinitrate_Kielbasa2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glyceryl_trinitrate   source: Kielbasa_2019 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'GlycerylTrinitrate_Kielbasa2019_reference_params';
  p.drug  = 'glyceryl_trinitrate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.5;                % central volume [L]
  p.CL = 0.008;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.02;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
