function p = Metformin_Zhang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Zhang_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Metformin_Zhang2025_reference_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 246.0;                % central volume [L]
  p.CL = 26.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
