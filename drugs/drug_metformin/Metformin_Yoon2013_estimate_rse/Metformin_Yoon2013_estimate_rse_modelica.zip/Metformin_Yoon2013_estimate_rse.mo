model Metformin_Yoon2013_estimate_rse
  parameter Real Cl_ref = 3.777777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.112 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 6.88888888888889e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Yoon_2013</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F, θOCT2', value '-0.248') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F, θOCTN1', value '-0.234') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F, θBW', value '0.0183') — already have one for this compound</li><li>unit_dimension_unknown: 'Tlag' (tlag)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'estimate (%rse)' subgroup of Yoon_2013 (paper reports 2 populations: estimate (%rse), shrinkage (%))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Yoon2013_estimate_rse;
