function p = Metformin_Yoon2013_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Yoon_2013 / estimate_rse   route: oral
  % estimated (absent from source): dose
  p.name  = 'Metformin_Yoon2013_estimate_rse_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 112.0;                % central volume [L]
  p.CL = 136.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.248;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
