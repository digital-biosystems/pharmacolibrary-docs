model Metformin_Ailabouni2026_reference
  parameter Real Cl_ref = 1.7222222222222224e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0063 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.00025,
    ka = 0.003638888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Ailabouni_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV on CL/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on CL/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on CL/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on CL/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on V/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on V/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on V/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on V/F (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on Ka (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on Ka (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on Ka (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV on Ka (CV%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Ailabouni2026_reference;
