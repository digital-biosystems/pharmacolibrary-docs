model Metformin_Chae2012_interindividual
  parameter Real Cl_ref = 8.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0221 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00011388888888888888,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy humans</td></tr><tr><td>source_paper:</td><td>Chae_2012</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter, unit' — extend the ontology if this is a real PK parameter (source ['tab_1:row2:col5'])</li><li>dropped unlinked row (NIL): 'r' — extend the ontology if this is a real PK parameter (source ['tab_1:row12:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=metformin</li><li>population split: 'interindividual' subgroup of Chae_2012 (paper reports 2 populations: interindividual, population)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chae_2012's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zhang_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Chae2012_interindividual;
