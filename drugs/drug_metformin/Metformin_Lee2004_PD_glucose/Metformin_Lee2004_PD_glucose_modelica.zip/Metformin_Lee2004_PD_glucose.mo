model Metformin_Lee2004_PD_glucose
  "indirect_response_i exposure-response sweep — Lee_2004 :: glucose (plasma concentrations of glucose)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 122.441176471,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00226,  // [kg/m3; microg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 microg/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (83.26/0.68 = 122.4) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 23, Interval = 0.046),
    Documentation(info = "<html><body><h4>Metformin_Lee2004_PD_glucose</h4><p>The steady-state exposure-response curve of Lee SH et al., <i>Archives of pharmacal research 27(7):806–810</i> 2004 (<a href=\"https://doi.org/10.1007/BF02980152\">doi:10.1007/BF02980152</a>) — plasma concentrations of glucose against metformin microg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 122.441176471          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       2.26 microg/mL exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one microg/mL of metformin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 122.4   (drug-free)
  exposure = EC50 (2.26 microg/mL)  response 61.22
  exposure -> infinity  response 0</pre></body></html>"));
end Metformin_Lee2004_PD_glucose;
