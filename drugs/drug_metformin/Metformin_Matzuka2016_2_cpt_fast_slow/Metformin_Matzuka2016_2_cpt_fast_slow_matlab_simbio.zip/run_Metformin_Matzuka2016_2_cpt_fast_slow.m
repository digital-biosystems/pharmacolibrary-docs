% Run (SimBiology): build model + dose, simulate 0..1680.0 h, plot.
p = Metformin_Matzuka2016_2_cpt_fast_slow_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1680.0);
