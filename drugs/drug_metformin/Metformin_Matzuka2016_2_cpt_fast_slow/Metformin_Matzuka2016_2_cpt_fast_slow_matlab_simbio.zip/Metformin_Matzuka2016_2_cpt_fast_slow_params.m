function p = Metformin_Matzuka2016_2_cpt_fast_slow_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Matzuka_2016 / 2_cpt_fast_slow   route: oral
  p.name  = 'Metformin_Matzuka2016_2_cpt_fast_slow_params';
  p.drug  = 'metformin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 284.0;                % central volume [L]
  p.CL = 37.0;                % clearance [L/h]
  p.Vp = [8430.0];             % peripheral volumes [L]
  p.Q  = [42.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.11;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
