model Metformin_Matzuka2016_2_cpt_fast_slow
  parameter Real Cl_ref = 1.0277777777777777e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28400000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.002,
    ka = 3.0555555555555554e-05,
    Tlag = 0.0,
    k12 = 4.166666666666666e-05,
    k21 = 1.4037168841439304e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>2-cpt fast/slow</td></tr><tr><td>source_paper:</td><td>Matzuka_2016</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cl (L h⁻¹)'; source reconciliation required</li><li>table representations disagree for 'Q / F (L h⁻¹)'; source reconciliation required</li><li>table representations disagree for 'V / F (L)'; source reconciliation required</li><li>table representations disagree for 'V2 / F (L)'; source reconciliation required</li><li>table representations disagree for 'ka (h⁻¹)'; source reconciliation required</li><li>table representations disagree for 'ka2 (h⁻¹)'; source reconciliation required</li><li>table representations disagree for 't1/2 (elim) (h)'; source reconciliation required</li><li>table representations disagree for 'σ²'; source reconciliation required</li><li>table representations disagree for 'Loglike'; source reconciliation required</li><li>table representations disagree for '-2LL'; source reconciliation required</li><li>table representations disagree for 'Time (s) [per iteration]'; source reconciliation required</li><li>unit_dimension_mismatch: 'ka2 (h⁻¹)' → Q67 (unit '1 / [time]' vs ontology '[mass] / [time]') — route to review</li><li>dropped unlinked row (NIL): '-2LL' — extend the ontology if this is a real PK parameter (source ['Matzuka_2016_table_p7_1:row20:col2'])</li><li>dropped unlinked row (NIL): 'Time (s) [per iteration]' — extend the ontology if this is a real PK parameter (source ['Matzuka_2016_table_p7_1:row21:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Metformin_Matzuka2016_2_cpt_fast_slow;
