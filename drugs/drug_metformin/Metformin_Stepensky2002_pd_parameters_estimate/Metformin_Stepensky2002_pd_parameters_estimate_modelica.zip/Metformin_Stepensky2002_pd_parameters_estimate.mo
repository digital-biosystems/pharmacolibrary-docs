model Metformin_Stepensky2002_pd_parameters_estimate
  parameter Real Cl_ref = 0.0005806079999999999 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07168 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.014,
    ka = 0.00011388888888888888,
    Tlag = 1224.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>streptozotocin diabetic rats</td></tr><tr><td>source_paper:</td><td>Stepensky_2002</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'k_g0 (min⁻¹)' — extend the ontology if this is a real PK parameter (source ['Stepensky_2002_table_p5_1:row1:col4'])</li><li>dropped unlinked row (NIL): 'k_gs (min⁻¹)' — extend the ontology if this is a real PK parameter (source ['Stepensky_2002_table_p5_1:row2:col4'])</li><li>dropped duplicate Q47 ('k_is (min⁻¹)', value '0.378') — already have one for this compound</li><li>dropped unlinked row (NIL): 'k_i4 (min⁻¹)' — extend the ontology if this is a real PK parameter (source ['Stepensky_2002_table_p5_1:row5:col4'])</li><li>dropped duplicate Q373 ('k_60 (min⁻¹)', value '521') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=metformin</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V_c (ml/kg)' is the general volume)</li><li>population split: 'pd parameters / estimate' subgroup of Stepensky_2002 (paper reports 2 populations: pd parameters / estimate, pk parameters / estimate)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Chae_2012's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zhou_2026's review values (primary lacked it)</li><li>derived CL=2090.19 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Stepensky2002_pd_parameters_estimate;
