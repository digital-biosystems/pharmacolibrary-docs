model Metformin_Parween2020_PD_mc2r_signaling
  "emax exposure-response sweep — Parween_2020 :: MC2R signaling (cAMP-dependent luciferase reporter activity (MC2R signaling))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 100,      // [1]
    Emax = -100,  // [1]
    EC50 = 4.2,  // [mM]
    gamma = 1,
    exposure_per_s = 1);   // 1 mM per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 42, Interval = 0.084),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metformin_Parween2020_PD_mc2r_signaling</h4><p>The steady-state exposure-response curve of Parween S et al., <i>The Journal of steroid biochemistry and molecular biology 200:105684</i> 2020 (<a href=\"https://doi.org/10.1016/j.jsbmb.2020.105684\">doi:10.1016/j.jsbmb.2020.105684</a>) — cAMP-dependent luciferase reporter activity (MC2R signaling) against metformin mM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        100          drug-free response (baseline) (Rmax (%; ±SEM), Q336)
  Emax  =        100          maximal effect term (Rmax (%; ±SEM), Q320)
  EC50  =        4.2 mM       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of metformin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 100   (drug-free)
  exposure = EC50 (4.2 mM)  response 50
  exposure -> infinity  response 0</pre></body></html>"));
end Metformin_Parween2020_PD_mc2r_signaling;
