function p = Metformin_Parween2020_PD_mc2r_signaling_params()
% Metformin_Parween2020_PD_mc2r_signaling_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Parween_2020::MC2R_signaling: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response MC2R signaling in its own unit. Driver: metformin (cited_pk).
p.E0 = 100.0;
p.Emax = -100.0;
p.EC50 = 4.2;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 42.0;
p.form = 'E0 + Emax*frac';
end
