model Metformin_Ailabouni2026_250_mg
  parameter Real Cl_ref = 2.683333333333333e-05 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.5451 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.761)*cov_egfr_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>pediatric patients with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Ailabouni_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'TBW on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_3:row6:col4', 'tab_3:row6:col5', 'tab_3:row6:col6'])</li><li>covariate level 'eGFR on CL/F' → Q900:egfr_on_cl_f = 0.761 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>population split: '250 mg' subgroup of Ailabouni_2026 (paper reports 3 populations: 250 mg, 850 mg, final model estimate)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Ailabouni2026_250_mg;
