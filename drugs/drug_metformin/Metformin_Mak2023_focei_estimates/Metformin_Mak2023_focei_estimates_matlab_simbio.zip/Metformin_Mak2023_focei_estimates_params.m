function p = Metformin_Mak2023_focei_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Mak_2023 / focei_estimates   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Metformin_Mak2023_focei_estimates_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 259.0;                % central volume [L]
  p.CL = 54.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
