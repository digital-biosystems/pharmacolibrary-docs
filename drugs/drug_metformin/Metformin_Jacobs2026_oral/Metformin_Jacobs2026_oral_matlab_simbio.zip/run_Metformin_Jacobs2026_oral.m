% Run (SimBiology): build model + dose, simulate 0..456.0 h, plot.
p = Metformin_Jacobs2026_oral_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 456.0);
