model Metformin_Jacobs2026_oral
  parameter Real Cl_ref = 1.6388888888888888e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.029259999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 7.86,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00011388888888888888,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>Thoroughbred horses</td></tr><tr><td>source_paper:</td><td>Jacobs_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dta70000-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=metformin</li><li>population split: 'oral' subgroup of Jacobs_2026 (paper reports 2 populations: intravenous, oral)</li><li>gap-filled Q22 (CL) from Choi_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Dong_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chae_2012's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zhang_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Jacobs2026_oral;
