model Metformin_Stepensky2002_PD_r
  "indirect_response_i exposure-response sweep — Stepensky_2002 :: R (blood glucose levels)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 383.763837638,      // [mg/100 ml]
    Emax = 0.486,  // type I effect term
    EC50 = 4.31e-07,  // [kg; µg × 1e-09]
    gamma = 2,
    exposure_per_s = 1e-09);   // 1 µg per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (2.08/0.00542 = 383.8) — the paper's stated baseline may differ
  annotation(experiment(StartTime = 0, StopTime = 4400, Interval = 8.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metformin_Stepensky2002_PD_r</h4><p>The steady-state exposure-response curve of Stepensky D et al., <i>Drug metabolism and disposition: the biological fate of chemicals 30(8):861–868</i> 2002 (<a href=\"https://doi.org/10.1124/dmd.30.8.861\">doi:10.1124/dmd.30.8.861</a>) — blood glucose levels [mg/100 ml] against metformin µg — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 383.763837638 mg/100 ml drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      0.486          maximal effect term (E_max GI, Q323)
  EC50  =        431 µg       exposure at half of the maximal effect term (EA_50 GI, Q321)
  gamma =          2          Hill coefficient (n_GI, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one µg of metformin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 383.8   (drug-free)
  exposure = EC50 (431 µg)  response 290.5
  exposure -> infinity  response 197.3</pre></body></html>"));
end Metformin_Stepensky2002_PD_r;
