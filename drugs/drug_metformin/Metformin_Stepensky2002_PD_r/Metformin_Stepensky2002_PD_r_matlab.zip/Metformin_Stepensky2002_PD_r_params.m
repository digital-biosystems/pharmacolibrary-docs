function p = Metformin_Stepensky2002_PD_r_params()
% Metformin_Stepensky2002_PD_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Stepensky_2002::R: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg per second, in SI inside (kg/m3, s). Response R in mg/100 ml. Driver: metformin (pk_record).
p.E0 = 383.7638376383764;
p.Emax = 0.486;
p.EC50 = 4.3100000000000003e-07;
p.gamma = 2.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 4400.0;
p.form = 'E0*(1 - Emax*frac)';
end
