model Metformin_Hong2008_reference
  parameter Real Cl_ref = 2.1944444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.648 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.0005,
    ka = 0.0005972222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>adults with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Hong_2008</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('Population mean estimates (relative standard error [RSE]) of clearance (CL/F)'=79.0) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=648) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('k a , h -1'=2.15) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F, L⋅h -1'=79.0) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F, L'=648) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Metformin_Hong2008_reference;
