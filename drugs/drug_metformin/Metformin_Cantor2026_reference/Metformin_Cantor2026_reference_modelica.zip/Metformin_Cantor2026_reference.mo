model Metformin_Cantor2026_reference
  parameter Real Cl_ref = 2.4080555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.277777777777778e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>youth-onset type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Cantor_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('Effect of OCT1_rs628031 on CL/F', value '0.58') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Cantor2026_reference;
