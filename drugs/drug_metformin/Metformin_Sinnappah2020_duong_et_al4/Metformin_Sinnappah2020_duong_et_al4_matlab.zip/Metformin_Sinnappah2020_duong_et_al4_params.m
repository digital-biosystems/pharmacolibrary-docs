function p = Metformin_Sinnappah2020_duong_et_al4_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Sinnappah_2020 / duong_et_al4   route: oral
  % estimated (absent from source): dose
  p.name  = 'Metformin_Sinnappah2020_duong_et_al4_params';
  p.drug  = 'metformin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 123.0;                % central volume [L]
  p.CL = 52.6;                % clearance [L/h]
  p.Vp = [335.0];             % peripheral volumes [L]
  p.Q  = [13.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.51;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
