model Metformin_Sinnappah2020_duong_et_al4
  parameter Real Cl_ref = 4.444444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.0005,
    ka = 0.00014166666666666668,
    Tlag = 0.0,
    k12 = 2.9358626919602534e-05,
    k21 = 1.0779436152570482e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>patients with Type 2 diabetes receiving intermittent haemodialysis</td></tr><tr><td>source_paper:</td><td>Sinnappah_2020</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (CV %)' routed out of structural estimates ('Between-subject\nvariability')</li><li>table section iiv: 'ωV2 (CV %)' routed out of structural estimates ('Between-subject\nvariability')</li><li>table section iiv: 'ωF1 (CV %)' routed out of structural estimates ('Between-subject\nvariability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>population split: 'duong et al4' subgroup of Sinnappah_2020 (paper reports 2 populations: duong et al4, parameter estimates (rse %))</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Metformin_Sinnappah2020_duong_et_al4;
