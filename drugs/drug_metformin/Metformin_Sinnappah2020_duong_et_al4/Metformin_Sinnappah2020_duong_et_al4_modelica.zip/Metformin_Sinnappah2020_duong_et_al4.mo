model Metformin_Sinnappah2020_duong_et_al4
  parameter Real Cl_ref = 1.4611111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00014166666666666668,
    Tlag = 0.0,
    k12 = 2.9358626919602534e-05,
    k21 = 1.0779436152570482e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>patients with Type 2 diabetes receiving intermittent haemodialysis</td></tr><tr><td>source_paper:</td><td>Sinnappah_2020</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Model</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ωCL (CV %)' — extend the ontology if this is a real PK parameter (source ['Sinnappah_2020_table_p4_1:row10:col1'])</li><li>dropped unlinked row (NIL): 'ωV2 (CV %)' — extend the ontology if this is a real PK parameter (source ['Sinnappah_2020_table_p4_1:row11:col1'])</li><li>dropped unlinked row (NIL): 'ωF1 (CV %)' — extend the ontology if this is a real PK parameter (source ['Sinnappah_2020_table_p4_1:row12:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>population split: 'duong et al4' subgroup of Sinnappah_2020 (paper reports 2 populations: duong et al4, parameter estimates (rse %))</li><li>gap-filled Q27 (CL/F) from Chae_2012's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Sinnappah2020_duong_et_al4;
