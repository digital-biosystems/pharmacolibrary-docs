model Metformin_Nikolaidis2026_final
  parameter Real Cl_ref = 2.322222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1688 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.722222222222222e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy men</td></tr><tr><td>source_paper:</td><td>Nikolaidis_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q76 ('βV/Fexercise session A', value '-0.37') — already have one for this compound</li><li>dropped duplicate Q27 ('βCL/Fexercise session A', value '-0.29') — already have one for this compound</li><li>dropped duplicate Q27 ('βCL/Fexercise session B', value '-0.19') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Corr ka–V/F' — extend the ontology if this is a real PK parameter (source ['Nikolaidis_2026_table_3:row14:col2', 'Nikolaidis_2026_table_3:row14:col3', 'Nikolaidis_2026_table_3:row14:col4'])</li><li>dropped unlinked row (NIL): 'a' — extend the ontology if this is a real PK parameter (source ['Nikolaidis_2026_table_3:row15:col2', 'Nikolaidis_2026_table_3:row15:col3', 'Nikolaidis_2026_table_3:row15:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>model-stage split: 'final estimate (rse%) [η-shrinkage%]' is the final model of Nikolaidis_2026 (paper reports 2 stages: base estimate (rse%) [η-shrinkage%], final estimate (rse%) [η-shrinkage%]); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Nikolaidis2026_final;
