model Metformin_Nikolaidis2026_final
  parameter Real Cl_ref = 2.322222222222222e-05 "Cl [m3/s]";
  parameter Real cov_exercise_session_a_0 = 0 "exercise session A covariate";
  parameter Real cov_exercise_session_b_1 = 0 "exercise session B covariate";
  parameter Real Vd_ref = 0.1688 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.29)*cov_exercise_session_a_0)*(1 + (-0.19)*cov_exercise_session_b_1),
    Vd = Vd_ref*(1 + (-0.37)*cov_exercise_session_a_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.001,
    ka = 9.722222222222222e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy men</td></tr><tr><td>source_paper:</td><td>Nikolaidis_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>'βV/Fexercise session A' is a β covariate effect on V/F, not Q76 (llm link set aside)</li><li>covariate level 'βV/Fexercise session A' → Q900:theta_v_f_exercise_session_a = -0.37 (linear_fractional on Q76)</li><li>'βCL/Fexercise session A' is a β covariate effect on CL/F, not Q27 (llm link set aside)</li><li>covariate level 'βCL/Fexercise session A' → Q900:theta_cl_f_exercise_session_a = -0.29 (linear_fractional on Q27)</li><li>'βCL/Fexercise session B' is a β covariate effect on CL/F, not Q27 (llm link set aside)</li><li>covariate level 'βCL/Fexercise session B' → Q900:theta_cl_f_exercise_session_b = -0.19 (linear_fractional on Q27)</li><li>dropped duplicate Q76 ('Corr ka–V/F', value '0.76') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>model-stage split: 'final estimate (rse%) [η-shrinkage%]' is the final model of Nikolaidis_2026 (paper reports 2 stages: base estimate (rse%) [η-shrinkage%], final estimate (rse%) [η-shrinkage%]); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Nikolaidis2026_final;
