function p = Metformin_Hong2008_PD_lactic_acid_params()
% Metformin_Hong2008_PD_lactic_acid_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Hong_2008::lactic_acid: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng.mL(-1) per second, in SI inside (kg/m3, s). Response lactic acid in its own unit. Driver: metformin (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.5;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
