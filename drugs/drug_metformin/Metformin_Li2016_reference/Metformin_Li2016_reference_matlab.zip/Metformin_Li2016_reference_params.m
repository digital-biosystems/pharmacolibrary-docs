function p = Metformin_Li2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Li_2016 / reference   route: oral
  p.name  = 'Metformin_Li2016_reference_params';
  p.drug  = 'metformin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 364.7;                % central volume [L]
  p.CL = 269.5;                % clearance [L/h]
  p.Vp = [777.7];             % peripheral volumes [L]
  p.Q  = [308.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.41;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.34;             % absorption lag [h]
  p.dose = 14000.0;             % dose [mg]
end
