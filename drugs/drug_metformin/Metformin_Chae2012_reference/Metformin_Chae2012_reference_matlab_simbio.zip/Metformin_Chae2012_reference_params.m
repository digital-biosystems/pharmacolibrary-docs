function p = Metformin_Chae2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Chae_2012 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Metformin_Chae2012_reference_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.1;                % central volume [L]
  p.CL = 29.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.41;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
