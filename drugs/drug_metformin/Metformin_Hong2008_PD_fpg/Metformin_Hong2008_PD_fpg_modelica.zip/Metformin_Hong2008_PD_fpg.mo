model Metformin_Hong2008_PD_fpg
  "indirect_response_ii exposure-response sweep — Hong_2008 :: FPG (fasting plasma glucose)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.41,      // [kg/m3; mg.dL(-1) × 0.01]
    Emax = 1,  // type II effect term
    EC50 = 0.00423,  // [kg/m3; mg.L(-1) × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg.L(-1) per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 43, Interval = 0.086),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metformin_Hong2008_PD_fpg</h4><p>The steady-state exposure-response curve of Hong Y et al., <i>Journal of clinical pharmacology 48(6):696–707</i> 2008 (<a href=\"https://doi.org/10.1177/0091270008316884\">doi:10.1177/0091270008316884</a>) — fasting plasma glucose [mg.dL(-1)] against metformin mg.L(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        241 mg.dL(-1) drug-free response (baseline) (baseline fasting plasma glucose, Q324)
  Emax  = (library default) maximal effect term
  EC50  =       4.23 mg.L(-1) exposure at half of the maximal effect term (drug concentration producing half-maximal effect, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg.L(-1) of metformin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.41   (drug-free)
  exposure = EC50 (4.23 mg.L(-1))  response 4.82
  exposure -> infinity  response inf</pre></body></html>"));
end Metformin_Hong2008_PD_fpg;
