model Metformin_Hong2008_PD_la
  "linear exposure-response sweep — Hong_2008 :: LA (fasting lactic acid)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.5   "[meter ** 4 / kilogram; mM.mL.ng(-1) × 1000]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metformin_Hong2008_PD_la</h4><p>The steady-state exposure-response curve of Hong Y et al., <i>Journal of clinical pharmacology 48(6):696–707</i> 2008 (<a href=\"https://doi.org/10.1177/0091270008316884\">doi:10.1177/0091270008316884</a>) — fasting lactic acid [mM] against metformin ng.mL(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0005 mM.mL.ng(-1) change in response per unit of exposure (slope coefficient, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng.mL(-1) of metformin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Metformin_Hong2008_PD_la;
