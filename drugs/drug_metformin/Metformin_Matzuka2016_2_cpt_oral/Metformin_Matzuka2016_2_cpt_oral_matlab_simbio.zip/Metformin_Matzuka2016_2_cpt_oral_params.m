function p = Metformin_Matzuka2016_2_cpt_oral_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Matzuka_2016 / 2_cpt_oral   route: oral
  p.name  = 'Metformin_Matzuka2016_2_cpt_oral_params';
  p.drug  = 'metformin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 593.12;                % central volume [L]
  p.CL = 17.79;                % clearance [L/h]
  p.Vp = [55823.5];             % peripheral volumes [L]
  p.Q  = [94.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.21;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
