function p = Metformin_Nikolaidis2026_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Nikolaidis_2026 / base   route: oral
  % estimated (absent from source): dose
  p.name  = 'Metformin_Nikolaidis2026_base_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 185.6;                % central volume [L]
  p.CL = 71.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.44;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
