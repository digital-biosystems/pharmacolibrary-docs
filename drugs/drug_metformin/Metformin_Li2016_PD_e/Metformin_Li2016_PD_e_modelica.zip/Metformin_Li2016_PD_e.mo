model Metformin_Li2016_PD_e
  "indirect_response_i exposure-response sweep — Li_2016 :: E (E)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0.69,      // [1]
    Emax = 1.5,  // type IV effect term
    EC50 = 14.93,  // [mg • L -1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg • L -1 per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 1.5; bound as the reciprocal stimulation form (IV) the paper fitted
  // exposure_unit_unresolved: 'mg • L -1' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 60, Interval = 0.12),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metformin_Li2016_PD_e</h4><p>The steady-state exposure-response curve of Li X et al., <i>Drug research 66(10):547–554</i> 2016 (<a href=\"https://doi.org/10.1055/s-0042-111514\">doi:10.1055/s-0042-111514</a>) — E against metformin mg • L -1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.69          drug-free response (baseline) (K in /K out, Q324)
  Emax  =        1.5          maximal effect term (I max, Q323)
  EC50  =      14.93 mg • L -1 exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg • L -1 of metformin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.69   (drug-free)
  exposure = EC50 (14.93 mg • L -1)  response 0.3943
  exposure -> infinity  response 0.276</pre></body></html>"));
end Metformin_Li2016_PD_e;
