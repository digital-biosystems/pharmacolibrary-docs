function p = Metformin_Li2016_PD_e_params()
% Metformin_Li2016_PD_e_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Li_2016::E: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg • L -1 per second, in SI inside (kg/m3, s). Response E in its own unit. Driver: metformin (pk_record).
p.E0 = 0.69;
p.Emax = 1.5;
p.EC50 = 14.93;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 60.0;
p.form = 'E0/(1 + Emax*frac)';
end
