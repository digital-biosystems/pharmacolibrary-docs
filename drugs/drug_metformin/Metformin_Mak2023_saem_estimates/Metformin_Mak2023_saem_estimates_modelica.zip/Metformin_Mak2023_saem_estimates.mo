model Metformin_Mak2023_saem_estimates
  parameter Real Cl_ref = 1.525e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.26 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00037222222222222225,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Mak_2023</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('ka,fed (h−1)', value '0.496') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Dfasted' — extend the ontology if this is a real PK parameter (source ['Mak_2023_table_2:row5:col1', 'Mak_2023_table_2:row5:col2'])</li><li>covariate effect for Q87 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L·h−1)); Q61 (V (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=metformin</li><li>population split: 'saem estimates' subgroup of Mak_2023 (paper reports 2 populations: focei estimates, saem estimates)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Mak2023_saem_estimates;
