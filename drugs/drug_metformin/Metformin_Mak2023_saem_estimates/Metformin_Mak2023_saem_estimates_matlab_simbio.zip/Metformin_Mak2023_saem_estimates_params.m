function p = Metformin_Mak2023_saem_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Mak_2023 / saem_estimates   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Metformin_Mak2023_saem_estimates_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 260.0;                % central volume [L]
  p.CL = 54.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.34;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
