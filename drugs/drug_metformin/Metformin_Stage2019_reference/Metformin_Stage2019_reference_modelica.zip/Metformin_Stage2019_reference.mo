model Metformin_Stage2019_reference
  parameter Real Cl_ref = 7.083333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0385 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.0005,
    ka = 8.944444444444444e-05,
    Tlag = 0.0,
    k12 = 6.435786435786436e-05,
    k21 = 7.140569964777457e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19484\">Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Stage_2019</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLnet secr' routed out of structural estimates ('IIV-CV')</li><li>table section iiv: 'Vc' routed out of structural estimates ('IIV-CV')</li><li>table section iiv: 'Q1' routed out of structural estimates ('IIV-CV')</li><li>table section iiv: 'Vp1' routed out of structural estimates ('IIV-CV')</li><li>table section iov: 'MTT' routed out of structural estimates ('IOV-CV')</li><li>table section iiv: 'ka' routed out of structural estimates ('IIV-CV')</li><li>table section iiv: 'F500' routed out of structural estimates ('IIV-CV')</li><li>table section iov: 'F500' routed out of structural estimates ('IOV-CV')</li><li>table section iiv: 'F1000' routed out of structural estimates ('IIV-CV')</li><li>table section iov: 'F1000' routed out of structural estimates ('IOV-CV')</li><li>table section iiv: 'Tpre-dose' routed out of structural estimates ('IIV-CV')</li><li>column 'typical value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'typical value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'typical value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'typical value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'typical value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Stage2019_reference;
