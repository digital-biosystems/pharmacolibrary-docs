function p = Metformin_Stage2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Stage_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Metformin_Stage2019_reference_params';
  p.drug  = 'metformin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.5;                % central volume [L]
  p.CL = 25.5;                % clearance [L/h]
  p.Vp = [347.0];             % peripheral volumes [L]
  p.Q  = [8.92];             % inter-compartmental clearances [L/h]
  p.ka = 0.322;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
