% Run (SimBiology): build model + dose, simulate 0..25.0 h, plot.
p = Metformin_Jiang2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 25.0);
