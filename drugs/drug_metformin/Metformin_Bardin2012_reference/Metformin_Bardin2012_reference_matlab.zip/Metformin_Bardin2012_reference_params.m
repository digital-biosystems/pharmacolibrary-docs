function p = Metformin_Bardin2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Bardin_2012 / reference   route: oral
  p.name  = 'Metformin_Bardin2012_reference_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 558.0;                % central volume [L]
  p.CL = 55.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.51;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
