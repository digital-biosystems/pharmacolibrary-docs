function p = Metformin_Ailabouni2026_final_model_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Ailabouni_2026 / final_model_estimate   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Metformin_Ailabouni2026_final_model_estimate_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 546.0;                % central volume [L]
  p.CL = 96.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
