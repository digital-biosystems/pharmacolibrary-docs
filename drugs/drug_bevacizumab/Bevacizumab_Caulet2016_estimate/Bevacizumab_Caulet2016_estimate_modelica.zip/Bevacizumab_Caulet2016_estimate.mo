model Bevacizumab_Caulet2016_estimate
  parameter Real Cl_ref = 2.1990740740740743e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004200000000000001 "Vd [m3]";
  parameter Real cov_height_0 = 0 "height covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (3.2)*cov_height_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 1.901455026455026e-06,
    k21 = 1.037157287157287e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bevacizumab</h4><p>Bevacizumab is a monoclonal antibody that blocks tumour blood vessel growth and is used to treat many cancers, including colorectal, breast, lung, kidney, cervical and ovarian cancers, as well as certain eye conditions such as wet macular degeneration. It is widely used and authorised in the European Union, appears on the WHO list of essential medicines, and is also used off-label in ophthalmology.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413299\">Wikidata Q413299</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bevacizumab</td></tr><tr><td>population:</td><td>patients with metastatic colorectal cancer</td></tr><tr><td>source_paper:</td><td>Caulet_2016</td></tr><tr><td>measured_compound:</td><td>bevacizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'VNTR 3/3 on V C' — extend the ontology if this is a real PK parameter (source ['tab_1:row3:col1'])</li><li>dropped unlinked row (NIL): 'CEA (lg/L) on k 10' — extend the ontology if this is a real PK parameter (source ['tab_1:row5:col1'])</li><li>dropped unlinked row (NIL): 'EHM on k 10' — extend the ontology if this is a real PK parameter (source ['tab_1:row6:col1'])</li><li>dropped unlinked row (NIL): 'VEGF (lg/L) on k 10' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1'])</li><li>unit_dimension_mismatch: 'x Vc' → Q63 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q63 ('x Vc', value '0.23') — already have one for this compound</li><li>dropped unlinked row (NIL): 'x k10' — extend the ontology if this is a real PK parameter (source ['tab_1:row14:col1'])</li><li>dropped unlinked row (NIL): 'x CL' — extend the ontology if this is a real PK parameter (source ['tab_1:row15:col1'])</li><li>routed 'r add (mg/L)' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'r prop (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bevacizumab</li><li>population split: 'estimate' subgroup of Caulet_2016 (paper reports 2 populations: estimate, p value a)</li><li>molar mass: none found for 'bevacizumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Bevacizumab_Caulet2016_estimate;
