function p = Bevacizumab_Caulet2016_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bevacizumab   source: Caulet_2016 / estimate   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Bevacizumab_Caulet2016_estimate_params';
  p.drug  = 'bevacizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.2;                % central volume [L]
  p.CL = 0.007917;                % clearance [L/h]
  p.Vp = [7.7];             % peripheral volumes [L]
  p.Q  = [0.02875];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
