model Bevacizumab_Turner2014_reference
  parameter Real Cl_ref = 2.260119592046649e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003437 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bevacizumab</h4><p>Bevacizumab is a monoclonal antibody that acts as an angiogenesis inhibitor to treat various cancers and certain eye conditions. It is administered intravenously for systemic cancers and by injection into the eye for macular degeneration.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q413299\">Wikidata Q413299</a>, <a href=\"https://en.wikipedia.org/wiki/Bevacizumab?oldid=1384835572\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bevacizumab</td></tr><tr><td>population:</td><td>children with osteosarcoma</td></tr><tr><td>source_paper:</td><td>Turner_2014</td></tr><tr><td>measured_compound:</td><td>bevacizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'terminal half-life'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bevacizumab</li><li>molar mass: none found for 'bevacizumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL=0.00813643 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Bevacizumab_Turner2014_reference;
