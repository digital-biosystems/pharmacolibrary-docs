model DabigatranEtexilate_Liesenfeld2006_PD_aptt
  "emax exposure-response sweep — Liesenfeld_2006 :: aPTT (activated partial thromboplastin time)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 33.4,      // [s; s × 1]
    Emax = 26.9,  // [s; s × 1]
    EC50 = 9.47e-05,  // [kg/m3; ng ml(-1) × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml(-1) per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 950, Interval = 1.9),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dabigatran_etexilate</h4><p>Dabigatran etexilate is a direct thrombin inhibitor anticoagulant used to prevent and treat thrombosis, including venous thromboembolism after joint replacement surgery and stroke risk in atrial fibrillation. It is approved and authorised in the European Union and is widely used as an oral anticoagulant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20078502\">Wikidata Q20078502</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>DabigatranEtexilate_Liesenfeld2006_PD_aptt</h4><p>The steady-state exposure-response curve of Liesenfeld KH et al., <i>British journal of clinical pharmacology 62(5):527–537</i> 2006 (<a href=\"https://doi.org/10.1111/j.1365-2125.2006.02667.x\">doi:10.1111/j.1365-2125.2006.02667.x</a>) — activated partial thromboplastin time [s] against dabigatran ng ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       33.4 s        drug-free response (baseline) (baseline aPTT, Q324)
  Emax  =       26.9 s        maximal effect term (E(max), Q320)
  EC50  =       94.7 ng ml(-1) exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml(-1) of dabigatran per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 33.4   (drug-free)
  exposure = EC50 (94.7 ng ml(-1))  response 46.85
  exposure -> infinity  response 60.3</pre></body></html>"));
end DabigatranEtexilate_Liesenfeld2006_PD_aptt;
