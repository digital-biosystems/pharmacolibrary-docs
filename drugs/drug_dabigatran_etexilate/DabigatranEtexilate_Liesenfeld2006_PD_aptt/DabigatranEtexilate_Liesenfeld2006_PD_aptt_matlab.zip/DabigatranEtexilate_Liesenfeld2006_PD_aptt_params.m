function p = DabigatranEtexilate_Liesenfeld2006_PD_aptt_params()
% DabigatranEtexilate_Liesenfeld2006_PD_aptt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dabigatran_etexilate Liesenfeld_2006::aPTT: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml(-1) per second, in SI inside (kg/m3, s). Response aPTT in s. Driver: dabigatran (cited_pk).
p.E0 = 33.4;
p.Emax = 26.9;
p.EC50 = 9.47e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 950.0;
p.form = 'E0 + Emax*frac';
end
