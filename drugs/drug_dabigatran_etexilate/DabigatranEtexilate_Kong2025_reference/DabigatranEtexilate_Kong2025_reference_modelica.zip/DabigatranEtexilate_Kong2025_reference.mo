model DabigatranEtexilate_Kong2025_reference
  parameter Real Cl_ref = 0.00010083333333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 0.835 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6277332,
    adminMass = 1e-08,
    ka = 0.0020916666666666666,
    Tlag = 0.0,
    k21 = 0.00018677339432056413
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dabigatran_etexilate</h4><p>Dabigatran etexilate is a direct thrombin inhibitor anticoagulant used to prevent and treat thrombosis, including venous thromboembolism after joint replacement surgery and stroke risk in atrial fibrillation. It is approved and authorised in the European Union and is widely used as an oral anticoagulant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20078502\">Wikidata Q20078502</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dabigatran_etexilate</td></tr><tr><td>population:</td><td>healthy volunteers and ESRD patients</td></tr><tr><td>source_paper:</td><td>Kong_2025</td></tr><tr><td>measured_compound:</td><td>dabigatran etexilate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt3546-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dabigatran etexilate 627.733 g/mol (drugbank); dabigatran_etexilate 627.733 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'k a' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V p/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V p/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>column 'unit' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'unit' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end DabigatranEtexilate_Kong2025_reference;
