function p = DabigatranEtexilate_Liesenfeld2006_PD_ect_params()
% DabigatranEtexilate_Liesenfeld2006_PD_ect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dabigatran_etexilate Liesenfeld_2006::ECT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml(-1) per second, in SI inside (kg/m3, s). Response ECT in s. Driver: dabigatran (cited_pk).
p.E0 = 28.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 380000.00000000006;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
