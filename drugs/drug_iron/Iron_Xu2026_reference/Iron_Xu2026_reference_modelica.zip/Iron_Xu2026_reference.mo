model Iron_Xu2026_reference
  parameter Real Cl_ref = 2.5231481481481483e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0015400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.3541666666666667e-06,
    Tlag = 0.0,
    k12 = 1.1123136123136122e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>iron</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Xu_2026</td></tr><tr><td>measured_compound:</td><td>iron</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Xu_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iron_Xu2026_reference;
