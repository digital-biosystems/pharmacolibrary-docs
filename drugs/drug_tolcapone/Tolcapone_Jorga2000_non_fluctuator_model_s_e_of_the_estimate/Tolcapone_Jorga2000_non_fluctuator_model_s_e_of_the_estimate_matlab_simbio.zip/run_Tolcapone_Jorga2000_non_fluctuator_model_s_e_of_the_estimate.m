% Run (SimBiology): build model + dose, simulate 0..33.0 h, plot.
p = Tolcapone_Jorga2000_non_fluctuator_model_s_e_of_the_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 33.0);
