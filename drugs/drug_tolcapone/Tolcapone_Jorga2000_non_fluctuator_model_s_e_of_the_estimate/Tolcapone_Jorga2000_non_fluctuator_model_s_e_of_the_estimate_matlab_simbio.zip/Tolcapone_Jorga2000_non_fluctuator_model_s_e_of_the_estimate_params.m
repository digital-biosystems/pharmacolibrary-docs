function p = Tolcapone_Jorga2000_non_fluctuator_model_s_e_of_the_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tolcapone   source: Jorga_2000 / non_fluctuator_model_s_e_of_the_estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Tolcapone_Jorga2000_non_fluctuator_model_s_e_of_the_estimate_params';
  p.drug  = 'tolcapone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.5;                % central volume [L]
  p.CL = 0.3;                % clearance [L/h]
  p.Vp = [3.1];             % peripheral volumes [L]
  p.Q  = [2.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.2;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.02;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
