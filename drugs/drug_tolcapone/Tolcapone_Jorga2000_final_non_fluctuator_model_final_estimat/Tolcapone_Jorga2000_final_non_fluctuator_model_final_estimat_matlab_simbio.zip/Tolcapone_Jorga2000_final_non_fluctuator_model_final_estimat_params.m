function p = Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tolcapone   source: Jorga_2000 / final_non_fluctuator_model_final_estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat_params';
  p.drug  = 'tolcapone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.5;                % central volume [L]
  p.CL = 4.5;                % clearance [L/h]
  p.Vp = [24.0];             % peripheral volumes [L]
  p.Q  = [7.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.7;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.4;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
