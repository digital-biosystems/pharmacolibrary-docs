% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
