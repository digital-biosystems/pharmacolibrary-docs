#!/usr/bin/env python3
"""Simulate Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat.sbml (0..24.0 h) with Tellurium/libRoadRunner and write results.

Headless-friendly: writes Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat.csv, Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat.json and Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat.png next to this script
(no interactive window). Requires `tellurium` (bundles libRoadRunner + matplotlib).
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat")

r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 24.0, 500, ["time", "Cc"])   # Cc = central concentration [mg/L]
t = [float(x) for x in res[:, 0]]
Cc = [float(x) for x in res[:, 1]]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat", "stop_time_h": 24.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
