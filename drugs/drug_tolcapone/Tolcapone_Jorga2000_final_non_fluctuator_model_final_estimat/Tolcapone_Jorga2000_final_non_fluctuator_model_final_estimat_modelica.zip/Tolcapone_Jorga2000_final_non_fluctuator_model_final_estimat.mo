model Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat
  parameter Real Cl_ref = 1.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2732408,
    adminMass = 5e-05,
    ka = 0.00019444444444444443,
    Tlag = 1440.0,
    k12 = 0.0006111111111111111,
    k21 = 8.912037037037037e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tolcapone</h4><p>Tolcapone is an antiparkinson drug that works as an enzyme inhibitor, indicated for the treatment of Parkinson's disease. It is given as an oral tablet, which is well absorbed through the gut. It is authorised in the European Union, although it carries a boxed warning and has been suspended in several countries due to liver toxicity.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q413840\">Wikidata Q413840</a>, <a href=\"https://en.wikipedia.org/wiki/Tolcapone?oldid=1333688199\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolcapone</td></tr><tr><td>population:</td><td>patients with Parkinson's disease</td></tr><tr><td>source_paper:</td><td>Jorga_2000</td></tr><tr><td>measured_compound:</td><td>tolcapone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tolcapone 273.241 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iov: 'IOV (CL)' routed out of structural estimates ('Inter-occasion variability σ²')</li><li>'θFood(F)': unit 'F' is a parameter symbol — dropped</li><li>dropped unlinked row (NIL): 'θProtein(Vc)' — extend the ontology if this is a real PK parameter (source ['Jorga_2000_table_3:row15:col3'])</li><li>unit_dimension_mismatch: 'θCLCr(CL)' → Q22 (unit '[length] ** 3' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('θCLCr(CL)', value '1.19') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ε (mult)' — extend the ontology if this is a real PK parameter (source ['Jorga_2000_table_3:row25:col3'])</li><li>routed 'ε (add)' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (l h⁻¹)); Q63 (Vc (l)); Q64 (Vp (l)); Q30 (Q (l h⁻¹))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tolcapone</li><li>model-stage split: 'non-fluctuator model final estimate' is the final model of Jorga_2000 (paper reports 6 stages: fluctuator model final estimate, fluctuator model s.e. of the estimate, fluctuators, non-fluctuator model final estimate, non-fluctuator model s.e. of the estimate, non-fluctuators); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tolcapone_Jorga2000_final_non_fluctuator_model_final_estimat;
