model Luspatercept_Chen2021_reference
  parameter Real Cl_ref = 6.1574074074074075e-09 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real cov_albumin_1 = 0 "albumin covariate";
  parameter Real cov_weight_2 = 0 "weight covariate";
  parameter Real Vd_ref = 0.00839 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.809)*cov_weight_0)*(1 + (-0.886)*cov_albumin_1)*(1 + (0.718)*cov_weight_2),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>luspatercept</td></tr><tr><td>population:</td><td>adult patients with β-thalassemia</td></tr><tr><td>source_paper:</td><td>Chen_2021</td></tr><tr><td>measured_compound:</td><td>luspatercept</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1696-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Weight, kg on CL/F' → Q900:weight_kg_on_cl_f = 0.809 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'RBCT burden (units/24 weeks) on CL/F' — extend the ontology if this is a real PK parameter (source ['jcph1696-tbl-0002:row7:col1', 'jcph1696-tbl-0002:row7:col2'])</li><li>covariate level 'Albumin, g/L on CL/F' → Q900:albumin_g_l_on_cl_f = -0.886 (linear_fractional on Q27)</li><li>covariate level 'Weight, kg on V1/F' → Q900:weight_kg_on_v1_f = 0.718 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'RBCT burden (units/24 weeks) on V1/F' — extend the ontology if this is a real PK parameter (source ['jcph1696-tbl-0002:row10:col1', 'jcph1696-tbl-0002:row10:col2'])</li><li>routed 'Interindividual variability of CL/F (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability of V1/F (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=luspatercept</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F, L' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Luspatercept_Chen2021_reference;
