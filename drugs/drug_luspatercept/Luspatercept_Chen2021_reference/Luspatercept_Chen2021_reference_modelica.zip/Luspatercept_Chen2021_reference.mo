model Luspatercept_Chen2021_reference
  parameter Real Cl_ref = 6.1574074074074075e-09 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real cov_albumin_1 = 0 "albumin covariate";
  parameter Real Vd_ref = 0.00839 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.806)*cov_weight_0)*(1 + (-0.881)*cov_albumin_1),
    Vd = Vd_ref*(1 + (0.705)*cov_weight_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.4e-05,
    ka = 4.733796296296296e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About luspatercept</h4><p>Luspatercept is an antianemic medicine used to treat anemia in people with myelodysplastic syndromes or beta-thalassemia. It is authorised in the European Union and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q30314143\">Wikidata Q30314143</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>luspatercept</td></tr><tr><td>population:</td><td>anemic patients with β-thalassemia</td></tr><tr><td>source_paper:</td><td>Chen_2021</td></tr><tr><td>measured_compound:</td><td>luspatercept</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1696-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Weight, kg on CL/F' → Q900:weight_kg_on_cl_f = 0.806 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'RBCT burden (units/24 weeks) on CL/F' — extend the ontology if this is a real PK parameter (source ['jcph1696-tbl-0002:row7:col1'])</li><li>covariate level 'Albumin, g/L on CL/F' → Q900:albumin_g_l_on_cl_f = -0.881 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'RBCT burden (units/24 weeks) on V1/F' — extend the ontology if this is a real PK parameter (source ['jcph1696-tbl-0002:row10:col1'])</li><li>routed 'Interindividual variability of CL/F (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability of V1/F (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=luspatercept</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F, L' is the general volume)</li><li>molar mass: none found for 'luspatercept' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Luspatercept_Chen2021_reference;
