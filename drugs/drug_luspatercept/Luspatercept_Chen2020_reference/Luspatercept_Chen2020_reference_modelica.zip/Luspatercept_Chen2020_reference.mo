model Luspatercept_Chen2020_reference
  parameter Real Cl_ref = 5.42824074074074e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0092 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.277777777777778e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>luspatercept</td></tr><tr><td>population:</td><td>anemic patients with myelodysplastic syndromes</td></tr><tr><td>source_paper:</td><td>Chen_2020</td></tr><tr><td>measured_compound:</td><td>luspatercept</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412521-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Weight, kg, on CL/F' — extend the ontology if this is a real PK parameter (source ['psp412521-tbl-0002:row6:col1', 'psp412521-tbl-0002:row6:col2'])</li><li>dropped unlinked row (NIL): 'Age, years, on CL/F' — extend the ontology if this is a real PK parameter (source ['psp412521-tbl-0002:row7:col1', 'psp412521-tbl-0002:row7:col2'])</li><li>dropped unlinked row (NIL): 'Albumin, g/L, on CL/F' — extend the ontology if this is a real PK parameter (source ['psp412521-tbl-0002:row8:col1', 'psp412521-tbl-0002:row8:col2'])</li><li>dropped unlinked row (NIL): 'Weight, kg, on V1/F' — extend the ontology if this is a real PK parameter (source ['psp412521-tbl-0002:row9:col1', 'psp412521-tbl-0002:row9:col2'])</li><li>dropped unlinked row (NIL): 'Albumin, g/L, on V1/F' — extend the ontology if this is a real PK parameter (source ['psp412521-tbl-0002:row10:col1', 'psp412521-tbl-0002:row10:col2'])</li><li>routed 'Interindividual variability of CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability of V1/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=luspatercept</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F, L' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Luspatercept_Chen2020_reference;
