model Ciclosporin_Gao2022_reference
  parameter Real Cl_ref = 8.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.325 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.202635,
    adminMass = 0.00035,
    ka = 0.00035,
    Tlag = 0.0,
    k12 = 2.64957264957265e-06,
    k21 = 3.286683630195081e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciclosporin</h4><p>Ciclosporin is an immunosuppressant used to treat autoimmune conditions such as rheumatoid arthritis, systemic lupus erythematosus, myasthenia gravis, and graft-versus-host disease, as well as certain eye conditions like dry eye syndromes. It is widely used and is included on the WHO essential medicines list; several products are authorised in the European Union, mainly for eye conditions, and it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q367700\">Wikidata Q367700</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciclosporin</td></tr><tr><td>population:</td><td>Chinese pediatric patients with acquired aplastic anemia</td></tr><tr><td>source_paper:</td><td>Gao_2022</td></tr><tr><td>measured_compound:</td><td>cyclosporine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciclosporin 1202.63 g/mol (pubchem); cyclosporine 1202.63 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('CV for IIV')</li><li>table section iiv: 'VC/F (L)' routed out of structural estimates ('CV for IIV')</li><li>dropped unlinked row (NIL): 'TBIL on CL (%)' — extend the ontology if this is a real PK parameter (source ['T2:row6:col1'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 28 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'allometric_exponent' from footnote/prose loose number 0.75 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 1.0 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 10.65 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number -0.0107 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cyclosporine</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Ciclosporin_Gao2022_reference;
