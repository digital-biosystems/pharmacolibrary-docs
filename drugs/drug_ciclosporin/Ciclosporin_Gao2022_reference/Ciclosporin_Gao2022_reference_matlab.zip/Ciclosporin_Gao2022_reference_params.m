function p = Ciclosporin_Gao2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciclosporin   source: Gao_2022 / reference   route: oral
  p.name  = 'Ciclosporin_Gao2022_reference_params';
  p.drug  = 'ciclosporin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 325.0;                % central volume [L]
  p.CL = 29.1;                % clearance [L/h]
  p.Vp = [262.0];             % peripheral volumes [L]
  p.Q  = [3.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.26;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
