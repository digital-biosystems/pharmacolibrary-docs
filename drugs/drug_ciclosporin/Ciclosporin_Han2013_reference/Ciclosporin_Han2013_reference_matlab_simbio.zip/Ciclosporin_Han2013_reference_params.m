function p = Ciclosporin_Han2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciclosporin   source: Han_2013 / reference   route: oral
  p.name  = 'Ciclosporin_Han2013_reference_params';
  p.drug  = 'ciclosporin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 94.4;                % central volume [L]
  p.CL = 23.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
