function p = Ciclosporin_Kauv2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciclosporin   source: Kauv_2025 / reference   route: oral
  p.name  = 'Ciclosporin_Kauv2025_reference_params';
  p.drug  = 'ciclosporin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.4;                % central volume [L]
  p.CL = 14.3;                % clearance [L/h]
  p.Vp = [6597.0];             % peripheral volumes [L]
  p.Q  = [0.072];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
