// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Desloratadine_Wang2015_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {180000.0},
    MM = 0.31082499999999996,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>desloratadine</td></tr><tr><td>population:</td><td>healthy Chinese male volunteers</td></tr><tr><td>source_paper:</td><td>Wang_2015</td></tr><tr><td>measured_compound:</td><td>Desloratadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>3-OH-desloratadine 326.824 g/mol (pubchem); Desloratadine 310.825 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for Cmax from footnote/prose kept as documentation only (['Wang_2015:abstract'])</li><li>covariate category for AUC∞ from footnote/prose kept as documentation only (['Wang_2015:abstract'])</li><li>covariate category for Cmax from footnote/prose kept as documentation only (['Wang_2015:abstract'])</li><li>covariate category for AUC∞ from footnote/prose kept as documentation only (['Wang_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Desloratadine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 6/6 row label(s) assigned, 0 linked by role; re-tagged Desloratadine→parent ×3, Desloratadine→3-OH-desloratadine ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1900.8));
end Desloratadine_Wang2015_reference;
