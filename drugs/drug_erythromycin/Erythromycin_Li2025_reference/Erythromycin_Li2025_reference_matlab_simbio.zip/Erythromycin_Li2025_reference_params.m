function p = Erythromycin_Li2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: erythromycin   source: Li_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Erythromycin_Li2025_reference_params';
  p.drug  = 'erythromycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.6;                % central volume [L]
  p.CL = 0.186;                % clearance [L/h]
  p.Vp = [17.1];             % peripheral volumes [L]
  p.Q  = [13.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
