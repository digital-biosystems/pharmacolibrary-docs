function p = Erythromycin_Wen2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: erythromycin   source: Wen_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Erythromycin_Wen2026_reference_params';
  p.drug  = 'erythromycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 211.0;                % central volume [L]
  p.CL = 32.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.01;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
