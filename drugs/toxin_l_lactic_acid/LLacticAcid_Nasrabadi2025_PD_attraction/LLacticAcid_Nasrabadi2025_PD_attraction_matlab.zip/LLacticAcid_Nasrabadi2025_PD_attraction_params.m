function p = LLacticAcid_Nasrabadi2025_PD_attraction_params()
% LLacticAcid_Nasrabadi2025_PD_attraction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% l_lactic_acid Nasrabadi_2025::attraction: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mL/L per second, in SI inside (kg/m3, s). Response attraction in %. Driver: lactic acid (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0248;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
