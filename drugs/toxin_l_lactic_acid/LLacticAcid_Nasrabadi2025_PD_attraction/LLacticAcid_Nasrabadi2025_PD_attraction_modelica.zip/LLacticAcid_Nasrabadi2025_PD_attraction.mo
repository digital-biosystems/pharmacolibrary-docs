model LLacticAcid_Nasrabadi2025_PD_attraction
  "linear exposure-response sweep — Nasrabadi_2025 :: attraction (attraction)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.0248   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>LLacticAcid_Nasrabadi2025_PD_attraction</h4><p>The steady-state exposure-response curve of Nasrabadi M et al., <i>Journal of arthropod-borne diseases 19(2):113–124</i> 2025 (<a href=\"https://doi.org/10.18502/jad.v19i2.20190\">doi:10.18502/jad.v19i2.20190</a>) — attraction [%] against lactic acid mL/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0248          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mL/L of lactic acid per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end LLacticAcid_Nasrabadi2025_PD_attraction;
