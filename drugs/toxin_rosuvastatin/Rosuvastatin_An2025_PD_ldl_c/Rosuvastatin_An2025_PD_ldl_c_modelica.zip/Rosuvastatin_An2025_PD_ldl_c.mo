model Rosuvastatin_An2025_PD_ldl_c
  "indirect_response_i exposure-response sweep — An_2025 :: LDL-C (LDL-C)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.922,      // [kg/m3; mg/dL × 0.01]
    Emax = 1,  // type I effect term
    EC50 = 4.6e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><h4>Rosuvastatin_An2025_PD_ldl_c</h4><p>The steady-state exposure-response curve of An H et al., <i>Drug design, development and therapy 19:4777-4787</i> 2025 (<a href=\"https://doi.org/10.2147/dddt.s522863\">doi:10.2147/dddt.s522863</a>) — LDL-C [mg/dL] against rosuvastatin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       92.2 mg/dL    drug-free response (baseline) (Baseline LDL, Q324)
  Emax  =          1          maximal effect term (Imax, Q323)
  EC50  =        4.6 ng/mL    exposure at half of the maximal effect term (IC50,R, Q322)
  gamma =          1          Hill coefficient (Hill, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of rosuvastatin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.922   (drug-free)
  exposure = EC50 (4.6 ng/mL)  response 0.461
  exposure -> infinity  response 0</pre></body></html>"));
end Rosuvastatin_An2025_PD_ldl_c;
