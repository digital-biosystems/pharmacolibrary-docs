function p = Rosuvastatin_An2025_PD_ldl_c_params()
% Rosuvastatin_An2025_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rosuvastatin An_2025::LDL_C: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response LDL-C in mg/dL. Driver: rosuvastatin (pk_record).
p.E0 = 0.9219999999999999;
p.Emax = 1.0;
p.EC50 = 4.599999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 46.0;
p.form = 'E0*(1 - Emax*frac)';
end
