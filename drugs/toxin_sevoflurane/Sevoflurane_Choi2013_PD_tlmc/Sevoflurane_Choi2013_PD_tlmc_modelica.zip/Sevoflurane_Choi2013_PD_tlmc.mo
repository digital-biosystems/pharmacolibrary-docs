model Sevoflurane_Choi2013_PD_tlmc
  "sigmoid_emax exposure-response sweep — Choi_2013 :: TLMC (Temporal linear mode complexity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.614,      // [1]
    Emax = -0.334,  // [1]
    EC50 = 5.48,  // [vol%]
    gamma = 1.88,
    exposure_per_s = 1);   // 1 vol% per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'vol%' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 55, Interval = 0.11),
    Documentation(info = "<html><body><h4>Sevoflurane_Choi2013_PD_tlmc</h4><p>The steady-state exposure-response curve of Choi BM et al., <i>Korean journal of anesthesiology 65(5):385-396</i> 2013 (<a href=\"https://doi.org/10.4097/kjae.2013.65.5.385\">doi:10.4097/kjae.2013.65.5.385</a>) — Temporal linear mode complexity against sevoflurane vol% — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.614          drug-free response (baseline) (E0, Q324)
  Emax  =      0.334          maximal effect term (Emax, Q323)
  EC50  =       5.48 vol%     exposure at half of the maximal effect term (Ce50, Q321)
  gamma =       1.88          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one vol% of sevoflurane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.614   (drug-free)
  exposure = EC50 (5.48 vol%)  response 0.447
  exposure -> infinity  response 0.28</pre></body></html>"));
end Sevoflurane_Choi2013_PD_tlmc;
