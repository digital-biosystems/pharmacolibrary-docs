function p = Sevoflurane_Choi2013_PD_tlmc_params()
% Sevoflurane_Choi2013_PD_tlmc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sevoflurane Choi_2013::TLMC: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one vol% per second, in SI inside (kg/m3, s). Response TLMC in its own unit. Driver: sevoflurane (cited_pk).
p.E0 = 0.614;
p.Emax = -0.334;
p.EC50 = 5.48;
p.gamma = 1.88;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 55.0;
p.form = 'E0 + Emax*frac';
end
