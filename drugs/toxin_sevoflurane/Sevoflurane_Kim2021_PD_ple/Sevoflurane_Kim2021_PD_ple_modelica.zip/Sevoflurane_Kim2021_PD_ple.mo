model Sevoflurane_Kim2021_PD_ple
  "sigmoid_emax exposure-response sweep — Kim_2021 :: PLE (Phase lag entropy)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 84.9,      // [1]
    Emax = -42,  // [1]
    EC50 = 1.81,  // [vol%]
    gamma = 4.78,
    exposure_per_s = 1);   // 1 vol% per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'vol%' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 19, Interval = 0.038),
    Documentation(info = "<html><body><h4>Sevoflurane_Kim2021_PD_ple</h4><p>The steady-state exposure-response curve of Kim KM et al., <i>Medicina (Kaunas, Lithuania) 57(10):1034</i> 2021 (<a href=\"https://doi.org/10.3390/medicina57101034\">doi:10.3390/medicina57101034</a>) — Phase lag entropy against sevoflurane vol% — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       84.9          drug-free response (baseline) (E0, Q324)
  Emax  =         42          maximal effect term (Emax, Q323)
  EC50  =       1.81 vol%     exposure at half of the maximal effect term (Ce50, Q321)
  gamma =       4.78          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one vol% of sevoflurane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 84.9   (drug-free)
  exposure = EC50 (1.81 vol%)  response 63.9
  exposure -> infinity  response 42.9</pre></body></html>"));
end Sevoflurane_Kim2021_PD_ple;
