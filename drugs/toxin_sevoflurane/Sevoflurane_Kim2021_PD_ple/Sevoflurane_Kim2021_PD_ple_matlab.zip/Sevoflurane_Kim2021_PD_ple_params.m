function p = Sevoflurane_Kim2021_PD_ple_params()
% Sevoflurane_Kim2021_PD_ple_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sevoflurane Kim_2021::PLE: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one vol% per second, in SI inside (kg/m3, s). Response PLE in its own unit. Driver: sevoflurane (cited_pk).
p.E0 = 84.9;
p.Emax = -42.0;
p.EC50 = 1.81;
p.gamma = 4.78;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 19.0;
p.form = 'E0 + Emax*frac';
end
