function p = Sevoflurane_Choi2013_PD_apen_params()
% Sevoflurane_Choi2013_PD_apen_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sevoflurane Choi_2013::ApEn: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one vol% per second, in SI inside (kg/m3, s). Response ApEn in its own unit. Driver: sevoflurane (cited_pk).
p.E0 = 0.617;
p.Emax = -0.287;
p.EC50 = 5.07;
p.gamma = 2.01;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 51.0;
p.form = 'E0 + Emax*frac';
end
