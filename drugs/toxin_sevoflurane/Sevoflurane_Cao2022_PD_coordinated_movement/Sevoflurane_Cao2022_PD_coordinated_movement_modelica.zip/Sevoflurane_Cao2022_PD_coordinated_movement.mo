model Sevoflurane_Cao2022_PD_coordinated_movement
  "sigmoid_emax exposure-response sweep — Cao_2022 :: coordinated movement (coordinated movement)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 0.0131,  // [1; % × 0.01]
    gamma = 1,
    exposure_per_s = 0.01);   // 1 % per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 14, Interval = 0.028),
    Documentation(info = "<html><body><h4>Sevoflurane_Cao2022_PD_coordinated_movement</h4><p>The steady-state exposure-response curve of Cao Y et al., <i>Dose-response : a publication of International Hormesis Society 20(1):15593258221082886</i> 2022 (<a href=\"https://doi.org/10.1177/15593258221082886\">doi:10.1177/15593258221082886</a>) — coordinated movement [%] against sevoflurane % — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q323)
  EC50  =       1.31 %        exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one % of sevoflurane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.31 %)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Sevoflurane_Cao2022_PD_coordinated_movement;
