function p = Sevoflurane_Cao2022_PD_coordinated_movement_params()
% Sevoflurane_Cao2022_PD_coordinated_movement_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sevoflurane Cao_2022::coordinated_movement: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one % per second, in SI inside (kg/m3, s). Response coordinated movement in %. Driver: sevoflurane (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.0131;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.01;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
