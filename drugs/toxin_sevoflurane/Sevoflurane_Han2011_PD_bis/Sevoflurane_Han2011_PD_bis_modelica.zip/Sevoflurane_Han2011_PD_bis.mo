model Sevoflurane_Han2011_PD_bis
  "sigmoid_emax exposure-response sweep — Han_2011 :: BIS (Bispectral index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -12.7,  // [1]
    EC50 = 1.6,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16, Interval = 0.032),
    Documentation(info = "<html><body><h4>Sevoflurane_Han2011_PD_bis</h4><p>The steady-state exposure-response curve of Han DW et al., <i>Acta pharmacologica Sinica 32(10):1208-1214</i> 2011 (<a href=\"https://doi.org/10.1038/aps.2011.99\">doi:10.1038/aps.2011.99</a>) — Bispectral index against sevoflurane — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       12.7          maximal effect term (Emax (upper plateau), Q323)
  EC50  =        1.6          exposure at half of the maximal effect term (C(eff50) (upper plateau), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of sevoflurane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.6 )  response -6.35
  exposure -> infinity  response -12.7</pre></body></html>"));
end Sevoflurane_Han2011_PD_bis;
