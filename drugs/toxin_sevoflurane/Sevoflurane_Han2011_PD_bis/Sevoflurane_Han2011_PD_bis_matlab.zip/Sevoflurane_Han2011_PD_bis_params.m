function p = Sevoflurane_Han2011_PD_bis_params()
% Sevoflurane_Han2011_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sevoflurane Han_2011::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: sevoflurane (cited_pk).
p.E0 = 0.0;
p.Emax = -12.7;
p.EC50 = 1.6;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 16.0;
p.form = 'E0 + Emax*frac';
end
