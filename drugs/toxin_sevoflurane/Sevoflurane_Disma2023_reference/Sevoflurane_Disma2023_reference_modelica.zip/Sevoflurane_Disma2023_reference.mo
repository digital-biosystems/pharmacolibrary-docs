model Sevoflurane_Disma2023_reference
  parameter Real Cl_ref = 1.1166666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.200053,
    adminMass = 1e-05,
    k12 = 0.0012017543859649123,
    k21 = 0.0009474412171507606
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sevoflurane</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Disma_2023</td></tr><tr><td>measured_compound:</td><td>sevoflurane</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sevoflurane 200.053 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Disma_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sevoflurane_Disma2023_reference;
