function p = Sevoflurane_Disma2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sevoflurane   source: Disma_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Sevoflurane_Disma2023_reference_params';
  p.drug  = 'sevoflurane';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 19.0;                % central volume [L]
  p.CL = 40.2;                % clearance [L/h]
  p.Vp = [24.1];             % peripheral volumes [L]
  p.Q  = [82.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
