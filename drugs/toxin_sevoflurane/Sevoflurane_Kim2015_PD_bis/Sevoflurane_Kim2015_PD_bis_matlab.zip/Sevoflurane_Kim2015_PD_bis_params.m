function p = Sevoflurane_Kim2015_PD_bis_params()
% Sevoflurane_Kim2015_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sevoflurane Kim_2015::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one vol% per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: End-tidal sevoflurane concentration (not_resolved).
p.E0 = 89.4;
p.Emax = -15.7;
p.EC50 = 2.2;
p.gamma = 6.6;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 22.0;
p.form = 'E0 + Emax*frac';
end
