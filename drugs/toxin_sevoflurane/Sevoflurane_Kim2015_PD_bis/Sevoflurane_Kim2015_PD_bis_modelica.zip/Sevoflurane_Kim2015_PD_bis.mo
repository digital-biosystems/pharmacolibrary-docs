model Sevoflurane_Kim2015_PD_bis
  "sigmoid_emax exposure-response sweep — Kim_2015 :: BIS (Bispectral Index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 89.4,      // [1]
    Emax = -15.7,  // [1]
    EC50 = 2.2,  // [vol%]
    gamma = 6.6,
    exposure_per_s = 1);   // 1 vol% per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'vol%' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 22, Interval = 0.044),
    Documentation(info = "<html><body><h4>Sevoflurane_Kim2015_PD_bis</h4><p>The steady-state exposure-response curve of Kim PJ et al., <i>Journal of pharmacokinetics and pharmacodynamics 42(2):123-134</i> 2015 (<a href=\"https://doi.org/10.1007/s10928-015-9405-5\">doi:10.1007/s10928-015-9405-5</a>) — Bispectral Index against End-tidal sevoflurane concentration vol% — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       89.4          drug-free response (baseline) (E0, Q324)
  Emax  =       15.7          maximal effect term (Emax, Q323)
  EC50  =        2.2 vol%     exposure at half of the maximal effect term (Ce50, Q321)
  gamma =        6.6          Hill coefficient (Gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one vol% of End-tidal sevoflurane concentration per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 89.4   (drug-free)
  exposure = EC50 (2.2 vol%)  response 81.55
  exposure -> infinity  response 73.7</pre></body></html>"));
end Sevoflurane_Kim2015_PD_bis;
