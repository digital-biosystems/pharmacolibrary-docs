model Sevoflurane_Ishibe1993_PD_hpv_response
  "sigmoid_emax exposure-response sweep — Ishibe_1993 :: HPV response (HPV response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1,      // [1; % × 0.01]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 1,  // [MAC]
    gamma = 1,
    exposure_per_s = 1);   // 1 MAC per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'MAC' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 10, Interval = 0.02),
    Documentation(info = "<html><body><h4>Sevoflurane_Ishibe1993_PD_hpv_response</h4><p>The steady-state exposure-response curve of Ishibe Y et al., <i>Anesthesiology 79(6):1348–1353</i> 1993 (<a href=\"https://doi.org/10.1097/00000542-199312000-00026\">doi:10.1097/00000542-199312000-00026</a>) — HPV response [% of baseline] against sevoflurane MAC — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        100 %        drug-free response (baseline) (E0, Q324)
  Emax  =        100 %        maximal effect term (Emax, Q323)
  EC50  =          1 MAC      exposure at half of the maximal effect term (ED50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one MAC of sevoflurane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)
  exposure = EC50 (1 MAC)  response 0.5
  exposure -> infinity  response 0</pre></body></html>"));
end Sevoflurane_Ishibe1993_PD_hpv_response;
