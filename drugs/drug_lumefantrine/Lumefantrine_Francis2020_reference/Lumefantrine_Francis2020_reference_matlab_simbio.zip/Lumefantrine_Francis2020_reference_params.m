function p = Lumefantrine_Francis2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lumefantrine   source: Francis_2020 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Lumefantrine_Francis2020_reference_params';
  p.drug  = 'lumefantrine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 60.0;                % central volume [L]
  p.CL = 3.28;                % clearance [L/h]
  p.Vp = [182.0];             % peripheral volumes [L]
  p.Q  = [0.63];             % inter-compartmental clearances [L/h]
  p.ka = 0.727;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
