model Lumefantrine_Francis2020_reference
  parameter Real Cl_ref = 9.11111111111111e-07 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Real Vd_ref = 0.06 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref + (6.333333333333332e-07)*(if cov_category_0 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5289400000000001,
    adminMass = 0.0001,
    ka = 0.00020194444444444443,
    Tlag = 0.0,
    k12 = 2.916666666666667e-06,
    k21 = 9.615384615384617e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lumefantrine</h4><p>Lumefantrine is an antimalarial drug used to treat malaria, typically in combination with artemisinin derivatives. It is an approved medicine and is widely used in antimalarial combination therapy around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q904464\">Wikidata Q904464</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lumefantrine</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Francis_2020</td></tr><tr><td>measured_compound:</td><td>lumefantrine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lumefantrine 528.94 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Intercompartmental clearance between central and second peripheral compartment (liters/h)c', value '1.55') — already have one for this compound</li><li>dropped duplicate Q64 ('Vol. of distribution of the second peripheral compartment (liters)c', value '39.1') — already have one for this compound</li><li>unit_dimension_mismatch: 'Efavirenz on CL (%)' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('Efavirenz on CL (%)', value '89.9') — already have one for this compound</li><li>unit_dimension_mismatch: 'Lopinavir-ritonavir on CL (%)' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('Lopinavir-ritonavir on CL (%)', value '-50.1') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Lopinavir-ritonavir on F (%)' — extend the ontology if this is a real PK parameter (source ['T3:row15:col1'])</li><li>dropped unlinked row (NIL): 'Lopinavir-ritonavir on Ka (%)' — extend the ontology if this is a real PK parameter (source ['T3:row16:col1'])</li><li>unit_dimension_mismatch: 'Rifampin-based TB treatment on CL (%)' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('Rifampin-based TB treatment on CL (%)', value '142') — already have one for this compound</li><li>dropped unlinked row (NIL): 'First dose in SECAT on F (%)' — extend the ontology if this is a real PK parameter (source ['T3:row18:col1'])</li><li>dropped unlinked row (NIL): 'Consecutive morning doses in SEACAT on F (%)' — extend the ontology if this is a real PK parameter (source ['T3:row19:col1'])</li><li>dropped unlinked row (NIL): 'Uganda studies on F (%)' — extend the ontology if this is a real PK parameter (source ['T3:row20:col1'])</li><li>dropped unlinked row (NIL): 'Nigeria study 1 on F (%)' — extend the ontology if this is a real PK parameter (source ['T3:row21:col1'])</li><li>dropped unlinked row (NIL): 'Delay for unobserved dose (h)d' — extend the ontology if this is a real PK parameter (source ['T3:row22:col1'])</li><li>covariate level 'Scaling factor for DBS concn (fold)e' → Q900:scaling_factor_for_dbs_concn_fold_e = 2.28 (additive_shift on Q22)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Lumefantrine_Francis2020_reference;
