% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Lumefantrine_Ding2026_nonem_estimates_rse_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
