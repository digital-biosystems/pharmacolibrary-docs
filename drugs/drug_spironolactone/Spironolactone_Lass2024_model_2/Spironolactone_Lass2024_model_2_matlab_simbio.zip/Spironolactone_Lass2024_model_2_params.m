function p = Spironolactone_Lass2024_model_2_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: spironolactone   source: Lass_2024 / model_2   route: oral
  % estimated (absent from source): F
  p.name  = 'Spironolactone_Lass2024_model_2_params';
  p.drug  = 'spironolactone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 103.0;                % central volume [L]
  p.CL = 78.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.63;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
