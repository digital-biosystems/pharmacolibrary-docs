function p = Rifampicin_Srivastava2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampicin   source: Srivastava_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Rifampicin_Srivastava2022_reference_params';
  p.drug  = 'rifampicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 285.8;                % central volume [L]
  p.CL = 23.02;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.61;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
