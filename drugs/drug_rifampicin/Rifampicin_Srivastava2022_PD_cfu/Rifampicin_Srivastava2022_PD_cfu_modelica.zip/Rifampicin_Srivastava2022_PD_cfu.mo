model Rifampicin_Srivastava2022_PD_cfu
  "sigmoid_emax exposure-response sweep — Srivastava_2022 :: CFU (M. kansasii bacterial burden)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5,  // [log10 CFU/mL]
    EC50 = 0.88,  // [×MIC]
    gamma = 1,
    exposure_per_s = 1);   // 1 ×MIC per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '×MIC' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8.8, Interval = 0.0176),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rifampicin</h4><p>Rifampicin is an antibiotic used to treat tuberculosis, including pulmonary and miliary disease and tuberculous meningitis, as well as leprosy and some staphylococcal infections. It is widely used worldwide and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422652\">Wikidata Q422652</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rifampicin_Srivastava2022_PD_cfu</h4><p>The steady-state exposure-response curve of Srivastava S et al., <i>Antimicrobial agents and chemotherapy 66(4):e0232021</i> 2022 (<a href=\"https://doi.org/10.1128/aac.02320-21\">doi:10.1128/aac.02320-21</a>) — M. kansasii bacterial burden [log10 CFU/mL] against rifampin ×MIC — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          5 log10 CFU/mL maximal effect term (Emax, Q323)
  EC50  =       0.88 ×MIC     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ×MIC of rifampin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.88 ×MIC)  response -2.5
  exposure -> infinity  response -5</pre></body></html>"));
end Rifampicin_Srivastava2022_PD_cfu;
