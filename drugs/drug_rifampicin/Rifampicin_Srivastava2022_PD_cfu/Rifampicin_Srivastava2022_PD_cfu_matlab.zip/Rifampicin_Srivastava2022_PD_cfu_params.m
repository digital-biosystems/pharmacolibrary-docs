function p = Rifampicin_Srivastava2022_PD_cfu_params()
% Rifampicin_Srivastava2022_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampicin Srivastava_2022::CFU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ×MIC per second, in SI inside (kg/m3, s). Response CFU in log10 CFU/mL. Driver: rifampin (not_resolved).
p.E0 = 0.0;
p.Emax = -5.0;
p.EC50 = 0.88;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 8.8;
p.form = 'E0 + Emax*frac';
end
