function p = Rifampicin_Ngo2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampicin   source: Ngo_2024 / reference   route: oral
  p.name  = 'Rifampicin_Ngo2024_reference_params';
  p.drug  = 'rifampicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.3;                % central volume [L]
  p.CL = 19.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.61;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
