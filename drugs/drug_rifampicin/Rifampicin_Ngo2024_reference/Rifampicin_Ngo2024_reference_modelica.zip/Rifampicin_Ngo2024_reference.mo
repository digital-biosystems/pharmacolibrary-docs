model Rifampicin_Ngo2024_reference
  parameter Real Cl_ref = 5.444444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0493 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8229529999999999,
    adminMass = 0.0006,
    ka = 0.0004472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rifampicin</h4><p>Rifampicin is an antibiotic used to treat tuberculosis, including pulmonary and miliary disease and tuberculous meningitis, as well as leprosy and some staphylococcal infections. It is widely used worldwide and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422652\">Wikidata Q422652</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifampicin</td></tr><tr><td>population:</td><td>adults with tuberculosis</td></tr><tr><td>source_paper:</td><td>Ngo_2024</td></tr><tr><td>measured_compound:</td><td>rifampicin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ciae119-T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifampicin 822.953 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV CL/F' routed out of structural estimates ('Interindividual variability,c %')</li><li>table section iiv: 'IIV CL/F' routed out of structural estimates ('Interindividual variability,c %')</li><li>table section iiv: 'IIV V/F' routed out of structural estimates ('Interindividual variability,c %')</li><li>table section iiv: 'IIV V/F' routed out of structural estimates ('Interindividual variability,c %')</li><li>table section iiv: 'IIV MTT' routed out of structural estimates ('Interindividual variability,c %')</li><li>table section iiv: 'IIV MTT' routed out of structural estimates ('Interindividual variability,c %')</li><li>table section covariance: 'CL/F-V/F' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'CL/F-V/F' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'CL/F-MTT' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'CL/F-MTT' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'V/F-MTT' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'V/F-MTT' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'εprop in log scale' routed out of structural estimates ('Correlation,c %')</li><li>table section covariance: 'εprop in log scale' routed out of structural estimates ('Correlation,c %')</li><li>dropped unlinked row (NIL): 'Asian relative to Black/mixed race' — extend the ontology if this is a real PK parameter (source ['ciae119-T2:row5:col1', 'ciae119-T2:row5:col2'])</li><li>dropped unlinked row (NIL): 'Female relative to male' — extend the ontology if this is a real PK parameter (source ['ciae119-T2:row6:col1', 'ciae119-T2:row6:col2', 'ciae119-T2:row8:col1', 'ciae119-T2:row8:col2'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rifampicin_Ngo2024_reference;
