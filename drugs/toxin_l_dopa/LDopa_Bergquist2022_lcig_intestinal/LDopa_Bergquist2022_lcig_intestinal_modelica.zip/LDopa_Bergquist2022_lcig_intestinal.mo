// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model LDopa_Bergquist2022_lcig_intestinal
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {32400.0},
    MM = 0.19719,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_dopa</td></tr><tr><td>population:</td><td>Patients with advanced Parkinson disease</td></tr><tr><td>source_paper:</td><td>Bergquist_2022</td></tr><tr><td>measured_compound:</td><td>Levodopa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Levodopa 197.19 g/mol (pubchem); l_dopa 197.19 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Bergquist_2022_table_1: rows are variants (DIZ102 (s.c.), LCIG (intestinal), DIZ101 (i.v.)), the parameters are the column headers (tmax (h) median (min, max)) — read one record per variant</li><li>salvaged Q57 ('t½'=9) from results prose — parameter table was unreadable</li><li>implicit units: 't½' → h (from the popPK convention: &quot;Parameter is half-life (t1/2). The text states 't/2 was longer for DIZ102 compared with LCIG' but does not explicitly st&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levodopa</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>estimate-method split: 'LCIG (intestinal)' is one of 3 estimates of Bergquist_2022's substance matrix (DIZ102 (s.c.), LCIG (intestinal), DIZ101 (i.v.)); same population, different estimation method</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 324.0));
end LDopa_Bergquist2022_lcig_intestinal;
