// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model LDopa_LeWitt2022_study_002
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7200.0},
    MM = 0.19719,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_dopa</td></tr><tr><td>population:</td><td>Healthy volunteers and patients with Parkinson's disease</td></tr><tr><td>source_paper:</td><td>LeWitt_2022</td></tr><tr><td>measured_compound:</td><td>L-Dopa (Levodopa)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>L-Dopa (Levodopa) 197.19 g/mol (pubchem); l_dopa 197.19 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Regimen' — extend the ontology if this is a real PK parameter (source ['T2:row1:col4', 'T2:row3:col4', 'T2:row4:col4', 'T2:row6:col4', 'T2:row7:col4', 'T2:row8:col4', 'T2:row9:col4', 'T2:row10:col4'])</li><li>dropped unlinked row (NIL): 'Tmax (h) median (range)' — extend the ontology if this is a real PK parameter (source ['T2:row1:col6', 'T2:row3:col6', 'T2:row4:col6', 'T2:row6:col6', 'T2:row7:col6', 'T2:row8:col6', 'T2:row9:col6', 'T2:row10:col6', 'T2:row11:col6'])</li><li>salvaged Q57 ('plasma half-life'=120) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=L-Dopa (Levodopa)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: plasma half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>population split: 'study 002' subgroup of LeWitt_2022 (paper reports 4 populations: regimen, study 002, study 003*, study 004**)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end LDopa_LeWitt2022_study_002;
