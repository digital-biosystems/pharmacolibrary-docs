// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model LDopa_LeWitt2023v2_fed
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6444.0},
    MM = 0.19719,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_dopa</td></tr><tr><td>population:</td><td>patients with PD and healthy subjects</td></tr><tr><td>source_paper:</td><td>LeWitt_2023_2</td></tr><tr><td>measured_compound:</td><td>Levodopa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t0010</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Levodopa 197.19 g/mol (pubchem); l_dopa 197.19 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'Tmax (h)'; source reconciliation required</li><li>table representations disagree for 'T1/2 (h)'; source reconciliation required</li><li>table representations disagree for 'AUC0-t (h ⋅ ng/mL)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levodopa</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'fed' subgroup of LeWitt_2023_2 (paper reports 3 populations: fasted, fed, sprinkled on applesauce)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end LDopa_LeWitt2023v2_fed;
