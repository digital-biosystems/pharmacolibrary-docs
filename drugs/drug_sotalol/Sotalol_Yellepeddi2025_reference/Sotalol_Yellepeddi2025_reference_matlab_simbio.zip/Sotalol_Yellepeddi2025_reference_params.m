function p = Sotalol_Yellepeddi2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sotalol   source: Yellepeddi_2025 / reference   route: oral
  p.name  = 'Sotalol_Yellepeddi2025_reference_params';
  p.drug  = 'sotalol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.2;                % central volume [L]
  p.CL = 9.5;                % clearance [L/h]
  p.Vp = [89.1];             % peripheral volumes [L]
  p.Q  = [71.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.2;                % absorption rate [1/h]
  p.F  = 0.016;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
