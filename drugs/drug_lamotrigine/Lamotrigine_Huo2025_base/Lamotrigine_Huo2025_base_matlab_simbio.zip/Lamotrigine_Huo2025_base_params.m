function p = Lamotrigine_Huo2025_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Huo_2025 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'Lamotrigine_Huo2025_base_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 68.8;                % central volume [L]
  p.CL = 3.43;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.93;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
