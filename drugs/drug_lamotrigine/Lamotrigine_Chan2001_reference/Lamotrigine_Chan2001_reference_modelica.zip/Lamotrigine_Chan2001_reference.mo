model Lamotrigine_Chan2001_reference
  parameter Real Cl_ref = 5.944444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 5.4670000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.256091,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lamotrigine</h4><p>Lamotrigine is an anticonvulsant used to treat epilepsy and bipolar disorder, and has also been used for other neurological and psychiatric conditions. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410346\">Wikidata Q410346</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>patients receiving oral lamotrigine therapy</td></tr><tr><td>source_paper:</td><td>Chan_2001</td></tr><tr><td>measured_compound:</td><td>lamotrigine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.091 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for IIV from footnote/prose kept as documentation only (['Chan_2001:abstract'])</li><li>covariate category for IOV from footnote/prose kept as documentation only (['Chan_2001:abstract'])</li><li>dropped unlinked row (NIL): 'The covariates of concomitant valproate and phenytoin therapy' — extend the ontology if this is a real PK parameter (source ['Chan_2001:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lamotrigine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Chan2001_reference;
