model Lamotrigine_Karanam2025_reference
  parameter Real Cl_ref = 8.055555555555555e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>women with epilepsy during pregnancy and postpartum, plus nonpregnant women with epilepsy</td></tr><tr><td>source_paper:</td><td>Karanam_2025</td></tr><tr><td>measured_compound:</td><td>lamotrigine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q76 ('nonpregnant V/F'=130) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('nonpregnant CL/F'=2.9) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('nonpregnant clearance'=0.33) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lamotrigine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Karanam2025_reference;
