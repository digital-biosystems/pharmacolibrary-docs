function p = Cetirizine_Spick1997_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cetirizine   source: Spicák_1997 / reference   route: oral
  p.name  = 'Cetirizine_Spick1997_reference_params';
  p.drug  = 'cetirizine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 30.8;                % central volume [L]
  p.CL = 8.946;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.095;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
