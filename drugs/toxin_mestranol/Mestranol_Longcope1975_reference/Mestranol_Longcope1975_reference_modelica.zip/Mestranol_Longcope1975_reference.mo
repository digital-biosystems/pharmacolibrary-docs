// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Mestranol_Longcope1975_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {50.1699894449018},
    MM = 0.310437,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mestranol</td></tr><tr><td>population:</td><td>non-users and users of oral contraceptives</td></tr><tr><td>source_paper:</td><td>Longcope_1975</td></tr><tr><td>measured_compound:</td><td>Mestranol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Ethinyl estradiol 296.41 g/mol (pubchem); Mestranol 310.437 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'overall mean plus or minus SE metabolic clearance rate (MCRM)' Q354 → Q47: a rate constant in '1/day/m2' (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'mean ratio of the concentrations of radioactivity as EE following administration of ME (CRM-BB,E)' — extend the ontology if this is a real PK parameter (source ['Longcope_1975:abstract'])</li><li>unit_dimension_unknown: 'fraction of administered ME measured in blood as EE' (fm)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mestranol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 1 linked by role; re-tagged Mestranol→parent ×1, Mestranol→Ethinyl estradiol ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Mestranol_Longcope1975_reference;
