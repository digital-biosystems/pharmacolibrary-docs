model Amifampridine_Thakkar2017_reference
  parameter Real Cl_ref = 2.4999999999999998e-05 "Cl [m3/s]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  parameter Real Vd_ref = 0.024 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_weight/1.0)^(0.7),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.109132,
    adminMass = 5e-06,
    ka = 0.00025,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amifampridine</h4><p>Amifampridine is a potassium channel blocker used primarily to treat Lambert-Eaton myasthenic syndrome and myasthenia gravis. It is taken orally in tablet form and is well absorbed by the gut. The drug is authorized in the European Union and is available for use in the United States, where it has orphan and breakthrough therapy designations.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411707\">Wikidata Q411707</a>, <a href=\"https://en.wikipedia.org/wiki/Amifampridine?oldid=1337381039\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amifampridine</td></tr><tr><td>population:</td><td>adults with Lambert-Eaton myasthenia</td></tr><tr><td>source_paper:</td><td>Thakkar_2017</td></tr><tr><td>measured_compound:</td><td>3,4-diaminopyridine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412218-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>3,4-diaminopyridine 109.132 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>PK_3M template not built: formation of 3-N-acetyl-3,4-diaminopyridine is not quantified (no CLfm, fm, kfm)</li><li>PK_3M template not built: formation of 3-N-acetyl-3,4-diaminopyridine is not quantified (no CLfm, fm, kfm)</li><li>compound tags: 12 row(s) → 3-N-acetyl-3,4-diaminopyridine (m_suffix 12)</li><li>table section iiv: 'Ka, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Vc/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Q/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Vp/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CLm/F3AcDAP, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F-Vc/F covarianced' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section residual_error: '3,4-DAP proportional error, %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: '3-Ac DAP proportional error, %' routed out of structural estimates ('Residual error')</li><li>covariate level 'Exponent for SCR on CLm/F3AcDAPc' → Q900:exponent_for_scr_on_clm_f3acdapc = 0.7 (power on Q27)</li><li>dropped value-less row: '3‐Ac DAP'</li><li>dropped value-less row: '3,4‐DAP'</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['psp412218-tbl-0002:footnote']); the table cell was unparseable — needs review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amifampridine_Thakkar2017_reference;
