model Rifampin_Svensson2016_PD_cfu
  "emax exposure-response sweep — Svensson_2016 :: CFU (CFU)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.04,  // [FIX]
    EC50 = 7.05e-05,  // [kg/m3; mg · L−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg · L−1 per second
  // family_inferred: the record's model family is unknown; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.71, Interval = 0.00142),
    Documentation(info = "<html><body><h4>Rifampin_Svensson2016_PD_cfu</h4><p>The steady-state exposure-response curve of Svensson RJ et al., <i>CPT: pharmacometrics &amp; systems pharmacology 5(5):264–273</i> 2016 (<a href=\"https://doi.org/10.1002/psp4.12079\">doi:10.1002/psp4.12079</a>) — CFU [log-10 CFU/ml] against rifampicin mg · L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.04 FIX      maximal effect term (Emax, Q320)
  EC50  =     0.0705 mg · L−1 exposure at half of the maximal effect term (EC50 (mg · L−1), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg · L−1 of rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0705 mg · L−1)  response -0.52
  exposure -> infinity  response -1.04</pre></body></html>"));
end Rifampin_Svensson2016_PD_cfu;
