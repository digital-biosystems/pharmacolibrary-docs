function p = Rifampin_Svensson2016_PD_cfu_params()
% Rifampin_Svensson2016_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Svensson_2016::CFU: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg · L−1 per second, in SI inside (kg/m3, s). Response CFU in log-10 CFU/ml. Driver: rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = -1.04;
p.EC50 = 7.049999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.71;
p.form = 'E0 + Emax*frac';
end
