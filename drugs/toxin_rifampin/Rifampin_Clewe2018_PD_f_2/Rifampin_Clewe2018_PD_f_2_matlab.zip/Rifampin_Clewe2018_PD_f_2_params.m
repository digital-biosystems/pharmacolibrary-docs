function p = Rifampin_Clewe2018_PD_f_2_params()
% Rifampin_Clewe2018_PD_f_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Clewe_2018::F::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L−1 per second, in SI inside (kg/m3, s). Response F in cfu. Driver: rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = 2.2800925925925923e-05;
p.EC50 = 3.0299999999999994e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.031;
p.form = 'E0 + Emax*frac';
end
