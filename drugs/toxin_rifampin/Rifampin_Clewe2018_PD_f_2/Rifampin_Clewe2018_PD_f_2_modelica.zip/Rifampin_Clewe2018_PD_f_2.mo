model Rifampin_Clewe2018_PD_f_2
  "emax exposure-response sweep — Clewe_2018 :: F (fast-multiplying bacterial state kill rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.28009259259e-05,  // [1/s; days-1 × 1.15741e-05]
    EC50 = 3.03e-06,  // [kg/m3; mg·L−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg·L−1 per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.031, Interval = 6.2e-05),
    Documentation(info = "<html><body><h4>Rifampin_Clewe2018_PD_f_2</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>The Journal of antimicrobial chemotherapy 73(2):437–447</i> 2018 (<a href=\"https://doi.org/10.1093/jac/dkx380\">doi:10.1093/jac/dkx380</a>) — fast-multiplying bacterial state kill rate [cfu] against rifampicin mg·L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.97 days-1   maximal effect term (EmaxRIFFD, Q320)
  EC50  =    0.00303 mg·L−1   exposure at half of the maximal effect term (EC50RIFFD, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L−1 of rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.00303 mg·L−1)  response 1.14e-05
  exposure -> infinity  response 2.28e-05</pre></body></html>"));
end Rifampin_Clewe2018_PD_f_2;
