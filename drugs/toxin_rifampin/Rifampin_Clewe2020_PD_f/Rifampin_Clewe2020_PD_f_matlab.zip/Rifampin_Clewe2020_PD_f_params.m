function p = Rifampin_Clewe2020_PD_f_params()
% Rifampin_Clewe2020_PD_f_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Clewe_2020::F: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response F in mL−1. Driver: rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = -2.4884259259259258e-05;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 17.000000000000004;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
