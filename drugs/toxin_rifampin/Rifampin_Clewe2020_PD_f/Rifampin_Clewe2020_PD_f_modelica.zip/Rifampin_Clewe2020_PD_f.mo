model Rifampin_Clewe2020_PD_f
  "linear exposure-response sweep — Clewe_2020 :: F (Fast-multiplying bacterial state (CFU))"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 17,  // [meter ** 3 / kilogram; L·mg−1 × 1000]
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Rifampin_Clewe2020_PD_f</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>Journal of pharmacokinetics and pharmacodynamics 47(5):421–430</i> 2020 (<a href=\"https://doi.org/10.1007/s10928-020-09694-0\">doi:10.1007/s10928-020-09694-0</a>) — Fast-multiplying bacterial state (CFU) [mL−1] against rifampicin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.15 days−1   maximal effect term (Maximum achievable drug-induced fast-multiplying state kill rate, Q323)
  slope =      0.017 L·mg−1   change in response per unit of exposure (Linear drug induced inhibition of fast-multiplying state growth, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/L of rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Rifampin_Clewe2020_PD_f;
