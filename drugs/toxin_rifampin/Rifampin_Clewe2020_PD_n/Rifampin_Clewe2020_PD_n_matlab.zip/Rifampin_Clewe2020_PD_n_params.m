function p = Rifampin_Clewe2020_PD_n_params()
% Rifampin_Clewe2020_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Clewe_2020::N: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L−1 per second, in SI inside (kg/m3, s). Response N in mL−1. Driver: rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = -2.986111111111111e-05;
p.EC50 = 0.03942;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 400.0;
p.form = 'E0 + Emax*frac';
end
