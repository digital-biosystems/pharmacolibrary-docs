model Rifampin_Phyo2026_initiation_phase_day_1
  parameter Real Cl_ref = 1.85e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0383 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8229,
    adminMass = 7.5e-05,
    ka = 1.6782407407407408e-07,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifampin</td></tr><tr><td>population:</td><td>adults with sputum-positive pulmonary TB, HIV-positive and HIV-negative</td></tr><tr><td>source_paper:</td><td>Phyo_2026</td></tr><tr><td>measured_compound:</td><td>Rifampin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tmi70165-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifampin 822.9 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'hr×µg/mL' (AUC)</li><li>dropped duplicate Q32 ('CMAX (µg /mL)', value '34.6') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Rifampin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'initiation phase (day 1)(n = 56)' subgroup of Phyo_2026 (paper reports 7 populations: initiation phase (day 1) hiv-negative (n = 36), initiation phase (day 1) hiv-positive (n = 24), initiation phase (day 1)(n = 56), patients with hiv (n=24), steady state (week 6) hiv-negative (n = 35), steady state (week 6) hiv-positive (n = 21), steady state (week 6)(n = 56))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Clewe_2018's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zahir_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Rifampin_Phyo2026_initiation_phase_day_1;
