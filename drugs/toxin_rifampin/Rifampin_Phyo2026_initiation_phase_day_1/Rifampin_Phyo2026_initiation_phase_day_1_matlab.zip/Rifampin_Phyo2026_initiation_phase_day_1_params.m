function p = Rifampin_Phyo2026_initiation_phase_day_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampin   source: Phyo_2026 / initiation_phase_day_1   route: oral
  p.name  = 'Rifampin_Phyo2026_initiation_phase_day_1_params';
  p.drug  = 'rifampin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.3;                % central volume [L]
  p.CL = 6.66;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.000604;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
