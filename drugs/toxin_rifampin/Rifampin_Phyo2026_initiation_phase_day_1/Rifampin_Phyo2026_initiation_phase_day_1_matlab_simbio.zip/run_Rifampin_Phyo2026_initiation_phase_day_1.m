% Run (SimBiology): build model + dose, simulate 0..4320.0 h, plot.
p = Rifampin_Phyo2026_initiation_phase_day_1_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4320.0);
