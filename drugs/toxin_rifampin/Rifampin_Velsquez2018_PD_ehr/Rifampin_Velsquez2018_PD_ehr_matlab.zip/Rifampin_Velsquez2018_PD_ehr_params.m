function p = Rifampin_Velsquez2018_PD_ehr_params()
% Rifampin_Velsquez2018_PD_ehr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Velásquez_2018::EHR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC per second, in SI inside (kg/m3, s). Response EHR in log10 cfu/ml/d. Driver: rifampin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.011;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
