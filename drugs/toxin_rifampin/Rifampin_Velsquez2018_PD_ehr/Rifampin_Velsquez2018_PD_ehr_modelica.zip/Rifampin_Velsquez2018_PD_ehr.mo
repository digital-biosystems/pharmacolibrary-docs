model Rifampin_Velsquez2018_PD_ehr
  "linear exposure-response sweep — Velásquez_2018 :: EHR (elimination rate of Mycobacterium tuberculosis)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -0.011,  // [log10 cfu/ml/d]
    exposure_per_s = 1);   // 1 AUC per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Rifampin_Velsquez2018_PD_ehr</h4><p>The steady-state exposure-response curve of Velásquez GE et al., <i>American journal of respiratory and critical care medicine 198(5):657-666</i> 2018 (<a href=\"https://doi.org/10.1164/rccm.201712-2524oc\">doi:10.1164/rccm.201712-2524oc</a>) — elimination rate of Mycobacterium tuberculosis [log10 cfu/ml/d] against rifampin AUC — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -0.011 log10 cfu/ml/d change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one AUC of rifampin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Rifampin_Velsquez2018_PD_ehr;
