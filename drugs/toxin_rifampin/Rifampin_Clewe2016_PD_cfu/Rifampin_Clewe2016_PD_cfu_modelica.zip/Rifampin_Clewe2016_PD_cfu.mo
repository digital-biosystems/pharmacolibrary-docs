model Rifampin_Clewe2016_PD_cfu
  "emax exposure-response sweep — Clewe_2016 :: cfu (log10 cfu (viable bacterial count in fast-, slow-, and non-multiplying states))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.48842592593e-05,  // [1/s; days⁻¹ × 1.15741e-05]
    EC50 = 0.00052,  // [kg/m3; mg·L⁻¹ × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg·L⁻¹ per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.2, Interval = 0.0104),
    Documentation(info = "<html><body><h4>Rifampin_Clewe2016_PD_cfu</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>The Journal of antimicrobial chemotherapy 71(4):964–974</i> 2016 (<a href=\"https://doi.org/10.1093/jac/dkv416\">doi:10.1093/jac/dkv416</a>) — log10 cfu (viable bacterial count in fast-, slow-, and non-multiplying states) [log10 cfu/mL] against Rifampicin mg·L⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.15 days⁻¹   maximal effect term (Maximum achievable drug-induced fast-multiplying state kill rate, Q323)
  EC50  =       0.52 mg·L⁻¹   exposure at half of the maximal effect term (Concentration at 50% of FDEmax, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L⁻¹ of Rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.52 mg·L⁻¹)  response -1.244e-05
  exposure -> infinity  response -2.488e-05</pre></body></html>"));
end Rifampin_Clewe2016_PD_cfu;
