function p = Rifampin_Clewe2016_PD_cfu_params()
% Rifampin_Clewe2016_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Clewe_2016::cfu: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L⁻¹ per second, in SI inside (kg/m3, s). Response cfu in log10 cfu/mL. Driver: Rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = -2.4884259259259258e-05;
p.EC50 = 0.00052;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.2;
p.form = 'E0 + Emax*frac';
end
