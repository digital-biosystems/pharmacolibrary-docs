model Rifampin_Clewe2020_PD_s
  "emax exposure-response sweep — Clewe_2020 :: S (Slow-multiplying bacterial state (CFU))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.44212962963e-05,  // [1/s; days−1 × 1.15741e-05]
    EC50 = 0.0134,  // [kg/m3; mg·L−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg·L−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><h4>Rifampin_Clewe2020_PD_s</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>Journal of pharmacokinetics and pharmacodynamics 47(5):421–430</i> 2020 (<a href=\"https://doi.org/10.1007/s10928-020-09694-0\">doi:10.1007/s10928-020-09694-0</a>) — Slow-multiplying bacterial state (CFU) [mL−1] against rifampicin mg·L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.11 days−1   maximal effect term (Maximum achievable drug-induced slow-multiplying state kill rate, Q323)
  EC50  =       13.4 mg·L−1   exposure at half of the maximal effect term (Concentration at 50% of SDEmax, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L−1 of rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13.4 mg·L−1)  response -1.221e-05
  exposure -> infinity  response -2.442e-05</pre></body></html>"));
end Rifampin_Clewe2020_PD_s;
