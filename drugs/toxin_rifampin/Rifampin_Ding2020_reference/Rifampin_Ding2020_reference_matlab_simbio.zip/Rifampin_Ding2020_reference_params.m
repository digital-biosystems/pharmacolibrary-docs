function p = Rifampin_Ding2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampin   source: Ding_2020 / reference   route: oral
  p.name  = 'Rifampin_Ding2020_reference_params';
  p.drug  = 'rifampin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 96.7;                % central volume [L]
  p.CL = 10.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.000604;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
