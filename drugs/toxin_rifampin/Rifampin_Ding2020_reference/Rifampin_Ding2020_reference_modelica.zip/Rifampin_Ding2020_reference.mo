model Rifampin_Ding2020_reference
  parameter Real Cl_ref = 2.8055555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09670000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8229,
    adminMass = 0.0007,
    ka = 1.6782407407407408e-07,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifampin</td></tr><tr><td>population:</td><td>patients with tuberculous meningitis</td></tr><tr><td>source_paper:</td><td>Ding_2020</td></tr><tr><td>measured_compound:</td><td>Rifampin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt1783-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifampin 822.9 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'F (%)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'MTT (hour)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'CL/F (L/hour)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'Q/F (L/hour)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'F (%)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'MTT (hour)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'CLslow/F (L/hour)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'Q/F (L/hour)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>dropped PD-category row 'Emax' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['cpt1783-tbl-0001:row6:col1'])</li><li>dropped PD-category row 'EC50 (mg/L)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['cpt1783-tbl-0001:row7:col1'])</li><li>dropped unlinked row (NIL): 'ED50 (mg)' — extend the ontology if this is a real PK parameter (source ['cpt1783-tbl-0001:row10:col1'])</li><li>dropped unlinked row (NIL): 'PC' — extend the ontology if this is a real PK parameter (source ['cpt1783-tbl-0001:row13:col1', 'Ding_2020_table_2:row9:col1', 'cpt1783-tbl-0001:footnote'])</li><li>dropped unlinked row (NIL): 'CSF protein on PC (%)' — extend the ontology if this is a real PK parameter (source ['cpt1783-tbl-0001:row17:col1'])</li><li>dropped duplicate Q27 ('CLslow/F (L/hour)', value '18.1') — already have one for this compound</li><li>dropped duplicate Q27 ('CLfast/F (L/hour)', value '40.7') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Rifampin_Ding2020_reference;
