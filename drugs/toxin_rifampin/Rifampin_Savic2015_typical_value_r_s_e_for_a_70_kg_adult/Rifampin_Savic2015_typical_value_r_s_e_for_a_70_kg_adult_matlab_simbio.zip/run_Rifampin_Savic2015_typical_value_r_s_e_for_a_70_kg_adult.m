% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Rifampin_Savic2015_typical_value_r_s_e_for_a_70_kg_adult_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
