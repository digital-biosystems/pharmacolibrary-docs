function p = Rifampin_Savic2015_typical_value_r_s_e_for_a_70_kg_adult_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampin   source: Savic_2015 / typical_value_r_s_e_for_a_70_kg_adult   route: oral
  p.name  = 'Rifampin_Savic2015_typical_value_r_s_e_for_a_70_kg_adult_params';
  p.drug  = 'rifampin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.9;                % central volume [L]
  p.CL = 5.71;                % clearance [L/h]
  p.Vp = [12.4];             % peripheral volumes [L]
  p.Q  = [9.46];             % inter-compartmental clearances [L/h]
  p.ka = 0.644;                % absorption rate [1/h]
  p.F  = 0.6;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
