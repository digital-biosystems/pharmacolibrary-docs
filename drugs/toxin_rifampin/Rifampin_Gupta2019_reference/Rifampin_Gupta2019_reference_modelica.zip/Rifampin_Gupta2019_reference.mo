model Rifampin_Gupta2019_reference
  parameter Real Cl_ref = 5.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005025387725763222 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8229,
    adminMass = 0.0006
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifampin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gupta_2019</td></tr><tr><td>measured_compound:</td><td>rifampin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rifampin 822.9 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gupta_2019) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rifampin_Gupta2019_reference;
