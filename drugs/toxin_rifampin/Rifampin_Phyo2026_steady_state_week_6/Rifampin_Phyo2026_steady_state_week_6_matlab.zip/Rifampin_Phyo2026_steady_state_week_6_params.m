function p = Rifampin_Phyo2026_steady_state_week_6_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampin   source: Phyo_2026 / steady_state_week_6   route: oral
  p.name  = 'Rifampin_Phyo2026_steady_state_week_6_params';
  p.drug  = 'rifampin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 41.8;                % central volume [L]
  p.CL = 13.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.000604;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
