function p = Rifampin_Svensson2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampin   source: Svensson_2016 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Rifampin_Svensson2016_reference_params';
  p.drug  = 'rifampin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 86.7;                % central volume [L]
  p.CL = 10.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
