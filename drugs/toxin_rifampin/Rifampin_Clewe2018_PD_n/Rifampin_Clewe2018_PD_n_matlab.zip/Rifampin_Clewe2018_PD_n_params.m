function p = Rifampin_Clewe2018_PD_n_params()
% Rifampin_Clewe2018_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Clewe_2018::N: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg L-1 per second, in SI inside (kg/m3, s). Response N in cfu. Driver: rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 3.8078703703703704e-05;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
