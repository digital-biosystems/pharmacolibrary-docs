model Rifampin_Clewe2018_PD_n
  "linear exposure-response sweep — Clewe_2018 :: N (non-multiplying bacterial state kill rate)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 3.80787037037e-05,  // [1 / second; days-1 × 1.15741e-05]
    exposure_per_s = 0.001);   // 1 mg L-1 per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Rifampin_Clewe2018_PD_n</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>The Journal of antimicrobial chemotherapy 73(2):437–447</i> 2018 (<a href=\"https://doi.org/10.1093/jac/dkx380\">doi:10.1093/jac/dkx380</a>) — non-multiplying bacterial state kill rate [cfu] against rifampicin mg L-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       3.29 days-1   change in response per unit of exposure (kRIFND, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg L-1 of rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Rifampin_Clewe2018_PD_n;
