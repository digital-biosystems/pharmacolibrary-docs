model Rifampin_Savic2015_typical_value_r_s_e_for_a_14_kg_child
  parameter Real Cl_ref = 1.5083333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0254 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8229,
    adminMass = 0.0006,
    ka = 0.0004972222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifampin</td></tr><tr><td>population:</td><td>adults with tuberculous meningitis; children</td></tr><tr><td>source_paper:</td><td>Savic_2015</td></tr><tr><td>measured_compound:</td><td>Rifampin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifampin 822.9 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV - CL (%)' routed out of structural estimates ('Between-Subject Variability (BSV)')</li><li>table section iiv: 'BSV - V (%)' routed out of structural estimates ('Between-Subject Variability (BSV)')</li><li>table section iiv: 'BSV - ka (%)' routed out of structural estimates ('Between-Subject Variability (BSV)')</li><li>table section residual_error: 'Additive mg/L' routed out of structural estimates ('Residual Error')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual Error')</li><li>table section covariance: 'CL-V' routed out of structural estimates ('Correlation')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Rifampin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'typical value (r.s.e) for a 14 kg child' subgroup of Savic_2015 (paper reports 2 populations: typical value (r.s.e) for a 14 kg child, typical value (r.s.e) for a 70 kg adult)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rifampin_Savic2015_typical_value_r_s_e_for_a_14_kg_child;
