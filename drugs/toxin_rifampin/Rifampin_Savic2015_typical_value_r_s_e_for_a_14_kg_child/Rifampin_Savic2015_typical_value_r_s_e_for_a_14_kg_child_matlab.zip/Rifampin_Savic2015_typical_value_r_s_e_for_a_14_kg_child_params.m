function p = Rifampin_Savic2015_typical_value_r_s_e_for_a_14_kg_child_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifampin   source: Savic_2015 / typical_value_r_s_e_for_a_14_kg_child   route: oral
  p.name  = 'Rifampin_Savic2015_typical_value_r_s_e_for_a_14_kg_child_params';
  p.drug  = 'rifampin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.4;                % central volume [L]
  p.CL = 5.43;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.79;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
