model Rifampin_Clewe2018_PD_f
  "sigmoid_emax exposure-response sweep — Clewe_2018 :: F (fast-multiplying bacterial state growth)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.15740740741e-05,  // [1/s; days-1 × 1.15741e-05]
    EC50 = 0.000388,  // [kg/m3; mg·L−1 × 0.001]
    gamma = 2.8,
    exposure_per_s = 0.001);   // 1 mg·L−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 3.9, Interval = 0.0078),
    Documentation(info = "<html><body><h4>Rifampin_Clewe2018_PD_f</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>The Journal of antimicrobial chemotherapy 73(2):437–447</i> 2018 (<a href=\"https://doi.org/10.1093/jac/dkx380\">doi:10.1093/jac/dkx380</a>) — fast-multiplying bacterial state growth [cfu] against rifampicin mg·L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1 days-1   maximal effect term (EmaxRFG, Q323)
  EC50  =      0.388 mg·L−1   exposure at half of the maximal effect term (EC50RIFFG, Q321)
  gamma =        2.8          Hill coefficient (Hill, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L−1 of rifampicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.388 mg·L−1)  response -5.787e-06
  exposure -> infinity  response -1.157e-05</pre></body></html>"));
end Rifampin_Clewe2018_PD_f;
