function p = Rifampin_Clewe2018_PD_f_params()
% Rifampin_Clewe2018_PD_f_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifampin Clewe_2018::F: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L−1 per second, in SI inside (kg/m3, s). Response F in cfu. Driver: rifampicin (cited_pk).
p.E0 = 0.0;
p.Emax = -1.1574074074074073e-05;
p.EC50 = 0.00038799999999999994;
p.gamma = 2.8;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.9;
p.form = 'E0 + Emax*frac';
end
