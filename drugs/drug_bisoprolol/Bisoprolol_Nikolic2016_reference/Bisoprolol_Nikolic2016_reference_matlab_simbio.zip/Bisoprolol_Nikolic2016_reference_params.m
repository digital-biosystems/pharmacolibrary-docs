function p = Bisoprolol_Nikolic2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bisoprolol   source: Nikolic_2016 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Bisoprolol_Nikolic2016_reference_params';
  p.drug  = 'bisoprolol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 44.8;                % central volume [L]
  p.CL = 0.12;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.25;             % dose [mg]
end
