model Bisoprolol_Momilovi2019_reference
  parameter Real Cl_ref = 7.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.51291 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bisoprolol</td></tr><tr><td>population:</td><td>patients with acute coronary syndrome</td></tr><tr><td>source_paper:</td><td>Momčilović_2019</td></tr><tr><td>measured_compound:</td><td>bisoprolol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['tab_2:row1:col2'])</li><li>dropped unlinked row (NIL): 'DD (mg/d)' — extend the ontology if this is a real PK parameter (source ['tab_2:row4:col1', 'tab_2:row4:col2', 'tab_2:row4:col3', 'tab_2:row4:col4'])</li><li>dropped unlinked row (NIL): 'SMOKING' — extend the ontology if this is a real PK parameter (source ['tab_2:row5:col1', 'tab_2:row5:col2', 'tab_2:row5:col3', 'tab_2:row5:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bisoprolol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bisoprolol_Momilovi2019_reference;
