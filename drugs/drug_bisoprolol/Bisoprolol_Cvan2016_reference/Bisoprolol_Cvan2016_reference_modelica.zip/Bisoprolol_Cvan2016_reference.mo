model Bisoprolol_Cvan2016_reference
  parameter Real Cl_ref = 9.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0036000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0033888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bisoprolol</td></tr><tr><td>population:</td><td>patients with chronic heart failure</td></tr><tr><td>source_paper:</td><td>Cvan_2016</td></tr><tr><td>measured_compound:</td><td>bisoprolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Effect of MDRD4 on CL a', value '12.8') — already have one for this compound</li><li>dropped duplicate Q61 ('Effect of SMI on V b', value '27.1') — already have one for this compound</li><li>dropped duplicate Q22 ('CL-V correlation', value '63.8') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Proportional (%)' — extend the ontology if this is a real PK parameter (source ['tab_0:row21:col1'])</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['tab_0:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V' from footnote/prose loose number None (source ['tab_0:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bisoprolol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bisoprolol_Cvan2016_reference;
