model Bepotastine_Yoon2024_inter_individual_variability_iiv_estima
  parameter Real Cl_ref = 7.777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.388892,
    adminMass = 3e-06,
    ka = 0.0011694444444444445,
    Tlag = 972.0000000000001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bepotastine</td></tr><tr><td>population:</td><td>pediatric patients aged 2 to 6 years</td></tr><tr><td>source_paper:</td><td>Yoon_2024</td></tr><tr><td>measured_compound:</td><td>Bepotastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-00334-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bepotastine 388.892 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'KA (h−1)' routed out of structural estimates ('Inter-Individual Variability (IIV) / Estimate (%RSE)')</li><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('Inter-Individual Variability (IIV) / Estimate (%RSE)')</li><li>table section iiv: 'V (L)' routed out of structural estimates ('Inter-Individual Variability (IIV) / Estimate (%RSE)')</li><li>table section iiv: 'ALAG (h)' routed out of structural estimates ('Inter-Individual Variability (IIV) / Estimate (%RSE)')</li><li>table section iiv: 'Exponent of CL' routed out of structural estimates ('Inter-Individual Variability (IIV) / Estimate (%RSE)')</li><li>table section iiv: 'Exponent of V' routed out of structural estimates ('Inter-Individual Variability (IIV) / Estimate (%RSE)')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>salvaged Q49 ('KA'=4.21) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('CL'=28.0) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V'=103.0) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('lag time (ALAG)'=0.27) from results prose — parameter table was unreadable</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL); Q61 (V)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Bepotastine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'inter-individual variability (iiv) / estimate (%rse)' subgroup of Yoon_2024 (paper reports 2 populations: inter-individual variability (iiv) / estimate (%rse), structural parameters / estimate (%rse))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bepotastine_Yoon2024_inter_individual_variability_iiv_estima;
