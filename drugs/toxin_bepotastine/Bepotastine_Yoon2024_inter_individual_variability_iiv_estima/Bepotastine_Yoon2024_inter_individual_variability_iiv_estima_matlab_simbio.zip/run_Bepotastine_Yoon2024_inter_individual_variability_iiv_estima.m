% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Bepotastine_Yoon2024_inter_individual_variability_iiv_estima_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
