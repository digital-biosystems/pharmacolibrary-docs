% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Bepotastine_Yoon2024_structural_parameters_estimate_rse_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
