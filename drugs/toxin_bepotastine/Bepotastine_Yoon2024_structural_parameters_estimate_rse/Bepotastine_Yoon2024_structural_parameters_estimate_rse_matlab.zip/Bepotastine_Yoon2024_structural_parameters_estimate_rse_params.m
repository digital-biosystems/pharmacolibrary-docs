function p = Bepotastine_Yoon2024_structural_parameters_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bepotastine   source: Yoon_2024 / structural_parameters_estimate_rse   route: oral
  % estimated (absent from source): F
  p.name  = 'Bepotastine_Yoon2024_structural_parameters_estimate_rse_params';
  p.drug  = 'bepotastine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 103.0;                % central volume [L]
  p.CL = 28.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.21;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.27;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
