// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Celecoxib_Mukesh2023_cel_na_pvp_va_assd
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {53604.0},
    MM = 0.381372,
    adminMass = 0.0007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>celecoxib</td></tr><tr><td>population:</td><td>female Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Mukesh_2023</td></tr><tr><td>measured_compound:</td><td>celecoxib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>celecoxib 381.372 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax (ng mL−1)'; source reconciliation required</li><li>table representations disagree for 'Fold increase'; source reconciliation required</li><li>table representations disagree for 'Tmax (h)'; source reconciliation required</li><li>table representations disagree for 'AUC (ng h mL−1)#'; source reconciliation required</li><li>table representations disagree for 'MRT (h)'; source reconciliation required</li><li>table representations disagree for 'T1/2 (h)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Fold increase' — extend the ontology if this is a real PK parameter (source ['Tab3:row3:col2', 'Tab3:row3:col5'])</li><li>NIL: refused to back-fill base 'equation variable' from footnote/prose loose number 0.05 (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 3 (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'fold increase'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=celecoxib</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'cel-na-pvp-va assd' subgroup of Mukesh_2023 (paper reports 7 populations: cel-hpmcas asd, cel-k-hpmcas assd, cel-k-pvp-va assd, cel-na-hpmcas assd, cel-na-pvp-va assd, cel-pvp-va asd, crystalline cel)</li><li>gap-filled Q22 (CL) from Cekanova_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cekanova_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1728.0));
end Celecoxib_Mukesh2023_cel_na_pvp_va_assd;
