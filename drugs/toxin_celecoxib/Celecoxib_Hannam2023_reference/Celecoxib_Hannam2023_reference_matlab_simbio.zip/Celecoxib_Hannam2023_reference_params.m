function p = Celecoxib_Hannam2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: celecoxib   source: Hannam_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Celecoxib_Hannam2023_reference_params';
  p.drug  = 'celecoxib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 346.0;                % central volume [L]
  p.CL = 518.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.02;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.62;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
