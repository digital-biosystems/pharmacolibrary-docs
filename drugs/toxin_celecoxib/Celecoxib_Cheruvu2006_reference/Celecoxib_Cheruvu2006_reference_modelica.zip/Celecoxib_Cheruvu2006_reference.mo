model Celecoxib_Cheruvu2006_reference
  parameter Real Cl_ref = 0.00014388888888888887 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0006979 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.381372,
    adminMass = 0.0002,
    ka = 5.555555555555556e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>celecoxib</td></tr><tr><td>population:</td><td>freshly excised bovine and porcine sclera/choroid-Bruch's layer preparations</td></tr><tr><td>source_paper:</td><td>Cheruvu_2006</td></tr><tr><td>measured_compound:</td><td>Celecoxib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>celecoxib 381.372 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): &quot;porcine tissue permeability reduction (choroid-Bruch's layer), mannitol&quot; — extend the ontology if this is a real PK parameter (source ['Cheruvu_2006:abstract'])</li><li>unit_dimension_unknown: 'fold' (Fab)</li><li>unit_dimension_unknown: 'fold' (Kp)</li><li>dropped unlinked row (NIL): &quot;porcine tissue permeability reduction (choroid-Bruch's layer), celecoxib&quot; — extend the ontology if this is a real PK parameter (source ['Cheruvu_2006:abstract'])</li><li>unit_dimension_unknown: 'fold' (Kp)</li><li>dropped duplicate Q410 (&quot;porcine tissue permeability reduction (choroid-Bruch's layer), rhodamine 6G&quot;, value 40) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Celecoxib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Cekanova_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cekanova_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Pan_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Celecoxib_Cheruvu2006_reference;
