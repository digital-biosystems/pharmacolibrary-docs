// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Armodafinil_Willavize2017_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.045},
    CLelim = {5.583333333333332e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About armodafinil</h4><p>Armodafinil is a wakefulness-promoting agent used for narcolepsy, hypersomnia, and sleep-wake disorders. It is administered orally as a tablet. The medication is approved for market use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q418913\">Wikidata Q418913</a>, <a href=\"https://en.wikipedia.org/wiki/Armodafinil?oldid=1370773396\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>armodafinil</td></tr><tr><td>population:</td><td>healthy subjects and patients with bipolar I disorder</td></tr><tr><td>source_paper:</td><td>Willavize_2017</td></tr><tr><td>measured_compound:</td><td>armodafinil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>armodafinil 273.35 g/mol (drugbank); R-modafinil acid 274.334 g/mol (pubchem); modafinil sulfone 289.349 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=armodafinil</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 3 linked by role; re-tagged armodafinil→parent ×3</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Armodafinil_Willavize2017_reference;
