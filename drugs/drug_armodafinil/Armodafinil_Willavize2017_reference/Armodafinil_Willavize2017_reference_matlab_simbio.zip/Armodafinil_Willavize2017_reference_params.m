function p = Armodafinil_Willavize2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: armodafinil   source: Willavize_2017 / reference   route: oral
  p.name  = 'Armodafinil_Willavize2017_reference_params';
  p.drug  = 'armodafinil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 2.01;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.067023;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
