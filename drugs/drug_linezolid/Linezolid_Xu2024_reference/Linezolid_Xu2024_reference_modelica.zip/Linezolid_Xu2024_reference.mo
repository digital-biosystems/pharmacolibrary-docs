model Linezolid_Xu2024_reference
  parameter Real Cl_ref = 7.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.057100000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3373461,
    adminMass = 0.0006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About linezolid</h4><p>Linezolid is an antibiotic used to treat serious bacterial infections, including pneumonia, skin infections such as cellulitis, urinary tract infections, and resistant staphylococcal infections like MRSA. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely available for human use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411377\">Wikidata Q411377</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>linezolid</td></tr><tr><td>population:</td><td>adults with hospital-acquired pneumonia and renal insufficiency</td></tr><tr><td>source_paper:</td><td>Xu_2024</td></tr><tr><td>measured_compound:</td><td>linezolid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>linezolid 337.346 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ(%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ(%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ(%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ(%)' routed out of structural estimates ('Residual variability')</li><li>kept covariate coefficient θAge=-0.6 (covariate Age) — not an ontology parameter</li><li>dropped duplicate Q22 ('θCrCL', value '0.5') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=linezolid</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Linezolid_Xu2024_reference;
