function p = Linezolid_VeraYunca2025_PD_bacterial_load_params()
% Linezolid_VeraYunca2025_PD_bacterial_load_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% linezolid Vera-Yunca_2025::bacterial_load: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response bacterial load in log10 cfu/total lung. Driver: linezolid (cited_pk).
p.E0 = 6.01;
p.Emax = -0.0005472222222222222;
p.EC50 = 0.00056;
p.gamma = 2.19;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.6;
p.form = 'E0 + Emax*frac';
end
