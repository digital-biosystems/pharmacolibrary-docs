% run_Linezolid_VeraYunca2025_PD_bacterial_load  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Linezolid_VeraYunca2025_PD_bacterial_load_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L]'); ylabel('response [log10 cfu/total lung]'); title('Linezolid_VeraYunca2025_PD_bacterial_load', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Linezolid_VeraYunca2025_PD_bacterial_load.csv');
