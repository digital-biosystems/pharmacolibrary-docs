model Linezolid_VeraYunca2025_PD_bacterial_load
  "sigmoid_emax exposure-response sweep — Vera-Yunca_2025 :: bacterial load (bacterial load)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.01,      // [log10 (cfu/mL)]
    Emax = -0.000547222222222,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00056,  // [kg/m3; mg/L × 0.001]
    gamma = 2.19,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 5.6, Interval = 0.0112),
    Documentation(info = "<html><body><!-- drug-about --><h4>About linezolid</h4><p>Linezolid is an antibiotic used to treat serious bacterial infections, including pneumonia, skin infections such as cellulitis, urinary tract infections, and resistant staphylococcal infections like MRSA. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely available for human use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411377\">Wikidata Q411377</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Linezolid_VeraYunca2025_PD_bacterial_load</h4><p>The steady-state exposure-response curve of Vera-Yunca D et al., <i>The Journal of antimicrobial chemotherapy 80(7):1860–1868</i> 2025 (<a href=\"https://doi.org/10.1093/jac/dkaf140\">doi:10.1093/jac/dkaf140</a>) — bacterial load [log10 cfu/total lung] against linezolid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.01 log10 (cfu/mL) drug-free response (baseline) (B 0 [log10 (cfu/mL)] Initial bacterial load, Q324)
  Emax  =       1.97 h−1      maximal effect term (E max,LZD, Q323)
  EC50  =       0.56 mg/L     exposure at half of the maximal effect term (EC50,LZD, Q321)
  gamma =       2.19          Hill coefficient (γ LZD, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of linezolid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.01   (drug-free)
  exposure = EC50 (0.56 mg/L)  response 6.01
  exposure -> infinity  response 6.009</pre></body></html>"));
end Linezolid_VeraYunca2025_PD_bacterial_load;
