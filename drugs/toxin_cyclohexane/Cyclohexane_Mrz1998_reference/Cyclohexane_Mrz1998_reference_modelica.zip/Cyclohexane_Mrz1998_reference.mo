// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cyclohexane_Mrz1998_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {57600.0},
    MM = 0.084162,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclohexane</td></tr><tr><td>population:</td><td>volunteers</td></tr><tr><td>source_paper:</td><td>Mráz_1998</td></tr><tr><td>measured_compound:</td><td>Cyclohexane</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cyclohexane 84.162 g/mol (pubchem); Cyclohexanol 100.161 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CH' — extend the ontology if this is a real PK parameter (source ['Mráz_1998:abstract'])</li><li>dropped unlinked row (NIL): 'CH-ol' — extend the ontology if this is a real PK parameter (source ['Mráz_1998:abstract'])</li><li>dropped unlinked row (NIL): 'CH, 1050 mg m(-3); CH-ol, 200 mg m(-3)' — extend the ontology if this is a real PK parameter (source ['Mráz_1998:abstract'])</li><li>dropped value-less row: '1,2- and 1,4-CH-diol'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyclohexane</li><li>toxin: 5 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: elimination half-lives printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 0 linked by role; re-tagged Cyclohexane→parent ×1, Cyclohexane→Cyclohexanol ×1</li><li>molar mass: none of 1 PubChem candidate(s) is '1,2-Cyclohexanediol' (LLM) — left in mass units</li><li>molar mass: none of 1 PubChem candidate(s) is '1,4-Cyclohexanediol' (LLM) — left in mass units</li><li>molar mass: none found for '1,2-Cyclohexanediol' — its concentrations stay mass-only</li><li>molar mass: none found for '1,4-Cyclohexanediol' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Cyclohexane_Mrz1998_reference;
