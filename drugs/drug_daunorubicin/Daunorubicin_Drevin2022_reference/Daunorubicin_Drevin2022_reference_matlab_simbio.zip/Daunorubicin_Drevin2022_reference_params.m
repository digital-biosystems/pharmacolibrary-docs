function p = Daunorubicin_Drevin2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daunorubicin   source: Drevin_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Daunorubicin_Drevin2022_reference_params';
  p.drug  = 'daunorubicin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.1;                % central volume [L]
  p.CL = 41.3;                % clearance [L/h]
  p.Vp = [1449.0];             % peripheral volumes [L]
  p.Q  = [69.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
