% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Daunorubicin_KroghMadsen2012_only_present_study_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
