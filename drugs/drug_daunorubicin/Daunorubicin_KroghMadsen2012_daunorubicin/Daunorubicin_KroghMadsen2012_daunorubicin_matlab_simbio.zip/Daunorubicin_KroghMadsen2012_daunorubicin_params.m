function p = Daunorubicin_KroghMadsen2012_daunorubicin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daunorubicin   source: Krogh-Madsen_2012 / daunorubicin   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Daunorubicin_KroghMadsen2012_daunorubicin_params';
  p.drug  = 'daunorubicin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 22.0;                % central volume [L]
  p.CL = 28.0;                % clearance [L/h]
  p.Vp = [911.0];             % peripheral volumes [L]
  p.Q  = [152.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
