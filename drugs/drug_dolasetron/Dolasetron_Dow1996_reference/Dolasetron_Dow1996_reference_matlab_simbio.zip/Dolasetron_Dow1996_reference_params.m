function p = Dolasetron_Dow1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dolasetron   source: Dow_1996 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Dolasetron_Dow1996_reference_params';
  p.drug  = 'dolasetron';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 58.1;                % central volume [L]
  p.CL = 457.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 14.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
