model Dolasetron_Dow1996_reference
  parameter Real Cl_ref = 0.00012716666666666665 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0581 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32438,
    adminMass = 0.0002,
    ka = 0.0038888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dolasetron</h4><p>Dolasetron is an antiemetic used to treat vomiting. It is an approved 5HT3 antagonist antiemetic, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1829318\">Wikidata Q1829318</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dolasetron</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Dow_1996</td></tr><tr><td>measured_compound:</td><td>dolasetron</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dolasetron 324.38 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('t1/2', value 4.0) — already have one for this compound</li><li>dropped duplicate Q22 ('Cltot', value 25) — already have one for this compound</li><li>dropped value-less row: 'first-order elimination rate constant (kel)' (captured trailing unit 'kel' for child rows)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dolasetron</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dolasetron_Dow1996_reference;
