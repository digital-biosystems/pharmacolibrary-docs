function p = Naltrexone_Reuning1979_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: naltrexone   source: Reuning_1979 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Naltrexone_Reuning1979_reference_params';
  p.drug  = 'naltrexone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.06;                % central volume [L]
  p.CL = 165.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 29.04;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
