function p = Eculizumab_Lee2024_PD_tca_params()
% Eculizumab_Lee2024_PD_tca_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eculizumab Lee_2024::TCA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response TCA in %. Driver: eculizumab (pk_record).
p.E0 = 0.8590000000000001;
p.Emax = -0.009300000000000001;
p.EC50 = 0.036599999999999994;
p.gamma = 4.56;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 370.0;
p.form = 'E0 + Emax*frac';
end
