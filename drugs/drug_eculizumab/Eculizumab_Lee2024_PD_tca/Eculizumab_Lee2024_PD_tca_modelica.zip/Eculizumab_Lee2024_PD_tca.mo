model Eculizumab_Lee2024_PD_tca
  "sigmoid_emax exposure-response sweep — Lee_2024 :: TCA (terminal complement activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.859,      // [1; % × 0.01]
    Emax = -0.0093,  // [1; % × 0.01]
    EC50 = 0.0366,  // [kg/m3; μg/mL × 0.001]
    gamma = 4.56,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 370, Interval = 0.74),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Eculizumab_Lee2024_PD_tca</h4><p>The steady-state exposure-response curve of Lee H et al., <i>European journal of clinical pharmacology 80(9):1325–1338</i> 2024 (<a href=\"https://doi.org/10.1007/s00228-024-03703-8\">doi:10.1007/s00228-024-03703-8</a>) — terminal complement activity [%] against eculizumab μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       85.9 %        drug-free response (baseline) (Baseline terminal complement activity in healthy subjects, Q324)
  Emax  =       0.93 %        maximal effect term (Maximum effect of inhibition in healthy subjects, Q323)
  EC50  =       36.6 μg/mL    exposure at half of the maximal effect term (Serum concentration achieving 50% of Imax, Q322)
  gamma =       4.56          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of eculizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.859   (drug-free)
  exposure = EC50 (36.6 μg/mL)  response 0.8544
  exposure -> infinity  response 0.8497</pre></body></html>"));
end Eculizumab_Lee2024_PD_tca;
