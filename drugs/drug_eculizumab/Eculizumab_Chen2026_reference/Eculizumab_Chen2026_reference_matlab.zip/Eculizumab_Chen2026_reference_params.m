function p = Eculizumab_Chen2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eculizumab   source: Chen_2026 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Eculizumab_Chen2026_reference_params';
  p.drug  = 'eculizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 163.0;                % central volume [L]
  p.CL = 79.5;                % clearance [L/h]
  p.Vp = [232.0];             % peripheral volumes [L]
  p.Q  = [34.9];             % inter-compartmental clearances [L/h]
  p.ka = 1.58;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.278;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
