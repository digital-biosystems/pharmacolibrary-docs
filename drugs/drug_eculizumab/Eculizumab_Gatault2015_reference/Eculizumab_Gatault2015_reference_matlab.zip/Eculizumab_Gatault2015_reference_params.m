function p = Eculizumab_Gatault2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eculizumab   source: Gatault_2015 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Eculizumab_Gatault2015_reference_params';
  p.drug  = 'eculizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.2;                % central volume [L]
  p.CL = 0.0075;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.58;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.278;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
