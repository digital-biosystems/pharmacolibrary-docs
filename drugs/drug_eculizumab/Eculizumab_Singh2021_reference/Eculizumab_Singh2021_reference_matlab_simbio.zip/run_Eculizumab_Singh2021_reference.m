% Run (SimBiology): build model + dose, simulate 0..2352.0 h, plot.
p = Eculizumab_Singh2021_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2352.0);
