function p = Eculizumab_Singh2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eculizumab   source: Singh_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Eculizumab_Singh2021_reference_params';
  p.drug  = 'eculizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.21;                % central volume [L]
  p.CL = 0.00668;                % clearance [L/h]
  p.Vp = [2.06];             % peripheral volumes [L]
  p.Q  = [0.226];             % inter-compartmental clearances [L/h]
  p.ka = 1.58;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.278;             % absorption lag [h]
  p.dose = 900.0;             % dose [mg]
end
