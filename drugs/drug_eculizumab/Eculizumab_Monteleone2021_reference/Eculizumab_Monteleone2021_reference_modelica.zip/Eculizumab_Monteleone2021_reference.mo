model Eculizumab_Monteleone2021_reference
  parameter Real Cl_ref = 2.9444444444444445e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00254 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0009,
    ka = 0.0004388888888888889,
    Tlag = 1000.8000000000001,
    k12 = 2.744969378827647e-05,
    k21 = 2.5539275539275543e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eculizumab</td></tr><tr><td>population:</td><td>adults with generalized myasthenia gravis</td></tr><tr><td>source_paper:</td><td>Monteleone_2021</td></tr><tr><td>measured_compound:</td><td>eculizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>competing summary columns for 'CL (L/h)'; not population strata</li><li>competing summary columns for 'V1 (L)'; not population strata</li><li>competing summary columns for 'V2 (L)'; not population strata</li><li>competing summary columns for 'Q (L/h)'; not population strata</li><li>competing summary columns for 'Observed Cmax (μg/ml)'; not population strata</li><li>competing summary columns for 'Cmax, ss (μg/ml)'; not population strata</li><li>competing summary columns for 'Ctrough, ss (μg/ml)'; not population strata</li><li>competing summary columns for 'Terminal half-life (h)'; not population strata</li><li>dropped duplicate Q32 ('Cmax, ss (μg/ml)', value '845') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eculizumab</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'eculizumab' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Chen_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chen_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Eculizumab_Monteleone2021_reference;
