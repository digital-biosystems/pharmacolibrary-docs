function p = Nimesulide_Huang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nimesulide   source: Huang_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Nimesulide_Huang2025_reference_params';
  p.drug  = 'nimesulide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.36;                % central volume [L]
  p.CL = 1.66;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
