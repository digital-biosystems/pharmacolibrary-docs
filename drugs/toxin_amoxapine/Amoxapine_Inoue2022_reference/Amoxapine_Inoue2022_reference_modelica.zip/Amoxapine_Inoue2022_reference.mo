// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Amoxapine_Inoue2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {30672.0},
    MM = 0.31378500000000004,
    adminMass = 0.0007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxapine</td></tr><tr><td>population:</td><td>mice (male mice, therapeutic and toxic doses)</td></tr><tr><td>source_paper:</td><td>Inoue_2022</td></tr><tr><td>measured_compound:</td><td>Amoxapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>amoxapine 313.785 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q56 ('Tmax Brain (hr)', value '0.75') — already have one for this compound</li><li>unit_dimension_unknown: 'x10^-3' (Kp)</li><li>dropped duplicate Q57 ('t1/2 Brain (hr)', value '2.78') — already have one for this compound</li><li>unit_dimension_mismatch: 'AUC Brain (ng/mL)' → Q88 (unit '[mass] / [length] ** 3' vs ontology '[mass] * [time] / [length] ** 3') — route to review</li><li>dropped duplicate Q88 ('AUC Brain (ng/mL)', value '3.76') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Amoxapine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 309.6));
end Amoxapine_Inoue2022_reference;
