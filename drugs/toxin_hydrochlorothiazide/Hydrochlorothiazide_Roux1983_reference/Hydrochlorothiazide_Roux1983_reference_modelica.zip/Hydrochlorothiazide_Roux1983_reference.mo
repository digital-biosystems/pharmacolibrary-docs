// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Hydrochlorothiazide_Roux1983_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {25200.0},
    MM = 0.297728,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydrochlorothiazide</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Roux_1983</td></tr><tr><td>measured_compound:</td><td>Hydrochlorothiazide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Acebutolol 336.432 g/mol (pubchem); Diacetolol 308.378 g/mol (pubchem); Hydrochlorothiazide 297.728 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'micrograms l-1h' (AUC)</li><li>unit_dimension_unknown: 'lh-1' (CLR)</li><li>dropped duplicate Q57 ('t 1/2', value 4) — already have one for this compound</li><li>implicit units: 'AUC' → µg*h/mL (from the popPK convention: 'For AUC, common units depend on concentration and time. Assuming standard concentration in µg/mL and time in h, a value ')</li><li>implicit units: 'renal clearance' → L/h (from the popPK convention: 'The instruction explicitly states that clearances and intercompartmental clearances are in L/h unless otherwise specifie')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hydrochlorothiazide</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role; re-tagged Hydrochlorothiazide→parent ×12</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V from Gosse_2006: its label names a different analyte ('telmisartan') — 'volume of distribution of telmisartan'</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Vlachou_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 280.8));
end Hydrochlorothiazide_Roux1983_reference;
