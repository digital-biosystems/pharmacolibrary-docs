// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Plutonium239_Harrison1980_241am
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {769689864000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>plutonium_239</td></tr><tr><td>population:</td><td>hamsters and rats</td></tr><tr><td>source_paper:</td><td>Harrison_1980</td></tr><tr><td>measured_compound:</td><td>Plutonium-239</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>plutonium_239 239.052 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Harrison_1980_table_3: rows are variants (239Pu, 241Am), the parameters are the column headers (Liver) — read one record per variant</li><li>dropped unlinked row (NIL): 'Liver' — extend the ontology if this is a real PK parameter (source ['Harrison_1980_table_3:row3:col4', 'Harrison_1980_table_3:row4:col4', 'Harrison_1980_table_3:row5:col4'])</li><li>salvaged Q57 ('half-life of 239Pu'=24390) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Plutonium-239</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: '241Am' is one of 2 estimates of Harrison_1980's substance matrix (239Pu, 241Am); same population, different estimation method</li><li>molar mass: no plausible PubChem entry for 'Plutonium-239' ('Plutonium-239') — left in mass units</li><li>molar mass: none found for 'Plutonium-239' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Birchall_2010's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Plutonium239_Harrison1980_241am;
