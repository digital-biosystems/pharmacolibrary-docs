model Neomycin_Qu2026_reference
  parameter Real Cl_ref = 1.277713044591084e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.021328299999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.61465,
    adminMass = 0.0021
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>neomycin</td></tr><tr><td>population:</td><td>healthy male donkeys</td></tr><tr><td>source_paper:</td><td>Qu_2026</td></tr><tr><td>measured_compound:</td><td>Neomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab6</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>neomycin 614.65 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 6. Pharmacokinetic Parameters of neomycin in feces in donkeys following a single intragastric administration of 30 mg·kg−1 BW, n = 5.'</li><li>salvaged Q57 ('T₁/₂λz'=32.14) from results prose — parameter table was unreadable</li><li>salvaged Q59 ('T₁/₂α'=3.16) from results prose — parameter table was unreadable</li><li>salvaged Q60 ('T₁/₂β'=1.98) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=304.69) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Neomycin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Qu_2026:discussion_prose, Qu_2026:other_prose, tab6:footnote); populations cattle, intramuscular, intravenous, neomycin, oral, sheep, subcutaneous, swine kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=0.459977 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Neomycin_Qu2026_reference;
