// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Neomycin_Qu2026_swine
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {44748.0},
    MM = 0.61465,
    adminMass = 0.0021,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>neomycin</td></tr><tr><td>population:</td><td>healthy male donkeys</td></tr><tr><td>source_paper:</td><td>Qu_2026</td></tr><tr><td>measured_compound:</td><td>Neomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab6</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>neomycin 614.65 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 6. Pharmacokinetic Parameters of neomycin in feces in donkeys following a single intragastric administration of 30 mg·kg−1 BW, n = 5.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Neomycin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'swine' subgroup of Qu_2026 (paper reports 8 populations: cattle, intramuscular, intravenous, neomycin, oral, sheep, subcutaneous, swine)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Neomycin_Qu2026_swine;
