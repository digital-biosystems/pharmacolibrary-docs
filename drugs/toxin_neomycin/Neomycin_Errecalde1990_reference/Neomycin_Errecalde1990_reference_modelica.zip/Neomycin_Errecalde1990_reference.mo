model Neomycin_Errecalde1990_reference
  parameter Real Cl_ref = 1.4562303990481362e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.021328299999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.61465,
    adminMass = 0.005,
    ka = 0.0005444134311655242,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>neomycin</td></tr><tr><td>population:</td><td>sheep</td></tr><tr><td>source_paper:</td><td>Errecalde_1990</td></tr><tr><td>measured_compound:</td><td>Neomycin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>neomycin 614.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate im for t1/2ka  from footnote/prose kept as documentation only (['Errecalde_1990:abstract'])</li><li>dropped duplicate Q95 ('Absorption half-life (IT)', value 40.83) — already have one for this compound</li><li>covariate im for t1/2z from footnote/prose kept as documentation only (['Errecalde_1990:abstract'])</li><li>dropped duplicate Q57 ('elimination half-life (IT)', value 2.55) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Neomycin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL/F=5.24243 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Neomycin_Errecalde1990_reference;
