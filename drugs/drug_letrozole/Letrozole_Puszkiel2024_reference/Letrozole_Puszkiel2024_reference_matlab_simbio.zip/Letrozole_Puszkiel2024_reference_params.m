function p = Letrozole_Puszkiel2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: letrozole   source: Puszkiel_2024 / reference   route: oral
  p.name  = 'Letrozole_Puszkiel2024_reference_params';
  p.drug  = 'letrozole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 207.0;                % central volume [L]
  p.CL = 1.31;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.12;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
