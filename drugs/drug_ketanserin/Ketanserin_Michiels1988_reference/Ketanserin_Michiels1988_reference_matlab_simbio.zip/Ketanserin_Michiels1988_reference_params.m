function p = Ketanserin_Michiels1988_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketanserin   source: Michiels_1988 / reference   route: iv_bolus
  p.name  = 'Ketanserin_Michiels1988_reference_params';
  p.drug  = 'ketanserin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 46.9;                % central volume [L]
  p.CL = 15.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.8;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
