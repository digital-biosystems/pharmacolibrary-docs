model Testosterone_Bi2018_bootstrapa_median
  parameter Real Cl_ref = 3.0092592592592597e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 14.400000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.288431,
    adminMass = 0.0001,
    ka = 1.412037037037037e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>testosterone</td></tr><tr><td>population:</td><td>healthy male subjects</td></tr><tr><td>source_paper:</td><td>Bi_2018</td></tr><tr><td>measured_compound:</td><td>Total Testosterone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412287-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Testosterone 288.431 g/mol (pubchem); Testosterone Cypionate 412.614 g/mol (pubchem); Total Testosterone 288.431 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>conflicting source units for 'IIV_A_0, TC': [{'unit': 'TC', 'source': 'psp412287-tbl-0002:row22:col0', 'scope': 'label'}, {'unit': '%', 'source': 'psp412287-tbl-0002:row22:col2', 'scope': 'inline'}]</li><li>dropped unlinked row (NIL): 'βbase, mg/day' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row5:col2'])</li><li>dropped PD-category row 'Lambda(λ)' → Q342 (lambda_hazard, category G14) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412287-tbl-0002:row6:col2'])</li><li>dropped PD-category row 'Emax, mg/day' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412287-tbl-0002:row7:col2'])</li><li>dropped unlinked row (NIL): 'LH50, IU/L' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row8:col2'])</li><li>dropped unlinked row (NIL): 'A_0, TC' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row9:col2'])</li><li>dropped unlinked row (NIL): 'θBalbumin−V' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row10:col2'])</li><li>dropped 'θCalbumin−V' → Q63 = -0.27: a volume of -0.27 is not a parameter value (source ['psp412287-tbl-0002:row11:col2'])</li><li>dropped unlinked row (NIL): 'θBWT−V' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row12:col2'])</li><li>dropped unlinked row (NIL): 'θBWT−CL' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row13:col2'])</li><li>dropped unlinked row (NIL): 'θCWT−CL' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row14:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Total Testosterone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>population split: 'bootstrapa / median' subgroup of Bi_2018 (paper reports 2 populations: bootstrapa / median, final model / estimate)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Testosterone_Bi2018_bootstrapa_median;
