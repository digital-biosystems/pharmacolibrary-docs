function p = Testosterone_Bi2018_bootstrapa_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: testosterone   source: Bi_2018 / bootstrapa_median   route: oral
  p.name  = 'Testosterone_Bi2018_bootstrapa_median_params';
  p.drug  = 'testosterone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14400.0;                % central volume [L]
  p.CL = 108.333333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.050833;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
