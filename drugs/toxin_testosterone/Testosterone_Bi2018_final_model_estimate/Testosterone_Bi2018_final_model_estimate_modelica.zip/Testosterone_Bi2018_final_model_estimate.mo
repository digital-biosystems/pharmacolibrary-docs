model Testosterone_Bi2018_final_model_estimate
  parameter Real Cl_ref = 3.0092592592592597e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 14.400000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.412037037037037e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>testosterone</td></tr><tr><td>population:</td><td>healthy male subjects</td></tr><tr><td>source_paper:</td><td>Bi_2018</td></tr><tr><td>measured_compound:</td><td>Total Testosterone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412287-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Testosterone 288.431 g/mol (pubchem); Testosterone Cypionate 412.614 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>conflicting source units for 'IIV_A_0, TC': [{'unit': 'TC', 'source': 'psp412287-tbl-0002:row22:col0', 'scope': 'label'}, {'unit': '%', 'source': 'psp412287-tbl-0002:row22:col1', 'scope': 'inline'}]</li><li>dropped unlinked row (NIL): 'βbase, mg/day' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row5:col1'])</li><li>dropped PD-category row 'Lambda(λ)' → Q342 (lambda_hazard, category G14) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412287-tbl-0002:row6:col1'])</li><li>dropped PD-category row 'Emax, mg/day' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412287-tbl-0002:row7:col1'])</li><li>dropped unlinked row (NIL): 'LH50, IU/L' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row8:col1'])</li><li>dropped unlinked row (NIL): 'A_0, TC' — extend the ontology if this is a real PK parameter (source ['psp412287-tbl-0002:row9:col1'])</li><li>dropped 'θBalbumin−V' → Q30 = -1.55: a clearance of -1.55 is not a parameter value (source ['psp412287-tbl-0002:row10:col1'])</li><li>dropped 'θCalbumin−V' → Q63 = -0.27: a volume of -0.27 is not a parameter value (source ['psp412287-tbl-0002:row11:col1'])</li><li>routed 'θBWT−V' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'θCWT−CL' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Total Testosterone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>population split: 'final model / estimate' subgroup of Bi_2018 (paper reports 2 populations: bootstrapa / median, final model / estimate)</li><li>row roles (LLM): model_class=compartmental; 21/21 row label(s) assigned, 6 linked by role; re-tagged Luteinizing Hormone→Total Testosterone ×38</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Testosterone_Bi2018_final_model_estimate;
