// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_246Trinitrotoluene_Lotufo2015_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4320.0},
    MM = 0.227132,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>246_trinitrotoluene</td></tr><tr><td>population:</td><td>Rana pipiens tadpoles</td></tr><tr><td>source_paper:</td><td>Lotufo_2015</td></tr><tr><td>measured_compound:</td><td>2,4,6-Trinitrotoluene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,4,6-Trinitrotoluene 227.132 g/mol (pubchem); 246_trinitrotoluene 227.132 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'bioconcentration factor of 0.25 L kg(-1) was determined for the insensitive munitions compound 3-nitro-1,2,4-trizole-5-one (NTO)' — extend the ontology if this is a real PK parameter (source ['Lotufo_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,4,6-Trinitrotoluene</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_246Trinitrotoluene_Lotufo2015_reference;
