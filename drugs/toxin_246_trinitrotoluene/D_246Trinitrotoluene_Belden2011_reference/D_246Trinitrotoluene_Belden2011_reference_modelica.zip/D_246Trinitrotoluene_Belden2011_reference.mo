// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_246Trinitrotoluene_Belden2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {325800.0},
    MM = 0.227132,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>246_trinitrotoluene</td></tr><tr><td>population:</td><td>Eisenia fetida</td></tr><tr><td>source_paper:</td><td>Belden_2011</td></tr><tr><td>measured_compound:</td><td>2,4,6-Trinitrotoluene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,4,6-Trinitrotoluene 227.132 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Nonextractable residues' — extend the ontology if this is a real PK parameter (source ['Belden_2011:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Belden_2011:abstract'])</li><li>dropped unlinked row (NIL): 'nonextractable residue was solubilized' — extend the ontology if this is a real PK parameter (source ['Belden_2011:abstract'])</li><li>dropped duplicate Q57 ('half-lives', value '220.5') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,4,6-Trinitrotoluene</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: Elimination half-lives printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 0 linked by role; re-tagged 2,4,6-Trinitrotoluene→nonextractable residues ×2</li><li>molar mass: no plausible PubChem entry for 'aminodinitrotoluenes (ADNTs)' ('aminodinitrotoluenes') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'diaminonitrotoluenes (DANTs)' ('diaminonitrotoluenes') — left in mass units</li><li>molar mass: none found for 'aminodinitrotoluenes (ADNTs)' — its concentrations stay mass-only</li><li>molar mass: none found for 'diaminonitrotoluenes (DANTs)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1641600, Tolerance = 1e-9, Interval = 3283.2));
end D_246Trinitrotoluene_Belden2011_reference;
