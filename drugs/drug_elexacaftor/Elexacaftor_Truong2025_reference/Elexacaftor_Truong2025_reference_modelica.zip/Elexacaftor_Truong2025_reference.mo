model Elexacaftor_Truong2025_reference
  parameter Real Cl_ref = 3.722222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.183 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.597657,
    adminMass = 7.5e-05,
    ka = 0.00011666666666666667,
    Tlag = 2520.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About elexacaftor</h4><p>Elexacaftor is a respiratory medicine, classified under other respiratory system products. It is an approved medicine, though detailed information on where and how widely it is used is not available here.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72184089\">Wikidata Q72184089</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>elexacaftor</td></tr><tr><td>population:</td><td>children with cystic fibrosis</td></tr><tr><td>source_paper:</td><td>Truong_2025</td></tr><tr><td>measured_compound:</td><td>elexacaftor, ivacaftor, tezacaftor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70245-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>elexacaftor 597.66 g/mol (drugbank); elexacaftor, ivacaftor, tezacaftor 597.657 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ additive (mg/L)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ proportional' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ proportional' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ proportional' routed out of structural estimates ('Residual error')</li><li>dropped value-less row: 'ELX C max (mg/L)' (captured trailing unit 'mg/L' for child rows)</li><li>dropped value-less row: 'ELX C trough (mg/L)' (captured trailing unit 'mg/L' for child rows)</li><li>dropped value-less row: 'ELX AUC0–24 (mg*h/L)' (captured trailing unit 'mg*h/L' for child rows)</li><li>dropped value-less row: 'TEZ C max (mg/L)' (captured trailing unit 'mg/L' for child rows)</li><li>dropped value-less row: 'TEZ C trough (mg/L)' (captured trailing unit 'mg/L' for child rows)</li><li>dropped value-less row: 'TEZ AUC0–24 (mg*h/L)' (captured trailing unit 'mg*h/L' for child rows)</li><li>dropped value-less row: 'IVA C max (mg/L)' (captured trailing unit 'mg/L' for child rows)</li><li>dropped value-less row: 'IVA C trough (mg/L)' (captured trailing unit 'mg/L' for child rows)</li><li>dropped value-less row: 'IVA AUC0–12 (mg*h/L)' (captured trailing unit 'mg*h/L' for child rows)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=elexacaftor, ivacaftor, tezacaftor</li><li>molar mass: none of 1 PubChem candidate(s) is 'elexacaftor, ivacaftor, tezacaftor' (LLM) — left in mass units</li><li>molar mass: none of 1 PubChem candidate(s) is 'elexacaftor, ivacaftor, tezacaftor' (LLM) — left in mass units</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Elexacaftor_Truong2025_reference;
