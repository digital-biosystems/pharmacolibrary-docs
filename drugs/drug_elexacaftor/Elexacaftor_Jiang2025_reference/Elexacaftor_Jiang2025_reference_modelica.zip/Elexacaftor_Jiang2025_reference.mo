model Elexacaftor_Jiang2025_reference
  parameter Real Cl_ref = 6e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.59766,
    adminMass = 0.0001,
    ka = 0.00036111111111111115,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About elexacaftor</h4><p>Elexacaftor is a respiratory medicine, classified under other respiratory system products. It is an approved medicine, though detailed information on where and how widely it is used is not available here.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72184089\">Wikidata Q72184089</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>elexacaftor</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jiang_2025</td></tr><tr><td>measured_compound:</td><td>elexacaftor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>elexacaftor 597.66 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jiang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Elexacaftor_Jiang2025_reference;
