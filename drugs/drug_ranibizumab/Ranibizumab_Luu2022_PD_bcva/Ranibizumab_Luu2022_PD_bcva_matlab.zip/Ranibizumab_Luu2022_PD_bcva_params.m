function p = Ranibizumab_Luu2022_PD_bcva_params()
% Ranibizumab_Luu2022_PD_bcva_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ranibizumab Luu_2022::BCVA: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response BCVA in Letters. Driver: ranibizumab (cited_pk).
p.E0 = 35.4;
p.Emax = 0.842;
p.EC50 = 14.7;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 150.0;
p.form = 'E0*(1 + Emax*frac)';
end
