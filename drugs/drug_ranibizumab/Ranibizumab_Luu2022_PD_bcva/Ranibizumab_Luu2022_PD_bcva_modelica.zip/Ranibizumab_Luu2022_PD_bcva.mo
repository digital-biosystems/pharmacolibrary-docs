model Ranibizumab_Luu2022_PD_bcva
  "indirect_response_iii exposure-response sweep — Luu_2022 :: BCVA (best-corrected visual acuity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 35.4,      // [Letters]
    Emax = 0.842,  // type III effect term
    EC50 = 14.7,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 150, Interval = 0.3),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ranibizumab</h4><p>Ranibizumab is an eye injection used to treat retinal diseases such as wet age-related macular degeneration, macular edema, diabetic retinopathy, and retinal vein occlusion. It is widely used and authorised in the European Union, where several products are approved.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414270\">Wikidata Q414270</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ranibizumab_Luu2022_PD_bcva</h4><p>The steady-state exposure-response curve of Luu KT et al., <i>Journal of clinical pharmacology 62(5):594-608</i> 2022 (<a href=\"https://doi.org/10.1002/jcph.2002\">doi:10.1002/jcph.2002</a>) — best-corrected visual acuity [Letters] against ranibizumab nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       35.4 Letters  drug-free response (baseline) (gss, Q324)
  Emax  =      0.842          maximal effect term (Emax ss, Q320)
  EC50  =       14.7 nM       exposure at half of the maximal effect term (Ra_EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of ranibizumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 35.4   (drug-free)
  exposure = EC50 (14.7 nM)  response 50.3
  exposure -> infinity  response 65.21</pre></body></html>"));
end Ranibizumab_Luu2022_PD_bcva;
