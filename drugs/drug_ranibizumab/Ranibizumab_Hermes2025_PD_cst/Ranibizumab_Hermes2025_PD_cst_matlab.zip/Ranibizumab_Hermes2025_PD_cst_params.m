function p = Ranibizumab_Hermes2025_PD_cst_params()
% Ranibizumab_Hermes2025_PD_cst_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ranibizumab Hermes_2025::CST: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response CST in µm. Driver: ranibizumab (cited_pk).
p.E0 = 255.0;
p.Emax = 1.0;
p.EC50 = 2.2e-08;
p.gamma = 2.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.22;
p.form = 'E0*(1 - Emax*frac)';
end
