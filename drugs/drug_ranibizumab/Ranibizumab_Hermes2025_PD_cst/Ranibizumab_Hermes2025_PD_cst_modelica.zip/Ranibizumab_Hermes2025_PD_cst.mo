model Ranibizumab_Hermes2025_PD_cst
  "indirect_response_i exposure-response sweep — Hermes_2025 :: CST (central subfield thickness)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 255,      // [µm]
    Emax = 1,  // type I effect term
    EC50 = 2.2e-08,  // [kg; mg × 1e-06]
    gamma = 2.2,
    exposure_per_s = 1e-06);   // 1 mg per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 0.22, Interval = 0.00044),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ranibizumab</h4><p>Ranibizumab is an eye injection used to treat retinal diseases such as wet age-related macular degeneration, macular edema, diabetic retinopathy, and retinal vein occlusion. It is widely used and authorised in the European Union, where several products are approved.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414270\">Wikidata Q414270</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ranibizumab_Hermes2025_PD_cst</h4><p>The steady-state exposure-response curve of Hermes J et al., <i>Translational vision science &amp; technology 14(9):2</i> 2025 (<a href=\"https://doi.org/10.1167/tvst.14.9.2\">doi:10.1167/tvst.14.9.2</a>) — central subfield thickness [µm] against ranibizumab mg — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        255 µm       drug-free response (baseline) (CST 0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      0.022 mg       exposure at half of the maximal effect term (EC 50,ranibizumab, Q321)
  gamma =        2.2          Hill coefficient (H, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg of ranibizumab per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 255   (drug-free)
  exposure = EC50 (0.022 mg)  response 127.5
  exposure -> infinity  response 0</pre></body></html>"));
end Ranibizumab_Hermes2025_PD_cst;
