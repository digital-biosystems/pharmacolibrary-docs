function p = Ranibizumab_Fidler2020_estimated_value_rse_interval_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ranibizumab   source: Fidler_2020 / estimated_value_rse_interval   route: oral
  p.name  = 'Ranibizumab_Fidler2020_estimated_value_rse_interval_params';
  p.drug  = 'ranibizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.58;                % central volume [L]
  p.CL = 1.186667;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.005;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.1;             % dose [mg]
end
