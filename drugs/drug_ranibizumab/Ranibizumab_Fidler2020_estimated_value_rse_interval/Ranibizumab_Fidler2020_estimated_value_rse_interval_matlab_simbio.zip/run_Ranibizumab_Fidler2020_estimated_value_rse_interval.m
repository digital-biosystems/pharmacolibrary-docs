% Run (SimBiology): build model + dose, simulate 0..840.0 h, plot.
p = Ranibizumab_Fidler2020_estimated_value_rse_interval_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 840.0);
