model Ranibizumab_Fidler2020_estimated_value_rse_interval
  parameter Real Cl_ref = 3.2962962962962966e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02758 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.0000000000000001e-07,
    ka = 1.3888888888888887e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ranibizumab</h4><p>Ranibizumab is an eye injection used to treat retinal diseases such as wet age-related macular degeneration, macular edema, diabetic retinopathy, and retinal vein occlusion. It is widely used and authorised in the European Union, where several products are approved.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414270\">Wikidata Q414270</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ranibizumab</td></tr><tr><td>population:</td><td>preterm infants with retinopathy of prematurity</td></tr><tr><td>source_paper:</td><td>Fidler_2020</td></tr><tr><td>measured_compound:</td><td>ranibizumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Lognormal SD' — extend the ontology if this is a real PK parameter (source ['tbl2:row4:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ranibizumab</li><li>population split: 'estimated value (%rse) interval' subgroup of Fidler_2020 (paper reports 3 populations: estimated value (%rse) interval, ranibizumab 0.1 mg n = 75, ranibizumab 0.2 mg n = 86*)</li><li>molar mass: none found for 'ranibizumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Ranibizumab_Fidler2020_estimated_value_rse_interval;
