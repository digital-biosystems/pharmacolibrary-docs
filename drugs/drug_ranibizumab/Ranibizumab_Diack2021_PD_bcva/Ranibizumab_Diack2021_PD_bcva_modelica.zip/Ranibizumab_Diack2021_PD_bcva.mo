model Ranibizumab_Diack2021_PD_bcva
  "emax exposure-response sweep — Diack_2021 :: BCVA (best-corrected visual acuity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 25.2,  // [letter]
    EC50 = 1.13541666667e-14,  // [kg/s; μg/day × 1.15741e-14]
    gamma = 1,
    exposure_per_s = 1.15740740741e-14);   // 1 μg/day per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 9.9, Interval = 0.0198),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ranibizumab</h4><p>Ranibizumab is an eye injection used to treat retinal diseases such as wet age-related macular degeneration, macular edema, diabetic retinopathy, and retinal vein occlusion. It is widely used and authorised in the European Union, where several products are approved.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414270\">Wikidata Q414270</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ranibizumab_Diack2021_PD_bcva</h4><p>The steady-state exposure-response curve of Diack C et al., <i>Translational vision science &amp; technology 10(6):11</i> 2021 (<a href=\"https://doi.org/10.1167/tvst.10.6.11\">doi:10.1167/tvst.10.6.11</a>) — best-corrected visual acuity [letter] against ranibizumab μg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       25.2 letter   maximal effect term (Emax0, Q320)
  EC50  =      0.981 μg/day   exposure at half of the maximal effect term (E50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/day of ranibizumab per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.981 μg/day)  response 12.6
  exposure -> infinity  response 25.2</pre></body></html>"));
end Ranibizumab_Diack2021_PD_bcva;
