function p = Ranibizumab_Diack2021_PD_bcva_params()
% Ranibizumab_Diack2021_PD_bcva_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ranibizumab Diack_2021::BCVA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/day per second, in SI inside (kg/m3, s). Response BCVA in letter. Driver: ranibizumab (dose_only).
p.E0 = 0.0;
p.Emax = 25.2;
p.EC50 = 1.1354166666666666e-14;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-14;
p.stop_time = 9.9;
p.form = 'E0 + Emax*frac';
end
