function p = Ranibizumab_Diack2024v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ranibizumab   source: Diack_2024_2 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Ranibizumab_Diack2024v2_reference_params';
  p.drug  = 'ranibizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.076637;                % central volume [L]
  p.CL = 0.097083;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
