model Ranibizumab_Spaide2021_PD_letters_of_improvement
  "log_linear exposure-response sweep — Spaide_2021 :: Letters of Improvement (Letters of Improvement)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = -6.66,      // [letters]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 15.7   "[1]";
equation
  response = E0 + slope*log(exposure);
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ranibizumab</h4><p>Ranibizumab is an eye injection used to treat retinal diseases such as wet age-related macular degeneration, macular edema, diabetic retinopathy, and retinal vein occlusion. It is widely used and authorised in the European Union, where several products are approved.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414270\">Wikidata Q414270</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ranibizumab_Spaide2021_PD_letters_of_improvement</h4><p>The steady-state exposure-response curve of Spaide RF, <i>Retina (Philadelphia, Pa.) 41(6):1153–1163</i> 2021 (<a href=\"https://doi.org/10.1097/IAE.0000000000003116\">doi:10.1097/IAE.0000000000003116</a>) — Letters of Improvement [letters] against ranibizumab injections per year — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      -6.66 letters  drug-free response (baseline) (Intercept, Q324)
  slope =       15.7          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one injections per year of ranibizumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Ranibizumab_Spaide2021_PD_letters_of_improvement;
