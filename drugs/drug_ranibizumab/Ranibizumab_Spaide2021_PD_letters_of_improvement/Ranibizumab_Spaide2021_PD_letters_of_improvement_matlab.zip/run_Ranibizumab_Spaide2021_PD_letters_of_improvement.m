% run_Ranibizumab_Spaide2021_PD_letters_of_improvement  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Ranibizumab_Spaide2021_PD_letters_of_improvement_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*log(exposure);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [injections per year]'); ylabel('response [letters]'); title('Ranibizumab_Spaide2021_PD_letters_of_improvement', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Ranibizumab_Spaide2021_PD_letters_of_improvement.csv');
