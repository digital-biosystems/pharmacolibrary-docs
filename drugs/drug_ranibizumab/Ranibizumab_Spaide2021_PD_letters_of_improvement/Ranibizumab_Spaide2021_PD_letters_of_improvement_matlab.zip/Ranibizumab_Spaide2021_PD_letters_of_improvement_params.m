function p = Ranibizumab_Spaide2021_PD_letters_of_improvement_params()
% Ranibizumab_Spaide2021_PD_letters_of_improvement_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ranibizumab Spaide_2021::Letters_of_Improvement: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one injections per year per second, in SI inside (kg/m3, s). Response Letters of Improvement in letters. Driver: ranibizumab (dose_only).
p.E0 = -6.66;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 15.7;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
