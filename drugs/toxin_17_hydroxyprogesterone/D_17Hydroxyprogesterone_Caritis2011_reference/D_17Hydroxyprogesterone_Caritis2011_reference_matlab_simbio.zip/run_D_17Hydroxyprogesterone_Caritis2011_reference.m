% Run (SimBiology): build model + dose, simulate 0..4200.0 h, plot.
p = D_17Hydroxyprogesterone_Caritis2011_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4200.0);
