function p = D_17Hydroxyprogesterone_Caritis2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 17_hydroxyprogesterone   source: Caritis_2011 / reference   route: oral
  p.name  = 'D_17Hydroxyprogesterone_Caritis2011_reference_params';
  p.drug  = '17_hydroxyprogesterone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 62.5;                % central volume [L]
  p.CL = 0.05375;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0625;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
