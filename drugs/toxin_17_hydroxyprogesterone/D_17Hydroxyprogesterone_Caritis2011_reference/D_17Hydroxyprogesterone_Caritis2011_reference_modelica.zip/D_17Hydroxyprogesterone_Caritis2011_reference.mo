model D_17Hydroxyprogesterone_Caritis2011_reference
  parameter Real Cl_ref = 1.4930555555555556e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0625 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.428613,
    adminMass = 0.00025,
    ka = 1.736111111111111e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>17_hydroxyprogesterone</td></tr><tr><td>population:</td><td>women with multifetal gestation</td></tr><tr><td>source_paper:</td><td>Caritis_2011</td></tr><tr><td>measured_compound:</td><td>17-hydroxyprogesterone caproate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>17-hydroxyprogesterone caproate 428.613 g/mol (pubchem); 17_hydroxyprogesterone 330.468 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'V/F (×103 ltr)' → L (from the paper text: &quot;The parameter header in Table 2 explicitly states '(×103 ltr)', indicating the base unit is liters.&quot;)</li><li>implicit units: 'Cl/F (×103ltr/d)' → L/d (from the paper text: &quot;The parameter header in Table 2 explicitly states '(×103ltr/d)', indicating the base unit is liters per day.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=17-hydroxyprogesterone caproate</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15120000, Tolerance = 1e-9, Interval = 1));
end D_17Hydroxyprogesterone_Caritis2011_reference;
