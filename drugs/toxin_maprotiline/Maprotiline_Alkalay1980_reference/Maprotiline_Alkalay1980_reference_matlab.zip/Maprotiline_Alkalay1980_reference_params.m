function p = Maprotiline_Alkalay1980_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: maprotiline   source: Alkalay_1980 / reference   route: oral
  p.name  = 'Maprotiline_Alkalay1980_reference_params';
  p.drug  = 'maprotiline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1000.0;                % central volume [L]
  p.CL = 14.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.34;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.42;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
