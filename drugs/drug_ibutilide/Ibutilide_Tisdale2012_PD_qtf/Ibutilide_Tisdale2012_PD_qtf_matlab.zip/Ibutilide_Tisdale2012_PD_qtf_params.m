function p = Ibutilide_Tisdale2012_PD_qtf_params()
% Ibutilide_Tisdale2012_PD_qtf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibutilide Tisdale_2012::QTF: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response QTF in s. Driver: ibutilide (cited_pk).
p.E0 = 0.0;
p.Emax = 0.491;
p.EC50 = 4.799999999999999e-07;
p.gamma = 3.21;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4.8;
p.form = 'E0 + Emax*frac';
end
