function p = Ibutilide_Zeng2017_PD_qtc_params()
% Ibutilide_Zeng2017_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibutilide Zeng_2017::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/mL per second, in SI inside (kg/m3, s). Response QTc in s. Driver: ibutilide (pk_record).
p.E0 = 0.408;
p.Emax = 0.492;
p.EC50 = 6.44e-07;
p.gamma = 6.87;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 6500.0;
p.form = 'E0 + Emax*frac';
end
