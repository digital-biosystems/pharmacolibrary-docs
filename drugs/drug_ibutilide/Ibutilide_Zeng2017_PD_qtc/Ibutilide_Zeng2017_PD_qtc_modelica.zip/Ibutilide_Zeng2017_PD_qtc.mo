model Ibutilide_Zeng2017_PD_qtc
  "sigmoid_emax exposure-response sweep — Zeng_2017 :: QTc (QT interval)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.408,      // [s; s × 1]
    Emax = 0.492,  // [s; s × 1]
    EC50 = 6.44e-07,  // [kg/m3; pg/mL × 1e-09]
    gamma = 6.87,
    exposure_per_s = 1e-09);   // 1 pg/mL per second
  annotation(experiment(StartTime = 0, StopTime = 6500, Interval = 13),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ibutilide</h4><p>Ibutilide is a class III antiarrhythmic drug used to treat atrial fibrillation. It is an approved medicine, given by injection, and its use is generally restricted to hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3791612\">Wikidata Q3791612</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ibutilide_Zeng2017_PD_qtc</h4><p>The steady-state exposure-response curve of Zeng Z et al., <i>Clinical therapeutics 39(7):1320–1335</i> 2017 (<a href=\"https://doi.org/10.1016/j.clinthera.2017.05.349\">doi:10.1016/j.clinthera.2017.05.349</a>) — QT interval [s] against ibutilide pg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.408 s        drug-free response (baseline) (QT cb, Q324)
  Emax  =      0.492 s        maximal effect term (E max, Q320)
  EC50  =        644 pg/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       6.87          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pg/mL of ibutilide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.408   (drug-free)
  exposure = EC50 (644 pg/mL)  response 0.654
  exposure -> infinity  response 0.9</pre></body></html>"));
end Ibutilide_Zeng2017_PD_qtc;
