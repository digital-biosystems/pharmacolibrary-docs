model Ibutilide_Li2007_reference
  parameter Real Cl_ref = 7.933333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.99 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38457600000000003,
    adminMass = 1e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ibutilide</h4><p>Ibutilide is a class III antiarrhythmic drug used to treat atrial fibrillation. It is an approved medicine, given by injection, and its use is generally restricted to hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3791612\">Wikidata Q3791612</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibutilide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2007</td></tr><tr><td>measured_compound:</td><td>ibutilide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ibutilide 384.576 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2007) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ibutilide_Li2007_reference;
