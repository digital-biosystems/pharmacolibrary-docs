function p = Ibutilide_Li2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibutilide   source: Li_2007 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ibutilide_Li2007_reference_params';
  p.drug  = 'ibutilide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3990.0;                % central volume [L]
  p.CL = 285.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
