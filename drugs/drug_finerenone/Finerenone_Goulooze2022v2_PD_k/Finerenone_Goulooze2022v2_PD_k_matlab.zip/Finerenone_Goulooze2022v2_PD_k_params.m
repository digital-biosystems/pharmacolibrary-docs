function p = Finerenone_Goulooze2022v2_PD_k_params()
% Finerenone_Goulooze2022v2_PD_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% finerenone Goulooze_2022_2::K: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg × h/L per second, in SI inside (kg/m3, s). Response K in mmol/L. Driver: finerenone (cited_pk).
p.E0 = 4.499999999999999;
p.Emax = 0.0905;
p.EC50 = 0.512;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 5.7;
p.form = 'E0/(1 - Emax*frac)';
end
