model Finerenone_Goulooze2022v2_PD_k
  "indirect_response_ii exposure-response sweep — Goulooze_2022_2 :: K (serum potassium)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4.5,      // [mol/m3; mmol/L × 1]
    Emax = 0.0905,  // type II effect term
    EC50 = 0.512,  // [mg × h/L]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg × h/L per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // exposure_unit_unresolved: 'mg × h/L' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.7, Interval = 0.0114),
    Documentation(info = "<html><body><!-- drug-about --><h4>About finerenone</h4><p>Finerenone is a nonsteroidal aldosterone antagonist used to treat chronic kidney disease associated with type 2 diabetes, and has also been studied for chronic heart failure. It is approved and authorised in the European Union, and remains under investigation for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21099046\">Wikidata Q21099046</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Finerenone_Goulooze2022v2_PD_k</h4><p>The steady-state exposure-response curve of Goulooze SC et al., <i>Clinical pharmacokinetics 61(3):451–462</i> 2022 (<a href=\"https://doi.org/10.1007/s40262-021-01083-1\">doi:10.1007/s40262-021-01083-1</a>) — serum potassium [mmol/L] against finerenone mg × h/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        4.5 mmol/L   drug-free response (baseline) (BSL, Q324)
  Emax  =     0.0905          maximal effect term (Emax, Q320)
  EC50  =      0.512 mg × h/L exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg × h/L of finerenone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.5   (drug-free)
  exposure = EC50 (0.512 mg × h/L)  response 4.713
  exposure -> infinity  response 4.948</pre></body></html>"));
end Finerenone_Goulooze2022v2_PD_k;
