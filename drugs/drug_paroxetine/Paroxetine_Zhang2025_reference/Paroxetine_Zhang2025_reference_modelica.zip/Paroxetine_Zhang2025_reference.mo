model Paroxetine_Zhang2025_reference
  parameter Real Cl_ref = 5.444444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.197 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00023916666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paroxetine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhang_2025</td></tr><tr><td>measured_compound:</td><td>paroxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Paroxetine_Zhang2025_reference;
