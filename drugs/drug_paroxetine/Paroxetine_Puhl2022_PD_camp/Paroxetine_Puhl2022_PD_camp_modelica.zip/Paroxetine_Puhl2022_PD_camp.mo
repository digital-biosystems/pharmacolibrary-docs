model Paroxetine_Puhl2022_PD_camp
  "emax exposure-response sweep — Puhl_2022 :: cAMP (cAMP stimulation in A2AAR-expressing cells)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.69,  // [1; % × 0.01]
    EC50 = 14,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><!-- drug-about --><h4>About paroxetine</h4><p>Paroxetine is a selective serotonin reuptake inhibitor antidepressant used for conditions such as depression, anxiety disorders, panic disorder, obsessive-compulsive disorder, and post-traumatic stress disorder. It is an approved medicine in widespread clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408471\">Wikidata Q408471</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Paroxetine_Puhl2022_PD_camp</h4><p>The steady-state exposure-response curve of Puhl AC et al., <i>Frontiers in pharmacology 13:920643</i> 2022 (<a href=\"https://doi.org/10.3389/fphar.2022.920643\">doi:10.3389/fphar.2022.920643</a>) — cAMP stimulation in A2AAR-expressing cells against paroxetine µM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         69 %        maximal effect term (Emax, Q320)
  EC50  =         14 µM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of paroxetine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (14 µM)  response 0.345
  exposure -> infinity  response 0.69</pre></body></html>"));
end Paroxetine_Puhl2022_PD_camp;
