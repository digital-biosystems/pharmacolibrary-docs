function p = Lithium_Yu2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lithium   source: Yu_2016 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Lithium_Yu2016_reference_params';
  p.drug  = 'lithium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1460.0;                % central volume [L]
  p.CL = 9.39;                % clearance [L/h]
  p.Vp = [10.4];             % peripheral volumes [L]
  p.Q  = [22.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.03;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.186;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
