model Lithium_Rosenthal1986_reference
  parameter Real Cl_ref = 1.1793129113693514e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01323 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.00694,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lithium</h4><p>Lithium is a mood stabilizer used primarily to treat bipolar disorder and major depressive disorder. It is administered orally by mouth. Blood levels are routinely measured to guide dosing and reduce the risk of toxicity. Lithium is a WHO essential medicine available as a generic medication.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q152763\">Wikidata Q152763</a>, <a href=\"https://en.wikipedia.org/wiki/Lithium_(medication)?oldid=1381376200\">Wikipedia</a> (CC BY-SA 4.0), the WHO ATC classification and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lithium</td></tr><tr><td>population:</td><td>adult dogs</td></tr><tr><td>source_paper:</td><td>Rosenthal_1986</td></tr><tr><td>measured_compound:</td><td>lithium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lithium 6.94 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lithium</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'mean apparent specific volume of distribution of the central compartment (V'c)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL=0.424553 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Lithium_Rosenthal1986_reference;
