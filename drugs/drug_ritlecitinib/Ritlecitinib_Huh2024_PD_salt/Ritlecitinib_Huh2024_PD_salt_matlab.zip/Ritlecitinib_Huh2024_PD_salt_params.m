function p = Ritlecitinib_Huh2024_PD_salt_params()
% Ritlecitinib_Huh2024_PD_salt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ritlecitinib Huh_2024::SALT: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response SALT in its own unit. Driver: ritlecitinib (cited_pk).
p.E0 = 0.0;
p.Emax = 15.8;
p.EC50 = 5.36e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 540.0;
p.form = 'E0*(1 + Emax*frac)';
end
