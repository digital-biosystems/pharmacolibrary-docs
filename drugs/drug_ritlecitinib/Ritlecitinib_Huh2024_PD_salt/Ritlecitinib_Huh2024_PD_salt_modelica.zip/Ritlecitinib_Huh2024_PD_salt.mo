model Ritlecitinib_Huh2024_PD_salt
  "indirect_response_iii exposure-response sweep — Huh_2024 :: SALT (SALT score)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 15.8,  // type III effect term
    EC50 = 5.36e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 540, Interval = 1.08),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ritlecitinib</h4><p>Ritlecitinib is a JAK inhibitor medicine used to treat alopecia areata, a condition causing hair loss. It is authorised in the European Union and is an approved, relatively new treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q120487896\">Wikidata Q120487896</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ritlecitinib_Huh2024_PD_salt</h4><p>The steady-state exposure-response curve of Huh Y et al., <i>Clinical pharmacokinetics 63(3):381–394</i> 2024 (<a href=\"https://doi.org/10.1007/s40262-024-01347-6\">doi:10.1007/s40262-024-01347-6</a>) — SALT score against ritlecitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       15.8          maximal effect term (Emax, Q320)
  EC50  =       53.6 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of ritlecitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (53.6 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ritlecitinib_Huh2024_PD_salt;
