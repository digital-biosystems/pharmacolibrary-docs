model Ritlecitinib_Wang2025_PD_eba
  "indirect_response_iii exposure-response sweep — Wang_2025 :: EBA (eyebrow assessment)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 6.05,      // [1]
    Emax = 11,  // type III effect term
    EC50 = 1.06e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ritlecitinib</h4><p>Ritlecitinib is a JAK inhibitor medicine used to treat alopecia areata, a condition causing hair loss. It is authorised in the European Union and is an approved, relatively new treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q120487896\">Wikidata Q120487896</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ritlecitinib_Wang2025_PD_eba</h4><p>The steady-state exposure-response curve of Wang Y et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(2):389–402</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.13283\">doi:10.1002/psp4.13283</a>) — eyebrow assessment against ritlecitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.05          drug-free response (baseline) (Baseline (B 1), Q324)
  Emax  =         11          maximal effect term (Maximum Drug effect (E max), Q320)
  EC50  =       10.6 ng/mL    exposure at half of the maximal effect term (Drug concentration producing half of the maximum stimulation (EC 50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of ritlecitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.05   (drug-free)
  exposure = EC50 (10.6 ng/mL)  response 39.32
  exposure -> infinity  response 72.6</pre></body></html>"));
end Ritlecitinib_Wang2025_PD_eba;
