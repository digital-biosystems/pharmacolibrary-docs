function p = Ritlecitinib_Wang2025_PD_ela_params()
% Ritlecitinib_Wang2025_PD_ela_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ritlecitinib Wang_2025::ELA: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ELA in its own unit. Driver: ritlecitinib (cited_pk).
p.E0 = 7.31;
p.Emax = 7.75;
p.EC50 = 1.0199999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 110.0;
p.form = 'E0*(1 + Emax*frac)';
end
