model Ritlecitinib_Huh2025_PD_qtcf
  "linear exposure-response sweep — Huh_2025 :: ∆QTcF (change from baseline heart rate– corrected QTcF (∆QTcF))"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.213,  // [meter ** 3 * second / kilogram; ms/ng/mL × 1000]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ritlecitinib</h4><p>Ritlecitinib is a JAK inhibitor medicine used to treat alopecia areata, a condition causing hair loss. It is authorised in the European Union and is an approved, relatively new treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q120487896\">Wikidata Q120487896</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ritlecitinib_Huh2025_PD_qtcf</h4><p>The steady-state exposure-response curve of Huh Y et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(6):1108–1118</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.70030\">doi:10.1002/psp4.70030</a>) — change from baseline heart rate– corrected QTcF (∆QTcF) [ms] against ritlecitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =   0.000213 ms/ng/mL change in response per unit of exposure (Slope (ms/ng/mL), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of ritlecitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ritlecitinib_Huh2025_PD_qtcf;
