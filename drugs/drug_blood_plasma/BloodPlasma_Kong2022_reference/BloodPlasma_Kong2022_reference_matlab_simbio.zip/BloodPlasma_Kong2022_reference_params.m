function p = BloodPlasma_Kong2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: blood_plasma   source: Kong_2022 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'BloodPlasma_Kong2022_reference_params';
  p.drug  = 'blood_plasma';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 80.49;                % central volume [L]
  p.CL = 41.15;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.48;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
