function p = BloodPlasma_Alshehri2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: blood_plasma   source: Alshehri_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'BloodPlasma_Alshehri2023_reference_params';
  p.drug  = 'blood_plasma';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 138.0;                % central volume [L]
  p.CL = 7.02;                % clearance [L/h]
  p.Vp = [424.33];             % peripheral volumes [L]
  p.Q  = [9.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.71;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.75;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
