model BloodPlasma_Alshehri2023_reference
  parameter Real Cl_ref = 1.95e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.138 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00019722222222222222,
    Tlag = 2700.0,
    k12 = 1.8337359098228662e-05,
    k21 = 5.963649884654763e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>blood_plasma</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Alshehri_2023</td></tr><tr><td>measured_compound:</td><td>blood_plasma</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Alshehri_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end BloodPlasma_Alshehri2023_reference;
