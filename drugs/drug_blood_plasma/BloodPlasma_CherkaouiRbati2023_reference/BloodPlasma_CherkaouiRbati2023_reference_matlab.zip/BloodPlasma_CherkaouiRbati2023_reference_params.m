function p = BloodPlasma_CherkaouiRbati2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: blood_plasma   source: Cherkaoui-Rbati_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'BloodPlasma_CherkaouiRbati2023_reference_params';
  p.drug  = 'blood_plasma';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.58;                % central volume [L]
  p.CL = 0.476;                % clearance [L/h]
  p.Vp = [57.3];             % peripheral volumes [L]
  p.Q  = [37.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.147;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
