model BloodPlasma_Yu2022_reference
  parameter Real Cl_ref = 3.935185185185186e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0026200000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.8171296296296296e-06,
    Tlag = 0.0,
    k12 = 1.5814956177551594e-06,
    k21 = 1.4798280423280424e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>blood_plasma</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yu_2022</td></tr><tr><td>measured_compound:</td><td>blood_plasma</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yu_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end BloodPlasma_Yu2022_reference;
