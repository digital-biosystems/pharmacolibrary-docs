function p = BloodPlasma_Yu2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: blood_plasma   source: Yu_2022 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'BloodPlasma_Yu2022_reference_params';
  p.drug  = 'blood_plasma';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.62;                % central volume [L]
  p.CL = 0.014167;                % clearance [L/h]
  p.Vp = [2.8];             % peripheral volumes [L]
  p.Q  = [0.014917];             % inter-compartmental clearances [L/h]
  p.ka = 0.006542;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
