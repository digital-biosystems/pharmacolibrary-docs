function p = Mexiletine_Vozeh1982_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mexiletine   source: Vozeh_1982 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Mexiletine_Vozeh1982_reference_params';
  p.drug  = 'mexiletine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 371.0;                % central volume [L]
  p.CL = 26.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.1;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.3;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
