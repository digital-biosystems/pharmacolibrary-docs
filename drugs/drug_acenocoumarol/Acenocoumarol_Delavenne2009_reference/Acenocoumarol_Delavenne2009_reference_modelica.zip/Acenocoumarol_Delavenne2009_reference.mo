// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Acenocoumarol_Delavenne2009_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.329, 0.0245},
    CLelim = {1.1333333333333334e-06, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {5.000000000000001e-07, 5.000000000000001e-07}
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About acenocoumarol</h4><p>Acenocoumarol is an anticoagulant, a vitamin K antagonist used to prevent and treat blood clots. It is an approved medicine and is used mainly in Europe, where it is often preferred over warfarin in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304088\">Wikidata Q304088</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>acenocoumarol</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Delavenne_2009</td></tr><tr><td>measured_compound:</td><td>acenocoumarol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table IV</td></tr><tr><td>molar_masses:</td><td>acenocoumarol 353.325 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('Cl (L/h)'=4.08) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V 2 (L)'=24.5) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q (L/h)'=1.8) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (/h)'=4.04) from results prose — parameter table was unreadable</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (Cl (L/h)); Q64 (V 2 (L)); Q30 (Q (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acenocoumarol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Chen_2024's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Acenocoumarol_Delavenne2009_reference;
