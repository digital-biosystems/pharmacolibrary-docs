model Acenocoumarol_Delavenne2009_reference
  parameter Real Cl_ref = 1.1333333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0011222222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acenocoumarol</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Delavenne_2009</td></tr><tr><td>measured_compound:</td><td>acenocoumarol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table IV</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('Cl (L/h)'=4.08) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V 2 (L)'=24.5) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q (L/h)'=1.8) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (/h)'=4.04) from results prose — parameter table was unreadable</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (Cl (L/h)); Q64 (V 2 (L)); Q30 (Q (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acenocoumarol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Chen_2024's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>unit re-normalised: kabs '/h' now converts (value unchanged)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Acenocoumarol_Delavenne2009_reference;
