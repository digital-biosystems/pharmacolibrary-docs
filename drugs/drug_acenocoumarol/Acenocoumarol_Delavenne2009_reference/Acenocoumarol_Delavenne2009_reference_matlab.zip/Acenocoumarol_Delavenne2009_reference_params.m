function p = Acenocoumarol_Delavenne2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: acenocoumarol   source: Delavenne_2009 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Acenocoumarol_Delavenne2009_reference_params';
  p.drug  = 'acenocoumarol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 4.08;                % clearance [L/h]
  p.Vp = [24.5];             % peripheral volumes [L]
  p.Q  = [1.8];             % inter-compartmental clearances [L/h]
  p.ka = 4.04;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
