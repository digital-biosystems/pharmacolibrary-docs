function p = Palonosetron_Li2026_palonosetron_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: palonosetron   source: Li_2026 / palonosetron   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Palonosetron_Li2026_palonosetron_params';
  p.drug  = 'palonosetron';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 839.62;                % central volume [L]
  p.CL = 7.92;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
