model Evinacumab_Bihorel2025_PD_ldl_c
  "indirect_response_i exposure-response sweep — Bihorel_2025 :: LDL-C (LDL-C)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.14,      // [kg/m3; mg/dL × 0.01]
    Emax = 0.574,  // type I effect term
    EC50 = 0.0327,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 330, Interval = 0.66),
    Documentation(info = "<html><body><!-- drug-about --><h4>About evinacumab</h4><p>Evinacumab is a monoclonal antibody used as a lipid-modifying agent for hypercholesterolemia and type I hyperlipoproteinemia. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19904115\">Wikidata Q19904115</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Evinacumab_Bihorel2025_PD_ldl_c</h4><p>The steady-state exposure-response curve of Bihorel S et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(11):1823–1834</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.70016\">doi:10.1002/psp4.70016</a>) — LDL-C [mg/dL] against evinacumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        214 mg/dL    drug-free response (baseline) (LDLC0, Q324)
  Emax  =      0.574          maximal effect term (Imax, Q323)
  EC50  =       32.7 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of evinacumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.14   (drug-free)
  exposure = EC50 (32.7 mg/L)  response 1.526
  exposure -> infinity  response 0.9116</pre></body></html>"));
end Evinacumab_Bihorel2025_PD_ldl_c;
