function p = Evinacumab_Pu2021_PD_ldl_c_params()
% Evinacumab_Pu2021_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% evinacumab Pu_2021::LDL_C: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response LDL-C in mg/dl. Driver: evinacumab (cited_pk).
p.E0 = 0.0;
p.Emax = 0.74;
p.EC50 = 0.057399999999999986;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 580.0;
p.form = 'E0*(1 - Emax*frac)';
end
