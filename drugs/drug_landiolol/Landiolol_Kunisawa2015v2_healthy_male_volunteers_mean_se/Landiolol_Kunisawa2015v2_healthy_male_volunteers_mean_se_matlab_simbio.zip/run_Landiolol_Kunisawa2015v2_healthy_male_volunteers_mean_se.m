% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Landiolol_Kunisawa2015v2_healthy_male_volunteers_mean_se_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
