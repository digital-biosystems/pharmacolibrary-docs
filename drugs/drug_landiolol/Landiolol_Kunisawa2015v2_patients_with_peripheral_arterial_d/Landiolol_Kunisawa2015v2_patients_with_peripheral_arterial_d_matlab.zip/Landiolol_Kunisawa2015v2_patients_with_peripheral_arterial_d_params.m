function p = Landiolol_Kunisawa2015v2_patients_with_peripheral_arterial_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: landiolol   source: Kunisawa_2015_2 / patients_with_peripheral_arterial_disease_mean_se   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Landiolol_Kunisawa2015v2_patients_with_peripheral_arterial_d_params';
  p.drug  = 'landiolol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.55;                % central volume [L]
  p.CL = 128.94;                % clearance [L/h]
  p.Vp = [3.808];             % peripheral volumes [L]
  p.Q  = [202.86];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.01055;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
