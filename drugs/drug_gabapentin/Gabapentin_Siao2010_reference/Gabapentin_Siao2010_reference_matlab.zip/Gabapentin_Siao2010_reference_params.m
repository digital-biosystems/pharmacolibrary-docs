function p = Gabapentin_Siao2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gabapentin   source: Siao_2010 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Gabapentin_Siao2010_reference_params';
  p.drug  = 'gabapentin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.328;                % central volume [L]
  p.CL = 12.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.24;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.45;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
