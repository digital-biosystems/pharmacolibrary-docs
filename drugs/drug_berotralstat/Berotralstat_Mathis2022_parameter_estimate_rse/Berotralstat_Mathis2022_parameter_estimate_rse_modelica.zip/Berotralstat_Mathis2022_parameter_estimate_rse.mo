model Berotralstat_Mathis2022_parameter_estimate_rse
  parameter Real Cl_ref = 1.3138888888888888e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6500000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.497,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 1684.8000000000002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>berotralstat</td></tr><tr><td>population:</td><td>healthy subjects and patients with hereditary angioedema</td></tr><tr><td>source_paper:</td><td>Mathis_2022</td></tr><tr><td>measured_compound:</td><td>berotralstat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13233-tbl-0001</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q48 ('K32 (1/h)', value '0.0309') — already have one for this compound</li><li>dropped duplicate Q48 ('K24 (1/h)', value '0.00281') — already have one for this compound</li><li>dropped duplicate Q48 ('K42 (1/h)', value '0.00136') — already have one for this compound</li><li>dropped duplicate Q61 ('Volume as a function of weight', value '1.00') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=berotralstat</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'parameter estimate (rse%)' subgroup of Mathis_2022 (paper reports 6 populations: adolescents (12–18 years), low weight adults (60–80 kg), normal weight adults (80–100 kg), overweight adults (100–120 kg), parameter estimate (rse%), underweight adults (40–60 kg))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Berotralstat_Mathis2022_parameter_estimate_rse;
