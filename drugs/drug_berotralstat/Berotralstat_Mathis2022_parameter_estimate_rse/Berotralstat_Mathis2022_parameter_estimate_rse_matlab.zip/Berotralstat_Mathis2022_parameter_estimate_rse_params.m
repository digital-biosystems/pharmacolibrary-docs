function p = Berotralstat_Mathis2022_parameter_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: berotralstat   source: Mathis_2022 / parameter_estimate_rse   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Berotralstat_Mathis2022_parameter_estimate_rse_params';
  p.drug  = 'berotralstat';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1650.0;                % central volume [L]
  p.CL = 47.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.497;                 % bioavailability [0-1]
  p.Tlag = 0.468;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
