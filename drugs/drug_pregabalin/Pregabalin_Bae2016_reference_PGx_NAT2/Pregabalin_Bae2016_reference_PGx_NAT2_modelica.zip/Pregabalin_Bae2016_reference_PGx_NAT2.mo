model Pregabalin_Bae2016_reference_PGx_NAT2
  "Pregabalin_Bae2016_reference with the NAT2 phenotype as a parameter (Bae_2016)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "NAT2 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {3.22222222222e-07, 3.03082222222e-07, 3.0624e-07, 3.22222222222e-07, 3.22222222222e-07, 3.22222222222e-07};
  extends Pregabalin_Bae2016_reference(Cl = Cl_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pregabalin</h4><p>Pregabalin is used for epilepsy, anxiety disorders, and various types of neuropathic pain such as neuralgia. It is widely used and authorised in the European Union, where several products remain on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412174\">Wikidata Q412174</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Pregabalin_Bae2016_reference_PGx_NAT2;
