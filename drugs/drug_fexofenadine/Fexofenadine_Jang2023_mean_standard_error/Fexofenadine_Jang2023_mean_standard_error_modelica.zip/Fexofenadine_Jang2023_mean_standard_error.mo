model Fexofenadine_Jang2023_mean_standard_error
  parameter Real Cl_ref = 2.1075e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.25919 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5016564,
    adminMass = 6e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fexofenadine</h4><p>Fexofenadine is a non-sedating antihistamine used to treat allergic conditions such as allergic rhinitis and urticaria. It is an approved medicine and is widely used for allergy relief.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415122\">Wikidata Q415122</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fexofenadine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Jang_2023</td></tr><tr><td>measured_compound:</td><td>fexofenadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl5</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>fexofenadine 501.656 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'mean ± standard error' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± standard error' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± standard error' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± standard error' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± standard error' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± standard error' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>dropped duplicate Q900 ('B', value '2028.31') — already have one for this compound</li><li>dropped duplicate Q900 ('C', value '0.03') — already have one for this compound</li><li>dropped unlinked row (NIL): 'AIC' — extend the ontology if this is a real PK parameter (source ['tbl5:row6:col1'])</li><li>salvaged Q76 ('Table 1: V/F (L)∗, TT'=259.19) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('Table 1: CL/F (L/h)∗, TT'=75.87) from results prose — parameter table was unreadable</li><li>implicit units: 'D' → h (from the popPK convention: 'D is the duration of a zero-order input, so it has units of time; hours are the usual population-PK convention and are c')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=fexofenadine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'mean ± standard error' subgroup of Jang_2023 (paper reports 3 populations: mean ± standard error, slco1b1 521t > c genotypes, slco2b1 1457c > t genotypes)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fexofenadine_Jang2023_mean_standard_error;
