model Fexofenadine_Gaspar2025_reference
  parameter Real Cl_ref = 1.2866666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0149 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5016564,
    adminMass = 2.5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.0009697986577181209,
    k21 = 9.91763898421414e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fexofenadine</h4><p>Fexofenadine is a non-sedating antihistamine used to treat allergic conditions such as allergic rhinitis and urticaria. It is an approved medicine and is widely used for allergy relief.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415122\">Wikidata Q415122</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fexofenadine</td></tr><tr><td>population:</td><td>hospitalized patients and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Gaspar_2025</td></tr><tr><td>measured_compound:</td><td>fexofenadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>fexofenadine 501.656 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameters'</li><li>dropped value-less row: 'CL (L/h)' (captured trailing unit 'L/h' for child rows)</li><li>dropped value-less row: 'β CLcr'</li><li>dropped value-less row: 'V1 (L)' (captured trailing unit 'L' for child rows)</li><li>dropped value-less row: 'Q (L/h)' (captured trailing unit 'L/h' for child rows)</li><li>dropped value-less row: 'V2 (L)' (captured trailing unit 'L' for child rows)</li><li>NIL: refused to back-fill base 'equation variable' from footnote/prose loose number 0.32 (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'βAGE'</li><li>dropped value-less row: 'βPGP'</li><li>salvaged Q22 ('mean estimated creatinine clearance'=77.2) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=114.64) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V1/F'=14.9) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('V2/F'=145.7) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=52.02) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=fexofenadine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fexofenadine_Gaspar2025_reference;
