model Fexofenadine_Jang2023_slco2b1_1457c_t_genotypes
  parameter Real Cl_ref = 1.0802777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16690000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5016564,
    adminMass = 6e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fexofenadine</h4><p>Fexofenadine is a non-sedating antihistamine used to treat allergic conditions such as allergic rhinitis and urticaria. It is an approved medicine and is widely used for allergy relief.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415122\">Wikidata Q415122</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fexofenadine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Jang_2023</td></tr><tr><td>measured_compound:</td><td>fexofenadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl5</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>fexofenadine 501.656 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q19 ('AUC108−120 (h·ng/mL)', value '5615.91') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC108−∞ (h·ng/mL)', value '6038.29') — already have one for this compound</li><li>implicit units: 'cSS,mean (ng/mL) a' → ng/mL (from the paper text: 'The parameter is printed as “cSS,mean (ng/mL)”; the table explicitly gives the unit ng/mL.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=fexofenadine</li><li>population split: 'slco2b1 1457c > t genotypes' subgroup of Jang_2023 (paper reports 3 populations: mean ± standard error, slco1b1 521t > c genotypes, slco2b1 1457c > t genotypes)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fexofenadine_Jang2023_slco2b1_1457c_t_genotypes;
