model Fexofenadine_Jang2023_reference
  parameter Real Cl_ref = 2.1075e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.25919 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5016564,
    adminMass = 6e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fexofenadine</h4><p>Fexofenadine is a second-generation antihistamine used to treat allergic rhinitis and urticaria. It is given by mouth in tablet, capsule, or suspension form and is well absorbed from the gut. It is widely used, with generic options available in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q415122\">Wikidata Q415122</a>, <a href=\"https://en.wikipedia.org/wiki/Fexofenadine?oldid=1385622892\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fexofenadine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Jang_2023</td></tr><tr><td>measured_compound:</td><td>fexofenadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl5</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>fexofenadine 501.656 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'A' — extend the ontology if this is a real PK parameter (source ['tbl5:row2:col1'])</li><li>dropped unlinked row (NIL): 'B' — extend the ontology if this is a real PK parameter (source ['tbl5:row3:col1'])</li><li>salvaged Q76 ('V/F (L)'=259.19) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F (L/h)'=75.87) from results prose — parameter table was unreadable</li><li>implicit units: 'D' → h (from the popPK convention: 'The parameter D is defined as the duration of a zero-order input (time). In the provided text, the dosing interval (tau)')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=fexofenadine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fexofenadine_Jang2023_reference;
