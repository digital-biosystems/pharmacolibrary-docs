function p = Fexofenadine_Jang2023_slco1b1_521t_c_genotypes_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fexofenadine   source: Jang_2023 / slco1b1_521t_c_genotypes   route: oral
  % estimated (absent from source): ka
  p.name  = 'Fexofenadine_Jang2023_slco1b1_521t_c_genotypes_params';
  p.drug  = 'fexofenadine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 259.19;                % central volume [L]
  p.CL = 75.87;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
