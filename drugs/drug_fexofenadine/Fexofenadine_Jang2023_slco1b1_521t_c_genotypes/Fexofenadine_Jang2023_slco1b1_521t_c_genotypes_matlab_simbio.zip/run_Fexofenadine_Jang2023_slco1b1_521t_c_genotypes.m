% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Fexofenadine_Jang2023_slco1b1_521t_c_genotypes_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
