// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model AmositeAsbestos_Hesterberg1998_amosite
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1728000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amosite_asbestos</td></tr><tr><td>population:</td><td>Fisher rats</td></tr><tr><td>source_paper:</td><td>Hesterberg_1998</td></tr><tr><td>measured_compound:</td><td>Amosite asbestos</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>TABLE 5</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>amosite_asbestos 309.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '% of total' — extend the ontology if this is a real PK parameter (source ['Hesterberg_1998_table_6:row1:col1'])</li><li>dropped duplicate Q57 ('Weighted half-times WT1/2', value '418') — already have one for this compound</li><li>dropped unlinked row (NIL): '90% clearance T-90' — extend the ontology if this is a real PK parameter (source ['Hesterberg_1998_table_6:row1:col8'])</li><li>implicit units: 'Faster pool T1/2' → d (from the paper text: &quot;The section 'Mathematical Models of Lung Fiber Clearance' defines the model variables stating 'x = recovery time in days&quot;)</li><li>implicit units: 'Slower pool T1/2' → d (from the paper text: &quot;The section 'Mathematical Models of Lung Fiber Clearance' defines the model variables stating 'x = recovery time in days&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Amosite asbestos</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'amosite' subgroup of Hesterberg_1998 (paper reports 9 populations: amosite, mmvf10, mmvf11, mmvf21, mmvf22, mmvf32, mmvf33, mmvf34, rcf1a)</li><li>molar mass: no plausible PubChem entry for 'Amosite asbestos' ('amosite asbestos') — left in mass units</li><li>molar mass: none found for 'Amosite asbestos' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 18144.0));
end AmositeAsbestos_Hesterberg1998_amosite;
