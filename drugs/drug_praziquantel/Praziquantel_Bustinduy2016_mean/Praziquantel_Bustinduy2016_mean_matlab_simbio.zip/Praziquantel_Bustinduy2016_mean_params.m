function p = Praziquantel_Bustinduy2016_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: praziquantel   source: Bustinduy_2016 / mean   route: oral
  p.name  = 'Praziquantel_Bustinduy2016_mean_params';
  p.drug  = 'praziquantel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 473.97;                % central volume [L]
  p.CL = 608.02;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 14.89;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2800.0;             % dose [mg]
end
