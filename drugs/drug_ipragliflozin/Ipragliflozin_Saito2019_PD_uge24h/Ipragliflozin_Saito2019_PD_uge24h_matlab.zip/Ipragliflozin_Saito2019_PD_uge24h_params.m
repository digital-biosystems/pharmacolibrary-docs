function p = Ipragliflozin_Saito2019_PD_uge24h_params()
% Ipragliflozin_Saito2019_PD_uge24h_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ipragliflozin Saito_2019::UGE24h: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·h/mL per second, in SI inside (kg/m3, s). Response ΔUGE24h in g. Driver: ipragliflozin (pk_record).
p.E0 = 0.0;
p.Emax = 72.3;
p.EC50 = 1590.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 16000.0;
p.form = 'E0 + Emax*frac';
end
