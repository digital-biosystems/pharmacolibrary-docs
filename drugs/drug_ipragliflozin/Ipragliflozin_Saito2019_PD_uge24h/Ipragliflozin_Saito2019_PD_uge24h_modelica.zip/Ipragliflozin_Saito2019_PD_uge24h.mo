model Ipragliflozin_Saito2019_PD_uge24h
  "emax exposure-response sweep — Saito_2019 :: ΔUGE24h (change from baseline in UGE for 24 hours)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 72.3,  // [g/24 h]
    EC50 = 1590,  // [ng·h/mL]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng·h/mL per second
  // exposure_unit_unresolved: 'ng·h/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16000, Interval = 32),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ipragliflozin</h4><p>Ipragliflozin is a sodium-glucose co-transporter 2 inhibitor, a class of blood glucose-lowering drugs developed for diabetes. It is not authorised in the European Union and is considered investigational, though it has been used in Japan.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17193526\">Wikidata Q17193526</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ipragliflozin_Saito2019_PD_uge24h</h4><p>The steady-state exposure-response curve of Saito M et al., <i>British journal of clinical pharmacology 85(8):1808–1819</i> 2019 (<a href=\"https://doi.org/10.1111/bcp.13972\">doi:10.1111/bcp.13972</a>) — change from baseline in UGE for 24 hours [g] against ipragliflozin ng·h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       72.3 g/24 h   maximal effect term (Emax, Q320)
  EC50  =       1590 ng·h/mL  exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng·h/mL of ipragliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1590 ng·h/mL)  response 36.15
  exposure -> infinity  response 72.3</pre></body></html>"));
end Ipragliflozin_Saito2019_PD_uge24h;
