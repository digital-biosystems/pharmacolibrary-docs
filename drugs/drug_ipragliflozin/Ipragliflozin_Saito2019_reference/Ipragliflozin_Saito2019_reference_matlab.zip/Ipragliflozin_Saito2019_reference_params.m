function p = Ipragliflozin_Saito2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ipragliflozin   source: Saito_2019 / reference   route: oral
  p.name  = 'Ipragliflozin_Saito2019_reference_params';
  p.drug  = 'ipragliflozin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 39.4;                % central volume [L]
  p.CL = 9.47;                % clearance [L/h]
  p.Vp = [68.1];             % peripheral volumes [L]
  p.Q  = [6.63];             % inter-compartmental clearances [L/h]
  p.ka = 6.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
