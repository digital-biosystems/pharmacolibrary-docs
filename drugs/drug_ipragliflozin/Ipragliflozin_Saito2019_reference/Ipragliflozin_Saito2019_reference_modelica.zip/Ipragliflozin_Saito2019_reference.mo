model Ipragliflozin_Saito2019_reference
  parameter Real Cl_ref = 2.630555555555556e-06 "Cl [m3/s]";
  parameter Real cov_gfr_0 = 0 "gfr covariate";
  parameter Real Vd_ref = 0.0394 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.233)*cov_gfr_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40445,
    adminMass = 1e-06,
    ka = 0.0017722222222222221,
    Tlag = 0.0,
    k12 = 4.674280879864636e-05,
    k21 = 2.7043563387175723e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ipragliflozin</h4><p>Ipragliflozin is a sodium-glucose co-transporter 2 inhibitor, a class of blood glucose-lowering drugs developed for diabetes. It is not authorised in the European Union and is considered investigational, though it has been used in Japan.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17193526\">Wikidata Q17193526</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ipragliflozin</td></tr><tr><td>population:</td><td>type 2 diabetes mellitus patients</td></tr><tr><td>source_paper:</td><td>Saito_2019</td></tr><tr><td>measured_compound:</td><td>ipragliflozin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp13972-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ipragliflozin 404.45 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2: CL' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'σ2' routed out of structural estimates ('Residual error')</li><li>covariate level 'GFR effect on CL' → Q900:gfr_effect_on_cl = 0.233 (linear_fractional on Q22)</li><li>dropped duplicate Q22 ('TPRO effect on CL', value '-0.417') — already have one for this compound</li><li>dropped duplicate Q22 ('TBIL effect on CL', value '-0.0681') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ipragliflozin</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ipragliflozin_Saito2019_reference;
