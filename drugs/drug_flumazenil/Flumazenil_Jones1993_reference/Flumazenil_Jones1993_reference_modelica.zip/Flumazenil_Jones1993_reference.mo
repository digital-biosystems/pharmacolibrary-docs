model Flumazenil_Jones1993_reference
  parameter Real Cl_ref = 1.7966666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.133 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3032884,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flumazenil</h4><p>Flumazenil is a selective GABA-A receptor antagonist and antidote used to treat benzodiazepine overdoses and reverse anesthesia. It is given as an intravenous injection or administered intranasally. It is widely available in generic formulations.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421920\">Wikidata Q421920</a>, <a href=\"https://en.wikipedia.org/wiki/Flumazenil?oldid=1382292395\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flumazenil</td></tr><tr><td>population:</td><td>healthy children</td></tr><tr><td>source_paper:</td><td>Jones_1993</td></tr><tr><td>measured_compound:</td><td>flumazenil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flumazenil 303.288 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('flumazenil terminal elimination half-life', value 35.3) — already have one for this compound</li><li>dropped duplicate Q22 ('flumazenil total plasma clearance', value 20.6) — already have one for this compound</li><li>dropped duplicate Q65 ('flumazenil apparent volume of distribution at steady state', value 1.0) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flumazenil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flumazenil_Jones1993_reference;
