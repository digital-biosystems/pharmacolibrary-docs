model Thalidomide_Chen1989_reference
  parameter Real Cl_ref = 2.6710068078473757e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.12069 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.258233,
    adminMass = 0.0001,
    ka = 0.0005388888888888889,
    Tlag = 1476.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thalidomide</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Chen_1989</td></tr><tr><td>measured_compound:</td><td>Thalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thalidomide 258.233 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '% of the total dose administered over 24 hr' (fe)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Thalidomide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Murayama_2018's review values (primary lacked it)</li><li>derived CL/F=9.61562 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Thalidomide_Chen1989_reference;
