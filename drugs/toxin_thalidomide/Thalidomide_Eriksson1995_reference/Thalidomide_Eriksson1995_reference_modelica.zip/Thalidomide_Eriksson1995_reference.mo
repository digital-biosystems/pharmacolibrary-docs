// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Thalidomide_Eriksson1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {14678.410882445898},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thalidomide</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Eriksson_1995</td></tr><tr><td>measured_compound:</td><td>(+)-(R)- and (-)-(S)-thalidomide enantiomers</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>thalidomide 258.233 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'Mean rate constant for in vivo inversion (R to S)' Q100 → Q47: a rate constant in 'h-1' (the unit decides, not the label)</li><li>covariate category for kel from footnote/prose kept as documentation only (['Eriksson_1995:abstract'])</li><li>covariate category for kin from footnote/prose kept as documentation only (['Eriksson_1995:abstract'])</li><li>covariate category for kabs from footnote/prose kept as documentation only (['Eriksson_1995:abstract'])</li><li>covariate category for kel from footnote/prose kept as documentation only (['Eriksson_1995:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=(+)-(R)- and (-)-(S)-thalidomide enantiomers</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for '(+)-(R)- and (-)-(S)-thalidomide enantiomers' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Murayama_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Thalidomide_Eriksson1995_reference;
