model Thalidomide_Atoyebi2019_reference
  parameter Real Cl_ref = 3.7777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.252 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.258233,
    adminMass = 0.0001,
    ka = 0.0005388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thalidomide</td></tr><tr><td>population:</td><td>non-pregnant and pregnant women (maternofoetal PBPK simulation, n=100 virtual subjects)</td></tr><tr><td>source_paper:</td><td>Atoyebi_2019</td></tr><tr><td>measured_compound:</td><td>Thalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0020</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thalidomide 258.233 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Efavirenza' — extend the ontology if this is a real PK parameter (source ['Atoyebi_2019_table_2:row0:col1', 'Atoyebi_2019_table_2:row0:col2'])</li><li>dropped unlinked row (NIL): 'Thalidomideb' — extend the ontology if this is a real PK parameter (source ['Atoyebi_2019_table_2:row11:col2'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 400 (source ['t0020:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q27 ('400 mg efavirenz CL/F (L/h), Second trimester'=13.6) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd (L/kg)'=3.6) from results prose — parameter table was unreadable</li><li>salvaged Q47 ('K (10 cm2/s)'=1.1) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Thalidomide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Atoyebi_2019:other_prose, Atoyebi_2019:prose, Atoyebi_2019_table_2, t0020:footnote); populations observed values, second trimestern = 100, simulated values, third trimestern = 100 kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Murayama_2018's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q47 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Thalidomide_Atoyebi2019_reference;
