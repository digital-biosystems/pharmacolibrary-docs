function p = Thalidomide_Teo2004v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: thalidomide   source: Teo_2004_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Thalidomide_Teo2004v2_reference_params';
  p.drug  = 'thalidomide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.0;                % central volume [L]
  p.CL = 10.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.94;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
