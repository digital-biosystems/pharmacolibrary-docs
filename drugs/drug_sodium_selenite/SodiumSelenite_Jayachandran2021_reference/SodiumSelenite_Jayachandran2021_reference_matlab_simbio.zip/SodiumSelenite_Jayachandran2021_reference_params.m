function p = SodiumSelenite_Jayachandran2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_selenite   source: Jayachandran_2021 / reference   route: oral
  p.name  = 'SodiumSelenite_Jayachandran2021_reference_params';
  p.drug  = 'sodium_selenite';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.5;                % central volume [L]
  p.CL = 1.59;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.642;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.5;             % dose [mg]
end
