// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Mechlorethamine_Collins1983_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {39600.0},
    MM = 0.15605000000000002,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mechlorethamine</td></tr><tr><td>population:</td><td>fasted rats</td></tr><tr><td>source_paper:</td><td>Collins_1983</td></tr><tr><td>measured_compound:</td><td>Mechlorethamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>mechlorethamine 156.05 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'The t 1/2 of AP' Q58 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped 'The t 1/2 of AP' → Q57: unit 'fold' is a statistic (%, CV, RSE, shrinkage or fold), not a time — the row is a variability or a ratio, not the estimate</li><li>dropped 'the t 1/2 of AP' → Q57: unit 'fold' is a statistic (%, CV, RSE, shrinkage or fold), not a time — the row is a variability or a ratio, not the estimate</li><li>dropped duplicate Q57 ('The half-lives of 10 micrograms/ml HN2 and 5 micrograms/ml L-PAM', value 17.1) — already have one for this compound</li><li>implicit units: 'The t 1/2 of HN2 at 50 micrograms/ml' → h (from the popPK convention: 'No unit stated in text or table. For population PK, elimination half-lives (t1/2) are typically reported in hours (h), w')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mechlorethamine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Hasanah_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Mechlorethamine_Collins1983_reference;
