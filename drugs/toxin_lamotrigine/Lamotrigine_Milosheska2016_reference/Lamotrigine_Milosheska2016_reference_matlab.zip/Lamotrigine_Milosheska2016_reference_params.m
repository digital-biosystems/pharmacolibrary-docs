function p = Lamotrigine_Milosheska2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Milosheska_2016 / reference   route: oral
  p.name  = 'Lamotrigine_Milosheska2016_reference_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.6;                % central volume [L]
  p.CL = 2.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.96;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
