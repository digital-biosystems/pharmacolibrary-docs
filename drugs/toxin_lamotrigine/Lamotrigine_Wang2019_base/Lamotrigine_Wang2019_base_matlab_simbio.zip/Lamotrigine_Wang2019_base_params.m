function p = Lamotrigine_Wang2019_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Wang_2019 / base   route: oral
  p.name  = 'Lamotrigine_Wang2019_base_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.6;                % central volume [L]
  p.CL = 0.959;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.97;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
