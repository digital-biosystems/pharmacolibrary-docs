// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Lamotrigine_Ladumor2019_ugt2b17
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {623.8324625039508},
    MM = 0.25609,
    adminMass = 0.00014,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>healthy adults, paediatric populations (early/middle childhood), hepatic impaired (Child-Pugh C cirrhosis)</td></tr><tr><td>source_paper:</td><td>Ladumor_2019</td></tr><tr><td>measured_compound:</td><td>Lamotrigine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.09 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Ladumor_2019_table_3: rows are variants (UGT1A1, UGT1A3, UGT1A4, UGT1A6, UGT1A9, UGT2B4), the parameters are the column headers (k) — read one record per variant</li><li>implicit units: 'k' → 1/h (from the popPK convention: &quot;The parameter is defined as 'Elimination rate constant'. In population pharmacokinetics, first-order elimination rate co&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lamotrigine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>estimate-method split: 'UGT2B17' is one of 13 estimates of Ladumor_2019's substance matrix (UGT1A1, UGT1A3, UGT1A4, UGT1A6, UGT1A9, UGT2B4, UGT2B7, UGT2B10, UGT2B15, UGT2B17, CES1, FMO3, FMO5); same population, different estimation method</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Caleffi-Marchesini_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Damnjanović_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q32, Q88 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Lamotrigine_Ladumor2019_ugt2b17;
