function p = Lamotrigine_Polepally2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Polepally_2018 / reference   route: oral
  p.name  = 'Lamotrigine_Polepally2018_reference_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 79.1;                % central volume [L]
  p.CL = 27.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.57;                % absorption rate [1/h]
  p.F  = 0.74;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
