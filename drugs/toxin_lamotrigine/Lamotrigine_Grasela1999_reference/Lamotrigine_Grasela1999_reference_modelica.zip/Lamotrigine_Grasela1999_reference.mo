model Lamotrigine_Grasela1999_reference
  parameter Real Cl_ref = 1.1666666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0688 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25609,
    adminMass = 0.0003,
    ka = 0.00043611111111111113,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>adults with epilepsy</td></tr><tr><td>source_paper:</td><td>Grasela_1999</td></tr><tr><td>measured_compound:</td><td>Lamotrigine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.09 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for CL from footnote/prose kept as documentation only (['Grasela_1999:abstract'])</li><li>implicit units: 'reduction in clearance in non-whites' — the LLM proposed '%', whose dimension does not fit Q22; left unset</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Lamotrigine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q76 (V/F) from Huo_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Damnjanović_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Damnjanović_2023, Huo_2025 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q22 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Grasela1999_reference;
