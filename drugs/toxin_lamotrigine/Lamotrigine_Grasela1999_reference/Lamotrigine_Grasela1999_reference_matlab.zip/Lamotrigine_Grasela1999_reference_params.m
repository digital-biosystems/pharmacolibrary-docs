function p = Lamotrigine_Grasela1999_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Grasela_1999 / reference   route: oral
  p.name  = 'Lamotrigine_Grasela1999_reference_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 68.8;                % central volume [L]
  p.CL = 4.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.57;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
