model Lamotrigine_Zhang2008_reference
  parameter Real Cl_ref = 1.8444444444444446e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25609,
    adminMass = 0.0003,
    ka = 0.0011111111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>Chinese children with epilepsy</td></tr><tr><td>source_paper:</td><td>Zhang_2008</td></tr><tr><td>measured_compound:</td><td>Lamotrigine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.09 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'null' (CL)</li><li>unit_dimension_unknown: 'null' (V)</li><li>unit_dimension_unknown: 'null' (kabs)</li><li>unit_dimension_unknown: 'null' (CL/F)</li><li>dropped unlinked row (NIL): 'VPA coefficient in CL/F' — extend the ontology if this is a real PK parameter (source ['Zhang_2008:abstract'])</li><li>dropped unlinked row (NIL): 'EI coefficient in CL/F' — extend the ontology if this is a real PK parameter (source ['Zhang_2008:abstract'])</li><li>unit_dimension_unknown: 'null' (V/F)</li><li>implicit units: 'clearance (CL/F)' → L/h (from the popPK convention: 'Standard unit for population PK clearance is L/h; magnitude 0.664 is consistent with this unit.')</li><li>implicit units: 'volume of distribution (V/F)' → L (from the popPK convention: 'Standard unit for volume of distribution is L; magnitude 45 is consistent with this unit.')</li><li>implicit units: 'KA' → 1/h (from the popPK convention: 'Standard unit for first-order absorption rate constant is 1/h; magnitude 4.0 is consistent with this unit.')</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'Standard unit for population PK clearance is L/h; magnitude 0.717 is consistent with this unit.')</li><li>implicit units: 'V/F' → L (from the popPK convention: 'Standard unit for volume of distribution is L; magnitude 40.2 is consistent with this unit.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Lamotrigine</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Zhang2008_reference;
