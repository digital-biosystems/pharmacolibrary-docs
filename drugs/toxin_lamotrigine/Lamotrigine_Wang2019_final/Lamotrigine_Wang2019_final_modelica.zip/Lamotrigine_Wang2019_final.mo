model Lamotrigine_Wang2019_final
  parameter Real Cl_ref = 3.111111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0127 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25609,
    adminMass = 0.0001,
    ka = 0.0005472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>Chinese patients with epilepsy</td></tr><tr><td>source_paper:</td><td>Wang_2019</td></tr><tr><td>measured_compound:</td><td>Lamotrigine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.09 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('θRFP on CL/F', value '0.647') — already have one for this compound</li><li>dropped 'θSLC22A1-1222 AA on CL/F' → Q27 = -0.525: a clearance of -0.525 is not a parameter value (source ['T4:row7:col3'])</li><li>dropped 'θABCG2 -34 AA on V/F' → Q76 = -0.420: a volume of -0.420 is not a parameter value (source ['T4:row8:col3'])</li><li>dropped duplicate Q76 ('θMDR1 -2677 TT + C3435 TT on V/F', value '1.390') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CLINTER VAR, %' — extend the ontology if this is a real PK parameter (source ['T4:row10:col3'])</li><li>dropped unlinked row (NIL): 'VINTER VAR, %' — extend the ontology if this is a real PK parameter (source ['T4:row11:col3'])</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'V/F'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'θ'</li><li>dropped value-less row: 'INTER VAR'</li><li>dropped value-less row: 'VPA'</li><li>dropped value-less row: 'RFP'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Lamotrigine</li><li>model-stage split: 'final model / estimates*' is the final model of Wang_2019 (paper reports 2 stages: base model / estimates, final model / estimates*); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Wang2019_final;
