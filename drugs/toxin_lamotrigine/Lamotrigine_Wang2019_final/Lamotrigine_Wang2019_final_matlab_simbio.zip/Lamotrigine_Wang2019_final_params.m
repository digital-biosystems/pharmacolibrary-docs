function p = Lamotrigine_Wang2019_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Wang_2019 / final   route: oral
  p.name  = 'Lamotrigine_Wang2019_final_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.7;                % central volume [L]
  p.CL = 1.12;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.97;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
