function p = Lamotrigine_Wang2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamotrigine   source: Wang_2019 / reference   route: oral
  p.name  = 'Lamotrigine_Wang2019_reference_params';
  p.drug  = 'lamotrigine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.7;                % central volume [L]
  p.CL = 1.11;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.57;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
