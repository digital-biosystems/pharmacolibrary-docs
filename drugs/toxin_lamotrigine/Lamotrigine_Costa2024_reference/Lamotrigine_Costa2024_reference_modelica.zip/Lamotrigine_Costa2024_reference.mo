model Lamotrigine_Costa2024_reference
  parameter Real Cl_ref = 9.711111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09387 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25609,
    adminMass = 2.5e-05,
    ka = 0.00043611111111111113,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>pregnant women and non-pregnant adults</td></tr><tr><td>source_paper:</td><td>Costa_2024</td></tr><tr><td>measured_compound:</td><td>Lamotrigine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-01163-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.09 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'log P' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row3:col1'])</li><li>dropped unlinked row (NIL): 'pKa (Base)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row4:col1'])</li><li>dropped unlinked row (NIL): 'Solubility factor' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row5:col1'])</li><li>dropped unlinked row (NIL): 'Mean particle radius (µm)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row14:col1'])</li><li>dropped unlinked row (NIL): 'Particle density (g/mL)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row15:col1'])</li><li>dropped unlinked row (NIL): 'Dose volume (mL)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row16:col1'])</li><li>dropped unlinked row (NIL): 'Precipitation time (s)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row18:col1'])</li><li>dropped unlinked row (NIL): 'Solubility FaSSGF (mg/mL)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row19:col1'])</li><li>dropped unlinked row (NIL): 'Solubility FaSSIF (mg/mL)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01163-t001:row20:col1'])</li><li>salvaged Q61 ('calculated Vd'=1.341) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('estimated total clearance'=3.496) from results prose — parameter table was unreadable</li><li>implicit units: 'B:P' — the LLM proposed 'none', whose dimension does not fit Q54; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lamotrigine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Costa2024_reference;
