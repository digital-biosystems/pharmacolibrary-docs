// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_9CisRetinoicAcid_Miller1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4680.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>9_cis_retinoic_acid</td></tr><tr><td>population:</td><td>patients with APL who had previously relapsed from a remission induced by all-trans RA</td></tr><tr><td>source_paper:</td><td>Miller_1995</td></tr><tr><td>measured_compound:</td><td>9-cis-Retinoic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>9_cis_retinoic_acid 300.442 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'mean change per dose level in area under the plasma concentration x time curves' — the LLM proposed 'h/mg', whose dimension does not fit Q189; left unset</li><li>implicit units: 'mean change per dose level in peak plasma concentrations' — the LLM proposed 'ng/mL/mg', whose dimension does not fit Q174; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=9-cis-Retinoic acid</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none of 1 PubChem candidate(s) is '9-cis-Retinoic acid' (LLM) — left in mass units</li><li>molar mass: none found for '9-cis-Retinoic acid' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q189, Q174 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_9CisRetinoicAcid_Miller1995_reference;
