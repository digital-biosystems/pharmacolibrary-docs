// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Plutonium240_Filipy1996_thyroid
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {284018400.0},
    MM = 0.24,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>plutonium_240</td></tr><tr><td>population:</td><td>occupational exposure adults</td></tr><tr><td>source_paper:</td><td>Filipy_1996</td></tr><tr><td>measured_compound:</td><td>239+240Pu</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>239+240Pu 240 g/mol (paper); plutonium_240 240.054 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Filipy_1996_table_p5_1: rows are variants (Liverᵈ, Muscle, Brain, Heart, Kidneys, Spleen), the parameters are the column headers (Relative absorbed dose) — read one record per variant</li><li>dropped unlinked row (NIL): 'Relative absorbed dose' — extend the ontology if this is a real PK parameter (source ['Filipy_1996_table_p5_1:row9:col5', 'Filipy_1996_table_p5_1:row19:col5'])</li><li>salvaged Q59 ('For 239+240Pu in skeletal muscle, strict adherence to the outlier rejection criterion resulted in a not unreasonable estimated retention half-time of 9 y; however, the Y-intercept indicated an initial uptake fraction in skeletal muscle of 37% of the initial systemic burden.'=9) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('ICRP 67 (1993) implied a retention half-time in the testes of approximately 55 y.'=55) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=239+240Pu</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'Thyroid' is one of 9 estimates of Filipy_1996's substance matrix (Liverᵈ, Muscle, Brain, Heart, Kidneys, Spleen, Pancreas, Testes, Thyroid); same population, different estimation method</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Plutonium240_Filipy1996_thyroid;
