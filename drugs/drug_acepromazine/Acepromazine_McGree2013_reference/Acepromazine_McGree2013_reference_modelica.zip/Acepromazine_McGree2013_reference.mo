model Acepromazine_McGree2013_reference
  parameter Real Cl_ref = 0.00021361111111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 6.8740000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345,
    adminMass = 3e-05,
    ka = 0.009963888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About acepromazine</h4><p>Acepromazine is a phenothiazine antipsychotic derivative that acts as a dopamine antagonist. It is provided as a solution or drops for veterinary use. The drug is no longer used in humans but is widely used in veterinary medicine for sedation in dogs, cats, and horses.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q425097\">Wikidata Q425097</a>, <a href=\"https://en.wikipedia.org/wiki/Acepromazine?oldid=1382572888\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>acepromazine</td></tr><tr><td>population:</td><td>horses</td></tr><tr><td>source_paper:</td><td>McGree_2013</td></tr><tr><td>measured_compound:</td><td>2-(1-hydroxyethyl)promazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>acepromazine 326.456 g/mol (drugbank); 2-(1-hydroxyethyl)promazine 345 g/mol (paper)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is acepromazine; the compartment is 2-(1-hydroxyethyl)promazine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is 2-(1-hydroxyethyl)promazine, not acepromazine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>acepromazine's own concentration-time course is not produced by this model</li><li>table section iiv: 'Cl/FPM (L/hr)' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'FE' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'V/FPM (L)' routed out of structural estimates ('BSV (%)')</li><li>implicit units: 'k12' → 1/h (from the popPK convention: &quot;The parameter k12 is identified as a first-order rate constant governing metabolite formation. The paper text states 'Th&quot;)</li><li>metabolite 2-(1-hydroxyethyl)promazine: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite volume: 'V/FPM (L)' Q63→Q61 for 2-(1-hydroxyethyl)promazine — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=2-(1-hydroxyethyl)promazine</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 5 linked by role</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Acepromazine_McGree2013_reference;
