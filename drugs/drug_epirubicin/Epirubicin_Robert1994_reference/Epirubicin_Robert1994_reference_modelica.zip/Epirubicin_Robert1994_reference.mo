model Epirubicin_Robert1994_reference
  parameter Real Cl_ref = 2.210555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.7300000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About epirubicin</h4><p>Epirubicin is an anthracycline antibiotic used to treat breast cancer, gastric adenocarcinoma, and invasive ductal carcinoma. It is administered via intravenous injection or intravesical instillation. It is widely used in chemotherapy regimens and is marketed under various brand names in the US and elsewhere.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q425122\">Wikidata Q425122</a>, <a href=\"https://en.wikipedia.org/wiki/Epirubicin?oldid=1384675075\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>adults with cancer</td></tr><tr><td>source_paper:</td><td>Robert_1994</td></tr><tr><td>measured_compound:</td><td>epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.519 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=epirubicin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Robert1994_reference;
