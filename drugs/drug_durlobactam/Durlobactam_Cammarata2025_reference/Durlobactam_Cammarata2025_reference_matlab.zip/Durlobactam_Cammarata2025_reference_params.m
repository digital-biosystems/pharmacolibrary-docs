function p = Durlobactam_Cammarata2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: durlobactam   source: Cammarata_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Durlobactam_Cammarata2025_reference_params';
  p.drug  = 'durlobactam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.32;                % central volume [L]
  p.CL = 5.2;                % clearance [L/h]
  p.Vp = [6.74];             % peripheral volumes [L]
  p.Q  = [12.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
