model Durlobactam_Cammarata2025_reference
  parameter Real Cl_ref = 1.4444444444444447e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00532 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27725,
    adminMass = 0.001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.000647451963241437,
    k21 = 0.0005110451697988791
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>durlobactam</td></tr><tr><td>population:</td><td>adults with hospital-acquired and ventilator-associated bacterial pneumonia</td></tr><tr><td>source_paper:</td><td>Cammarata_2025</td></tr><tr><td>measured_compound:</td><td>durlobactam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>durlobactam 277.25 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CLEASIAFL1' — extend the ontology if this is a real PK parameter (source ['T1:row9:col1', 'T1:row9:col2', 'T1:row9:col4', 'T1:row9:col5', 'T1:row9:col6'])</li><li>dropped unlinked row (NIL): 'CLWTKG1' — extend the ontology if this is a real PK parameter (source ['T1:row10:col1', 'T1:row10:col2', 'T1:row10:col4', 'T1:row10:col5', 'T1:row10:col6', 'T1:row37:col1', 'T1:row37:col2', 'T1:row37:col4', 'T1:row37:col5', 'T1:row37:col6'])</li><li>dropped unlinked row (NIL): 'V1INFTYPN1&2 (HABP and VABP)' — extend the ontology if this is a real PK parameter (source ['T1:row11:col1', 'T1:row11:col2', 'T1:row11:col4', 'T1:row11:col5', 'T1:row11:col6'])</li><li>unit_dimension_unknown: 'cUTI' (V1)</li><li>dropped duplicate Q63 ('V1INFTYPN3 (cUTI)', value '32.4') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V1INFTYPN4 (bacteremia)' — extend the ontology if this is a real PK parameter (source ['T1:row13:col1', 'T1:row13:col2', 'T1:row13:col4', 'T1:row13:col5', 'T1:row13:col6'])</li><li>dropped duplicate Q63 ('V1EASIAFL1', value '25.8') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CLINFTYPN1 (HABP)' — extend the ontology if this is a real PK parameter (source ['T1:row32:col1', 'T1:row32:col2', 'T1:row32:col4', 'T1:row32:col5', 'T1:row32:col6'])</li><li>dropped unlinked row (NIL): 'CLINFTYPN2 (VABP)' — extend the ontology if this is a real PK parameter (source ['T1:row33:col1', 'T1:row33:col2', 'T1:row33:col4', 'T1:row33:col5', 'T1:row33:col6'])</li><li>dropped unlinked row (NIL): 'CLINFTYPN3 (cUTI)' — extend the ontology if this is a real PK parameter (source ['T1:row34:col1', 'T1:row34:col2', 'T1:row34:col4', 'T1:row34:col5', 'T1:row34:col6'])</li><li>dropped unlinked row (NIL): 'CLINFTYPN4 (bacteremia)' — extend the ontology if this is a real PK parameter (source ['T1:row35:col1', 'T1:row35:col2', 'T1:row35:col4', 'T1:row35:col5', 'T1:row35:col6'])</li><li>dropped unlinked row (NIL): 'CLINFTYPN5 (AP)' — extend the ontology if this is a real PK parameter (source ['T1:row36:col1', 'T1:row36:col2', 'T1:row36:col4', 'T1:row36:col5', 'T1:row36:col6'])</li><li>dropped unlinked row (NIL): 'V3INFTYPN1 (HABP)' — extend the ontology if this is a real PK parameter (source ['T1:row38:col1', 'T1:row38:col2', 'T1:row38:col4', 'T1:row38:col5', 'T1:row38:col6'])</li><li>dropped unlinked row (NIL): 'V3INFTYPN2 (VABP)' — extend the ontology if this is a real PK parameter (source ['T1:row39:col1', 'T1:row39:col2', 'T1:row39:col4', 'T1:row39:col5', 'T1:row39:col6'])</li><li>unit_dimension_unknown: 'cUTI' (V3)</li><li>unit_dimension_unknown: 'bacteremia' (V3/F)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Durlobactam_Cammarata2025_reference;
