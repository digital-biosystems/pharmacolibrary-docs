function p = Raltitrexed_Blair2004_full_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: raltitrexed   source: Blair_2004 / full   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Raltitrexed_Blair2004_full_params';
  p.drug  = 'raltitrexed';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.68;                % central volume [L]
  p.CL = 2.11;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
