function p = Savolitinib_Jones2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: savolitinib   source: Jones_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Savolitinib_Jones2023_reference_params';
  p.drug  = 'savolitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 100.8;                % central volume [L]
  p.CL = 30.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.44;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.4;             % dose [mg]
end
