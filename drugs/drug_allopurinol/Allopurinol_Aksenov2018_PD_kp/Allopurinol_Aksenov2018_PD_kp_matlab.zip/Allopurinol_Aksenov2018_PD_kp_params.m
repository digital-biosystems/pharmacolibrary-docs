function p = Allopurinol_Aksenov2018_PD_kp_params()
% Allopurinol_Aksenov2018_PD_kp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Aksenov_2018::kP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response kP in mg/h. Driver: oxypurinol (cited_pk).
p.E0 = 1.4027777777777777e-08;
p.Emax = -2.333333333333333e-10;
p.EC50 = 0.013999999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 140000.0;
p.form = 'E0 + Emax*frac';
end
