model Allopurinol_Aksenov2018_PD_kp
  "emax exposure-response sweep — Aksenov_2018 :: kP (production rate of uric acid)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.33333333333e-10,  // [kg/s; mg/h × 2.77778e-10]
    EC50 = 0.014,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140000, Interval = 280),
    Documentation(info = "<html><body><h4>Allopurinol_Aksenov2018_PD_kp</h4><p>The steady-state exposure-response curve of Aksenov S et al., <i>Physiological reports 6(5)</i> 2018 (<a href=\"https://doi.org/10.14814/phy2.13614\">doi:10.14814/phy2.13614</a>) — production rate of uric acid [mg/h] against oxypurinol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.84 mg/h     maximal effect term (R max, Q323)
  EC50  =      14000 ng/mL    exposure at half of the maximal effect term ([P] 50,PIN, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of oxypurinol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (14000 ng/mL)  response -1.167e-10
  exposure -> infinity  response -2.333e-10</pre></body></html>"));
end Allopurinol_Aksenov2018_PD_kp;
