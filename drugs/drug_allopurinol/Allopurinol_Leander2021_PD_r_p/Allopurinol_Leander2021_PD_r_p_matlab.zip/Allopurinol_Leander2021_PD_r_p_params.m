function p = Allopurinol_Leander2021_PD_r_p_params()
% Allopurinol_Leander2021_PD_r_p_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Leander_2021::R_P: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response R P in mg/h. Driver: oxypurinol (cited_pk).
p.E0 = 0.0076999999999999985;
p.Emax = -2.333333333333333e-10;
p.EC50 = 0.01303;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 140000.0;
p.form = 'E0 + Emax*frac';
end
