#!/usr/bin/env python3
"""Sweep Allopurinol_Wen2023_PD_su.sbml with Tellurium/libRoadRunner: response against exposure.

Simulated time is the swept exposure (exposure = exposure_per_s * time), so the x axis of the
plot is `exposure`, not time. Writes Allopurinol_Wen2023_PD_su.csv/.json/.png next to this script.
"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Allopurinol_Wen2023_PD_su")
r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 176.0, 500, ["time", "exposure", "response"])
x = [float(v) for v in res[:, 1]]; y = [float(v) for v in res[:, 2]]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Allopurinol_Wen2023_PD_su", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [mg/L]"); plt.ylabel("response [mg/dL]")
plt.title("Allopurinol_Wen2023_PD_su"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
