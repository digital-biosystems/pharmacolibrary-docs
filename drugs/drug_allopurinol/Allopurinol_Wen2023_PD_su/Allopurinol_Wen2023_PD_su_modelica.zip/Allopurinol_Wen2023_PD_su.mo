model Allopurinol_Wen2023_PD_su
  "emax exposure-response sweep — Wen_2023 :: SU (serum urate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -0.07599999999999998,  // [kg/m3; mg/dL × 0.01]
    EC50 = 0.017599999999999998,  // [kg/m3; mg/L × 0.001]
    gamma = 1.0,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 176, Interval = 0.352));
end Allopurinol_Wen2023_PD_su;
