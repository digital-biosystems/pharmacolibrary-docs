model Allopurinol_Wen2023_final
  parameter Real Cl_ref = 1.3299999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0406 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0007222222222222223,
    Tlag = 846.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>allopurinol</td></tr><tr><td>population:</td><td>Hmong adults with gout and/or hyperuricemia</td></tr><tr><td>source_paper:</td><td>Wen_2023</td></tr><tr><td>measured_compound:</td><td>oxypurinol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '/h' (kfm)</li><li>dropped unlinked row (NIL): 'BLurate (mg/dL)' — extend the ontology if this is a real PK parameter (source ['T2:row5:col2'])</li><li>dropped PD-category row 'Imax (mg/dL)' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row6:col2'])</li><li>dropped PD-category row 'IC50 (mg/L)' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row7:col2'])</li><li>dropped unlinked row (NIL): 'Standardized creatinine clearance (power)' — extend the ontology if this is a real PK parameter (source ['T2:row9:col2'])</li><li>dropped unlinked row (NIL): 'SLC22A12 rs505802 T allelea' — extend the ontology if this is a real PK parameter (source ['T2:row10:col2'])</li><li>covariate level 'Standardized creatinine clearance (power) on baseline SU' → Q900:standardized_creatinine_clearance_power_on_baseline_su = -0.18 (power on Q351)</li><li>dropped PD-category row 'PDZK1 rs12129861 A allele on IC50a' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row13:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=oxypurinol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'final model' is the final model of Wen_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Allopurinol_Wen2023_final;
