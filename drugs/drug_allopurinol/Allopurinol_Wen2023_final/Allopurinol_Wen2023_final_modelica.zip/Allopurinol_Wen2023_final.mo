model Allopurinol_Wen2023_final
  parameter Real Cl_ref = 2.916666666666667e-07 "Cl [m3/s]";
  parameter Real cov_creatinine = 1.0 "creatinine covariate (reference 1.0)";
  parameter Real Vd_ref = 0.0593 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_creatinine/1.0)^(-0.18),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.15211000000000002,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>allopurinol</td></tr><tr><td>population:</td><td>Hmong adults with gout and/or hyperuricemia</td></tr><tr><td>source_paper:</td><td>Wen_2023</td></tr><tr><td>measured_compound:</td><td>oxypurinol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>allopurinol 136.112 g/mol (drugbank); oxypurinol 152.11 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'BLurate (mg/dL)' — extend the ontology if this is a real PK parameter (source ['T2:row5:col2'])</li><li>dropped PD-category row 'Imax (mg/dL)' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row6:col2'])</li><li>dropped PD-category row 'IC50 (mg/L)' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row7:col2'])</li><li>dropped unlinked row (NIL): 'Standardized creatinine clearance (power)' — extend the ontology if this is a real PK parameter (source ['T2:row9:col2'])</li><li>dropped unlinked row (NIL): 'SLC22A12 rs505802 T allelea' — extend the ontology if this is a real PK parameter (source ['T2:row10:col2'])</li><li>covariate level 'Standardized creatinine clearance (power) on baseline SU' → Q900:standardized_creatinine_clearance_power_on_baseline_su = -0.18 (power on Q27)</li><li>dropped unlinked row (NIL): 'PDZK1 rs12129861 A allele on IC50a' — extend the ontology if this is a real PK parameter (source ['T2:row13:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=oxypurinol</li><li>template fit: PK_Parent_Metabolite — one metabolite formed from central, both 1-compartment</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V/fm (L)' is the general volume)</li><li>model-stage split: 'final model' is the final model of Wen_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>row roles (LLM): model_class=compartmental; 13/13 row label(s) assigned, 7 linked by role; re-tagged oxypurinol→serum urate ×14</li><li>review gap-fill skipped: this record measures 'oxypurinol', not allopurinol — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Allopurinol_Wen2023_final;
