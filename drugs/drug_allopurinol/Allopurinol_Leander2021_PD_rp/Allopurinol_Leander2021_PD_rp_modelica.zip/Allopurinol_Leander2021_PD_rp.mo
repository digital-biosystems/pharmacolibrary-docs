model Allopurinol_Leander2021_PD_rp
  "emax exposure-response sweep — Leander_2021 :: RP (uric acid production rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.33333333333e-10,  // [kg/s; mg/h × 2.77778e-10]
    EC50 = 0.01303,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140000, Interval = 280),
    Documentation(info = "<html><body><!-- drug-about --><h4>About allopurinol</h4><p>Allopurinol is a medicine used to lower high uric acid levels in the blood, mainly to treat gout and hyperuricemia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412486\">Wikidata Q412486</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Allopurinol_Leander2021_PD_rp</h4><p>The steady-state exposure-response curve of Leander J et al., <i>Journal of pharmacokinetics and pharmacodynamics 48(4):525–541</i> 2021 (<a href=\"https://doi.org/10.1007/s10928-021-09747-y\">doi:10.1007/s10928-021-09747-y</a>) — uric acid production rate [mg/h] against oxypurinol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.84 mg/h     maximal effect term (Emax, Q323)
  EC50  =      13030 ng/mL    exposure at half of the maximal effect term (Oxypurinol EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of oxypurinol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13030 ng/mL)  response -1.167e-10
  exposure -> infinity  response -2.333e-10</pre></body></html>"));
end Allopurinol_Leander2021_PD_rp;
