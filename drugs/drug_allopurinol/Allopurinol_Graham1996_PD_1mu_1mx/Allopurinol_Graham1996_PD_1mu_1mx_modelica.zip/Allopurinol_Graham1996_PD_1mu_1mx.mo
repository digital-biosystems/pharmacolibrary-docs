model Allopurinol_Graham1996_PD_1mu_1mx
  "sigmoid_emax exposure-response sweep — Graham_1996 :: 1MU/1MX (ratio of 1MU/1MX in urine)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 2.63,      // [1]
    Emax = -2.27,  // [1]
    EC50 = 0.00401,  // [kg/m3; mg l-1 × 0.001]
    gamma = 8.92,
    exposure_per_s = 0.001);   // 1 mg l-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 41, Interval = 0.082),
    Documentation(info = "<html><body><h4>Allopurinol_Graham1996_PD_1mu_1mx</h4><p>The steady-state exposure-response curve of Graham S et al., <i>British journal of clinical pharmacology 41(4):299–304</i> 1996 (<a href=\"https://doi.org/10.1046/j.1365-2125.1996.03116.x\">doi:10.1046/j.1365-2125.1996.03116.x</a>) — ratio of 1MU/1MX in urine against oxypurinol mg l-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       2.63          drug-free response (baseline) (Ro, Q324)
  Emax  =       2.27          maximal effect term (E max, Q323)
  EC50  =       4.01 mg l-1   exposure at half of the maximal effect term (C 50, Q322)
  gamma =       8.92          Hill coefficient (c, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg l-1 of oxypurinol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.63   (drug-free)
  exposure = EC50 (4.01 mg l-1)  response 1.495
  exposure -> infinity  response 0.36</pre></body></html>"));
end Allopurinol_Graham1996_PD_1mu_1mx;
