function p = Allopurinol_Day2007_PD_urate_params()
% Allopurinol_Day2007_PD_urate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Day_2007::urate: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response urate in its own unit. Driver: oxypurinol (cited_pk).
p.E0 = 0.0;
p.Emax = -0.83;
p.EC50 = 0.005599999999999998;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 56.0;
p.form = 'E0 + Emax*frac';
end
