model Allopurinol_Wen2023_base
  parameter Real Cl_ref = 2.7777777777777776e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.047700000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0003055555555555556,
    Tlag = 846.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>allopurinol</td></tr><tr><td>population:</td><td>Hmong adults with gout and/or hyperuricemia</td></tr><tr><td>source_paper:</td><td>Wen_2023</td></tr><tr><td>measured_compound:</td><td>oxypurinol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is allopurinol; the compartment is oxypurinol. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is oxypurinol, not allopurinol</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>allopurinol's own concentration-time course is not produced by this model</li><li>formation is 52x faster than oxypurinol elimination (kfm 1.1/h vs ke 0.021/h), so the metabolite is elimination-rate-limited and the input rate is identifiable</li><li>unit_dimension_unknown: '/h' (kfm)</li><li>dropped unlinked row (NIL): 'BLurate (mg/dL)' — extend the ontology if this is a real PK parameter (source ['T2:row5:col1'])</li><li>dropped PD-category row 'Imax (mg/dL)' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row6:col1'])</li><li>dropped PD-category row 'IC50 (mg/L)' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row7:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=oxypurinol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'base model' is the base model of Wen_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>gap-filled Q27 (CL/F) from Day_2007's review values (primary lacked it)</li><li>gap-filled Q76 (V/F) from Day_2007's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Allopurinol_Wen2023_base;
