function p = Allopurinol_Jonkman1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: allopurinol   source: Jonkman_1984 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Allopurinol_Jonkman1984_reference_params';
  p.drug  = 'allopurinol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 43249.400475;                % central volume [L]
  p.CL = 3059.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
