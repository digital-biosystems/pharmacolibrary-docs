function p = Allopurinol_Day2007_PD_1_mu_1_mx_2_params()
% Allopurinol_Day2007_PD_1_mu_1_mx_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Day_2007::1_MU_1_MX::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response 1-MU/1-MX in its own unit. Driver: oxypurinol (cited_pk).
p.E0 = 0.0;
p.Emax = -0.93;
p.EC50 = 0.0013999999999999996;
p.gamma = 3.6;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
