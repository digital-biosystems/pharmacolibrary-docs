model Allopurinol_Day2007_PD_1_mu_1_mx_2
  "sigmoid_emax exposure-response sweep — Day_2007 :: 1-MU/1-MX (1-MU/1-MX (1-MX))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.93,  // [1; % × 0.01]
    EC50 = 0.0014,  // [kg/m3; mg/L × 0.001]
    gamma = 3.6,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 14, Interval = 0.028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About allopurinol</h4><p>Allopurinol is a medicine used to lower high uric acid levels in the blood, mainly to treat gout and hyperuricemia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412486\">Wikidata Q412486</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Allopurinol_Day2007_PD_1_mu_1_mx_2</h4><p>The steady-state exposure-response curve of Day RO et al., <i>Clinical pharmacokinetics 46(8):623–644</i> 2007 (<a href=\"https://doi.org/10.2165/00003088-200746080-00001\">doi:10.2165/00003088-200746080-00001</a>) — 1-MU/1-MX (1-MX) against oxypurinol mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         93 %        maximal effect term (Emax/E0, Q323)
  EC50  =        1.4 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =        3.6          Hill coefficient (Hill, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of oxypurinol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.4 mg/L)  response -0.465
  exposure -> infinity  response -0.93</pre></body></html>"));
end Allopurinol_Day2007_PD_1_mu_1_mx_2;
