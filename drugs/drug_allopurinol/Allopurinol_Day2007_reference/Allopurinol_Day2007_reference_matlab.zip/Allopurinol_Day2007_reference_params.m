function p = Allopurinol_Day2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: allopurinol   source: Day_2007 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Allopurinol_Day2007_reference_params';
  p.drug  = 'allopurinol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 40.6;                % central volume [L]
  p.CL = 47.88;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
