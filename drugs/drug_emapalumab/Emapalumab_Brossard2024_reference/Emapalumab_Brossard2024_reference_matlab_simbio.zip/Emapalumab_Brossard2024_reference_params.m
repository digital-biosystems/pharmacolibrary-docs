function p = Emapalumab_Brossard2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: emapalumab   source: Brossard_2024 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Emapalumab_Brossard2024_reference_params';
  p.drug  = 'emapalumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.07;                % central volume [L]
  p.CL = 0.00876;                % clearance [L/h]
  p.Vp = [4.21];             % peripheral volumes [L]
  p.Q  = [0.0814];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
