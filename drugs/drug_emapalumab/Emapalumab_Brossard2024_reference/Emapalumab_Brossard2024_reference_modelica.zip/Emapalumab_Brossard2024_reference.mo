model Emapalumab_Brossard2024_reference
  parameter Real Cl_ref = 2.4333333333333336e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004070000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-05,
    k12 = 5.555555555555554e-06,
    k21 = 5.3708102401689096e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About emapalumab</h4><p>Emapalumab is a monoclonal antibody used to treat hemophagocytic lymphohistiocytosis, an immune system disease. It is an approved immunosuppressant, though a marketing application for one product was refused in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209889\">Wikidata Q28209889</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>emapalumab</td></tr><tr><td>population:</td><td>patients with primary HLH or MAS in sJIA</td></tr><tr><td>source_paper:</td><td>Brossard_2024</td></tr><tr><td>measured_compound:</td><td>emapalumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'RUV_add' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'RUV_add' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q22 ('CLNL, l/h/70 kg', value '0.0748') — already have one for this compound</li><li>dropped duplicate Q22 ('CLNL_IFNγ', value '0.562') — already have one for this compound</li><li>dropped duplicate Q22 ('CLs_AGE', value '0.187') — already have one for this compound</li><li>unit_dimension_mismatch: 'CLs_V1_TBIL' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('CLs_V1_TBIL', value '0.162') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Corr V1,V2' — extend the ontology if this is a real PK parameter (source ['Tab3:row18:col1', 'Brossard_2024_table_2:row14:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=emapalumab</li><li>molar mass: none found for 'emapalumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Emapalumab_Brossard2024_reference;
