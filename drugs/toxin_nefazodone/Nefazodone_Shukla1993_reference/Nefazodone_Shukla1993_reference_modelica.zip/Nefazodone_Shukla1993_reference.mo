model Nefazodone_Shukla1993_reference
  parameter Real Cl_ref = 3.0333333333333337e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.22680000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.470014,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nefazodone</td></tr><tr><td>population:</td><td>beagle dogs</td></tr><tr><td>source_paper:</td><td>Shukla_1993</td></tr><tr><td>measured_compound:</td><td>Nefazodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Nefazodone 470.014 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'The fraction of oral NEF eliminated presystemically' → Q42: printed without a unit and above 1 — read as a percentage</li><li>'fecal' → Q44: printed without a unit and above 1 — read as a percentage</li><li>covariate category for equation variable from footnote/prose kept as documentation only (['Shukla_1993:abstract', 'Shukla_1993:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nefazodone</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/6 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'hydroxynefazodone' — its concentrations stay mass-only</li><li>molar mass: none found for 'm-chlorophenylpiperazine' — its concentrations stay mass-only</li><li>molar mass: none found for 'p-hydroxynefazodone' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nefazodone_Shukla1993_reference;
