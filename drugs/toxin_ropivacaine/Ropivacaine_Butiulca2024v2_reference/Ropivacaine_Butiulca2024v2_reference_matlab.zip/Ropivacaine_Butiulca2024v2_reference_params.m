function p = Ropivacaine_Butiulca2024v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ropivacaine   source: Butiulca_2024_2 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Ropivacaine_Butiulca2024v2_reference_params';
  p.drug  = 'ropivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2702.7;                % central volume [L]
  p.CL = 1078.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
