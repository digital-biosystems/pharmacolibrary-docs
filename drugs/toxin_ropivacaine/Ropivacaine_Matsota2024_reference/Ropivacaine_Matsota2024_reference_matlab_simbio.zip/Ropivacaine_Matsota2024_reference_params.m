function p = Ropivacaine_Matsota2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ropivacaine   source: Matsota_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ropivacaine_Matsota2024_reference_params';
  p.drug  = 'ropivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 160.98332;                % central volume [L]
  p.CL = 11.4288;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 32.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.49;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
