model Ropivacaine_Matsota2024_reference
  parameter Real Cl_ref = 3.1746666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16098332 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27440800000000004,
    adminMass = 1.2e-05,
    ka = 0.008888888888888889,
    Tlag = 1764.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ropivacaine</td></tr><tr><td>population:</td><td>adult patients scheduled for elective open thoracotomy</td></tr><tr><td>source_paper:</td><td>Matsota_2024</td></tr><tr><td>measured_compound:</td><td>Ropivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>joacp_353_22-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ropivacaine 274.408 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'kb (min−1)'; source reconciliation required</li><li>table representations disagree for 'Vap (ml)a'; source reconciliation required</li><li>table representations disagree for 'Cl (ml/min)a'; source reconciliation required</li><li>table representations disagree for 'beta_Cl_Sex'; source reconciliation required</li><li>table representations disagree for 'omega_Vap'; source reconciliation required</li><li>table representations disagree for 'omega_Cl'; source reconciliation required</li><li>table representations disagree for 'corr_Vap_Cl'; source reconciliation required</li><li>table representations disagree for 'B'; source reconciliation required</li><li>dropped 'beta_Cl_Sex' → Q22 = -0.17: a clearance of -0.17 is not a parameter value (source ['joacp_353_22-t002:row7:col1', 'joacp_353_22-t002:row7:col2', 'joacp_353_22-t002:row7:col3', 'joacp_353_22-t002:row22:col1', 'joacp_353_22-t002:row22:col2', 'joacp_353_22-t002:row22:col3', 'joacp_353_22-t002:row22:col4', 'joacp_353_22-t002:footnote'])</li><li>routed 'corr_Vap_Cl' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'B' — extend the ontology if this is a real PK parameter (source ['joacp_353_22-t002:row14:col1', 'joacp_353_22-t002:row14:col2', 'joacp_353_22-t002:row14:col3', 'joacp_353_22-t002:row29:col1', 'joacp_353_22-t002:row29:col2', 'joacp_353_22-t002:row29:col3'])</li><li>dropped value-less row: 'kb'</li><li>dropped value-less row: 'Vap'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ropivacaine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ropivacaine_Matsota2024_reference;
