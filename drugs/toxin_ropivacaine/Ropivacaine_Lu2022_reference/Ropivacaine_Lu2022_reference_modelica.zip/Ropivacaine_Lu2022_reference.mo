// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ropivacaine_Lu2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {12960.0},
    MM = 0.27440800000000004,
    adminMass = 0.00525,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ropivacaine</td></tr><tr><td>population:</td><td>rats (half male and half female)</td></tr><tr><td>source_paper:</td><td>Lu_2022</td></tr><tr><td>measured_compound:</td><td>Ropivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ropivacaine 274.408 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 18 (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ropivacaine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Ropivacaine_Lu2022_reference;
