model Pentobarbital_Helfer2026_estimate
  parameter Real Cl_ref = 1.4472222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0374 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.226276,
    adminMass = 4.7e-06,
    k12 = 0.00013443256090314915,
    k21 = 7.868196835332987e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>pediatric patients (birth to 21 years)</td></tr><tr><td>source_paper:</td><td>Helfer_2026</td></tr><tr><td>measured_compound:</td><td>Pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70204-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.276 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>column 'estimate' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>routed 'Shared variability CL and V1 b' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pentobarbital</li><li>population split: 'estimate' subgroup of Helfer_2026 (paper reports 5 populations: 2 to <6 years, 6 to <12 years, <2 years, estimate, ≥12 years)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Helfer2026_estimate;
