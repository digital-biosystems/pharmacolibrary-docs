function p = Pentobarbital_Helfer2026_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Helfer_2026 / estimate   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pentobarbital_Helfer2026_estimate_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 37.4;                % central volume [L]
  p.CL = 5.21;                % clearance [L/h]
  p.Vp = [63.9];             % peripheral volumes [L]
  p.Q  = [18.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.7;             % dose [mg]
end
