function p = Pentobarbital_Drayer1982_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Drayer_1982 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Pentobarbital_Drayer1982_reference_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 89.6;                % central volume [L]
  p.CL = 3.15;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
