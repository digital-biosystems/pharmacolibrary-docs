model Pentobarbital_Ketharanathan2023_final
  parameter Real Cl_ref = 9.972222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14200000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.226276,
    adminMass = 0.00014
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>children with status epilepticus and severe traumatic brain injury</td></tr><tr><td>source_paper:</td><td>Ketharanathan_2023</td></tr><tr><td>measured_compound:</td><td>Pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.276 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section residual_error: 'Additional (mg/L)' routed out of structural estimates ('Residual variability (%)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pentobarbital</li><li>model-stage split: 'final model' is the final model of Ketharanathan_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Ketharanathan2023_final;
