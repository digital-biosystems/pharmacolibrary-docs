function p = Pentobarbital_Zuppa2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Zuppa_2011 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pentobarbital_Zuppa2011_reference_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 31.5;                % central volume [L]
  p.CL = 8.4;                % clearance [L/h]
  p.Vp = [68.6];             % peripheral volumes [L]
  p.Q  = [0.384];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
