model Pentobarbital_Zuppa2011_reference
  parameter Real Cl_ref = 2.3333333333333336e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0315 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.226276,
    adminMass = 0.0001,
    k12 = 3.386243386243386e-06,
    k21 = 1.554907677356657e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>neonates, infants, and children</td></tr><tr><td>source_paper:</td><td>Zuppa_2011</td></tr><tr><td>measured_compound:</td><td>Pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.276 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'weight' — extend the ontology if this is a real PK parameter (source ['Zuppa_2011:abstract', 'Zuppa_2011:abstract'])</li><li>dropped unlinked row (NIL): 'bypass grafting time' — extend the ontology if this is a real PK parameter (source ['Zuppa_2011:abstract', 'Zuppa_2011:abstract'])</li><li>dropped unlinked row (NIL): 'age' — extend the ontology if this is a real PK parameter (source ['Zuppa_2011:abstract', 'Zuppa_2011:abstract'])</li><li>dropped value-less row: 'ventricular physiology'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pentobarbital</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q30 (Q) from Churchill_1975's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Zuppa2011_reference;
