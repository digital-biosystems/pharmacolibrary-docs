function p = Pentobarbital_Helfer2026_2_years_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Helfer_2026 / 2_years   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pentobarbital_Helfer2026_2_years_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 40.6;                % central volume [L]
  p.CL = 9.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.7;             % dose [mg]
end
