% Run (SimBiology): build model + dose, simulate 0..45.0 h, plot.
p = Arketamine_Fux2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 45.0);
