model Cisplatin_Mody2022_PD_r
  "sigmoid_emax exposure-response sweep — Mody_2022 :: R (cell viability (Huh7))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1,      // [1; % × 0.01]
    Emax = -1,  // [% cell viability]
    EC50 = 1.96,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 20, Interval = 0.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cisplatin</h4><p>Cisplatin is a platinum-based anticancer drug used to treat many cancers, including testicular, ovarian, bladder, lung, stomach, and head and neck cancers. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412415\">Wikidata Q412415</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cisplatin_Mody2022_PD_r</h4><p>The steady-state exposure-response curve of Mody H et al., <i>Cells 12(1)</i> 2022 (<a href=\"https://doi.org/10.3390/cells12010057\">doi:10.3390/cells12010057</a>) — cell viability (Huh7) [% cell viability] against cisplatin µM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        100 %        drug-free response (baseline) (Baseline % Cell Viability, Q324)
  Emax  =          1 % cell viability maximal effect term (Maximal effect, Q323)
  EC50  =       1.96 µM       exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of cisplatin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)
  exposure = EC50 (1.96 µM)  response 0.5
  exposure -> infinity  response 0</pre></body></html>"));
end Cisplatin_Mody2022_PD_r;
