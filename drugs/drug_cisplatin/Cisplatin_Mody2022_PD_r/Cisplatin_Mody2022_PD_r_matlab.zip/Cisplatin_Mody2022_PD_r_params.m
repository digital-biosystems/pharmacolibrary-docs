function p = Cisplatin_Mody2022_PD_r_params()
% Cisplatin_Mody2022_PD_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cisplatin Mody_2022::R: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response R in % cell viability. Driver: cisplatin (cited_pk).
p.E0 = 1.0;
p.Emax = -1.0;
p.EC50 = 1.96;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 20.0;
p.form = 'E0 + Emax*frac';
end
