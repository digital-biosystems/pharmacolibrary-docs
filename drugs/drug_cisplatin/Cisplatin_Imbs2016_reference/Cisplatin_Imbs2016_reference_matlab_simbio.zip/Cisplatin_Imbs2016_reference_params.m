function p = Cisplatin_Imbs2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cisplatin   source: Imbs_2016 / reference   route: oral
  p.name  = 'Cisplatin_Imbs2016_reference_params';
  p.drug  = 'cisplatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.3;                % central volume [L]
  p.CL = 0.659;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.31;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
