model Cisplatin_Imbs2016_reference
  parameter Real Cl_ref = 1.830555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.024300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30005000000000004,
    adminMass = 0.0002,
    ka = 0.0003638888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cisplatin</h4><p>Cisplatin is a platinum-based anticancer drug used to treat many cancers, including testicular, ovarian, bladder, lung, stomach, and head and neck cancers. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412415\">Wikidata Q412415</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisplatin</td></tr><tr><td>population:</td><td>patients in a phase I pazopanib-cisplatin combination study</td></tr><tr><td>source_paper:</td><td>Imbs_2016</td></tr><tr><td>measured_compound:</td><td>cisplatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cisplatin 300.05 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('Inter-individual')</li><li>table section iov: 'CL/F (L/h)' routed out of structural estimates ('Inter-occasion')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('Inter-individual')</li><li>table section iov: 'V/F (L)' routed out of structural estimates ('Inter-occasion')</li><li>table section iiv: 'Ka (h -1 )' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'Lag time (h)' routed out of structural estimates ('Inter-individual')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('and Day 1 and Day 2 Residual variability')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('and Day 1 and Day 2 Residual variability')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('and Day 1 and Day 2 Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cisplatin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Cisplatin_Imbs2016_reference;
