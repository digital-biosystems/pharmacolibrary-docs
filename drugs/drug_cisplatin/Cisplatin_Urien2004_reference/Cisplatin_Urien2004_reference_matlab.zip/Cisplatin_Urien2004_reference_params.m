function p = Cisplatin_Urien2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cisplatin   source: Urien_2004 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cisplatin_Urien2004_reference_params';
  p.drug  = 'cisplatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 23.4;                % central volume [L]
  p.CL = 0.68;                % clearance [L/h]
  p.Vp = [12.0];             % peripheral volumes [L]
  p.Q  = [8.64];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
