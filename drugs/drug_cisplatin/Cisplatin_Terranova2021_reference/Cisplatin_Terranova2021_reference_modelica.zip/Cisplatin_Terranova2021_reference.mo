model Cisplatin_Terranova2021_reference
  parameter Real Cl_ref = 1.8055555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30005000000000004,
    adminMass = 1e-05,
    k12 = 0.0006944444444444444,
    k21 = 7.955771305285867e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cisplatin</h4><p>Cisplatin is a platinum-based chemotherapy agent used to treat multiple solid tumors, including those of the testis, ovary, bladder, and lung. The medication is administered as an intravenous injection. It is considered a cornerstone treatment and is listed among essential medicines globally.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412415\">Wikidata Q412415</a>, <a href=\"https://en.wikipedia.org/wiki/Cisplatin?oldid=1384057176\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisplatin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Terranova_2021</td></tr><tr><td>measured_compound:</td><td>cisplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cisplatin 300.05 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Terranova_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cisplatin_Terranova2021_reference;
