function p = Cisplatin_Xie2020_PD_leukocytes_params()
% Cisplatin_Xie2020_PD_leukocytes_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cisplatin Xie_2020::leukocytes: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response leukocytes in 10^9 cells/l. Driver: cisplatin (cited_pk).
p.E0 = 5.47;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 20.500000000000007;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
