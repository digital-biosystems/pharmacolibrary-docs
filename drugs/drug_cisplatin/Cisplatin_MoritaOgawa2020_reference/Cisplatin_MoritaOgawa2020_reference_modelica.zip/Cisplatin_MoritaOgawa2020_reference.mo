model Cisplatin_MoritaOgawa2020_reference
  parameter Real Cl_ref = 5.3055555555555565e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013800000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.300042,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cisplatin</h4><p>Cisplatin is a platinum-based anticancer drug used to treat many cancers, including testicular, ovarian, bladder, lung, stomach, and head and neck cancers. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412415\">Wikidata Q412415</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisplatin</td></tr><tr><td>population:</td><td>cancer patients with moderate renal dysfunction</td></tr><tr><td>source_paper:</td><td>Morita-Ogawa_2020</td></tr><tr><td>measured_compound:</td><td>unchanged cisplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cisplatin 300.05 g/mol (drugbank); unchanged cisplatin 300.042 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=unchanged cisplatin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cisplatin_MoritaOgawa2020_reference;
