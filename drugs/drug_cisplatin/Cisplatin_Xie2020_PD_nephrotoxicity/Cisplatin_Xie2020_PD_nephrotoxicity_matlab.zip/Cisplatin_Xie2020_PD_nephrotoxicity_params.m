function p = Cisplatin_Xie2020_PD_nephrotoxicity_params()
% Cisplatin_Xie2020_PD_nephrotoxicity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cisplatin Xie_2020::nephrotoxicity: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response nephrotoxicity in its own unit. Driver: cisplatin (cited_pk).
p.E0 = 0.0;
p.Emax = 344.0;
p.EC50 = 0.0004329999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4.4;
p.form = 'E0*(1 + Emax*frac)';
end
