model Cisplatin_Xie2020_PD_nephrotoxicity
  "indirect_response_iii exposure-response sweep — Xie_2020 :: nephrotoxicity (nephrotoxicity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 344,  // type III effect term
    EC50 = 0.000433,  // [kg/m3; μg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/ml per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.4, Interval = 0.0088),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cisplatin</h4><p>Cisplatin is a platinum-based anticancer drug used to treat many cancers, including testicular, ovarian, bladder, lung, stomach, and head and neck cancers. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412415\">Wikidata Q412415</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cisplatin_Xie2020_PD_nephrotoxicity</h4><p>The steady-state exposure-response curve of Xie F et al., <i>The AAPS journal 22(5):96</i> 2020 (<a href=\"https://doi.org/10.1208/s12248-020-00489-2\">doi:10.1208/s12248-020-00489-2</a>) — nephrotoxicity against cisplatin μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        344          maximal effect term (E max, Q320)
  EC50  =      0.433 μg/ml    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/ml of cisplatin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.433 μg/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Cisplatin_Xie2020_PD_nephrotoxicity;
