% Run (SimBiology): build model + dose, simulate 0..3864.0 h, plot.
p = Milrinone_Panel2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3864.0);
