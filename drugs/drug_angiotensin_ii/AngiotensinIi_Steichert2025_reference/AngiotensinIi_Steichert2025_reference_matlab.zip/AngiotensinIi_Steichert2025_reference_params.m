function p = AngiotensinIi_Steichert2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: angiotensin_ii   source: Steichert_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'AngiotensinIi_Steichert2025_reference_params';
  p.drug  = 'angiotensin_ii';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 223.71;                % central volume [L]
  p.CL = 36.39;                % clearance [L/h]
  p.Vp = [108.26];             % peripheral volumes [L]
  p.Q  = [6.38];             % inter-compartmental clearances [L/h]
  p.ka = 1.19;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
