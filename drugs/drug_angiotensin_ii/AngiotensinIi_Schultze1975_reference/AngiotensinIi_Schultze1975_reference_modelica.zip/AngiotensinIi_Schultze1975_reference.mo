model AngiotensinIi_Schultze1975_reference
  parameter Real Cl_ref = 2.1405555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0004611111111111111,
    Tlag = 7200.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>angiotensin_ii</td></tr><tr><td>population:</td><td>patient with malignant renovascular hypertension</td></tr><tr><td>source_paper:</td><td>Schultze_1975</td></tr><tr><td>measured_compound:</td><td>renin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=renin</li><li>gap-filled Q22 (CL) from Athanassa_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Athanassa_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Athanassa_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kim_2017's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AngiotensinIi_Schultze1975_reference;
