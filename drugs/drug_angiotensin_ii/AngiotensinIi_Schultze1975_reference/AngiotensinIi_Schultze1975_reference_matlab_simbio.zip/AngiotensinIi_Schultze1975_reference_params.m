function p = AngiotensinIi_Schultze1975_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: angiotensin_ii   source: Schultze_1975 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'AngiotensinIi_Schultze1975_reference_params';
  p.drug  = 'angiotensin_ii';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.0;                % central volume [L]
  p.CL = 7.706;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.66;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
