model AngiotensinIi_Baan1997_PD_fbf
  "sigmoid_emax exposure-response sweep — Baan_1997 :: FBF (forearm blood flow)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.78,  // [1; % × 0.01]
    EC50 = -9.4,  // [log M]
    gamma = 1,
    exposure_per_s = 1);   // 1 log M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'log M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = -94, Interval = -0.188),
    Documentation(info = "<html><body><!-- drug-about --><h4>About angiotensin_ii</h4><p>Angiotensin II, a peptide hormone, is used as a cardiac stimulant to raise blood pressure in hypotension and shock. It is authorised in the European Union, but its use is limited to a single approved product, mainly in hospital settings for severe low blood pressure.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412999\">Wikidata Q412999</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>AngiotensinIi_Baan1997_PD_fbf</h4><p>The steady-state exposure-response curve of Baan J et al., <i>Blood pressure 6(5):279–285</i> 1997 (<a href=\"https://doi.org/10.3109/08037059709062083\">doi:10.3109/08037059709062083</a>) — forearm blood flow [%] against angiotensin_ii log M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        -78 %        maximal effect term (Emax, Q323)
  EC50  =       -9.4 log M    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one log M of angiotensin_ii per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (-9.4 log M)  response -0.39
  exposure -> infinity  response -0.78</pre></body></html>"));
end AngiotensinIi_Baan1997_PD_fbf;
