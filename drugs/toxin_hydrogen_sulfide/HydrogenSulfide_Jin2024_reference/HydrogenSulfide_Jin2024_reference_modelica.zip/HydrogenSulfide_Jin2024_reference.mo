// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model HydrogenSulfide_Jin2024_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3696.0000000000005},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydrogen_sulfide</td></tr><tr><td>population:</td><td>mice dosed orally with JZ-HND</td></tr><tr><td>source_paper:</td><td>Jin_2024</td></tr><tr><td>measured_compound:</td><td>hydrogen sulfide (H2S) / hydronidone (HND)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Figure 4 (concentration–time profiles and rate constants; representative pharmacokinetic parameters table)</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>hydrogen_sulfide 34.076 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q47 ('H2S release from JZ-6: k'=0.0113) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('H2S release from JZ-6: t1/2'=61.6) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydrogen sulfide (H2S) / hydronidone (HND)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 4 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'JZ-HND' — its concentrations stay mass-only</li><li>molar mass: none found for 'hydrogen sulfide (H2S)' — its concentrations stay mass-only</li><li>molar mass: none found for 'compound 3' — its concentrations stay mass-only</li><li>molar mass: none found for 'hydrogen sulfide (H2S) / hydronidone (HND)' — its concentrations stay mass-only</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end HydrogenSulfide_Jin2024_reference;
