model Kanamycin_Lee2023_PD_unknown
  "sigmoid_emax exposure-response sweep — Lee_2023 :: ψ (net growth rate of bacteria)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.729,      // [1]
    Emax = -0.9728,  // [1]
    EC50 = 1.374,  // [1]
    gamma = -0.5324,
    exposure_per_s = 1);   // 1 unit per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 14, Interval = 0.028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About kanamycin</h4><p>Kanamycin is an antibiotic used to treat bacterial infections, including gram-negative infections, upper respiratory tract infections, hepatic coma, and tuberculosis. It remains in use, with approved and veterinary-approved status, and is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421951\">Wikidata Q421951</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Kanamycin_Lee2023_PD_unknown</h4><p>The steady-state exposure-response curve of Lee EB et al., <i>Pharmaceuticals (Basel, Switzerland) 17(1)</i> 2023 (<a href=\"https://doi.org/10.3390/ph17010027\">doi:10.3390/ph17010027</a>) — net growth rate of bacteria against kanamycin — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.729          drug-free response (baseline) (ψmax, Q324)
  Emax  =    -0.9728          maximal effect term (ψmin, Q323)
  EC50  =      1.374          exposure at half of the maximal effect term (EC50, Q321)
  gamma =    -0.5324          Hill coefficient (Hill Coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of kanamycin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.729   (drug-free)
  exposure = EC50 (1.374 )  response 0.2426
  exposure -> infinity  response -0.2438</pre></body></html>"));
end Kanamycin_Lee2023_PD_unknown;
