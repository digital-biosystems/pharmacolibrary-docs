function p = Kanamycin_Lee2023_PD_unknown_params()
% Kanamycin_Lee2023_PD_unknown_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% kanamycin Lee_2023::resp: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response ψ in its own unit. Driver: kanamycin (cited_pk).
p.E0 = 0.729;
p.Emax = -0.9728;
p.EC50 = 1.374;
p.gamma = -0.5324;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
