function p = Kanamycin_Strydom2019v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: kanamycin   source: Strydom_2019_2 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Kanamycin_Strydom2019v2_reference_params';
  p.drug  = 'kanamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 30.6;                % central volume [L]
  p.CL = 4.61;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.65;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
