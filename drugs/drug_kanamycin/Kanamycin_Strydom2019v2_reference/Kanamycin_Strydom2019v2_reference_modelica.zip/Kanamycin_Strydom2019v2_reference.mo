model Kanamycin_Strydom2019v2_reference
  parameter Real Cl_ref = 1.2805555555555557e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.030600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0004583333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>kanamycin</td></tr><tr><td>population:</td><td>adults with tuberculosis</td></tr><tr><td>source_paper:</td><td>Strydom_2019_2</td></tr><tr><td>measured_compound:</td><td>kanamycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pmed.1002773.t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (Clearance (L/h)); Q63 (Central volume (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=kanamycin</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Central volume (L)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Kanamycin_Strydom2019v2_reference;
