% Run: build params, simulate 0..72.0 h, plot + save Kanamycin_Strydom2019v2_mfx.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Kanamycin_Strydom2019v2_mfx.m
here = fileparts(mfilename('fullpath'));
p = Kanamycin_Strydom2019v2_mfx_params();
out = simulate_pk(p, 0:0.05:72.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('kanamycin — Strydom_2019_2 (oral)');
print(fig, fullfile(here, 'Kanamycin_Strydom2019v2_mfx.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Kanamycin_Strydom2019v2_mfx.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Kanamycin_Strydom2019v2_mfx.json'), 'w');
try
  s.model = 'Kanamycin_Strydom2019v2_mfx'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Kanamycin_Strydom2019v2_mfx","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Kanamycin_Strydom2019v2_mfx.png, Kanamycin_Strydom2019v2_mfx.csv, Kanamycin_Strydom2019v2_mfx.json\n');
