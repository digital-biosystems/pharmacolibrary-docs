% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Kanamycin_Strydom2019v2_mfx_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
