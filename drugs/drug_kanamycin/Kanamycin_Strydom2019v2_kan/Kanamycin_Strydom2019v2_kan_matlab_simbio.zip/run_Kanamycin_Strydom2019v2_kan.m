% Run (SimBiology): build model + dose, simulate 0..25.0 h, plot.
p = Kanamycin_Strydom2019v2_kan_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 25.0);
