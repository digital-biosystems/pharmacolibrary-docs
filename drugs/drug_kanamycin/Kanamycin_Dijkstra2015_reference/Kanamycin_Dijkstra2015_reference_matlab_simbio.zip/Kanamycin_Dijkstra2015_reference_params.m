function p = Kanamycin_Dijkstra2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: kanamycin   source: Dijkstra_2015 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Kanamycin_Dijkstra2015_reference_params';
  p.drug  = 'kanamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 12.0;                % central volume [L]
  p.CL = 4.62;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
