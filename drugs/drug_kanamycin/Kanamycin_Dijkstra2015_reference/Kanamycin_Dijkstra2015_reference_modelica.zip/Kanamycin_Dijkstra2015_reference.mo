model Kanamycin_Dijkstra2015_reference
  parameter Real Cl_ref = 1.2833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.012 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4844986,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About kanamycin</h4><p>Kanamycin is an antibiotic used to treat bacterial infections, including gram-negative infections, upper respiratory tract infections, hepatic coma, and tuberculosis. It remains in use, with approved and veterinary-approved status, and is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421951\">Wikidata Q421951</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>kanamycin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Dijkstra_2015</td></tr><tr><td>measured_compound:</td><td>kanamycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>kanamycin 484.499 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Dijkstra_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Kanamycin_Dijkstra2015_reference;
