function p = Kanamycin_Strydom2019v2_lzd_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: kanamycin   source: Strydom_2019_2 / lzd   route: oral
  % estimated (absent from source): F
  p.name  = 'Kanamycin_Strydom2019v2_lzd_params';
  p.drug  = 'kanamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 145.0;                % central volume [L]
  p.CL = 3.77;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.13;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
