// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model StrontiumChromate_McAughey1988_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2073600.0},
    MM = 0.051996,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>strontium_chromate</td></tr><tr><td>population:</td><td>occupational exposure in the chromate pigment production industry</td></tr><tr><td>source_paper:</td><td>McAughey_1988</td></tr><tr><td>measured_compound:</td><td>Hexavalent chromium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Strontium chromate 203.612 g/mol (pubchem); Hexavalent chromium 51.996 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('half-life'=24) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hexavalent chromium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 10886400, Tolerance = 1e-9, Interval = 21772.8));
end StrontiumChromate_McAughey1988_reference;
