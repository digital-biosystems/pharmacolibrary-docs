// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Methyl2Hydroxybenzoate_Pensado2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4302.292844854833},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methyl_2_hydroxybenzoate</td></tr><tr><td>population:</td><td>healthy human volunteers (in vivo stratum corneum sampling) and excised porcine skin</td></tr><tr><td>source_paper:</td><td>Pensado_2026</td></tr><tr><td>measured_compound:</td><td>methyl salicylate (Methyl 2-hydroxybenzoate)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>methyl_2_hydroxybenzoate 152.149 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q47 ('first-order clearance rate constant (30% formulation)', value 0.8) — already have one for this compound</li><li>dropped duplicate Q900 ('r2 (30% formulation)', value 0.84) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methyl salicylate (Methyl 2-hydroxybenzoate)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'methyl salicylate (Methyl 2-hydroxybenzoate)' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Methyl2Hydroxybenzoate_Pensado2026_reference;
