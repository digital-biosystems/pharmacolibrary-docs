// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Gatifloxacin_Andes2002_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2160.0},
    MM = 0.37539999999999996,
    adminMass = 0.0004,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gatifloxacin</td></tr><tr><td>population:</td><td>neutropenic and nonneutropenic mice in thigh and lung infection models</td></tr><tr><td>source_paper:</td><td>Andes_2002</td></tr><tr><td>measured_compound:</td><td>gatifloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>gatifloxacin 375.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 6 column 4 (char 310)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=gatifloxacin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q174, Q189 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Gatifloxacin_Andes2002_reference;
