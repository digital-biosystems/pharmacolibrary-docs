// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Gatifloxacin_Nagai2010_naive_rats
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {8532.0},
    MM = 0.37539999999999996,
    adminMass = 0.007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gatifloxacin</td></tr><tr><td>population:</td><td>male Wistar (naive) and Goto-Kakizaki (diabetic) rats given oral gatifloxacin 100 mg/kg/day</td></tr><tr><td>source_paper:</td><td>Nagai_2010</td></tr><tr><td>measured_compound:</td><td>Gatifloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>gatifloxacin 375.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Pancreatic GFLX concentrations (μg/g)' — extend the ontology if this is a real PK parameter (source ['Nagai_2010_table_2:row0:col7', 'Nagai_2010_table_2:row1:col7'])</li><li>dropped value-less row: 'a Determination of serum GFLX concentrations in diabetic rats receiving GFLX at 300 mg/kg/day was carried out on day 9 (n = 2) because of moribund conditions.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Gatifloxacin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'naive rats' subgroup of Nagai_2010 (paper reports 2 populations: diabetic rats, naive rats)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Gatifloxacin_Nagai2010_naive_rats;
