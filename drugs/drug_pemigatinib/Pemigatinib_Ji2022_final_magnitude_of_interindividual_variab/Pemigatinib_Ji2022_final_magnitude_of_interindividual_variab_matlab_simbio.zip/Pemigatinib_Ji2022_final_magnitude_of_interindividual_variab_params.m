function p = Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemigatinib   source: Ji_2022 / final_magnitude_of_interindividual_variability_cv_final_estimate   route: oral
  % estimated (absent from source): ka
  p.name  = 'Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab_params';
  p.drug  = 'pemigatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 134.0;                % central volume [L]
  p.CL = 10.7;                % clearance [L/h]
  p.Vp = [87.0];             % peripheral volumes [L]
  p.Q  = [14.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
