% Run (SimBiology): build model + dose, simulate 0..44.0 h, plot.
p = Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 44.0);
