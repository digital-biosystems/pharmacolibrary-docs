% Run: build params, simulate 0..44.0 h, plot + save Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.m
here = fileparts(mfilename('fullpath'));
p = Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab_params();
out = simulate_pk(p, 0:0.05:44.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('pemigatinib — Ji_2022 (oral)');
print(fig, fullfile(here, 'Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.json'), 'w');
try
  s.model = 'Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.png, Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.csv, Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab.json\n');
