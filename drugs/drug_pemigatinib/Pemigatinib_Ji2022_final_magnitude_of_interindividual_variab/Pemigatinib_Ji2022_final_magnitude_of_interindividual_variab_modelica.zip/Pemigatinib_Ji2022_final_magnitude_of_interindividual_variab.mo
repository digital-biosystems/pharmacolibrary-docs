model Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab
  parameter Real Cl_ref = 2.972222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.134 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.487508,
    adminMass = 1e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.005804311774461e-05,
    k21 = 4.6296296296296294e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pemigatinib</h4><p>Pemigatinib is a protein kinase inhibitor used to treat cholangiocarcinoma. It is an approved cancer medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q96398739\">Wikidata Q96398739</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemigatinib</td></tr><tr><td>population:</td><td>adults with advanced malignancies</td></tr><tr><td>source_paper:</td><td>Ji_2022</td></tr><tr><td>measured_compound:</td><td>pemigatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpdd1038-tbl-0004</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>pemigatinib 487.508 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ka, h−1' routed out of structural estimates ('Magnitude of Interindividual Variability (%CV) / Final Estimate')</li><li>table section iiv: 'ka, h−1' routed out of structural estimates ('Magnitude of Interindividual Variability (%CV) / %RSE')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Magnitude of Interindividual Variability (%CV) / Final Estimate')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Magnitude of Interindividual Variability (%CV) / %RSE')</li><li>table section iiv: 'Vc/F, L' routed out of structural estimates ('Magnitude of Interindividual Variability (%CV) / Final Estimate')</li><li>table section iiv: 'Vc/F, L' routed out of structural estimates ('Magnitude of Interindividual Variability (%CV) / %RSE')</li><li>salvaged Q27 ('CL/F'=10.7) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F'=134) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('Vp/F'=87.0) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=14.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pemigatinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'magnitude of interindividual variability (%cv) / final estimate' is the final model of Ji_2022 (paper reports 2 stages: final parameter estimate / population mean, magnitude of interindividual variability (%cv) / final estimate); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Pemigatinib_Ji2022_final_magnitude_of_interindividual_variab;
