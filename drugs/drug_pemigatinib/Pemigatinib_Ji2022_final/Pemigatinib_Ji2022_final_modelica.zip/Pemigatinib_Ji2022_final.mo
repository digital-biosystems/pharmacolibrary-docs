model Pemigatinib_Ji2022_final
  parameter Real Cl_ref = 2.5e-06 "Cl [m3/s]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  parameter Real cov_body_weight_1 = 0 "body weight covariate";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.738)*cov_body_weight_0)*(1 + (1.22)*cov_body_weight_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.487508,
    adminMass = 1e-06,
    ka = 0.0004138888888888889,
    Tlag = 0.0,
    k12 = 2.760524499654934e-05,
    k21 = 5.548619780829519e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pemigatinib</h4><p>Pemigatinib is a protein kinase inhibitor used to treat cholangiocarcinoma. It is an approved cancer medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q96398739\">Wikidata Q96398739</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemigatinib</td></tr><tr><td>population:</td><td>adults with advanced malignancies</td></tr><tr><td>source_paper:</td><td>Ji_2022</td></tr><tr><td>measured_compound:</td><td>pemigatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpdd1038-tbl-0004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pemigatinib 487.508 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Phosphate binder on CL' — extend the ontology if this is a real PK parameter (source ['cpdd1038-tbl-0004:row7:col1'])</li><li>covariate level 'Body weight (median = 73.3 kg) on Vc/F' → Q900:body_weight_median_73.3_kg_on_vc_f = 0.738 (linear_fractional on Q27)</li><li>dropped duplicate Q290 ('Proton pump inhibitor on Vc/F', value '-0.244') — already have one for this compound</li><li>covariate level 'Body weight on Vp/F' → Q900:body_weight_on_vp_f = 1.22 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'RV, SD' — extend the ontology if this is a real PK parameter (source ['cpdd1038-tbl-0004:row13:col1'])</li><li>covariate effect for Q22 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pemigatinib</li><li>model-stage split: 'final parameter estimate / population mean' is the final model of Ji_2022 (paper reports 2 stages: final parameter estimate / population mean, magnitude of interindividual variability (%cv) / final estimate); same population, different model-building step</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Pemigatinib_Ji2022_final;
