function p = Pemigatinib_Ji2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemigatinib   source: Ji_2022 / final   route: oral
  p.name  = 'Pemigatinib_Ji2022_final_params';
  p.drug  = 'pemigatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 161.0;                % central volume [L]
  p.CL = 9.0;                % clearance [L/h]
  p.Vp = [80.1];             % peripheral volumes [L]
  p.Q  = [16.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.49;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
