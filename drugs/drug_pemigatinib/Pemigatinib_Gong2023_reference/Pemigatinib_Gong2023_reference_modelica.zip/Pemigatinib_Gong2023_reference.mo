model Pemigatinib_Gong2023_reference
  parameter Real Cl_ref = 1.2444444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0437 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.487508,
    adminMass = 6e-06,
    ka = 0.03611111111111111,
    Tlag = 0.0,
    k12 = 0.00016018306636155606,
    k21 = 7.368421052631579e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pemigatinib</h4><p>Pemigatinib is a protein kinase inhibitor used to treat cholangiocarcinoma. It is an approved cancer medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q96398739\">Wikidata Q96398739</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemigatinib</td></tr><tr><td>population:</td><td>patients with advanced solid tumors including cholangiocarcinoma and healthy participants</td></tr><tr><td>source_paper:</td><td>Gong_2023</td></tr><tr><td>measured_compound:</td><td>pemigatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413064-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pemigatinib 487.508 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CL/F-Vc/Fa correlation coefficient, CV' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row2:col4'])</li><li>dropped unlinked row (NIL): 'Phosphate binder on CL/F, %' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row8:col1'])</li><li>dropped unlinked row (NIL): 'PPI on Ka, %' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row9:col1'])</li><li>dropped unlinked row (NIL): 'Male sex on CL/F, %' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row10:col1'])</li><li>dropped unlinked row (NIL): 'H2B antagonist on D1, %' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row12:col1'])</li><li>dropped unlinked row (NIL): 'Body weight on Vc/F, %' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row13:col1'])</li><li>dropped unlinked row (NIL): 'Body weight to Vp/F, %' — extend the ontology if this is a real PK parameter (source ['Gong_2023_table_p6_1:row14:col1'])</li><li>covariate effect for Q95 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pemigatinib</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pemigatinib_Gong2023_reference;
