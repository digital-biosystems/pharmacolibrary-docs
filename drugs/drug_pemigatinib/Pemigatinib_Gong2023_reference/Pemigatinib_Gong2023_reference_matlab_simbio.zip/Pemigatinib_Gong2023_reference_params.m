function p = Pemigatinib_Gong2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemigatinib   source: Gong_2023 / reference   route: oral
  p.name  = 'Pemigatinib_Gong2023_reference_params';
  p.drug  = 'pemigatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 43.7;                % central volume [L]
  p.CL = 44.8;                % clearance [L/h]
  p.Vp = [95.0];             % peripheral volumes [L]
  p.Q  = [25.2];             % inter-compartmental clearances [L/h]
  p.ka = 130.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 6.0;             % dose [mg]
end
