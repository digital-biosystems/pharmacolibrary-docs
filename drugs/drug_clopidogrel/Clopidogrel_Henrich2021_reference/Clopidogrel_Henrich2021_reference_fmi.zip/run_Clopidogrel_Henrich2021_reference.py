"""Simulate Clopidogrel_Henrich2021_reference — a parameter set for the generic PK_2C_enteral FMU.

    pip install fmpy matplotlib
    python run_Clopidogrel_Henrich2021_reference.py [--fmu PATH] [--step 0.02] [--stop 86400]

TWO FILES, ONE MODEL

This archive holds no binary. The model is PK_2C_enteral.fmu — one compiled template shared by
every model of this structure — plus the parameter values in Clopidogrel_Henrich2021_reference_params.json. Download the
template once from the record page and keep it next to this script (or point --fmu at it).

Why: the template FMU is ~0.46 MB and identical for hundreds of models; shipping one per
model meant 566 MB of near-identical binaries. Applying the parameters at run time gives a
result identical to a model-specific FMU — verified pointwise, not approximately.

WHY THE STEP IS SMALL

The dose is a RECTANGULAR PULSE one second wide inside a 24-hour simulation. The FMU
embeds CVODE but steps on an equidistant grid with root finding OFF, so a communication step
wider than the pulse integrates it for longer than it lasts and delivers too much drug —
89x too high at 176 s, 2.1x at 1 s, ~1% at 0.02 s. The step is an ACCURACY setting; the run
checks its own peaks and says FAIL if the step was too wide.
"""
import argparse
import re
import json
import json
import os
import numpy as np
from fmpy import extract, read_model_description
from fmpy.fmi2 import FMU2Slave, fmi2OK

NAME = "Clopidogrel_Henrich2021_reference"
TEMPLATE = "PK_2C_enteral"
OBSERVABLES = ['central.C']
REFERENCE = {'central.C': 0.014996218971429161}          # peak values from the authored Modelica model
STOP, STEP, EVERY = 86400, 0.02, 250

ap = argparse.ArgumentParser()
ap.add_argument("--fmu", default=None, help=f"path to {TEMPLATE}.fmu (default: alongside this script)")
ap.add_argument("--step", type=float, default=STEP, help="communication step (s)")
ap.add_argument("--record-every", type=int, default=EVERY, help="keep every Nth step")
ap.add_argument("--stop", type=float, default=STOP, help="stop time (s)")
args = ap.parse_args()

here = os.path.dirname(os.path.abspath(__file__))
fmu_path = args.fmu or os.path.join(here, TEMPLATE + ".fmu")
if not os.path.isfile(fmu_path):
    raise SystemExit(
        f"{TEMPLATE}.fmu not found at {fmu_path}.\n"
        f"It is a separate download — the 'generic FMU' link on this model's page — "
        f"because one template serves every model of this structure. "
        f"Put it beside this script, or pass --fmu PATH.")

with open(os.path.join(here, NAME + "_params.json"), encoding="utf-8") as fh:
    params = json.load(fh)["parameters"]

md = read_model_description(fmu_path)
vrs = {v.name: v.valueReference for v in md.modelVariables}
types = {v.name: v.type for v in md.modelVariables}
unknown = sorted(set(params) - set(vrs))
if unknown:
    raise SystemExit(f"{TEMPLATE}.fmu has no parameter(s) {unknown} — wrong template?")

tmp = extract(fmu_path)
fmu = FMU2Slave(guid=md.guid, unzipDirectory=tmp,
                modelIdentifier=md.coSimulation.modelIdentifier, instanceName=NAME)
fmu.instantiate()
# Parameters are set in the SETUP phase, before initialization: they are variability="fixed",
# so this is the only window in which the FMU accepts them.
fmu.setupExperiment(startTime=0.0, stopTime=args.stop)
# Split by DECLARED type. adminCount is an Integer parameter, and setReal on an Integer is
# rejected by the FMU — the run then aborts on its first step and writes an empty result.
_by_type = {"Real": ([], []), "Integer": ([], []), "Boolean": ([], [])}
for _k, _v in params.items():
    _t = types.get(_k, "Real")
    _refs, _vals = _by_type.get(_t, _by_type["Real"])
    _refs.append(vrs[_k])
    _vals.append(bool(_v) if _t == "Boolean" else int(_v) if _t == "Integer" else float(_v))
if _by_type["Real"][0]:
    fmu.setReal(*_by_type["Real"])
if _by_type["Integer"][0]:
    fmu.setInteger(*_by_type["Integer"])
if _by_type["Boolean"][0]:
    fmu.setBoolean(*_by_type["Boolean"])
fmu.enterInitializationMode()
fmu.exitInitializationMode()

obs_vrs = [vrs[o] for o in OBSERVABLES if o in vrs]
obs_names = [o for o in OBSERVABLES if o in vrs]
t, rows, k, failures = 0.0, [], 0, 0
while t < args.stop - 1e-9:
    h = min(args.step, args.stop - t)
    # fmpy RAISES on a real error and returns None on success in current versions, so a
    # plain `!= fmi2OK` treats every good step as a failure — which ends the loop at t=0 and
    # writes an empty result.
    st = fmu.doStep(currentCommunicationPoint=t, communicationStepSize=h)
    if st is not None and st != fmi2OK:
        failures += 1
    t += h
    k += 1
    if k % args.record_every == 0 or t >= args.stop - 1e-9:
        rows.append([t] + list(fmu.getReal(obs_vrs)))
fmu.terminate(); fmu.freeInstance()
if failures:
    print(f"warning: {failures} solver step(s) reported a non-OK status")

data = np.array(rows)
np.savetxt(NAME + ".csv", data, delimiter=",", header=",".join(["time"] + obs_names), comments="")
print(f"wrote {NAME}.csv ({len(data)} rows, step {args.step} s)")

print("peak check against the authored Modelica model:")
ok = True
for i, name in enumerate(obs_names, start=1):
    ref = REFERENCE.get(name)
    if ref is None:
        continue
    got = float(data[:, i].max())
    dev = abs(got - ref) / ref * 100 if ref else 0.0
    flag = "ok" if dev <= 5 else "FAIL — widen? no: narrow --step"
    ok = ok and dev <= 5
    print(f"  {name:30s} {got:.6g} vs {ref:.6g}   {dev:.1f}%  {flag}")
if not ok:
    print("a FAIL here means the communication step was too wide, not that the model is wrong")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    for i, name in enumerate(obs_names, start=1):
        plt.plot(data[:, 0] / 3600.0, data[:, i], label=name)
    plt.xlabel("time (h)"); plt.ylabel("concentration"); plt.legend(); plt.tight_layout()
    plt.savefig(NAME + ".png", dpi=120)
    print(f"wrote {NAME}.png")
except ImportError:
    pass
