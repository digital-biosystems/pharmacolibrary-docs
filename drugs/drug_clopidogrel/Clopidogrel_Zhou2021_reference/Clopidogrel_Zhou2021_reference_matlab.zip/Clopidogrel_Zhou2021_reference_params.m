function p = Clopidogrel_Zhou2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Zhou_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Clopidogrel_Zhou2021_reference_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.9;                % central volume [L]
  p.CL = 70.8;                % clearance [L/h]
  p.Vp = [18.7];             % peripheral volumes [L]
  p.Q  = [17.04];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
