% Run (SimBiology): build model + dose, simulate 0..43.0 h, plot.
p = Clopidogrel_Kim2009_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 43.0);
