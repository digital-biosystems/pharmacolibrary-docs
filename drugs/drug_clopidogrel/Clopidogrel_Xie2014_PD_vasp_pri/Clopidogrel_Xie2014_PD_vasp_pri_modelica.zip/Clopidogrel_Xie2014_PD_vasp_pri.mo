model Clopidogrel_Xie2014_PD_vasp_pri
  "indirect_response_i exposure-response sweep — Xie_2014 :: VASP-PRI (vasodilator stimulated phosphoprotein platelet reactivity index)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.664,  // type I effect term
    EC50 = 1.57e-06,  // [kg/m3; ng x mL(-1) × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng x mL(-1) per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16, Interval = 0.032),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Clopidogrel_Xie2014_PD_vasp_pri</h4><p>The steady-state exposure-response curve of Xie C et al., <i>Yao xue xue bao = Acta pharmaceutica Sinica 49(10):1426–1432</i> 2014 — vasodilator stimulated phosphoprotein platelet reactivity index against clopidogrel active metabolite ng x mL(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.664          maximal effect term (E(max), Q323)
  EC50  =       1.57 ng x mL(-1) exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng x mL(-1) of clopidogrel active metabolite per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.57 ng x mL(-1))  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Clopidogrel_Xie2014_PD_vasp_pri;
