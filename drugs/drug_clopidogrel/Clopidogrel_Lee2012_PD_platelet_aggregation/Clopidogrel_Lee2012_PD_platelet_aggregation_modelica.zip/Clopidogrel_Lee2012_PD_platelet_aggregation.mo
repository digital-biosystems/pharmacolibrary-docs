model Clopidogrel_Lee2012_PD_platelet_aggregation
  "indirect_response_i exposure-response sweep — Lee_2012 :: platelet aggregation (platelet aggregation)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.667,      // [1; % × 0.01]
    Emax = 0.292,  // type I effect term
    EC50 = 6.29e-09,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.063, Interval = 0.000126),
    Documentation(info = "<html><body><h4>Clopidogrel_Lee2012_PD_platelet_aggregation</h4><p>The steady-state exposure-response curve of Lee J et al., <i>Journal of clinical pharmacology 52(7):985–995</i> 2012 (<a href=\"https://doi.org/10.1177/0091270011409228\">doi:10.1177/0091270011409228</a>) — platelet aggregation [%] against SR26334 ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       66.7 %        drug-free response (baseline) (BASE, Q324)
  Emax  =      0.292          maximal effect term (E(max), Q323)
  EC50  =    0.00629 ng/mL    exposure at half of the maximal effect term (EC(5) (0), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of SR26334 per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.667   (drug-free)
  exposure = EC50 (0.00629 ng/mL)  response 0.5696
  exposure -> infinity  response 0.4722</pre></body></html>"));
end Clopidogrel_Lee2012_PD_platelet_aggregation;
