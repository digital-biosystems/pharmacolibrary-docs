# clopidogrel — `Clopidogrel_Jung2024` (matlab)

**This is a hand-authored reference model, not a machine extraction.**

The Modelica file in the Modelica bundle is written and checked by a person. This bundle is DERIVED from it: the same compartments, volumes and flows re-expressed as matlab, generated from the model's curated structure so it cannot drift from the original.

- **population:** CYP2C19 extensive (normal) metaboliser
- **source:** Jung 2024, population PK-PD modelling of clopidogrel for dose optimisation
- **parameterisation:** apparent (F = 1.0, so volumes and clearances are apparent)

## Structure

- **clopidogrel** (pro-drug (parent)) — 3C: hepatic 1463.92 L, central 1463.92 L, peripheral 2823.98 L
- **clopidogrel H4** (active metabolite) — 1C: central_H4 51.45 L
- **clopidogrel carboxylic acid** (inactive metabolite) — 2C: central_carboxylic_acid 17.34 L, peripheral_carboxylic_acid 51.89 L

Transfers within a moiety are two-way; metabolite formation is **one-way** out of the hepatic compartment, so nothing flows back into the pro-drug.

## Observed

- `central` — clopidogrel (parent)
- `central_H4` — clopidogrel H4 (active metabolite)
- `central_carboxylic_acid` — clopidogrel carboxylic acid (inactive metabolite)

## Files

- `Clopidogrel_Jung2024_params.m` — the parameters, as a struct
- `Clopidogrel_Jung2024_rhs.m` — the right-hand side of the ODE system
- `run_Clopidogrel_Jung2024.m` — run script — simulates and writes a CSV and a plot

## Running it

MATLAB (no toolbox needed — plain ode15s).

```bash
run_Clopidogrel_Jung2024        % in MATLAB, from this directory
```

## What a correct run produces

Dose 0.0003 kg (300 mg loading dose, as reported in the paper), 0–86400 s:

| variable | Cmax (kg/m³ = g/L) | t_max | at 24 h |
|---|---|---|---|
| `central.C` | 1.23883e-05 (12.4 ng/mL) | 0.597 h | 1.52e-07 |
| `central_H4.C` | 0.000418679 (419 ng/mL) | 0.55 h | 2.08e-07 |
| `central_carboxylic_acid.C` | 0.0103504 (10.4 ug/mL) | 0.642 h | 0.000251 |

Units are SI throughout: amounts in kg, volumes in m³, time in seconds, so a concentration in kg/m³ is the same number as g/L.

---

Curated by Tomas Kulhanek (2026-09-09). Packaged by `pk_knowledge_scripts.export.curated`.
