model Clopidogrel_Jung2024_PGx_CYP2C19
  "Clopidogrel_Jung2024 with the CYP2C19 phenotype as a parameter (Jung_2024)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2C19 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real CL1_by_phenotype[6] = {0.00010285833333333333, 0.00082719123909043768, 0.00038067974236454156, 0.00010285833333333333, 0.00010285833333333333, 0.00010285833333333333};
  parameter Real q1_m11_by_phenotype[6] = {0.00030857499999999995, 8.7423113662126118e-05, 0.00018289737020495215, 0.00030857499999999995, 0.00030857499999999995, 0.00030857499999999995};
  parameter Real q1_m21_by_phenotype[6] = {0.0021600333333333332, 0.0016568503726517737, 0.0020078889671295095, 0.0021600333333333332, 0.0021600333333333332, 0.0021600333333333332};
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(CLm1 = 2.0625e-05, CLm2 = 2.0133333333333333e-06, F = 1, Tlag = 705.60000000000002, Vd1 = 1.4639200000000001, Vd1m1 = 0.051450000000000003, Vd1m2 = 0.017340000000000001, Vd2 = 1.4639200000000001, Vd2m2 = 0.051889999999999999, Vd3 = 2.8239800000000002, adminCount = 1, adminDuration = 600, adminMass = 0.00029999999999999997, ka = 0.0054555555555555555, q12 = 0.00023491666666666667, q21 = 0.00023491666666666667, q23 = 0.00016331388888888887, q32 = 0.00016331388888888887, qm21_m22 = 1.2433333333333332e-06, qm22_m21 = 1.2433333333333332e-06, CL1 = CL1_by_phenotype[Integer(metabolizer)], q1_m11 = q1_m11_by_phenotype[Integer(metabolizer)], q1_m21 = q1_m21_by_phenotype[Integer(metabolizer)]);
  annotation (experiment(StartTime = 0, StopTime = 86400));
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Clopidogrel_Jung2024_PGx_CYP2C19;
