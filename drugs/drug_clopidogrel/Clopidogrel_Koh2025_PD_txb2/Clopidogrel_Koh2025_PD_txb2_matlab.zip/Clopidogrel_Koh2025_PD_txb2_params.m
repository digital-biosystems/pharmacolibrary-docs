function p = Clopidogrel_Koh2025_PD_txb2_params()
% Clopidogrel_Koh2025_PD_txb2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clopidogrel Koh_2025::TXB2: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mol/L per second, in SI inside (kg/m3, s). Response TXB2 in μg/L. Driver: acetylsalicylic acid (conc_no_pk).
p.E0 = 2.639999999999999e-05;
p.Emax = 1.0;
p.EC50 = 3.5999999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 999.9999999999999;
p.stop_time = 0.036;
p.form = 'E0*(1 - Emax*frac)';
end
