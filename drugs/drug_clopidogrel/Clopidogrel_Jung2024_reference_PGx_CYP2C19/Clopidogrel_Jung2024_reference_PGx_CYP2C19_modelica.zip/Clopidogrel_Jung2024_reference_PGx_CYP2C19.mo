model Clopidogrel_Jung2024_reference_PGx_CYP2C19
  "Clopidogrel_Jung2024_reference with the CYP2C19 phenotype as a parameter (Jung_2024)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2C19 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real CL1_by_phenotype[6] = {0.000102858666667, 0.000827193919772, 0.000380680976035, 0.000102858666667, 0.000102858666667, 0.000102858666667};
  parameter Real q1_m11_by_phenotype[6] = {0.000308576, 8.74233969745e-05, 0.000182897962921, 0.000308576, 0.000308576, 0.000308576};
  parameter Real q1_m21_by_phenotype[6] = {0.002160032, 0.00165684934992, 0.00200788772771, 0.002160032, 0.002160032, 0.002160032};
  extends Clopidogrel_Jung2024_reference(CL1 = CL1_by_phenotype[Integer(metabolizer)], q1_m11 = q1_m11_by_phenotype[Integer(metabolizer)], q1_m21 = q1_m21_by_phenotype[Integer(metabolizer)]);
end Clopidogrel_Jung2024_reference_PGx_CYP2C19;
