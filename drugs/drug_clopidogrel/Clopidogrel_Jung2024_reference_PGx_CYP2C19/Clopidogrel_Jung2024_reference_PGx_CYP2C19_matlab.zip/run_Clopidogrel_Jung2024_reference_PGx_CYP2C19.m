% Run: build params, simulate 0..24.0 h, plot every molecule + save Clopidogrel_Jung2024_reference_PGx_CYP2C19.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Clopidogrel_Jung2024_reference_PGx_CYP2C19.m
% metabolizer: the CYP2C19 phenotype (1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra).
% Set it before running, e.g.  metabolizer = 2; run_Clopidogrel_Jung2024_reference_PGx_CYP2C19  (default 4, the reference).
if ~exist('metabolizer', 'var'), metabolizer = 4; end
phenotypes = {'Unknown', 'Poor', 'Intermediate', 'Normal', 'Rapid', 'Ultra'};
here = fileparts(mfilename('fullpath'));
p = Clopidogrel_Jung2024_reference_PGx_CYP2C19_params(metabolizer);
out = simulate_network(p, 0:0.05:24.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('concentration [mg/L]');
title('clopidogrel — Jung_2024 (parent + metabolites)');
print(fig, fullfile(here, ['Clopidogrel_Jung2024_reference_PGx_CYP2C19_' phenotypes{metabolizer} '.png']), '-dpng', '-r150');

fid = fopen(fullfile(here, ['Clopidogrel_Jung2024_reference_PGx_CYP2C19_' phenotypes{metabolizer} '.csv']), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg_per_L', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, ['Clopidogrel_Jung2024_reference_PGx_CYP2C19_' phenotypes{metabolizer} '.json']), 'w');
try
  s.model = 'Clopidogrel_Jung2024_reference_PGx_CYP2C19'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg_per_L']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Clopidogrel_Jung2024_reference_PGx_CYP2C19"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): Cmax=%.4g mg/L  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Clopidogrel_Jung2024_reference_PGx_CYP2C19.png, Clopidogrel_Jung2024_reference_PGx_CYP2C19.csv, Clopidogrel_Jung2024_reference_PGx_CYP2C19.json\n');
