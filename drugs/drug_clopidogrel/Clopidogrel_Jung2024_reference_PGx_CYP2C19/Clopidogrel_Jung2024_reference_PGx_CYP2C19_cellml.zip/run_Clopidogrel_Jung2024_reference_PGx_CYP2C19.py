#!/usr/bin/env python3
"""Simulate Clopidogrel_Jung2024_reference_PGx_CYP2C19.cellml (0..24.0 h) — a parent and its metabolites — and write
Clopidogrel_Jung2024_reference_PGx_CYP2C19.csv, Clopidogrel_Jung2024_reference_PGx_CYP2C19.json and Clopidogrel_Jung2024_reference_PGx_CYP2C19.png. Requires libcellml, scipy and matplotlib."""
import re
import sys

# The CYP2C19 phenotype (Pharmacolibrary.Pharmacogenomics.PGx.MetabolizerStatus order):
# 1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra.
# python run_Clopidogrel_Jung2024_reference_PGx_CYP2C19.py 2   -> poor metaboliser; outputs Clopidogrel_Jung2024_reference_PGx_CYP2C19_Poor.csv/.json/.png
PHENOTYPES = ['Unknown', 'Poor', 'Intermediate', 'Normal', 'Rapid', 'Ultra']
METABOLIZER = int(sys.argv[1]) if len(sys.argv) > 1 else 4
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import libcellml as lc
from scipy.integrate import solve_ivp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Clopidogrel_Jung2024_reference_PGx_CYP2C19")
OUT = {'C_central': 'clopidogrel', 'C_M1': 'clopidogrel H4', 'C_M2': 'clopidogrel carboxylic acid'}                        # output -> molecule
EDGES = [0.21266666666666667, 0.3793333333333333]                     # the dose pulse [h]: integrated piecewise across it

_text = re.sub(r'(<variable name="metabolizer" units="dimensionless" initial_value=")[^"]*',
               r"\g<1>%d" % METABOLIZER, open(BASE + ".cellml").read())
model = lc.Parser().parseModel(_text)
BASE += "_" + PHENOTYPES[METABOLIZER - 1]
validator = lc.Validator(); validator.validateModel(model)
if validator.errorCount():
    raise SystemExit("Clopidogrel_Jung2024_reference_PGx_CYP2C19.cellml is not valid: " + validator.error(0).description())
analyser = lc.Analyser(); analyser.analyseModel(model)
if analyser.errorCount():
    raise SystemExit("Clopidogrel_Jung2024_reference_PGx_CYP2C19.cellml is not solvable: " + analyser.error(0).description())
generator = lc.Generator()
generator.setProfile(lc.GeneratorProfile(lc.GeneratorProfile.Profile.PYTHON))
generator.setModel(analyser.model())
ns = {}
exec(compile(generator.implementationCode(), "<generated>", "exec"), ns)
states = ns["create_states_array"]()
variables = ns["create_variables_array"]()
ns["initialise_variables"](states, ns["create_states_array"](), variables)
ns["compute_computed_constants"](variables)

def rhs(t, y):
    r = ns["create_states_array"]()
    ns["compute_rates"](t, list(y), r, variables)
    return list(r)

t_eval = np.linspace(0.0, 24.0, 2001)
cuts = sorted({0.0, 24.0, *[e for e in EDGES if 0.0 < e < 24.0]})
ts, ys, y0 = [], [], list(states)
for a, b in zip(cuts[:-1], cuts[1:]):
    te = t_eval[(t_eval >= a) & (t_eval <= b)]
    sol = solve_ivp(rhs, (a, b), y0, t_eval=np.unique(np.r_[a, te, b]),
                    method="LSODA", rtol=1e-10, atol=1e-12)
    if not sol.success:
        raise SystemExit("integration failed: " + sol.message)
    keep = np.isin(sol.t, t_eval) & ((sol.t > a) if ts else True)
    ts += list(sol.t[keep]); ys += list(sol.y[:, keep].T); y0 = list(sol.y[:, -1])

names = [v.get("name") if isinstance(v, dict) else str(v) for v in ns.get("VARIABLE_INFO", [])]
cols = {o: [] for o in OUT}
for tk, yk in zip(ts, ys):
    v = list(variables)
    ns["compute_variables"](tk, list(yk), ns["create_states_array"](), v)
    for o in OUT:
        cols[o].append(float(v[names.index(o)]))
t = [float(x) for x in ts]

with open(BASE + ".csv", "w") as f:
    f.write("time_h," + ",".join(o + "_mg_per_L" for o in OUT) + "\n")
    for k, ti in enumerate(t):
        f.write("%r," % ti + ",".join("%r" % cols[o][k] for o in OUT) + "\n")
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Clopidogrel_Jung2024_reference_PGx_CYP2C19", "stop_time_h": 24.0, "labels": OUT, "time_h": t,
               **{o + "_mg_per_L": cols[o] for o in OUT}}, f, indent=2)
plt.figure()
for o in OUT:
    plt.semilogy(t, [max(c, 1e-12) for c in cols[o]], linewidth=1.5, label=f"{OUT[o]} ({o})")
plt.xlabel("time [h]"); plt.ylabel("concentration [mg/L]"); plt.legend()
plt.title("Clopidogrel_Jung2024_reference_PGx_CYP2C19"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
