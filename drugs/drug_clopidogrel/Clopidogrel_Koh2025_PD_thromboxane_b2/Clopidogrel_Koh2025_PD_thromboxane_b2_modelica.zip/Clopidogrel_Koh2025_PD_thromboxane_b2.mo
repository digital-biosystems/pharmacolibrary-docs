model Clopidogrel_Koh2025_PD_thromboxane_b2
  "sigmoid_emax exposure-response sweep — Koh_2025 :: thromboxane B2 (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 2.639999999999999e-05,      // [kg/m3; μg/L × 1e-06]
    Emax = -9.999999999999997e-07,  // [kg/m3; μg/L × 1e-06]
    EC50 = 3.5999999999999996,  // [mol/m3; mol/L × 1000]
    gamma = 1.0,
    exposure_per_s = 999.9999999999999);   // 1 mol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 0.036, Interval = 7.2e-05));
end Clopidogrel_Koh2025_PD_thromboxane_b2;
