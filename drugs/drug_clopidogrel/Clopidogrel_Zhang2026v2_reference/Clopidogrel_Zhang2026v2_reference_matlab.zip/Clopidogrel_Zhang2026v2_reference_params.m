function p = Clopidogrel_Zhang2026v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Zhang_2026_2 / reference   route: oral
  p.name  = 'Clopidogrel_Zhang2026v2_reference_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1920.0;                % central volume [L]
  p.CL = 20.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.48;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
