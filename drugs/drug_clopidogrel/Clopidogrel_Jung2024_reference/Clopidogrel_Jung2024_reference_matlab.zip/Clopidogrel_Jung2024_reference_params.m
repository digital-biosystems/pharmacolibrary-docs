function p = Clopidogrel_Jung2024_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: clopidogrel   source: Jung_2024 / reference   PK_3M_3C parent + 2 metabolite(s), 6 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=321.822 g/mol C_M1=355.83 g/mol C_M2=307.8 g/mol
  p.name  = 'Clopidogrel_Jung2024_reference_params';
  p.drug  = 'clopidogrel';
  p.kind  = 'network';
  p.template = 'PK_3M_3C';
  p.states = {'hepatic', 'central', 'peripheral', 'central_M1', 'central_M2', 'peripheral_M2'};
  p.V = [1463.92, 1463.92, 2823.98, 51.45, 17.34, 51.89];          % compartment volumes [L]
  p.K = [-6.901319744248322, 0.5776955024864747, 0.0, 0.0, 0.0, 0.0;
         0.5776955024864747, -0.9793089786327122, 0.20819198436249547, 0.0, 0.0, 0.0;
         0.0, 0.40161347614623744, -0.20819198436249547, 0.0, 0.0, 0.0;
         0.8390235150907462, 0.0, 0.0, -1.443148688046647, 0.0, 0.0;
         5.080403747897934, 0.0, 0.0, 0.0, -0.6761245674740484, 0.08625939487377143;
         0.0, 0.0, 0.0, 0.0, 0.25813148788927337, -0.08625939487377143];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % hepatic
  p.ka = 19.64;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.196;             % absorption lag [h] (in dose_start)
  p.dose = 75.0;             % dose [mg]
  p.dose_start = 0.21266666666666667;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [2.0, 4.0, 5.0];
  p.out_names = {'C_central', 'C_M1', 'C_M2'};
  p.out_labels = {'clopidogrel', 'clopidogrel H4', 'clopidogrel carboxylic acid'};
end
