function p = Clopidogrel_Jung2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Jung_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Clopidogrel_Jung2024_reference_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1463.92;                % central volume [L]
  p.CL = 9257.28;                % clearance [L/h]
  p.Vp = [2823.98];             % peripheral volumes [L]
  p.Q  = [587.93];             % inter-compartmental clearances [L/h]
  p.ka = 19.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
