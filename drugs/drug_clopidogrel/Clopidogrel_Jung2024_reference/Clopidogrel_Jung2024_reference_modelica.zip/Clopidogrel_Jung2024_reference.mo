// parent + metabolites (clopidogrel H4, clopidogrel carboxylic acid): PK_3M_3C — hepatic compartment; parent 2 + hepatic, metabolites [1, 2]
model Clopidogrel_Jung2024_reference
  parameter Real Q22_clopidogrel_H4_ref = 2.0625e-05 "CLm1 (L/h) [SI]";
  parameter Real cov_im = 1.0 "im covariate (reference 1.0)";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(
    Vd1 = 1.46392,
    Vd2 = 1.46392,
    Vd3 = 2.82398,
    q12 = 0.0002349166666666667,
    q21 = 0.0002349166666666667,
    q23 = 0.00016331388888888887,
    q32 = 0.00016331388888888887,
    q1_m11 = 0.0003085760000000001,
    q1_m21 = 0.0021600320000000005,
    CL1 = 0.00010285866666666669,
    Vd1m1 = 0.05145,
    CLm1 = Q22_clopidogrel_H4_ref*(cov_im/1.0)^(-0.45),
    Vd1m2 = 0.01734,
    CLm2 = 2.0133333333333333e-06,
    Vd2m2 = 0.05189,
    qm21_m22 = 1.2433333333333332e-06,
    qm22_m21 = 1.2433333333333332e-06,
    MW = 0.321822,
    MW_m1 = 0.35583,
    MW_m2 = 0.3078,
    F = 1.0,
    ka = 0.0054555555555555555,
    Tlag = 705.6,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clopidogrel</td></tr><tr><td>population:</td><td>healthy males</td></tr><tr><td>source_paper:</td><td>Jung_2024</td></tr><tr><td>measured_compound:</td><td>clopidogrel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413053-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_3C: absorption rate constant reported; hepatic volume not reported separately — set equal to the central volume (as Jung_2024 fixes Vc = VH); formation of clopidogrel H4: 0.120 = 0.12 of CL (the paper's fm scheme); formation of clopidogrel carboxylic acid: 0.84 = 0.84 of CL (the paper's fm scheme); F = 1: first pass is the hepatic compartment (absorption complete, no bioavailability reported); dose 75 mg (paper); covariate effects applied (1): fm1_im — typical subject by default</td></tr><tr><td>molar_masses:</td><td>clopidogrel 321.822 g/mol (drugbank); clopidogrel H4 355.83 g/mol (paper); clopidogrel carboxylic acid 307.8 g/mol (paper)</td></tr></table><h4>Interpretation flags</h4><ul><li>compound tags: 1 row(s) → clopidogrel carboxylic acid (m_suffix 1)</li><li>table representations disagree for 'V c (=VH) (L)'; source reconciliation required</li><li>table representations disagree for 'V p (L)'; source reconciliation required</li><li>table representations disagree for 'CLc (L/h)'; source reconciliation required</li><li>table representations disagree for 'Q c (L/h)'; source reconciliation required</li><li>table representations disagree for 'Q p (L/h)'; source reconciliation required</li><li>table representations disagree for 'k a (h−1)'; source reconciliation required</li><li>table representations disagree for 'T lag (h)'; source reconciliation required</li><li>table representations disagree for 'σ clopidogrel'; source reconciliation required</li><li>table representations disagree for 'fm1'; source reconciliation required</li><li>table representations disagree for 'fm1~IM'; source reconciliation required</li><li>table representations disagree for 'fm1~PM'; source reconciliation required</li><li>table representations disagree for 'fm2'; source reconciliation required</li><li>table representations disagree for 'fm2~IM'; source reconciliation required</li><li>table representations disagree for 'fm2~PM'; source reconciliation required</li><li>table representations disagree for 'V m1 (L)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clopidogrel_Jung2024_reference;
