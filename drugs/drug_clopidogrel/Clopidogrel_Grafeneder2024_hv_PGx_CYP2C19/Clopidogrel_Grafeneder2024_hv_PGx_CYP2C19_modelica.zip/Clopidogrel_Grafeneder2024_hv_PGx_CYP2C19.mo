model Clopidogrel_Grafeneder2024_hv_PGx_CYP2C19
  "Clopidogrel_Grafeneder2024_hv with the CYP2C19 phenotype as a parameter (Grafeneder_2024::hv)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2C19 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {1.42833333333e-06, 1.42833333333e-06, 0.00156635769462, 1.42833333333e-06, 3.88261254498e-06, 1.42833333333e-06};
  extends Clopidogrel_Grafeneder2024_hv(Cl = Cl_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Clopidogrel_Grafeneder2024_hv_PGx_CYP2C19;
