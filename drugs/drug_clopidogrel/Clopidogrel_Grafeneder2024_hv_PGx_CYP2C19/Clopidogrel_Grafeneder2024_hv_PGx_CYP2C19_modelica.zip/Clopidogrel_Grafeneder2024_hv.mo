model Clopidogrel_Grafeneder2024_hv
  parameter Real Cl_ref = 1.4283333333333334e-06 "Cl [m3/s]";
  parameter Real cov_intermediate_metabolizer_0 = 0 "intermediate metabolizer covariate";
  parameter Real cov_normal_metabolizer_1 = 0 "normal metabolizer covariate";
  parameter Real cov_rapid_metabolizer_2 = 0 "rapid metabolizer covariate";
  parameter Real Vd_ref = 0.007528 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (7.0)*cov_intermediate_metabolizer_0)*(1 + (8.0)*cov_normal_metabolizer_1)*(1 + (1.0)*cov_rapid_metabolizer_2),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.321822,
    adminMass = 7.5e-05,
    ka = 0.0016527777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clopidogrel</td></tr><tr><td>population:</td><td>hemodialysis patients and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Grafeneder_2024</td></tr><tr><td>measured_compound:</td><td>clopidogrel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clopidogrel 321.822 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Cmax,CAM [ng/ml]', value '24.7') — already have one for this compound</li><li>dropped duplicate Q74 ('AUClast_CAM [ng/ml·min]', value '1596') — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2_CAM [min]', value '35.2') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax [μg/ml]', value '9.6') — already have one for this compound</li><li>dropped duplicate Q74 ('AUClast [μg/ml·min]', value '409') — already have one for this compound</li><li>dropped duplicate Q17 ('AUCinf [μg/ml·min]', value '468') — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 [min]', value '76.8') — already have one for this compound</li><li>covariate level 'Intermediate metabolizer' → Q900:intermediate_metabolizer = 7 (linear_fractional on Q22)</li><li>covariate level 'Normal metabolizer' → Q900:normal_metabolizer = 8 (linear_fractional on Q22)</li><li>covariate level 'Rapid metabolizer' → Q900:rapid_metabolizer = 1 (linear_fractional on Q22)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clopidogrel</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>pharmacogenetic covariate 'intermediate_metabolizer' (intermediate metabolizer) — PGx domain</li><li>pharmacogenetic covariate 'normal_metabolizer' (normal metabolizer) — PGx domain</li><li>pharmacogenetic covariate 'rapid_metabolizer' (rapid metabolizer) — PGx domain</li><li>population split: 'hv n = 16' subgroup of Grafeneder_2024 (paper reports 2 populations: hdp n = 17, hv n = 16)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clopidogrel_Grafeneder2024_hv;
