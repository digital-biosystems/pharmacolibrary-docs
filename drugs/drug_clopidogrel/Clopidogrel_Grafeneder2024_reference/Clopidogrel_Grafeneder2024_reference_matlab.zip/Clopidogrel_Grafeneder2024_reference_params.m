function p = Clopidogrel_Grafeneder2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Grafeneder_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Clopidogrel_Grafeneder2024_reference_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.528;                % central volume [L]
  p.CL = 5.142;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.81;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
