function p = Clopidogrel_Grafeneder2024_hv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Grafeneder_2024 / hv   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Clopidogrel_Grafeneder2024_hv_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.128;                % central volume [L]
  p.CL = 4.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
