function p = Clopidogrel_Grafeneder2024_hv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Grafeneder_2024 / hv   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Clopidogrel_Grafeneder2024_hv_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.128;                % central volume [L]
  p.CL = 4.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
