function p = Clopidogrel_Jung2024_PD_pru_params()
% Clopidogrel_Jung2024_PD_pru_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clopidogrel Jung_2024::PRU: indirect_response_ii exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PRU in its own unit. Driver: clopidogrel H4 (pk_record).
p.E0 = 204.16666666666669;
p.Emax = 57.84;
p.EC50 = 6.731999999999999e-05;
p.gamma = 1.851;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 673.2;
p.form = 'E0/(1 + Emax*frac)';
end
