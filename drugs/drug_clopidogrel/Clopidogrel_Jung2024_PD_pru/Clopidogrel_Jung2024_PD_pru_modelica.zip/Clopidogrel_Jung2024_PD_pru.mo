model Clopidogrel_Jung2024_PD_pru
  "indirect_response_iv exposure-response sweep — Jung_2024 :: PRU (P2Y12 reaction unit)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 204.166666667,      // [1]
    Emax = 57.84,  // type IV effect term
    EC50 = 6.732e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.851,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (1.225/0.006 = 204.2) — the paper's stated baseline may differ
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><h4>Clopidogrel_Jung2024_PD_pru</h4><p>The steady-state exposure-response curve of Jung YS et al., <i>CPT: pharmacometrics &amp; systems pharmacology 13(1):29–40</i> 2024 (<a href=\"https://doi.org/10.1002/psp4.13053\">doi:10.1002/psp4.13053</a>) — P2Y12 reaction unit against clopidogrel H4 ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 204.166666667          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      57.84          maximal effect term (E max, Q320)
  EC50  =      67.32 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =      1.851          Hill coefficient (Hill, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of clopidogrel H4 per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 204.2   (drug-free)
  exposure = EC50 (67.32 ng/mL)  response 6.824
  exposure -> infinity  response 3.47</pre></body></html>"));
end Clopidogrel_Jung2024_PD_pru;
