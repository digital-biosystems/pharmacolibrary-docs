model Clopidogrel_Jung2024_PD_pru
  "indirect_response_ii exposure-response sweep — Jung_2024 :: PRU (P2Y12 reaction unit)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 204.16666666666669,      // [1]
    Emax = 57.84,  // type IV effect term
    EC50 = 6.731999999999999e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.851,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (1.225/0.006 = 204.2) — the paper's stated baseline may differ
  // emax_not_a_fraction: type II needs Imax ≤ 1 but the record has 57.84; bound as the reciprocal stimulation form (IV) the paper fitted
  annotation(experiment(StartTime = 0, StopTime = 673.2, Interval = 1.3464));
end Clopidogrel_Jung2024_PD_pru;
