function p = Clopidogrel_Yata2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clopidogrel   source: Yata_2026 / reference   route: oral
  p.name  = 'Clopidogrel_Yata2026_reference_params';
  p.drug  = 'clopidogrel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 282.1;                % central volume [L]
  p.CL = 67.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.62;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
