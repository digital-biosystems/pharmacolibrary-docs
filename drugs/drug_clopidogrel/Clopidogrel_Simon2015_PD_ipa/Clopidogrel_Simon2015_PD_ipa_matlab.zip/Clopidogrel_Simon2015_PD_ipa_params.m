function p = Clopidogrel_Simon2015_PD_ipa_params()
% Clopidogrel_Simon2015_PD_ipa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clopidogrel Simon_2015::IPA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h*μg/L per second, in SI inside (kg/m3, s). Response IPA in %. Driver: active metabolite (dose_only).
p.E0 = 0.0;
p.Emax = -0.56;
p.EC50 = 15.9;
p.gamma = 7.04;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 160.0;
p.form = 'E0 + Emax*frac';
end
