model Clopidogrel_Simon2015_PD_ipa
  "sigmoid_emax exposure-response sweep — Simon_2015 :: IPA (inhibition of platelet aggregation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.56,  // [1; % × 0.01]
    EC50 = 15.9,  // [h*μg/L]
    gamma = 7.04,
    exposure_per_s = 1);   // 1 h*μg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'h*μg/L' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 160, Interval = 0.32),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Clopidogrel_Simon2015_PD_ipa</h4><p>The steady-state exposure-response curve of Simon N et al., <i>European journal of clinical pharmacology 71(9):1059–1066</i> 2015 (<a href=\"https://doi.org/10.1007/s00228-015-1882-3\">doi:10.1007/s00228-015-1882-3</a>) — inhibition of platelet aggregation [%] against active metabolite h*μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         56 %        maximal effect term (Emax, Q323)
  EC50  =       15.9 h*μg/L   exposure at half of the maximal effect term (EAUC50, Q321)
  gamma =       7.04          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one h*μg/L of active metabolite per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (15.9 h*μg/L)  response -0.28
  exposure -> infinity  response -0.56</pre></body></html>"));
end Clopidogrel_Simon2015_PD_ipa;
