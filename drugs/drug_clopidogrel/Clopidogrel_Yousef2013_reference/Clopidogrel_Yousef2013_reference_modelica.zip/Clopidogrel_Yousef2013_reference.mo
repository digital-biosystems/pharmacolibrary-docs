model Clopidogrel_Yousef2013_reference
  parameter Real Cl_ref = 1.6555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7.5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clopidogrel</td></tr><tr><td>population:</td><td>healthy Jordanian subjects</td></tr><tr><td>source_paper:</td><td>Yousef_2013</td></tr><tr><td>measured_compound:</td><td>clopidogrel-IM</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>clopidogrel 321.822 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is clopidogrel; the compartment is clopidogrel-IM. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is clopidogrel-IM, not clopidogrel</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>clopidogrel's own concentration-time course is not produced by this model</li><li>dropped unlinked row (NIL): 'T 42 (h)' — extend the ontology if this is a real PK parameter (source ['tab_0:row6:col1', 'Yousef_2013_table_2:row5:col1'])</li><li>metabolite clopidogrel-im: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=clopidogrel-IM</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V c /F (l)' is the general volume)</li><li>row roles (LLM): model_class=compartmental; 5/5 row label(s) assigned, 6 linked by role</li><li>molar mass: no plausible PubChem entry for 'clopidogrel-IM' ('clopidogrel carboxylic acid metabolite') — left in mass units</li><li>molar mass: none found for 'clopidogrel-IM' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clopidogrel_Yousef2013_reference;
