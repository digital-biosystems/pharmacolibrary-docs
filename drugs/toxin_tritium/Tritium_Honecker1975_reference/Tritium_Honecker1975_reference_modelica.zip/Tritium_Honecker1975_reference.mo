// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tritium_Honecker1975_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3600.0},
    adminMass = 0.00035,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tritium</td></tr><tr><td>population:</td><td>young adult and old male rats</td></tr><tr><td>source_paper:</td><td>Honecker_1975</td></tr><tr><td>measured_compound:</td><td>Amphetamine, p-hydroxyamphetamine, p-hydroxynorephedrine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Amphetamine 135.21 g/mol (pubchem); p-hydroxyamphetamine 151.209 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('half life of the elimination from the plasma in young adult animals'=60) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Amphetamine, p-hydroxyamphetamine, p-hydroxynorephedrine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'Amphetamine, p-hydroxyamphetamine, p-hydroxynorephedrine' ('amphetamine, p-hydroxyamphetamine, p-hydroxynorephedrine') — left in mass units</li><li>molar mass: none found for 'Amphetamine, p-hydroxyamphetamine, p-hydroxynorephedrine' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Amphetamine, p-hydroxyamphetamine, p-hydroxynorephedrine', not tritium — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Tritium_Honecker1975_reference;
