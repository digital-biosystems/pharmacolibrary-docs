function p = Asunaprevir_Osawa2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: asunaprevir   source: Osawa_2018 / reference   route: oral
  p.name  = 'Asunaprevir_Osawa2018_reference_params';
  p.drug  = 'asunaprevir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 64.2;                % central volume [L]
  p.CL = 5.29;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.865;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
