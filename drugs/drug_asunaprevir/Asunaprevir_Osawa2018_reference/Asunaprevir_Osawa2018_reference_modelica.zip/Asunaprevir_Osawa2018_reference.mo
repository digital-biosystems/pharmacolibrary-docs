model Asunaprevir_Osawa2018_reference
  parameter Real Cl_ref = 1.4694444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06420000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7482859999999999,
    adminMass = 1e-05,
    ka = 0.0002402777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About asunaprevir</h4><p>Asunaprevir is an antiviral protease inhibitor that was used to treat hepatitis C virus infections. It is no longer in use, having been withdrawn from the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4811881\">Wikidata Q4811881</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>asunaprevir</td></tr><tr><td>population:</td><td>Japanese subjects with chronic hepatitis C virus infection</td></tr><tr><td>source_paper:</td><td>Osawa_2018</td></tr><tr><td>measured_compound:</td><td>asunaprevir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1274-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>asunaprevir 748.286 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ' routed out of structural estimates ('Residual error')</li><li>unit_dimension_unknown: 'h‐1' (kabs)</li><li>dropped duplicate Q27 ('CL/F ∼SEX', value '0.0274') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F ∼TX', value '0.0336') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F ∼BCRCL', value '0.235') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F ∼BBWT', value '0.605') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F', value '0.155') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '0.145') — already have one for this compound</li><li>dropped duplicate Q49 ('Ka', value '0.756') — already have one for this compound</li><li>dropped duplicate Q76 ('CL/F: V/F', value '0.141') — already have one for this compound</li><li>implicit units: 'Ka (h‐1)' → 1/h (from the paper text: 'The text states: &quot;Ka was 0.865 h‐1 (5.97 RSE%)&quot; and &quot;The first‐order absorption rate constant was 0.23 h‐1&quot;. The table f')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=asunaprevir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Asunaprevir_Osawa2018_reference;
