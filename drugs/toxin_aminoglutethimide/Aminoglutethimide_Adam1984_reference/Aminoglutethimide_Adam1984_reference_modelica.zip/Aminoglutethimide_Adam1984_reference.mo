// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Aminoglutethimide_Adam1984_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {70200.0},
    MM = 0.232283,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminoglutethimide</td></tr><tr><td>population:</td><td>healthy volunteers and metastatic breast cancer patients</td></tr><tr><td>source_paper:</td><td>Adam_1984</td></tr><tr><td>measured_compound:</td><td>Aminoglutethimide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Aminoglutethimide 232.283 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('AG half-life (slow acetylators)', value 12.6) — already have one for this compound</li><li>unit_dimension_unknown: 'metabolic clearance vs acetylAG/AG ratio' (CL_ratio)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Aminoglutethimide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>row roles: LLM call failed (JSONDecodeError) — deterministic compound tags kept</li><li>molar mass: none found for 'Acetylaminoglutethimide' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Aminoglutethimide_Adam1984_reference;
