// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Aminoglutethimide_Murray1979_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {967.182112409226},
    MM = 0.232283,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminoglutethimide</td></tr><tr><td>population:</td><td>women with metastatic breast carcinoma treated with aminoglutethimide and hydrocortisone</td></tr><tr><td>source_paper:</td><td>Murray_1979</td></tr><tr><td>measured_compound:</td><td>Aminoglutethimide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>aminoglutethimide 232.283 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('mean half-life after six to 32 weeks of therapy', value 7.3) — already have one for this compound</li><li>relinked 'mean clearance rate prior to therapy' Q22 → Q47: a rate constant in '1./hour' (the unit decides, not the label)</li><li>relinked 'mean clearance rate after therapy' Q22 → Q47: a rate constant in '1./hour' (the unit decides, not the label)</li><li>dropped duplicate Q47 ('mean clearance rate after therapy', value 5.29) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Aminoglutethimide</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Aminoglutethimide_Murray1979_reference;
