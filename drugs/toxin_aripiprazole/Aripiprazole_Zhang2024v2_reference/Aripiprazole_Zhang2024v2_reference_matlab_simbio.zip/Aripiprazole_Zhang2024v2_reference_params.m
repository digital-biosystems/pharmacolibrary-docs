function p = Aripiprazole_Zhang2024v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Zhang_2024_2 / reference   route: oral
  p.name  = 'Aripiprazole_Zhang2024v2_reference_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 854.0;                % central volume [L]
  p.CL = 27.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.861;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
