% Run: build params, simulate 0..37.0 h, plot + save Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.m
here = fileparts(mfilename('fullpath'));
p = Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test_params();
out = simulate_pk(p, 0:0.05:37.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('aripiprazole — Ciocotișan_2026 (oral)');
print(fig, fullfile(here, 'Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.json'), 'w');
try
  s.model = 'Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.png, Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.csv, Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test.json\n');
