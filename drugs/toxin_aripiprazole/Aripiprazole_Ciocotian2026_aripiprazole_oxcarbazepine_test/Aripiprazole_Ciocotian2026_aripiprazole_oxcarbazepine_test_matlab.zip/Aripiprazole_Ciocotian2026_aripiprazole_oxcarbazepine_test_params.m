function p = Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Ciocotișan_2026 / aripiprazole_oxcarbazepine_test   route: oral
  p.name  = 'Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11834.9;                % central volume [L]
  p.CL = 1112.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.65;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 76.8;             % absorption lag [h]
  p.dose = 560.0;             % dose [mg]
end
