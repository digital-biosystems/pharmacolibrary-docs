function p = Aripiprazole_Zhang2019_PD_psp_increase_params()
% Aripiprazole_Zhang2019_PD_psp_increase_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% aripiprazole Zhang_2019::PSP_increase: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one week per second, in SI inside (kg/m3, s). Response PSP increase in %. Driver: aripiprazole (cited_pk).
p.E0 = 0.0;
p.Emax = 0.239;
p.EC50 = 22256640.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 604800.0;
p.stop_time = 370.0;
p.form = 'E0 + Emax*frac';
end
