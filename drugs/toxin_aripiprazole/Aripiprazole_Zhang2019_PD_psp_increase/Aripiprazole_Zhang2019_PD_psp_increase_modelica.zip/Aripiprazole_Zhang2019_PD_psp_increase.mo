model Aripiprazole_Zhang2019_PD_psp_increase
  "emax exposure-response sweep — Zhang_2019 :: PSP increase (Personal and Social Performance (PSP) score increase from baseline)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.239,  // [1; % × 0.01]
    EC50 = 22256640,  // [s; week × 604800]
    gamma = 1,
    exposure_per_s = 604800);   // 1 week per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 370, Interval = 0.74),
    Documentation(info = "<html><body><h4>Aripiprazole_Zhang2019_PD_psp_increase</h4><p>The steady-state exposure-response curve of Zhang L et al., <i>Acta pharmacologica Sinica 40(12):1611-1620</i> 2019 (<a href=\"https://doi.org/10.1038/s41401-019-0285-x\">doi:10.1038/s41401-019-0285-x</a>) — Personal and Social Performance (PSP) score increase from baseline [%] against aripiprazole week — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       23.9 %        maximal effect term (Emax, Q320)
  EC50  =       36.8 week     exposure at half of the maximal effect term (ET50, Q321)
  gamma =          1          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one week of aripiprazole per second of simulated time (exposure is in s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (36.8 week)  response 0.1195
  exposure -> infinity  response 0.239</pre></body></html>"));
end Aripiprazole_Zhang2019_PD_psp_increase;
