model Aripiprazole_Wang2022_final_PGx_CYP2D6
  "Aripiprazole_Wang2022_final with the CYP2D6 phenotype as a parameter (Wang_2022::final)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2D6 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real ka_by_phenotype[6] = {0.00015, 0.00015, 0.00015013566131, 0.00015, 0.00015, 0.00015};
  extends Aripiprazole_Wang2022_final(ka = ka_by_phenotype[Integer(metabolizer)]);
end Aripiprazole_Wang2022_final_PGx_CYP2D6;
