function p = Aripiprazole_Wang2022_final_PGx_CYP2D6_params(metabolizer)
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Wang_2022 / final   route: oral
%   PGx: metabolizer is the CYP2D6 phenotype (1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra);
%   it selects ka. A phenotype the paper gives no effect for
%   runs the reference values.
  if nargin < 1, metabolizer = 4; end
  p.name  = 'Aripiprazole_Wang2022_final_PGx_CYP2D6_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 93.4;                % central volume [L]
  p.CL = 4.515;                % clearance [L/h]
  p.Vp = [134.0];             % peripheral volumes [L]
  p.Q  = [0.591];             % inter-compartmental clearances [L/h]
  p.ka = 0.54;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
  switch metabolizer
    case 3   % Intermediate metabolizer
      p.ka = 0.540488;                % absorption rate [1/h]
  end
  p.metabolizer = metabolizer;
end
