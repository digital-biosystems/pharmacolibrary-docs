function p = Aripiprazole_Ciocotian2026_aripiprazole_group_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Ciocotișan_2026 / aripiprazole_group_reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Aripiprazole_Ciocotian2026_aripiprazole_group_reference_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8514.8;                % central volume [L]
  p.CL = 1040.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 560.0;             % dose [mg]
end
