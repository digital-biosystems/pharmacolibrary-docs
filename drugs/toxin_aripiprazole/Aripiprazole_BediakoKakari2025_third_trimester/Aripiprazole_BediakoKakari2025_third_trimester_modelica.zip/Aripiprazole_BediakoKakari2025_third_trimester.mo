// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Aripiprazole_BediakoKakari2025_third_trimester
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {146.784108824459},
    MM = 0.44838799999999995,
    adminMass = 1.5e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aripiprazole</td></tr><tr><td>population:</td><td>virtual pregnant adults (100 per scenario)</td></tr><tr><td>source_paper:</td><td>Bediako-Kakari_2025</td></tr><tr><td>measured_compound:</td><td>Aripiprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>aripiprazole 448.388 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Aripiprazole' — extend the ontology if this is a real PK parameter (source ['Tab1:row1:col2', 'Tab1:row1:col4'])</li><li>dropped unlinked row (NIL): 'Mean C:M ratio' — extend the ontology if this is a real PK parameter (source ['Tab1:row2:col2', 'Tab1:row2:col4', 'Tab1:row11:col2', 'Tab1:row11:col4', 'Tab1:row19:col2', 'Tab1:row19:col4', 'Tab1:row28:col2', 'Tab1:row28:col4'])</li><li>dropped duplicate Q18 ('fAUC 0–24 h,ss (µg.h/mL)', value '0.75') — already have one for this compound</li><li>dropped duplicate Q18 ('mAUC0–28d,ss (µg.h/mL)', value '33.88') — already have one for this compound</li><li>dropped duplicate Q18 ('fAUC0–28d,ss (µg.h/mL)', value '22.00') — already have one for this compound</li><li>dropped duplicate Q32 ('fCmaxss,oral (ng/mL)', value '43.3') — already have one for this compound</li><li>dropped duplicate Q32 ('fCmaxss,LAI (ng/mL)', value '71.1') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Olanzapine' — extend the ontology if this is a real PK parameter (source ['Tab1:row18:col2', 'Tab1:row18:col4'])</li><li>dropped duplicate Q18 ('mAUC0–24h,ss (µg.h/mL)', value '0.42') — already have one for this compound</li><li>dropped duplicate Q18 ('fAUC 0–24h,ss (µg.h/mL)', value '0.15') — already have one for this compound</li><li>dropped duplicate Q18 ('fAUC 0–28d,ss (µg.h/mL)', value '9.60') — already have one for this compound</li><li>dropped value-less row: 'C:M cord-to-maternal plasma drug concentration ratio'</li><li>dropped value-less row: 'mAUCss'</li><li>dropped value-less row: 'fAUCss'</li><li>dropped value-less row: 'mCmaxss'</li><li>dropped value-less row: 'fCmaxss'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Aripiprazole_BediakoKakari2025_third_trimester;
