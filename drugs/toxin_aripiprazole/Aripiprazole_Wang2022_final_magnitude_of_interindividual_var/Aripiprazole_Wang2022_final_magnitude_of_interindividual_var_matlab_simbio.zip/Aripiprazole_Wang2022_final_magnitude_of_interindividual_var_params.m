function p = Aripiprazole_Wang2022_final_magnitude_of_interindividual_var_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Wang_2022 / final_magnitude_of_interindividual_variability_cv_final_estimate   route: oral
  p.name  = 'Aripiprazole_Wang2022_final_magnitude_of_interindividual_var_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 157.0;                % central volume [L]
  p.CL = 3.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.65;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 76.8;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
