% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Aripiprazole_Wang2022_final_magnitude_of_interindividual_var_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
