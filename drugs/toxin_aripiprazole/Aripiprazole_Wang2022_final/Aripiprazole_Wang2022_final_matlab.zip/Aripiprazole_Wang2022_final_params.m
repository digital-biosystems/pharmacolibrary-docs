function p = Aripiprazole_Wang2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Wang_2022 / final   route: oral
  p.name  = 'Aripiprazole_Wang2022_final_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 93.4;                % central volume [L]
  p.CL = 4.515;                % clearance [L/h]
  p.Vp = [134.0];             % peripheral volumes [L]
  p.Q  = [0.591];             % inter-compartmental clearances [L/h]
  p.ka = 0.54;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
