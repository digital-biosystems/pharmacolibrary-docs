model Aripiprazole_Wang2022_final
  parameter Real Cl_ref = 1.2541666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09340000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.44838799999999995,
    adminMass = 2.5e-05,
    ka = 0.00015000000000000001,
    Tlag = 0.0,
    k12 = 1.7576730906495357e-06,
    k21 = 1.2251243781094526e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aripiprazole</td></tr><tr><td>population:</td><td>subjects with schizophrenia</td></tr><tr><td>source_paper:</td><td>Wang_2022</td></tr><tr><td>measured_compound:</td><td>Aripiprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpdd1022-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>aripiprazole 448.388 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Phase 1 RV (%CV)' — extend the ontology if this is a real PK parameter (source ['cpdd1022-tbl-0001:row17:col1'])</li><li>dropped unlinked row (NIL): 'Phase 3 RV (%CV)' — extend the ontology if this is a real PK parameter (source ['cpdd1022-tbl-0001:row18:col1'])</li><li>dropped unlinked row (NIL): 'Minimum value of the objective function = 48892.907' — extend the ontology if this is a real PK parameter (source ['cpdd1022-tbl-0001:row19:col1'])</li><li>NIL: refused to back-fill base 'R1' from footnote/prose loose number None (source ['cpdd1022-tbl-0001:footnote', 'cpdd1022-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 7.3 (source ['cpdd1022-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 52.2 (source ['cpdd1022-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 8.2 (source ['cpdd1022-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>covariate im for shrinkage from footnote/prose kept as documentation only (['cpdd1022-tbl-0001:footnote'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['cpdd1022-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['cpdd1022-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>dropped duplicate covariate effect 'im'/'' on Q49 — ambiguous identity (two shifts cannot share one category)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Aripiprazole</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Aripiprazole_Wang2022_final;
