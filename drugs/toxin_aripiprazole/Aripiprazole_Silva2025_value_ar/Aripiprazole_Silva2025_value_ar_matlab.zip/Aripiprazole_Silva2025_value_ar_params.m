function p = Aripiprazole_Silva2025_value_ar_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aripiprazole   source: Silva_2025 / value_ar   route: oral
  p.name  = 'Aripiprazole_Silva2025_value_ar_params';
  p.drug  = 'aripiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 110.775;                % central volume [L]
  p.CL = 4.515;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.65;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 76.8;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
