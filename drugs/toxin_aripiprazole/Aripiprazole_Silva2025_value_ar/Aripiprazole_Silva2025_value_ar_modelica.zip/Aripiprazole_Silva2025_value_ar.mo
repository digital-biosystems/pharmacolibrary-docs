model Aripiprazole_Silva2025_value_ar
  parameter Real Cl_ref = 1.2541666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.145817 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.44838799999999995,
    adminMass = 2e-06,
    ka = 0.0007361111111111111,
    Tlag = 276480.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aripiprazole</td></tr><tr><td>population:</td><td>humans</td></tr><tr><td>source_paper:</td><td>Silva_2025</td></tr><tr><td>measured_compound:</td><td>Aripiprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Aripiprazole 448.388 g/mol (pubchem); Aripiprazole lauroxil 660.721 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is aripiprazole; the compartment is Aripiprazole. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Aripiprazole, not aripiprazole</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>aripiprazole's own concentration-time course is not produced by this model</li><li>dropped unlinked row (NIL): 'Log P' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row2:col2'])</li><li>dropped unlinked row (NIL): 'Precipitation time (s)' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row4:col2'])</li><li>dropped unlinked row (NIL): 'Solubility Factor' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row6:col2'])</li><li>unit_dimension_unknown: 'B:p' (Kp)</li><li>dropped unlinked row (NIL): 'Human effective jejunal permeability (Peff)(×10⁻⁴ cm/s)' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row10:col2'])</li><li>dropped unlinked row (NIL): 'Bile salt solubilization ratio' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row11:col2'])</li><li>dropped unlinked row (NIL): 'Particle radius (um)' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row13:col2'])</li><li>dropped unlinked row (NIL): 'Compartmental PK' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row15:col2'])</li><li>dropped unlinked row (NIL): '5 mg AR' — extend the ontology if this is a real PK parameter (source ['Silva_2025_table_2:row18:col2'])</li><li>salvaged Q63 ('volume of central'=1.5825) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of second'=2.0831) from results prose — parameter table was unreadable</li><li>metabolite aripiprazole: Q61→Q376 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>metabolite volume: 'volume of central' Q63→Q61 for Aripiprazole — it is 1-compartment, so its central volume is its only volume</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Aripiprazole_Silva2025_value_ar;
