model Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test_2
  parameter Real Cl_ref = 0.00019561111111111114 "Cl [m3/s]";
  parameter Real Vd_ref = 3.4825000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.44838799999999995,
    adminMass = 0.00056,
    ka = 0.0007361111111111111,
    Tlag = 276480.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aripiprazole</td></tr><tr><td>population:</td><td>male Wistar albino rats</td></tr><tr><td>source_paper:</td><td>Ciocotișan_2026</td></tr><tr><td>measured_compound:</td><td>Aripiprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Aripiprazole 448.388 g/mol (pubchem); Dehydroaripiprazole 446.372 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Aripiprazole</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'aripiprazole + oxcarbazepine(test, n = 12)' subgroup of Ciocotișan_2026 (paper reports 3 populations: aripiprazole + oxcarbazepine (test, n = 12), aripiprazole + oxcarbazepine(test, n = 12), aripiprazole group (reference, n = 12))</li><li>row roles (LLM): model_class=noncompartmental; 10/10 row label(s) assigned, 0 linked by role; re-tagged Aripiprazole→parent ×36</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Koue_2007's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Hard_2017's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Aripiprazole_Ciocotian2026_aripiprazole_oxcarbazepine_test_2;
