// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Methotrimeprazine_Dahl1976_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {108000.0},
    MM = 0.328474,
    adminMass = 0.0001,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrimeprazine</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Dahl_1976</td></tr><tr><td>measured_compound:</td><td>Methotrimeprazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Methotrimeprazine 328.474 g/mol (pubchem); Methotrimeprazine sulfoxide 344.473 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/kg body weight' (t1/2β)</li><li>unit_dimension_unknown: '% shorter than the half-life of methotrimeprazine' (t1/2z)</li><li>implicit units: 'apparent half-life of the sulfoxide' → h (from the popPK convention: 'The parameter is a half-life (t1/2) with a value of 30. In population pharmacokinetics, half-lives are conventionally re')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methotrimeprazine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 0 linked by role; re-tagged Methotrimeprazine→parent ×1, Methotrimeprazine→Methotrimeprazine sulfoxide ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end Methotrimeprazine_Dahl1976_reference;
