model Methotrimeprazine_Hals1982_reference
  parameter Real Cl_ref = 2.0500000000000002e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 1.162 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrimeprazine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Hals_1982</td></tr><tr><td>measured_compound:</td><td>Methotrimeprazine (Levomepromazine)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>methotrimeprazine 328.474 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for t1/2α from footnote/prose kept as documentation only (['Hals_1982:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Methotrimeprazine (Levomepromazine)</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 0 linked by role; re-tagged Methotrimeprazine (Levomepromazine)→parent ×2</li><li>molar mass: no plausible PubChem entry for 'Methotrimeprazine (Levomepromazine)' ('Methotrimeprazine (Levomepromazine)') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'N-monodesmethyl levomepromazine' ('N-monodesmethyl levomepromazine') — left in mass units</li><li>molar mass: none of 1 PubChem candidate(s) is 'levomepromazine sulfoxide' (LLM) — left in mass units</li><li>molar mass: none found for 'Methotrimeprazine (Levomepromazine)' — its concentrations stay mass-only</li><li>molar mass: none found for 'N-monodesmethyl levomepromazine' — its concentrations stay mass-only</li><li>molar mass: none found for 'levomepromazine sulfoxide' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Methotrimeprazine_Hals1982_reference;
