model Methotrimeprazine_ter2003_reference
  parameter Real Cl_ref = 5.26278414869588e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0040999999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.328474,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrimeprazine</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>ter_2003</td></tr><tr><td>measured_compound:</td><td>Levomepromazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Levomepromazine 328.474 g/mol (pubchem); methotrimeprazine 328.474 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l per kg lean body mass' (V/F)</li><li>unit_dimension_unknown: 'l per hour per 70 kg' (CL)</li><li>implicit units: 'apparent volume of distribution' → L (from the popPK convention: 'No text or caption specifies units. In population PK, the volume of distribution is typically reported in Liters (L). Th')</li><li>implicit units: 'metabolic clearance' → L/h (from the popPK convention: 'No text or caption specifies units. In population PK, clearance is typically reported in Liters per hour (L/h). The valu')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Levomepromazine</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>toxin: half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li><li>derived CL/F=1.8946 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrimeprazine_ter2003_reference;
