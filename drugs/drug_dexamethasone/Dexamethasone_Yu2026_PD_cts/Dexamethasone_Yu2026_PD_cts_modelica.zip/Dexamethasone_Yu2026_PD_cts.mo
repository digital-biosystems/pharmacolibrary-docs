model Dexamethasone_Yu2026_PD_cts
  "indirect_response_i exposure-response sweep — Yu_2026 :: CTS (cortisol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 3.83e-08,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.39, Interval = 0.00078),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dexamethasone</h4><p>Dexamethasone is a corticosteroid used for many conditions, including inflammation, autoimmune disease, several cancers and lymphomas, cerebral and macular edema, Addison's disease, and COVID-19. It is widely used, appears on the WHO essential medicines list, is approved for human and veterinary use, and is authorised in the European Union for indications such as multiple myeloma, uveitis, and COVID-19.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422252\">Wikidata Q422252</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dexamethasone_Yu2026_PD_cts</h4><p>The steady-state exposure-response curve of Yu R et al., <i>Pharmaceutical research</i> 2026 (<a href=\"https://doi.org/10.1007/s11095-026-04120-5\">doi:10.1007/s11095-026-04120-5</a>) — cortisol [ng/mL] against dexamethasone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (I max, Q323)
  EC50  =     0.0383 ng/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of dexamethasone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0383 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Dexamethasone_Yu2026_PD_cts;
