model Dexamethasone_Calderin2025v2_reference
  parameter Real Cl_ref = 3.638888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 8.946759259259258e-06,
    Tlag = 1044.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>adults with HIV-associated tuberculosis meningitis</td></tr><tr><td>source_paper:</td><td>Calderin_2025_2</td></tr><tr><td>measured_compound:</td><td>dexamethasone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q76 ('V/F'=26.6) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=131) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dexamethasone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Luo_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Świerczek_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Calderin2025v2_reference;
