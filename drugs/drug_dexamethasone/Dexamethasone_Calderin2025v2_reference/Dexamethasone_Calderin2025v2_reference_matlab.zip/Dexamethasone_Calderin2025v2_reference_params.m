function p = Dexamethasone_Calderin2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexamethasone   source: Calderin_2025_2 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Dexamethasone_Calderin2025v2_reference_params';
  p.drug  = 'dexamethasone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26.6;                % central volume [L]
  p.CL = 131.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.29;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
