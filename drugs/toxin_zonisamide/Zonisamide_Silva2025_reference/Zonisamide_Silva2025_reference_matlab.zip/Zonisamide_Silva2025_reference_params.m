function p = Zonisamide_Silva2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zonisamide   source: Silva_2025 / reference   route: oral
  p.name  = 'Zonisamide_Silva2025_reference_params';
  p.drug  = 'zonisamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.1;                % central volume [L]
  p.CL = 0.761;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.671;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
