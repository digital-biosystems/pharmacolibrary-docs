model Zonisamide_Silva2025_reference
  parameter Real Cl_ref = 2.113888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.048100000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21222300000000002,
    adminMass = 0.0002,
    ka = 0.0001863888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zonisamide</td></tr><tr><td>population:</td><td>patients with refractory epilepsy</td></tr><tr><td>source_paper:</td><td>Silva_2025</td></tr><tr><td>measured_compound:</td><td>Zonisamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zonisamide 212.223 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'BPV associated with CL/F' — extend the ontology if this is a real PK parameter (source ['Silva_2025:abstract'])</li><li>routed 'BPV associated with Vd/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q49 ('BPV associated with ka', value 91.27) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Zonisamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Zonisamide_Silva2025_reference;
