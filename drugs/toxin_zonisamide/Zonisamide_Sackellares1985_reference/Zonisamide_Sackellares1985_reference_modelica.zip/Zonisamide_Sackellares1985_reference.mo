model Zonisamide_Sackellares1985_reference
  parameter Real Cl_ref = 6.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0889 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21222300000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zonisamide</td></tr><tr><td>population:</td><td>adults with medically refractory partial seizures</td></tr><tr><td>source_paper:</td><td>Sackellares_1985</td></tr><tr><td>measured_compound:</td><td>Zonisamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zonisamide 212.223 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h after dosing' (tmax)</li><li>implicit units: 'peak plasma levels occurred an average of' → h (from the popPK convention: 'No units are stated in the text or table footnotes. Tmax (time to maximum concentration) is a time parameter, and the mo')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zonisamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Mula_2013's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Mula_2013 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Zonisamide_Sackellares1985_reference;
