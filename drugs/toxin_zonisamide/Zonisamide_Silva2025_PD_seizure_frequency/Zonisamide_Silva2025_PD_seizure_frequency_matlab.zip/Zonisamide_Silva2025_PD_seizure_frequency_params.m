function p = Zonisamide_Silva2025_PD_seizure_frequency_params()
% Zonisamide_Silva2025_PD_seizure_frequency_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zonisamide Silva_2025::Seizure_frequency: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response Seizure frequency in its own unit. Driver: zonisamide (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 12.900000000000002;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
