model Zonisamide_Silva2025_PD_seizure_frequency
  "linear exposure-response sweep — Silva_2025 :: Seizure frequency (Seizure frequency)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 12.9,  // [meter ** 3 / kilogram; mL/µg × 1000]
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Zonisamide_Silva2025_PD_seizure_frequency</h4><p>The steady-state exposure-response curve of Silva R et al., <i>European journal of pharmaceutical sciences : official journal of the European Federation for Pharmaceutical Sciences 207:107023</i> 2025 (<a href=\"https://doi.org/10.1016/j.ejps.2025.107023\">doi:10.1016/j.ejps.2025.107023</a>) — Seizure frequency against zonisamide µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0129 mL/µg    change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of zonisamide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Zonisamide_Silva2025_PD_seizure_frequency;
