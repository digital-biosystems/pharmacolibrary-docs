model Zonisamide_Qiu2016_reference
  parameter Real Cl_ref = 6.458333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0345 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21222300000000002,
    adminMass = 0.0002,
    ka = 7.222222222222222e-06,
    Tlag = 0.0,
    k12 = 0.00016280193236714973,
    k21 = 3.930487520410544e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zonisamide</td></tr><tr><td>population:</td><td>healthy Chinese volunteers</td></tr><tr><td>source_paper:</td><td>Qiu_2016</td></tr><tr><td>measured_compound:</td><td>Zonisamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zonisamide 212.223 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (clearance (CL)); Q63 (volume of distribution of the central compartment (Vc)); Q30 (intercompartmental clearance (Q)); Q64 (peripheral volume of distribution (Vp))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zonisamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Zonisamide_Qiu2016_reference;
