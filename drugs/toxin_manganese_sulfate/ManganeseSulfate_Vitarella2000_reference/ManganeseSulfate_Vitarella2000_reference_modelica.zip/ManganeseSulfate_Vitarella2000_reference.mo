// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ManganeseSulfate_Vitarella2000_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {43200.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>manganese_sulfate</td></tr><tr><td>population:</td><td>Adult CD rats</td></tr><tr><td>source_paper:</td><td>Vitarella_2000</td></tr><tr><td>measured_compound:</td><td>Manganese</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>manganese_sulfate 150.994 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'The dissolution rate constant of the Mn compounds ... in Hatch artificial lung lining fluid than in Gamble lung simulant fluid' — extend the ontology if this is a real PK parameter (source ['Vitarella_2000:abstract'])</li><li>dropped unlinked row (NIL): 'The dissolution rate constant of the water-soluble MnSO(4) particles in Hatch artificial lung fluid containing protein' — extend the ontology if this is a real PK parameter (source ['Vitarella_2000:abstract'])</li><li>dropped unlinked row (NIL): 'The dissolution rate constants for these compounds ... in Gamble lung fluid simulant' — extend the ontology if this is a real PK parameter (source ['Vitarella_2000:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Manganese</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none of 1 PubChem candidate(s) is 'Manganese' (LLM) — left in mass units</li><li>molar mass: none found for 'Manganese' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end ManganeseSulfate_Vitarella2000_reference;
