model Ramucirumab_Marachelian2016_reference
  parameter Real Cl_ref = 7.905092592592593e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4e-05,
    k12 = 6.207912457912458e-06,
    k21 = 2.2531255875164506e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ramucirumab</h4><p>Ramucirumab is a monoclonal antibody used as an anticancer treatment for tumours such as gastric, lung, and colon cancer. It is an approved medicine, with products authorised in the European Union, and is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7290345\">Wikidata Q7290345</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ramucirumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Marachelian_2016</td></tr><tr><td>measured_compound:</td><td>ramucirumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Marachelian_2016) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Ramucirumab_Marachelian2016_reference;
