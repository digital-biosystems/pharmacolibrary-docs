function p = Ramucirumab_Marachelian2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ramucirumab   source: Marachelian_2016 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ramucirumab_Marachelian2016_reference_params';
  p.drug  = 'ramucirumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.43;                % central volume [L]
  p.CL = 0.028458;                % clearance [L/h]
  p.Vp = [3.94];             % peripheral volumes [L]
  p.Q  = [0.031958];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
