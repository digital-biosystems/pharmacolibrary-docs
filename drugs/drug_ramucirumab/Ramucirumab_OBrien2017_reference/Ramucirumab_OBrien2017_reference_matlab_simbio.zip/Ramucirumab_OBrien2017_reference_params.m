function p = Ramucirumab_OBrien2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ramucirumab   source: OBrien_2017 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ramucirumab_OBrien2017_reference_params';
  p.drug  = 'ramucirumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.26;                % central volume [L]
  p.CL = 0.0148;                % clearance [L/h]
  p.Vp = [2.04];             % peripheral volumes [L]
  p.Q  = [0.0102];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 560.0;             % dose [mg]
end
