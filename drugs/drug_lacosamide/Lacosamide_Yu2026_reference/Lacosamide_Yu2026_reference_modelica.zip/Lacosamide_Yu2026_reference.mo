model Lacosamide_Yu2026_reference
  parameter Real Cl_ref = 5.166666666666667e-07 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real cov_crcl_1 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.041999999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.875)*cov_sex_0)*(1 + (0.311)*cov_crcl_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0017972222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lacosamide</td></tr><tr><td>population:</td><td>adult patients with epilepsy</td></tr><tr><td>source_paper:</td><td>Yu_2026</td></tr><tr><td>measured_compound:</td><td>lacosamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CBZ on CL/F' — extend the ontology if this is a real PK parameter (source ['Tab2:row5:col1', 'Tab2:row5:col2', 'Tab2:row5:col3', 'Tab2:row5:col4'])</li><li>covariate level 'SEX on CL/F' → Q900:sex_on_cl_f = 0.875 (linear_fractional on Q27)</li><li>covariate level 'CRCL on CL/F' → Q900:crcl_on_cl_f = 0.311 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'ω CL' — extend the ontology if this is a real PK parameter (source ['Tab2:row9:col1', 'Tab2:row9:col2', 'Tab2:row9:col3', 'Tab2:row9:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lacosamide</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lacosamide_Yu2026_reference;
