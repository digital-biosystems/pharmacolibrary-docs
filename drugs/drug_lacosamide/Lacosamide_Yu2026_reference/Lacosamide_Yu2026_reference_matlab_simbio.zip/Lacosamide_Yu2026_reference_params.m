function p = Lacosamide_Yu2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lacosamide   source: Yu_2026 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Lacosamide_Yu2026_reference_params';
  p.drug  = 'lacosamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.0;                % central volume [L]
  p.CL = 1.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.47;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
