model Lacosamide_Li2025_boostrap
  parameter Real Cl_ref = 4.1944444444444446e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.023600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lacosamide</td></tr><tr><td>population:</td><td>children with epilepsy</td></tr><tr><td>source_paper:</td><td>Li_2025</td></tr><tr><td>measured_compound:</td><td>lacosamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CL-rs12769205*GA' — extend the ontology if this is a real PK parameter (source ['Tab2:row20:col3', 'Tab2:row20:col5'])</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lacosamide</li><li>population split: 'boostrap' subgroup of Li_2025 (paper reports 2 populations: boostrap, final models)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lacosamide_Li2025_boostrap;
