function p = Lacosamide_Li2025_boostrap_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lacosamide   source: Li_2025 / boostrap   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Lacosamide_Li2025_boostrap_params';
  p.drug  = 'lacosamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 23.6;                % central volume [L]
  p.CL = 1.51;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
