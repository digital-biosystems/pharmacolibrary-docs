function p = InsulinHuman_Potocka2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: insulin_human   source: Potocka_2011 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'InsulinHuman_Potocka2011_reference_params';
  p.drug  = 'insulin_human';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.0;                % central volume [L]
  p.CL = 43.4;                % clearance [L/h]
  p.Vp = [30.7];             % peripheral volumes [L]
  p.Q  = [23.9];             % inter-compartmental clearances [L/h]
  p.ka = 2.35;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
