function p = EtirinotecanPegol_Sy2018_population_parameter_estimate_se_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: etirinotecan_pegol   source: Sy_2018 / population_parameter_estimate_se   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'EtirinotecanPegol_Sy2018_population_parameter_estimate_se_params';
  p.drug  = 'etirinotecan_pegol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.05;                % central volume [L]
  p.CL = 0.237;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
