% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = EtirinotecanPegol_Sy2018_population_parameter_estimate_se_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
