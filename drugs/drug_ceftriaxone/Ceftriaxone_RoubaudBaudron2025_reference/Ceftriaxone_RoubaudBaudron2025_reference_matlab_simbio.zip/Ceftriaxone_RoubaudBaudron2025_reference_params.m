function p = Ceftriaxone_RoubaudBaudron2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ceftriaxone   source: Roubaud-Baudron_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ceftriaxone_RoubaudBaudron2025_reference_params';
  p.drug  = 'ceftriaxone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.13;                % central volume [L]
  p.CL = 0.35;                % clearance [L/h]
  p.Vp = [8.29];             % peripheral volumes [L]
  p.Q  = [9.14];             % inter-compartmental clearances [L/h]
  p.ka = 1.63;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
