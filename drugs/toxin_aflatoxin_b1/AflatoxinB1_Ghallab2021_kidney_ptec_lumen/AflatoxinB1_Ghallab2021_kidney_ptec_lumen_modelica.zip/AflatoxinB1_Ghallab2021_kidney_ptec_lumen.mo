// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model AflatoxinB1_Ghallab2021_kidney_ptec_lumen
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {24.0},
    MM = 0.31227,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aflatoxin_b1</td></tr><tr><td>population:</td><td>anesthetized mice</td></tr><tr><td>source_paper:</td><td>Ghallab_2021</td></tr><tr><td>measured_compound:</td><td>Aflatoxin B1</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Aflatoxin B1 312.27 g/mol (pubchem); aflatoxin_b1 312.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'AFB1 (1.5 mg/kg)' — extend the ontology if this is a real PK parameter (source ['Tab3:row5:col3'])</li><li>dropped value-less row: 'ND'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Aflatoxin B1</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'kidney / ptec-lumen' subgroup of Ghallab_2021 (paper reports 5 populations: kidney / dtec -lumen, kidney / dtec-cells, kidney / mycotoxin, kidney / ptec-cells, kidney / ptec-lumen)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end AflatoxinB1_Ghallab2021_kidney_ptec_lumen;
