function p = Amoxicillin_Fournier2018_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Fournier_2018 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Fournier2018_base_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.1;                % central volume [L]
  p.CL = 13.1;                % clearance [L/h]
  p.Vp = [16.6];             % peripheral volumes [L]
  p.Q  = [20.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
