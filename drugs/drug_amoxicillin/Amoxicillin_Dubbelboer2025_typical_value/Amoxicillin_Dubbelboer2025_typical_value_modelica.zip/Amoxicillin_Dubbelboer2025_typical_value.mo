model Amoxicillin_Dubbelboer2025_typical_value
  parameter Real Cl_ref = 3.5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0084 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0007,
    ka = 8.61111111111111e-05,
    Tlag = 900.0,
    k12 = 0.000902777777777778,
    k21 = 0.001177536231884058
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>healthy cats</td></tr><tr><td>source_paper:</td><td>Dubbelboer_2025</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp70003-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q 2', value '0.009') — already have one for this compound</li><li>dropped duplicate Q83 ('T lagsc', value '0.06') — already have one for this compound</li><li>dropped unlinked row (NIL): 'k apo' — extend the ontology if this is a real PK parameter (source ['jvp70003-tbl-0002:row10:col2'])</li><li>dropped unlinked row (NIL): 'K apo_covariate sex “male”' — extend the ontology if this is a real PK parameter (source ['jvp70003-tbl-0002:row11:col2'])</li><li>dropped unlinked row (NIL): 'F sc' — extend the ontology if this is a real PK parameter (source ['jvp70003-tbl-0002:row14:col2'])</li><li>implicit units: 'V 1' → L/kg (from the paper text: &quot;The abstract states: 'the volume of the central compartment was 0.12 L/kg'.&quot;)</li><li>implicit units: 'V 2' → L/kg (from the paper text: &quot;The abstract states: 'the highly perfused compartment was 0.009 L/kg' (referring to the peripheral compartment volume in&quot;)</li><li>implicit units: 'V 3' → L/kg (from the paper text: &quot;The abstract states: 'the poorly perfused compartment was 0.002 L/kg' (referring to the second peripheral compartment vo&quot;)</li><li>implicit units: 'Cl' → L/h/kg (from the paper text: &quot;The abstract states: 'The population clearance was 0.18 L/h∙kg'.&quot;)</li><li>implicit units: 'Q 1' → L/h/kg (from the popPK convention: 'Intercompartmental clearances (Q) are typically expressed in the same units as total clearance. Since the study normaliz')</li><li>implicit units: 'T lagpo' → h (from the popPK convention: &quot;Lag time (Tlag) is a time parameter, and the standard unit in pharmacokinetics is hours (h). The text mentions 'time 0 h&quot;)</li><li>implicit units: 'K asc' → 1/h (from the paper text: &quot;The text states: 'Without the use of the covariate “sex” the population value for k apo was 0.34 1/h.' This establishes &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'typical value' subgroup of Dubbelboer_2025 (paper reports 8 populations: cat 1, cat 2, cat 3, cat 4, cat 5, cat 6, median, typical value)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Dubbelboer2025_typical_value;
