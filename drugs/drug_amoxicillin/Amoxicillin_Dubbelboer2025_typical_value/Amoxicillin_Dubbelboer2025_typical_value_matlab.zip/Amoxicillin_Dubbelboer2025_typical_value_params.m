function p = Amoxicillin_Dubbelboer2025_typical_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Dubbelboer_2025 / typical_value   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Amoxicillin_Dubbelboer2025_typical_value_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.4;                % central volume [L]
  p.CL = 12.6;                % clearance [L/h]
  p.Vp = [6.44];             % peripheral volumes [L]
  p.Q  = [27.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.31;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
