function p = Amoxicillin_Muller2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Muller_2009 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Muller2009_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.4;                % central volume [L]
  p.CL = 19.7;                % clearance [L/h]
  p.Vp = [5.88];             % peripheral volumes [L]
  p.Q  = [56.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.125;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
