model Amoxicillin_Muller2009_reference
  parameter Real Cl_ref = 5.472222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0064 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.001,
    ka = 4.722222222222223e-05,
    Tlag = 450.0,
    k12 = 0.0024565972222222224,
    k21 = 0.00267384731670446
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>pregnant women and neonates</td></tr><tr><td>source_paper:</td><td>Muller_2009</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>'Q₂ (liters/h)' linked to Q99: a second intercompartmental clearance beside the Q30 already present</li><li>dropped duplicate Q348 ('k₄₈', value '5.1') — already have one for this compound</li><li>routed 'Intersubject variability in CL' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Intersubject variability in V₁' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>implicit units: 'k₁₄' → 1/h (from the popPK convention: &quot;The parameter is described as a 'First-order transfer rate constant'. Standard units for first-order rate constants in p&quot;)</li><li>implicit units: 'k₄₁' → 1/h (from the popPK convention: &quot;The parameter is described as a 'First-order transfer rate constant'. Standard units for first-order rate constants in p&quot;)</li><li>implicit units: 'k₅₄' → 1/h (from the popPK convention: &quot;The parameter is described as a 'Micro-rate constants governing drug distribution'. In population PK modeling, micro-rat&quot;)</li><li>implicit units: 'k₅₀' → 1/h (from the popPK convention: &quot;The parameter is described as a 'First-order elimination rate constant'. Standard units for first-order rate constants i&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>gap-filled Q49 (kabs) from Baklouti_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Franck_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Muller2009_reference;
