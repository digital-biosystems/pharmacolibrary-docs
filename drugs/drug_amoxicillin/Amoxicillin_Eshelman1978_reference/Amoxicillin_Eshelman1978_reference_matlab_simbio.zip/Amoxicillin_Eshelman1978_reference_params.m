function p = Amoxicillin_Eshelman1978_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Eshelman_1978 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Amoxicillin_Eshelman1978_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 121.1;                % central volume [L]
  p.CL = 12.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
