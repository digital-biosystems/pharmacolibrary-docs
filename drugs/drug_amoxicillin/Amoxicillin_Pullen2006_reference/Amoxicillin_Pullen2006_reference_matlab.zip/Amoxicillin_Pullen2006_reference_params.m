function p = Amoxicillin_Pullen2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Pullen_2006 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Pullen2006_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 45.5;                % central volume [L]
  p.CL = 6.72;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 280.0;             % dose [mg]
end
