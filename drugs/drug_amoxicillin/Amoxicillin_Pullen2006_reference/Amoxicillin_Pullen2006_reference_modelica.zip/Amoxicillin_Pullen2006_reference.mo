model Amoxicillin_Pullen2006_reference
  parameter Real Cl_ref = 1.8666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045500000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.00028,
    ka = 4.722222222222223e-05,
    Tlag = 450.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>(pre)term neonates</td></tr><tr><td>source_paper:</td><td>Pullen_2006</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>column 'cl' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'PNA' — extend the ontology if this is a real PK parameter (source ['Pullen_2006_table_2:row8:col2'])</li><li>salvaged Q22 ('Mean total body clearance of amoxicillin corrected for body weight (CL/W)'=0.096) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('mean volume of distribution of amoxicillin corrected for body weight (V/W)'=0.65) from results prose — parameter table was unreadable</li><li>implicit units: 'Mean total body clearance of amoxicillin corrected for body weight (CL/W)' → L/kg/h (from the paper text: 'The text in the Abstract and Results sections explicitly states: &quot;Mean total body clearance corrected for body weight (C')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Baklouti_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Franck_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Pullen2006_reference;
