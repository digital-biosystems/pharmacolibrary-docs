function p = Amoxicillin_Vegas2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Vegas_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Vegas2021_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.11;                % central volume [L]
  p.CL = 23.52;                % clearance [L/h]
  p.Vp = [12.18];             % peripheral volumes [L]
  p.Q  = [60.27];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.125;             % absorption lag [h]
  p.dose = 1400.0;             % dose [mg]
end
