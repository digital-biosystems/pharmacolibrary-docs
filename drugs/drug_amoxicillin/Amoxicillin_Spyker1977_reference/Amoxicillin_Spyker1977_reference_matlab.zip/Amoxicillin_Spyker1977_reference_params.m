function p = Amoxicillin_Spyker1977_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Spyker_1977 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Amoxicillin_Spyker1977_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 30.8;                % central volume [L]
  p.CL = 23.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
