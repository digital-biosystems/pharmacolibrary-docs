function p = Amoxicillin_Isla2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Isla_2011 / reference   route: oral
  p.name  = 'Amoxicillin_Isla2011_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 100.8;                % central volume [L]
  p.CL = 0.556;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.77;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
