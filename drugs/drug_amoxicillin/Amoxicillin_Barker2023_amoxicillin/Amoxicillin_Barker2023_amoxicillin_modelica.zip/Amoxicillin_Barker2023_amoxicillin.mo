model Amoxicillin_Barker2023_amoxicillin
  parameter Real Cl_ref = 4.555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.046200000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0015,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 4.112554112554112e-05,
    k21 = 0.00013571428571428572
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>neonates and paediatric patients</td></tr><tr><td>source_paper:</td><td>Barker_2023</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkad196-T6</td></tr><tr><td>input:</td><td>PK_3C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k13, k31.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'TVCL'; source reconciliation required</li><li>table representations disagree for 'TVV'; source reconciliation required</li><li>table representations disagree for 'Var IIV (1)'; source reconciliation required</li><li>table representations disagree for 'Var IIV (2)'; source reconciliation required</li><li>table representations disagree for 'Var prop RE'; source reconciliation required</li><li>table representations disagree for 'T50'; source reconciliation required</li><li>table representations disagree for 'Hill'; source reconciliation required</li><li>table representations disagree for 'M'; source reconciliation required</li><li>table representations disagree for 'Creat on CL'; source reconciliation required</li><li>routed 'Var prop RE' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['dkad196-T6:row10:col1', 'dkad196-T6:row10:col2', 'dkad196-T6:row10:col3', 'Barker_2023_table_S4:row10:col1'])</li><li>dropped unlinked row (NIL): 'M' — extend the ontology if this is a real PK parameter (source ['dkad196-T6:row11:col1', 'dkad196-T6:row11:col2', 'dkad196-T6:row11:col3'])</li><li>dropped duplicate Q22 ('Creat on CL', value '-0.302') — already have one for this compound</li><li>implicit units: 'TVCL' → L/h (from the popPK convention: 'Total clearance (CL) in population PK models is conventionally expressed in L/h, consistent with the value magnitude for')</li><li>implicit units: 'TVV' → L (from the popPK convention: 'Volume of distribution (V) in population PK models is conventionally expressed in L, consistent with the value magnitude')</li><li>implicit units: 'T50' → h (from the popPK convention: 'tmax (time to maximum concentration) is a time parameter, conventionally expressed in hours.')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Barker2023_amoxicillin;
