function p = Amoxicillin_Barker2023_amoxicillin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Barker_2023 / amoxicillin   route: oral
  % estimated (absent from source): ka
  p.name  = 'Amoxicillin_Barker2023_amoxicillin_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.2;                % central volume [L]
  p.CL = 16.4;                % clearance [L/h]
  p.Vp = [14.0];             % peripheral volumes [L]
  p.Q  = [6.84];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
