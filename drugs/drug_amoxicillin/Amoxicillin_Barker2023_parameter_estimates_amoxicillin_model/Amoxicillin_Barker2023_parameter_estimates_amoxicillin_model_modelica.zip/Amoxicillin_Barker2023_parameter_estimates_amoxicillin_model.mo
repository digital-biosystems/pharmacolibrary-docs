model Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model
  parameter Real Cl_ref = 4.555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.046200000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.003
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>neonates and paediatric patients</td></tr><tr><td>source_paper:</td><td>Barker_2023</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkad196-T6</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'T50' — extend the ontology if this is a real PK parameter (source ['Barker_2023_table_7:row3:col2'])</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Barker_2023_table_7:row4:col2'])</li><li>dropped unlinked row (NIL): 'M' — extend the ontology if this is a real PK parameter (source ['Barker_2023_table_7:row5:col2'])</li><li>dropped duplicate Q22 ('Creat on CL', value '-0.302') — already have one for this compound</li><li>implicit units: 'TVCL' → L/h (from the popPK convention: 'Total clearance (TVCL) in population PK models is conventionally expressed in L/h, and the magnitude (16.4) is consisten')</li><li>implicit units: 'TVV' → L (from the popPK convention: 'Volume of distribution (TVV) in population PK models is conventionally expressed in L, and the magnitude (46.2) is consi')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>population split: 'parameter estimates / amoxicillin model' subgroup of Barker_2023 (paper reports 12 populations: abdose (icu age 0.008–85)y), amoxicillin, benzylpenicillin, neonates/infants(age 1 – 37 d,ga 28–41 wk), nicu (age 2 to 5 d,ga 36 – 42 wk), parameter estimates / amoxicillin model, parameter estimates / flucloxacillin model, picu (age 1m to 15y), preterm and term infants (aged 10 to 52 days), preterm and term neonates (25-42 wks ga), this study: nappa (aged 1 – 5711 weeks), vlbw neonates (<32 wks, <1500g))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model;
