function p = Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Barker_2023 / parameter_estimates_amoxicillin_model   route: oral
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.2;                % central volume [L]
  p.CL = 16.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.125;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
