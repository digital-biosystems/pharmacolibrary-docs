function p = Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Barker_2023 / parameter_estimates_amoxicillin_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 46.2;                % central volume [L]
  p.CL = 16.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
