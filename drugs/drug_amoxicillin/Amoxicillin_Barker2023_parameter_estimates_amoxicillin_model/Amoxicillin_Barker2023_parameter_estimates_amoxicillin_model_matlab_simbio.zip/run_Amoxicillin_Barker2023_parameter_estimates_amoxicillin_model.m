% Run (SimBiology): build model + dose, simulate 0..28.0 h, plot.
p = Amoxicillin_Barker2023_parameter_estimates_amoxicillin_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 28.0);
