function p = Amoxicillin_Abulfathi2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Abulfathi_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Abulfathi2021_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 14.2;                % central volume [L]
  p.CL = 11.8;                % clearance [L/h]
  p.Vp = [3.12];             % peripheral volumes [L]
  p.Q  = [3.26];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
