model Amoxicillin_Dubbelboer2025_cat_2
  parameter Real Cl_ref = 3.3055555555555558e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0385 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0001,
    ka = 4.722222222222223e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>healthy cats</td></tr><tr><td>source_paper:</td><td>Dubbelboer_2025</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp70003-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('C max SC', value '10.4') — already have one for this compound</li><li>dropped duplicate Q56 ('T maxSC', value '3') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0‐ꚙPO', value '24.7') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0‐ꚙSC', value '63.0') — already have one for this compound</li><li>dropped duplicate Q47 ('k ePO', value '0.26') — already have one for this compound</li><li>dropped duplicate Q47 ('k eSC', value '0.31') — already have one for this compound</li><li>dropped duplicate Q57 ('t 1/2zPO', value '2.7') — already have one for this compound</li><li>dropped duplicate Q57 ('t 1/2zSC', value '2.3') — already have one for this compound</li><li>implicit units: 'Cl' → L/h/kg (from the paper text: &quot;The paper text states: 'the calculated Cl (present: 0.17 L/kg∙h...)' and the abstract states 'The population clearance w&quot;)</li><li>implicit units: 'V d' → L/kg (from the paper text: &quot;The paper text states: 'and V d (present: 0.36 L/kg...)' and the abstract states 'the volume of the central compartment &quot;)</li><li>implicit units: 'C maxPO' → mg/L (from the popPK convention: &quot;The paper does not explicitly state the unit for Cmax in the text or table footnotes. However, the text reports AUC in '&quot;)</li><li>implicit units: 'T maxPO' → h (from the popPK convention: 'The paper does not explicitly state the unit for Tmax in the text or table footnotes. Tmax is a time parameter, and the ')</li><li>implicit units: 'AUC0‐ꚙIV' → mg*h/L (from the paper text: &quot;The paper text states: 'leading to a roughly 2‐fold higher IV AUCIV (57.6 mg∙h/L vs. 23.87 mg∙h/L)'.&quot;)</li><li>implicit units: 'k eIV' → 1/h (from the paper text: &quot;The paper text states: 'Without the use of the covariate “sex” the population value for k apo was 0.34 1/h.' While this &quot;)</li><li>implicit units: 't 1/2zIV' → h (from the popPK convention: 'The paper does not explicitly state the unit for t1/2z in the text or table footnotes. Half-life is a time parameter, an')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Dubbelboer2025_cat_2;
