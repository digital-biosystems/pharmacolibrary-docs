model Amoxicillin_Li1994_PD_k
  "emax exposure-response sweep — Li_1994 :: K' (bactericidal rate constant)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.001525,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.00295,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 30, Interval = 0.06),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amoxicillin_Li1994_PD_k</h4><p>The steady-state exposure-response curve of Li RC et al., <i>Journal of pharmaceutical sciences 83(7):970–975</i> 1994 (<a href=\"https://doi.org/10.1002/jps.2600830711\">doi:10.1002/jps.2600830711</a>) — bactericidal rate constant [h-1] against amoxicillin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       5.49 h-1      maximal effect term (K'max, Q323)
  EC50  =       2.95 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of amoxicillin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.95 mg/L)  response -0.0007625
  exposure -> infinity  response -0.001525</pre></body></html>"));
end Amoxicillin_Li1994_PD_k;
