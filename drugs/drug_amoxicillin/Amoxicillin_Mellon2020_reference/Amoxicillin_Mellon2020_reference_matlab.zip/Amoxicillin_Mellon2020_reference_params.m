function p = Amoxicillin_Mellon2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Mellon_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Mellon2020_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9.0;                % central volume [L]
  p.CL = 14.6;                % clearance [L/h]
  p.Vp = [6.4];             % peripheral volumes [L]
  p.Q  = [4.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
