model Amoxicillin_Cattrall2019_reference
  parameter Real Cl_ref = 5.916666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0277 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0005277777777777777,
    Tlag = 0.0,
    k12 = 1.704773365423185e-05,
    k21 = 0.00015636497424576895
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cattrall_2019</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cattrall_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Cattrall2019_reference;
