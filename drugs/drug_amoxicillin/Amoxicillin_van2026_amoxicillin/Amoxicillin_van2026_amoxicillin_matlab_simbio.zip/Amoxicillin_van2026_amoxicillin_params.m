function p = Amoxicillin_van2026_amoxicillin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: van_2026 / amoxicillin   route: oral
  p.name  = 'Amoxicillin_van2026_amoxicillin_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.0;                % central volume [L]
  p.CL = 11.8;                % clearance [L/h]
  p.Vp = [3.73];             % peripheral volumes [L]
  p.Q  = [0.743];             % inter-compartmental clearances [L/h]
  p.ka = 0.963;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
