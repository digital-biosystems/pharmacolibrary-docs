model Amoxicillin_van2026_amoxicillin
  parameter Real Cl_ref = 3.277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0015,
    ka = 0.0002675,
    Tlag = 0.0,
    k12 = 1.4742063492063492e-05,
    k21 = 5.53321417932678e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>children with severe community-acquired pneumonia</td></tr><tr><td>source_paper:</td><td>van_2026</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Clearance' routed out of structural estimates ('Between-subject variability (%CV) d')</li><li>table section iov: 'Bioavailability, F' routed out of structural estimates ('Between-occasion variability (%CV) d')</li><li>table section iov: 'Bioavailability correlation c' routed out of structural estimates ('Between-occasion variability (%CV) d')</li><li>table section iov: 'First-order absorption, ka' routed out of structural estimates ('Between-occasion variability (%CV) d')</li><li>table section iov: 'First-order absorption correlation c' routed out of structural estimates ('Between-occasion variability (%CV) d')</li><li>table section iov: 'Zero-order input' routed out of structural estimates ('Between-occasion variability (%CV) d')</li><li>table section iov: 'Zero-order input correlation c' routed out of structural estimates ('Between-occasion variability (%CV) d')</li><li>dropped unlinked row (NIL): 'Zero-order input (h)' — extend the ontology if this is a real PK parameter (source ['van_2026_table_p27_1:row5:col1'])</li><li>dropped PD-category row 'Hill coefficient, Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['van_2026_table_p27_1:row14:col1'])</li><li>dropped unlinked row (NIL): 'Postmenstrual age at 50% maturation, PMA50 (week)' — extend the ontology if this is a real PK parameter (source ['van_2026_table_p27_1:row15:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amoxicillin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'amoxicillin' subgroup of van_2026 (paper reports 3 populations: amoxicillin, clavulanate, formulation (amoxicillin:clavulanate) 7:1)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_van2026_amoxicillin;
