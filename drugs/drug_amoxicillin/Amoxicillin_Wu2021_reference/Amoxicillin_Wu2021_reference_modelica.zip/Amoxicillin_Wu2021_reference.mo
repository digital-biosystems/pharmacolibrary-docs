model Amoxicillin_Wu2021_reference
  parameter Real Cl_ref = 6.055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00223 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0015,
    ka = 4.722222222222223e-05,
    Tlag = 0.0,
    k12 = 8.881415047334329e-05,
    k21 = 8.72491434165443e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>Chinese infants</td></tr><tr><td>source_paper:</td><td>Wu_2021</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V₂' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'Residual variability (%)' routed out of structural estimates ('Interindividual variability (%)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>model equation 'Fweight = (CW/7)^0.5
θ5' not bound — neither LHS nor base term 'CW' linked to an ontology parameter</li><li>gap-filled Q49 (kabs) from Baklouti_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Wu2021_reference;
