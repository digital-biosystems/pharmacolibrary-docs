model Amoxicillin_Bijleveld2018_final
  parameter Real Cl_ref = 8.416666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0274 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.00175
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>term neonates undergoing moderate hypothermia</td></tr><tr><td>source_paper:</td><td>Bijleveld_2018</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('θ_CL_PNA', value '0.20') — already have one for this compound</li><li>dropped unlinked row (NIL): 'θ_CL_TEMP' — extend the ontology if this is a real PK parameter (source ['Bijleveld_2018_table_2:row3:col1'])</li><li>dropped duplicate Q22 ('θ_CL_URINE OUTPUT', value '0.11') — already have one for this compound</li><li>dropped duplicate Q22 ('θ_CL_GA', value '5.12') — already have one for this compound</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['tab_0:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc (L/70 kg)' is the general volume)</li><li>model-stage split: 'model-building dataset (n=80) final model estimates' is the final model of Bijleveld_2018 (paper reports 2 stages: model-building dataset (n=80) final model estimates, total dataset (n=125) final model estimates); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Bijleveld2018_final;
