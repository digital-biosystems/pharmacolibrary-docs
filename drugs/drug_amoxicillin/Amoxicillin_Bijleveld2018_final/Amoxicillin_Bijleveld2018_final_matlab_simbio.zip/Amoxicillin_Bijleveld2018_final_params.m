function p = Amoxicillin_Bijleveld2018_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Bijleveld_2018 / final   route: oral
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Bijleveld2018_final_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.4;                % central volume [L]
  p.CL = 3.03;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.125;             % absorption lag [h]
  p.dose = 1750.0;             % dose [mg]
end
