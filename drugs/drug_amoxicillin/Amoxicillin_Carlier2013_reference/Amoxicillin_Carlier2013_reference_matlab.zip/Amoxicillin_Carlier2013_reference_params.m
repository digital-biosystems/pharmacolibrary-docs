function p = Amoxicillin_Carlier2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Carlier_2013 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Carlier2013_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.5;                % central volume [L]
  p.CL = 10.3;                % clearance [L/h]
  p.Vp = [14.1];             % peripheral volumes [L]
  p.Q  = [15.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
