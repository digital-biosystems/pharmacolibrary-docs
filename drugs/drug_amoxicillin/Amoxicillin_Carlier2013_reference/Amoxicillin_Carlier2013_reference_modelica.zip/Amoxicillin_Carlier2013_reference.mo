model Amoxicillin_Carlier2013_reference
  parameter Real Cl_ref = 2.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0135 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.001,
    ka = 4.722222222222223e-05,
    Tlag = 450.0,
    k12 = 0.0003230452674897119,
    k21 = 0.0003092986603624902
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>critically ill patients</td></tr><tr><td>source_paper:</td><td>Carlier_2013</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('Random-effects BSV (% CV)')</li><li>table section iiv: 'V c (L)' routed out of structural estimates ('Random-effects BSV (% CV)')</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'V c (L)'; source reconciliation required</li><li>table representations disagree for 'V p (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>table representations disagree for 'RUV (% CV)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q49 (kabs) from Baklouti_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Franck_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Carlier2013_reference;
