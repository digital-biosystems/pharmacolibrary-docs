function p = Amoxicillin_Li1994_PD_n_params()
% Amoxicillin_Li1994_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amoxicillin Li_1994::N: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response N in cfu/mL. Driver: amoxicillin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -1.48;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
