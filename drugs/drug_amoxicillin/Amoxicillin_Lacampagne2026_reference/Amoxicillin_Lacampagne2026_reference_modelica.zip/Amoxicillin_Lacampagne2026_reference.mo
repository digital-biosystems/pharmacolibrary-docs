model Amoxicillin_Lacampagne2026_reference
  parameter Real Cl_ref = 1.536111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 25.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0015,
    ka = 0.00011388888888888888,
    Tlag = 0.0,
    k12 = 0.0005952380952380951,
    k21 = 0.000980392156862745
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>post-weaning piglets</td></tr><tr><td>source_paper:</td><td>Lacampagne_2026</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>implicit units: 'Cl' → L/h/kg (from the paper text: &quot;The text states: 'The clearance estimated in our study (0.79 ± 0.07 L/h·kg) was of the same order of magnitude...'&quot;)</li><li>implicit units: 'Q' → L/h/kg (from the popPK convention: 'The paper reports clearance (Cl) in L/h/kg. Inter-compartmental clearance (Q) is a clearance parameter and is typically ')</li><li>implicit units: 'V1' → L/kg (from the popPK convention: 'The paper reports clearance in L/h/kg, implying weight-normalized parameters. Volume of distribution (V1) is a volume pa')</li><li>implicit units: 'V2' → L/kg (from the popPK convention: 'The paper reports clearance in L/h/kg, implying weight-normalized parameters. Volume of distribution (V2) is a volume pa')</li><li>implicit units: 'Ka' → 1/h (from the popPK convention: 'Ka is a first-order rate constant of absorption. The standard unit for first-order rate constants in pharmacokinetics is')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Lacampagne2026_reference;
