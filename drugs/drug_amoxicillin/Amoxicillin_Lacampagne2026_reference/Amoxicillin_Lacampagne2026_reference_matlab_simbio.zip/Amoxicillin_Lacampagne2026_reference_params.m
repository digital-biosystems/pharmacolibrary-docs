function p = Amoxicillin_Lacampagne2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Lacampagne_2026 / reference   route: oral
  p.name  = 'Amoxicillin_Lacampagne2026_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.6;                % central volume [L]
  p.CL = 55.3;                % clearance [L/h]
  p.Vp = [11.9];             % peripheral volumes [L]
  p.Q  = [42.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.41;                % absorption rate [1/h]
  p.F  = 0.25;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
