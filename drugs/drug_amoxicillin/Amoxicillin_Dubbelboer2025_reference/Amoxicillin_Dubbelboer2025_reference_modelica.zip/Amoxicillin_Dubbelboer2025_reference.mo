model Amoxicillin_Dubbelboer2025_reference
  parameter Real Cl_ref = 3.5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0084 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0007,
    ka = 0.00016666666666666666,
    Tlag = 900.0,
    k12 = 0.000902777777777778,
    k21 = 0.001177536231884058
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>healthy cats</td></tr><tr><td>source_paper:</td><td>Dubbelboer_2025</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp70003-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'V 1' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'V 2' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'V 3' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'Cl' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'T lagpo' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'T lagsc' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'k apo' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'K asc' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'F oral' routed out of structural estimates ('I.I.V. (%)')</li><li>table section iiv: 'F sc' routed out of structural estimates ('I.I.V. (%)')</li><li>'Q 2' linked to Q99: a second intercompartmental clearance beside the Q30 already present</li><li>dropped duplicate Q83 ('T lagsc', value '0.06') — already have one for this compound</li><li>covariate level 'K apo_covariate sex “male”' → Q900:theta_kabs_sex_male = -1.7 (linear_fractional on Q49)</li><li>dropped duplicate Q49 ('K asc', value '0.31') — already have one for this compound</li><li>dropped duplicate Q40 ('F sc', value '69') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Dubbelboer2025_reference;
