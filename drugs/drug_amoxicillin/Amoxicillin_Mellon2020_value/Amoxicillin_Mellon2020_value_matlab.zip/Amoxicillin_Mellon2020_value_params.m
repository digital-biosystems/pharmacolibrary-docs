function p = Amoxicillin_Mellon2020_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Mellon_2020 / value   route: oral
  p.name  = 'Amoxicillin_Mellon2020_value_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.0;                % central volume [L]
  p.CL = 14.6;                % clearance [L/h]
  p.Vp = [6.4];             % peripheral volumes [L]
  p.Q  = [4.2];             % inter-compartmental clearances [L/h]
  p.ka = 1.7;                % absorption rate [1/h]
  p.F  = 0.797;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
