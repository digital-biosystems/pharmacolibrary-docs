function p = Amoxicillin_van2026_clavulanate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: van_2026 / clavulanate   route: oral
  p.name  = 'Amoxicillin_van2026_clavulanate_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.0;                % central volume [L]
  p.CL = 6.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.6;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.37;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
