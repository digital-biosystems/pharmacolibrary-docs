model Amoxicillin_Arancibia1980_reference
  parameter Real Cl_ref = 3.6944444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 4.722222222222223e-05,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Arancibia_1980</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '(h-)' — extend the ontology if this is a real PK parameter (source ['tab_1:row1:col1'])</li><li>unit_dimension_unknown: &quot;h-'&quot; (k21)</li><li>unit_dimension_unknown: &quot;h-'&quot; (kel)</li><li>unit_dimension_unknown: &quot;h-'&quot; (k12)</li><li>dropped duplicate Q61 ('Vd ,, (liters)', value '20.2') — already have one for this compound</li><li>dropped duplicate Q61 ('Vd (liters)', value '16.7') — already have one for this compound</li><li>unit_dimension_unknown: &quot;h-'&quot; (AUC∞)</li><li>dropped unlinked row (NIL): 'Urinary recovery over' — extend the ontology if this is a real PK parameter (source ['tab_1:row13:col1'])</li><li>dropped value-less row: 'F=u (oral) x 100 (6)' (captured trailing unit '6' for child rows)</li><li>dropped value-less row: 'fu (i.v.)' (captured trailing unit 'i.v.' for child rows)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Arancibia1980_reference;
