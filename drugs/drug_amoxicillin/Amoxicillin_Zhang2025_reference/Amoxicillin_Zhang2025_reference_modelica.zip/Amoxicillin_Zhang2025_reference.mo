model Amoxicillin_Zhang2025_reference
  parameter Real Cl_ref = 2.6166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00466 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.003,
    k12 = 0.00034215546018121125,
    k21 = 0.0003138670166229221
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amoxicillin</h4><p>Amoxicillin is a penicillin antibiotic used to treat many bacterial infections, including ear, sinus, respiratory and urinary tract infections, and it is also given in combination to eradicate Helicobacter pylori. It is widely used around the world, is included on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201928\">Wikidata Q201928</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhang_2025</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Zhang2025_reference;
