model MagnesiumDifferentSaltsInCombination_Deng2024_reference
  parameter Real Cl_ref = 8.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025070000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.005
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_different_salts_in_combination</td></tr><tr><td>population:</td><td>Chinese preeclampsia population</td></tr><tr><td>source_paper:</td><td>Deng_2024</td></tr><tr><td>measured_compound:</td><td>magnesium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped diagnostic row 'dVdfurosemide' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped diagnostic row 'dCLdfurosemide' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped diagnostic row 'dCLdCCR' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>unit_dimension_unknown: 'shrinkage %' (CL)</li><li>dropped duplicate Q22 ('dCLdBMI', value '-0.54') — already have one for this compound</li><li>dropped diagnostic row 'stdev0' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=magnesium</li><li>review gap-fill skipped: this record measures 'magnesium', not magnesium_different_salts_in_combination — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end MagnesiumDifferentSaltsInCombination_Deng2024_reference;
