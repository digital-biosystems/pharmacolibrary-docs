function p = Amiodarone_Lescroart2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amiodarone   source: Lescroart_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amiodarone_Lescroart2022_reference_params';
  p.drug  = 'amiodarone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.09;                % central volume [L]
  p.CL = 0.39;                % clearance [L/h]
  p.Vp = [1.64];             % peripheral volumes [L]
  p.Q  = [0.33];             % inter-compartmental clearances [L/h]
  p.ka = 2.05;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
