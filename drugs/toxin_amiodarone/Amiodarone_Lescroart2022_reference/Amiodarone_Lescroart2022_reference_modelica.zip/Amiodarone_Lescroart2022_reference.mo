model Amiodarone_Lescroart2022_reference
  parameter Real Cl_ref = 1.0833333333333335e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00109 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6453110000000001,
    adminMass = 0.0001,
    ka = 0.0005694444444444444,
    Tlag = 0.0,
    k12 = 8.409785932721712e-05,
    k21 = 5.589430894308943e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>pigs undergoing CPR with and without VV ECMO</td></tr><tr><td>source_paper:</td><td>Lescroart_2022</td></tr><tr><td>measured_compound:</td><td>Amiodarone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00974-t003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amiodarone 645.311 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCl (%)' routed out of structural estimates ('Between subject intervariability')</li><li>table section iiv: 'ωVc (%)' routed out of structural estimates ('Between subject intervariability')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>'βECMO/Cl' is a β covariate effect on E, not Q31 (llm link set aside)</li><li>dropped unlinked row (NIL): 'βECMO/Cl' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00974-t003:row4:col1'])</li><li>'βECMO/Vc' is a β covariate effect on E, not Q22 (llm link set aside)</li><li>dropped unlinked row (NIL): 'βECMO/Vc' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00974-t003:row5:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Amiodarone</li><li>gap-filled Q49 (kabs) from Rodríguez-Fernández_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amiodarone_Lescroart2022_reference;
