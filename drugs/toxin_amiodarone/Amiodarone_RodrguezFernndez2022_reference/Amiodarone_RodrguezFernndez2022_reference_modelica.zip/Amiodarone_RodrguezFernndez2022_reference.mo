model Amiodarone_RodrguezFernndez2022_reference
  parameter Real Cl_ref = 1.4823055555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.030703 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6453110000000001,
    adminMass = 0.0002,
    ka = 0.0005694444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Rodríguez-Fernández_2022</td></tr><tr><td>measured_compound:</td><td>Amiodarone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amiodarone 645.311 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'k a1 (%)'; source reconciliation required</li><li>table representations disagree for 'k a2-3 (%)'; source reconciliation required</li><li>table representations disagree for 'k 12 (%)'; source reconciliation required</li><li>table representations disagree for 'V 2 (%)'; source reconciliation required</li><li>table representations disagree for 'K u (%)'; source reconciliation required</li><li>table representations disagree for 'Plasma (%)'; source reconciliation required</li><li>table representations disagree for 'produces a B max /2, K u : rate constant of unbinding in central compartment, K tu :'; source reconciliation required</li><li>table representations disagree for 'produces a B max /2, K u : rate constant of unbinding in central compartment, K tu :'; source reconciliation required</li><li>dropped 'k a1 (%)' → Q49: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a rate — the row is a variability or a ratio, not the estimate</li><li>dropped 'k a2-3 (%)' → Q49: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a rate — the row is a variability or a ratio, not the estimate</li><li>dropped 'k 12 (%)' → Q301: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a rate — the row is a variability or a ratio, not the estimate</li><li>dropped 'V 2 (%)' → Q64: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a volume — the row is a variability or a ratio, not the estimate</li><li>dropped 'K u (%)' → Q50: the uptake rate from the exposure medium (bioaccumulation), not a body toxicokinetic parameter</li><li>dropped value-less row: 'k B'</li><li>dropped value-less row: 'k a1'</li><li>dropped value-less row: 'F Sol I'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amiodarone_RodrguezFernndez2022_reference;
