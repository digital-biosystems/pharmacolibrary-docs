% run_Lonafarnib_Canini2017_PD_hdv  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Lonafarnib_Canini2017_PD_hdv_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/mL]'); ylabel('response [log10 IU/mL]'); title('Lonafarnib_Canini2017_PD_hdv', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Lonafarnib_Canini2017_PD_hdv.csv');
