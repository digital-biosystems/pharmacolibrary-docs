model Fluconazole_Watt2018_reported_value
  parameter Real Cl_ref = 8.333333333333334e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.049 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.306276,
    adminMass = 0.00084,
    ka = 0.0010722222222222222,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluconazole</td></tr><tr><td>population:</td><td>children on ECMO</td></tr><tr><td>source_paper:</td><td>Watt_2018</td></tr><tr><td>measured_compound:</td><td>Fluconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412338-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluconazole 306.276 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Lipophilicity (LogP)' — extend the ontology if this is a real PK parameter (source ['psp412338-tbl-0001:row2:col1'])</li><li>dropped unlinked row (NIL): 'Compound type/pKa' — extend the ontology if this is a real PK parameter (source ['psp412338-tbl-0001:row6:col1'])</li><li>salvaged Q22 ('UGT2B7 specific clearance'=0.005) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fluconazole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'reported value' subgroup of Watt_2018 (paper reports 2 populations: optimized value, reported value)</li><li>gap-filled Q61 (V) from Adamiszak_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Comisar_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zahir_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Adamiszak_2025, Comisar_2025, Zahir_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Fluconazole_Watt2018_reported_value;
