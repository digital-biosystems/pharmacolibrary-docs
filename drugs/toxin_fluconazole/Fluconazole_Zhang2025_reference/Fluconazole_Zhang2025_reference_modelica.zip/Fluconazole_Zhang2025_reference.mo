model Fluconazole_Zhang2025_reference
  parameter Real Cl_ref = 1.1388888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.037899999999999996 "Vd [m3]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (0.799)*cov_wt_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.306276,
    adminMass = 0.0002,
    ka = 0.0010722222222222222,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluconazole</td></tr><tr><td>population:</td><td>acute renal failure patients undergoing continuous renal replacement therapy</td></tr><tr><td>source_paper:</td><td>Zhang_2025</td></tr><tr><td>measured_compound:</td><td>Fluconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluconazole 306.276 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Vc' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Vcrrt' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Interindividual variability (ω2)')</li><li>table section residual_error: 'Additive error (mg/L)' routed out of structural estimates ('Residual variability (σ)')</li><li>dropped unlinked row (NIL): 'Vcrrt (L)' — extend the ontology if this is a real PK parameter (source ['T2:row6:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fluconazole</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc (L)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Comisar_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zahir_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Fluconazole_Zhang2025_reference;
