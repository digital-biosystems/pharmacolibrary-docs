function p = Fluconazole_Engbers2022_cohort_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluconazole   source: Engbers_2022 / cohort_1   route: oral
  % estimated (absent from source): F
  p.name  = 'Fluconazole_Engbers2022_cohort_1_params';
  p.drug  = 'fluconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.844;                % central volume [L]
  p.CL = 0.0147;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.86;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 840.0;             % dose [mg]
end
