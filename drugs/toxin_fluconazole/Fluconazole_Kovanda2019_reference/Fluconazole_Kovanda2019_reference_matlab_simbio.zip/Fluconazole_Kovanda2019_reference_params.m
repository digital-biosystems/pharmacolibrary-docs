function p = Fluconazole_Kovanda2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluconazole   source: Kovanda_2019 / reference   route: oral
  p.name  = 'Fluconazole_Kovanda2019_reference_params';
  p.drug  = 'fluconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 165.876;                % central volume [L]
  p.CL = 2.639;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.196;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
