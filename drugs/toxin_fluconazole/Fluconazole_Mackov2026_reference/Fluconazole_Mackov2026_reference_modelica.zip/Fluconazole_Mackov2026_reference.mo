model Fluconazole_Mackov2026_reference
  parameter Real Cl_ref = 2.2500000000000002e-07 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "eGFR covariate";
  parameter Real Vd_ref = 0.04158 "Vd [m3]";
  parameter Real cov_abw_0 = 0 "ABW covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.43)*cov_egfr_0),
    Vd = Vd_ref*(1 + (2.28)*cov_abw_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.306276,
    adminMass = 0.0002,
    ka = 0.0010722222222222222,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluconazole</td></tr><tr><td>population:</td><td>adult patients</td></tr><tr><td>source_paper:</td><td>Macková_2026</td></tr><tr><td>measured_compound:</td><td>Fluconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00929-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluconazole 306.276 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Vd' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'CL' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'β_CL_eGFR' routed out of structural estimates ('Between subject variability')</li><li>table representations disagree for 'Vd_pop (L)'; source reconciliation required</li><li>table representations disagree for 'β_Vd_ABW'; source reconciliation required</li><li>table representations disagree for 'CL_pop (L/h)'; source reconciliation required</li><li>table representations disagree for 'β_CL_eGFR'; source reconciliation required</li><li>table representations disagree for 'Proportional'; source reconciliation required</li><li>'β_Vd_ABW' is a β covariate effect on _Vd_, not Q61 (llm link set aside)</li><li>covariate level 'β_Vd_ABW' → Q900:theta_v_abw = 2.28 (linear_fractional on Q61)</li><li>'β_CL_eGFR' is a β covariate effect on _CL_, not Q22 (llm link set aside)</li><li>covariate level 'β_CL_eGFR' → Q900:theta_cl_egfr = 0.43 (linear_fractional on Q22)</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>dropped value-less row: 'Vd'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'pop'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Fluconazole_Mackov2026_reference;
