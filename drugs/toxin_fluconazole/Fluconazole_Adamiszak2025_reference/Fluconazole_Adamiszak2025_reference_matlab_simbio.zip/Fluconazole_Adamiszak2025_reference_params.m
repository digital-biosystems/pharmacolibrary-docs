function p = Fluconazole_Adamiszak2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluconazole   source: Adamiszak_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Fluconazole_Adamiszak2025_reference_params';
  p.drug  = 'fluconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 104.07;                % central volume [L]
  p.CL = 1.24;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.86;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 210.0;             % dose [mg]
end
