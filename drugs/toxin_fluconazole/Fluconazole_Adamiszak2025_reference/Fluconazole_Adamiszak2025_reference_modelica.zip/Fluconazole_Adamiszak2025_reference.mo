model Fluconazole_Adamiszak2025_reference
  parameter Real Cl_ref = 3.4444444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10407 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.306276,
    adminMass = 0.00021,
    ka = 0.0010722222222222222,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluconazole</td></tr><tr><td>population:</td><td>hemato-oncologic pediatric patients</td></tr><tr><td>source_paper:</td><td>Adamiszak_2025</td></tr><tr><td>measured_compound:</td><td>Fluconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-00488-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluconazole 306.276 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BIC' routed out of structural estimates ('BIC, Bayesian Information Criteria; CV%, coefficient of variation calculated as exp\u2061ω2−1×100%; IIV, interindividual variability; OFV, objective function value.')</li><li>table section iiv: 'CV%' routed out of structural estimates ('BIC, Bayesian Information Criteria; CV%, coefficient of variation calculated as exp\u2061ω2−1×100%; IIV, interindividual variability; OFV, objective function value.')</li><li>table section iiv: 'IIV' routed out of structural estimates ('BIC, Bayesian Information Criteria; CV%, coefficient of variation calculated as exp\u2061ω2−1×100%; IIV, interindividual variability; OFV, objective function value.')</li><li>table section iiv: 'OFV' routed out of structural estimates ('BIC, Bayesian Information Criteria; CV%, coefficient of variation calculated as exp\u2061ω2−1×100%; IIV, interindividual variability; OFV, objective function value.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fluconazole</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Comisar_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Zahir_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C1_half_life_beta failed (ratio 1.9391))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Fluconazole_Adamiszak2025_reference;
