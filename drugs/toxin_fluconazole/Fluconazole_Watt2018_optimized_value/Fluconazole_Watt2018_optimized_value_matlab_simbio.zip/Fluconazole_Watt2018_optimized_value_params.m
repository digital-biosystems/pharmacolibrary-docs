function p = Fluconazole_Watt2018_optimized_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluconazole   source: Watt_2018 / optimized_value   route: oral
  % estimated (absent from source): F
  p.name  = 'Fluconazole_Watt2018_optimized_value_params';
  p.drug  = 'fluconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.0;                % central volume [L]
  p.CL = 0.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.86;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 840.0;             % dose [mg]
end
