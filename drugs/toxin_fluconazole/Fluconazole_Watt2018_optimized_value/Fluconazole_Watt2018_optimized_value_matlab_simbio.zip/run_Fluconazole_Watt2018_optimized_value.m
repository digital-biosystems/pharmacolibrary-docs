% Run (SimBiology): build model + dose, simulate 0..672.0 h, plot.
p = Fluconazole_Watt2018_optimized_value_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 672.0);
