model Oxcarbazepine_Sinha2022_initial_estimate
  parameter Real Cl_ref = 4.8611111111111115e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.227 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.001,
    ka = 0.00013472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxcarbazepine</td></tr><tr><td>population:</td><td>children and adolescents aged >=2 years, and healthy adults (model development)</td></tr><tr><td>source_paper:</td><td>Sinha_2022</td></tr><tr><td>measured_compound:</td><td>MHD (10-monohydroxy derivative of oxcarbazepine)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412750-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Oxcarbazepine 252.273 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'fu,p'; source reconciliation required</li><li>table representations disagree for 'CLint,AKR1 C 1'; source reconciliation required</li><li>table representations disagree for 'CLint, H'; source reconciliation required</li><li>conflicting source units for 'CLint, H': [{'unit': 'MHD', 'source': 'psp412750-tbl-0001:row9:col2', 'scope': 'unit_column'}, {'unit': 'H', 'source': 'psp412750-tbl-0001:row9:col0', 'scope': 'label'}]</li><li>unit_dimension_unknown: 'OXZ' (fu)</li><li>unit_dimension_unknown: 'OXZ' (CLint)</li><li>unit_dimension_mismatch: 'CLint, H' → Q3 (unit '[time]' vs ontology '[length] ** 3 / [mass] / [time]') — route to review</li><li>dropped duplicate Q3 ('CLint, H', value '0.035') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Distribution, Metabolism and Excretion' — extend the ontology if this is a real PK parameter (source ['Sinha_2022_table_2:row0:col3', 'Sinha_2022_table_2:row1:col3', 'Sinha_2022_table_2:row2:col3', 'Sinha_2022_table_2:row4:col3', 'Sinha_2022_table_2:row5:col3'])</li><li>dropped value-less row: 'a In the absence of enzyme inducers.'</li><li>dropped value-less row: 'b In the presence of enzyme inducers.'</li><li>dropped value-less row: 'c PK‐Sim generated value.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=MHD (10-monohydroxy derivative of oxcarbazepine)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: prose indicates saturable/MM/TMDD/time-varying kinetics — manual_model_class</li><li>template fit: none — nonlinear / manual model class</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxcarbazepine_Sinha2022_initial_estimate;
