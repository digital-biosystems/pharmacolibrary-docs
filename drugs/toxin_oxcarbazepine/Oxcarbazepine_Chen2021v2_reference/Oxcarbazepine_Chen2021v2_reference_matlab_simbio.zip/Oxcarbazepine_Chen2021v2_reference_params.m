function p = Oxcarbazepine_Chen2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxcarbazepine   source: Chen_2021_2 / reference   route: oral
  p.name  = 'Oxcarbazepine_Chen2021v2_reference_params';
  p.drug  = 'oxcarbazepine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 294.0;                % central volume [L]
  p.CL = 8.59;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.485;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
