model Oxcarbazepine_Rodrigues2017_reference
  parameter Real Cl_ref = 1.1416666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.337 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 5.1516650181338604e-05,
    k21 = 0.0002860150100677283
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxcarbazepine</td></tr><tr><td>population:</td><td>epileptic children aged 2-12 years</td></tr><tr><td>source_paper:</td><td>Rodrigues_2017</td></tr><tr><td>measured_compound:</td><td>MHD (monohydroxy derivative)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>oxcarbazepine 252.273 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is oxcarbazepine; the compartment is MHD (monohydroxy derivative). Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is MHD (monohydroxy derivative), not oxcarbazepine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>oxcarbazepine's own concentration-time course is not produced by this model</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=MHD (monohydroxy derivative)</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>molar mass: none found for 'MHD (monohydroxy derivative)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'MHD (monohydroxy derivative)', not oxcarbazepine — the review values are the parent's</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q22 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Oxcarbazepine_Rodrigues2017_reference;
