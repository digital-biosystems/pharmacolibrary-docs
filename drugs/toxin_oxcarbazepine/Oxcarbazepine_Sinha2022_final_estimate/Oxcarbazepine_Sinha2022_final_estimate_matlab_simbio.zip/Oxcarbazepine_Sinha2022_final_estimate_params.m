function p = Oxcarbazepine_Sinha2022_final_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxcarbazepine   source: Sinha_2022 / final_estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Oxcarbazepine_Sinha2022_final_estimate_params';
  p.drug  = 'oxcarbazepine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 227.0;                % central volume [L]
  p.CL = 175.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.485;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
