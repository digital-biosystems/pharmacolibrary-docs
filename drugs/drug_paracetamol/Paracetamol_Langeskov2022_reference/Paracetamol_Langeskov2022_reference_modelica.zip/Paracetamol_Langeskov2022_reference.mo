model Paracetamol_Langeskov2022_reference
  parameter Real Cl_ref = 7.194444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0485 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 576.0,
    k12 = 0.0011397479954180986,
    k21 = 0.00099779382270357
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Langeskov_2022</td></tr><tr><td>measured_compound:</td><td>paracetamol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp2962-tbl-0002</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Placebo' (kabs)</li><li>routed 'Θkacovariate' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>unit_dimension_mismatch: 'ΘV1/Fcovariate' → Q290 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q290 ('ΘV1/Fcovariate', value '0.0312') — already have one for this compound</li><li>unit_dimension_unknown: 'Placebo' (ktr)</li><li>kept covariate coefficient Θktrcovariate=0.791 (covariate ktrcovariate) — not an ontology parameter</li><li>dropped duplicate Q290 ('V1/F (L) a', value '1843') — already have one for this compound</li><li>dropped duplicate Q27 ('Cl/F (L/h) a', value '620') — already have one for this compound</li><li>dropped duplicate Q82 ('V2/F(L) a', value '4184') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=paracetamol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Langeskov2022_reference;
