function p = Paracetamol_Langeskov2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Langeskov_2022 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Paracetamol_Langeskov2022_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.5;                % central volume [L]
  p.CL = 25.9;                % clearance [L/h]
  p.Vp = [55.4];             % peripheral volumes [L]
  p.Q  = [199.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.16;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
