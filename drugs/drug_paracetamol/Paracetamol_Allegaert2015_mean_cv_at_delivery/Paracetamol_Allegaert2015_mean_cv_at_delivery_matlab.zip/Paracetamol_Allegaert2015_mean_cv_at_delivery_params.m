function p = Paracetamol_Allegaert2015_mean_cv_at_delivery_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Allegaert_2015 / mean_cv_at_delivery   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Paracetamol_Allegaert2015_mean_cv_at_delivery_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 34.4;                % central volume [L]
  p.CL = 3.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
