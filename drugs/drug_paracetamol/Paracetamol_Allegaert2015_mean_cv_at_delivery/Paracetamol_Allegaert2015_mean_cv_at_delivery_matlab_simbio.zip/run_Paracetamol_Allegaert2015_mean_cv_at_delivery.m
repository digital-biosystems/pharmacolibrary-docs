% Run (SimBiology): build model + dose, simulate 0..31.0 h, plot.
p = Paracetamol_Allegaert2015_mean_cv_at_delivery_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 31.0);
