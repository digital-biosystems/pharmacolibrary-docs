function p = Paracetamol_Hakim2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Hakim_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Paracetamol_Hakim2019_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1428.0;                % central volume [L]
  p.CL = 742.0;                % clearance [L/h]
  p.Vp = [1176.0];             % peripheral volumes [L]
  p.Q  = [2611.0];             % inter-compartmental clearances [L/h]
  p.ka = 9.76;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
