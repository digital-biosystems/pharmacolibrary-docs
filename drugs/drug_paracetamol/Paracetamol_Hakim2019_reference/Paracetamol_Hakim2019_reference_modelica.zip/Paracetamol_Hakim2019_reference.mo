model Paracetamol_Hakim2019_reference
  parameter Real Cl_ref = 0.00020611111111111112 "Cl [m3/s]";
  parameter Real Vd_ref = 1.428 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.151165,
    adminMass = 0.001,
    ka = 0.002711111111111111,
    Tlag = 252.0,
    k12 = 0.0005078976034858388,
    k21 = 0.0006167328042328041
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>severely obese adolescents and young adults</td></tr><tr><td>source_paper:</td><td>Hakim_2019</td></tr><tr><td>measured_compound:</td><td>acetaminophen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>acetaminophen 151.165 g/mol (pubchem); paracetamol 151.165 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'fFatCL' — extend the ontology if this is a real PK parameter (source ['Hakim_2019_table_2:row5:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acetaminophen</li><li>gap-filled Q49 (kabs) from Anderson_1998's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gibb_2008's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Hakim2019_reference;
