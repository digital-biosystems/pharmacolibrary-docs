model Paracetamol_Bouazza2021_reference
  parameter Real Cl_ref = 9.611111111111111e-08 "Cl [m3/s]";
  parameter Real cov_bw_0 = 0 "BW covariate";
  parameter Real cov_ga_1 = 0 "GA covariate";
  parameter Real Vd_ref = 0.00199 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.7)*cov_bw_0)*(1 + (2.48)*cov_ga_1),
    Vd = Vd_ref*(1 + (1.06)*cov_bw_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.151165,
    adminMass = 0.000525,
    ka = 0.002711111111111111,
    Tlag = 252.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>preterm infants</td></tr><tr><td>source_paper:</td><td>Bouazza_2021</td></tr><tr><td>measured_compound:</td><td>paracetamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paracetamol 151.165 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>'β CL_BW' is a β covariate effect on CL_, not Q22 (llm link set aside)</li><li>covariate level 'β CL_BW' → Q900:theta_cl_bw = 0.70 (linear_fractional on Q22)</li><li>'β V_BW' is a β covariate effect on V_, not Q64 (llm link set aside)</li><li>covariate level 'β V_BW' → Q900:theta_v_bw = 1.06 (linear_fractional on Q61)</li><li>dropped duplicate Q900 ('β Te_GA', value '-4.49') — already have one for this compound</li><li>dropped duplicate Q900 ('p', value '4') — already have one for this compound</li><li>dropped PD-category row 'Imax' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_0:row15:col1'])</li><li>'β Imax_GA' is a β covariate effect on Imax_, not Q319 (llm link set aside)</li><li>covariate level 'β Imax_GA' → Q900:imax_ga = 2.48 (linear_fractional on Q22)</li><li>unit inherited for theta_cl_bw (Q900): 'h' from a same-Q-code sibling (this row's label had no unit)</li><li>unit inherited for theta_v_bw (Q900): 'h' from a same-Q-code sibling (this row's label had no unit)</li><li>unit inherited for imax_ga (Q900): 'h' from a same-Q-code sibling (this row's label had no unit)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=paracetamol</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Anderson_1998's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Bouazza2021_reference;
