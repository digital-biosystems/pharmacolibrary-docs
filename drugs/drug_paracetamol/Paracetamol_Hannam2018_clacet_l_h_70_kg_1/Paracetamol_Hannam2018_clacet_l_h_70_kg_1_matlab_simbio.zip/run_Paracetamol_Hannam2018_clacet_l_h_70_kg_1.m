% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Paracetamol_Hannam2018_clacet_l_h_70_kg_1_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
