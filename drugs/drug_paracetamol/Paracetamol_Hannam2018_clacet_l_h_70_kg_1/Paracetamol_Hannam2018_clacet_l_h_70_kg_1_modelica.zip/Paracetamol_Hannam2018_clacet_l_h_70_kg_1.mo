model Paracetamol_Hannam2018_clacet_l_h_70_kg_1
  parameter Real Cl_ref = 0.00025666666666666665 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00635 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>children undergoing adenotonsillectomy</td></tr><tr><td>source_paper:</td><td>Hannam_2018</td></tr><tr><td>measured_compound:</td><td>acetaminophen, ibuprofen, tramadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Estimate' — extend the ontology if this is a real PK parameter (source ['Hannam_2018_table_p4_1:row0:col1'])</li><li>routed 'PPV' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped diagnostic row 'Shrinkage%' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>salvaged Q22 ('CL ACET (L/h.70 kg -1 )'=13.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acetaminophen, ibuprofen, tramadol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'clacet (l/h.70 kg-1)' subgroup of Hannam_2018 (paper reports 4 populations: clacet (l/h.70 kg-1), erradd.acet (mg/l), tabsacet (h), vacet (l.70 kg-1))</li><li>gap-filled Q61 (V) from Albert_1984's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Gibb_2008's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Hannam2018_clacet_l_h_70_kg_1;
