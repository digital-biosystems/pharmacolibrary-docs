function p = Paracetamol_Mian2019v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Mian_2019_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Paracetamol_Mian2019v2_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.96;                % central volume [L]
  p.CL = 0.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.76;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 525.0;             % dose [mg]
end
