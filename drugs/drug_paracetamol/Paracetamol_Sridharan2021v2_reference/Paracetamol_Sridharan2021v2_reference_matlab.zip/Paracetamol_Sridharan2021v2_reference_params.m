function p = Paracetamol_Sridharan2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Sridharan_2021_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Paracetamol_Sridharan2021v2_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.18;                % central volume [L]
  p.CL = 0.0452;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.76;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
