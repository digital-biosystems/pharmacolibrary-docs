model Paracetamol_Gibb2008_PD_vas
  "sigmoid_emax exposure-response sweep — Gibb_2008 :: VAS (pain relief)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -10.0,  // [VAS of 0-10]
    EC50 = 0.00998,  // [kg/m3; mg/l × 0.001]
    gamma = 1.0,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/l per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 99.8, Interval = 0.1996));
end Paracetamol_Gibb2008_PD_vas;
