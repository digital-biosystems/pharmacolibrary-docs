model Paracetamol_Anderson2005_6_months_pna
  parameter Real Cl_ref = 7.777777777777778e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0574 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.151165,
    adminMass = 0.00105,
    ka = 0.0001388888888888889,
    Tlag = 252.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>children (postconception age 27 weeks-14 years)</td></tr><tr><td>source_paper:</td><td>Anderson_2005</td></tr><tr><td>measured_compound:</td><td>paracetamol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>paracetamol 151.165 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Weight (kg)' — extend the ontology if this is a real PK parameter (source ['Anderson_2005_table_3:row5:col1'])</li><li>dropped duplicate Q78 ('V3/Foral (L·kg⁻¹)', value '0.47') — already have one for this compound</li><li>implicit units: 'CL/Foral L·h⁻¹·kg⁻¹' → L/h (from the popPK convention: 'The parameter description indicates it is total clearance (CL/F). In the paper text, the equation for CL/F is explicitly')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=paracetamol</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>population split: '6 months pna' subgroup of Anderson_2005 (paper reports 11 populations: 1 year pna, 2 years pna, 28 weeks pca, 3 months pna, 30 weeks pca, 34 weeks pca, 40 weeks pca, 5 years pna, 6 months pna, 8 years pna, estimate)</li><li>gap-filled Q76 (V/F) from Anderson_2015's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gibb_2008's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Anderson2005_6_months_pna;
