model Paracetamol_Anderson2015_PD_vas
  "sigmoid_emax exposure-response sweep — Anderson_2015 :: VAS (VAS pain score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.2,  // [0--10]
    EC50 = 0.0098,  // [kg/m3; mg/l × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 98, Interval = 0.196),
    Documentation(info = "<html><body><h4>Paracetamol_Anderson2015_PD_vas</h4><p>The steady-state exposure-response curve of Anderson BJ et al., <i>Expert opinion on drug metabolism &amp; toxicology 11(9):1393–1408</i> 2015 (<a href=\"https://doi.org/10.1517/17425255.2015.1061505\">doi:10.1517/17425255.2015.1061505</a>) — VAS pain score [0--10] against paracetamol mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        5.2 0--10    maximal effect term (E max, Q320)
  EC50  =        9.8 mg/l     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =          1          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of paracetamol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (9.8 mg/l)  response -2.6
  exposure -> infinity  response -5.2</pre></body></html>"));
end Paracetamol_Anderson2015_PD_vas;
