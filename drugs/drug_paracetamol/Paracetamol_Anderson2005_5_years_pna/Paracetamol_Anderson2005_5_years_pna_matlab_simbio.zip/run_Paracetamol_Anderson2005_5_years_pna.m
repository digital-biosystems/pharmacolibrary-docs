% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Paracetamol_Anderson2005_5_years_pna_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
