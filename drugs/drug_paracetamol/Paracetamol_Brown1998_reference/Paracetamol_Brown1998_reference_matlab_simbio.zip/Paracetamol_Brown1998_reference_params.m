function p = Paracetamol_Brown1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Brown_1998 / reference   route: oral
  p.name  = 'Paracetamol_Brown1998_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 68.6;                % central volume [L]
  p.CL = 29.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.18;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
