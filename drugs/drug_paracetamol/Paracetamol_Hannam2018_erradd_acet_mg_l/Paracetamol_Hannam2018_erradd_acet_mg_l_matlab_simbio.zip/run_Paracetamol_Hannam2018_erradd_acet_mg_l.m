% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Paracetamol_Hannam2018_erradd_acet_mg_l_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
