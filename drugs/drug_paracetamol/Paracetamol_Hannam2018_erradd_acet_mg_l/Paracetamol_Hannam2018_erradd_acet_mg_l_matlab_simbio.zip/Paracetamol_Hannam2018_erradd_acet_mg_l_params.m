function p = Paracetamol_Hannam2018_erradd_acet_mg_l_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Hannam_2018 / erradd_acet_mg_l   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Paracetamol_Hannam2018_erradd_acet_mg_l_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.35;                % central volume [L]
  p.CL = 924.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
