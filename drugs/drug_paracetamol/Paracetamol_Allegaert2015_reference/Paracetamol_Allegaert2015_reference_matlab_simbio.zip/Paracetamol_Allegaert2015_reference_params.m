function p = Paracetamol_Allegaert2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Allegaert_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Paracetamol_Allegaert2015_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.83;                % central volume [L]
  p.CL = 2.02;                % clearance [L/h]
  p.Vp = [22.3];             % peripheral volumes [L]
  p.Q  = [1.34];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
