// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Paracetamol_Allegaert2015_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.00183, 0.0223},
    CLelim = {5.611111111111111e-07, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {3.722222222222222e-07, 3.722222222222222e-07}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>young women</td></tr><tr><td>source_paper:</td><td>Allegaert_2015</td></tr><tr><td>measured_compound:</td><td>paracetamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '2.03(8.8) × 7.33 = 14.9' — extend the ontology if this is a real PK parameter (source ['Tab2:row8:col3'])</li><li>dropped duplicate Q22 ('CLPS (L/h)', value '3.82') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Preterm = 5.61 (7.9)' — extend the ontology if this is a real PK parameter (source ['Tab2:row10:col1'])</li><li>dropped duplicate Q22 ('CLPU (L/h)', value '0.94') — already have one for this compound</li><li>dropped unlinked row (NIL): '34.4' — extend the ontology if this is a real PK parameter (source ['Tab2:row14:col1'])</li><li>dropped unlinked row (NIL): 'V8 (L)' — extend the ontology if this is a real PK parameter (source ['Tab2:row16:col1', 'Tab2:row16:col2', 'Tab2:row16:col3', 'Tab2:row16:col4'])</li><li>dropped duplicate Q30 ('Q1 (L/h)', value '61.6') — already have one for this compound</li><li>dropped unlinked row (NIL): 'MF' — extend the ontology if this is a real PK parameter (source ['Tab2:row20:col1', 'Tab2:row20:col2', 'Tab2:row20:col3', 'Tab2:row20:col4'])</li><li>dropped duplicate Q22 ('ωCLpg2', value '0.12') — already have one for this compound</li><li>routed 'ωV12' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'ωCLpu2' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): '−2LL' — extend the ontology if this is a real PK parameter (source ['Tab2:row33:col1', 'Tab2:row33:col2', 'Tab2:row33:col3', 'Tab2:row33:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=paracetamol</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>gap-filled Q83 (tlag) from Gibb_2008's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Allegaert2015_reference;
