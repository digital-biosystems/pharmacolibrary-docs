% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Paracetamol_Allegaert2015_postpartum_early_10_weeks_later_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
