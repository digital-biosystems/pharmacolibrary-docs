// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Paracetamol_Allegaert2015_postpartum_early_10_weeks_later
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0185},
    CLelim = {1.0722222222222223e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>young women</td></tr><tr><td>source_paper:</td><td>Allegaert_2015</td></tr><tr><td>measured_compound:</td><td>paracetamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>molar_masses:</td><td>paracetamol 151.165 g/mol (pubchem); paracetamol-glucuronide 328.3 g/mol (paper); paracetamol-sulphate 230.2 g/mol (paper)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=paracetamol</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0, 0]</li><li>population split: 'postpartum, early 10 weeks later' subgroup of Allegaert_2015 (paper reports 3 populations: mean (cv%) at delivery, postpartum, early 10 weeks later, postpartum, late + healthy volunteers)</li><li>row roles: 2 per-group rows of paracetamol residual_error but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=compartmental; 18/18 row label(s) assigned, 11 linked by role; re-tagged parent→paracetamol-glucuronide ×2, parent→paracetamol-sulphate ×1</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Gibb_2008's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Allegaert2015_postpartum_early_10_weeks_later;
