function p = Paracetamol_Fritz1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Fritz_1984 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Paracetamol_Fritz1984_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.35;                % central volume [L]
  p.CL = 26.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 85.0;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
