function p = Paracetamol_Anderson1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Anderson_1998 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Paracetamol_Anderson1998_reference_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 67.1;                % central volume [L]
  p.CL = 10.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.77;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2800.0;             % dose [mg]
end
