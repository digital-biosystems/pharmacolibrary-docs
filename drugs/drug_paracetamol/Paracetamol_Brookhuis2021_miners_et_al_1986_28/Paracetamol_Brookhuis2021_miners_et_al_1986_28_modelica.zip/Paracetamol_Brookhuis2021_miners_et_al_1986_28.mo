// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Paracetamol_Brookhuis2021_miners_et_al_1986_28
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.001},
    CLelim = {7.233333333333333e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = {}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>pregnant women</td></tr><tr><td>source_paper:</td><td>Brookhuis_2021</td></tr><tr><td>measured_compound:</td><td>acetaminophen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-01302-t005</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'miners et al. (1986) [28]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'miners et al. (1986) [28]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q61 ('Vd (L/kg)', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acetaminophen</li><li>topology: 3 first-order transfer(s) across 3 compounds → general_linear</li><li>population split: 'miners et al. (1986) [28]' subgroup of Brookhuis_2021 (paper reports 11 populations: allegaert et al. (2015) [16], beaulac-baillargeon et al. (1993) [12], beaulac-baillargeon et al. (1994) [22], clark and seagel (1983) [23], kulo et al. (2012) [31], kulo et al. (2013) [15], miners et al. (1986) [28], nimmo et al. (1975) [26], simpson et al. (1988) [34], stanley et al. (1995) [33], whitehead et al. (1993) [14])</li><li>gap-filled Q22 (CL) from Anderson_2015's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Gibb_2008's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Brookhuis2021_miners_et_al_1986_28;
