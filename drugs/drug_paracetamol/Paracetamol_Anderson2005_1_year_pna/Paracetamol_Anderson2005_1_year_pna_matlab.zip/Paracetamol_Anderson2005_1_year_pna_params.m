function p = Paracetamol_Anderson2005_1_year_pna_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paracetamol   source: Anderson_2005 / 1_year_pna   route: oral
  % estimated (absent from source): ka
  p.name  = 'Paracetamol_Anderson2005_1_year_pna_params';
  p.drug  = 'paracetamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 57.4;                % central volume [L]
  p.CL = 0.32;                % clearance [L/h]
  p.Vp = [23.8];             % peripheral volumes [L]
  p.Q  = [87.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.07;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
