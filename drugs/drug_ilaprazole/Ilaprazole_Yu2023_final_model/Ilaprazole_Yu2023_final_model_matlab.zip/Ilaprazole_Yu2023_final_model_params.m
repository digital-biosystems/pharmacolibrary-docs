function p = Ilaprazole_Yu2023_final_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ilaprazole   source: Yu_2023 / final_model   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Ilaprazole_Yu2023_final_model_params';
  p.drug  = 'ilaprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.795;                % central volume [L]
  p.CL = 3.394;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
