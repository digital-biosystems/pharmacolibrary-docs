model Ilaprazole_Yu2023_final_model
  parameter Real Cl_ref = 9.427777777777779e-07 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real Vd_ref = 0.006795 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.545)*cov_wt_0)*(1 + (-0.213)*cov_sex_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ilaprazole</td></tr><tr><td>population:</td><td>healthy subjects and patients with duodenal ulcer</td></tr><tr><td>source_paper:</td><td>Yu_2023</td></tr><tr><td>measured_compound:</td><td>ilaprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CLp (L/h)', value '13.086') — already have one for this compound</li><li>covariate level 'WT effect on Vp' → Q900:wt_effect_on_vp = 1.545 (linear_fractional on Q22)</li><li>unit_dimension_unknown: 'Disease status = 1' (CL)</li><li>dropped duplicate Q22 ('Disease status effect on CL (Disease status = 1)', value '0.290') — already have one for this compound</li><li>unit_dimension_unknown: 'Disease status = 1' (V2)</li><li>dropped duplicate Q64 ('Disease status effect on Vp (Disease status = 1)', value '0.356') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ilaprazole</li><li>population split: 'final model' subgroup of Yu_2023 (paper reports 2 populations: bootstrapping, final model)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ilaprazole_Yu2023_final_model;
