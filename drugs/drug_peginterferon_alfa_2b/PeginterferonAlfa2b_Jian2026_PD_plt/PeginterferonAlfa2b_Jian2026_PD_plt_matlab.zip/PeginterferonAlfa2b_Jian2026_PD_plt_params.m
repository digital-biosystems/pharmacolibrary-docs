function p = PeginterferonAlfa2b_Jian2026_PD_plt_params()
% PeginterferonAlfa2b_Jian2026_PD_plt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% peginterferon_alfa_2b Jian_2026::PLT: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/mL per second, in SI inside (kg/m3, s). Response PLT in ×10 9 /L. Driver: peginterferon_alfa_2b (cited_pk).
p.E0 = 180.0;
p.Emax = 0.197;
p.EC50 = 4.0100000000000006e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 41000.0;
p.form = 'E0*(1 - Emax*frac)';
end
