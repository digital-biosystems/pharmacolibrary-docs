model PeginterferonAlfa2b_Jian2026_PD_plt
  "indirect_response_i exposure-response sweep — Jian_2026 :: PLT (Platelet)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 180,      // [×10 9 /L]
    Emax = 0.197,  // type I effect term
    EC50 = 4.01e-06,  // [kg/m3; pg/mL × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 41000, Interval = 82),
    Documentation(info = "<html><body><!-- drug-about --><h4>About peginterferon_alfa_2b</h4><p>Peginterferon alfa-2b is an antiviral immunostimulant used to treat chronic hepatitis C and melanoma. It has been an approved medicine and is listed among WHO essential medicines, although some of its European marketing authorisations have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7160789\">Wikidata Q7160789</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>PeginterferonAlfa2b_Jian2026_PD_plt</h4><p>The steady-state exposure-response curve of Jian W et al., <i>Clinical pharmacology and therapeutics 119(1):219–227</i> 2026 (<a href=\"https://doi.org/10.1002/cpt.70079\">doi:10.1002/cpt.70079</a>) — Platelet [×10 9 /L] against peginterferon_alfa_2b pg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        180 ×10 9 /L drug-free response (baseline) (PLT 0, Q324)
  Emax  =      0.197          maximal effect term (E max, Q323)
  EC50  =       4010 pg/mL    exposure at half of the maximal effect term (EC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one pg/mL of peginterferon_alfa_2b per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 180   (drug-free)
  exposure = EC50 (4010 pg/mL)  response 162.3
  exposure -> infinity  response 144.5</pre></body></html>"));
end PeginterferonAlfa2b_Jian2026_PD_plt;
