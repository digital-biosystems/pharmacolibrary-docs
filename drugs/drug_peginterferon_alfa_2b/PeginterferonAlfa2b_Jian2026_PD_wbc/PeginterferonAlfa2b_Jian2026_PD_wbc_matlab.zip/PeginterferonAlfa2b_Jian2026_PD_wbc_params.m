function p = PeginterferonAlfa2b_Jian2026_PD_wbc_params()
% PeginterferonAlfa2b_Jian2026_PD_wbc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% peginterferon_alfa_2b Jian_2026::WBC: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/mL per second, in SI inside (kg/m3, s). Response WBC in ×10 9 /L. Driver: peginterferon_alfa_2b (cited_pk).
p.E0 = 5.25;
p.Emax = 0.0952;
p.EC50 = 1.94e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 20000.0;
p.form = 'E0*(1 - Emax*frac)';
end
