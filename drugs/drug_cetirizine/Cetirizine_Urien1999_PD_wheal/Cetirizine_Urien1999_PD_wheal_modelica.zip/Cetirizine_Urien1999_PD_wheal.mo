model Cetirizine_Urien1999_PD_wheal
  "indirect_response_i exposure-response sweep — Urien_1999 :: wheal (wheal)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.3e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cetirizine</h4><p>Cetirizine is a non-sedating antihistamine used to treat allergic conditions such as allergic rhinitis, urticaria, and sinus problems. It is an approved medicine, widely used as an oral antihistamine and also available as an eye drop for allergic eye conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423075\">Wikidata Q423075</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cetirizine_Urien1999_PD_wheal</h4><p>The steady-state exposure-response curve of Urien S et al., <i>International journal of clinical pharmacology and therapeutics 37(10):499–502</i> 1999 — wheal against cetirizine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =         13 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of cetirizine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Cetirizine_Urien1999_PD_wheal;
