model Cetirizine_Olsn2008_PD_wheal_formation
  "emax exposure-response sweep — Olsén_2008 :: wheal formation (histamine-induced cutaneous wheal formation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.95,  // [1; % × 0.01]
    EC50 = 1.8e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 180, Interval = 0.36),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cetirizine</h4><p>Cetirizine is a non-sedating antihistamine used to treat allergic conditions such as allergic rhinitis, urticaria, and sinus problems. It is an approved medicine, widely used as an oral antihistamine and also available as an eye drop for allergic eye conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423075\">Wikidata Q423075</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cetirizine_Olsn2008_PD_wheal_formation</h4><p>The steady-state exposure-response curve of Olsén L et al., <i>Veterinary journal (London, England : 1997) 177(2):242–249</i> 2008 (<a href=\"https://doi.org/10.1016/j.tvjl.2007.03.026\">doi:10.1016/j.tvjl.2007.03.026</a>) — histamine-induced cutaneous wheal formation against cetirizine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         95 %        maximal effect term (maximal inhibition, Q323)
  EC50  =         18 ng/mL    exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of cetirizine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (18 ng/mL)  response -0.475
  exposure -> infinity  response -0.95</pre></body></html>"));
end Cetirizine_Olsn2008_PD_wheal_formation;
