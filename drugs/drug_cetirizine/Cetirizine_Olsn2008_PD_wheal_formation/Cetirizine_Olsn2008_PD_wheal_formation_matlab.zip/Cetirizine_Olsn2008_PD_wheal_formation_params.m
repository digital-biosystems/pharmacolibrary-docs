function p = Cetirizine_Olsn2008_PD_wheal_formation_params()
% Cetirizine_Olsn2008_PD_wheal_formation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cetirizine Olsén_2008::wheal_formation: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response wheal formation in its own unit. Driver: cetirizine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.9500000000000001;
p.EC50 = 1.8e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 180.0;
p.form = 'E0 + Emax*frac';
end
