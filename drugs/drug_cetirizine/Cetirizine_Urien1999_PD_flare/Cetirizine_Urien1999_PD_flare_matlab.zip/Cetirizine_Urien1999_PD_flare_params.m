function p = Cetirizine_Urien1999_PD_flare_params()
% Cetirizine_Urien1999_PD_flare_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cetirizine Urien_1999::flare: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response flare in its own unit. Driver: cetirizine (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 3.9999999999999996e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 400.0;
p.form = 'E0*(1 - Emax*frac)';
end
