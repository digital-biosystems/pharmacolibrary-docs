model Cetirizine_Melander2025_reference
  parameter Real Cl_ref = 7e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019899999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38888799999999996,
    adminMass = 5e-06,
    ka = 2.638888888888889e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cetirizine</h4><p>Cetirizine is a non-sedating antihistamine used to treat allergic conditions such as allergic rhinitis, urticaria, and sinus problems. It is an approved medicine, widely used as an oral antihistamine and also available as an eye drop for allergic eye conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423075\">Wikidata Q423075</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cetirizine</td></tr><tr><td>population:</td><td>breastfeeding women</td></tr><tr><td>source_paper:</td><td>Melander_2025</td></tr><tr><td>measured_compound:</td><td>cetirizine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcpt14100-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cetirizine 388.888 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is cetirizine; the compartment is cetirizine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is cetirizine, not cetirizine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>cetirizine's own concentration-time course is not produced by this model</li><li>routed 'Covariate effect of pumping duration on VM (L)' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Inter‐individual variability in Clearance (%CV)' — extend the ontology if this is a real PK parameter (source ['bcpt14100-tbl-0001:row7:col1'])</li><li>implicit units: 'Tmax' → h (from the paper text: &quot;The text states: 'Model‐predicted Tmax was 2.53 ± 1.09 h (range: 1.23–5.83)'&quot;)</li><li>implicit units: 'Cmax' → μg/L (from the paper text: &quot;The text states: 'with a model‐predicted Cmax of 30.6 ± 7.02 μg/l (range: 13.2–55.2)'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cetirizine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Cetirizine_Melander2025_reference;
