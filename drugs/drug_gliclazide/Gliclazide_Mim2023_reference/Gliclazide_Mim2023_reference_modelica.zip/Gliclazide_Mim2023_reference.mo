model Gliclazide_Mim2023_reference
  parameter Real Cl_ref = 3e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32341000000000003,
    adminMass = 6e-05,
    ka = 0.00038888888888888887,
    Tlag = 0.0,
    k12 = 0.0003698979591836734,
    k21 = 0.0008257403189066059
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About gliclazide</h4><p>Gliclazide is a sulfonylurea blood glucose-lowering drug used to treat diabetes. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q290001\">Wikidata Q290001</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>gliclazide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Mim_2023</td></tr><tr><td>measured_compound:</td><td>gliclazide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gliclazide 323.41 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Mim_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Gliclazide_Mim2023_reference;
