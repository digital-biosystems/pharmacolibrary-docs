model Gliclazide_Frey2003_PD_fpg
  "emax exposure-response sweep — Frey_2003 :: FPG (fasting plasma glucose (FPG))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 9.6,      // [mol/m3; mmol l-1 × 1]
    Emax = -29,  // [% of baseline FPG]
    EC50 = 20,  // [mg h ml-1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg h ml-1 per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mg h ml-1' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 200, Interval = 0.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About gliclazide</h4><p>Gliclazide is a sulfonylurea blood glucose-lowering drug used to treat diabetes. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q290001\">Wikidata Q290001</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Gliclazide_Frey2003_PD_fpg</h4><p>The steady-state exposure-response curve of Frey N et al., <i>British journal of clinical pharmacology 55(2):147–157</i> 2003 (<a href=\"https://doi.org/10.1046/j.1365-2125.2003.01751.x\">doi:10.1046/j.1365-2125.2003.01751.x</a>) — fasting plasma glucose (FPG) [mmol l-1] against gliclazide AUC mg h ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        9.6 mmol l-1 drug-free response (baseline) (Baseline FPG, Q324)
  Emax  =         29 % of baseline FPG maximal effect term (Emax, Q323)
  EC50  =         20 mg h ml-1 exposure at half of the maximal effect term (AUC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg h ml-1 of gliclazide AUC per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 9.6   (drug-free)
  exposure = EC50 (20 mg h ml-1)  response -4.9
  exposure -> infinity  response -19.4</pre></body></html>"));
end Gliclazide_Frey2003_PD_fpg;
