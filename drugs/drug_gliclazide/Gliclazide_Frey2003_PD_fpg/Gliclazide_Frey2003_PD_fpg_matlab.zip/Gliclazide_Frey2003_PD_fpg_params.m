function p = Gliclazide_Frey2003_PD_fpg_params()
% Gliclazide_Frey2003_PD_fpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gliclazide Frey_2003::FPG: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg h ml-1 per second, in SI inside (kg/m3, s). Response FPG in mmol l-1. Driver: gliclazide AUC (not_resolved).
p.E0 = 9.599999999999998;
p.Emax = -29.0;
p.EC50 = 20.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 200.0;
p.form = 'E0 + Emax*frac';
end
