// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Dextroamphetamine_Ilic2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {37440.0},
    MM = 0.13521,
    adminMass = 6.25e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dextroamphetamine</td></tr><tr><td>population:</td><td>Children aged 4–5 years with Attention-Deficit/Hyperactivity Disorder</td></tr><tr><td>source_paper:</td><td>Ilic_2022</td></tr><tr><td>measured_compound:</td><td>d-amphetamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>d-amphetamine 135.21 g/mol (pubchem); dextroamphetamine 135.21 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Mean ± SD'; source reconciliation required</li><li>table representations disagree for 'Median (range)'; source reconciliation required</li><li>table representations disagree for 'GM (% CV of GM)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Mean ± SD' — extend the ontology if this is a real PK parameter (source ['Tab2:row2:col1', 'Tab2:row6:col1', 'Tab2:row10:col1', 'Tab2:row14:col1', 'Tab2:row18:col1', 'Tab2:row22:col1', 'Tab2:row26:col1', 'Tab2:row30:col1', 'Tab2:row34:col1'])</li><li>dropped unlinked row (NIL): 'Median (range)' — extend the ontology if this is a real PK parameter (source ['Tab2:row3:col1', 'Tab2:row7:col1', 'Tab2:row11:col1', 'Tab2:row19:col1', 'Tab2:row23:col1', 'Tab2:row27:col1', 'Tab2:row31:col1', 'Tab2:row35:col1'])</li><li>dropped value-less row: 'AUC'</li><li>dropped value-less row: 'AUC0–t'</li><li>dropped value-less row: 'AUCtau,ss'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'Ctrough,ss'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'd-amphetamine'</li><li>dropped value-less row: 'GM'</li><li>dropped value-less row: 'l-amphetamine'</li><li>dropped value-less row: 'LLoQ'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Dextroamphetamine_Ilic2022_reference;
