function p = Dextroamphetamine_Ermer2020_single_lisdexamfetamine_dose_20_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dextroamphetamine   source: Ermer_2020 / single_lisdexamfetamine_dose_20_mg_japanese   route: oral
  % estimated (absent from source): ka
  p.name  = 'Dextroamphetamine_Ermer2020_single_lisdexamfetamine_dose_20_params';
  p.drug  = 'dextroamphetamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2207.0;                % central volume [L]
  p.CL = 59.46;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
