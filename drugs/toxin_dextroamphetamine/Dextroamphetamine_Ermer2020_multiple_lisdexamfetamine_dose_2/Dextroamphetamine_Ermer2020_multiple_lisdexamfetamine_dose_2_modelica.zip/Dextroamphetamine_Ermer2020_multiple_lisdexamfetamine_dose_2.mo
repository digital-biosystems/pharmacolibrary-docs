model Dextroamphetamine_Ermer2020_multiple_lisdexamfetamine_dose_2
  parameter Real Cl_ref = 1.7494444444444442e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.207 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.13521,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dextroamphetamine</td></tr><tr><td>population:</td><td>Japanese and Caucasian healthy adult subjects</td></tr><tr><td>source_paper:</td><td>Ermer_2020</td></tr><tr><td>measured_compound:</td><td>d-amphetamine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>npr212082-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>d-amphetamine 135.21 g/mol (pubchem); dextroamphetamine 135.21 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('Weight‐adjusted CL/F, L/h/kg', value '1.00') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=d-amphetamine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'multiple lisdexamfetamine dose / 20 mg/d / japanese (n = 11)' subgroup of Ermer_2020 (paper reports 7 populations: multiple lisdexamfetamine dose / 20 mg/d / caucasian (n = 14), multiple lisdexamfetamine dose / 20 mg/d / japanese (n = 11), multiple lisdexamfetamine dose / 50 mg/d / caucasian (n = 12), multiple lisdexamfetamine dose / 50 mg/d / japanese (n = 11), multiple lisdexamfetamine dose / 70 mg/d / caucasian (n = 11), multiple lisdexamfetamine dose / 70 mg/d / japanese (n = 10), single lisdexamfetamine dose / 20 mg / japanese (n = 12))</li><li>gap-filled Q76 (V/F) from Childress_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG from Kämmerer_2024: its label names a different analyte ('lag') — 'Prolongation of lag time (t lag ) (LDX vs dexamphetamine)'</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Childress_2020 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Dextroamphetamine_Ermer2020_multiple_lisdexamfetamine_dose_2;
