function p = SodiumStibogluconate_Jaser1995_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_stibogluconate   source: Jaser_1995 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'SodiumStibogluconate_Jaser1995_reference_params';
  p.drug  = 'sodium_stibogluconate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 45.7;                % central volume [L]
  p.CL = 17.67;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 850.0;             % dose [mg]
end
