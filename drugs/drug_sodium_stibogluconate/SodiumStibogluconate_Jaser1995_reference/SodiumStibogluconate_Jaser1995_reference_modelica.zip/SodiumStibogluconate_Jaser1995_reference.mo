model SodiumStibogluconate_Jaser1995_reference
  parameter Real Cl_ref = 4.9083333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045700000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00085
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sodium_stibogluconate</h4><p>Sodium stibogluconate is a pentavalent antimonial medication used to treat leishmaniasis. It is administered via intramuscular injection.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q2757844\">Wikidata Q2757844</a>, <a href=\"https://en.wikipedia.org/wiki/Sodium_stibogluconate?oldid=1363161171\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_stibogluconate</td></tr><tr><td>population:</td><td>patients with cutaneous leishmaniasis</td></tr><tr><td>source_paper:</td><td>Jaser_1995</td></tr><tr><td>measured_compound:</td><td>antimony</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sodium_stibogluconate 907.88 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for kabs from footnote/prose kept as documentation only (['Jaser_1995:abstract'])</li><li>covariate category for kel from footnote/prose kept as documentation only (['Jaser_1995:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=antimony</li><li>molar mass: no plausible PubChem entry for 'antimony' ('antimony') — left in mass units</li><li>molar mass: none found for 'antimony' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SodiumStibogluconate_Jaser1995_reference;
