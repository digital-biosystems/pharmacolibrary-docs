model Infliximab_Song2025_reference
  parameter Real Cl_ref = 2.8703703703703706e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0018700000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.667,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.60648148148148e-07,
    Tlag = 0.0,
    k12 = 3.7074173103584865e-06,
    k21 = 3.5371787603930464e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About infliximab</h4><p>Infliximab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, Crohn's disease, ulcerative colitis, psoriasis, and ankylosing spondylitis. It is approved and widely used, with several products authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415264\">Wikidata Q415264</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>patients with inflammatory bowel disease</td></tr><tr><td>source_paper:</td><td>Song_2025</td></tr><tr><td>measured_compound:</td><td>infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Infliximab_Song2025_reference;
