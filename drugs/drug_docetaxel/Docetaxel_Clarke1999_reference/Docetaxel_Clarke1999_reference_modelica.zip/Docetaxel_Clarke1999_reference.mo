model Docetaxel_Clarke1999_reference
  parameter Real Cl_ref = 6.11111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.074 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8078792,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About docetaxel</h4><p>Docetaxel is a taxane chemotherapy drug used to treat several cancers, including breast, ovarian, lung, stomach, pancreatic, head and neck cancers and melanoma. It is widely used worldwide, is included on the WHO essential medicines list, and remains authorised in the European Union for several cancer types.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420436\">Wikidata Q420436</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>adults and children with cancer</td></tr><tr><td>source_paper:</td><td>Clarke_1999</td></tr><tr><td>measured_compound:</td><td>docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.879 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/m2' (V)</li><li>unit_dimension_unknown: 'L/h/m2' (CL)</li><li>covariate category for CL from footnote/prose kept as documentation only (['Clarke_1999:abstract'])</li><li>implicit units: 'mean volume of distribution' → L (from the popPK convention: 'The parameter is the mean volume of distribution. In population pharmacokinetics, volume parameters are standardly expre')</li><li>implicit units: 'mean total body clearance' → L/h (from the popPK convention: 'The parameter is the mean total body clearance. In population pharmacokinetics, clearance parameters are standardly expr')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=docetaxel</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Clarke1999_reference;
