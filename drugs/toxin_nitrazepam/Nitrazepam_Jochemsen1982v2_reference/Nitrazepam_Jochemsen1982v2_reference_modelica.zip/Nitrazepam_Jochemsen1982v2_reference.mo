model Nitrazepam_Jochemsen1982v2_reference
  parameter Real Cl_ref = 9.883333333333331e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.281271,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nitrazepam</td></tr><tr><td>population:</td><td>healthy young males and females, with and without oral contraceptives</td></tr><tr><td>source_paper:</td><td>Jochemsen_1982_2</td></tr><tr><td>measured_compound:</td><td>Nitrazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>nitrazepam 281.271 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('elimination half-life in females in the follicular phase', value 27.7) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life in females in the luteal phase of the menstrual cycle', value 29.6) — already have one for this compound</li><li>dropped duplicate Q22 ('Total plasma clearance in females in the follicular phase', value 58.2) — already have one for this compound</li><li>dropped duplicate Q22 ('Total plasma clearance in females in the luteal phase', value 55.8) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life of nitrazepam in the first half of the pill cycle', value 30.6) — already have one for this compound</li><li>dropped duplicate Q22 ('The total nitrazepam clearance in these females (first half of the pill cycle)', value 46.6) — already have one for this compound</li><li>dropped duplicate Q22 ('The total nitrazepam clearance in these females (second half of the pill cycle)', value 45.6) — already have one for this compound</li><li>dropped duplicate Q22 ('Cli in females using OC-steroids', value 323) — already have one for this compound</li><li>dropped duplicate Q22 ('Cli in males', value 530) — already have one for this compound</li><li>dropped duplicate Q22 ('Cli in females not taking OC-steroids', value 459) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nitrazepam</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Vikingsson_2017's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Nitrazepam_Jochemsen1982v2_reference;
