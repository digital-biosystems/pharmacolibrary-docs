model Nitrazepam_Jochemsen1983_reference
  parameter Real Cl_ref = 9.833333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.20510000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.281271,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nitrazepam</td></tr><tr><td>population:</td><td>healthy young adults, healthy elderly subjects and patients with alcoholic liver cirrhosis</td></tr><tr><td>source_paper:</td><td>Jochemsen_1983</td></tr><tr><td>measured_compound:</td><td>Nitrazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>nitrazepam 281.271 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'elimination half-life of nitrazepam in the elderly subjects'</li><li>dropped duplicate Q61 ('volume of distribution, young group', value 1.89) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half life, healthy subjects', value 31) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance, healthy subjects', value 63) — already have one for this compound</li><li>dropped duplicate Q61 ('volume of distribution, healthy subjects', value 2.38) — already have one for this compound</li><li>dropped duplicate Q22 ('Clearance calculated relative to unbound nitrazepam (intrinsic clearance), patient group', value 320) — already have one for this compound</li><li>dropped duplicate Q22 ('Clearance calculated relative to unbound nitrazepam (intrinsic clearance), healthy subjects', value 472) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nitrazepam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Nitrazepam_Jochemsen1983_reference;
