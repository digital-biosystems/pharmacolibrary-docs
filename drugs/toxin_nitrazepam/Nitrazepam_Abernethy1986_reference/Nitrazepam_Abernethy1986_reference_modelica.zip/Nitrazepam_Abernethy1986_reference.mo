model Nitrazepam_Abernethy1986_reference
  parameter Real Cl_ref = 1.6833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.29 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.281271,
    adminMass = 5e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nitrazepam</td></tr><tr><td>population:</td><td>obese and normal body weight adult subjects</td></tr><tr><td>source_paper:</td><td>Abernethy_1986</td></tr><tr><td>measured_compound:</td><td>nitrazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>nitrazepam 281.271 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Elimination half-life (control)', value 23.9) — already have one for this compound</li><li>dropped duplicate Q27 ('Oral clearance (control)', value 66.8) — already have one for this compound</li><li>covariate body weight for V from footnote/prose kept as documentation only (['Abernethy_1986:abstract'])</li><li>covariate body weight for Vnorm from footnote/prose kept as documentation only (['Abernethy_1986:abstract'])</li><li>covariate body weight for CLnorm from footnote/prose kept as documentation only (['Abernethy_1986:abstract'])</li><li>covariate body weight for CLnorm from footnote/prose kept as documentation only (['Abernethy_1986:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nitrazepam</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Nitrazepam_Abernethy1986_reference;
