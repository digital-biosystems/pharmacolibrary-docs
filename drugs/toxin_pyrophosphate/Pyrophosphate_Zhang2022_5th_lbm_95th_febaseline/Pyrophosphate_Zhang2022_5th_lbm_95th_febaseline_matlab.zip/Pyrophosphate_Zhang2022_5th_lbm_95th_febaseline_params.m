function p = Pyrophosphate_Zhang2022_5th_lbm_95th_febaseline_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pyrophosphate   source: Zhang_2022 / 5th_lbm_95th_febaseline   route: oral
  % estimated (absent from source): dose
  p.name  = 'Pyrophosphate_Zhang2022_5th_lbm_95th_febaseline_params';
  p.drug  = 'pyrophosphate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.62;                % central volume [L]
  p.CL = 0.477;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4212.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.522;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
