% Run (SimBiology): build model + dose, simulate 0..27.0 h, plot.
p = Pyrophosphate_Zhang2022_5th_453_32_ng_ml_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 27.0);
