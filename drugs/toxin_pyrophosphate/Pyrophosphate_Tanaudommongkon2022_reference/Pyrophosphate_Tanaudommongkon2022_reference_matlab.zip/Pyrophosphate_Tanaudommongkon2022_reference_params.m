function p = Pyrophosphate_Tanaudommongkon2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pyrophosphate   source: Tanaudommongkon_2022 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Pyrophosphate_Tanaudommongkon2022_reference_params';
  p.drug  = 'pyrophosphate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.9;                % central volume [L]
  p.CL = 19.8;                % clearance [L/h]
  p.Vp = [76.1];             % peripheral volumes [L]
  p.Q  = [7.89];             % inter-compartmental clearances [L/h]
  p.ka = 3.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.522;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
