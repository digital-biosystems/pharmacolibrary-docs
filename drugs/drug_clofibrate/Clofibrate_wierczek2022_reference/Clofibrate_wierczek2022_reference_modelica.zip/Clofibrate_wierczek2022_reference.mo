model Clofibrate_wierczek2022_reference
  parameter Real Cl_ref = 0.0005133333333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 0.609 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24269900000000003,
    adminMass = 0.002,
    ka = 0.009666666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clofibrate</h4><p>Clofibrate is a fibrate lipid-lowering drug that was used to treat high blood lipid levels such as hypertriglyceridemia and familial hyperlipidemia, as well as related conditions like arteriosclerosis and coronary artery disease. It has been withdrawn from the market, largely because of concerns about lack of benefit and safety issues including cancer-causing potential.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2701912\">Wikidata Q2701912</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clofibrate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Świerczek_2022</td></tr><tr><td>measured_compound:</td><td>clofibrate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clofibrate 242.699 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Świerczek_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clofibrate_wierczek2022_reference;
