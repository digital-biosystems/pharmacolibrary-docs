function p = Clofibrate_wierczek2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clofibrate   source: Świerczek_2022 / reference   route: oral
  p.name  = 'Clofibrate_wierczek2022_reference_params';
  p.drug  = 'clofibrate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 609.0;                % central volume [L]
  p.CL = 1848.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 34.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
