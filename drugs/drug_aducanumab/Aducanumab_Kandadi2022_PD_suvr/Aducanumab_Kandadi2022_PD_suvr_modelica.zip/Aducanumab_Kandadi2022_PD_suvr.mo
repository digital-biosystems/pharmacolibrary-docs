model Aducanumab_Kandadi2022_PD_suvr
  "indirect_response_iv exposure-response sweep — Kandadi_2022 :: SUVR (composite SUVR)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 1.4,      // [1]
    Emax = 0.702,  // type IV effect term
    EC50 = 0.0464,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 280, Interval = 0.56),
    Documentation(info = "<html><body><!-- drug-about --><h4>About aducanumab</h4><p>Aducanumab is a monoclonal antibody against beta-amyloid that was developed to treat Alzheimer's disease. Its marketing application was withdrawn in the European Union, and it is not in routine use there.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708278\">Wikidata Q15708278</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Aducanumab_Kandadi2022_PD_suvr</h4><p>The steady-state exposure-response curve of Kandadi Muralidharan K et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(1):7–19</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12728\">doi:10.1002/psp4.12728</a>) — composite SUVR against aducanumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        1.4          drug-free response (baseline) (BL, Q324)
  Emax  =      0.702          maximal effect term (Emax, Q320)
  EC50  =       46.4 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg/L of aducanumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.4   (drug-free)
  exposure = EC50 (46.4 mg/L)  response 1.036
  exposure -> infinity  response 0.8226</pre></body></html>"));
end Aducanumab_Kandadi2022_PD_suvr;
