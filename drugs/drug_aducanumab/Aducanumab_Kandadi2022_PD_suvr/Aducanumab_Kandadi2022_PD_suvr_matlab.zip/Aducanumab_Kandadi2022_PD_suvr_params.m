function p = Aducanumab_Kandadi2022_PD_suvr_params()
% Aducanumab_Kandadi2022_PD_suvr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% aducanumab Kandadi_2022::SUVR: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response SUVR in its own unit. Driver: aducanumab (pk_record).
p.E0 = 1.4;
p.Emax = 0.702;
p.EC50 = 0.04639999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 280.0;
p.form = 'E0/(1 + Emax*frac)';
end
