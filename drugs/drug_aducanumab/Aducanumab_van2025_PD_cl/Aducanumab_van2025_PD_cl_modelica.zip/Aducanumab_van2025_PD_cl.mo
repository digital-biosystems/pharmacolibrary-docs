model Aducanumab_van2025_PD_cl
  "indirect_response_iii exposure-response sweep — van_2025 :: CL (amyloid plaque burden)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 96.5517241379,      // [CL]
    Emax = 78.7,  // type III effect term
    EC50 = 24.1,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.028/0.00029 = 96.55) — the paper's stated baseline may differ
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 250, Interval = 0.5),
    Documentation(info = "<html><body><!-- drug-about --><h4>About aducanumab</h4><p>Aducanumab is a monoclonal antibody against beta-amyloid that was developed to treat Alzheimer's disease. Its marketing application was withdrawn in the European Union, and it is not in routine use there.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708278\">Wikidata Q15708278</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Aducanumab_van2025_PD_cl</h4><p>The steady-state exposure-response curve of van Maanen E et al., <i>Alzheimer's &amp; dementia (New York, N. Y.) 11(4):e70169</i> 2025 (<a href=\"https://doi.org/10.1002/trc2.70169\">doi:10.1002/trc2.70169</a>) — amyloid plaque burden [CL] against aducanumab nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 96.5517241379 CL       drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       78.7          maximal effect term (inhibition, Q323)
  EC50  =       24.1 nM       exposure at half of the maximal effect term (half‐maximal inhibitory concentration of verubecestat for CSF biomarker effects (Aβ40, Aβ42, sAPPβ), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of aducanumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96.55   (drug-free)
  exposure = EC50 (24.1 nM)  response 3896
  exposure -> infinity  response 7695</pre></body></html>"));
end Aducanumab_van2025_PD_cl;
