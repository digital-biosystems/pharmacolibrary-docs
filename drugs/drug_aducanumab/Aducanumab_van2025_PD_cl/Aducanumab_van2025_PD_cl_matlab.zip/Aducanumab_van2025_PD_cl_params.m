function p = Aducanumab_van2025_PD_cl_params()
% Aducanumab_van2025_PD_cl_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% aducanumab van_2025::CL: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response CL in CL. Driver: aducanumab (cited_pk).
p.E0 = 96.55172413793103;
p.Emax = 78.7;
p.EC50 = 24.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 250.0;
p.form = 'E0*(1 + Emax*frac)';
end
