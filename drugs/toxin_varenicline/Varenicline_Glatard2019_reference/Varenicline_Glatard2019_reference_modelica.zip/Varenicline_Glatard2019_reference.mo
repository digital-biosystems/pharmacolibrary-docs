model Varenicline_Glatard2019_reference
  parameter Real Cl_ref = 2.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.228 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211268,
    adminMass = 2e-06,
    ka = 0.0002722222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>varenicline</td></tr><tr><td>population:</td><td>smokers from the general population</td></tr><tr><td>source_paper:</td><td>Glatard_2019</td></tr><tr><td>measured_compound:</td><td>Varenicline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>varenicline 211.268 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h<sup>-1</sup>' (kabs)</li><li>implicit units: 'absorption rate (k<sub>a</sub>)' → 1/h (from the popPK convention: 'Absorption rate constant (ka) is a first-order rate constant. The standard unit is inverse time, and the magnitude 0.98 ')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Varenicline</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Varenicline_Glatard2019_reference;
