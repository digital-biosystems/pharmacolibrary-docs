model Varenicline_Fediuk2021_reference
  parameter Real Cl_ref = 3.4722222222222224e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.231 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211268,
    adminMass = 5e-07,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>varenicline</td></tr><tr><td>population:</td><td>adolescent smokers</td></tr><tr><td>source_paper:</td><td>Fediuk_2021</td></tr><tr><td>measured_compound:</td><td>Varenicline</td></tr><tr><td>parameterization:</td><td>apparent_wrt_Fm</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>PSP4-10-769-s003.docx</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>varenicline 211.268 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>control_stream: no THETA→param binding found in $PK — route_to_review</li><li>$THETA(1) has no $PK binding — index may be misassigned</li><li>$THETA(2) has no $PK binding — index may be misassigned</li><li>$THETA(3) has no $PK binding — index may be misassigned</li><li>$THETA(4) has no $PK binding — index may be misassigned</li><li>$THETA(5) has no $PK binding — index may be misassigned</li><li>$THETA(6) has no $PK binding — index may be misassigned</li><li>$THETA(7) has no $PK binding — index may be misassigned</li><li>$THETA(8) has no $PK binding — index may be misassigned</li><li>$THETA(9) has no $PK binding — index may be misassigned</li><li>apparent-ness: parameterization=apparent_wrt_Fm (metabolite model)</li><li>theta_crosscheck: table present but its labels did not align to bound THETAs (skipped)</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q27 (CL/F) from Fediuk_2021's review values (primary lacked it)</li><li>gap-filled Q76 (V/F) from Fediuk_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Varenicline_Fediuk2021_reference;
