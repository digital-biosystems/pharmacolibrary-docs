model Varenicline_Wu2022_result_of_fit_1
  parameter Real Cl_ref = 2.7780555555555553e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.194352 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211268,
    adminMass = 6e-08,
    ka = 0.0002877777777777778,
    Tlag = 1335.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>varenicline</td></tr><tr><td>population:</td><td>Virtual subjects (American and Chinese)</td></tr><tr><td>source_paper:</td><td>Wu_2022</td></tr><tr><td>measured_compound:</td><td>Varenicline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>varenicline 211.268 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (Vc); Q22 (CL)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Varenicline</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc' is the general volume)</li><li>population split: 'result of fit 1' subgroup of Wu_2022 (paper reports 2 populations: result of fit 1, result of fit 2)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Varenicline_Wu2022_result_of_fit_1;
