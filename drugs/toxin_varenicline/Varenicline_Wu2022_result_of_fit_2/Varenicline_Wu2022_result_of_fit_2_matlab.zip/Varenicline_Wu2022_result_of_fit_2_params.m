function p = Varenicline_Wu2022_result_of_fit_2_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: varenicline   source: Wu_2022 / result_of_fit_2   route: oral
  % estimated (absent from source): F
  p.name  = 'Varenicline_Wu2022_result_of_fit_2_params';
  p.drug  = 'varenicline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 190.823;                % central volume [L]
  p.CL = 11.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.064;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.156;             % absorption lag [h]
  p.dose = 0.06;             % dose [mg]
end
