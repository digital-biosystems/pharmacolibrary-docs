% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Varenicline_Wu2022_result_of_fit_2_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
