model Creatine_Alraddadi2018_reference
  parameter Real Cl_ref = 1.4166666666666666e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02128 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 15.69,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    ka = 0.0017972222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>creatine</td></tr><tr><td>population:</td><td>adult male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Alraddadi_2018</td></tr><tr><td>measured_compound:</td><td>Creatine-13C</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-10-00031-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>creatine 131.135 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'R2 value (model vs. observed)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-10-00031-t001:row9:col1', 'pharmaceutics-10-00031-t001:row9:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Creatine-13C</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'Creatine-13C' ('creatine-13C') — left in mass units</li><li>molar mass: none found for 'Creatine-13C' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Yu_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Creatine_Alraddadi2018_reference;
