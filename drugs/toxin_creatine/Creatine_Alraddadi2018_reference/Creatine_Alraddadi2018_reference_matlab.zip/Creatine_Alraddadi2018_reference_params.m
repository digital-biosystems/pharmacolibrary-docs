function p = Creatine_Alraddadi2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: creatine   source: Alraddadi_2018 / reference   route: oral
  p.name  = 'Creatine_Alraddadi2018_reference_params';
  p.drug  = 'creatine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.28;                % central volume [L]
  p.CL = 0.051;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.47;                % absorption rate [1/h]
  p.F  = 0.1569;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
