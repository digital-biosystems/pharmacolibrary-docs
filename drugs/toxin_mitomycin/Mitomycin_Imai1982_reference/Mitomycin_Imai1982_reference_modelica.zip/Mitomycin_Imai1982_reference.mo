// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Mitomycin_Imai1982_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1074.0},
    MM = 0.42642899999999995,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitomycin</td></tr><tr><td>population:</td><td>normal mice</td></tr><tr><td>source_paper:</td><td>Imai_1982</td></tr><tr><td>measured_compound:</td><td>7-N-(p-hydroxyphenyl)-mitomycin C (M-83)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>7-N-(p-hydroxyphenyl)-mitomycin C (M-83) 426.429 g/mol (pubchem); mitomycin 334.332 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-lives (MMC)', value 19.8) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life of M-83 (10.2 mg/kg) after iv bolus injection', value 7.5) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives', value '18.85') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=7-N-(p-hydroxyphenyl)-mitomycin C (M-83)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Sui_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Mitomycin_Imai1982_reference;
