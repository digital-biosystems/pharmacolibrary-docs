% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Mitomycin_Prasad2025_geometric_mean_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
