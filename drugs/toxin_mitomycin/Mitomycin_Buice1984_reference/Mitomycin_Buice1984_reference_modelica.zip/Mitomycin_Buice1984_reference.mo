model Mitomycin_Buice1984_reference
  parameter Real Cl_ref = 2.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045975999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.334332,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitomycin</td></tr><tr><td>population:</td><td>six male patients receiving mitomycin C in combination with cisplatin and vinblastine for non-oat cell carcinoma of the lung</td></tr><tr><td>source_paper:</td><td>Buice_1984</td></tr><tr><td>measured_compound:</td><td>Mitomycin C</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Mitomycin C 334.332 g/mol (pubchem); mitomycin 334.332 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml X kg-1 X min-1' (CL)</li><li>implicit units: 'total body clearance' → L/h (from the popPK convention: 'The paper provides no text or footnotes stating units. For total body clearance in population pharmacokinetics, the magn')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mitomycin C</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mitomycin_Buice1984_reference;
