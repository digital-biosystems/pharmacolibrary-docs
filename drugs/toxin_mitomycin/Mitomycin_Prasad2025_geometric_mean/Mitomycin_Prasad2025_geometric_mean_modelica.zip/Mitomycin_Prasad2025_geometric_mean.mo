model Mitomycin_Prasad2025_geometric_mean
  parameter Real Cl_ref = 0.0007533527777777778 "Cl [m3/s]";
  parameter Real Vd_ref = 3.1374400000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.334332,
    adminMass = 7.5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitomycin</td></tr><tr><td>population:</td><td>patients with NMIBC</td></tr><tr><td>source_paper:</td><td>Prasad_2025</td></tr><tr><td>measured_compound:</td><td>Mitomycin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>mitomycin 334.332 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Mitomycin</li><li>population split: 'geometric mean' subgroup of Prasad_2025 (paper reports 2 populations: geometric mean, geometric mean (cv))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mitomycin_Prasad2025_geometric_mean;
