% Run (SimBiology): build model + dose, simulate 0..31.0 h, plot.
p = Sufentanil_Khaowroongrueng2024_estimatecpb_adjusted_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 31.0);
