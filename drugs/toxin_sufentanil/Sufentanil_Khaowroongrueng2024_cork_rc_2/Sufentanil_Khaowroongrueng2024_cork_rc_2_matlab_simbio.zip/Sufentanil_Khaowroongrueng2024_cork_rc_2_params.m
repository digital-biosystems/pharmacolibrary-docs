function p = Sufentanil_Khaowroongrueng2024_cork_rc_2_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sufentanil   source: Khaowroongrueng_2024 / cork_rc_2   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Sufentanil_Khaowroongrueng2024_cork_rc_2_params';
  p.drug  = 'sufentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.49;                % central volume [L]
  p.CL = 65.1;                % clearance [L/h]
  p.Vp = [92.7];             % peripheral volumes [L]
  p.Q  = [41.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
