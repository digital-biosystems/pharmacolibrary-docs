model Sufentanil_Khaowroongrueng2024_final_model_estimate
  parameter Real Cl_ref = 1.4388888888888888e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0725 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38655399999999995,
    adminMass = 1e-05,
    k12 = 0.00021149425287356324,
    k21 = 3.931623931623932e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sufentanil</td></tr><tr><td>population:</td><td>adult Korean patients undergoing cardiac surgery with cardiopulmonary bypass</td></tr><tr><td>source_paper:</td><td>Khaowroongrueng_2024</td></tr><tr><td>measured_compound:</td><td>Sufentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413205-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sufentanil 386.554 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL CPB&warming', value '2.80') — already have one for this compound</li><li>dropped duplicate Q63 ('V1 CPB', value '2.74') — already have one for this compound</li><li>routed 'RSV σprop (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sufentanil</li><li>population split: 'final model / estimate' subgroup of Khaowroongrueng_2024 (paper reports 10 populations: bovill jg (1984) [1], cork rc (1988) [2], estimatecpb adjusted model, ethuin f (2003) [5], final model / estimate, gepts e (1995) [4], hahn j (2019)ecmo [8], hudson rj (2004) cpb adjusted model [6], jeleazcov c (2012) cpb adjusted model [7], lehmann ka (1993) [3])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sufentanil_Khaowroongrueng2024_final_model_estimate;
