% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Sufentanil_Khaowroongrueng2024_ethuin_f_5_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
