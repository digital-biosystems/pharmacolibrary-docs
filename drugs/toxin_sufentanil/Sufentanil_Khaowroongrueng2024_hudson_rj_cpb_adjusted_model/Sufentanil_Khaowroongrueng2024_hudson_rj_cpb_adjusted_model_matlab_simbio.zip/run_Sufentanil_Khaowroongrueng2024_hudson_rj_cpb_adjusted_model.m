% Run (SimBiology): build model + dose, simulate 0..35.0 h, plot.
p = Sufentanil_Khaowroongrueng2024_hudson_rj_cpb_adjusted_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 35.0);
