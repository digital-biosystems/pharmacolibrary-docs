function p = Sufentanil_Khaowroongrueng2024_jeleazcov_c_cpb_adjusted_mode_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sufentanil   source: Khaowroongrueng_2024 / jeleazcov_c_cpb_adjusted_model_7   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Sufentanil_Khaowroongrueng2024_jeleazcov_c_cpb_adjusted_mode_params';
  p.drug  = 'sufentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 18.0;                % central volume [L]
  p.CL = 42.0;                % clearance [L/h]
  p.Vp = [232.0];             % peripheral volumes [L]
  p.Q  = [41.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
