model Sufentanil_Khaowroongrueng2024_lehmann_ka_3
  parameter Real Cl_ref = 1.5166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.231 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38655399999999995,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sufentanil</td></tr><tr><td>population:</td><td>adult Korean patients undergoing cardiac surgery with cardiopulmonary bypass</td></tr><tr><td>source_paper:</td><td>Khaowroongrueng_2024</td></tr><tr><td>measured_compound:</td><td>Sufentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413205-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sufentanil 386.554 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'No. of Compartment' — extend the ontology if this is a real PK parameter (source ['Khaowroongrueng_2024_table_S3:row1:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sufentanil</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'lehmann ka (1993) [3]' subgroup of Khaowroongrueng_2024 (paper reports 10 populations: bovill jg (1984) [1], cork rc (1988) [2], estimatecpb adjusted model, ethuin f (2003) [5], final model / estimate, gepts e (1995) [4], hahn j (2019)ecmo [8], hudson rj (2004) cpb adjusted model [6], jeleazcov c (2012) cpb adjusted model [7], lehmann ka (1993) [3])</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sufentanil_Khaowroongrueng2024_lehmann_ka_3;
