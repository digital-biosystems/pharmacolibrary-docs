function p = Sufentanil_Khaowroongrueng2024_bovill_jg_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sufentanil   source: Khaowroongrueng_2024 / bovill_jg_1   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Sufentanil_Khaowroongrueng2024_bovill_jg_1_params';
  p.drug  = 'sufentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.5;                % central volume [L]
  p.CL = 53.2;                % clearance [L/h]
  p.Vp = [92.7];             % peripheral volumes [L]
  p.Q  = [41.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
