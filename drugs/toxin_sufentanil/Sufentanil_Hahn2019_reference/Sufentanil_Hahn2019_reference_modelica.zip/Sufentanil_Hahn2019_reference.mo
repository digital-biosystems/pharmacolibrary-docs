model Sufentanil_Hahn2019_reference
  parameter Real Cl_ref = 1.05e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38655399999999995,
    adminMass = 1e-05,
    k12 = 4.973313925278991e-05,
    k21 = 6.944444444444445e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sufentanil</td></tr><tr><td>population:</td><td>critically ill adult patients supported with venoarterial ECMO</td></tr><tr><td>source_paper:</td><td>Hahn_2019</td></tr><tr><td>measured_compound:</td><td>Sufentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sufentanil 386.554 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q63 ('V1'=229) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q'=41) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('CL'=37.8) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2'=1640) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sufentanil</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sufentanil_Hahn2019_reference;
