model Amiodarone_Lehnert2022_reference
  parameter Real Cl_ref = 1.7555555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.167 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6453116,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>paediatric patients with arrhythmias</td></tr><tr><td>source_paper:</td><td>Lehnert_2022</td></tr><tr><td>measured_compound:</td><td>amiodarone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amiodarone 645.312 g/mol (drugbank); N-desethylamiodarone 617.257 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>routed 'clearance between subject variability (ω, square root of the variance)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amiodarone</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Amiodarone_Lehnert2022_reference;
