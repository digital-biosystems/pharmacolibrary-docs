function p = Amiodarone_Lehnert2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amiodarone   source: Lehnert_2022 / reference   route: iv_bolus
  p.name  = 'Amiodarone_Lehnert2022_reference_params';
  p.drug  = 'amiodarone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 167.0;                % central volume [L]
  p.CL = 6.32;                % clearance [L/h]
  p.Vp = [3930.0];             % peripheral volumes [L]
  p.Q  = [7.14];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.362;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
