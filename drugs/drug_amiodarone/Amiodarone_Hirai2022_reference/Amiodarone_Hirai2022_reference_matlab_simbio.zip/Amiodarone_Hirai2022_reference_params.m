function p = Amiodarone_Hirai2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amiodarone   source: Hirai_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amiodarone_Hirai2022_reference_params';
  p.drug  = 'amiodarone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 980.0;                % central volume [L]
  p.CL = 7.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
