model Amiodarone_Kolowrat2025_reference
  parameter Real Cl_ref = 3.6666666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04345 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6453116,
    adminMass = 0.0002,
    ka = 0.00022777777777777775,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amiodarone</h4><p>Amiodarone is an antiarrhythmic medicine used to treat and prevent various types of irregular heartbeat, including ventricular tachycardia, atrial fibrillation, and other arrhythmias. It is widely used, is included on the WHO list of essential medicines, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410061\">Wikidata Q410061</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kolowrat_2025</td></tr><tr><td>measured_compound:</td><td>amiodarone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amiodarone 645.312 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kolowrat_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Amiodarone_Kolowrat2025_reference;
