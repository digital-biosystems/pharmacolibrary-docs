model Amiodarone_Sermsappasuk2006_PD_lvdp
  "sigmoid_emax exposure-response sweep — Sermsappasuk_2006 :: LVDP (left ventricular developed pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.37,  // [1; % × 0.01]
    EC50 = 0.53,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.3, Interval = 0.0106),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amiodarone</h4><p>Amiodarone is an antiarrhythmic medicine used to treat and prevent various types of irregular heartbeat, including ventricular tachycardia, atrial fibrillation, and other arrhythmias. It is widely used, is included on the WHO list of essential medicines, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410061\">Wikidata Q410061</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amiodarone_Sermsappasuk2006_PD_lvdp</h4><p>The steady-state exposure-response curve of Sermsappasuk P et al., <i>European journal of pharmaceutical sciences : official journal of the European Federation for Pharmaceutical Sciences 28(3):243–248</i> 2006 (<a href=\"https://doi.org/10.1016/j.ejps.2006.02.007\">doi:10.1016/j.ejps.2006.02.007</a>) — left ventricular developed pressure [%] against amiodarone M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         37 %        maximal effect term (E max, Q323)
  EC50  =       0.53 M        exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of amiodarone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.53 M)  response -0.185
  exposure -> infinity  response -0.37</pre></body></html>"));
end Amiodarone_Sermsappasuk2006_PD_lvdp;
