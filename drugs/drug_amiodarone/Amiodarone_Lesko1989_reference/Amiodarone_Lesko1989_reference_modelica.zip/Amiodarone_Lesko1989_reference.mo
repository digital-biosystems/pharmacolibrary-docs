model Amiodarone_Lesko1989_reference
  parameter Real Cl_ref = 8.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16501545877687962 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6453116,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amiodarone</h4><p>Amiodarone is an antiarrhythmic medicine used to treat and prevent various types of irregular heartbeat, including ventricular tachycardia, atrial fibrillation, and other arrhythmias. It is widely used, is included on the WHO list of essential medicines, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410061\">Wikidata Q410061</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Lesko_1989</td></tr><tr><td>measured_compound:</td><td>amiodarone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amiodarone 645.312 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Lesko_1989) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amiodarone_Lesko1989_reference;
