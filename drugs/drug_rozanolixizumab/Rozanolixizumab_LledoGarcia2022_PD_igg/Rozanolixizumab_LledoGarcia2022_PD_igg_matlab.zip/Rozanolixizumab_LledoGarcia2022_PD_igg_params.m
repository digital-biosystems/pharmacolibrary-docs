function p = Rozanolixizumab_LledoGarcia2022_PD_igg_params()
% Rozanolixizumab_LledoGarcia2022_PD_igg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rozanolixizumab Lledo-Garcia_2022::IgG: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response IgG in mg/ml. Driver: rozanolixizumab (pk_record).
p.E0 = 9.879999999999999;
p.Emax = 4.24;
p.EC50 = 0.00015399999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.3;
p.form = 'E0/(1 + Emax*frac)';
end
