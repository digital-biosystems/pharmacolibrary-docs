model Rozanolixizumab_LledoGarcia2022_PD_igg
  "indirect_response_iv exposure-response sweep — Lledo-Garcia_2022 :: IgG (IgG)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 9.88,      // [kg/m3; mg/ml × 1]
    Emax = 4.24,  // type IV effect term
    EC50 = 0.000154,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.3, Interval = 0.0006),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rozanolixizumab</h4><p>Rozanolixizumab is a monoclonal antibody used to treat myasthenia gravis. It is an authorised medicine in the European Union, given as an immunosuppressant that blocks the neonatal Fc receptor.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q120491843\">Wikidata Q120491843</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Rozanolixizumab_LledoGarcia2022_PD_igg</h4><p>The steady-state exposure-response curve of Lledo-Garcia R et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(1):116–128</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12739\">doi:10.1002/psp4.12739</a>) — IgG [mg/ml] against rozanolixizumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       9.88 mg/ml    drug-free response (baseline) (IgG base, Q324)
  Emax  =       4.24          maximal effect term (Emax, Q320)
  EC50  =      0.154 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg/L of rozanolixizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 9.88   (drug-free)
  exposure = EC50 (0.154 mg/L)  response 3.167
  exposure -> infinity  response 1.885</pre></body></html>"));
end Rozanolixizumab_LledoGarcia2022_PD_igg;
