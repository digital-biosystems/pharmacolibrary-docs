// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ZincOxide_Creutzenberg2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2592000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zinc_oxide</td></tr><tr><td>population:</td><td>Wistar rats</td></tr><tr><td>source_paper:</td><td>Creutzenberg_2022</td></tr><tr><td>measured_compound:</td><td>zinc (Zn)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 1 (retention half-times of test items in lungs)</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>zinc_oxide 81.379 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>substance matrix Creutzenberg_2022_table_1 ('TABLE 1 | Retention half-times of test items in lungs.'): no row names this substance — its 3 row(s) (Low dose, Mid dose, High dose) are other substances' values; none taken</li><li>salvaged Q57 ('actual half-times'=30) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=zinc (Zn)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'zinc (Zn)' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'zinc (Zn)', not zinc_oxide — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 13305600, Tolerance = 1e-9, Interval = 26611.2));
end ZincOxide_Creutzenberg2022_reference;
