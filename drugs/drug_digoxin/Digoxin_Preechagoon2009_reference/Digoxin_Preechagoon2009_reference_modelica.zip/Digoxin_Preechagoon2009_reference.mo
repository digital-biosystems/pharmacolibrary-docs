model Digoxin_Preechagoon2009_reference
  parameter Real Cl_ref = 4.336111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.029259999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0006361111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>digoxin</td></tr><tr><td>population:</td><td>Thai pediatric patients with heart disease</td></tr><tr><td>source_paper:</td><td>Preechagoon_2009</td></tr><tr><td>measured_compound:</td><td>digoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for CL/F from footnote/prose kept as documentation only (['Preechagoon_2009:abstract'])</li><li>covariate category for CL/F from footnote/prose kept as documentation only (['Preechagoon_2009:abstract'])</li><li>covariate category for V/F from footnote/prose kept as documentation only (['Preechagoon_2009:abstract'])</li><li>routed 'intraindividual variability with proportional error model' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=digoxin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Dong_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Dong_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Dong_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Digoxin_Preechagoon2009_reference;
