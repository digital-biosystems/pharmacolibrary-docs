function p = Digoxin_Ishibashi2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: digoxin   source: Ishibashi_2024 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Digoxin_Ishibashi2024_reference_params';
  p.drug  = 'digoxin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.7;                % central volume [L]
  p.CL = 0.211;                % clearance [L/h]
  p.Vp = [2.5];             % peripheral volumes [L]
  p.Q  = [0.539];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
