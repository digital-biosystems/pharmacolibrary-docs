function p = Digoxin_MartnSurez1993_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: digoxin   source: Martín-Suárez_1993 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Digoxin_MartnSurez1993_reference_params';
  p.drug  = 'digoxin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 542.92;                % central volume [L]
  p.CL = 8.73;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.29;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
