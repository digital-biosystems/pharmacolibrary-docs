function p = Nirmatrelvir_Chen2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nirmatrelvir   source: Chen_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Nirmatrelvir_Chen2024_reference_params';
  p.drug  = 'nirmatrelvir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 36.5;                % central volume [L]
  p.CL = 3.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.42;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
