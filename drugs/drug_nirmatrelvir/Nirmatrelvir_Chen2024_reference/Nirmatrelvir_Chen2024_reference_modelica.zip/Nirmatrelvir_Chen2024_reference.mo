model Nirmatrelvir_Chen2024_reference
  parameter Real Cl_ref = 1.0000000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0365 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.499535,
    adminMass = 0.00015,
    ka = 0.00011666666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nirmatrelvir</h4><p>It is an approved medicine, widely used in combination with ritonavir for the treatment of the disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106405348\">Wikidata Q106405348</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nirmatrelvir</td></tr><tr><td>population:</td><td>critically ill adults with COVID-19</td></tr><tr><td>source_paper:</td><td>Chen_2024</td></tr><tr><td>measured_compound:</td><td>nirmatrelvir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nirmatrelvir 499.535 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CorrV-CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CorrV-CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'stdev' routed out of structural estimates ('Residual variability (σ)')</li><li>table section residual_error: 'stdev' routed out of structural estimates ('Residual variability (σ)')</li><li>table section residual_error: 'stdev' routed out of structural estimates ('Residual variability (σ)')</li><li>table section residual_error: 'stdev' routed out of structural estimates ('Residual variability (σ)')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CorrV-CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CorrV-CL' routed out of structural estimates ('Inter-individual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Nirmatrelvir_Chen2024_reference;
