function p = Nirmatrelvir_Esmaeili2024_PD_v_params()
% Nirmatrelvir_Esmaeili2024_PD_v_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nirmatrelvir Esmaeili_2024::V: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response V in log10 copies/ml. Driver: nirmatrelvir (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.037;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.37;
p.form = 'E0 + Emax*frac';
end
