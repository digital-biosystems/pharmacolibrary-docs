model Nirmatrelvir_Esmaeili2024_PD_v
  "sigmoid_emax exposure-response sweep — Esmaeili_2024 :: V (viral load)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [log10 copies/ml]
    EC50 = 0.037,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.37, Interval = 0.00074),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nirmatrelvir</h4><p>It is given orally as a tablet. It is an approved antiviral medication.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q106405348\">Wikidata Q106405348</a>, <a href=\"https://en.wikipedia.org/wiki/Nirmatrelvir?oldid=1371301069\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Nirmatrelvir_Esmaeili2024_PD_v</h4><p>The steady-state exposure-response curve of Esmaeili S et al., <i>Nature communications 15(1):5478</i> 2024 (<a href=\"https://doi.org/10.1038/s41467-024-49458-9\">doi:10.1038/s41467-024-49458-9</a>) — viral load [log10 copies/ml] against nirmatrelvir nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1 log10 copies/ml maximal effect term (Emax, Q323)
  EC50  =      0.037 nM       exposure at half of the maximal effect term (IC50, Q322)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of nirmatrelvir per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.037 nM)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Nirmatrelvir_Esmaeili2024_PD_v;
