function p = Nirmatrelvir_Yang2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nirmatrelvir   source: Yang_2024 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Nirmatrelvir_Yang2024_reference_params';
  p.drug  = 'nirmatrelvir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.71;                % central volume [L]
  p.CL = 3.45;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
