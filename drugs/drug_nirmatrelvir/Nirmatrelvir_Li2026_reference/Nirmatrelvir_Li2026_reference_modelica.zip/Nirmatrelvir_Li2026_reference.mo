model Nirmatrelvir_Li2026_reference
  parameter Real Cl_ref = 2.605277777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09101000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.499535,
    adminMass = 0.0003,
    ka = 5.555555555555556e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nirmatrelvir</h4><p>It is an approved medicine, widely used in combination with ritonavir for the treatment of the disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106405348\">Wikidata Q106405348</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nirmatrelvir</td></tr><tr><td>population:</td><td>healthy Chinese adults</td></tr><tr><td>source_paper:</td><td>Li_2026</td></tr><tr><td>measured_compound:</td><td>nirmatrelvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nirmatrelvir 499.535 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'After first dose on day 1' — extend the ontology if this is a real PK parameter (source ['Tab2:row2:col1', 'Tab2:row2:col2'])</li><li>dropped duplicate Q18 ('AUCtau, µg·h/mL', value '32.01') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax, µg/mL', value '4.500') — already have one for this compound</li><li>dropped value-less row: 'Aetau'</li><li>dropped value-less row: 'AUC12'</li><li>dropped value-less row: 'AUCtau'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'CLr'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'N'</li><li>dropped value-less row: 'n'</li><li>dropped value-less row: 'PK'</li><li>dropped value-less row: 't½'</li><li>dropped value-less row: 'tmax'</li><li>dropped value-less row: 'Vz/F'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nirmatrelvir</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Nirmatrelvir_Li2026_reference;
