function p = Nirmatrelvir_Li2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nirmatrelvir   source: Li_2026 / reference   route: oral
  p.name  = 'Nirmatrelvir_Li2026_reference_params';
  p.drug  = 'nirmatrelvir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 91.01;                % central volume [L]
  p.CL = 9.379;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
