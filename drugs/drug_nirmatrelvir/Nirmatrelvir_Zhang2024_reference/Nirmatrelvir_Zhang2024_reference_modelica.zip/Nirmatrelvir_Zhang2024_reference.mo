model Nirmatrelvir_Zhang2024_reference
  parameter Real Cl_ref = 8.777777777777778e-07 "Cl [m3/s]";
  parameter Real cov_crcl_0 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.039 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.21)*cov_crcl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.499535,
    adminMass = 0.00015,
    ka = 0.00022222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nirmatrelvir</h4><p>It is an approved medicine, widely used in combination with ritonavir for the treatment of the disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106405348\">Wikidata Q106405348</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nirmatrelvir</td></tr><tr><td>population:</td><td>Chinese patients with COVID-19 infection</td></tr><tr><td>source_paper:</td><td>Zhang_2024</td></tr><tr><td>measured_compound:</td><td>nirmatrelvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nirmatrelvir 499.535 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Interindividual variability, CV%')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Interindividual variability, CV%')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Interindividual variability, CV%')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Interindividual variability, CV%')</li><li>table section residual_error: 'ε1' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε1' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε1' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε1' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε2' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε2' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε2' routed out of structural estimates ('Residual variability, CV%')</li><li>table section residual_error: 'ε2' routed out of structural estimates ('Residual variability, CV%')</li><li>unit_dimension_unknown: 'n=1000' (equation variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nirmatrelvir</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Nirmatrelvir_Zhang2024_reference;
