function p = Canrenone_Suyagh2012_final_pharmacokinetic_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canrenone   source: Suyagh_2012 / final_pharmacokinetic_model   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Canrenone_Suyagh2012_final_pharmacokinetic_model_params';
  p.drug  = 'canrenone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26194.0;                % central volume [L]
  p.CL = 798.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
