model Canrenone_Suyagh2012_median
  parameter Real Cl_ref = 0.00022166666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 1.4027999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3404559,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>canrenone</td></tr><tr><td>population:</td><td>paediatric patients</td></tr><tr><td>source_paper:</td><td>Suyagh_2012</td></tr><tr><td>measured_compound:</td><td>canrenone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_M1</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>canrenone 340.456 g/mol (drugbank); potassium canrenoate 396.568 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>PK_3M template not built: the parent has no clearance and no central volume</li><li>dropped duplicate Q27 ('CL/F (l h -1 )', value '1.33') — already have one for this compound</li><li>dropped duplicate Q290 ('V/F (l)', value '19.62') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F (l h -1 kg -1 )*', value '0.32') — already have one for this compound</li><li>dropped duplicate Q290 ('V/F (l kg -1 )*', value '5.35') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=canrenone</li><li>template fit: PK_3M_9C — formed from central; parent 0, metabolites [1]</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V/F (l 70 kg -1 )' is the general volume)</li><li>population split: 'median' subgroup of Suyagh_2012 (paper reports 2 populations: final pharmacokinetic model, median)</li><li>row roles (LLM): model_class=compartmental; 11/11 row label(s) assigned, 31 linked by role</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Canrenone_Suyagh2012_median;
