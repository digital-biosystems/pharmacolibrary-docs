function p = Quinine_Paintaud1994_PD_hearing_impairment_at_the_frequency_params()
% Quinine_Paintaud1994_PD_hearing_impairment_at_the_frequency_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quinine Paintaud_1994::hearing_impairment_at_the_frequency_of_2000_Hz: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response hearing impairment at the frequency of 2000 Hz in its own unit. Driver: quinine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.12;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
