model Quinine_Paintaud1994_PD_hearing_impairment_at_the_frequency
  "linear exposure-response sweep — Paintaud_1994 :: hearing impairment at the frequency of 2000 Hz (hearing impairment at the frequency of 2000 Hz)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.12,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial alkaloid prescribed for Plasmodium falciparum malaria and babesiosis. It is administered orally or intravenously. It remains a global essential medicine for resistant infections where preferred treatments are unavailable.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a>, <a href=\"https://en.wikipedia.org/wiki/Quinine?oldid=1384638728\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Quinine_Paintaud1994_PD_hearing_impairment_at_the_frequency</h4><p>The steady-state exposure-response curve of Paintaud G et al., <i>Clinical pharmacology and therapeutics 55(3):317–323</i> 1994 (<a href=\"https://doi.org/10.1038/clpt.1994.32\">doi:10.1038/clpt.1994.32</a>) — hearing impairment at the frequency of 2000 Hz against quinine — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.12          change in response per unit of exposure (k, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of quinine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Quinine_Paintaud1994_PD_hearing_impairment_at_the_frequency;
