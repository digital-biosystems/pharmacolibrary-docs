model Quinine_Maciel2024_PD_parasitemia
  "emax exposure-response sweep — Maciel_2024 :: parasitemia (parasitemia (P. berghei-infected erythrocytes))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.00055,  // [1; % × 0.01]
    EC50 = 0.00359,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial alkaloid prescribed for Plasmodium falciparum malaria and babesiosis. It is administered orally or intravenously. It remains a global essential medicine for resistant infections where preferred treatments are unavailable.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a>, <a href=\"https://en.wikipedia.org/wiki/Quinine?oldid=1384638728\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Quinine_Maciel2024_PD_parasitemia</h4><p>The steady-state exposure-response curve of Maciel TR et al., <i>Pharmaceutics 16(11)</i> 2024 (<a href=\"https://doi.org/10.3390/pharmaceutics16111369\">doi:10.3390/pharmaceutics16111369</a>) — parasitemia (P. berghei-infected erythrocytes) [%] against quinine mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.055 %        maximal effect term (Emax_pop, Q323)
  EC50  =       3.59 mg/L     exposure at half of the maximal effect term (EC50_pop, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of quinine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.59 mg/L)  response -0.000275
  exposure -> infinity  response -0.00055</pre></body></html>"));
end Quinine_Maciel2024_PD_parasitemia;
