function p = Quinine_Kloprogge2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: quinine   source: Kloprogge_2014 / reference   route: oral
  p.name  = 'Quinine_Kloprogge2014_reference_params';
  p.drug  = 'quinine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 174.0;                % central volume [L]
  p.CL = 10.4;                % clearance [L/h]
  p.Vp = [54.3];             % peripheral volumes [L]
  p.Q  = [10.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.817;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
