function p = Quinine_Kloprogge2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: quinine   source: Kloprogge_2014 / reference   route: oral
  % estimated (absent from source): ka
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Quinine_Kloprogge2014_reference_params';
  p.drug  = 'quinine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 284.9;                % central volume [L]
  p.CL = 13.72;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
