model Quinine_Kloprogge2014_reference
  parameter Real Cl_ref = 3.8111111111111117e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28490000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.0007,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>pregnant women with uncomplicated Plasmodium falciparum malaria</td></tr><tr><td>source_paper:</td><td>Kloprogge_2014</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>DKU228TB2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ka (1/h)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'Vp/F (L)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'AUC0-8 (mg·h/L)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'AUC0-12 (mg·h/L)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'Cmax (mg/L)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'Tmax (h)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 't½ (h)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'CL/F (L /h/kg)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'VSS/F (L/kg)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>dropped duplicate Q19 ('AUC0-12 (mg·h/L)', value '36.7') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=quinine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Quinine_Kloprogge2014_reference;
