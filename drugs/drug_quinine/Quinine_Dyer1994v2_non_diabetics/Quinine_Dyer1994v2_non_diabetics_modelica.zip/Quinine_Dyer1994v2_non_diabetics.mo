model Quinine_Dyer1994v2_non_diabetics
  parameter Real Cl_ref = 1.2483333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.119 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.0006,
    ka = 0.00032090147248145615,
    Tlag = 3600.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial alkaloid prescribed for Plasmodium falciparum malaria and babesiosis. It is administered orally or intravenously. It remains a global essential medicine for resistant infections where preferred treatments are unavailable.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a>, <a href=\"https://en.wikipedia.org/wiki/Quinine?oldid=1384638728\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>diabetic and non-diabetic elderly</td></tr><tr><td>source_paper:</td><td>Dyer_1994_2</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>'Volume of distribution (V/F) 1 kg-1': unit 'V/F' is a parameter symbol — dropped</li><li>implicit units: 'Volume of distribution (V/F) 1 kg-1' → L/kg (from the popPK convention: &quot;The text states 'volume of distribution' was assessed. While Table 2 explicitly lists units for clearance (ml kg-1 min-1&quot;)</li><li>implicit units: 'Absorption lag-time (t_lag) h' → h (from the popPK convention: &quot;The abstract states 'mean absorption lag-time of approximately 1 h'. Lag time is a duration, and hours are the standard &quot;)</li><li>implicit units: 'Absorption half-time (t_1/2,abs) h' → h (from the popPK convention: &quot;The abstract lists 'Absorption and elimination half-times'. Half-times are durations. The paper uses hours (h) for time &quot;)</li><li>implicit units: 'Maximum concentration (C_max) mg 1-1' → mg/L (from the popPK convention: &quot;The text mentions quinine assay detection limits and CVs in 'mg 1-1' (which denotes mg per liter, as seen in 'mg 1-1' fo&quot;)</li><li>implicit units: 'Elimination half-time (t_1/2,l) h' → h (from the popPK convention: &quot;The abstract lists 'Absorption and elimination half-times'. Half-times are durations. The paper uses hours (h) for time &quot;)</li><li>implicit units: 'Systemic clearance (CL/F) ml kg-1 min-1' → mL/kg/min (from the paper text: &quot;The table excerpt explicitly states: 'Systemic clearance ... (CL/F) ml kg-1 min-1'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=quinine</li><li>population split: 'non-diabetics' subgroup of Dyer_1994_2 (paper reports 2 populations: diabetics, non-diabetics)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Quinine_Dyer1994v2_non_diabetics;
