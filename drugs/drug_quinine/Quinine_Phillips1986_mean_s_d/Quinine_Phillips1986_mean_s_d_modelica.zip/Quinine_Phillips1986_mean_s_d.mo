model Quinine_Phillips1986_mean_s_d
  parameter Real Cl_ref = 1.4233333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0672 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.0007
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>pregnant and lactating women with falciparum malaria</td></tr><tr><td>source_paper:</td><td>Phillips_1986</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'mean ± s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>unit_dimension_unknown: 'ml min-1 kg-1' (CL)</li><li>dropped value-less row: 't,lz'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'CL'</li><li>implicit units: 't1/2,z' → h (from the paper text: &quot;The abstract states: 'elimination half-time (t112,z), 11.3 ± 4.3 h'&quot;)</li><li>implicit units: 'CL (ml min-1 kg-1)' → mL/min/kg (from the paper text: &quot;The abstract states: 'total clearance, 1.22 + 0.77 ml min7l kg-' (noting 'ml min7l kg-' is an OCR error for ml min-1 kg-&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=quinine</li><li>population split: 'mean ± s.d.' subgroup of Phillips_1986 (paper reports 4 populations: cerebral, mean ± s.d., pregnancy, uncomplicated)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Quinine_Phillips1986_mean_s_d;
