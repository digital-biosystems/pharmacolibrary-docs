model Quinine_Michels2019_estimate
  parameter Real Cl_ref = 1.2583333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.000611 "Vd [m3]";
  parameter Real cov_catnceud_0 = 0 "CATNCEUD covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (-1.29)*cov_catnceud_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.0014,
    k12 = 0.000900163666121113,
    k21 = 8.218768679019726e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Michels_2019</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T0004</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional model' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'log-likelihood estimate' routed out of structural estimates ('Residual variability')</li><li>'β_V1_CATNCEUD' is a β covariate effect on _V1_, not Q63 (llm link set aside)</li><li>covariate level 'β_V1_CATNCEUD' → Q900:theta_v1_catnceud = -1.29 (linear_fractional on Q63)</li><li>covariate level 'β_Q_CATNCP80' → Q900:theta_q_catncp80 = -1.71 (linear_fractional on Q30)</li><li>covariate level 'β_Q_CATNCEUD' → Q900:theta_q_catnceud = -3.59 (linear_fractional on Q30)</li><li>'β_V2_NCP80' is a β covariate effect on _V2_, not Q64 (llm link set aside)</li><li>covariate level 'β_V2_NCP80' → Q900:theta_v2_ncp80 = 1.91 (linear_fractional on Q64)</li><li>dropped duplicate Q301 ('K12_NCP80 (h−1)', value '0.58') — already have one for this compound</li><li>dropped duplicate Q301 ('K12_NCEUD (h−1)', value '0.324') — already have one for this compound</li><li>dropped duplicate Q302 ('K21_NCP80 (h−1)', value '0.055') — already have one for this compound</li><li>dropped duplicate Q302 ('K21_NCEUD (h−1)', value '0.056') — already have one for this compound</li><li>implicit units: 'Q pop' → L/h (from the paper text: &quot;The text explicitly compares the population value of Q to a control value with units: 'Q was shown to be inferior to the&quot;)</li><li>implicit units: 'V2 pop' → L/kg (from the paper text: &quot;The text provides specific values for the peripheral volume of distribution (V2) with units: 'NCP80 showed that the K12 &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=quinine</li><li>population split: 'estimate' subgroup of Michels_2019 (paper reports 3 populations: estimate, non-compartmental, two-compartmental model)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Quinine_Michels2019_estimate;
