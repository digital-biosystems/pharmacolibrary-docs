function p = Quinine_Michels2019_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: quinine   source: Michels_2019 / estimate   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Quinine_Michels2019_estimate_params';
  p.drug  = 'quinine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.611;                % central volume [L]
  p.CL = 0.453;                % clearance [L/h]
  p.Vp = [66.92];             % peripheral volumes [L]
  p.Q  = [1.98];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1400.0;             % dose [mg]
end
