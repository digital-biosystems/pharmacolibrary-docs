function p = Quinine_Pukrittayakamee2003_PD_pmr_params()
% Quinine_Pukrittayakamee2003_PD_pmr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quinine Pukrittayakamee_2003::PMR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one g/ml per second, in SI inside (kg/m3, s). Response PMR in its own unit. Driver: quinine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.9999;
p.EC50 = 3359.9999999999995;
p.gamma = 3.0;
p.slope = 0.0;
p.exposure_per_s = 1000.0;
p.stop_time = 34.0;
p.form = 'E0 + Emax*frac';
end
