function p = Quinine_Dyer1994v2_diabetics_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: quinine   source: Dyer_1994_2 / diabetics   route: oral
  p.name  = 'Quinine_Dyer1994v2_diabetics_params';
  p.drug  = 'quinine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 119.0;                % central volume [L]
  p.CL = 4.788;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.99021;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.2;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
