model Quinine_Garrido2003_PD_cl_m10
  "emax exposure-response sweep — Garrido_2003 :: CL(M10) (CL(M10))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.94,  // [1]
    EC50 = 9.7e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 970, Interval = 1.94),
    Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial alkaloid prescribed for Plasmodium falciparum malaria and babesiosis. It is administered orally or intravenously. It remains a global essential medicine for resistant infections where preferred treatments are unavailable.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a>, <a href=\"https://en.wikipedia.org/wiki/Quinine?oldid=1384638728\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Quinine_Garrido2003_PD_cl_m10</h4><p>The steady-state exposure-response curve of Garrido MJ et al., <i>The Journal of pharmacology and experimental therapeutics 305(2):710–718</i> 2003 (<a href=\"https://doi.org/10.1124/jpet.102.047779\">doi:10.1124/jpet.102.047779</a>) — CL(M10) against Q ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.94          maximal effect term (maximum degree of inhibition, Q323)
  EC50  =         97 ng/ml    exposure at half of the maximal effect term (IC(50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of Q per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (97 ng/ml)  response -0.47
  exposure -> infinity  response -0.94</pre></body></html>"));
end Quinine_Garrido2003_PD_cl_m10;
