model Citalopram_KraghSrensen1981_reference
  parameter Real Cl_ref = 1.1666666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 1.1500000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.324399,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>citalopram</td></tr><tr><td>population:</td><td>volunteers</td></tr><tr><td>source_paper:</td><td>Kragh-Sørensen_1981</td></tr><tr><td>measured_compound:</td><td>Citalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>citalopram 324.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l plasma/min.)' (CL/F)</li><li>implicit units: 'Systemic and apparent oral clearance estimates (mean' → L/h (from the popPK convention: 'The parameter is clearance (CL/F). No specific unit is provided in the text or table. For population pharmacokinetics, s')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Citalopram</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Citalopram_KraghSrensen1981_reference;
