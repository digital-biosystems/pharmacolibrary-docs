function p = Citalopram_Weisskopf2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: citalopram   source: Weisskopf_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Citalopram_Weisskopf2020_reference_params';
  p.drug  = 'citalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1590.0;                % central volume [L]
  p.CL = 32.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.87;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
