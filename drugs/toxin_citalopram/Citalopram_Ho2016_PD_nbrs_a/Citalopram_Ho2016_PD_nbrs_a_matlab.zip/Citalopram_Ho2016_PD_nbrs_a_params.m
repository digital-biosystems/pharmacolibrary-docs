function p = Citalopram_Ho2016_PD_nbrs_a_params()
% Citalopram_Ho2016_PD_nbrs_a_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% citalopram Ho_2016::NBRS_A: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC(0,24 h) per second, in SI inside (kg/m3, s). Response NBRS-A in score. Driver: (R)-citalopram (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.502;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
