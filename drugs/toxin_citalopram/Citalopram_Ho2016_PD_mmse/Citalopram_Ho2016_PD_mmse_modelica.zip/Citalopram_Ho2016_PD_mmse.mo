model Citalopram_Ho2016_PD_mmse
  "linear exposure-response sweep — Ho_2016 :: MMSE (MMSE)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -0.000176388888889,  // [meter; points × 0.000352778]
    exposure_per_s = 1);   // 1 AUC(0,24 h) per second
  // family_inferred: the record's model family is unknown; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Citalopram_Ho2016_PD_mmse</h4><p>The steady-state exposure-response curve of Ho T et al., <i>British journal of clinical pharmacology 82(3):784-792</i> 2016 (<a href=\"https://doi.org/10.1111/bcp.12997\">doi:10.1111/bcp.12997</a>) — MMSE [points] against (R)-citalopram AUC(0,24 h) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -0.5 points   change in response per unit of exposure (Change in MMSE score, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one AUC(0,24 h) of (R)-citalopram per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Citalopram_Ho2016_PD_mmse;
