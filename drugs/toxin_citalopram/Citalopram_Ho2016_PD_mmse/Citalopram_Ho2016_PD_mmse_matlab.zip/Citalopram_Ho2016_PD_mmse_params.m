function p = Citalopram_Ho2016_PD_mmse_params()
% Citalopram_Ho2016_PD_mmse_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% citalopram Ho_2016::MMSE: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC(0,24 h) per second, in SI inside (kg/m3, s). Response MMSE in points. Driver: (R)-citalopram (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.00017638888888888888;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
