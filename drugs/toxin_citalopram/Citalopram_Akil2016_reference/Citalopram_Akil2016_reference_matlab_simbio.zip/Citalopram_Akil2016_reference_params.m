function p = Citalopram_Akil2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: citalopram   source: Akil_2016 / reference   route: oral
  p.name  = 'Citalopram_Akil2016_reference_params';
  p.drug  = 'citalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1390.0;                % central volume [L]
  p.CL = 24.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
