function p = Triclosan_Siddiqui1979_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: triclosan   source: Siddiqui_1979 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Triclosan_Siddiqui1979_reference_params';
  p.drug  = 'triclosan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.0;                % central volume [L]
  p.CL = 5.425;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
