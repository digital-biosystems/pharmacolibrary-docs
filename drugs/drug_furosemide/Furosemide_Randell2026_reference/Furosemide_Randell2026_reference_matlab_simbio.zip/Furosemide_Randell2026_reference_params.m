function p = Furosemide_Randell2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Randell_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Furosemide_Randell2026_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.73;                % central volume [L]
  p.CL = 0.875;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.679;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
