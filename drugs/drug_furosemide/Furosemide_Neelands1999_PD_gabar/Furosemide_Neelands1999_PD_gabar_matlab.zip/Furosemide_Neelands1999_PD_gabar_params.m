function p = Furosemide_Neelands1999_PD_gabar_params()
% Furosemide_Neelands1999_PD_gabar_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% furosemide Neelands_1999::GABAR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response GABAR in pA. Driver: furosemide (cited_pk).
p.E0 = 0.0;
p.Emax = -0.014895187200000002;
p.EC50 = 873.0;
p.gamma = -0.9;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 8800.0;
p.form = 'E0 + Emax*frac';
end
