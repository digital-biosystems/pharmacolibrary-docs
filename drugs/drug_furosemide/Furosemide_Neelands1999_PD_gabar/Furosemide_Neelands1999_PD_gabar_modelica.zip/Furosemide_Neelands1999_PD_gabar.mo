model Furosemide_Neelands1999_PD_gabar
  "sigmoid_emax exposure-response sweep — Neelands_1999 :: GABAR (GABAR currents)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0148951872,  // [s; pA × 3.15576e-05]
    EC50 = 873,  // [M]
    gamma = -0.9,
    exposure_per_s = 1);   // 1 M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 8800, Interval = 17.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About furosemide</h4><p>Furosemide is a loop diuretic used to treat fluid build-up caused by heart failure, liver cirrhosis, or kidney disease, and is also used for high blood pressure. It is widely used in human medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q388801\">Wikidata Q388801</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Furosemide_Neelands1999_PD_gabar</h4><p>The steady-state exposure-response curve of Neelands TR et al., <i>The Journal of neuroscience : the official journal of the Society for Neuroscience 19(16):7057–7065</i> 1999 (<a href=\"https://doi.org/10.1523/JNEUROSCI.19-16-07057.1999\">doi:10.1523/JNEUROSCI.19-16-07057.1999</a>) — GABAR currents [pA] against furosemide M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        472 pA       maximal effect term (I max, Q323)
  EC50  =        873 M        exposure at half of the maximal effect term (IC 50, Q322)
  gamma =       -0.9          Hill coefficient (n H, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of furosemide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (873 M)  response -0.007448
  exposure -> infinity  response -0.0149</pre></body></html>"));
end Furosemide_Neelands1999_PD_gabar;
