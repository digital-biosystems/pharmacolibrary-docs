function p = Furosemide_Tilstone1978_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Tilstone_1978 / reference   route: oral
  p.name  = 'Furosemide_Tilstone1978_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.61;                % central volume [L]
  p.CL = 6.426;                % clearance [L/h]
  p.Vp = [2.48];             % peripheral volumes [L]
  p.Q  = [0.63];             % inter-compartmental clearances [L/h]
  p.ka = 4.51;                % absorption rate [1/h]
  p.F  = 0.434;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
