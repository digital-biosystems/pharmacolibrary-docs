function p = Zanamivir_Zuo2020_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zanamivir   source: Zuo_2020 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Zanamivir_Zuo2020_final_params';
  p.drug  = 'zanamivir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 12.3;                % central volume [L]
  p.CL = 6.83;                % clearance [L/h]
  p.Vp = [6.54];             % peripheral volumes [L]
  p.Q  = [4.83];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
