// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tizanidine_Zaman2019_mbfs
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {37548.0},
    MM = 0.253708,
    adminMass = 7e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tizanidine</td></tr><tr><td>population:</td><td>healthy rabbits (in-vivo pharmacokinetic study subjects)</td></tr><tr><td>source_paper:</td><td>Zaman_2019</td></tr><tr><td>measured_compound:</td><td>Tizanidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>tizanidine 253.708 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tizanidine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'mbfs' subgroup of Zaman_2019 (paper reports 2 populations: mbfs, sos)</li><li>gap-filled Q22 (CL) from Akhlaq_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Tizanidine_Zaman2019_mbfs;
