// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tizanidine_Granfors2004_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3000.0},
    MM = 0.253708,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tizanidine</td></tr><tr><td>population:</td><td>pooled human liver microsomes (in vitro)</td></tr><tr><td>source_paper:</td><td>Granfors_2004</td></tr><tr><td>measured_compound:</td><td>Tizanidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>tizanidine 253.708 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'initial reaction velocity' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Granfors_2004:abstract'])</li><li>unit_dimension_unknown: 'ml x min-1 x kg-1' (CLint)</li><li>dropped duplicate Q25 ('predicted in vivo hepatic clearance (CLh) using the parallel-tube model, close to estimated in vivo CLh', value 82) — already have one for this compound</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 6 column 4 (char 372)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tizanidine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Akhlaq_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q3, Q25 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Tizanidine_Granfors2004_reference;
