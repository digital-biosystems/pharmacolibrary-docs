function p = Nintedanib_Koziar2024_PD_fvc_params()
% Nintedanib_Koziar2024_PD_fvc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nintedanib Koziar_2024::FVC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response FVC in l/yr. Driver: nintedanib (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -1.6794686541435346e-12;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
