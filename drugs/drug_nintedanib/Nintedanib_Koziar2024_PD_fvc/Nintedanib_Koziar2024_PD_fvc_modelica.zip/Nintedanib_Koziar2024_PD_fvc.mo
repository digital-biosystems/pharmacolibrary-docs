model Nintedanib_Koziar2024_PD_fvc
  "linear exposure-response sweep — Koziar_2024 :: FVC (Annual rate of FVC decline)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -1.67946865414e-12,  // [meter ** 3 / second; l/yr × 3.16881e-11]
    exposure_per_s = 1);   // 1 unit per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nintedanib</h4><p>Nintedanib is a protein kinase inhibitor used to treat idiopathic pulmonary fibrosis and certain types of non-small-cell lung cancer. It is taken orally in capsule form. The medication is authorised in the European Union for these conditions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q15149723\">Wikidata Q15149723</a>, <a href=\"https://en.wikipedia.org/wiki/Nintedanib?oldid=1348387438\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Nintedanib_Koziar2024_PD_fvc</h4><p>The steady-state exposure-response curve of Koziar Vašáková M et al., <i>Respiratory medicine 234:107791</i> 2024 (<a href=\"https://doi.org/10.1016/j.rmed.2024.107791\">doi:10.1016/j.rmed.2024.107791</a>) — Annual rate of FVC decline [l/yr] against nintedanib — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -0.053 l/yr     change in response per unit of exposure (adjusted FVC decline rate (NIN), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of nintedanib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Nintedanib_Koziar2024_PD_fvc;
