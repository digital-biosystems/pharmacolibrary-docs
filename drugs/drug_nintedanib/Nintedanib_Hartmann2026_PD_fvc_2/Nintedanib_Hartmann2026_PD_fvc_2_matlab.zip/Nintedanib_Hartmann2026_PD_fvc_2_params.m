function p = Nintedanib_Hartmann2026_PD_fvc_2_params()
% Nintedanib_Hartmann2026_PD_fvc_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nintedanib Hartmann_2026::FVC::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response FVC in Z-score. Driver: nintedanib (cited_pk).
p.E0 = -3.49;
p.Emax = 0.292;
p.EC50 = 8.12;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 82.0;
p.form = 'E0 + Emax*frac';
end
