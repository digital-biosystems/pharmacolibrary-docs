function p = Nintedanib_Schmid2018v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nintedanib   source: Schmid_2018_2 / reference   route: oral
  p.name  = 'Nintedanib_Schmid2018v2_reference_params';
  p.drug  = 'nintedanib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 465.0;                % central volume [L]
  p.CL = 897.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0376;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
