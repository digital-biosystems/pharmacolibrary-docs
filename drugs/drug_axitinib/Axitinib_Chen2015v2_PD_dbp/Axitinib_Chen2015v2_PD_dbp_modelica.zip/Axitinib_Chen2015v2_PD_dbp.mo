model Axitinib_Chen2015v2_PD_dbp
  "indirect_response_ii exposure-response sweep — Chen_2015_2 :: dBP (24-h diastolic ambulatory blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 20.8,  // type IV effect term
    EC50 = 1.24e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // emax_not_a_fraction: type II needs Imax ≤ 1 but the record has 20.8; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a small molecule tyrosine kinase inhibitor that treats renal cell carcinoma and other kidney cancers. It is given orally as a tablet. It is authorized in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a>, <a href=\"https://en.wikipedia.org/wiki/Axitinib?oldid=1335549960\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Axitinib_Chen2015v2_PD_dbp</h4><p>The steady-state exposure-response curve of Chen Y et al., <i>Clinical pharmacokinetics 54(4):397–407</i> 2015 (<a href=\"https://doi.org/10.1007/s40262-014-0207-5\">doi:10.1007/s40262-014-0207-5</a>) — 24-h diastolic ambulatory blood pressure [mmHg] against axitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       20.8          maximal effect term (Emax, Q323)
  EC50  =       12.4 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of axitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (12.4 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Axitinib_Chen2015v2_PD_dbp;
