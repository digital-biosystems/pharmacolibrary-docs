function p = Axitinib_Ma2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: axitinib   source: Ma_2019 / reference   route: oral
  p.name  = 'Axitinib_Ma2019_reference_params';
  p.drug  = 'axitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1155.0;                % central volume [L]
  p.CL = 930.416667;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.279167;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2100.0;             % dose [mg]
end
