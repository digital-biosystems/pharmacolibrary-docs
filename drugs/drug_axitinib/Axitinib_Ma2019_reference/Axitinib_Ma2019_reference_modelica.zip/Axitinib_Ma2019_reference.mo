model Axitinib_Ma2019_reference
  parameter Real Cl_ref = 0.0002584490740740741 "Cl [m3/s]";
  parameter Real Vd_ref = 1.155 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38647000000000004,
    adminMass = 0.0021,
    ka = 0.0009108796296296296,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a small molecule tyrosine kinase inhibitor that treats renal cell carcinoma and other kidney cancers. It is given orally as a tablet. It is authorized in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a>, <a href=\"https://en.wikipedia.org/wiki/Axitinib?oldid=1335549960\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>axitinib</td></tr><tr><td>population:</td><td>mice with MCF-7/ADR breast cancer xenograft</td></tr><tr><td>source_paper:</td><td>Ma_2019</td></tr><tr><td>measured_compound:</td><td>axitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>axitinib 386.47 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'k a (per day)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'V/F (L/kg)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'CL/F (L/kg/day)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'λ 0 (per day)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'λ 1 (mm 3 /day)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'k max (per day)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'kC 50 (mg/L)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'ψ' routed out of structural estimates ('IIV / CV (%)')</li><li>dropped unlinked row (NIL): 'λ 0 (per day)' — extend the ontology if this is a real PK parameter (source ['tab_0:row6:col1'])</li><li>dropped PD-category row 'k max (per day)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_0:row8:col1'])</li><li>dropped unlinked row (NIL): 'kC 50 (mg/L)' — extend the ontology if this is a real PK parameter (source ['tab_0:row9:col1'])</li><li>dropped unlinked row (NIL): 'ψ' — extend the ontology if this is a real PK parameter (source ['tab_0:row10:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=axitinib</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Axitinib_Ma2019_reference;
