function p = Axitinib_Garrett2014_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: axitinib   source: Garrett_2014 / final   route: iv_bolus
  p.name  = 'Axitinib_Garrett2014_final_params';
  p.drug  = 'axitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 45.3;                % central volume [L]
  p.CL = 17.0;                % clearance [L/h]
  p.Vp = [45.9];             % peripheral volumes [L]
  p.Q  = [1.74];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.465;                 % bioavailability [0-1]
  p.Tlag = 0.457;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
