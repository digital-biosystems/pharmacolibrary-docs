function p = Axitinib_Garrett2014_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: axitinib   source: Garrett_2014 / final   route: oral
  p.name  = 'Axitinib_Garrett2014_final_params';
  p.drug  = 'axitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.6;                % central volume [L]
  p.CL = 8.2;                % clearance [L/h]
  p.Vp = [20.0];             % peripheral volumes [L]
  p.Q  = [8.2];             % inter-compartmental clearances [L/h]
  p.ka = 3.279167;                % absorption rate [1/h]
  p.F  = 0.078;                 % bioavailability [0-1]
  p.Tlag = 0.32;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
