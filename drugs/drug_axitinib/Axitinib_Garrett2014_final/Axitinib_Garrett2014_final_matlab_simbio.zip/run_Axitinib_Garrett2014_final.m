% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Axitinib_Garrett2014_final_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
