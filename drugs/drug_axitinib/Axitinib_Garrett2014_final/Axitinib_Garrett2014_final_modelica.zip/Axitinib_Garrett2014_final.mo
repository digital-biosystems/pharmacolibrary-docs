model Axitinib_Garrett2014_final
  parameter Real Cl_ref = 4.722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0453 "Vd [m3]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (0.758)*cov_weight_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38647000000000004,
    adminMass = 1e-06,
    k12 = 1.066961000735835e-05,
    k21 = 1.0530137981118374e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a small molecule tyrosine kinase inhibitor that treats renal cell carcinoma and other kidney cancers. It is given orally as a tablet. It is authorized in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a>, <a href=\"https://en.wikipedia.org/wiki/Axitinib?oldid=1335549960\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>axitinib</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Garrett_2014</td></tr><tr><td>measured_compound:</td><td>axitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>axitinib 386.47 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2 CL' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vc' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Q' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vp' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 ka' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω CL ω Vc' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω Q ω Vp' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section residual_error: 'Oral, %' routed out of structural estimates ('Residual error model parameters')</li><li>table section residual_error: 'Intravenous, %' routed out of structural estimates ('Residual error model parameters')</li><li>table representations disagree for 'CL (l h -1 )'; source reconciliation required</li><li>table representations disagree for 'Vc (l)'; source reconciliation required</li><li>table representations disagree for 'Weight effect on Vc'; source reconciliation required</li><li>table representations disagree for 'Q (l h -1 )'; source reconciliation required</li><li>table representations disagree for 'Vp (l)'; source reconciliation required</li><li>table representations disagree for 'ka (h -1 ) Form IV, Fed'; source reconciliation required</li><li>table representations disagree for 'Fasting'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Axitinib_Garrett2014_final;
