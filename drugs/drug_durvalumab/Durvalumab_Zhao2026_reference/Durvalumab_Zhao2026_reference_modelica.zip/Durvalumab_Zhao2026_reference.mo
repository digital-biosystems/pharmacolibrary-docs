model Durvalumab_Zhao2026_reference
  parameter Real Cl_ref = 3.298611111111111e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00342 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    k12 = 1.2893924626380768e-06,
    k21 = 1.917270531400966e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About durvalumab</h4><p>Durvalumab is a monoclonal antibody that blocks the PD-L1 protein and is used to treat non-small-cell lung cancer. It is approved and authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19904005\">Wikidata Q19904005</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>durvalumab</td></tr><tr><td>population:</td><td>patients with resectable stage II to IIIB (N2) NSCLC</td></tr><tr><td>source_paper:</td><td>Zhao_2026</td></tr><tr><td>measured_compound:</td><td>durvalumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70287-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ETA CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cov CL‐V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA T max' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional component' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive component' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q22 ('T max change CL', value '-0.412') — already have one for this compound</li><li>unit_dimension_mismatch: 'TC50 change CL' → Q22 (unit '[time]' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('TC50 change CL', value '48.0') — already have one for this compound</li><li>dropped unlinked row (NIL): 'LAM change CL' — extend the ontology if this is a real PK parameter (source ['bcp70287-tbl-0003:row8:col1'])</li><li>dropped unlinked row (NIL): 'Albumin on CL' — extend the ontology if this is a real PK parameter (source ['bcp70287-tbl-0003:row10:col1'])</li><li>dropped unlinked row (NIL): 'Creatinine clearance on CL' — extend the ontology if this is a real PK parameter (source ['bcp70287-tbl-0003:row11:col1'])</li><li>dropped unlinked row (NIL): 'ECOG status on CL' — extend the ontology if this is a real PK parameter (source ['bcp70287-tbl-0003:row12:col1'])</li><li>dropped unlinked row (NIL): 'Sex on CL' — extend the ontology if this is a real PK parameter (source ['bcp70287-tbl-0003:row13:col1'])</li><li>unit_dimension_unknown: '‐' (equation variable)</li><li>dropped unlinked row (NIL): 'COMB 2 on CL' — extend the ontology if this is a real PK parameter (source ['bcp70287-tbl-0003:row15:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Durvalumab_Zhao2026_reference;
