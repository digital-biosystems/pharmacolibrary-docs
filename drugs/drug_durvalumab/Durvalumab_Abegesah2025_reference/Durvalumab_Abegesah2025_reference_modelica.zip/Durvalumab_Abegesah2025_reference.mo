model Durvalumab_Abegesah2025_reference
  parameter Real Cl_ref = 3.449074074074074e-09 "Cl [m3/s]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  parameter Real cov_crcl_1 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.00342 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.515)*cov_body_weight_0)*(1 + (0.136)*cov_crcl_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5.36e-05,
    k12 = 1.529672947801603e-06,
    k21 = 2.628885166573609e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About durvalumab</h4><p>Durvalumab is a monoclonal antibody that blocks the PD-L1 protein and is used to treat non-small-cell lung cancer. It is approved and authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19904005\">Wikidata Q19904005</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>durvalumab</td></tr><tr><td>population:</td><td>patients with advanced biliary tract cancer</td></tr><tr><td>source_paper:</td><td>Abegesah_2025</td></tr><tr><td>measured_compound:</td><td>durvalumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ETA CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cov CL-V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA Tmax' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional component' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive component' routed out of structural estimates ('Residual variability')</li><li>table representations disagree for 'CL'; source reconciliation required</li><li>table representations disagree for 'V1'; source reconciliation required</li><li>table representations disagree for 'Q'; source reconciliation required</li><li>table representations disagree for 'V2'; source reconciliation required</li><li>table representations disagree for 'TC50 change CL'; source reconciliation required</li><li>table representations disagree for 'LAM'; source reconciliation required</li><li>table representations disagree for 'CrCL on CL'; source reconciliation required</li><li>table representations disagree for 'LDH on CL'; source reconciliation required</li><li>table representations disagree for 'Body weight on CL'; source reconciliation required</li><li>table representations disagree for 'Tumor type 1 on CL'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Durvalumab_Abegesah2025_reference;
