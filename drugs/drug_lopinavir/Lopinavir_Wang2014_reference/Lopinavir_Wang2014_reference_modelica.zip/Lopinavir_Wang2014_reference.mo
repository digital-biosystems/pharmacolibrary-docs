model Lopinavir_Wang2014_reference
  parameter Real Cl_ref = 0.00016555555555555554 "Cl [m3/s]";
  parameter Real Vd_ref = 6.37 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6288007999999999,
    adminMass = 0.0001,
    ka = 0.00021055555555555554,
    Tlag = 0.0,
    k12 = 2.062619919762777e-07,
    k21 = 2.3588669459405546e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lopinavir</h4><p>Lopinavir is an antiviral protease inhibitor used to treat HIV infection and HIV/AIDS. It is a WHO essential medicine and is used widely, typically in combination with other antiretroviral drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422585\">Wikidata Q422585</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lopinavir</td></tr><tr><td>population:</td><td>treatment-naïve HIV-1 infected patients</td></tr><tr><td>source_paper:</td><td>Wang_2014</td></tr><tr><td>measured_compound:</td><td>lopinavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lopinavir 628.801 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'virion clearance rate' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Wang_2014:abstract'])</li><li>dropped duplicate Q37 ('LPVLPVt C trough (EC95)', value 726) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lopinavir</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Liang_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Lopinavir_Wang2014_reference;
