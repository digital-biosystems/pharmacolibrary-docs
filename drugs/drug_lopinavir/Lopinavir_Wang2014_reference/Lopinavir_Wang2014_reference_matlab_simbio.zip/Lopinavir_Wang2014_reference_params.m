function p = Lopinavir_Wang2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lopinavir   source: Wang_2014 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Lopinavir_Wang2014_reference_params';
  p.drug  = 'lopinavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6370.0;                % central volume [L]
  p.CL = 596.0;                % clearance [L/h]
  p.Vp = [55.7];             % peripheral volumes [L]
  p.Q  = [4.73];             % inter-compartmental clearances [L/h]
  p.ka = 0.758;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
