model Lopinavir_Alvarez2021_reference
  parameter Real Cl_ref = 1.3555555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0948 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6288007999999999,
    adminMass = 0.0001,
    ka = 0.0001588888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lopinavir</h4><p>Lopinavir is a protease inhibitor antiviral used to treat HIV infections, usually combined with ritonavir. It is given orally as tablets or capsules and is poorly absorbed by mouth. It is a WHO essential medicine, used as second-line therapy in some regions while remaining common in low- and middle-income countries, especially for children.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422585\">Wikidata Q422585</a>, <a href=\"https://en.wikipedia.org/wiki/Lopinavir?oldid=1382964655\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lopinavir</td></tr><tr><td>population:</td><td>patients with coronavirus disease 2019 (Covid-19)</td></tr><tr><td>source_paper:</td><td>Alvarez_2021</td></tr><tr><td>measured_compound:</td><td>lopinavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lopinavir 628.801 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability (ω)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability (ω)')</li><li>table section iiv: 'V' routed out of structural estimates ('Inter-individual variability (ω)')</li><li>table section iiv: 'V' routed out of structural estimates ('Inter-individual variability (ω)')</li><li>column 'shr (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'shr (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped PD-category row 'IC50 (fixed)a' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab2:row5:col2'])</li><li>dropped PD-category row 'Imax (fixed)a' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab2:row6:col2'])</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Additive (fixed)' — extend the ontology if this is a real PK parameter (source ['Tab2:row12:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lopinavir</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Lopinavir_Alvarez2021_reference;
