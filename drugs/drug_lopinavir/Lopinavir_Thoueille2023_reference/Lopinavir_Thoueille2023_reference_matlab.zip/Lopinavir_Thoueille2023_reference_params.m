function p = Lopinavir_Thoueille2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lopinavir   source: Thoueille_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Lopinavir_Thoueille2023_reference_params';
  p.drug  = 'lopinavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.0;                % central volume [L]
  p.CL = 14.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
