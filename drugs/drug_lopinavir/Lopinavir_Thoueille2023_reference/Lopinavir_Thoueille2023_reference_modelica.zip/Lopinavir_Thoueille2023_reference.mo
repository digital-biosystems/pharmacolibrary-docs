model Lopinavir_Thoueille2023_reference
  parameter Real Cl_ref = 3.888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6288007999999999,
    adminMass = 0.0001,
    ka = 0.0008333333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lopinavir</h4><p>Lopinavir is an antiviral protease inhibitor used to treat HIV infection and HIV/AIDS. It is a WHO essential medicine and is used widely, typically in combination with other antiretroviral drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422585\">Wikidata Q422585</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lopinavir</td></tr><tr><td>population:</td><td>HIV-negative individuals exposed to SARS-CoV-2 and people living with HIV</td></tr><tr><td>source_paper:</td><td>Thoueille_2023</td></tr><tr><td>measured_compound:</td><td>lopinavir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lopinavir 628.801 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameters'</li><li>dropped value-less row: 'BW-70'</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (VLPV (L)); Q22 (CLLPV (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lopinavir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lopinavir_Thoueille2023_reference;
