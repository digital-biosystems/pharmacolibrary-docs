function p = Sufentanil_Borsuk2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sufentanil   source: Borsuk_2017 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Sufentanil_Borsuk2017_reference_params';
  p.drug  = 'sufentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.63;                % central volume [L]
  p.CL = 52.6;                % clearance [L/h]
  p.Vp = [473.0];             % peripheral volumes [L]
  p.Q  = [40.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.0459;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
