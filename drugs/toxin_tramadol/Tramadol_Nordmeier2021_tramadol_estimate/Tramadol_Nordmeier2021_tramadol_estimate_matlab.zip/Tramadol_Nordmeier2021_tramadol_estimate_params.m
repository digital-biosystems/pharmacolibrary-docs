function p = Tramadol_Nordmeier2021_tramadol_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Nordmeier_2021 / tramadol_estimate   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tramadol_Nordmeier2021_tramadol_estimate_params';
  p.drug  = 'tramadol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 91.0;                % central volume [L]
  p.CL = 133.0;                % clearance [L/h]
  p.Vp = [119.0];             % peripheral volumes [L]
  p.Q  = [49.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
