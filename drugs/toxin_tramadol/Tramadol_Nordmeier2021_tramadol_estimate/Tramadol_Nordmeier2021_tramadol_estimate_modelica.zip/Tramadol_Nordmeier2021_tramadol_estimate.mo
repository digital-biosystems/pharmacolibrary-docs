model Tramadol_Nordmeier2021_tramadol_estimate
  parameter Real Cl_ref = 3.694444444444444e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09100000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.263381,
    adminMass = 7e-06,
    k12 = 0.00014957264957264955,
    k21 = 0.00011437908496732027
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tramadol</td></tr><tr><td>population:</td><td>pigs</td></tr><tr><td>source_paper:</td><td>Nordmeier_2021</td></tr><tr><td>measured_compound:</td><td>Tramadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tramadol 263.381 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Proportional residual error' routed out of structural estimates ('IIV Q3 (%CV) n.a')</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'n.a'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tramadol</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'tramadol / estimate' subgroup of Nordmeier_2021 (paper reports 2 populations: tramadol / estimate, u-47700 / estimate)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tramadol_Nordmeier2021_tramadol_estimate;
