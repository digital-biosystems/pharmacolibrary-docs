model Tramadol_Chun2025_PD_vas
  "emax exposure-response sweep — Chun_2025 :: VAS (Pain score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.464,      // [normalized to 0-1]
    Emax = -0.908,  // [normalized to 0-1]
    EC50 = 2.36e-06,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 24, Interval = 0.048),
    Documentation(info = "<html><body><h4>Tramadol_Chun2025_PD_vas</h4><p>The steady-state exposure-response curve of Chun D et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(4):781-795</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.13315\">doi:10.1002/psp4.13315</a>) — Pain score [normalized to 0-1] against (1R,2R)-M1 (O-desmethyltramadol) nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.464 normalized to 0-1 drug-free response (baseline) (PD0, Q324)
  Emax  =      0.908 normalized to 0-1 maximal effect term (Imax, Q323)
  EC50  =       2.36 nmol/L   exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of (1R,2R)-M1 (O-desmethyltramadol) per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.464   (drug-free)
  exposure = EC50 (2.36 nmol/L)  response 0.01
  exposure -> infinity  response -0.444</pre></body></html>"));
end Tramadol_Chun2025_PD_vas;
