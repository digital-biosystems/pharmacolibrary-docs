function p = Tramadol_Long2022_p_o_7_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Long_2022 / p_o_7   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tramadol_Long2022_p_o_7_params';
  p.drug  = 'tramadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 256.9;                % central volume [L]
  p.CL = 16.968;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
