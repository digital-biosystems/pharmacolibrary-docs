function p = Tramadol_Long2022_i_v_18_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Long_2022 / i_v_18   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tramadol_Long2022_i_v_18_params';
  p.drug  = 'tramadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 270.2;                % central volume [L]
  p.CL = 16.968;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
