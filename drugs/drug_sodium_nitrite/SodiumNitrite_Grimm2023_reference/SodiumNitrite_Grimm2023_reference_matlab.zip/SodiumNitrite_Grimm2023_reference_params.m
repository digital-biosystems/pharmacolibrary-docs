function p = SodiumNitrite_Grimm2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_nitrite   source: Grimm_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'SodiumNitrite_Grimm2023_reference_params';
  p.drug  = 'sodium_nitrite';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.178;                % central volume [L]
  p.CL = 0.0707;                % clearance [L/h]
  p.Vp = [4.424];             % peripheral volumes [L]
  p.Q  = [0.05222];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
