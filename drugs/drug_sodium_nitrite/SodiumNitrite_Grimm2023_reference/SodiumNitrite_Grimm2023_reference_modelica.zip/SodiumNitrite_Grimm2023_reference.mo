model SodiumNitrite_Grimm2023_reference
  parameter Real Cl_ref = 1.9638888888888884e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003178 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.0470134,
    adminMass = 1e-05,
    k12 = 4.56436612824278e-06,
    k21 = 3.2788326300984526e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sodium_nitrite</h4><p>Sodium nitrite is used as an antidote, mainly for cyanide poisoning. It is an approved medicine and appears on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q339975\">Wikidata Q339975</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_nitrite</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Grimm_2023</td></tr><tr><td>measured_compound:</td><td>sodium_nitrite</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sodium_nitrite 47.0134 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Grimm_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end SodiumNitrite_Grimm2023_reference;
