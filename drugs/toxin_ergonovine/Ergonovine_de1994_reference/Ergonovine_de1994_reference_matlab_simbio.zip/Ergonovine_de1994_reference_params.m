function p = Ergonovine_de1994_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ergonovine   source: de_1994 / reference   route: oral
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Ergonovine_de1994_reference_params';
  p.drug  = 'ergonovine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 73.4;                % central volume [L]
  p.CL = 35.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.648143;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.2;             % dose [mg]
end
