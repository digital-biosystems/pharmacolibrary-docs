model Ergonovine_de1994_reference
  parameter Real Cl_ref = 9.972222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0734 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.325412,
    adminMass = 2.0000000000000002e-07,
    ka = 0.001013373070994072,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ergonovine</td></tr><tr><td>population:</td><td>six human male subjects</td></tr><tr><td>source_paper:</td><td>de_1994</td></tr><tr><td>measured_compound:</td><td>ergonovine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>ergonovine 325.412 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'the steady-state volume (Vss) of distribution' → L (from the popPK convention: 'Vss represents a volume of distribution. Population pharmacokinetic parameters for volume of distribution are convention')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ergonovine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ergonovine_de1994_reference;
