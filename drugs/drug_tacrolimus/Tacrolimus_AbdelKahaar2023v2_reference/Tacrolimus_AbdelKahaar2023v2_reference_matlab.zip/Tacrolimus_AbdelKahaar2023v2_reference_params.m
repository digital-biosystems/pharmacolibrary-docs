function p = Tacrolimus_AbdelKahaar2023v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Abdel-Kahaar_2023_2 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tacrolimus_AbdelKahaar2023v2_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2154.0;                % central volume [L]
  p.CL = 60.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
