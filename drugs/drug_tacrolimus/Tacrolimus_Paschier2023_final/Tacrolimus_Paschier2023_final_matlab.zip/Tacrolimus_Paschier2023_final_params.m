function p = Tacrolimus_Paschier2023_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Paschier_2023 / final   route: oral
  p.name  = 'Tacrolimus_Paschier2023_final_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.02;                % central volume [L]
  p.CL = 13.51;                % clearance [L/h]
  p.Vp = [453.25];             % peripheral volumes [L]
  p.Q  = [69.59];             % inter-compartmental clearances [L/h]
  p.ka = 0.99;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
