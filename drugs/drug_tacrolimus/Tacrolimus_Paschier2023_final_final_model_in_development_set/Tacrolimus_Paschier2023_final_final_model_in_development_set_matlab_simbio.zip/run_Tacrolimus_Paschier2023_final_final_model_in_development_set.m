% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Tacrolimus_Paschier2023_final_final_model_in_development_set_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
