function p = Tacrolimus_Paschier2023_final_final_model_in_development_set_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Paschier_2023 / final_final_model_in_development_set_model_used_for_the_be   route: oral
  p.name  = 'Tacrolimus_Paschier2023_final_final_model_in_development_set_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.35;                % central volume [L]
  p.CL = 13.87;                % clearance [L/h]
  p.Vp = [540.65];             % peripheral volumes [L]
  p.Q  = [65.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.84;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
