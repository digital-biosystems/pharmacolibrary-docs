model Tacrolimus_Paschier2023_final_final_model_in_development_set
  parameter Real Cl_ref = 3.852777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019350000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8040182,
    adminMass = 5e-06,
    ka = 0.00023333333333333333,
    Tlag = 0.0,
    k12 = 0.0009374102784955496,
    k21 = 3.355015053896031e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult heart transplant patients</td></tr><tr><td>source_paper:</td><td>Paschier_2023</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804.018 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'V2-apparent peripheral volume of distribution' routed out of structural estimates ('V2-apparent peripheral volume of distribution; IIV -inter individual variability.CV=√(𝑒 𝑠𝑑 2 -1) 37 (CV -Coefficient of variation; SD -Standard deviation)')</li><li>table section iiv: 'CV' routed out of structural estimates ('V2-apparent peripheral volume of distribution; IIV -inter individual variability.CV=√(𝑒 𝑠𝑑 2 -1) 37 (CV -Coefficient of variation; SD -Standard deviation)')</li><li>covariate effect for Q47 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'Ka' → 1/h (from the popPK convention: 'Ka is a first-order absorption rate constant. The paper does not explicitly state the unit for Ka in the table or text f')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tacrolimus</li><li>pharmacogenetic covariate 'theta_q47_cyp3a5' (cyp3a5) — PGx domain</li><li>model-stage split: 'final model in development set (model used for the be)' is the final model of Paschier_2023 (paper reports 5 stages: base model in development set, be model in validation set, final model in all patients, final model in development set (model used for the be), relative mean bias (%)); same population, different model-building step</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Paschier2023_final_final_model_in_development_set;
