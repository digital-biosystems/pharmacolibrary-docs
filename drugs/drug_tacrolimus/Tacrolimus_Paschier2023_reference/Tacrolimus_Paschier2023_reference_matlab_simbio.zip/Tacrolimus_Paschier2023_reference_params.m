function p = Tacrolimus_Paschier2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Paschier_2023 / reference   route: oral
  p.name  = 'Tacrolimus_Paschier2023_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 256.2;                % central volume [L]
  p.CL = 25.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.9;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.25;             % dose [mg]
end
