% Run (SimBiology): build model + dose, simulate 0..288.0 h, plot.
p = Tacrolimus_Chen2023_base_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 288.0);
