model Tacrolimus_Paschier2023_be_model_in_validation_set
  parameter Real Cl_ref = 7.194444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2562 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8040182,
    adminMass = 5e-06,
    ka = 0.0010833333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult heart transplant patients</td></tr><tr><td>source_paper:</td><td>Paschier_2023</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804.018 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'V2-apparent peripheral volume of distribution' routed out of structural estimates ('V2-apparent peripheral volume of distribution; IIV -inter individual variability.CV=√(𝑒 𝑠𝑑 2 -1) 37 (CV -Coefficient of variation; SD -Standard deviation)')</li><li>table section iiv: 'CV' routed out of structural estimates ('V2-apparent peripheral volume of distribution; IIV -inter individual variability.CV=√(𝑒 𝑠𝑑 2 -1) 37 (CV -Coefficient of variation; SD -Standard deviation)')</li><li>salvaged Q27 ('apparent clearance'=0.37) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central compartment volume'=3.66) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('apparent central volume of distribution'=2.99) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tacrolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: 'be model in validation set' subgroup of Paschier_2023 (paper reports 5 populations: base model in development set, be model in validation set, final model in all patients, final model in development set (model used for the be), relative mean bias (%))</li><li>gap-filled Q49 (kabs) from Xiang_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Paschier2023_be_model_in_validation_set;
