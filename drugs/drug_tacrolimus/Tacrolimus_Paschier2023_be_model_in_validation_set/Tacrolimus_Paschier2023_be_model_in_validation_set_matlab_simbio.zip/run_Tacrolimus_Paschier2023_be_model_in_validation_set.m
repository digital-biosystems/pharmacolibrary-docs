% Run (SimBiology): build model + dose, simulate 0..36.0 h, plot.
p = Tacrolimus_Paschier2023_be_model_in_validation_set_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 36.0);
