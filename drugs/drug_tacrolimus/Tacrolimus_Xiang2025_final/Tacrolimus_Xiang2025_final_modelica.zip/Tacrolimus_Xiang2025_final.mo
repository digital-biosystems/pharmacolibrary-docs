model Tacrolimus_Xiang2025_final
  parameter Real Cl_ref = 1.916666666666667e-06 "Cl [m3/s]";
  parameter Real cov_cyp3a5_0 = 0 "cyp3a5 covariate";
  parameter Real cov_age_1 = 0 "age covariate";
  parameter Real cov_age_2 = 0 "age covariate";
  parameter Real Vd_ref = 0.010400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (21.1)*cov_cyp3a5_0)*(1 + (23.9)*cov_age_1)*(1 + (14.8)*cov_age_2),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8040182,
    adminMass = 5e-06,
    ka = 0.0010833333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>renal transplant recipients</td></tr><tr><td>source_paper:</td><td>Xiang_2025</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804.018 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'POD on CL/F'; source reconciliation required</li><li>table representations disagree for 'WZ on CL/F'; source reconciliation required</li><li>table representations disagree for 'CYP3A5*3/*3 on CL/F'; source reconciliation required</li><li>table representations disagree for 'IIV CL/F (%)'; source reconciliation required</li><li>table representations disagree for 'IIV V/F (%)'; source reconciliation required</li><li>table representations disagree for 'Residual errorAdditive (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'FPG0 (mmol/L)'; source reconciliation required</li><li>table representations disagree for 'Age on FPG0'; source reconciliation required</li><li>table representations disagree for 'IIV FPG0 ((%)'; source reconciliation required</li><li>table representations disagree for 'Residual errorProportional (%)'; source reconciliation required</li><li>table representations disagree for 'eGFR0 (mL/min/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'Age on eGFR0'; source reconciliation required</li><li>table representations disagree for 'HB on eGFR0'; source reconciliation required</li><li>table representations disagree for 'IIV eGFR0 (%)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Xiang2025_final;
