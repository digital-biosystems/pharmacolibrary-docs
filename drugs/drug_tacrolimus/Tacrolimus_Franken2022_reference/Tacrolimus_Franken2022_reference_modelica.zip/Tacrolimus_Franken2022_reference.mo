model Tacrolimus_Franken2022_reference
  parameter Real Cl_ref = 6.3888888888888885e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6920000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8040182,
    adminMass = 5e-06,
    ka = 0.0009944444444444445,
    Tlag = 1368.0,
    k12 = 4.656390494540783e-06,
    k21 = 6.034124011652101e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>kidney transplant recipients</td></tr><tr><td>source_paper:</td><td>Franken_2022</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804.018 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLa' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CLa' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CLa' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V1a' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V1a' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V1a' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V2a' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V2a' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V2a' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Qa' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Qa' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Qa' routed out of structural estimates ('IIV (%)')</li><li>table section iov: 'CL/Fa' routed out of structural estimates ('IOV (%)')</li><li>table section iov: 'CL/Fa' routed out of structural estimates ('IOV (%)')</li><li>table section residual_error: 'Proportional WB' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional WB' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Franken2022_reference;
