function p = Tacrolimus_Xiang2025_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Xiang_2025 / base   route: oral
  p.name  = 'Tacrolimus_Xiang2025_base_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.1;                % central volume [L]
  p.CL = 4.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.9;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
