model Tacrolimus_Fontova2023_PD_cna
  "emax exposure-response sweep — Fontova_2023 :: CNA (calcineurin activity (CNA))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.304,  // [1; % × 0.01]
    EC50 = 43.9,  // [pg/million cells]
    gamma = 1,
    exposure_per_s = 1);   // 1 pg/million cells per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'pg/million cells' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 440, Interval = 0.88),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tacrolimus_Fontova2023_PD_cna</h4><p>The steady-state exposure-response curve of Fontova P et al., <i>Pharmaceutics 15(5)</i> 2023 (<a href=\"https://doi.org/10.3390/pharmaceutics15051481\">doi:10.3390/pharmaceutics15051481</a>) — calcineurin activity (CNA) [% inhibition Inadir] against intracellular tacrolimus pg/million cells — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       30.4 %        maximal effect term (E0, Q323)
  EC50  =       43.9 pg/million cells exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pg/million cells of intracellular tacrolimus per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (43.9 pg/million cells)  response -0.152
  exposure -> infinity  response -0.304</pre></body></html>"));
end Tacrolimus_Fontova2023_PD_cna;
