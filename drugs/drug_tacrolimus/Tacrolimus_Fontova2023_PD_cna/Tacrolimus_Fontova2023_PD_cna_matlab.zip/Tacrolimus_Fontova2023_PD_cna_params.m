function p = Tacrolimus_Fontova2023_PD_cna_params()
% Tacrolimus_Fontova2023_PD_cna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tacrolimus Fontova_2023::CNA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/million cells per second, in SI inside (kg/m3, s). Response CNA in % inhibition Inadir. Driver: intracellular tacrolimus (not_resolved).
p.E0 = 0.0;
p.Emax = -0.304;
p.EC50 = 43.9;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 440.0;
p.form = 'E0 + Emax*frac';
end
