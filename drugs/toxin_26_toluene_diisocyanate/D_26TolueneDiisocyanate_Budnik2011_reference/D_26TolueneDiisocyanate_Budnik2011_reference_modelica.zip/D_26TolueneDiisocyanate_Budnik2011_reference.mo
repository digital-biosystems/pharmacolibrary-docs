// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_26TolueneDiisocyanate_Budnik2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {17100.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>26_toluene_diisocyanate</td></tr><tr><td>population:</td><td>adult patients undergoing specific inhalation challenge tests with diisocyanates for diagnostic reasons</td></tr><tr><td>source_paper:</td><td>Budnik_2011</td></tr><tr><td>measured_compound:</td><td>2,6-Toluene diamine (2,6-TDA)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>26_toluene_diisocyanate 174.159 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('half-life'=4.75) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,6-Toluene diamine (2,6-TDA)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 6 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>toxin: half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>molar mass: LLM call failed (ResponseError) — metabolites left in mass units</li><li>molar mass: none found for '2,6-Toluene diisocyanate' — its concentrations stay mass-only</li><li>molar mass: none found for '2,6-Toluene diamine' — its concentrations stay mass-only</li><li>molar mass: none found for '2,4-Toluene diamine' — its concentrations stay mass-only</li><li>molar mass: none found for '1,6-Hexamethylene diamine' — its concentrations stay mass-only</li><li>molar mass: none found for &quot;4,4'-Diphenylmethane diamine&quot; — its concentrations stay mass-only</li><li>molar mass: none found for 'Isophorone diamine (cis/trans)' — its concentrations stay mass-only</li><li>molar mass: none found for '1,5-Naphthalene diamine' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_26TolueneDiisocyanate_Budnik2011_reference;
