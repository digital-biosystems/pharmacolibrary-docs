% Run (SimBiology): build model + dose, simulate 0..26.0 h, plot.
p = Asparaginase_Sassen2017_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 26.0);
