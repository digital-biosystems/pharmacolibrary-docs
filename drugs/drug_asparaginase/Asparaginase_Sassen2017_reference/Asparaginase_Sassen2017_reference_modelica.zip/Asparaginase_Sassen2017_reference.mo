model Asparaginase_Sassen2017_reference
  parameter Real Cl_ref = 1.1666666666666665e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0033 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.666666666666667e-06,
    Tlag = 0.0,
    k12 = 1.0942760942760944e-05,
    k21 = 1.3374485596707819e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About asparaginase</h4><p>Asparaginase is an enzyme medication used as an anticancer drug to treat lymphoma and lymphoid leukemia. It is an approved medicine, included on the WHO list of essential medicines, and is authorised in the European Union for precursor cell lymphoblastic leukemia-lymphoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105296036\">Wikidata Q105296036</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>asparaginase</td></tr><tr><td>population:</td><td>pediatric acute lymphoblastic leukemia patients</td></tr><tr><td>source_paper:</td><td>Sassen_2017</td></tr><tr><td>measured_compound:</td><td>Erwinia asparaginase</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t3-1020552</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL month 1 diff', value '1.12') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Erwinia asparaginase</li><li>molar mass: no plausible PubChem entry for 'Erwinia asparaginase' ('Erwinia asparaginase') — left in mass units</li><li>molar mass: none found for 'asparaginase' — its concentrations stay mass-only</li><li>molar mass: none found for 'Erwinia asparaginase' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Lin_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Asparaginase_Sassen2017_reference;
