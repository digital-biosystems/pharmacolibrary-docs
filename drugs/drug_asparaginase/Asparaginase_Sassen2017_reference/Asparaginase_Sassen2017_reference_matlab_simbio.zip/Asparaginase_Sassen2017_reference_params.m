function p = Asparaginase_Sassen2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: asparaginase   source: Sassen_2017 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Asparaginase_Sassen2017_reference_params';
  p.drug  = 'asparaginase';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.3;                % central volume [L]
  p.CL = 0.42;                % clearance [L/h]
  p.Vp = [2.7];             % peripheral volumes [L]
  p.Q  = [0.13];             % inter-compartmental clearances [L/h]
  p.ka = 0.0348;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
