model Asparaginase_Borghorst2012_reference
  parameter Real Cl_ref = 3.611111111111111e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004110000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 7.164098404974316e-06,
    k21 = 1.8064076346284938e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About asparaginase</h4><p>Asparaginase is an enzyme medication used as an anticancer drug to treat lymphoma and lymphoid leukemia. It is an approved medicine, included on the WHO list of essential medicines, and is authorised in the European Union for precursor cell lymphoblastic leukemia-lymphoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105296036\">Wikidata Q105296036</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>asparaginase</td></tr><tr><td>population:</td><td>pediatric patients with previously untreated acute lymphoblastic leukemia</td></tr><tr><td>source_paper:</td><td>Borghorst_2012</td></tr><tr><td>measured_compound:</td><td>asparaginase</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h per 1.73 m(2)' (CL)</li><li>unit_dimension_unknown: 'L per 70 kg' (V1)</li><li>unit_dimension_unknown: 'L per 70 kg' (V2)</li><li>implicit units: 'total body clearance' → L/h (from the popPK convention: 'Total body clearance is conventionally expressed in L/h in population PK studies; the value 0.13 is consistent with this')</li><li>implicit units: 'volume of distribution in the central compartment' → L (from the popPK convention: 'Volume of distribution is conventionally expressed in L; the value 4.11 is consistent with a central compartment volume ')</li><li>implicit units: 'volume of distribution in the peripheral compartment' → L (from the popPK convention: 'Volume of distribution is conventionally expressed in L; the value 1.63 is consistent with a peripheral compartment volu')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=asparaginase</li><li>molar mass: none found for 'asparaginase' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Asparaginase_Borghorst2012_reference;
