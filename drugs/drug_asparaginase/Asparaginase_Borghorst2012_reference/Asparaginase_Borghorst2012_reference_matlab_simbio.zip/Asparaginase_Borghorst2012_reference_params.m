function p = Asparaginase_Borghorst2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: asparaginase   source: Borghorst_2012 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Asparaginase_Borghorst2012_reference_params';
  p.drug  = 'asparaginase';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.11;                % central volume [L]
  p.CL = 0.13;                % clearance [L/h]
  p.Vp = [1.63];             % peripheral volumes [L]
  p.Q  = [0.106];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
