function p = Asparaginase_Hoeben2026_PD_tv_params()
% Asparaginase_Hoeben2026_PD_tv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% asparaginase Hoeben_2026::TV: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one IU/L per second, in SI inside (kg/m3, s). Response TV in mm3. Driver: plasma asparaginase activity (not_resolved).
p.E0 = 152.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 3.22;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
