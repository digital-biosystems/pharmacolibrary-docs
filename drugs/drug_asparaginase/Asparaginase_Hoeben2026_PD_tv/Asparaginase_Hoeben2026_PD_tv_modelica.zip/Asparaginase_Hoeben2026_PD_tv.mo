model Asparaginase_Hoeben2026_PD_tv
  "linear exposure-response sweep — Hoeben_2026 :: TV (tumor volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 152,      // [mm3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 3.22   "[L/IU/h × 10−5]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About asparaginase</h4><p>Asparaginase is an enzyme medication used as an anticancer drug to treat lymphoma and lymphoid leukemia. It is an approved medicine, included on the WHO list of essential medicines, and is authorised in the European Union for precursor cell lymphoblastic leukemia-lymphoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105296036\">Wikidata Q105296036</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Asparaginase_Hoeben2026_PD_tv</h4><p>The steady-state exposure-response curve of Hoeben E et al., <i>European journal of drug metabolism and pharmacokinetics</i> 2026 (<a href=\"https://doi.org/10.1007/s13318-026-01010-4\">doi:10.1007/s13318-026-01010-4</a>) — tumor volume [mm3] against plasma asparaginase activity IU/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        152 mm3      drug-free response (baseline) (W0, Q324)
  slope =       3.22 L/IU/h × 10−5 change in response per unit of exposure (slp, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one IU/L of plasma asparaginase activity per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 152   (drug-free)</pre></body></html>"));
end Asparaginase_Hoeben2026_PD_tv;
