function p = Edoxaban_Edwina2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: edoxaban   source: Edwina_2025 / reference   route: oral
  p.name  = 'Edoxaban_Edwina2025_reference_params';
  p.drug  = 'edoxaban';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.4;                % central volume [L]
  p.CL = 9.02;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.104;                % absorption rate [1/h]
  p.F  = 0.24;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
