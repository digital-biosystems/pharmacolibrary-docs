model Edoxaban_Edwina2025_reference
  parameter Real Cl_ref = 2.505555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0474 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 24.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.54806,
    adminMass = 6e-05,
    ka = 2.8888888888888888e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About edoxaban</h4><p>Edoxaban is a direct factor Xa inhibitor used to prevent stroke in atrial fibrillation and to treat venous thromboembolism such as pulmonary embolism. It is an approved medicine, authorised in the European Union, and is widely used as an anticoagulant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21011234\">Wikidata Q21011234</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>edoxaban</td></tr><tr><td>population:</td><td>geriatric patients with atrial fibrillation</td></tr><tr><td>source_paper:</td><td>Edwina_2025</td></tr><tr><td>measured_compound:</td><td>edoxaban</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>edoxaban 548.06 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'probability of overexposure with 15 mg' — extend the ontology if this is a real PK parameter (source ['Edwina_2025:abstract'])</li><li>dropped unlinked row (NIL): 'probability of overexposure with 30 mg' — extend the ontology if this is a real PK parameter (source ['Edwina_2025:abstract'])</li><li>dropped unlinked row (NIL): 'probability of overexposure with 60 mg' — extend the ontology if this is a real PK parameter (source ['Edwina_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=edoxaban</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 7/7 row label(s) assigned, 4 linked by role; re-tagged edoxaban→parent ×8</li><li>molar mass: no plausible PubChem entry for 'M4' ('M4') — left in mass units</li><li>molar mass: none found for 'M4' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Edoxaban_Edwina2025_reference;
