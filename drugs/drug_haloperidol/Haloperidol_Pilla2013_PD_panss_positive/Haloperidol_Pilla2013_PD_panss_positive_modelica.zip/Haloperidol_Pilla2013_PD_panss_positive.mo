model Haloperidol_Pilla2013_PD_panss_positive
  "sigmoid_emax exposure-response sweep — Pilla_2013 :: PANSS positive (PANSS positive subscale)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 23.4,      // [1]
    Emax = -0.41,  // [1]
    EC50 = 1.2e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About haloperidol</h4><p>Haloperidol is a typical antipsychotic drug used to treat schizophrenia, psychosis, and other mental disorders. It can be taken orally or given as an intramuscular or intravenous injection. It is a widely used essential medicine listed by the World Health Organization.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q251347\">Wikidata Q251347</a>, <a href=\"https://en.wikipedia.org/wiki/Haloperidol?oldid=1368777994\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Haloperidol_Pilla2013_PD_panss_positive</h4><p>The steady-state exposure-response curve of Pilla Reddy V et al., <i>Journal of clinical psychopharmacology 33(6):731–739</i> 2013 (<a href=\"https://doi.org/10.1097/JCP.0b013e3182a4ee2c\">doi:10.1097/JCP.0b013e3182a4ee2c</a>) — PANSS positive subscale against haloperidol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       23.4          drug-free response (baseline) (Baseline Score, Q324)
  Emax  =       0.41          maximal effect term (E max, Q323)
  EC50  =        1.2 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of haloperidol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 23.4   (drug-free)
  exposure = EC50 (1.2 ng/mL)  response 23.2
  exposure -> infinity  response 22.99</pre></body></html>"));
end Haloperidol_Pilla2013_PD_panss_positive;
