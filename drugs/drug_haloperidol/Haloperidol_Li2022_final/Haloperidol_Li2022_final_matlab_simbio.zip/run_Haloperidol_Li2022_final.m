% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Haloperidol_Li2022_final_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
