function p = Haloperidol_Ohe1991_PD_che_params()
% Haloperidol_Ohe1991_PD_che_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% haloperidol Oh-e_1991::ChE: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ChE in U/L. Driver: haloperidol (cited_pk).
p.E0 = 7.5;
p.Emax = 0.45;
p.EC50 = 5.2e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 52.0;
p.form = 'E0*(1 - Emax*frac)';
end
