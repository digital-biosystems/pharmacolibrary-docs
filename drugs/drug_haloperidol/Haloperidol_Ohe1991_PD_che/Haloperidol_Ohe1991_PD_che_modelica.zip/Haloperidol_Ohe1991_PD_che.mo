model Haloperidol_Ohe1991_PD_che
  "indirect_response_i exposure-response sweep — Oh-e_1991 :: ChE (Plasma Cholinesterase Activity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 7.5,      // [U/L]
    Emax = 0.45,  // type I effect term
    EC50 = 5.2e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.15/0.02 = 7.5) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 52, Interval = 0.104),
    Documentation(info = "<html><body><!-- drug-about --><h4>About haloperidol</h4><p>Haloperidol is a typical antipsychotic drug used to treat schizophrenia, psychosis, and other mental disorders. It can be taken orally or given as an intramuscular or intravenous injection. It is a widely used essential medicine listed by the World Health Organization.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q251347\">Wikidata Q251347</a>, <a href=\"https://en.wikipedia.org/wiki/Haloperidol?oldid=1368777994\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Haloperidol_Ohe1991_PD_che</h4><p>The steady-state exposure-response curve of Oh-e Y et al., <i>Journal of pharmacobio-dynamics 14(11):615–622</i> 1991 (<a href=\"https://doi.org/10.1248/bpb1978.14.615\">doi:10.1248/bpb1978.14.615</a>) — Plasma Cholinesterase Activity [U/L] against haloperidol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        7.5 U/L      drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       0.45          maximal effect term (Inhibitory effect, Q323)
  EC50  =        5.2 ng/mL    exposure at half of the maximal effect term (Half-maximal inhibitory concentration, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of haloperidol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.5   (drug-free)
  exposure = EC50 (5.2 ng/mL)  response 5.812
  exposure -> infinity  response 4.125</pre></body></html>"));
end Haloperidol_Ohe1991_PD_che;
