model Haloperidol_Pilla2013_reference
  parameter Real Cl_ref = 2.3888888888888892e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.009000000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.00037037037037037035,
    k21 = 0.0002777777777777778
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>patients with schizophrenia</td></tr><tr><td>source_paper:</td><td>Pilla_2013</td></tr><tr><td>measured_compound:</td><td>haloperidol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h j1' (kabs)</li><li>dropped duplicate Q47 ('BHAZ: haloperidol (1/d)', value '0.1') — already have one for this compound</li><li>unit_dimension_unknown: 'additive' (sigma)</li><li>dropped duplicate Q315 ('RUV as SD (additive)', value '0.1') — already have one for this compound</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 16.2 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=haloperidol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Pilla2013_reference;
