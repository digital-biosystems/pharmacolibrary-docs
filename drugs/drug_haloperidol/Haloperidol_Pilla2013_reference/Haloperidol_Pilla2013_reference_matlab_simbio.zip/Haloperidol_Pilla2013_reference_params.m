function p = Haloperidol_Pilla2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Pilla_2013 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Haloperidol_Pilla2013_reference_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.0;                % central volume [L]
  p.CL = 86.0;                % clearance [L/h]
  p.Vp = [12.0];             % peripheral volumes [L]
  p.Q  = [12.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
