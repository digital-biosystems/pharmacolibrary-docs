function p = Haloperidol_Yukawa2002_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Yukawa_2002 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Haloperidol_Yukawa2002_reference_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 34.4;                % central volume [L]
  p.CL = 42.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.3;             % dose [mg]
end
