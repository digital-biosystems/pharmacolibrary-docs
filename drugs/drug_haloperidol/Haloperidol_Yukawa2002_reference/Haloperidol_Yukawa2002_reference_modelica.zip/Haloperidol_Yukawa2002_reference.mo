model Haloperidol_Yukawa2002_reference
  parameter Real Cl_ref = 1.1777777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0344 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375864,
    adminMass = 3.2999999999999997e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About haloperidol</h4><p>Haloperidol is a typical antipsychotic drug used to treat schizophrenia, psychosis, and other mental disorders. It can be taken orally or given as an intramuscular or intravenous injection. It is a widely used essential medicine listed by the World Health Organization.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q251347\">Wikidata Q251347</a>, <a href=\"https://en.wikipedia.org/wiki/Haloperidol?oldid=1368777994\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>Japanese patients with psychiatric disorders</td></tr><tr><td>source_paper:</td><td>Yukawa_2002</td></tr><tr><td>measured_compound:</td><td>haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.864 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'TBW'</li><li>dropped value-less row: 'DOSE'</li><li>dropped value-less row: 'AGE > or = 55'</li><li>dropped value-less row: 'AGE > or = 65'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=haloperidol</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Yukawa2002_reference;
