% Run (SimBiology): build model + dose, simulate 0..840.0 h, plot.
p = LTyrosine_Xu2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 840.0);
