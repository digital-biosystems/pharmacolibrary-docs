function p = Caffeine_Lammers2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caffeine   source: Lammers_2017 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Caffeine_Lammers2017_reference_params';
  p.drug  = 'caffeine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 50.5;                % central volume [L]
  p.CL = 6.67;                % clearance [L/h]
  p.Vp = [97.6];             % peripheral volumes [L]
  p.Q  = [74.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.97;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
