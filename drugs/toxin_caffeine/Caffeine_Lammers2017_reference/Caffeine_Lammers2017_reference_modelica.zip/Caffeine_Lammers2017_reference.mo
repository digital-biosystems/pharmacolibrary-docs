model Caffeine_Lammers2017_reference
  parameter Real Cl_ref = 1.8527777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0505 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.97,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.19419399999999998,
    adminMass = 0.0004,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.00040979097909790973,
    k21 = 0.00021203324225865208
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>caffeine</td></tr><tr><td>population:</td><td>healthy male subjects</td></tr><tr><td>source_paper:</td><td>Lammers_2017</td></tr><tr><td>measured_compound:</td><td>caffeine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>caffeine 194.194 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CL, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CL, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CL, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CL, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V 1, %' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Prop. error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Prop. error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Prop. error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Prop. error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Prop. error' routed out of structural estimates ('Residual variability')</li><li>table representations disagree for 'CL, L h−1'; source reconciliation required</li><li>table representations disagree for 'CL, L h−1'; source reconciliation required</li><li>table representations disagree for 'CL, L h−1'; source reconciliation required</li><li>table representations disagree for 'CL, L h−1'; source reconciliation required</li><li>table representations disagree for 'CL, L h−1'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Caffeine_Lammers2017_reference;
