model Caffeine_Faramarzi2021_study_1
  parameter Real Cl_ref = 1.3194444444444446e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0011086 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.19419399999999998,
    adminMass = 0.000175,
    ka = 6.944444444444444e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>caffeine</td></tr><tr><td>population:</td><td>premature neonates with apnea</td></tr><tr><td>source_paper:</td><td>Faramarzi_2021</td></tr><tr><td>measured_compound:</td><td>Caffeine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T5</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>caffeine 194.194 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Clearance (L/h)', value '0.014') — already have one for this compound</li><li>dropped value-less row: 'Table 5. A summary of pharmacokinetic parameters of caffeine in preterm infants after 24-h (Study 1) or 12 h (Study 2) IV infusion of the drug'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Caffeine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'study-1' subgroup of Faramarzi_2021 (paper reports 4 populations: all, study-1, study-1a, study-2)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Cheng_2026_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Caffeine_Faramarzi2021_study_1;
