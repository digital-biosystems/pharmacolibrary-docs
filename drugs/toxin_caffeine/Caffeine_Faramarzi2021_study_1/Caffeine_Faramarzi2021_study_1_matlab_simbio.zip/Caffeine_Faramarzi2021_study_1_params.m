function p = Caffeine_Faramarzi2021_study_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caffeine   source: Faramarzi_2021 / study_1   route: oral
  % estimated (absent from source): F
  p.name  = 'Caffeine_Faramarzi2021_study_1_params';
  p.drug  = 'caffeine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.1086;                % central volume [L]
  p.CL = 0.0475;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.25;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 175.0;             % dose [mg]
end
