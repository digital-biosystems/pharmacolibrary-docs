function p = Caffeine_Newman2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caffeine   source: Newman_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Caffeine_Newman2022_reference_params';
  p.drug  = 'caffeine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.841;                % central volume [L]
  p.CL = 0.09;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.25;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
