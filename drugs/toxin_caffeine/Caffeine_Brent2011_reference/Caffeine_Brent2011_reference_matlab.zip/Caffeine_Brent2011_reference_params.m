function p = Caffeine_Brent2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caffeine   source: Brent_2011 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Caffeine_Brent2011_reference_params';
  p.drug  = 'caffeine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.841;                % central volume [L]
  p.CL = 3.36;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.25;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 175.0;             % dose [mg]
end
