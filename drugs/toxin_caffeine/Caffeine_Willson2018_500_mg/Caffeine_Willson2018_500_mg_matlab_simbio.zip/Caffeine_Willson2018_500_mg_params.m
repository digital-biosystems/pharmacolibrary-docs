function p = Caffeine_Willson2018_500_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caffeine   source: Willson_2018 / 500_mg   route: oral
  % estimated (absent from source): F
  p.name  = 'Caffeine_Willson2018_500_mg_params';
  p.drug  = 'caffeine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.0;                % central volume [L]
  p.CL = 0.09;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.25;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
