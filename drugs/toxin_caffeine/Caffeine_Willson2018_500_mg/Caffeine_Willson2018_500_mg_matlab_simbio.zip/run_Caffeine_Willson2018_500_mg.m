% Run (SimBiology): build model + dose, simulate 0..2016.0 h, plot.
p = Caffeine_Willson2018_500_mg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2016.0);
