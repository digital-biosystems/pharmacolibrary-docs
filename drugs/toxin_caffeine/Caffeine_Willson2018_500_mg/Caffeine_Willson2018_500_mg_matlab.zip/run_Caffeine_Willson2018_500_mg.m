% Run: build params, simulate 0..2016.0 h, plot + save Caffeine_Willson2018_500_mg.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Caffeine_Willson2018_500_mg.m
here = fileparts(mfilename('fullpath'));
p = Caffeine_Willson2018_500_mg_params();
out = simulate_pk(p, 0:0.05:2016.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('caffeine — Willson_2018 (oral)');
print(fig, fullfile(here, 'Caffeine_Willson2018_500_mg.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Caffeine_Willson2018_500_mg.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Caffeine_Willson2018_500_mg.json'), 'w');
try
  s.model = 'Caffeine_Willson2018_500_mg'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Caffeine_Willson2018_500_mg","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Caffeine_Willson2018_500_mg.png, Caffeine_Willson2018_500_mg.csv, Caffeine_Willson2018_500_mg.json\n');
