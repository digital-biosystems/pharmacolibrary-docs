function p = Caffeine_Thompson2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caffeine   source: Thompson_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Caffeine_Thompson2025_reference_params';
  p.drug  = 'caffeine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 87.1;                % central volume [L]
  p.CL = 0.09;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.25;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
