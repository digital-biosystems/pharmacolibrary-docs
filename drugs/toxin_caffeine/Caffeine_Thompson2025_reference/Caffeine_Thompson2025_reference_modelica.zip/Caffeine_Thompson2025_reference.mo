model Caffeine_Thompson2025_reference
  parameter Real Cl_ref = 2.5e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0871 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.19419399999999998,
    adminMass = 0.0004,
    ka = 6.944444444444444e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>caffeine</td></tr><tr><td>population:</td><td>term infants with hypoxic-ischemic ischemic encephalopathy receiving cooling</td></tr><tr><td>source_paper:</td><td>Thompson_2025</td></tr><tr><td>measured_compound:</td><td>Caffeine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>caffeine 194.194 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'dosing regimens of 30 mg/kg followed by 5' — extend the ontology if this is a real PK parameter (source ['Thompson_2025:abstract'])</li><li>dropped unlinked row (NIL): 'toxic range' — extend the ontology if this is a real PK parameter (source ['Thompson_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Caffeine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Faramarzi_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Cheng_2026_2's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Cheng_2026_2, Faramarzi_2021 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 12700800, Tolerance = 1e-9, Interval = 1));
end Caffeine_Thompson2025_reference;
