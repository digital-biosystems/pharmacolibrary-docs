model Caffeine_Adachi2021_reference
  parameter Real Cl_ref = 7.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.19419399999999998,
    adminMass = 0.0004,
    ka = 0.0013722222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>caffeine</td></tr><tr><td>population:</td><td>human female patient after caffeine overdose</td></tr><tr><td>source_paper:</td><td>Adachi_2021</td></tr><tr><td>measured_compound:</td><td>Caffeine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Caffeine 194.194 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q410 ('Blood–plasma concentration ratio', value '0.822') — already have one for this compound</li><li>dropped duplicate Q410 ('Liver–plasma concentration ratio', value '0.681') — already have one for this compound</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 1 column 198 (char 197)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Caffeine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Volume of systemic circulation, L' is the general volume)</li><li>row roles (LLM): model_class=pbpk; 0/15 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Paraxanthine' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q374, Q91 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Caffeine_Adachi2021_reference;
