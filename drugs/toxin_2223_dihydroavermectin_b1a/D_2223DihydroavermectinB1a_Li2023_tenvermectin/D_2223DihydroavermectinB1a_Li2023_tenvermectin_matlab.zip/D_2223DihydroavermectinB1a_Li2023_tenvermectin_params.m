function p = D_2223DihydroavermectinB1a_Li2023_tenvermectin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 2223_dihydroavermectin_b1a   source: Li_2023 / tenvermectin   route: oral
  p.name  = 'D_2223DihydroavermectinB1a_Li2023_tenvermectin_params';
  p.drug  = '2223_dihydroavermectin_b1a';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2980.5076;                % central volume [L]
  p.CL = 22.5974;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7082;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 21.0;             % dose [mg]
end
