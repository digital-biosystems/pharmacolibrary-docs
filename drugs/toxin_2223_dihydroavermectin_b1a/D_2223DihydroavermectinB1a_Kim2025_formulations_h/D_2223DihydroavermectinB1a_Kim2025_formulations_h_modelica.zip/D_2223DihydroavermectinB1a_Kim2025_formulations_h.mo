model D_2223DihydroavermectinB1a_Kim2025_formulations_h
  parameter Real Cl_ref = 9.722222222222224e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4.34e-07,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1a</td></tr><tr><td>population:</td><td>healthy dogs</td></tr><tr><td>source_paper:</td><td>Kim_2025</td></tr><tr><td>measured_compound:</td><td>ivermectin (22,23-dihydroavermectin B1a)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1a 875.1 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ng·h2/mL' (AUMC)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ivermectin (22,23-dihydroavermectin B1a)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'formulations / h' subgroup of Kim_2025 (paper reports 18 populations: formulations / a, formulations / b, formulations / c, formulations / d, formulations / e, formulations / f, formulations / g, formulations / h, formulations / i, formulations of ivermectin / a, formulations of ivermectin / b, formulations of ivermectin / c, formulations of ivermectin / d, formulations of ivermectin / e, formulations of ivermectin / f, formulations of ivermectin / g, formulations of ivermectin / h, formulations of ivermectin / i)</li><li>molar mass: none found for 'ivermectin (22,23-dihydroavermectin B1a)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q20 — no SI value to build from; C2_base_Q900 failed (ratio 0.5715); C2_base_Q32 failed (ratio 16.5485))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end D_2223DihydroavermectinB1a_Kim2025_formulations_h;
