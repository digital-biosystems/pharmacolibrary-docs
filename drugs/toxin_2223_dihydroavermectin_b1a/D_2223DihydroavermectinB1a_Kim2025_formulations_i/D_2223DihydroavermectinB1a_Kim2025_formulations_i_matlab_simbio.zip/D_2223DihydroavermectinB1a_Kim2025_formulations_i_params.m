function p = D_2223DihydroavermectinB1a_Kim2025_formulations_i_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 2223_dihydroavermectin_b1a   source: Kim_2025 / formulations_i   route: oral
  p.name  = 'D_2223DihydroavermectinB1a_Kim2025_formulations_i_params';
  p.drug  = '2223_dihydroavermectin_b1a';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.2;                % central volume [L]
  p.CL = 2.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.13;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.434;             % dose [mg]
end
