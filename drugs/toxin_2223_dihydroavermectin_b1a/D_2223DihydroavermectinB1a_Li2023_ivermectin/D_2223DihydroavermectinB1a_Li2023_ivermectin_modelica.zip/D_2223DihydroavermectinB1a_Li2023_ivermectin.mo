model D_2223DihydroavermectinB1a_Li2023_ivermectin
  parameter Real Cl_ref = 2.9329999999999997e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.2289784999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.1e-05,
    ka = 0.00019672222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1a</td></tr><tr><td>population:</td><td>swine (pigs), single subcutaneous dose, n=6 per group</td></tr><tr><td>source_paper:</td><td>Li_2023</td></tr><tr><td>measured_compound:</td><td>tenvermectin and ivermectin (22,23-dihydroavermectin B1a)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>vms31085-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1a 875.1 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'λz'</li><li>dropped value-less row: 'T 1/2λz'</li><li>dropped value-less row: 'T max'</li><li>dropped value-less row: 'C max'</li><li>dropped value-less row: 'AUC0‐last'</li><li>dropped value-less row: 'AUC0‐∞'</li><li>dropped value-less row: 'Vd/F'</li><li>dropped value-less row: 'Cl/F'</li><li>dropped value-less row: 'MRTlast'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tenvermectin and ivermectin (22,23-dihydroavermectin B1a)</li><li>population split: 'ivermectin' subgroup of Li_2023 (paper reports 2 populations: ivermectin, tenvermectin)</li><li>molar mass: none found for 'tenvermectin and ivermectin (22,23-dihydroavermectin B1a)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Fimbo_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end D_2223DihydroavermectinB1a_Li2023_ivermectin;
