function p = D_2223DihydroavermectinB1a_Li2023_ivermectin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 2223_dihydroavermectin_b1a   source: Li_2023 / ivermectin   route: oral
  p.name  = 'D_2223DihydroavermectinB1a_Li2023_ivermectin_params';
  p.drug  = '2223_dihydroavermectin_b1a';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2228.9785;                % central volume [L]
  p.CL = 10.5588;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7082;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 21.0;             % dose [mg]
end
