% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = D_2223DihydroavermectinB1a_Kim2025_formulations_e_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
