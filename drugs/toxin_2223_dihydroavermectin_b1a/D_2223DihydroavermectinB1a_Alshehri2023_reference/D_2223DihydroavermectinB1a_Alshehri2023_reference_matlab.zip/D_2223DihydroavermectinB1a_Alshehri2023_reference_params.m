function p = D_2223DihydroavermectinB1a_Alshehri2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 2223_dihydroavermectin_b1a   source: Alshehri_2023 / reference   route: oral
  p.name  = 'D_2223DihydroavermectinB1a_Alshehri2023_reference_params';
  p.drug  = '2223_dihydroavermectin_b1a';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 138.0;                % central volume [L]
  p.CL = 7.02;                % clearance [L/h]
  p.Vp = [424.33];             % peripheral volumes [L]
  p.Q  = [9.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.71;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.75;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
