model D_2223DihydroavermectinB1a_Alshehri2023_reference
  parameter Real Cl_ref = 1.95e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.138 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.2e-05,
    ka = 0.00019722222222222222,
    Tlag = 2700.0,
    k12 = 1.8337359098228662e-05,
    k21 = 5.963649884654763e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1a</td></tr><tr><td>population:</td><td>LF-infected and uninfected adults in Côte d'Ivoire</td></tr><tr><td>source_paper:</td><td>Alshehri_2023</td></tr><tr><td>measured_compound:</td><td>ivermectin (22,23-dihydroavermectin B1a)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pntd.0011319.t002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1a 875.1 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Additive residual error (ng/mL)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional residual error' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q27 ('CL/F', value '0.25') — already have one for this compound</li><li>dropped duplicate Q69 ('Q/F', value '0.19') — already have one for this compound</li><li>dropped duplicate Q290 ('Vc/F', value '0.23') — already have one for this compound</li><li>dropped duplicate Q82 ('Vp /F', value '0.17') — already have one for this compound</li><li>dropped duplicate Q83 ('Tlag', value '0.35') — already have one for this compound</li><li>dropped duplicate Q310 ('Tk0', value '0.11') — already have one for this compound</li><li>dropped duplicate Q49 ('Ka', value '0.55') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ivermectin (22,23-dihydroavermectin B1a)</li><li>molar mass: none found for 'ivermectin (22,23-dihydroavermectin B1a)' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end D_2223DihydroavermectinB1a_Alshehri2023_reference;
