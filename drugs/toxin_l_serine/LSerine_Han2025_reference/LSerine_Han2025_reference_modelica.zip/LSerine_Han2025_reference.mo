model LSerine_Han2025_reference
  parameter Real Cl_ref = 9.916666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004486999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.105093,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_serine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Han_2025</td></tr><tr><td>measured_compound:</td><td>l_serine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>l_serine 105.093 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Han_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1641600, Tolerance = 1e-9, Interval = 1));
end LSerine_Han2025_reference;
