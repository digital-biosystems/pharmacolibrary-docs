% Run (SimBiology): build model + dose, simulate 0..456.0 h, plot.
p = LSerine_Han2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 456.0);
