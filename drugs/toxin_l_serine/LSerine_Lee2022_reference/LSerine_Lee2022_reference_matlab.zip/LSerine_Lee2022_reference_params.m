function p = LSerine_Lee2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: l_serine   source: Lee_2022 / reference   route: oral
  p.name  = 'LSerine_Lee2022_reference_params';
  p.drug  = 'l_serine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 68.4;                % central volume [L]
  p.CL = 22.9;                % clearance [L/h]
  p.Vp = [196.0];             % peripheral volumes [L]
  p.Q  = [16.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.67;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10000.0;             % dose [mg]
end
