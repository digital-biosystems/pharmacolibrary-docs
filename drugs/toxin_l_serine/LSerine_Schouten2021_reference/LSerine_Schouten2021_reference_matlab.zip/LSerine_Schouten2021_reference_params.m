function p = LSerine_Schouten2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: l_serine   source: Schouten_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'LSerine_Schouten2021_reference_params';
  p.drug  = 'l_serine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.14;                % central volume [L]
  p.CL = 0.025208;                % clearance [L/h]
  p.Vp = [3.09];             % peripheral volumes [L]
  p.Q  = [0.087917];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
