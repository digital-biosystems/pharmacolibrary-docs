% Run: build params, simulate 0..4320.0 h, plot every molecule + save UraniumDioxide_Morris1989_james_et_al.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_UraniumDioxide_Morris1989_james_et_al.m
here = fileparts(mfilename('fullpath'));
p = UraniumDioxide_Morris1989_james_et_al_params();
out = simulate_network(p, 0:0.05:4320.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('uranium_dioxide — Morris_1989 (retention function)');
print(fig, fullfile(here, 'UraniumDioxide_Morris1989_james_et_al.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'UraniumDioxide_Morris1989_james_et_al.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'UraniumDioxide_Morris1989_james_et_al.json'), 'w');
try
  s.model = 'UraniumDioxide_Morris1989_james_et_al'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"UraniumDioxide_Morris1989_james_et_al"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote UraniumDioxide_Morris1989_james_et_al.png, UraniumDioxide_Morris1989_james_et_al.csv, UraniumDioxide_Morris1989_james_et_al.json\n');
