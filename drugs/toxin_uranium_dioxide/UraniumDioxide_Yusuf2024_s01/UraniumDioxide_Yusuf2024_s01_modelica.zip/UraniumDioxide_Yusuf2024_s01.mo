// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model UraniumDioxide_Yusuf2024_s01
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {57196800.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_dioxide</td></tr><tr><td>population:</td><td>Retired nuclear fuel workers (ex-pelletizing and ex-conversion)</td></tr><tr><td>source_paper:</td><td>Yusuf_2024</td></tr><tr><td>measured_compound:</td><td>Uranium (238U)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>TA1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>uranium_dioxide 270.028 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'One Compartment Non-Linear Regression Fit / A0 (Bq d−1)' — extend the ontology if this is a real PK parameter (source ['Yusuf_2024_table_2:row1:col1'])</li><li>dropped unlinked row (NIL): 'One Compartment Non-Linear Regression Fit / SE (Bq d−1)' — extend the ontology if this is a real PK parameter (source ['Yusuf_2024_table_2:row1:col2'])</li><li>dropped unlinked row (NIL): 'One Compartment Non-Linear Regression Fit / SE (d)' — extend the ontology if this is a real PK parameter (source ['Yusuf_2024_table_2:row1:col6'])</li><li>routed 'One Compartment Non-Linear Regression Fit / R2 (p-value)' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium (238U)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 's01 (n = 24)' subgroup of Yusuf_2024 (paper reports 2 populations: s01 (n = 24), s02 (n = 18))</li><li>molar mass: none found for 'Uranium (238U)' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Uranium (238U)', not uranium_dioxide — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end UraniumDioxide_Yusuf2024_s01;
