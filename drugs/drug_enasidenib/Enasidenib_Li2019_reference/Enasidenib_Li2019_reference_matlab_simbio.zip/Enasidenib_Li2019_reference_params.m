function p = Enasidenib_Li2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: enasidenib   source: Li_2019 / reference   route: oral
  p.name  = 'Enasidenib_Li2019_reference_params';
  p.drug  = 'enasidenib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 97.7;                % central volume [L]
  p.CL = 0.392083;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.922083;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
