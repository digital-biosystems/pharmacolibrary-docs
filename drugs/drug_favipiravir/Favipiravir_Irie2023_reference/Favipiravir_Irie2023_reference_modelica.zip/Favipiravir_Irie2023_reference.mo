model Favipiravir_Irie2023_reference
  parameter Real Cl_ref = 1.4166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.041600000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.15710400000000002,
    adminMass = 0.0006,
    ka = 0.00041666666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About favipiravir</h4><p>Favipiravir is an antiviral drug investigated for treating infections caused by RNA viruses. It is not authorised in the European Union and remains an investigational drug, though it has been approved in some places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q16934561\">Wikidata Q16934561</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>favipiravir</td></tr><tr><td>population:</td><td>patients with COVID-19</td></tr><tr><td>source_paper:</td><td>Irie_2023</td></tr><tr><td>measured_compound:</td><td>favipiravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>favipiravir 157.104 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2 CL/F' routed out of structural estimates ('Interindividual variability model parameters')</li><li>table section iiv: 'ω 2 CL/F' routed out of structural estimates ('Interindividual variability model parameters')</li><li>table section iiv: 'ω 2 CL/F' routed out of structural estimates ('Interindividual variability model parameters')</li><li>table section residual_error: 'σ 2 proportional error' routed out of structural estimates ('Residual error model parameters')</li><li>table section residual_error: 'σ 2 proportional error' routed out of structural estimates ('Residual error model parameters')</li><li>table section residual_error: 'σ 2 proportional error' routed out of structural estimates ('Residual error model parameters')</li><li>table section residual_error: 'σ 2 additive error' routed out of structural estimates ('Residual error model parameters')</li><li>table section residual_error: 'σ 2 additive error' routed out of structural estimates ('Residual error model parameters')</li><li>dropped duplicate Q27 ('Dose on CL/F', value '-0.61') — already have one for this compound</li><li>routed 'IMV on CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q27 ('BSA on CL/F', value '2.2') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=favipiravir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Agyeman_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Favipiravir_Irie2023_reference;
