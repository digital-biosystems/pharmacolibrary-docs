model Favipiravir_Irie2023_reference
  parameter Real Cl_ref = 1.4166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.041600000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.15710400000000002,
    adminMass = 0.0006,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About favipiravir</h4><p>Favipiravir is an antiviral medication primarily indicated for treating influenza. The drug is administered orally in tablet form. It is approved for medical use in Japan and is also being studied for other viral infections.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q16934561\">Wikidata Q16934561</a>, <a href=\"https://en.wikipedia.org/wiki/Favipiravir?oldid=1384988984\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>favipiravir</td></tr><tr><td>population:</td><td>patients with COVID-19</td></tr><tr><td>source_paper:</td><td>Irie_2023</td></tr><tr><td>measured_compound:</td><td>favipiravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>favipiravir 157.104 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2 CL/F' routed out of structural estimates ('Interindividual variability model parameters')</li><li>table section residual_error: 'σ 2 proportional error' routed out of structural estimates ('Residual error model parameters')</li><li>table section residual_error: 'σ 2 additive error' routed out of structural estimates ('Residual error model parameters')</li><li>dropped unlinked row (NIL): 'Dose on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_0:row3:col1'])</li><li>dropped duplicate Q27 ('IMV on CL/F', value '1.7') — already have one for this compound</li><li>dropped unlinked row (NIL): 'BSA on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_0:row5:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=favipiravir</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Favipiravir_Irie2023_reference;
