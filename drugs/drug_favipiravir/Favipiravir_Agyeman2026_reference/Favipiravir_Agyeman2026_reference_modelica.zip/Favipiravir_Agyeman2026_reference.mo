model Favipiravir_Agyeman2026_reference
  parameter Real Cl_ref = 4.805555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0221 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.15710400000000002,
    adminMass = 0.0004,
    ka = 0.00041666666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About favipiravir</h4><p>Favipiravir is an antiviral drug investigated for treating infections caused by RNA viruses. It is not authorised in the European Union and remains an investigational drug, though it has been approved in some places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q16934561\">Wikidata Q16934561</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>favipiravir</td></tr><tr><td>population:</td><td>adults with COVID-19</td></tr><tr><td>source_paper:</td><td>Agyeman_2026</td></tr><tr><td>measured_compound:</td><td>favipiravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>favipiravir 157.104 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('After evaluation of IIV on k a , CL/F and V/F, only IIV on CL/F achieved the lowest OFV. 24 The estimated mean CL/F and V/F were 1.73 L/h (95% CI: S3.')</li><li>salvaged Q49 ('k a'=1.5) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=1.73) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=22.1) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=favipiravir</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Favipiravir_Agyeman2026_reference;
