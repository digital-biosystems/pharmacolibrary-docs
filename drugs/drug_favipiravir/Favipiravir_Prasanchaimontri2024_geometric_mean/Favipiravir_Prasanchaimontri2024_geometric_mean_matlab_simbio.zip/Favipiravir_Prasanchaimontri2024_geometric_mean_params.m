function p = Favipiravir_Prasanchaimontri2024_geometric_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: favipiravir   source: Prasanchaimontri_2024 / geometric_mean   route: oral
  p.name  = 'Favipiravir_Prasanchaimontri2024_geometric_mean_params';
  p.drug  = 'favipiravir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.5;                % central volume [L]
  p.CL = 1.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
