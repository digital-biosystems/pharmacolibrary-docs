model Favipiravir_Prasanchaimontri2024_geometric_mean
  parameter Real Cl_ref = 2.7777777777777776e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0195 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.15710400000000002,
    adminMass = 0.0008,
    ka = 0.0009444444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About favipiravir</h4><p>Favipiravir is an antiviral drug investigated for treating infections caused by RNA viruses. It is not authorised in the European Union and remains an investigational drug, though it has been approved in some places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q16934561\">Wikidata Q16934561</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>favipiravir</td></tr><tr><td>population:</td><td>Thai adults with mild COVID-19</td></tr><tr><td>source_paper:</td><td>Prasanchaimontri_2024</td></tr><tr><td>measured_compound:</td><td>favipiravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21233-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>favipiravir 157.104 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'CL/F (L/h) [%RSE]' → L/h (from the paper text: 'The paper states that apparent clearance is parameterized as “CL/F, L/h.”')</li><li>implicit units: 'V/F (L) [%RSE]' → L (from the paper text: 'The paper states that apparent volume of distribution is parameterized as “V/F, L.”')</li><li>implicit units: 'K A (h−1) [%RSE]' → 1/h (from the paper text: 'The paper states that the absorption rate constant is “K A, h−1.”')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=favipiravir</li><li>population split: 'geometric mean' subgroup of Prasanchaimontri_2024 (paper reports 2 populations: arithmetic mean, geometric mean)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Favipiravir_Prasanchaimontri2024_geometric_mean;
