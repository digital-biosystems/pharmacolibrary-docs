model Favipiravir_Erameh2026_PD_ct
  "linear exposure-response sweep — Erameh_2026 :: Ct (GPC gene RT–PCR)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1.30555555556e-05,  // [1 / second; /h × 0.000277778]
    exposure_per_s = 0.001);   // 1 mg l−1 per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About favipiravir</h4><p>Favipiravir is an antiviral medication primarily indicated for treating influenza. The drug is administered orally in tablet form. It is approved for medical use in Japan and is also being studied for other viral infections.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q16934561\">Wikidata Q16934561</a>, <a href=\"https://en.wikipedia.org/wiki/Favipiravir?oldid=1384988984\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Favipiravir_Erameh2026_PD_ct</h4><p>The steady-state exposure-response curve of Erameh C et al., <i>Nature medicine</i> 2026 (<a href=\"https://doi.org/10.1038/s41591-026-04402-w\">doi:10.1038/s41591-026-04402-w</a>) — GPC gene RT–PCR [Ct] against favipiravir mg l−1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.047 /h       change in response per unit of exposure (α, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg l−1 of favipiravir per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Favipiravir_Erameh2026_PD_ct;
