function p = Favipiravir_Erameh2026_PD_ct_params()
% Favipiravir_Erameh2026_PD_ct_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% favipiravir Erameh_2026::Ct: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l−1 per second, in SI inside (kg/m3, s). Response Ct in Ct. Driver: favipiravir (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.3055555555555555e-05;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
