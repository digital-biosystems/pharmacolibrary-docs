function p = Risankizumab_Thomas2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: risankizumab   source: Thomas_2026 / reference   route: oral
  p.name  = 'Risankizumab_Thomas2026_reference_params';
  p.drug  = 'risankizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.9;                % central volume [L]
  p.CL = 0.014208;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.009542;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
