function p = Risankizumab_Khatri2019_japanese_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: risankizumab   source: Khatri_2019 / japanese   route: oral
  % estimated (absent from source): F
  p.name  = 'Risankizumab_Khatri2019_japanese_params';
  p.drug  = 'risankizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.12;                % central volume [L]
  p.CL = 0.01;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.037833;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 18.0;             % dose [mg]
end
