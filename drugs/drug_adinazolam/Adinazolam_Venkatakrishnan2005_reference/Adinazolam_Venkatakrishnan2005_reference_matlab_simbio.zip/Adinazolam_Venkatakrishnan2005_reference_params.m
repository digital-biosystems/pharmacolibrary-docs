function p = Adinazolam_Venkatakrishnan2005_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: adinazolam   source: Venkatakrishnan_2005 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Adinazolam_Venkatakrishnan2005_reference_params';
  p.drug  = 'adinazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.0;                % central volume [L]
  p.CL = 5.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
