function p = ValproicAcid_Huo2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valproic_acid   source: Huo_2025 / reference   route: oral
  p.name  = 'ValproicAcid_Huo2025_reference_params';
  p.drug  = 'valproic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 68.8;                % central volume [L]
  p.CL = 2.42;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.93;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
