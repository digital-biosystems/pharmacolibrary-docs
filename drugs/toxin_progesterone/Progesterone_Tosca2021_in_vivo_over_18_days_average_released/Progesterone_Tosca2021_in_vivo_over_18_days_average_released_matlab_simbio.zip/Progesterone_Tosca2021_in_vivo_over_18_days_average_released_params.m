function p = Progesterone_Tosca2021_in_vivo_over_18_days_average_released_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: progesterone   source: Tosca_2021 / in_vivo_over_18_days_average_released_progesterone_mg   route: oral
  % estimated (absent from source): F
  p.name  = 'Progesterone_Tosca2021_in_vivo_over_18_days_average_released_params';
  p.drug  = 'progesterone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.41;                % central volume [L]
  p.CL = 7.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.26;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.134;             % absorption lag [h]
  p.dose = 125.0;             % dose [mg]
end
