% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Progesterone_Tosca2021_in_vivo_over_18_days_average_released_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
