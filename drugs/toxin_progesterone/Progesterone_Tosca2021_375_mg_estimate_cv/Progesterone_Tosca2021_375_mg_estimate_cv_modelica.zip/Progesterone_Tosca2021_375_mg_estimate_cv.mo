// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Progesterone_Tosca2021_375_mg_estimate_cv
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {29495.624704678525},
    MM = 0.314469,
    adminMass = 0.000125,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>progesterone</td></tr><tr><td>population:</td><td>healthy women using progesterone vaginal rings (clinical study participants)</td></tr><tr><td>source_paper:</td><td>Tosca_2021</td></tr><tr><td>measured_compound:</td><td>Progesterone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00255-t0A1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): coefficients in mg normalised to their sum — the pools describe the measured curve's shape, C(t)/C(0), not a share of the intake</td></tr><tr><td>molar_masses:</td><td>progesterone 314.469 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Error (sd)' — extend the ontology if this is a real PK parameter (source ['Tosca_2021_table_9:row6:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Progesterone</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: '375 mg / estimate [cv%]' subgroup of Tosca_2021 (paper reports 9 populations: 125 mg / estimate [cv%], 1500 mg / estimate [cv%], 375 mg / estimate [cv%], 750 mg / estimate [cv%], in vitro (over 15 days) / average released progesterone [mg], in vitro (over 15 days) / percentage of total released progesterone [%], in vivo (over 18 days) / average released progesterone [mg], in vivo (over 18 days) / percentage of total released progesterone [%], population parameters / typical value (cv%))</li><li>gap-filled Q22 (CL) from Schultze-Mosgau_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cottu_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Morris_2011's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Sutter_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 316.8));
end Progesterone_Tosca2021_375_mg_estimate_cv;
