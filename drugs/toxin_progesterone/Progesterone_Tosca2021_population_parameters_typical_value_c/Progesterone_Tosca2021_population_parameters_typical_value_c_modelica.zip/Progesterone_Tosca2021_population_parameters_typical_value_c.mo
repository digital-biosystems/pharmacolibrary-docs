model Progesterone_Tosca2021_population_parameters_typical_value_c
  parameter Real Cl_ref = 2.381888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.88 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.314469,
    adminMass = 0.000125,
    ka = 0.00023249999999999999,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>progesterone</td></tr><tr><td>population:</td><td>healthy women using progesterone vaginal rings (clinical study participants)</td></tr><tr><td>source_paper:</td><td>Tosca_2021</td></tr><tr><td>measured_compound:</td><td>Progesterone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00255-t0A1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>progesterone 314.469 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'varconc' routed out of structural estimates ('Residual variability (variance)')</li><li>table section residual_error: 'varconc' routed out of structural estimates ('Residual variability (variance)')</li><li>dropped PD-category row 'γ [-]' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pharmaceutics-13-00255-t0A1:row5:col1', 'Tosca_2021_table_1:row4:col1'])</li><li>dropped duplicate Q49 ('Kabs [1/h]', value '0.4430') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Progesterone</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'population parameters / typical value (cv%)' subgroup of Tosca_2021 (paper reports 9 populations: 125 mg / estimate [cv%], 1500 mg / estimate [cv%], 375 mg / estimate [cv%], 750 mg / estimate [cv%], in vitro (over 15 days) / average released progesterone [mg], in vitro (over 15 days) / percentage of total released progesterone [%], in vivo (over 18 days) / average released progesterone [mg], in vivo (over 18 days) / percentage of total released progesterone [%], population parameters / typical value (cv%))</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q86 — no SI value to build from)</li><li>derived CL/F=85.748 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Progesterone_Tosca2021_population_parameters_typical_value_c;
