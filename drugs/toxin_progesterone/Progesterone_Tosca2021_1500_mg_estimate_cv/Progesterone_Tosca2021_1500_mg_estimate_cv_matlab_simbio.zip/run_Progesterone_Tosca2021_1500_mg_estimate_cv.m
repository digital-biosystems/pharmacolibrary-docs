% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Progesterone_Tosca2021_1500_mg_estimate_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
