model Progesterone_Tosca2021_1500_mg_estimate_cv
  parameter Real Cl_ref = 1.9444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00541 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.314469,
    adminMass = 0.000125,
    ka = 1.8222222222222224e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>progesterone</td></tr><tr><td>population:</td><td>healthy women using progesterone vaginal rings (clinical study participants)</td></tr><tr><td>source_paper:</td><td>Tosca_2021</td></tr><tr><td>measured_compound:</td><td>Progesterone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00255-t0A1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>progesterone 314.469 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Error (sd)' — extend the ontology if this is a real PK parameter (source ['Tosca_2021_table_9:row6:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Progesterone</li><li>population split: '1500 mg / estimate [cv%]' subgroup of Tosca_2021 (paper reports 9 populations: 125 mg / estimate [cv%], 1500 mg / estimate [cv%], 375 mg / estimate [cv%], 750 mg / estimate [cv%], in vitro (over 15 days) / average released progesterone [mg], in vitro (over 15 days) / percentage of total released progesterone [%], in vivo (over 18 days) / average released progesterone [mg], in vivo (over 18 days) / percentage of total released progesterone [%], population parameters / typical value (cv%))</li><li>gap-filled Q22 (CL) from Schultze-Mosgau_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cottu_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Cottu_2018, Schultze-Mosgau_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Progesterone_Tosca2021_1500_mg_estimate_cv;
