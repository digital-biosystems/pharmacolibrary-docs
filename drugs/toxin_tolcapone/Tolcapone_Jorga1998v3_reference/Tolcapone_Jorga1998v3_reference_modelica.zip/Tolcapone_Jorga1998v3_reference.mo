model Tolcapone_Jorga1998v3_reference
  parameter Real Cl_ref = 1.9722222222222224e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.009000000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27324400000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolcapone</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Jorga_1998_3</td></tr><tr><td>measured_compound:</td><td>Tolcapone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tolcapone 273.244 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '1.h-l' (CL)</li><li>implicit units: 'volume of distribution' → L (from the popPK convention: 'Paper states no unit. Population PK convention for volume of distribution is L. A value of 9 is consistent with liters.')</li><li>implicit units: 'total clearance' → L/h (from the popPK convention: 'Paper states no unit. Population PK convention for total clearance is L/h. A value of 71 is consistent with liters per h')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volume of distribution); Q22 (total clearance)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tolcapone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tolcapone_Jorga1998v3_reference;
