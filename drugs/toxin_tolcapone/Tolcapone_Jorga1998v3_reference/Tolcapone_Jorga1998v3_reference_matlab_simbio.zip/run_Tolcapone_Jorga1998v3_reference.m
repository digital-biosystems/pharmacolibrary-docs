% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Tolcapone_Jorga1998v3_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
