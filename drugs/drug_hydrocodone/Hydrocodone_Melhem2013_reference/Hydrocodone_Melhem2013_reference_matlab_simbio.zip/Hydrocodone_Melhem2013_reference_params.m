function p = Hydrocodone_Melhem2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydrocodone   source: Melhem_2013 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Hydrocodone_Melhem2013_reference_params';
  p.drug  = 'hydrocodone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 713.0;                % central volume [L]
  p.CL = 64.3;                % clearance [L/h]
  p.Vp = [153.0];             % peripheral volumes [L]
  p.Q  = [0.9];             % inter-compartmental clearances [L/h]
  p.ka = 2.28;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
