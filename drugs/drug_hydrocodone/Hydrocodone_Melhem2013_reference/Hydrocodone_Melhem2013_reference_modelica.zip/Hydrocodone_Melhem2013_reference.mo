model Hydrocodone_Melhem2013_reference
  parameter Real Cl_ref = 1.786111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.713 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0006333333333333333,
    Tlag = 0.0,
    k12 = 3.5063113604488084e-07,
    k21 = 1.6339869281045755e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydrocodone</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Melhem_2013</td></tr><tr><td>measured_compound:</td><td>hydrocodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ALAG2 hr' — extend the ontology if this is a real PK parameter (source ['Melhem_2013:abstract'])</li><li>dropped unlinked row (NIL): 'F1 %' — extend the ontology if this is a real PK parameter (source ['Melhem_2013:abstract'])</li><li>dropped unlinked row (NIL): 'ALAG1 hr' — extend the ontology if this is a real PK parameter (source ['Melhem_2013:abstract'])</li><li>dropped duplicate Q49 ('KA2 1/hr', value 0.434) — already have one for this compound</li><li>dropped unlinked row (NIL): 'CRE none' — extend the ontology if this is a real PK parameter (source ['Melhem_2013:abstract'])</li><li>dropped unlinked row (NIL): 'BSE none' — extend the ontology if this is a real PK parameter (source ['Melhem_2013:abstract'])</li><li>dropped unlinked row (NIL): 'Log_RV SD' — extend the ontology if this is a real PK parameter (source ['Melhem_2013:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydrocodone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydrocodone_Melhem2013_reference;
