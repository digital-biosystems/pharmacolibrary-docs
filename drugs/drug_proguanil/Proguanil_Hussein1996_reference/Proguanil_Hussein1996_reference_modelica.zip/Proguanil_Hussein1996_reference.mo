model Proguanil_Hussein1996_reference
  parameter Real Cl_ref = 1.5e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.562 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.253731,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About proguanil</h4><p>Proguanil is an antimalarial drug used to treat and prevent malaria, especially falciparum malaria. It is widely used, often combined with other antimalarials, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420607\">Wikidata Q420607</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>proguanil</td></tr><tr><td>population:</td><td>patients with acute P. falciparum malaria</td></tr><tr><td>source_paper:</td><td>Hussein_1996</td></tr><tr><td>measured_compound:</td><td>proguanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>proguanil 253.731 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate body weight for CL/F from footnote/prose kept as documentation only (['Hussein_1996:abstract'])</li><li>dropped unlinked row (NIL): 'was 13% higher in Orientals than Blacks and Malays' — extend the ontology if this is a real PK parameter (source ['Hussein_1996:abstract'])</li><li>dropped unlinked row (NIL): &quot;and 17% lower in 'poor' than 'extensive' metabolizers&quot; — extend the ontology if this is a real PK parameter (source ['Hussein_1996:abstract'])</li><li>covariate body weight for V/F from footnote/prose kept as documentation only (['Hussein_1996:abstract'])</li><li>routed 'The final magnitudes of interpatient variability in CLo and V/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=proguanil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Cherkaoui-Rbati_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Proguanil_Hussein1996_reference;
