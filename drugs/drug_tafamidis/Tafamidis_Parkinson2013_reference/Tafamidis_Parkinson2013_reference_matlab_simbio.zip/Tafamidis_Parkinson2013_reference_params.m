function p = Tafamidis_Parkinson2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tafamidis   source: Parkinson_2013 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Tafamidis_Parkinson2013_reference_params';
  p.drug  = 'tafamidis';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.675138;                % central volume [L]
  p.CL = 8.4;                % clearance [L/h]
  p.Vp = [19.6];             % peripheral volumes [L]
  p.Q  = [532.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.41;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
