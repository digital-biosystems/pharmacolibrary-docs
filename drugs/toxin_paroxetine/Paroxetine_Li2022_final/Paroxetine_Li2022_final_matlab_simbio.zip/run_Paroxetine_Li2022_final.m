% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Paroxetine_Li2022_final_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
