function p = Paroxetine_Li2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paroxetine   source: Li_2022 / final   route: oral
  p.name  = 'Paroxetine_Li2022_final_params';
  p.drug  = 'paroxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.85;                % central volume [L]
  p.CL = 21.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.908;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
