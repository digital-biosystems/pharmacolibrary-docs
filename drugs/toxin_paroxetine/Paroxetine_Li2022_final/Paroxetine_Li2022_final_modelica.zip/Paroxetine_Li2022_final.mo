model Paroxetine_Li2022_final
  parameter Real Cl_ref = 5.888888888888889e-06 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real Vd_ref = 0.00885 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.475)*cov_sex_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32937099999999997,
    adminMass = 2e-05,
    ka = 0.0002522222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paroxetine</td></tr><tr><td>population:</td><td>Chinese psychotic patients (inpatients with psychosis)</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>Paroxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paroxetine 329.371 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'θ_CL-dosage' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>covariate level 'θ_E-sex' → Q900:e_sex = 0.475 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'PRO (CV%)' — extend the ontology if this is a real PK parameter (source ['Li_2022_table_p6_1:row6:col1'])</li><li>covariate effect for Q61 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Paroxetine</li><li>model-stage split: 'final model estimate' is the final model of Li_2022 (paper reports 2 stages: final model estimate, final model iiv (cv%)); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paroxetine_Li2022_final;
