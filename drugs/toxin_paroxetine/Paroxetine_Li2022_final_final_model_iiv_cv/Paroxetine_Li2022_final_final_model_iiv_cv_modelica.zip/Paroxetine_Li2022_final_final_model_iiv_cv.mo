model Paroxetine_Li2022_final_final_model_iiv_cv
  parameter Real Cl_ref = 5.888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 8.85 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32937099999999997,
    adminMass = 2e-05,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>paroxetine</td></tr><tr><td>population:</td><td>Chinese psychotic patients (inpatients with psychosis)</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>Paroxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paroxetine 329.371 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('Final model IIV (CV%)')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('Final model IIV (CV%)')</li><li>salvaged Q27 ('CL/F in the base model'=21.2) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F in the base model'=8850) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Paroxetine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'final model iiv (cv%)' is the final model of Li_2022 (paper reports 2 stages: final model estimate, final model iiv (cv%)); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Paroxetine_Li2022_final_final_model_iiv_cv;
