% Run (SimBiology): build model + dose, simulate 0..1512.0 h, plot.
p = Paroxetine_Li2022_final_final_model_iiv_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1512.0);
