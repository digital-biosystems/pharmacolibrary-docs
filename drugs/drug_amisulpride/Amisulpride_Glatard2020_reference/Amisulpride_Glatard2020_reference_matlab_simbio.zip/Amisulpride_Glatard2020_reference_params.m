function p = Amisulpride_Glatard2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amisulpride   source: Glatard_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amisulpride_Glatard2020_reference_params';
  p.drug  = 'amisulpride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 956.0;                % central volume [L]
  p.CL = 44.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
