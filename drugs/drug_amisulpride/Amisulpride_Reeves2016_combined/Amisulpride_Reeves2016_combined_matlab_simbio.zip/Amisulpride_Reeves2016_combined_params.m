function p = Amisulpride_Reeves2016_combined_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amisulpride   source: Reeves_2016 / combined   route: oral
  % estimated (absent from source): F
  p.name  = 'Amisulpride_Reeves2016_combined_params';
  p.drug  = 'amisulpride';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 455.0;                % central volume [L]
  p.CL = 54.3;                % clearance [L/h]
  p.Vp = [736.0];             % peripheral volumes [L]
  p.Q  = [111.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.85;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
