function p = Amisulpride_Reeves2016_group_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amisulpride   source: Reeves_2016 / group_1   route: oral
  % estimated (absent from source): F
  p.name  = 'Amisulpride_Reeves2016_group_1_params';
  p.drug  = 'amisulpride';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.0;                % central volume [L]
  p.CL = 84.0;                % clearance [L/h]
  p.Vp = [808.0];             % peripheral volumes [L]
  p.Q  = [117.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.87;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
