function p = Dasatinib_Wang2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dasatinib   source: Wang_2013 / reference   route: oral
  p.name  = 'Dasatinib_Wang2013_reference_params';
  p.drug  = 'dasatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1230.0;                % central volume [L]
  p.CL = 296.0;                % clearance [L/h]
  p.Vp = [1030.0];             % peripheral volumes [L]
  p.Q  = [119.0];             % inter-compartmental clearances [L/h]
  p.ka = 2.1;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
