model Docetaxel_Patil2021_reference
  parameter Real Cl_ref = 5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0058 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.80789,
    adminMass = 1e-05,
    k12 = 0.00031082375478927205,
    k21 = 0.000680293501048218
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>Indian cancer patients</td></tr><tr><td>source_paper:</td><td>Patil_2021</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cam44026-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual variability')</li><li>dropped 'Clearance (%)' → Q22: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a clearance — the row is a variability or a ratio, not the estimate</li><li>dropped 'Inter‐compartmental clearance 1–3 (%)' → Q99: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a clearance — the row is a variability or a ratio, not the estimate</li><li>dropped 'Volume of compartment 3 (%)' → Q77: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a volume — the row is a variability or a ratio, not the estimate</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Patil2021_reference;
