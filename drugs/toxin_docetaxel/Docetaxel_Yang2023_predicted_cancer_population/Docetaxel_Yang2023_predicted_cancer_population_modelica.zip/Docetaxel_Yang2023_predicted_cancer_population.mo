model Docetaxel_Yang2023_predicted_cancer_population
  parameter Real Cl_ref = 9.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00505 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.80789,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>pregnant patients with cancer and non-pregnant patients with cancer</td></tr><tr><td>source_paper:</td><td>Yang_2023</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-02727-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table pharmaceutics-15-02727-t003: rows are variants (Observed: non-pregnant patients with cancer (Byrd et al. (2016) [38]), Predicted: HV population, Predicted: Cancer population, Ratio HV/Cancer, Predicted: Pregnancy (32 GW), Ratio Pregnancy/Cancer), the parameters are the column headers (Cmax (ng/mL)) — read one record per variant</li><li>salvaged Q22 ('predicted mean CL'=33.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'Predicted: Cancer population' is one of 7 estimates of Yang_2023's substance matrix (Observed: non-pregnant patients with cancer (Byrd et al. (2016) [38]), Predicted: HV population, Predicted: Cancer population, Ratio HV/Cancer, Predicted: Pregnancy (32 GW), Ratio Pregnancy/Cancer, Ratio Pregnancy/HV); same population, different estimation method</li><li>gap-filled Q61 (V) from Attia_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Attia_2023 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Yang2023_predicted_cancer_population;
