function p = Docetaxel_OHanlon2026_PD_neutrophil_count_params()
% Docetaxel_OHanlon2026_PD_neutrophil_count_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% docetaxel OHanlon_2026::neutrophil_count: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response neutrophil count in cells × 10^9/L. Driver: docetaxel (cited_pk).
p.E0 = 4.07;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 15000.000000000004;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
