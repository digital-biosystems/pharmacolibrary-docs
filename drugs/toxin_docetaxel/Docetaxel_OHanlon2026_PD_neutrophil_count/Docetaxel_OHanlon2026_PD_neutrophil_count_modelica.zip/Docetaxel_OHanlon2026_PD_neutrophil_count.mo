model Docetaxel_OHanlon2026_PD_neutrophil_count
  "linear exposure-response sweep — OHanlon_2026 :: neutrophil count (neutrophil count)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 4.07,      // [Cells × 10^9/L]
    slope = 15000,  // [meter ** 3 / kilogram; 1/(mg/L) × 1000]
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Docetaxel_OHanlon2026_PD_neutrophil_count</h4><p>The steady-state exposure-response curve of O'Hanlon CJ et al., <i>Clinical pharmacology and therapeutics 119(2):427-436</i> 2026 (<a href=\"https://doi.org/10.1002/cpt.70116\">doi:10.1002/cpt.70116</a>) — neutrophil count [cells × 10^9/L] against docetaxel mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       4.07 Cells × 10^9/L drug-free response (baseline) (Baseline, Q324)
  slope =         15 1/(mg/L) change in response per unit of exposure (Slope (effect), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/L of docetaxel per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.07   (drug-free)</pre></body></html>"));
end Docetaxel_OHanlon2026_PD_neutrophil_count;
