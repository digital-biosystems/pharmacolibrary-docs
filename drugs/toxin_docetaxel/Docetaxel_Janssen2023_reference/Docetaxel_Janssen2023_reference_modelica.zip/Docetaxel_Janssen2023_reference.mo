model Docetaxel_Janssen2023_reference
  parameter Real Cl_ref = 1.9916666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0089 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.80789,
    adminMass = 1e-05,
    k12 = 0.00019038701622971284,
    k21 = 0.00023211567732115673
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>pregnant patients</td></tr><tr><td>source_paper:</td><td>Janssen_2023</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q63 ('Docetaxel V1'=8.9) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Docetaxel Q1'=6.1) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('Docetaxel V2'=7.3) from results prose — parameter table was unreadable</li><li>salvaged Q99 ('Docetaxel Q2'=14.4) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Epirubicin CL'=71.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Janssen2023_reference;
