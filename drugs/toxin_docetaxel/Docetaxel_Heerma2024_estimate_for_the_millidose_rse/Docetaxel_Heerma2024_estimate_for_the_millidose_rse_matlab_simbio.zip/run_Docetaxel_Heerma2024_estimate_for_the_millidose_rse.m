% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Docetaxel_Heerma2024_estimate_for_the_millidose_rse_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
