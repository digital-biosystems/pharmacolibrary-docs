function p = Docetaxel_Heerma2024_estimate_for_the_millidose_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: docetaxel   source: Heerma_2024 / estimate_for_the_millidose_rse   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Docetaxel_Heerma2024_estimate_for_the_millidose_rse_params';
  p.drug  = 'docetaxel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.7;                % central volume [L]
  p.CL = 49.6;                % clearance [L/h]
  p.Vp = [109.0];             % peripheral volumes [L]
  p.Q  = [39.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.075;             % dose [mg]
end
