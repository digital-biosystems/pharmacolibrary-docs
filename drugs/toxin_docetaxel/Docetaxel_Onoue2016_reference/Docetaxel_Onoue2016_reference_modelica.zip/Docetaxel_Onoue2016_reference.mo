model Docetaxel_Onoue2016_reference
  parameter Real Cl_ref = 6.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00505 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.80789,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>Japanese female breast cancer patients</td></tr><tr><td>source_paper:</td><td>Onoue_2016</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for CL from footnote/prose kept as documentation only (['Onoue_2016:abstract'])</li><li>covariate category for V1 from footnote/prose kept as documentation only (['Onoue_2016:abstract'])</li><li>implicit units: 'clearance ... In patients over 58 years' → L/h (from the popPK convention: 'The paper provides no explicit units. Total clearance is typically reported in L/h in population PK studies, and a value')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Attia_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Attia_2023 — borrowed values do not complete its disposition core)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Onoue2016_reference;
