// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Docetaxel_Dong2026_kidneys
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3960.0000000000005},
    MM = 0.80789,
    adminMass = 0.00035,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>male CD-1 mice</td></tr><tr><td>source_paper:</td><td>Dong_2026</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'T/P ratio' — extend the ontology if this is a real PK parameter (source ['Tab3:row8:col4', 'Dong_2026_table_2:row7:col4', 'Dong_2026_table_4:row7:col4'])</li><li>dropped duplicate Q57 ('t1/2 (h)', value '3.00') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'kidneys' subgroup of Dong_2026 (paper reports 10 populations: brain, heart, kidneys, liver, lung, lymph node, plasma, small intestine, spleen, stomach)</li><li>gap-filled Q22 (CL) from Attia_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Attia_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Docetaxel_Dong2026_kidneys;
