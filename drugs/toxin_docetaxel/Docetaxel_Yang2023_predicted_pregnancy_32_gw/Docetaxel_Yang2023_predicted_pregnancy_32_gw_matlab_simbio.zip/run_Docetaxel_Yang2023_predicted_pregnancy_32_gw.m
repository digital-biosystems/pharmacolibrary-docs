% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Docetaxel_Yang2023_predicted_pregnancy_32_gw_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
