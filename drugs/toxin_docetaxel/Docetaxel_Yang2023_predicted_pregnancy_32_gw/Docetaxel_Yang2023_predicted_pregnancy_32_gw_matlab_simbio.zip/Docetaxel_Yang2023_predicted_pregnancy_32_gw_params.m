function p = Docetaxel_Yang2023_predicted_pregnancy_32_gw_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: docetaxel   source: Yang_2023 / predicted_pregnancy_32_gw   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Docetaxel_Yang2023_predicted_pregnancy_32_gw_params';
  p.drug  = 'docetaxel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.05;                % central volume [L]
  p.CL = 33.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
