model Docetaxel_Kenmotsu2017_PD_decrease_anc
  "sigmoid_emax exposure-response sweep — Kenmotsu_2017 :: % decrease ANC (percent decrease in ANC at nadir)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.845,  // [1; % × 0.01]
    EC50 = 0.142,  // [μg·h ml−1]
    gamma = 3.72,
    exposure_per_s = 1);   // 1 μg·h ml−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μg·h ml−1' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1.5, Interval = 0.003),
    Documentation(info = "<html><body><h4>Docetaxel_Kenmotsu2017_PD_decrease_anc</h4><p>The steady-state exposure-response curve of Kenmotsu H et al., <i>British journal of clinical pharmacology 83(11):2416-2425</i> 2017 (<a href=\"https://doi.org/10.1111/bcp.13354\">doi:10.1111/bcp.13354</a>) — percent decrease in ANC at nadir [%] against docetaxel μg·h ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       84.5 %        maximal effect term (Emax, Q323)
  EC50  =      0.142 μg·h ml−1 exposure at half of the maximal effect term (EC50 (Baseline ANC &gt; 4341), Q321)
  gamma =       3.72          Hill coefficient (Shape parameter, γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg·h ml−1 of docetaxel per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.142 μg·h ml−1)  response -0.4225
  exposure -> infinity  response -0.845</pre></body></html>"));
end Docetaxel_Kenmotsu2017_PD_decrease_anc;
