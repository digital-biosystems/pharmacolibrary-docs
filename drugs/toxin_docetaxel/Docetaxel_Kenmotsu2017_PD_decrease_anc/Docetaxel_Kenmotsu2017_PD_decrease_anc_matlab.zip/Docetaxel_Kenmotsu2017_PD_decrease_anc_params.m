function p = Docetaxel_Kenmotsu2017_PD_decrease_anc_params()
% Docetaxel_Kenmotsu2017_PD_decrease_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% docetaxel Kenmotsu_2017::decrease_ANC: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg·h ml−1 per second, in SI inside (kg/m3, s). Response % decrease ANC in %. Driver: docetaxel (pk_record).
p.E0 = 0.0;
p.Emax = -0.845;
p.EC50 = 0.142;
p.gamma = 3.72;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.5;
p.form = 'E0 + Emax*frac';
end
