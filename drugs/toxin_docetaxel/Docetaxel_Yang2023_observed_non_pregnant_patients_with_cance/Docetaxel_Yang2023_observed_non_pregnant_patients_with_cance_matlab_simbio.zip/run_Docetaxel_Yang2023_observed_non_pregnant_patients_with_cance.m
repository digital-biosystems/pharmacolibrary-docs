% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Docetaxel_Yang2023_observed_non_pregnant_patients_with_cance_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
