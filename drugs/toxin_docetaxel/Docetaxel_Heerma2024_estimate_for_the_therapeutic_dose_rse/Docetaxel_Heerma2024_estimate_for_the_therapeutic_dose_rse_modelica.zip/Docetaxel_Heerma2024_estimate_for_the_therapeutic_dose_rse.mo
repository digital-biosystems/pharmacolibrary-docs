model Docetaxel_Heerma2024_estimate_for_the_therapeutic_dose_rse
  parameter Real Cl_ref = 9.61111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.80789,
    adminMass = 7.5e-08,
    k12 = 0.0001607638888888889,
    k21 = 5.7932932932932927e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>Prostate cancer patients</td></tr><tr><td>source_paper:</td><td>Heerma_2024</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>population split: 'estimate for the therapeutic dose (rse)' subgroup of Heerma_2024 (paper reports 2 populations: estimate for the millidose (rse), estimate for the therapeutic dose (rse))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Heerma2024_estimate_for_the_therapeutic_dose_rse;
