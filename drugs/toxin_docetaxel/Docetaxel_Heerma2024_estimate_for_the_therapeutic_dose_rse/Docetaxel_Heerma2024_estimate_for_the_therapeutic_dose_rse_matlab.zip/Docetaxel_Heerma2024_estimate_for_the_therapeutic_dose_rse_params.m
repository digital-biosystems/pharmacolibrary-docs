function p = Docetaxel_Heerma2024_estimate_for_the_therapeutic_dose_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: docetaxel   source: Heerma_2024 / estimate_for_the_therapeutic_dose_rse   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Docetaxel_Heerma2024_estimate_for_the_therapeutic_dose_rse_params';
  p.drug  = 'docetaxel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.0;                % central volume [L]
  p.CL = 34.6;                % clearance [L/h]
  p.Vp = [22.2];             % peripheral volumes [L]
  p.Q  = [4.63];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.075;             % dose [mg]
end
