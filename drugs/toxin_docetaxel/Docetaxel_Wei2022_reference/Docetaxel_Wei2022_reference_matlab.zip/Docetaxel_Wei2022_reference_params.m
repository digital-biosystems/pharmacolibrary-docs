function p = Docetaxel_Wei2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: docetaxel   source: Wei_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Docetaxel_Wei2022_reference_params';
  p.drug  = 'docetaxel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.73;                % central volume [L]
  p.CL = 38.2;                % clearance [L/h]
  p.Vp = [270.87];             % peripheral volumes [L]
  p.Q  = [40.99];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
