model Docetaxel_Wei2022_reference
  parameter Real Cl_ref = 1.0611111111111113e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005730000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.80789,
    adminMass = 1e-05,
    k12 = 0.001987104905953074,
    k21 = 4.203533470340427e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>docetaxel</td></tr><tr><td>population:</td><td>Chinese cancer patients</td></tr><tr><td>source_paper:</td><td>Wei_2022</td></tr><tr><td>measured_compound:</td><td>Docetaxel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>docetaxel 807.89 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Vc (L)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Vc (L)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Q (L/h)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Q (L/h)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Vp (L)' routed out of structural estimates ('IIV (CV%)')</li><li>table section iiv: 'Vp (L)' routed out of structural estimates ('IIV (CV%)')</li><li>table section residual_error: 'σ' routed out of structural estimates ('Residual error (proportional error, CV%)')</li><li>dropped unlinked row (NIL): 'fAge-CL' — extend the ontology if this is a real PK parameter (source ['Wei_2022_table_p5_1:row5:col1'])</li><li>dropped duplicate Q22 ('fBSA-CL', value '0.99') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Docetaxel</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q354 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Docetaxel_Wei2022_reference;
