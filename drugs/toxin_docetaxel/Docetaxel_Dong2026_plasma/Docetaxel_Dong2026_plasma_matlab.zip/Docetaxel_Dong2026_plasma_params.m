function p = Docetaxel_Dong2026_plasma_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: docetaxel   source: Dong_2026 / plasma   route: oral
  % estimated (absent from source): ka
  p.name  = 'Docetaxel_Dong2026_plasma_params';
  p.drug  = 'docetaxel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 589.26;                % central volume [L]
  p.CL = 222.18;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
