% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Cabozantinib_Tan2024_estimates_in_the_registration_file_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
