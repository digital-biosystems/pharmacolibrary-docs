function p = Cabozantinib_Ly2023_ase_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabozantinib   source: Ly_2023 / ase   route: oral
  p.name  = 'Cabozantinib_Ly2023_ase_params';
  p.drug  = 'cabozantinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.69;                % central volume [L]
  p.CL = 0.0323;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.175;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0404;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
