// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Norethindrone_Van2013_treatment_a_oc_alonea_2
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {61560.00000000001},
    MM = 0.29842599999999997,
    adminMass = 2e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>norethindrone</td></tr><tr><td>population:</td><td>healthy women aged 18-45 years</td></tr><tr><td>source_paper:</td><td>Van_2013</td></tr><tr><td>measured_compound:</td><td>norethisterone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>norethindrone 298.426 g/mol (pubchem); norethisterone 298.426 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC τ'</li><li>dropped value-less row: 'AUC 24'</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'C max'</li><li>dropped value-less row: 'C min'</li><li>dropped value-less row: 'OC'</li><li>dropped value-less row: 'PE'</li><li>dropped value-less row: 't ½'</li><li>dropped value-less row: 't max'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=norethisterone</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'treatment a oc alonea' subgroup of Van_2013 (paper reports 4 populations: treatment a / oc alonea, treatment a oc alonea, treatment b / oc + prucalopridea, treatment b oc + prucalopridea)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Norethindrone_Van2013_treatment_a_oc_alonea_2;
