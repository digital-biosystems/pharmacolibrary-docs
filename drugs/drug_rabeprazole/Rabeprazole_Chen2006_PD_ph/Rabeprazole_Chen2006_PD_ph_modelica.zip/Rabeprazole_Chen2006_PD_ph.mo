model Rabeprazole_Chen2006_PD_ph
  "sigmoid_emax exposure-response sweep — Chen_2006 :: pH (intragastric pH)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 2.3,      // [1]
    Emax = 7.32,  // [1]
    EC50 = 5.13e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 5,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  annotation(experiment(StartTime = 0, StopTime = 520, Interval = 1.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rabeprazole</h4><p>Rabeprazole is a proton-pump inhibitor used to treat acid-related conditions such as gastroesophageal reflux disease, duodenal ulcer, and Zollinger–Ellison syndrome. It is an approved medication and remains in use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3515\">Wikidata Q3515</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rabeprazole_Chen2006_PD_ph</h4><p>The steady-state exposure-response curve of Chen ZY et al., <i>European journal of drug metabolism and pharmacokinetics 31(1):27–33</i> 2006 (<a href=\"https://doi.org/10.1007/BF03190639\">doi:10.1007/BF03190639</a>) — intragastric pH against rabeprazole ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.3          drug-free response (baseline) (E0, Q324)
  Emax  =       7.32          maximal effect term (Emax, Q320)
  EC50  =       51.3 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =          5          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of rabeprazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.3   (drug-free)
  exposure = EC50 (51.3 ng/ml)  response 5.96
  exposure -> infinity  response 9.62</pre></body></html>"));
end Rabeprazole_Chen2006_PD_ph;
