function p = Rabeprazole_Chen2006_PD_ph_params()
% Rabeprazole_Chen2006_PD_ph_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rabeprazole Chen_2006::pH: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response pH in its own unit. Driver: rabeprazole (cited_pk).
p.E0 = 2.3;
p.Emax = 7.32;
p.EC50 = 5.129999999999999e-05;
p.gamma = 5.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 520.0;
p.form = 'E0 + Emax*frac';
end
