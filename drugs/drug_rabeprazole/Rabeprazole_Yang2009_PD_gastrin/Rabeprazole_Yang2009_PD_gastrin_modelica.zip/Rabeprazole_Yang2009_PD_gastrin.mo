model Rabeprazole_Yang2009_PD_gastrin
  "sigmoid_emax exposure-response sweep — Yang_2009 :: gastrin (gastrin)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 4.23e-08,      // [kg/m3; pg ml -1 × 1e-09]
    Emax = 2.934e-07,  // [kg/m3; pg ml -1 × 1e-09]
    EC50 = 2e-07,  // [kg/m3; ng ml -1 × 1e-06]
    gamma = 2.0003,
    exposure_per_s = 1e-06);   // 1 ng ml -1 per second
  annotation(experiment(StartTime = 0, StopTime = 2, Interval = 0.004),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rabeprazole</h4><p>Rabeprazole is a proton-pump inhibitor used to treat acid-related conditions such as gastroesophageal reflux disease, duodenal ulcer, and Zollinger–Ellison syndrome. It is an approved medication and remains in use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3515\">Wikidata Q3515</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rabeprazole_Yang2009_PD_gastrin</h4><p>The steady-state exposure-response curve of Yang JC et al., <i>British journal of clinical pharmacology 67(5):503–510</i> 2009 (<a href=\"https://doi.org/10.1111/j.1365-2125.2009.03393.x\">doi:10.1111/j.1365-2125.2009.03393.x</a>) — gastrin [pg ml -1] against rabeprazole ng ml -1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       42.3 pg ml -1 drug-free response (baseline) (E0, Q324)
  Emax  =      293.4 pg ml -1 maximal effect term (Emax, Q320)
  EC50  =        0.2 ng ml -1 exposure at half of the maximal effect term (EC50, Q321)
  gamma =     2.0003          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml -1 of rabeprazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.23e-08   (drug-free)
  exposure = EC50 (0.2 ng ml -1)  response 1.89e-07
  exposure -> infinity  response 3.357e-07</pre></body></html>"));
end Rabeprazole_Yang2009_PD_gastrin;
