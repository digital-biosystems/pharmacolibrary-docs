function p = Rabeprazole_Yang2009_PD_gastrin_params()
% Rabeprazole_Yang2009_PD_gastrin_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rabeprazole Yang_2009::gastrin: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml -1 per second, in SI inside (kg/m3, s). Response gastrin in pg ml -1. Driver: rabeprazole (pk_record).
p.E0 = 4.23e-08;
p.Emax = 2.934e-07;
p.EC50 = 2e-07;
p.gamma = 2.0003;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2.0;
p.form = 'E0 + Emax*frac';
end
