% Run: build params, simulate 0..40.0 h, plot every molecule + save Glipizide_Badran2022_glp_tdf.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Glipizide_Badran2022_glp_tdf.m
here = fileparts(mfilename('fullpath'));
p = Glipizide_Badran2022_glp_tdf_params();
out = simulate_network(p, 0:0.05:40.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('glipizide — Badran_2022 (retention function)');
print(fig, fullfile(here, 'Glipizide_Badran2022_glp_tdf.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Glipizide_Badran2022_glp_tdf.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Glipizide_Badran2022_glp_tdf.json'), 'w');
try
  s.model = 'Glipizide_Badran2022_glp_tdf'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Glipizide_Badran2022_glp_tdf"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Glipizide_Badran2022_glp_tdf.png, Glipizide_Badran2022_glp_tdf.csv, Glipizide_Badran2022_glp_tdf.json\n');
