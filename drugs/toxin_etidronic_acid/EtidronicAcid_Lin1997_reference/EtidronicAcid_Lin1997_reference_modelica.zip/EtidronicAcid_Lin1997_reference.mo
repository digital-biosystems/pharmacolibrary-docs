// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model EtidronicAcid_Lin1997_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {60839.99999999999},
    adminMass = 0.0015,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>etidronic_acid</td></tr><tr><td>population:</td><td>rats (biodistribution) and New Zealand rabbits with induced tibial bone lesions (L/N ratio)</td></tr><tr><td>source_paper:</td><td>Lin_1997</td></tr><tr><td>measured_compound:</td><td>188Re-HEDP (measured as 188Re radioactivity)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>etidronic_acid 206.027 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'physical half-life' Q900 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('biological half-life in bone', value 60.86) — already have one for this compound</li><li>dropped duplicate Q57 ('biological half-lives in muscle', value 2.99) — already have one for this compound</li><li>relinked 'biological half-lives in blood' Q23 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('biological half-lives in blood', value 6.21) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=188Re-HEDP (measured as 188Re radioactivity)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for '188Re-HEDP (measured as 188Re radioactivity)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end EtidronicAcid_Lin1997_reference;
