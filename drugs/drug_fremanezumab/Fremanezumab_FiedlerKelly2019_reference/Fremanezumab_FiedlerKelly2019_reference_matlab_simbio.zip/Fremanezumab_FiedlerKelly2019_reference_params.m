function p = Fremanezumab_FiedlerKelly2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fremanezumab   source: Fiedler-Kelly_2019 / reference   route: oral
  p.name  = 'Fremanezumab_FiedlerKelly2019_reference_params';
  p.drug  = 'fremanezumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.98;                % central volume [L]
  p.CL = 0.191667;                % clearance [L/h]
  p.Vp = [1.72];             % peripheral volumes [L]
  p.Q  = [0.010917];             % inter-compartmental clearances [L/h]
  p.ka = 0.658333;                % absorption rate [1/h]
  p.F  = 0.658;                 % bioavailability [0-1]
  p.Tlag = 1.9272;             % absorption lag [h]
  p.dose = 225.0;             % dose [mg]
end
