model Fremanezumab_FiedlerKelly2019_reference
  parameter Real Cl_ref = 1.0439814814814816e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00298 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.658,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.000225,
    ka = 2.083333333333333e-06,
    Tlag = 6937.92,
    k12 = 1.0175863783246334e-06,
    k21 = 1.7630275624461673e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fremanezumab</h4><p>Fremanezumab is a monoclonal antibody used to prevent migraine, including migraine with and without aura. It is an approved CGRP-antagonist medicine authorised in the European Union for migraine prevention.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39048381\">Wikidata Q39048381</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fremanezumab</td></tr><tr><td>population:</td><td>healthy subjects and patients with migraine</td></tr><tr><td>source_paper:</td><td>Fiedler-Kelly_2019</td></tr><tr><td>measured_compound:</td><td>fremanezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp14096-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q63 ('VC,SC: Central volume of distribution SC (L)e', value '1.88') — already have one for this compound</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 10.6 (source ['bcp14096-tbl-0002:footnote', 'bcp14096-tbl-0002:footnote', 'bcp14096-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>covariate category for CL from footnote/prose kept as documentation only (['bcp14096-tbl-0002:footnote'])</li><li>covariate category for V1 from footnote/prose kept as documentation only (['bcp14096-tbl-0002:footnote'])</li><li>covariate category for V1 from footnote/prose kept as documentation only (['bcp14096-tbl-0002:footnote'])</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 3.1 (source ['bcp14096-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fremanezumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'fremanezumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 11491200, Tolerance = 1e-9, Interval = 1));
end Fremanezumab_FiedlerKelly2019_reference;
