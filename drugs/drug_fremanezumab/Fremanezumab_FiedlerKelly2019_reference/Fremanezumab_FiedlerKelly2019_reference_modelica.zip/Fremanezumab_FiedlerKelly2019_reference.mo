model Fremanezumab_FiedlerKelly2019_reference
  parameter Real Cl_ref = 1.0439814814814816e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fremanezumab</td></tr><tr><td>population:</td><td>healthy subjects and patients with migraine</td></tr><tr><td>source_paper:</td><td>Fiedler-Kelly_2019</td></tr><tr><td>measured_compound:</td><td>fremanezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fremanezumab</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central distribution volume' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fremanezumab_FiedlerKelly2019_reference;
