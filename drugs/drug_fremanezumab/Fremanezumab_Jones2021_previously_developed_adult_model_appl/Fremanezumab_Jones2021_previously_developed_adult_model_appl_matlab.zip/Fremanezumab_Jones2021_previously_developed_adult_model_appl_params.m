function p = Fremanezumab_Jones2021_previously_developed_adult_model_appl_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fremanezumab   source: Jones_2021 / previously_developed_adult_model_applied_to_pediatric_data   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Fremanezumab_Jones2021_previously_developed_adult_model_appl_params';
  p.drug  = 'fremanezumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.88;                % central volume [L]
  p.CL = 0.003758;                % clearance [L/h]
  p.Vp = [1.72];             % peripheral volumes [L]
  p.Q  = [0.010917];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.658;                 % bioavailability [0-1]
  p.Tlag = 1.9272;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
