model Fremanezumab_Jones2021_previously_developed_adult_model_appl
  parameter Real Cl_ref = 1.0439814814814816e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.658,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 6937.92,
    k12 = 1.6129826635145786e-06,
    k21 = 1.7630275624461673e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fremanezumab</td></tr><tr><td>population:</td><td>pediatric patients with migraine</td></tr><tr><td>source_paper:</td><td>Jones_2021</td></tr><tr><td>measured_compound:</td><td>fremanezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00785-t001</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fremanezumab</li><li>population split: 'previously developed adult model applied to pediatric data' subgroup of Jones_2021 (paper reports 2 populations: pediatric model to support phase 3 development 1, previously developed adult model applied to pediatric data)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fremanezumab_Jones2021_previously_developed_adult_model_appl;
