% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Fremanezumab_Jones2021_pediatric_model_to_support_phase_3_de_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
