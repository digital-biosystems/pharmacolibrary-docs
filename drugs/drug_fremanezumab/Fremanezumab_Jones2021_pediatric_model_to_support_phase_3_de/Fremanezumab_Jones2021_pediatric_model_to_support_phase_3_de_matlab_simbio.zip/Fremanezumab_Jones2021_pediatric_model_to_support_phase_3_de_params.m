function p = Fremanezumab_Jones2021_pediatric_model_to_support_phase_3_de_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fremanezumab   source: Jones_2021 / pediatric_model_to_support_phase_3_development_1   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'Fremanezumab_Jones2021_pediatric_model_to_support_phase_3_de_params';
  p.drug  = 'fremanezumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.89;                % central volume [L]
  p.CL = 0.003771;                % clearance [L/h]
  p.Vp = [1.72];             % peripheral volumes [L]
  p.Q  = [0.010917];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
