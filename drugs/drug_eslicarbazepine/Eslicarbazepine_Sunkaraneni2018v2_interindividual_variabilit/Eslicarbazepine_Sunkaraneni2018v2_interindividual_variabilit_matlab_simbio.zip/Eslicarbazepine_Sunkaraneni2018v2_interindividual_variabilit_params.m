function p = Eslicarbazepine_Sunkaraneni2018v2_interindividual_variabilit_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eslicarbazepine   source: Sunkaraneni_2018_2 / interindividual_variability_residual_variabilitya   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Eslicarbazepine_Sunkaraneni2018v2_interindividual_variabilit_params';
  p.drug  = 'eslicarbazepine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 65.1;                % central volume [L]
  p.CL = 15.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
