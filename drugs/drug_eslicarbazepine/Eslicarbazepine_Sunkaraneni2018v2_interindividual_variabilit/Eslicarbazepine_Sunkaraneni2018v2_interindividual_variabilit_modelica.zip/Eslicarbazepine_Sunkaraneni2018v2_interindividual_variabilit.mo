model Eslicarbazepine_Sunkaraneni2018v2_interindividual_variabilit
  parameter Real Cl_ref = 4.305555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06509999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>eslicarbazepine</td></tr><tr><td>population:</td><td>pediatric patients with partial-onset seizures</td></tr><tr><td>source_paper:</td><td>Sunkaraneni_2018_2</td></tr><tr><td>measured_compound:</td><td>eslicarbazepine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=eslicarbazepine</li><li>population split: 'interindividual variability/residual variabilitya' subgroup of Sunkaraneni_2018_2 (paper reports 2 populations: final parameter estimate, interindividual variability/residual variabilitya)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eslicarbazepine_Sunkaraneni2018v2_interindividual_variabilit;
