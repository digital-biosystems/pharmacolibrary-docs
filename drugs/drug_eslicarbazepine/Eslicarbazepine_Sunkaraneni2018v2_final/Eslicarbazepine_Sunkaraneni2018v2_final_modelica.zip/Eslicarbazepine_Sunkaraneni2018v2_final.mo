model Eslicarbazepine_Sunkaraneni2018v2_final
  parameter Real Cl_ref = 8.11111111111111e-07 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Real Vd_ref = 0.00478 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref + (7.111111111111111e-06)*(if cov_category_0 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>eslicarbazepine</td></tr><tr><td>population:</td><td>pediatric patients with partial-onset seizures</td></tr><tr><td>source_paper:</td><td>Sunkaraneni_2018_2</td></tr><tr><td>measured_compound:</td><td>eslicarbazepine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'RV CCV component' — extend the ontology if this is a real PK parameter (source ['Tab3:row9:col1', 'Tab3:row9:col2'])</li><li>dropped unlinked row (NIL): 'RV additive component' — extend the ontology if this is a real PK parameter (source ['Tab3:row10:col1', 'Tab3:row10:col2'])</li><li>dropped duplicate covariate effect 'category'/'' on Q22 — ambiguous identity (two shifts cannot share one category)</li><li>covariate effect for Q49 has no base parameter row (kept as unattached equation-variable)</li><li>dropped duplicate covariate effect 'category'/'' on Q49 — ambiguous identity (two shifts cannot share one category)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=eslicarbazepine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'final parameter estimate' is the final model of Sunkaraneni_2018_2 (paper reports 2 stages: final parameter estimate, interindividual variability/residual variabilitya); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eslicarbazepine_Sunkaraneni2018v2_final;
