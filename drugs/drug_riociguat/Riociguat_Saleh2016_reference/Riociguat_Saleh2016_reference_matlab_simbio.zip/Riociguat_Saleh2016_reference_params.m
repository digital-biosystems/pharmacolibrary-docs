function p = Riociguat_Saleh2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: riociguat   source: Saleh_2016 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Riociguat_Saleh2016_reference_params';
  p.drug  = 'riociguat';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.3;                % central volume [L]
  p.CL = 1.81;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.5;             % dose [mg]
end
