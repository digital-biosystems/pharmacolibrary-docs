// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SodiumArsenate_Diacomanolis2013_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {231624.0},
    MM = 0.074922,
    adminMass = 0.000175,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_arsenate</td></tr><tr><td>population:</td><td>Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Diacomanolis_2013</td></tr><tr><td>measured_compound:</td><td>Arsenic</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Arsenic 74.922 g/mol (pubchem); sodium_arsenate 163.924 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PK parameters' — extend the ontology if this is a real PK parameter (source ['Diacomanolis_2013_table_1:row0:col2', 'Diacomanolis_2013_table_1:row0:col3', 'Diacomanolis_2013_table_1:row0:col4', 'Diacomanolis_2013_table_1:row0:col5', 'Diacomanolis_2013_table_1:row4:col2', 'Diacomanolis_2013_table_1:row4:col3', 'Diacomanolis_2013_table_1:row4:col4', 'Diacomanolis_2013_table_1:row4:col5'])</li><li>dropped unlinked row (NIL): '% ABA' — extend the ontology if this is a real PK parameter (source ['Diacomanolis_2013_table_1:row3:col3', 'Diacomanolis_2013_table_1:row3:col4', 'Diacomanolis_2013_table_1:row3:col5', 'Diacomanolis_2013_table_1:row7:col2', 'Diacomanolis_2013_table_1:row7:col3', 'Diacomanolis_2013_table_1:row7:col4', 'Diacomanolis_2013_table_1:row7:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Arsenic</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>review gap-fill skipped: this record measures 'Arsenic', not sodium_arsenate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 2419.2));
end SodiumArsenate_Diacomanolis2013_reference;
