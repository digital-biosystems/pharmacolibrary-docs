model Quizartinib_Kang2021_PD_qtcf
  "sigmoid_emax exposure-response sweep — Kang_2021 :: QTcF (QTcF)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.413,      // [s; ms × 0.001]
    Emax = 0.0312,  // [s; ms × 0.001]
    EC50 = 0.000315,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.52,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  annotation(experiment(StartTime = 0, StopTime = 3200, Interval = 6.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About quizartinib</h4><p>Quizartinib is a protein kinase inhibitor used to treat acute myeloid leukemia. It is an approved medicine, authorised in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7272714\">Wikidata Q7272714</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Quizartinib_Kang2021_PD_qtcf</h4><p>The steady-state exposure-response curve of Kang D et al., <i>Cancer chemotherapy and pharmacology 87(4):513–523</i> 2021 (<a href=\"https://doi.org/10.1007/s00280-020-04204-y\">doi:10.1007/s00280-020-04204-y</a>) — QTcF [ms] against quizartinib and AC886 ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        413 ms       drug-free response (baseline) (Baseline QTcF, Q324)
  Emax  =       31.2 ms       maximal effect term (Maximum effect of parent drug, Q320)
  EC50  =        315 ng/mL    exposure at half of the maximal effect term (Concentration at 50% of maximum parent effect, Q321)
  gamma =       1.52          Hill coefficient (Hill coefficient for parent drug, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of quizartinib and AC886 per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.413   (drug-free)
  exposure = EC50 (315 ng/mL)  response 0.4286
  exposure -> infinity  response 0.4442</pre></body></html>"));
end Quizartinib_Kang2021_PD_qtcf;
