function p = Quizartinib_Kang2021_PD_qtcf_params()
% Quizartinib_Kang2021_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quizartinib Kang_2021::QTcF: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response QTcF in ms. Driver: quizartinib and AC886 (conc_no_pk).
p.E0 = 0.41300000000000003;
p.Emax = 0.0312;
p.EC50 = 0.00031499999999999996;
p.gamma = 1.52;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3200.0;
p.form = 'E0 + Emax*frac';
end
