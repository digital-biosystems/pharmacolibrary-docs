function p = Nadroparin_Mast2023_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nadroparin   source: Mast_2023 / final   route: oral
  % estimated (absent from source): dose
  p.name  = 'Nadroparin_Mast2023_final_params';
  p.drug  = 'nadroparin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.24;                % central volume [L]
  p.CL = 21.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.942;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
