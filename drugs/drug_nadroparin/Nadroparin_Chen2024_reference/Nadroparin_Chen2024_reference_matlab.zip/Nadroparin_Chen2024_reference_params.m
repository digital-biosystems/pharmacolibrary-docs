function p = Nadroparin_Chen2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nadroparin   source: Chen_2024 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Nadroparin_Chen2024_reference_params';
  p.drug  = 'nadroparin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.55;                % central volume [L]
  p.CL = 0.211;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.495;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
