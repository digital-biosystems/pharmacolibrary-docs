model DermatanSulfate_Qiao2026_reference
  parameter Real Cl_ref = 1.688888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0246 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47537999999999997,
    adminMass = 1e-05,
    k12 = 3.511743450767841e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dermatan_sulfate</h4><p>Dermatan sulfate, a glycosaminoglycan also known as chondroitin sulfate B, has been investigated as an antithrombotic agent for preventing blood clots. It remains an investigational compound and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2335618\">Wikidata Q2335618</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dermatan_sulfate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Qiao_2026</td></tr><tr><td>measured_compound:</td><td>dermatan_sulfate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dermatan_sulfate 475.38 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Qiao_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end DermatanSulfate_Qiao2026_reference;
