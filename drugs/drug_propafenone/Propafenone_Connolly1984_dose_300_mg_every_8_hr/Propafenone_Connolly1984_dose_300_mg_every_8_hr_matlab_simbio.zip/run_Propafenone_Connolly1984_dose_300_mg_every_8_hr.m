% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Propafenone_Connolly1984_dose_300_mg_every_8_hr_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
