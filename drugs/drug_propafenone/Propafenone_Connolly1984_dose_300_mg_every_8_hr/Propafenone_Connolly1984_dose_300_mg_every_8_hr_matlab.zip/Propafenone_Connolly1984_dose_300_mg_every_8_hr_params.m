function p = Propafenone_Connolly1984_dose_300_mg_every_8_hr_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propafenone   source: Connolly_1984 / dose_300_mg_every_8_hr   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Propafenone_Connolly1984_dose_300_mg_every_8_hr_params';
  p.drug  = 'propafenone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 252.0;                % central volume [L]
  p.CL = 47.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
