model CoagulationFactorVii_Zenklusen2024_reference
  parameter Real Cl_ref = 1.388888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05770780163555854 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About coagulation_factor_vii</h4><p>Coagulation factor VII is a blood clotting protein used to treat or prevent bleeding caused by a lack or defect of this factor. It is an approved medicine, given as a blood coagulation factor product, and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412850\">Wikidata Q412850</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>coagulation_factor_vii</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zenklusen_2024</td></tr><tr><td>measured_compound:</td><td>coagulation_factor_vii</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zenklusen_2024) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end CoagulationFactorVii_Zenklusen2024_reference;
