% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = CoagulationFactorVii_Klitgaard2008_patients_with_traumatic_b_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
