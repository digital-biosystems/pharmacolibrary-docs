function p = CoagulationFactorVii_Klitgaard2008_noncirrhotic_patients_und_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: coagulation_factor_vii   source: Klitgaard_2008 / noncirrhotic_patients_undergoing_liver_resection_27_klitgaard_data_on_file_2005   route: iv_bolus
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'CoagulationFactorVii_Klitgaard2008_noncirrhotic_patients_und_params';
  p.drug  = 'coagulation_factor_vii';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 12.215;                % central volume [L]
  p.CL = 4.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
