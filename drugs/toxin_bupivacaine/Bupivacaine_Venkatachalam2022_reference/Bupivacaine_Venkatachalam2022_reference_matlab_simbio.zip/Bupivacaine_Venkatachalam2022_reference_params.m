function p = Bupivacaine_Venkatachalam2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bupivacaine   source: Venkatachalam_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Bupivacaine_Venkatachalam2022_reference_params';
  p.drug  = 'bupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.0;                % central volume [L]
  p.CL = 0.12;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.276;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
