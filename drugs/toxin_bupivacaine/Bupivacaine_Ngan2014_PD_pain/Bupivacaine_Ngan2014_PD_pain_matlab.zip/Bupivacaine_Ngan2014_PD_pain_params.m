function p = Bupivacaine_Ngan2014_PD_pain_params()
% Bupivacaine_Ngan2014_PD_pain_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bupivacaine Ngan_2014::Pain: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms per second, in SI inside (kg/m3, s). Response Pain in % decrease in pain score. Driver: bupivacaine (dose_only).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 1.59e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 16000.0;
p.form = 'E0 + Emax*frac';
end
