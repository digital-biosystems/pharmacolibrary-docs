model Bupivacaine_Ngan2014_PD_pain
  "emax exposure-response sweep — Ngan_2014 :: Pain (Pain)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 1.59e-06,  // [kg; micrograms × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 micrograms per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16000, Interval = 32),
    Documentation(info = "<html><body><h4>Bupivacaine_Ngan2014_PD_pain</h4><p>The steady-state exposure-response curve of Ngan Kee WD et al., <i>Anesthesiology 120(5):1126–1136</i> 2014 (<a href=\"https://doi.org/10.1097/ALN.0000000000000118\">doi:10.1097/ALN.0000000000000118</a>) — Pain [% decrease in pain score] against bupivacaine micrograms — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q323)
  EC50  =       1590 micrograms exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micrograms of bupivacaine per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1590 micrograms)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Bupivacaine_Ngan2014_PD_pain;
