model Bupivacaine_Araneda2025_reference
  parameter Real Cl_ref = 4.8e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0419 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 54.3,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.288435,
    adminMass = 0.0001,
    ka = 7.666666666666667e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bupivacaine</td></tr><tr><td>population:</td><td>patients receiving interfacial blocks and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Araneda_2025</td></tr><tr><td>measured_compound:</td><td>Levobupivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Levobupivacaine 288.435 g/mol (pubchem); bupivacaine 288.435 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'P' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract', 'Araneda_2025:abstract'])</li><li>dropped unlinked row (NIL): 'ESP samples' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract'])</li><li>dropped unlinked row (NIL): 'TAP samples' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract'])</li><li>dropped unlinked row (NIL): 'bupivacaine i.v.' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract'])</li><li>dropped unlinked row (NIL): 'Simulated doses' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract', 'Araneda_2025:abstract', 'Araneda_2025:abstract', 'Araneda_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levobupivacaine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Eljebari_2014's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bupivacaine_Araneda2025_reference;
