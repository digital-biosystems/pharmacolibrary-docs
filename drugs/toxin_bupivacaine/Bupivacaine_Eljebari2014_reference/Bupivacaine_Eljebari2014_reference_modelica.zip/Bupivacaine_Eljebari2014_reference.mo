model Bupivacaine_Eljebari2014_reference
  parameter Real Cl_ref = 1.55e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.134 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.288435,
    adminMass = 0.00015,
    ka = 7.666666666666667e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bupivacaine</td></tr><tr><td>population:</td><td>patients scheduled for elective lower extremity surgery</td></tr><tr><td>source_paper:</td><td>Eljebari_2014</td></tr><tr><td>measured_compound:</td><td>Bupivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bupivacaine 288.435 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (ml/min) θ1=930 (930±282.24)' routed out of structural estimates ('Inter individual variability (CV %)')</li><li>table section iiv: 'VC (ml) θ2=134 000 (134000±33510)' routed out of structural estimates ('Inter individual variability (CV %)')</li><li>table section iiv: 'Ka2 (min-1) θ4=0.292 (0.292±0.162)' routed out of structural estimates ('Inter individual variability (CV %)')</li><li>dropped value-less row: 'Table 2. Population pharmacokinetic parameters of the final model with two absorption kinetics of bupivacaine (n=31)' (captured trailing unit 'n=31' for child rows)</li><li>salvaged Q57 ('T1/2 of bupivacaine'=100.43) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('population clearance'=930) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central volume of distribution'=134) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Bupivacaine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>model equation 'θi = TV (θi)* exp (ηθi)' not bound — neither LHS nor base term 'TV' linked to an ontology parameter</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Eljebari_2014's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bupivacaine_Eljebari2014_reference;
