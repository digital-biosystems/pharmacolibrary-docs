function p = Bupivacaine_Eljebari2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bupivacaine   source: Eljebari_2014 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Bupivacaine_Eljebari2014_reference_params';
  p.drug  = 'bupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 134.0;                % central volume [L]
  p.CL = 55.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.276;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
