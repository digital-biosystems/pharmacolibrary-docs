function p = Lidocaine_Greuber2021_lidocaine_1_8_3_ts_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lidocaine   source: Greuber_2021 / lidocaine_1_8_3_ts   route: oral
  % estimated (absent from source): ka
  p.name  = 'Lidocaine_Greuber2021_lidocaine_1_8_3_ts_params';
  p.drug  = 'lidocaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 286.69;                % central volume [L]
  p.CL = 35.33;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 108.0;             % dose [mg]
end
