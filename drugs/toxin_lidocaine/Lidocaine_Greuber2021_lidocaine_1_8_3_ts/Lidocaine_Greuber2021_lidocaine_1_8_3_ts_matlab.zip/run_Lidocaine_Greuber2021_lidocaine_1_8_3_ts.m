% Run: build params, simulate 0..28.0 h, plot + save Lidocaine_Greuber2021_lidocaine_1_8_3_ts.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Lidocaine_Greuber2021_lidocaine_1_8_3_ts.m
here = fileparts(mfilename('fullpath'));
p = Lidocaine_Greuber2021_lidocaine_1_8_3_ts_params();
out = simulate_pk(p, 0:0.05:28.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('lidocaine — Greuber_2021 (oral)');
print(fig, fullfile(here, 'Lidocaine_Greuber2021_lidocaine_1_8_3_ts.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Lidocaine_Greuber2021_lidocaine_1_8_3_ts.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Lidocaine_Greuber2021_lidocaine_1_8_3_ts.json'), 'w');
try
  s.model = 'Lidocaine_Greuber2021_lidocaine_1_8_3_ts'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Lidocaine_Greuber2021_lidocaine_1_8_3_ts","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Lidocaine_Greuber2021_lidocaine_1_8_3_ts.png, Lidocaine_Greuber2021_lidocaine_1_8_3_ts.csv, Lidocaine_Greuber2021_lidocaine_1_8_3_ts.json\n');
