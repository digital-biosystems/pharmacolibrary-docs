model Lidocaine_Greuber2021_lidocaine_1_8_3_ts
  parameter Real Cl_ref = 9.813888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28669 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.234343,
    adminMass = 0.000108,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lidocaine</td></tr><tr><td>population:</td><td>healthy human volunteers</td></tr><tr><td>source_paper:</td><td>Greuber_2021</td></tr><tr><td>measured_compound:</td><td>Lidocaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>lidocaine 234.343 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Apparent dose (mg)' — extend the ontology if this is a real PK parameter (source ['Tab5:row7:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Lidocaine</li><li>population split: 'lidocaine 1.8% (3 ts)n = 14' subgroup of Greuber_2021 (paper reports 4 populations: lidocaine 1.8% (3 ts)n = 14, lidocaine 5.4% (1 ts)n = 14, lidocaine 5.4% (2 ts)n = 14, lidocaine 5.4% (3 ts)n = 15)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Lidocaine_Greuber2021_lidocaine_1_8_3_ts;
