model Lidocaine_Tognolini2025_reference
  parameter Real Cl_ref = 4.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.216 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.234343,
    adminMass = 0.003
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lidocaine</td></tr><tr><td>population:</td><td>patients with a BMI >= 30 kg.m-2 undergoing elective laparoscopic abdominal surgery</td></tr><tr><td>source_paper:</td><td>Tognolini_2025</td></tr><tr><td>measured_compound:</td><td>Lidocaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Glycinexylidide 178.235 g/mol (pubchem); Lidocaine 234.343 g/mol (pubchem); Monoethylglycinexylidide 206.289 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l.kg^{-1}' (Vss)</li><li>unit_dimension_unknown: 'l.kg^{-1}.h^{-1}' (CL)</li><li>implicit units: 'Unbound lidocaine volume of distribution' → L/kg (from the popPK convention: 'No unit provided in text. Value is 2.1. Lidocaine is typically administered based on body weight, and its steady-state v')</li><li>implicit units: 'clearance' → L/h (from the popPK convention: 'No unit provided in text. Value is 1.7. Total clearance (CL) is conventionally reported in L/h or L/h/kg in population P')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lidocaine</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 2 linked by role; re-tagged Lidocaine→parent ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Osborne_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1641600, Tolerance = 1e-9, Interval = 1));
end Lidocaine_Tognolini2025_reference;
