model Lidocaine_Riff2018_reference
  parameter Real Cl_ref = 6.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.195 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.234343,
    adminMass = 0.0001,
    ka = 7.777777777777778e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lidocaine</td></tr><tr><td>population:</td><td>elderly women undergoing breast cancer surgery</td></tr><tr><td>source_paper:</td><td>Riff_2018</td></tr><tr><td>measured_compound:</td><td>Lidocaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lidocaine 234.343 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'median tumescent lidocaine dose' — extend the ontology if this is a real PK parameter (source ['Riff_2018:abstract'])</li><li>dropped unlinked row (NIL): 'infusion time' — extend the ontology if this is a real PK parameter (source ['Riff_2018:abstract'])</li><li>unit_dimension_unknown: 'L h<sup>-1</sup>' (CL/F)</li><li>unit_dimension_unknown: 'h<sup>-1</sup>' (kabs)</li><li>unit_dimension_unknown: 'h<sup>-1</sup>' (kabs)</li><li>dropped duplicate Q49 ('instillation absorption rate', value '2.56') — already have one for this compound</li><li>implicit units: 'apparent clearance' → L/h (from the popPK convention: 'Apparent clearance (CL/F) is conventionally expressed in L/h. The value 24.7 is consistent with this magnitude for a typ')</li><li>implicit units: 'tumescent absorption rate' → 1/h (from the popPK convention: 'First-order absorption rate constants (kabs) are conventionally expressed in inverse time (1/h). The value 0.28 is consi')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Lidocaine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Lidocaine_Riff2018_reference;
