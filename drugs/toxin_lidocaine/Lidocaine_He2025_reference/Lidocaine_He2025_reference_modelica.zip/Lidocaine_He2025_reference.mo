// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Lidocaine_He2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.00873, 0.0636},
    CLelim = {7.25e-06, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {1.138888888888889e-05, 1.138888888888889e-05}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lidocaine</td></tr><tr><td>population:</td><td>Chinese hepatectomy patients</td></tr><tr><td>source_paper:</td><td>He_2025</td></tr><tr><td>measured_compound:</td><td>Lidocaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>molar_masses:</td><td>Lidocaine 234.343 g/mol (pubchem); MEGX (Monoethylglycinexylide) 206.289 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'V1' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'CLFM' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'CLD' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'CLEFM' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'CLE' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section iiv: 'CLG' routed out of structural estimates ('Inter-Individual Variability (%CV)')</li><li>table section residual_error: 'σ2Lidocaine' routed out of structural estimates ('Residual errors (%CV)')</li><li>table section residual_error: 'σ2MEGX' routed out of structural estimates ('Residual errors (%CV)')</li><li>table section residual_error: 'σ2GX' routed out of structural estimates ('Residual errors (%CV)')</li><li>column 'estimate (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>column 'estimate (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>column 'estimate (95% ci)' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lidocaine_He2025_reference;
