function p = Lidocaine_He2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lidocaine   source: He_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Lidocaine_He2025_reference_params';
  p.drug  = 'lidocaine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.73;                % central volume [L]
  p.CL = 26.1;                % clearance [L/h]
  p.Vp = [63.6];             % peripheral volumes [L]
  p.Q  = [41.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 57.97;             % dose [mg]
end
