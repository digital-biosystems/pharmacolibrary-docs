model Lidocaine_Osborne2025_PD_vas
  "sigmoid_emax exposure-response sweep — Osborne_2025 :: VAS (Pain score (VAS))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 10,      // [VAS 0–10 cm]
    Emax = -0.59,  // [VAS 0–10 cm]
    EC50 = 0.00021,  // [kg/m3; mg/L × 0.001]
    gamma = 4,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 2.1, Interval = 0.0042),
    Documentation(info = "<html><body><h4>Lidocaine_Osborne2025_PD_vas</h4><p>The steady-state exposure-response curve of Osborne KW et al., <i>European journal of drug metabolism and pharmacokinetics 50(4):295-306</i> 2025 (<a href=\"https://doi.org/10.1007/s13318-025-00948-1\">doi:10.1007/s13318-025-00948-1</a>) — Pain score (VAS) [cm] against unbound lidocaine mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         10 VAS 0–10 cm drug-free response (baseline) (E0, Q324)
  Emax  =       0.59 VAS 0–10 cm maximal effect term (Emax, Q323)
  EC50  =       0.21 mg/L     exposure at half of the maximal effect term (C50, Q321)
  gamma =          4          Hill coefficient (HILL, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of unbound lidocaine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 10   (drug-free)
  exposure = EC50 (0.21 mg/L)  response 9.705
  exposure -> infinity  response 9.41</pre></body></html>"));
end Lidocaine_Osborne2025_PD_vas;
