function p = Lidocaine_Osborne2025_PD_vas_params()
% Lidocaine_Osborne2025_PD_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lidocaine Osborne_2025::VAS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response VAS in cm. Driver: unbound lidocaine (conc_no_pk).
p.E0 = 10.0;
p.Emax = -0.59;
p.EC50 = 0.00020999999999999995;
p.gamma = 4.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.1;
p.form = 'E0 + Emax*frac';
end
