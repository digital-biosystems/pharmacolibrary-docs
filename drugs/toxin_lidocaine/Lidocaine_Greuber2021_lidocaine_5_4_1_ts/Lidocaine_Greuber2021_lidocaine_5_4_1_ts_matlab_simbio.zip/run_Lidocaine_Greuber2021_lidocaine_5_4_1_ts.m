% Run (SimBiology): build model + dose, simulate 0..29.0 h, plot.
p = Lidocaine_Greuber2021_lidocaine_5_4_1_ts_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 29.0);
