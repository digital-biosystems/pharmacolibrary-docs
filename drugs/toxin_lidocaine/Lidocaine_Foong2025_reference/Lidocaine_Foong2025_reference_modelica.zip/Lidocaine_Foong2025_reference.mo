model Lidocaine_Foong2025_reference
  parameter Real Cl_ref = 1.2749999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0252 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.234343,
    adminMass = 0.003
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lidocaine</td></tr><tr><td>population:</td><td>adult surgical patients (donor nephrectomy and cholecystectomy)</td></tr><tr><td>source_paper:</td><td>Foong_2025</td></tr><tr><td>measured_compound:</td><td>Lidocaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>GX 178.235 g/mol (pubchem); Lidocaine 234.343 g/mol (pubchem); MEGX 206.289 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'decreasing by' — extend the ontology if this is a real PK parameter (source ['Foong_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lidocaine</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — a metabolite is formed from another metabolite (a chain)</li><li>row roles (LLM): model_class=compartmental; 5/5 row label(s) assigned, 6 linked by role; re-tagged Lidocaine→parent ×7</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lidocaine_Foong2025_reference;
