model Atazanavir_Savic2012_reference
  parameter Real Cl_ref = 4.444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0792 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7048555,
    adminMass = 0.0003,
    ka = 0.00075,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atazanavir</h4><p>Atazanavir is an antiviral protease inhibitor used to treat HIV infections. It is taken by mouth as capsules or tablets. The medication is authorised in the European Union and is widely used as part of combination therapy.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q423467\">Wikidata Q423467</a>, <a href=\"https://en.wikipedia.org/wiki/Atazanavir?oldid=1384665709\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atazanavir</td></tr><tr><td>population:</td><td>treatment-naive HIV-infected patients</td></tr><tr><td>source_paper:</td><td>Savic_2012</td></tr><tr><td>measured_compound:</td><td>atazanavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atazanavir 704.856 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('unboosted ATV CL'=16) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F (l/h)'=7.2) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F (l)'=79.2) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('ka (h -1 )'=2.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=atazanavir</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atazanavir_Savic2012_reference;
