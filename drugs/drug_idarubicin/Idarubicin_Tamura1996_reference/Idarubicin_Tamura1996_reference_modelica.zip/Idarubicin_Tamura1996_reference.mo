model Idarubicin_Tamura1996_reference
  parameter Real Cl_ref = 3.954972222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6173770000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4974939,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About idarubicin</h4><p>Idarubicin is an anthracycline antibiotic used to treat breast cancer and various forms of leukemia. It is given as an intravenous injection. It is currently used as a first-line treatment for acute myeloid leukemia, often combined with cytosine arabinoside.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q1063862\">Wikidata Q1063862</a>, <a href=\"https://en.wikipedia.org/wiki/Idarubicin?oldid=1369616122\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>idarubicin</td></tr><tr><td>population:</td><td>patients with acute leukemia and CML in blastic crisis</td></tr><tr><td>source_paper:</td><td>Tamura_1996</td></tr><tr><td>measured_compound:</td><td>idarubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>idarubicin 497.494 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('t1/2', value None) — already have one for this compound</li><li>unit_dimension_unknown: 'times higher than that of IDA' (AUC)</li><li>unit_dimension_unknown: 'times higher than that of IDA' (AUC)</li><li>dropped duplicate Q88 ('AUC', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=idarubicin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end Idarubicin_Tamura1996_reference;
