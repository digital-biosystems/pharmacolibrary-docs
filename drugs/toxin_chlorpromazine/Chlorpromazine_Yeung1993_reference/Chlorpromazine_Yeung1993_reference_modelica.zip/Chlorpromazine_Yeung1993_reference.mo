model Chlorpromazine_Yeung1993_reference
  parameter Real Cl_ref = 2.1277777777777777e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.215 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.318863,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chlorpromazine</td></tr><tr><td>population:</td><td>healthy young men</td></tr><tr><td>source_paper:</td><td>Yeung_1993</td></tr><tr><td>measured_compound:</td><td>Chlorpromazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Chlorpromazine 318.863 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'F%' → Q40: printed without a unit and above 1 — read as a percentage</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chlorpromazine</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/6 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'Chlorpromazine N-oxide' — its concentrations stay mass-only</li><li>molar mass: none found for 'Chlorpromazine sulfoxide' — its concentrations stay mass-only</li><li>molar mass: none found for '7-hydroxy-Chlorpromazine (free and conjugated)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Chlorpromazine_Yeung1993_reference;
