model Desflurane_Weber2021_reference
  parameter Real Cl_ref = 6.95e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.168036,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>desflurane</td></tr><tr><td>population:</td><td>obese simulation models</td></tr><tr><td>source_paper:</td><td>Weber_2021</td></tr><tr><td>measured_compound:</td><td>Desflurane</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>desflurane 168.036 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'desflurane' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): '6.0' — extend the ontology if this is a real PK parameter (source ['Tab1:row1:col2'])</li><li>dropped unlinked row (NIL): 'Blood' — extend the ontology if this is a real PK parameter (source ['Tab1:row2:col2'])</li><li>dropped duplicate Q411 ('0.97', value '2.40') — already have one for this compound</li><li>dropped duplicate Q411 ('13.00', value '34.00') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Brain' — extend the ontology if this is a real PK parameter (source ['Tab1:row6:col2'])</li><li>dropped unlinked row (NIL): '2.31' — extend the ontology if this is a real PK parameter (source ['Tab1:row7:col2'])</li><li>dropped duplicate Q411 ('30.95', value '53.21') — already have one for this compound</li><li>salvaged Q61 ('VRG Volume 70 kg model'=6.0) from results prose — parameter table was unreadable</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Desflurane_Weber2021_reference;
