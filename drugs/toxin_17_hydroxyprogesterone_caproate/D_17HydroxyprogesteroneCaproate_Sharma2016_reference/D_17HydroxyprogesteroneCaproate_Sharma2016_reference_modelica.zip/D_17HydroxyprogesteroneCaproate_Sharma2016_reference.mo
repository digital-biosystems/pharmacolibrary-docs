model D_17HydroxyprogesteroneCaproate_Sharma2016_reference
  parameter Real Cl_ref = 2.079861111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 32.61 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.428613,
    adminMass = 0.0001,
    ka = 5.787037037037037e-08,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>17_hydroxyprogesterone_caproate</td></tr><tr><td>population:</td><td>women with singleton pregnancies</td></tr><tr><td>source_paper:</td><td>Sharma_2016</td></tr><tr><td>measured_compound:</td><td>17-Hydroxyprogesterone caproate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>17-Hydroxyprogesterone caproate 428.613 g/mol (pubchem); 17_hydroxyprogesterone_caproate 428.613 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is 17_hydroxyprogesterone_caproate; the compartment is 17-Hydroxyprogesterone caproate. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is 17-Hydroxyprogesterone caproate, not 17_hydroxyprogesterone_caproate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>17_hydroxyprogesterone_caproate's own concentration-time course is not produced by this model</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=17-Hydroxyprogesterone caproate</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q76 (V/F) from Caritis_2011's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Caritis_2011's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end D_17HydroxyprogesteroneCaproate_Sharma2016_reference;
