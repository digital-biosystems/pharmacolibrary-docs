% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = D_17HydroxyprogesteroneCaproate_Caritis2011_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
