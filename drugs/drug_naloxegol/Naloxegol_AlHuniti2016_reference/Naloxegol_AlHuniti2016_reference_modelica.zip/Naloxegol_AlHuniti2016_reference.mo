model Naloxegol_AlHuniti2016_reference
  parameter Real Cl_ref = 3.194444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.651794,
    adminMass = 2.5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About naloxegol</h4><p>Naloxegol is an opioid antagonist used to treat constipation caused by opioid medicines. It is authorised in the European Union as a drug for constipation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708351\">Wikidata Q15708351</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>naloxegol</td></tr><tr><td>population:</td><td>healthy subjects and patients with OIC and non-OIC</td></tr><tr><td>source_paper:</td><td>Al-Huniti_2016</td></tr><tr><td>measured_compound:</td><td>naloxegol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>naloxegol 651.794 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=naloxegol</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc /F' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Naloxegol_AlHuniti2016_reference;
