model Letrozole_Arora2021_reference
  parameter Real Cl_ref = 1.116111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.5166000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28531,
    adminMass = 0.00028
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>letrozole</td></tr><tr><td>population:</td><td>male and female Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Arora_2021</td></tr><tr><td>measured_compound:</td><td>Letrozole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone.0248579.t004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>letrozole 285.31 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('systemic clearance in female rats'=57.4) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('terminal half-life ... female rats'=34.0) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Letrozole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Lu_2011's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Lu_2011 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Letrozole_Arora2021_reference;
