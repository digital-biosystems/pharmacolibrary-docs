// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Letrozole_Pfister2001_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {151200.0},
    MM = 0.28531,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>letrozole</td></tr><tr><td>population:</td><td>breast cancer patients</td></tr><tr><td>source_paper:</td><td>Pfister_2001</td></tr><tr><td>measured_compound:</td><td>Letrozole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>letrozole 285.31 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'half-life increase (steady state vs single dose)' Q58 → Q57: a half-life by its label (the unit decides, not the label)</li><li>unit_dimension_unknown: 'steady state vs single dose' (t1/2z)</li><li>unit_dimension_unknown: 'steady state vs single dose' (AUC ratio)</li><li>unit_dimension_unknown: 'at steady state' (Ae )</li><li>unit_dimension_unknown: 'at steady state' (Ae )</li><li>dropped duplicate Q91 ('excreted in urine as the glucuronide of the major, pharmacologically inactive metabolite CGP44645 (at steady state)', value 64.2) — already have one for this compound</li><li>implicit units: 'half-life increase (steady state vs single dose)' → h (from the popPK convention: 'Half-life is a time parameter. In population PK, half-lives are conventionally reported in hours (h). The value 42 is pl')</li><li>implicit units: 'excreted in urine as unchanged letrozole (at steady state)' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Letrozole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Lu_2011's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Lu_2011's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1555.2));
end Letrozole_Pfister2001_reference;
