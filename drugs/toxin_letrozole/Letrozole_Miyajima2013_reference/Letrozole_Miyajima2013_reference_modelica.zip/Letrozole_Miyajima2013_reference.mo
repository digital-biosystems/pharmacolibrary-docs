// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Letrozole_Miyajima2013_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.5166000000000001},
    CLelim = {1.8888888888888888e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>letrozole</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Miyajima_2013</td></tr><tr><td>measured_compound:</td><td>Letrozole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>letrozole 285.31 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'min·g brain' (kuptake)</li><li>unit_dimension_unknown: 'min·g brain' (kuptake)</li><li>dropped duplicate Q349 ('uptake clearance [mL/(min·g brain)] of letrozole', value 0.422) — already have one for this compound</li><li>unit_dimension_unknown: 'min·g brain' (kuptake)</li><li>dropped duplicate Q349 ('uptake clearance [mL/(min·g brain)] of vorozole', value 0.91) — already have one for this compound</li><li>implicit units: 'uptake clearance [mL/(min·g brain)] of anastrozole' — the LLM proposed 'mL/(min·g brain)', whose dimension does not fit Q349; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Letrozole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 1 first-order transfer(s) across 3 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Lu_2011's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Lu_2011's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Lu_2011 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q349 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Letrozole_Miyajima2013_reference;
