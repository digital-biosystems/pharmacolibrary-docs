function p = Propranolol_Marques2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propranolol   source: Marques_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Propranolol_Marques2026_reference_params';
  p.drug  = 'propranolol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.07;                % central volume [L]
  p.CL = 28.93;                % clearance [L/h]
  p.Vp = [9.27];             % peripheral volumes [L]
  p.Q  = [1.07];             % inter-compartmental clearances [L/h]
  p.ka = 2.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 160.0;             % dose [mg]
end
