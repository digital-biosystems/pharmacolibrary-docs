model Propranolol_Salehifar2017_this_study
  parameter Real Cl_ref = 3.830555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3577000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2593434,
    adminMass = 4e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About propranolol</h4><p>Propranolol is a non-selective beta blocker used for conditions such as high blood pressure, angina, heart rhythm problems, migraine, anxiety, essential tremor, and infantile hemangioma. It remains widely used, is listed among WHO essential medicines, and is authorised in the European Union, where an approved product is indicated for hemangioma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423364\">Wikidata Q423364</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>propranolol</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Salehifar_2017</td></tr><tr><td>measured_compound:</td><td>propranolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propranolol 259.343 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Lit/kg/hr' (CL)</li><li>unit_dimension_unknown: 'Lit/kg' (V)</li><li>implicit units: 'Cl (Lit/kg/hr)' → L/kg/h (from the paper text: &quot;Table 4 explicitly lists the parameter as 'Cl (Lit/kg/hr)' and the text states 'The average clearance in our study (1.97&quot;)</li><li>implicit units: 'Vd (Lit/kg)' → L/kg (from the paper text: &quot;Table 4 explicitly lists the parameter as 'Vd (Lit/kg)'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=propranolol</li><li>population split: 'this study' subgroup of Salehifar_2017 (paper reports 5 populations: female (n=10), male (n=10), mean of differences, other sources, this study)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propranolol_Salehifar2017_this_study;
