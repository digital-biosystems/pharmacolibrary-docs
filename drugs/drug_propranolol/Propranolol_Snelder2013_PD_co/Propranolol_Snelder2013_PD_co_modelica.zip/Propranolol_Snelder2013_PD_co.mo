model Propranolol_Snelder2013_PD_co
  "indirect_response_i exposure-response sweep — Snelder_2013 :: CO (cardiac output)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.335,  // type I effect term
    EC50 = 9.82,  // [ng•mL -1]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng•mL -1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'ng•mL -1' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 99, Interval = 0.198),
    Documentation(info = "<html><body><!-- drug-about --><h4>About propranolol</h4><p>Propranolol is a non-selective beta blocker used for conditions such as high blood pressure, angina, heart rhythm problems, migraine, anxiety, essential tremor, and infantile hemangioma. It remains widely used, is listed among WHO essential medicines, and is authorised in the European Union, where an approved product is indicated for hemangioma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423364\">Wikidata Q423364</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Propranolol_Snelder2013_PD_co</h4><p>The steady-state exposure-response curve of Snelder N et al., <i>British journal of pharmacology 169(7):1510–1524</i> 2013 (<a href=\"https://doi.org/10.1111/bph.12190\">doi:10.1111/bph.12190</a>) — cardiac output [mL•min -1] against propranolol ng•mL -1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.335          maximal effect term (Emax, Q323)
  EC50  =       9.82 ng•mL -1 exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng•mL -1 of propranolol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (9.82 ng•mL -1)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Propranolol_Snelder2013_PD_co;
