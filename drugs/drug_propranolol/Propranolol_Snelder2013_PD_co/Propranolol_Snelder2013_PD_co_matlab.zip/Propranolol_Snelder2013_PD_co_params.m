function p = Propranolol_Snelder2013_PD_co_params()
% Propranolol_Snelder2013_PD_co_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propranolol Snelder_2013::CO: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng•mL -1 per second, in SI inside (kg/m3, s). Response CO in mL•min -1. Driver: propranolol (cited_pk).
p.E0 = 0.0;
p.Emax = 0.335;
p.EC50 = 9.82;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 99.0;
p.form = 'E0*(1 - Emax*frac)';
end
