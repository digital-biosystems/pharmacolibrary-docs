model Propranolol_Lalonde1987_PD_percentage_reduction_in_exercise
  "emax exposure-response sweep — Lalonde_1987 :: percentage reduction in exercise heart rate (percentage reduction in exercise heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.336,  // [1; % × 0.01]
    EC50 = 1.82e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 190, Interval = 0.38),
    Documentation(info = "<html><body><!-- drug-about --><h4>About propranolol</h4><p>Propranolol is a non-selective beta blocker used for conditions such as high blood pressure, angina, heart rhythm problems, migraine, anxiety, essential tremor, and infantile hemangioma. It remains widely used, is listed among WHO essential medicines, and is authorised in the European Union, where an approved product is indicated for hemangioma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423364\">Wikidata Q423364</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Propranolol_Lalonde1987_PD_percentage_reduction_in_exercise</h4><p>The steady-state exposure-response curve of Lalonde RL et al., <i>Journal of pharmacokinetics and biopharmaceutics 15(6):569–582</i> 1987 (<a href=\"https://doi.org/10.1007/BF01068413\">doi:10.1007/BF01068413</a>) — percentage reduction in exercise heart rate [%] against propranolol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       33.6 %        maximal effect term (Emax, Q323)
  EC50  =       18.2 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of propranolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (18.2 ng/ml)  response -0.168
  exposure -> infinity  response -0.336</pre></body></html>"));
end Propranolol_Lalonde1987_PD_percentage_reduction_in_exercise;
