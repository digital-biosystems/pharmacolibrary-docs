function p = Propranolol_Lalonde1987_PD_percentage_reduction_in_exercise_params()
% Propranolol_Lalonde1987_PD_percentage_reduction_in_exercise_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propranolol Lalonde_1987::percentage_reduction_in_exercise_heart_rate: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response percentage reduction in exercise heart rate in %. Driver: propranolol (cited_pk).
p.E0 = 0.0;
p.Emax = -0.336;
p.EC50 = 1.82e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 190.0;
p.form = 'E0 + Emax*frac';
end
