function p = Propranolol_Takechi2018_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propranolol   source: Takechi_2018 / estimate_rse   route: oral
  p.name  = 'Propranolol_Takechi2018_estimate_rse_params';
  p.drug  = 'propranolol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 134.0;                % central volume [L]
  p.CL = 9.17;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.773;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
