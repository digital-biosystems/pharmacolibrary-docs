model Baclofen_Imbert2015_PD_ocds
  "emax exposure-response sweep — Imbert_2015 :: OCDS (OCDS)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.72,  // [1; % × 0.01]
    EC50 = 12.6,  // [h mg/l]
    gamma = 1,
    exposure_per_s = 1);   // 1 h mg/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'h mg/l' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><h4>Baclofen_Imbert2015_PD_ocds</h4><p>The steady-state exposure-response curve of Imbert B et al., <i>Alcoholism, clinical and experimental research 39(9):1602-1608</i> 2015 (<a href=\"https://doi.org/10.1111/acer.12823\">doi:10.1111/acer.12823</a>) — OCDS [score] against baclofen h mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         72 %        maximal effect term (Emax, Q323)
  EC50  =       12.6 h mg/l   exposure at half of the maximal effect term (BE50 (responders), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one h mg/l of baclofen per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (12.6 h mg/l)  response -0.36
  exposure -> infinity  response -0.72</pre></body></html>"));
end Baclofen_Imbert2015_PD_ocds;
