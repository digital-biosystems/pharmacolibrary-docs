function p = Baclofen_SallerinCaute1991_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: baclofen   source: Sallerin-Caute_1991 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Baclofen_SallerinCaute1991_reference_params';
  p.drug  = 'baclofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.0;                % central volume [L]
  p.CL = 0.013;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
