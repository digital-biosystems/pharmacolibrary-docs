function p = Baclofen_Wuis1990_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: baclofen   source: Wuis_1990 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Baclofen_Wuis1990_reference_params';
  p.drug  = 'baclofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.0;                % central volume [L]
  p.CL = 10.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
