% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Vincristine_Choules2026_2_mg_adults_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
