function p = Vincristine_Choules2026_2_mg_adults_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vincristine   source: Choules_2026 / 2_mg_adults   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vincristine_Choules2026_2_mg_adults_params';
  p.drug  = 'vincristine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.39;                % central volume [L]
  p.CL = 65.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
