model Vincristine_Szymanska2012_single_agent
  parameter Real Cl_ref = 1.1722222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00539 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8249719999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vincristine</td></tr><tr><td>population:</td><td>female NOD/SCID mice</td></tr><tr><td>source_paper:</td><td>Szymanska_2012</td></tr><tr><td>measured_compound:</td><td>Vincristine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone-0033894-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vincristine 824.972 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'AUC0-∞ (mg/L*min)'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'Tmax (h)'; source reconciliation required</li><li>table representations disagree for 'AUC0-∞ (ng*h/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC0-∞ (U*h/mL)'; source reconciliation required</li><li>table representations disagree for 'Cmax (U/mL)'; source reconciliation required</li><li>dropped duplicate Q17 ('AUC0-∞ (ng*h/mL)', value '3279.05') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0-∞ (U*h/mL)', value '87.02') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (U/mL)', value '8.27') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vincristine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'single agent' subgroup of Szymanska_2012 (paper reports 2 populations: single agent, vxl combination)</li><li>gap-filled Q22 (CL) from Centanni_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Nijstad_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vincristine_Szymanska2012_single_agent;
