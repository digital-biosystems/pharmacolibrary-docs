function p = Vincristine_Szymanska2012_single_agent_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vincristine   source: Szymanska_2012 / single_agent   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vincristine_Szymanska2012_single_agent_params';
  p.drug  = 'vincristine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.39;                % central volume [L]
  p.CL = 42.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
