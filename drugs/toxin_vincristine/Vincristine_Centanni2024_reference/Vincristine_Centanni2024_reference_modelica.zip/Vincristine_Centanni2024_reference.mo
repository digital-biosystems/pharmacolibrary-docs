model Vincristine_Centanni2024_reference
  parameter Real Cl_ref = 1.2555555555555557e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0233 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8249719999999999,
    adminMass = 1e-05,
    k12 = 0.0013590844062947066,
    k21 = 5.4976851851851844e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vincristine</td></tr><tr><td>population:</td><td>pediatric oncology patients</td></tr><tr><td>source_paper:</td><td>Centanni_2024</td></tr><tr><td>measured_compound:</td><td>Vincristine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vincristine 824.972 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'LAGT'</li><li>dropped value-less row: 'PK'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)a); Q63 (Vc (L)a); Q30 (Q (L/h)a); Q64 (Vp (L)a)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vincristine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vincristine_Centanni2024_reference;
