model Vincristine_Choules2026_1_5_mg_m2_pediatric
  parameter Real Cl_ref = 2.025e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00539 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8249719999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vincristine</td></tr><tr><td>population:</td><td>pediatric cancer patients</td></tr><tr><td>source_paper:</td><td>Choules_2026</td></tr><tr><td>measured_compound:</td><td>Vincristine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vincristine 824.972 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vincristine</li><li>population split: '1.5 mg/m2 pediatric (40)' subgroup of Choules_2026 (paper reports 4 populations: 1.5 mg/m2 pediatric (40), 1.5 mg/m2 pediatric (41), 2 mg adults (39), value)</li><li>gap-filled Q61 (V) from Nijstad_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Nijstad_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vincristine_Choules2026_1_5_mg_m2_pediatric;
