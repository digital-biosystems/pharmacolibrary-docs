model D_5HydroxyLTryptophan_Arbona2023_reference
  parameter Real Cl_ref = 4.043358553266347e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.041999999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.22019999999999998,
    adminMass = 0.0001,
    ka = 0.000525,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>5_hydroxy_l_tryptophan</td></tr><tr><td>population:</td><td>3-year-old, male neutered Labrador Retriever</td></tr><tr><td>source_paper:</td><td>Arbona_2023</td></tr><tr><td>measured_compound:</td><td>5-Hydroxy-L-tryptophan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5-Hydroxy-L-tryptophan 220.2 g/mol (paper); 5_hydroxy_l_tryptophan 220.228 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('distribution volume high'=0.6) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('apparent plasma half-time elimination for 5-HTP'=2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=5-Hydroxy-L-tryptophan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Guan_2020's review values (primary lacked it)</li><li>derived CL=14.5561 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_5HydroxyLTryptophan_Arbona2023_reference;
