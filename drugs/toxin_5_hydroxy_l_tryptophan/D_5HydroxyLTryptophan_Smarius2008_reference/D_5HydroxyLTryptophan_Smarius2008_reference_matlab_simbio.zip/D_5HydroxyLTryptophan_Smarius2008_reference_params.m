function p = D_5HydroxyLTryptophan_Smarius2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 5_hydroxy_l_tryptophan   source: Smarius_2008 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'D_5HydroxyLTryptophan_Smarius2008_reference_params';
  p.drug  = '5_hydroxy_l_tryptophan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 28.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.89;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
