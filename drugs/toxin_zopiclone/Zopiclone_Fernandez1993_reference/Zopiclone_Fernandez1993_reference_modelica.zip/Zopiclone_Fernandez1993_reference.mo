model Zopiclone_Fernandez1993_reference
  parameter Real Cl_ref = 3.258333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0986 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.388812,
    adminMass = 7.5e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zopiclone</td></tr><tr><td>population:</td><td>Caucasian young healthy volunteers</td></tr><tr><td>source_paper:</td><td>Fernandez_1993</td></tr><tr><td>measured_compound:</td><td>Zopiclone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zopiclone 388.812 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'N-desmethylzopiclone' — extend the ontology if this is a real PK parameter (source ['Fernandez_1993:abstract'])</li><li>dropped unlinked row (NIL): 'N-oxidezopiclone' — extend the ontology if this is a real PK parameter (source ['Fernandez_1993:abstract'])</li><li>implicit units: 'unchanged zopiclone was excreted' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Zopiclone</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end Zopiclone_Fernandez1993_reference;
