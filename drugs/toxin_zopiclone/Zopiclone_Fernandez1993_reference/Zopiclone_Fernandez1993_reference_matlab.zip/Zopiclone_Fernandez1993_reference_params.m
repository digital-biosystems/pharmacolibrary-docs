function p = Zopiclone_Fernandez1993_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zopiclone   source: Fernandez_1993 / reference   route: oral
  p.name  = 'Zopiclone_Fernandez1993_reference_params';
  p.drug  = 'zopiclone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 98.6;                % central volume [L]
  p.CL = 11.73;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
