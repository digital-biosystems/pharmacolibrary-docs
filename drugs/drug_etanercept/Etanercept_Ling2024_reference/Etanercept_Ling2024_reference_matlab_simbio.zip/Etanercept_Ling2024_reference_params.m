function p = Etanercept_Ling2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: etanercept   source: Ling_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Etanercept_Ling2024_reference_params';
  p.drug  = 'etanercept';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.19;                % central volume [L]
  p.CL = 0.00283;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.1167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
