function p = Etanercept_Breedveld2018_PD_painful_joints_params()
% Etanercept_Breedveld2018_PD_painful_joints_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etanercept Breedveld_2018::Painful_joints: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Painful joints in %. Driver: etanercept (cited_pk).
p.E0 = 0.0;
p.Emax = 0.6681999999999999;
p.EC50 = 0.0005729999999999999;
p.gamma = 1.67;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5800.0;
p.form = 'E0 + Emax*frac';
end
