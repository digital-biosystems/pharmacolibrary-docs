model Telmisartan_Tatami2003_final
  parameter Real Cl_ref = 1.633333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.192 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5146168999999999,
    adminMass = 2e-05,
    ka = 9.166666666666667e-05,
    Tlag = 1454.4,
    k12 = 0.00011530671296296297,
    k21 = 2.2227800089245872e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>healthy volunteers and hypertensive patients</td></tr><tr><td>source_paper:</td><td>Tatami_2003</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>telmisartan 514.617 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 's 2' → Q30 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q30 ('s 2', value '0.329') — already have one for this compound</li><li>implicit units: 'CLW F' → L/h (from the paper text: &quot;Model development section: 'The basic pharmacokinetic parameters were oral clearance (CL W F, L W hr)'&quot;)</li><li>implicit units: 'V 1 W F' → L (from the paper text: &quot;Model development section: 'volume of distribution for the central compartment (V1 W F, L)'&quot;)</li><li>implicit units: 'Q W F' → L/h (from the paper text: &quot;Model development section: 'inter-compartmen- tal clearance (Q W F, L W hr)'&quot;)</li><li>implicit units: 'V 2 W F' → L (from the paper text: &quot;Model development section: 'volume of distribution for the peripheral compartment (V 2 W F, L)'&quot;)</li><li>implicit units: 'Ka' → 1/h (from the paper text: &quot;Model development section: 'ˆrst-order ab- sorption rate constant (Ka, hr -1 )'&quot;)</li><li>implicit units: 'Absorption lag time' → h (from the paper text: &quot;Model development section: 'and absorption lag time (ALAG, hr)'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=telmisartan</li><li>model-stage split: 'final estimates of the model parameters' is the final model of Tatami_2003 (paper reports 4 stages: estimated parameters, estimated value, final estimates of the model parameters, value); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Tatami2003_final;
