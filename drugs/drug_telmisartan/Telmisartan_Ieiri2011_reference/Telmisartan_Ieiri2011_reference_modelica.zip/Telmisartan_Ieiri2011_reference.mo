model Telmisartan_Ieiri2011_reference
  parameter Real Cl_ref = 4.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0831 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.722222222222222e-05,
    Tlag = 871.1999999999999
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Ieiri_2011</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Effect UGT1A3*2a' — extend the ontology if this is a real PK parameter (source ['tab_3:row8:col1', 'tab_3:row8:col3', 'tab_3:row8:col4'])</li><li>dropped unlinked row (NIL): 'Effect UGT1A3*4a' — extend the ontology if this is a real PK parameter (source ['tab_3:row10:col1', 'tab_3:row10:col3', 'tab_3:row10:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=telmisartan</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Hao_2014's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Ieiri2011_reference;
