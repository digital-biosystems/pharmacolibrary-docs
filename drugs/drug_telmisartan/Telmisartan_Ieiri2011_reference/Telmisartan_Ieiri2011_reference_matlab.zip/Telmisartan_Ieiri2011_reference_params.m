function p = Telmisartan_Ieiri2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Ieiri_2011 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Telmisartan_Ieiri2011_reference_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 83.1;                % central volume [L]
  p.CL = 15.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.53;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.242;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
