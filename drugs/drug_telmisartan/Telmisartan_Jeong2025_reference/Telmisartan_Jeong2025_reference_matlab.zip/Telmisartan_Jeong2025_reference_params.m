function p = Telmisartan_Jeong2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Jeong_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Telmisartan_Jeong2025_reference_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 20.7;                % central volume [L]
  p.CL = 18.3;                % clearance [L/h]
  p.Vp = [360.0];             % peripheral volumes [L]
  p.Q  = [12.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.182;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.228;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
