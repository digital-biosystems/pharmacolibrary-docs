model Telmisartan_Jeong2025_reference
  parameter Real Cl_ref = 5.0833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0207 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.055555555555555e-05,
    Tlag = 820.8000000000001,
    k12 = 0.00017042404723564142,
    k21 = 9.799382716049382e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>healthy subjects and hypertensive patients</td></tr><tr><td>source_paper:</td><td>Jeong_2025</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('k a (h -1 )'=0.182) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V 1 /F (L)'=20.7) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F (L/h)'=18.3) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('V 2 /F (L)'=360) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F (L/h)'=12.7) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('ALAG (h)'=0.228) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=telmisartan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Jeong2025_reference;
