% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Telmisartan_Chen2013_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
