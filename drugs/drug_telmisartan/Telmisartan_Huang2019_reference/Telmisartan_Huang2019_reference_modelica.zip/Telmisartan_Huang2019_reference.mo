model Telmisartan_Huang2019_reference
  parameter Real Cl_ref = 6.972222222222223e-06 "Cl [m3/s]";
  parameter Real cov_ugt1a1_0 = 0 "ugt1a1 covariate";
  parameter Real Vd_ref = 0.5 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.481)*cov_ugt1a1_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5146168999999999,
    adminMass = 8e-05,
    ka = 0.0001586111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>Chinese patients with hypertension</td></tr><tr><td>source_paper:</td><td>Huang_2019</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>telmisartan 514.617 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'V2 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'V2 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'F1 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'F1 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'CV (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'CV (%)' routed out of structural estimates ('Residual variability')</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'V2 (L)'; source reconciliation required</li><li>table representations disagree for 'V3 (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>table representations disagree for 'Ka (h-1)'; source reconciliation required</li><li>table representations disagree for 'TG on CL'; source reconciliation required</li><li>table representations disagree for 'GNDA on CL'; source reconciliation required</li><li>table representations disagree for 'UGT1A1 AA on F1'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Huang2019_reference;
