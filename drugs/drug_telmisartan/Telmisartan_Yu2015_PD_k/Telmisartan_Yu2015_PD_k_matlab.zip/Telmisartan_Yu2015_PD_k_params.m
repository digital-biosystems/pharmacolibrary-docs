function p = Telmisartan_Yu2015_PD_k_params()
% Telmisartan_Yu2015_PD_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% telmisartan Yu_2015::K: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response K+ in mmol/L. Driver: telmisartan (cited_pk).
p.E0 = 5.25;
p.Emax = 0.28;
p.EC50 = 0.0002615;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2100.0;
p.form = 'E0/(1 + Emax*frac)';
end
