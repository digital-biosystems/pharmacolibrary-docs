model Telmisartan_Yu2015_PD_k
  "indirect_response_iv exposure-response sweep — Yu_2015 :: K+ (plasma potassium)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 5.25,      // [mmol/L]
    Emax = 0.28,  // type IV effect term
    EC50 = 0.0002615,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.42/0.08 = 5.25) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2100, Interval = 4.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Telmisartan_Yu2015_PD_k</h4><p>The steady-state exposure-response curve of Yu D et al., <i>Fundamental &amp; clinical pharmacology 29(6):543–552</i> 2015 (<a href=\"https://doi.org/10.1111/fcp.12152\">doi:10.1111/fcp.12152</a>) — plasma potassium [mmol/L] against telmisartan ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       5.25 mmol/L   drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       0.28          maximal effect term (I max, Q323)
  EC50  =      261.5 ng/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of telmisartan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5.25   (drug-free)
  exposure = EC50 (261.5 ng/mL)  response 4.605
  exposure -> infinity  response 4.102</pre></body></html>"));
end Telmisartan_Yu2015_PD_k;
