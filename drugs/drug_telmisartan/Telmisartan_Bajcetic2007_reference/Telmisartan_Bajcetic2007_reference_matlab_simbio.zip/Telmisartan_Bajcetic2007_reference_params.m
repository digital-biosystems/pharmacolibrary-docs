function p = Telmisartan_Bajcetic2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Bajcetic_2007 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Telmisartan_Bajcetic2007_reference_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1204.0;                % central volume [L]
  p.CL = 45.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
