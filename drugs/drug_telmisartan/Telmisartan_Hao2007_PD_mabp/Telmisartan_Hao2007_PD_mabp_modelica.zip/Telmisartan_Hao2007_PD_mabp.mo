model Telmisartan_Hao2007_PD_mabp
  "indirect_response_i exposure-response sweep — Hao_2007 :: MABP (mean arterial blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 86.2,  // [ng•mL -1]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng•mL -1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'ng•mL -1' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 870, Interval = 1.74),
    Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Telmisartan_Hao2007_PD_mabp</h4><p>The steady-state exposure-response curve of Hao K et al., <i>Acta pharmacologica Sinica 28(5):738–743</i> 2007 (<a href=\"https://doi.org/10.1111/j.1745-7254.2007.00556.x\">doi:10.1111/j.1745-7254.2007.00556.x</a>) — mean arterial blood pressure [mmHg] against telmisartan ng•mL -1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       86.2 ng•mL -1 exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng•mL -1 of telmisartan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (86.2 ng•mL -1)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Telmisartan_Hao2007_PD_mabp;
