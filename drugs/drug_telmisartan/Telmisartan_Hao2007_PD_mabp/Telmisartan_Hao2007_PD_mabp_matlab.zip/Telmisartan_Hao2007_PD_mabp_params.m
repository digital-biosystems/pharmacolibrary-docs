function p = Telmisartan_Hao2007_PD_mabp_params()
% Telmisartan_Hao2007_PD_mabp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% telmisartan Hao_2007::MABP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng•mL -1 per second, in SI inside (kg/m3, s). Response MABP in mmHg. Driver: telmisartan (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 86.2;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 870.0;
p.form = 'E0*(1 - Emax*frac)';
end
