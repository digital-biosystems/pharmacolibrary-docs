function p = Telmisartan_Hao2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Hao_2007 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Telmisartan_Hao2007_reference_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 500.0;                % central volume [L]
  p.CL = 22.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.53;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
