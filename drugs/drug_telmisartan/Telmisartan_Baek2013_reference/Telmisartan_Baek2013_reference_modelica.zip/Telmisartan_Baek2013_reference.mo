model Telmisartan_Baek2013_reference
  parameter Real Cl_ref = 1.013888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02793 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5146168999999999,
    adminMass = 5e-05,
    ka = 0.0002555555555555556,
    Tlag = 0.0,
    k12 = 0.00012630783307475036,
    k21 = 9.799382716049382e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>beagle dogs</td></tr><tr><td>source_paper:</td><td>Baek_2013</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>telmisartan 514.617 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>documentation only: 'K a' → Q49 (kabs) comes from ['fig_2:caption', 'fig_2:caption'], not from a located parameter table — not emitted as a model parameter</li><li>documentation only: 'K el' → Q47 (kel) comes from ['fig_2:caption', 'fig_2:caption'], not from a located parameter table — not emitted as a model parameter</li><li>documentation only: 'V c /F' → Q290 (V1/F) comes from ['fig_2:caption', 'fig_2:caption'], not from a located parameter table — not emitted as a model parameter</li><li>salvaged Q22 ('Cl t /F'=3.65) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V z /F'=27.93) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('K a'=0.92) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V c /F'=2.19) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=telmisartan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q82 (V2/F) from Jeong_2025's review values (primary lacked it)</li><li>gap-filled Q69 (Q/F) from Jeong_2025's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Baek2013_reference;
