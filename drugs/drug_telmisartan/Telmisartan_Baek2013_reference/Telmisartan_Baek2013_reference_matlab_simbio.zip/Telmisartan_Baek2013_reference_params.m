function p = Telmisartan_Baek2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Baek_2013 / reference   route: oral
  p.name  = 'Telmisartan_Baek2013_reference_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.93;                % central volume [L]
  p.CL = 3.65;                % clearance [L/h]
  p.Vp = [360.0];             % peripheral volumes [L]
  p.Q  = [12.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.92;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
