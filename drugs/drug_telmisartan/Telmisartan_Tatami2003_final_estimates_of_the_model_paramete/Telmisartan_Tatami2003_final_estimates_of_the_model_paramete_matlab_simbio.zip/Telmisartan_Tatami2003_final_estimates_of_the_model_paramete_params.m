function p = Telmisartan_Tatami2003_final_estimates_of_the_model_paramete_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Tatami_2003 / final_estimates_of_the_model_parameters   route: oral
  p.name  = 'Telmisartan_Tatami2003_final_estimates_of_the_model_paramete_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 192.0;                % central volume [L]
  p.CL = 58.8;                % clearance [L/h]
  p.Vp = [996.0];             % peripheral volumes [L]
  p.Q  = [79.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.33;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.404;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
