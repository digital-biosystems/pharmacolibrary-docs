// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Diazoxon_Kretschmann2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {191948.45000121562},
    MM = 0.30434500000000003,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazoxon</td></tr><tr><td>population:</td><td>Daphnia magna</td></tr><tr><td>source_paper:</td><td>Kretschmann_2011</td></tr><tr><td>measured_compound:</td><td>diazinon</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2-isopropyl-6-methyl-4-pyrimidinol 152.197 g/mol (pubchem); diazinon 304.345 g/mol (pubchem); diazoxon 288.284 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'kinetic bioconcentration factor (BCF) of diazinon' — extend the ontology if this is a real PK parameter (source ['Kretschmann_2011:abstract', 'Kretschmann_2011:abstract', 'Kretschmann_2011:abstract', 'Kretschmann_2011:abstract'])</li><li>linked 'magna' as 'kel' → Q47 (kel) for  — compound marker removed</li><li>implicit units: 'oxidative dearylation to pyrimidinol' → 1/h (from the popPK convention: 'First-order rate constants (kfm) are conventionally expressed in reciprocal time units (1/h) in population pharmacokinet')</li><li>implicit units: 'oxidative activation to diazoxon' → 1/h (from the popPK convention: 'First-order rate constants (kfm) are conventionally expressed in reciprocal time units (1/h) in population pharmacokinet')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=diazinon</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=other; 4/4 row label(s) assigned, 5 linked by role; re-tagged diazinon→parent ×5, diazinon→2-isopropyl-6-methyl-4-pyrimidinol ×2, diazinon→diazoxon ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'diazinon', not diazoxon — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end Diazoxon_Kretschmann2011_reference;
