% Run (SimBiology): build model + dose, simulate 0..168.0 h, plot.
p = Frovatriptan_Zheng2021_5_mg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 168.0);
