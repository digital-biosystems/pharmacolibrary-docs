function p = Frovatriptan_Zheng2021_10_mg_female_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: frovatriptan   source: Zheng_2021 / 10_mg_female   route: oral
  % estimated (absent from source): ka
  p.name  = 'Frovatriptan_Zheng2021_10_mg_female_params';
  p.drug  = 'frovatriptan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1143.87;                % central volume [L]
  p.CL = 27.16;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
