model Frovatriptan_Zheng2021_2_5_mg
  parameter Real Cl_ref = 9.527777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.22063 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24331,
    adminMass = 2.5e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>frovatriptan</td></tr><tr><td>population:</td><td>healthy Chinese subjects</td></tr><tr><td>source_paper:</td><td>Zheng_2021</td></tr><tr><td>measured_compound:</td><td>Frovatriptan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0004</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>frovatriptan 243.31 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'tmax' from footnote/prose loose number None (source ['t0004:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Q' from footnote/prose loose number 0.05 (source ['t0004:footnote', 't0004:footnote', 't0004:footnote', 't0004:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Frovatriptan</li><li>population split: '2.5 mg (n = 12)' subgroup of Zheng_2021 (paper reports 13 populations: 10 mg (n = 12), 10 mg / female, 10 mg / male, 2.5 mg (n = 12), 2.5 mg / female, 2.5 mg / male, 5 mg (n = 12), 5 mg / female, 5 mg / male, female (n=6), male (n=5), multiple-dose / day 7 (n = 11), single-dose / (n=12))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Frovatriptan_Zheng2021_2_5_mg;
