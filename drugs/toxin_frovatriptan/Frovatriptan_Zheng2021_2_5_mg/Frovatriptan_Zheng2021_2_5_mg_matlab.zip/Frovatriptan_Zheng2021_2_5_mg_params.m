function p = Frovatriptan_Zheng2021_2_5_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: frovatriptan   source: Zheng_2021 / 2_5_mg   route: oral
  % estimated (absent from source): ka
  p.name  = 'Frovatriptan_Zheng2021_2_5_mg_params';
  p.drug  = 'frovatriptan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1220.63;                % central volume [L]
  p.CL = 34.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
