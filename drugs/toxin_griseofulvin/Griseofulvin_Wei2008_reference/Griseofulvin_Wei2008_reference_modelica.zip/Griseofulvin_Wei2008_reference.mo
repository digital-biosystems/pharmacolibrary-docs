model Griseofulvin_Wei2008_reference
  parameter Real Cl_ref = 1.8472222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0414 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.352767,
    adminMass = 0.0035,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>griseofulvin</td></tr><tr><td>population:</td><td>adult male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Wei_2008</td></tr><tr><td>measured_compound:</td><td>Griseofulvin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>text (noncompartmental PK parameters, Cmax/Tmax/AUC/T1/2/Vd/F/CL/F/MRT)</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>griseofulvin 352.767 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('T1/2'=4.3) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Vd/F'=41.4) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=6.65) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Griseofulvin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Griseofulvin_Wei2008_reference;
