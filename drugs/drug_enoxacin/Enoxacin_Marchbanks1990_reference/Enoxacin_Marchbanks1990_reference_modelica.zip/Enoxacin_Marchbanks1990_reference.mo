model Enoxacin_Marchbanks1990_reference
  parameter Real Cl_ref = 3.0099999999999996e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11270000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32031889999999996,
    adminMass = 0.0004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enoxacin</h4><p>Enoxacin is a fluoroquinolone antibiotic used to treat bacterial infections, including urinary tract infections, gonorrhea, and infections caused by gram-negative bacteria such as E. coli and Pseudomonas. It has been approved as a systemic antibacterial medicine, though it is not authorised in the European Union and is now used only in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1639616\">Wikidata Q1639616</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enoxacin</td></tr><tr><td>population:</td><td>elderly men with complicated urinary tract infections</td></tr><tr><td>source_paper:</td><td>Marchbanks_1990</td></tr><tr><td>measured_compound:</td><td>enoxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>enoxacin 320.319 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('volume of distribution'=1.61) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('total body clearance'=2.58) from results prose — parameter table was unreadable</li><li>implicit units: 'total body clearance' → mL/min/kg (from the paper text: 'Mean values for major pharmacokinetic parameters (noncompartmental) were similar following i.v. and oral administration,')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=enoxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Enoxacin_Marchbanks1990_reference;
