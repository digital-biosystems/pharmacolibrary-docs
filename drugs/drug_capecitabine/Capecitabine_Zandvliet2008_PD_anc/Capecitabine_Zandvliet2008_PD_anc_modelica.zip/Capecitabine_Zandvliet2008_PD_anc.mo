model Capecitabine_Zandvliet2008_PD_anc
  "linear exposure-response sweep — Zandvliet_2008 :: ANC (absolute neutrophil count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 19.4   "[meter ** 3 / kilogram; l/mg × 1000]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About capecitabine</h4><p>Capecitabine is an antimetabolite cancer medicine used to treat various cancers, including breast, colorectal, gastric, and other gastrointestinal tumours. It is widely used and is included on the WHO essential medicines list, with several products authorised in the European Union for bowel, breast, and stomach cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420207\">Wikidata Q420207</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Capecitabine_Zandvliet2008_PD_anc</h4><p>The steady-state exposure-response curve of Zandvliet AS et al., <i>Clinical pharmacology and therapeutics 83(6):829–839</i> 2008 (<a href=\"https://doi.org/10.1038/sj.clpt.6100344\">doi:10.1038/sj.clpt.6100344</a>) — absolute neutrophil count [×10 9 /l] against indisulam mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0194 l/mg     change in response per unit of exposure (Slope indisulam, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/l of indisulam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Capecitabine_Zandvliet2008_PD_anc;
