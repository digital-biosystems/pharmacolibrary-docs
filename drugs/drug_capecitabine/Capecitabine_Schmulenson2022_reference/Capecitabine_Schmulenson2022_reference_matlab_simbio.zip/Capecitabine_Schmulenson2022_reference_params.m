function p = Capecitabine_Schmulenson2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: capecitabine   source: Schmulenson_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Capecitabine_Schmulenson2022_reference_params';
  p.drug  = 'capecitabine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.4;                % central volume [L]
  p.CL = 1.94;                % clearance [L/h]
  p.Vp = [63.9];             % peripheral volumes [L]
  p.Q  = [13.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
