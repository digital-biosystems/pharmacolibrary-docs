function p = Capecitabine_Panoilia2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: capecitabine   source: Panoilia_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Capecitabine_Panoilia2015_reference_params';
  p.drug  = 'capecitabine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.14;                % central volume [L]
  p.CL = 0.007083;                % clearance [L/h]
  p.Vp = [2.63];             % peripheral volumes [L]
  p.Q  = [0.015];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
