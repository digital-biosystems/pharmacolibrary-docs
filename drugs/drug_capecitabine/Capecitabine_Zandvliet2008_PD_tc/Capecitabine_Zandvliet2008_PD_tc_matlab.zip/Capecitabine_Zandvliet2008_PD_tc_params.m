function p = Capecitabine_Zandvliet2008_PD_tc_params()
% Capecitabine_Zandvliet2008_PD_tc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% capecitabine Zandvliet_2008::TC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response TC in ×10 9 /l. Driver: indisulam (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 14.500000000000004;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
