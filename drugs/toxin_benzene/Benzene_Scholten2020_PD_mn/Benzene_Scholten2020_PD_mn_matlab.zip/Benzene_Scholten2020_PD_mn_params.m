function p = Benzene_Scholten2020_PD_mn_params()
% Benzene_Scholten2020_PD_mn_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% benzene Scholten_2020::MN: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ppm per second, in SI inside (kg/m3, s). Response MN in %. Driver: benzene (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2700.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
