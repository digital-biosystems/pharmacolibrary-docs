model Benzene_Scholten2020_PD_ca
  "linear exposure-response sweep — Scholten_2020 :: CA (Chromosomal aberrations)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 2700,  // [dimensionless; %/ppm × 10000]
    exposure_per_s = 1e-06);   // 1 ppm per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Benzene_Scholten2020_PD_ca</h4><p>The steady-state exposure-response curve of Scholten B et al., <i>Environmental health perspectives 128(8):87004</i> 2020 (<a href=\"https://doi.org/10.1289/EHP6404\">doi:10.1289/EHP6404</a>) — Chromosomal aberrations [%] against benzene ppm — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.27 %/ppm    change in response per unit of exposure (Slope estimate (primary study set), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ppm of benzene per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Benzene_Scholten2020_PD_ca;
