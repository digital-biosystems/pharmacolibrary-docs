model Cabotegravir_Renou2026_han_et_al_PGx_genotype
  "Cabotegravir_Renou2026_han_et_al with the genotype phenotype as a parameter (Renou_2026::han_et_al)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "genotype phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {4.19444444444e-08, 4.19444444444e-08, 2996873.55357, 4.19444444444e-08, 4.19444444444e-08, 4.19444444444e-08};
  parameter Real ka_by_phenotype[6] = {0.000391666666667, 0.000391666666667, 0.000391953863578, 0.000391666666667, 0.000391666666667, 0.000391666666667};
  extends Cabotegravir_Renou2026_han_et_al(Cl = Cl_by_phenotype[Integer(metabolizer)], ka = ka_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabotegravir</h4><p>Cabotegravir is an antiviral drug used to treat HIV infection. It is an authorised medicine in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15411012\">Wikidata Q15411012</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Cabotegravir_Renou2026_han_et_al_PGx_genotype;
