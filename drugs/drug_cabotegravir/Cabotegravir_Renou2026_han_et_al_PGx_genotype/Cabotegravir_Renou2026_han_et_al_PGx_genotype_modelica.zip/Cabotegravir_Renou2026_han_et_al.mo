model Cabotegravir_Renou2026_han_et_al
  parameter Real Cl_ref = 4.1944444444444445e-08 "Cl [m3/s]";
  parameter Real cov_im_0 = 0 "im covariate";
  parameter Real Vd_ref = 0.0052699999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (31.9)*cov_im_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.405358,
    adminMass = 0.0006,
    ka = 0.00039166666666666663,
    Tlag = 0.0,
    k12 = 2.67235926628716e-05,
    k21 = 5.7956104252400534e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabotegravir</h4><p>Cabotegravir is an antiviral drug used to treat HIV infection. It is an authorised medicine in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15411012\">Wikidata Q15411012</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cabotegravir</td></tr><tr><td>population:</td><td>HIV-infected adults (CARLAPOP)</td></tr><tr><td>source_paper:</td><td>Renou_2026</td></tr><tr><td>measured_compound:</td><td>cabotegravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470180-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cabotegravir 405.358 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ka oral' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'ka IM' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vc/F' routed out of structural estimates ('IIV (%)')</li><li>covariate level 'IM' → Q900:im = 31.9 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cabotegravir</li><li>population split: 'han et al.' subgroup of Renou_2026 (paper reports 2 populations: han et al., thoueille et al.)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Cabotegravir_Renou2026_han_et_al;
