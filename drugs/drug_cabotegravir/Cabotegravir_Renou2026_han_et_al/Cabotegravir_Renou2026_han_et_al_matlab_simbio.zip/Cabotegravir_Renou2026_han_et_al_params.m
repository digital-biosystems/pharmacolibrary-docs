function p = Cabotegravir_Renou2026_han_et_al_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabotegravir   source: Renou_2026 / han_et_al   route: oral
  p.name  = 'Cabotegravir_Renou2026_han_et_al_params';
  p.drug  = 'cabotegravir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.27;                % central volume [L]
  p.CL = 0.151;                % clearance [L/h]
  p.Vp = [2.43];             % peripheral volumes [L]
  p.Q  = [0.507];             % inter-compartmental clearances [L/h]
  p.ka = 1.41;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
