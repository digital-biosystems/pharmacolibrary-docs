function p = Ajmaline_Yasuhara1987_PD_qrs_params()
% Ajmaline_Yasuhara1987_PD_qrs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ajmaline Yasuhara_1987::QRS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response QRS in msec. Driver: ajmaline (pk_record).
p.E0 = 0.0;
p.Emax = 0.0152;
p.EC50 = 0.0003619999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.7;
p.form = 'E0 + Emax*frac';
end
