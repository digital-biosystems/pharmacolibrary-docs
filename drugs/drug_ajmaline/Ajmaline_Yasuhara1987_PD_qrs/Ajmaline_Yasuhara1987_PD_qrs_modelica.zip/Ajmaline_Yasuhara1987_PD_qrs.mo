model Ajmaline_Yasuhara1987_PD_qrs
  "emax exposure-response sweep — Yasuhara_1987 :: QRS (QRS interval change)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0152,  // [s; msec × 0.001]
    EC50 = 0.000362,  // [kg/m3; µg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/ml per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.7, Interval = 0.0074),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ajmaline</h4><p>Ajmaline is a class Ia antiarrhythmic, a sodium channel blocker used to treat heart rhythm disorders. It has been withdrawn from use in some markets, though it remains approved elsewhere.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q385858\">Wikidata Q385858</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ajmaline_Yasuhara1987_PD_qrs</h4><p>The steady-state exposure-response curve of Yasuhara M et al., <i>Journal of pharmacokinetics and biopharmaceutics 15(1):39–55</i> 1987 (<a href=\"https://doi.org/10.1007/BF01062938\">doi:10.1007/BF01062938</a>) — QRS interval change [msec] against ajmaline µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       15.2 msec     maximal effect term (Rm, Q320)
  EC50  =      0.362 µg/ml    exposure at half of the maximal effect term (Ce(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/ml of ajmaline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.362 µg/ml)  response 0.0076
  exposure -> infinity  response 0.0152</pre></body></html>"));
end Ajmaline_Yasuhara1987_PD_qrs;
