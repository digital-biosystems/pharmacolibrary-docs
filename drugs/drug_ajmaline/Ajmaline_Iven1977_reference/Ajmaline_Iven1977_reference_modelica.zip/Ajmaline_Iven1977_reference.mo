model Ajmaline_Iven1977_reference
  parameter Real Cl_ref = 1.0000000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0021 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32643259999999996,
    adminMass = 0.0007,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ajmaline</h4><p>Ajmaline is a class Ia antiarrhythmic, a sodium channel blocker used to treat heart rhythm disorders. It has been withdrawn from use in some markets, though it remains approved elsewhere.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q385858\">Wikidata Q385858</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ajmaline</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Iven_1977</td></tr><tr><td>measured_compound:</td><td>ajmaline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ajmaline 326.433 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Heart' — extend the ontology if this is a real PK parameter (source ['Iven_1977_table_1:row1:col5'])</li><li>dropped unlinked row (NIL): 'Lung' — extend the ontology if this is a real PK parameter (source ['Iven_1977_table_1:row2:col5'])</li><li>dropped unlinked row (NIL): 'Brain' — extend the ontology if this is a real PK parameter (source ['Iven_1977_table_1:row3:col5'])</li><li>dropped unlinked row (NIL): 'Liver' — extend the ontology if this is a real PK parameter (source ['Iven_1977_table_1:row4:col5'])</li><li>table mostly unlinked (4/4 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q22 ('overall body clearance Cl,ot'=6) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('mean apparent volume of distribution (Vd~)'=2100) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ajmaline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ajmaline_Iven1977_reference;
