model Methylphenidate_Diack2011_PD_v
  "sigmoid_emax exposure-response sweep — Diack_2011 :: v (intensity of clearance of sleep (v))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.71,  // [1]
    EC50 = 288,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2900, Interval = 5.8),
    Documentation(info = "<html><body><h4>Methylphenidate_Diack2011_PD_v</h4><p>The steady-state exposure-response curve of Diack C et al., <i>Journal of pharmacokinetics and pharmacodynamics 38(6):697-711</i> 2011 (<a href=\"https://doi.org/10.1007/s10928-011-9215-3\">doi:10.1007/s10928-011-9215-3</a>) — intensity of clearance of sleep (v) against methylphenidate nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      -0.71          maximal effect term (Emax, Q323)
  EC50  =        288 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of methylphenidate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (288 nM)  response -0.355
  exposure -> infinity  response -0.71</pre></body></html>"));
end Methylphenidate_Diack2011_PD_v;
