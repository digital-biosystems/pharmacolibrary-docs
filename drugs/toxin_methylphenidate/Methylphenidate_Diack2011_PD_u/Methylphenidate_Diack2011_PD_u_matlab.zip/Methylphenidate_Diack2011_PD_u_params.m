function p = Methylphenidate_Diack2011_PD_u_params()
% Methylphenidate_Diack2011_PD_u_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylphenidate Diack_2011::u: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response u in its own unit. Driver: methylphenidate (cited_pk).
p.E0 = 0.0;
p.Emax = -2.59;
p.EC50 = 41.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 410.0;
p.form = 'E0 + Emax*frac';
end
