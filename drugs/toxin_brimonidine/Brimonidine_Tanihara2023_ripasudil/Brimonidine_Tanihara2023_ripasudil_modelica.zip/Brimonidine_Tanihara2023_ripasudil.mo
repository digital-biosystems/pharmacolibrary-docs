// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Brimonidine_Tanihara2023_ripasudil
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {11145.599999999999},
    MM = 0.29214,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>brimonidine</td></tr><tr><td>population:</td><td>healthy adult men</td></tr><tr><td>source_paper:</td><td>Tanihara_2023</td></tr><tr><td>measured_compound:</td><td>Brimonidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Supplementary Table S3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Brimonidine 292.14 g/mol (pubchem); Ripasudil 323.386 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'Geometric mean Cmaxa' → ng/mL (from the paper text: 'The value 0.7379 matches the concentration of the ripasudil metabolite M1 mentioned in the text: &quot;peak plasma concentrat')</li><li>implicit units: 'Geometric mean AUC0-τb' → ng·h/mL (from the paper text: 'The value 2.4998 matches the AUC of the ripasudil metabolite M1 mentioned in the text: &quot;The AUC0–τ of... M1... was... 2.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Brimonidine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'ripasudil (n = 17)' subgroup of Tanihara_2023 (paper reports 3 populations: brimonidine (n = 17), ripasudil (n = 17), ripasudil–brimonidine fixed-dose combination (n = 17))</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role; re-tagged Brimonidine→Ripasudil ×6, parent→Ripasudil ×9, parent→Ripasudil metabolite M1 ×3, Brimonidine→Ripasudil metabolite M1 ×1</li><li>molar mass: no plausible PubChem entry for 'Ripasudil metabolite M1' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'Ripasudil metabolite M1' — its concentrations stay mass-only</li><li>gap-filled Q61 (V) from So_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Brimonidine_Tanihara2023_ripasudil;
