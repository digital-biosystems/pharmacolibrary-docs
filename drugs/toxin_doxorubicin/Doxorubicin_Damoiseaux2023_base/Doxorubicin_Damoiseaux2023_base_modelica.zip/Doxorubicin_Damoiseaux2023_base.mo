model Doxorubicin_Damoiseaux2023_base
  parameter Real Cl_ref = 6.097222222222223e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0015768 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 4.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 0.0001,
    ka = 0.00032356532356532357,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>infants</td></tr><tr><td>source_paper:</td><td>Damoiseaux_2023</td></tr><tr><td>measured_compound:</td><td>Doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413043-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: transit-compartment absorption reported; transit absorption (ktr=0.02944/s, n=90) folded to first-order ka = ktr/(n+1) = 0.0003236/s — same mean absorption time, no delay phase</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.525 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Specific intestinal permeability +100%' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row1:col5'])</li><li>dropped unlinked row (NIL): 'Specific intestinal permeability +50%' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row2:col5'])</li><li>'Fraction unbound −25%' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped unlinked row (NIL): 'GIT pH upper ileum of 5.8' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row5:col5'])</li><li>dropped unlinked row (NIL): 'GIT pH lower ileum of 6.0' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row6:col5'])</li><li>dropped unlinked row (NIL): 'GIT pH lower jejunum of 5.5' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row7:col5'])</li><li>dropped unlinked row (NIL): 'GIT pH upper jejunum of 5.0' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row8:col5'])</li><li>dropped unlinked row (NIL): 'Base model' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row10:col5'])</li><li>dropped unlinked row (NIL): 'GIT pH duodenum of 4.8' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row11:col5'])</li><li>dropped duplicate Q311 ('GIT transit time stomach +25%', value '100') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Without food' — extend the ontology if this is a real PK parameter (source ['psp413043-tbl-0001:row14:col5'])</li><li>'Fraction unbound +25%' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q46 ('Fraction unbound +25%', value '100') — already have one for this compound</li><li>dropped value-less row: 'AUC0‐inf, area under the plasma‐concentration time curve extrapolated until infinity.'</li><li>covariate effect for Q410 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'GIT transit time large intestine +25%' → 1/h (from the popPK convention: &quot;The parameter is described as a 'First-order transit rate constant' (ktr). In population pharmacokinetics and PBPK model&quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Damoiseaux2023_base;
