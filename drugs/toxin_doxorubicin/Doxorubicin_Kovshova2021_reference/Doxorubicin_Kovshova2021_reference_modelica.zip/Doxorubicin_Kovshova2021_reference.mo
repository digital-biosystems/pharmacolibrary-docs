// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Doxorubicin_Kovshova2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1396.7999999999997},
    MM = 0.5435249999999999,
    adminMass = 0.00014,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>Wistar rats</td></tr><tr><td>source_paper:</td><td>Kovshova_2021</td></tr><tr><td>measured_compound:</td><td>Doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>molecules-26-00831-t005</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.525 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Half-life (h)'; source reconciliation required</li><li>table representations disagree for 'Half-life (h)'; source reconciliation required</li><li>table representations disagree for '0.468'; source reconciliation required</li><li>table representations disagree for '0.832'; source reconciliation required</li><li>table representations disagree for '9.052'; source reconciliation required</li><li>table representations disagree for '11.935'; source reconciliation required</li><li>table representations disagree for '7.415'; source reconciliation required</li><li>table representations disagree for 'Half-life (h)'; source reconciliation required</li><li>table representations disagree for '0.460'; source reconciliation required</li><li>table representations disagree for '0.880'; source reconciliation required</li><li>table representations disagree for '11.227'; source reconciliation required</li><li>table representations disagree for '10.521'; source reconciliation required</li><li>table representations disagree for '5.899'; source reconciliation required</li><li>table representations disagree for 'Half-life (h)'; source reconciliation required</li><li>table representations disagree for '0.413'; source reconciliation required</li><li>table representations disagree for '0.870'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Doxorubicin_Kovshova2021_reference;
