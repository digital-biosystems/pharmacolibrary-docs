% Run (SimBiology): build model + dose, simulate 0..168.0 h, plot.
p = Doxorubicin_Huang2022_ar_pre_treatmentper_group_dox_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 168.0);
