function p = Doxorubicin_Huang2022_ar_pre_treatmentper_group_dox_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxorubicin   source: Huang_2022 / ar_pre_treatmentper_group_dox   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doxorubicin_Huang2022_ar_pre_treatmentper_group_dox_params';
  p.drug  = 'doxorubicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9369.5;                % central volume [L]
  p.CL = 204.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
