% Run: build params, simulate 0..25.0 h, plot + save Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.m
here = fileparts(mfilename('fullpath'));
p = Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif_params();
out = simulate_pk(p, 0:0.05:25.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('doxorubicin — Damoiseaux_2023 (iv_bolus)');
print(fig, fullfile(here, 'Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.json'), 'w');
try
  s.model = 'Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.png, Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.csv, Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif.json\n');
