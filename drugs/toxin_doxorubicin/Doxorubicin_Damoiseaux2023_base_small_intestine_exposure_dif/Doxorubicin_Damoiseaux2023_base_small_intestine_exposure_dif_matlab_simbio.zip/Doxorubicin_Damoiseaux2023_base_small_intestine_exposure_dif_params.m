function p = Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxorubicin   source: Damoiseaux_2023 / base_small_intestine_exposure_difference_from_base_model   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Doxorubicin_Damoiseaux2023_base_small_intestine_exposure_dif_params';
  p.drug  = 'doxorubicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.5768;                % central volume [L]
  p.CL = 0.2195;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.04;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
