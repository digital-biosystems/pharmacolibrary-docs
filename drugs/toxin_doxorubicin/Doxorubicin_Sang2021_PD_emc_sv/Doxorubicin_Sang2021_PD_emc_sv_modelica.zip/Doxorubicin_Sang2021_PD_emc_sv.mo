model Doxorubicin_Sang2021_PD_emc_sv
  "sigmoid_emax exposure-response sweep — Sang_2021 :: EMC_SV (myocardial compliance (direct effect on SV))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1]
    EC50 = 1704,  // [mg·h·ml−1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg·h·ml−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mg·h·ml−1' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 18000, Interval = 36),
    Documentation(info = "<html><body><h4>Doxorubicin_Sang2021_PD_emc_sv</h4><p>The steady-state exposure-response curve of Sang L et al., <i>CPT: pharmacometrics &amp; systems pharmacology 10(12):1512-1524</i> 2021 (<a href=\"https://doi.org/10.1002/psp4.12719\">doi:10.1002/psp4.12719</a>) — myocardial compliance (direct effect on SV) against doxorubicin mg·h·ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (Imax, Q323)
  EC50  =       1704 mg·h·ml−1 exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·h·ml−1 of doxorubicin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1704 mg·h·ml−1)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Doxorubicin_Sang2021_PD_emc_sv;
