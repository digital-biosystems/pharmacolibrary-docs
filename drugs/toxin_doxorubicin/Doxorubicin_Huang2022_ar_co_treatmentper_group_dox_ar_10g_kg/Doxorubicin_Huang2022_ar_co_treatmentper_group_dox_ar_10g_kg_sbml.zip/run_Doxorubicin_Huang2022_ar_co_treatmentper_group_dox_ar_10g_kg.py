#!/usr/bin/env python3
"""Simulate Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg.sbml (0..168.0 h) with Tellurium/libRoadRunner and write results.

Headless-friendly: writes Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg.csv, Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg.json and Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg.png next to this script
(no interactive window). Requires `tellurium` (bundles libRoadRunner + matplotlib).
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg")

r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 168.0, 500, ["time", "Cc"])   # Cc = central concentration [mg/L]
t = [float(x) for x in res[:, 0]]
Cc = [float(x) for x in res[:, 1]]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg", "stop_time_h": 168.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Doxorubicin_Huang2022_ar_co_treatmentper_group_dox_ar_10g_kg"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
