model Doxorubicin_Mody2023v2_PD_cell_viability
  "indirect_response_i exposure-response sweep — Mody_2023_2 :: % cell viability (% cell viability)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.01,      // [1; % × 0.01]
    Emax = 0.0697,  // type I effect term
    EC50 = 0.107,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.1, Interval = 0.0022),
    Documentation(info = "<html><body><h4>Doxorubicin_Mody2023v2_PD_cell_viability</h4><p>The steady-state exposure-response curve of Mody H et al., <i>Scientific reports 13(1):3100</i> 2023 (<a href=\"https://doi.org/10.1038/s41598-023-29964-4\">doi:10.1038/s41598-023-29964-4</a>) — % cell viability [%] against doxorubicin µM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        101 %        drug-free response (baseline) (Baseline % cell viability, Q324)
  Emax  =     0.0697          maximal effect term (Maximal killing rate constant of DOX on AC16, Q323)
  EC50  =      0.107 µM       exposure at half of the maximal effect term (DOX concentration inducing 50% of maximal killing rate on AC16, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one µM of doxorubicin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.01   (drug-free)
  exposure = EC50 (0.107 µM)  response 0.9748
  exposure -> infinity  response 0.9396</pre></body></html>"));
end Doxorubicin_Mody2023v2_PD_cell_viability;
