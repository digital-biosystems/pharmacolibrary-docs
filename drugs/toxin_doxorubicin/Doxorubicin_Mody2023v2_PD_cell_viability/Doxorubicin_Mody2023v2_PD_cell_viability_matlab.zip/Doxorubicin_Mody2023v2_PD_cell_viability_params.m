function p = Doxorubicin_Mody2023v2_PD_cell_viability_params()
% Doxorubicin_Mody2023v2_PD_cell_viability_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Mody_2023_2::cell_viability: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response % cell viability in %. Driver: doxorubicin (cited_pk).
p.E0 = 1.01;
p.Emax = 0.0697;
p.EC50 = 0.107;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.1;
p.form = 'E0*(1 - Emax*frac)';
end
