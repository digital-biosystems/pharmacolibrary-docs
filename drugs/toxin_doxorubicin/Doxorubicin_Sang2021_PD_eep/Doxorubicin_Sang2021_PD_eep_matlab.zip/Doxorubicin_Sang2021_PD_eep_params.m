function p = Doxorubicin_Sang2021_PD_eep_params()
% Doxorubicin_Sang2021_PD_eep_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Sang_2021::EEP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·h·ml−1 per second, in SI inside (kg/m3, s). Response EEP in its own unit. Driver: doxorubicin (dose_only).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 1390.0;
p.gamma = 3.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 14000.0;
p.form = 'E0 + Emax*frac';
end
