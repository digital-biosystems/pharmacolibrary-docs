model Doxorubicin_Gartrell2022_reference
  parameter Real Cl_ref = 7.472222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008324999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>children and adults with non-rhabdomyosarcoma soft tissue sarcoma</td></tr><tr><td>source_paper:</td><td>Gartrell_2022</td></tr><tr><td>measured_compound:</td><td>Doxorubicin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Doxorubicin 543.525 g/mol (pubchem); Doxorubicinol 545.541 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/m<sup>2</sup>' (CL)</li><li>unit_dimension_unknown: 'L/h/m<sup>2</sup>' (CL/F)</li><li>implicit units: 'The doxorubicin clearance' → L/h (from the popPK convention: 'No units provided in the paper. Population PK conventions typically report total clearance in L/h, and 26.9 is a plausib')</li><li>implicit units: 'The doxorubicinol apparent clearance' → L/h (from the popPK convention: 'No units provided in the paper. Apparent clearance (CL/F) is conventionally reported in L/h in population PK studies, an')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Doxorubicin</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 2/2 row label(s) assigned, 4 linked by role; re-tagged Doxorubicin→parent ×2, Doxorubicin→Doxorubicinol ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q76 (V/F) from Kovshova_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Kovshova_2021 — borrowed values do not complete its disposition core)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Gartrell2022_reference;
