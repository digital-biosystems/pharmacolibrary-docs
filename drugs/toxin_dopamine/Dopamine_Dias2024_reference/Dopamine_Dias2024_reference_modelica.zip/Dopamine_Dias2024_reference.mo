model Dopamine_Dias2024_reference
  parameter Real Cl_ref = 1.0527777777777777e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6520000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.153181,
    adminMass = 0.0001,
    ka = 0.0003805555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dopamine</td></tr><tr><td>population:</td><td>naive rats and schizophrenia phenotyped rats</td></tr><tr><td>source_paper:</td><td>Dias_2024</td></tr><tr><td>measured_compound:</td><td>Dopamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413107-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dopamine 153.181 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Kin (ng/mL * h)' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413107-tbl-0001:row3:col1', 'psp413107-tbl-0001:row3:col2', 'psp413107-tbl-0001:row3:col3', 'psp413107-tbl-0001:row3:col4'])</li><li>dropped unlinked row (NIL): 'DA0 (ng/mL)' — extend the ontology if this is a real PK parameter (source ['psp413107-tbl-0001:row4:col1', 'psp413107-tbl-0001:row4:col3'])</li><li>dropped unlinked row (NIL): 'EQTP' — extend the ontology if this is a real PK parameter (source ['psp413107-tbl-0001:row5:col1', 'psp413107-tbl-0001:row5:col2', 'psp413107-tbl-0001:row5:col3'])</li><li>dropped PD-category row 'Keo (h−1)' → Q326 (ke0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413107-tbl-0001:row6:col1', 'psp413107-tbl-0001:row6:col2', 'psp413107-tbl-0001:row6:col3'])</li><li>dropped PD-category row 'Kmod (h−1)' → Q326 (ke0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413107-tbl-0001:row7:col1', 'psp413107-tbl-0001:row7:col2', 'psp413107-tbl-0001:row7:col3', 'psp413107-tbl-0001:row7:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dopamine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>gap-filled Q22 (CL) from Johnson_2016's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hopkins_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Johnson_2016's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Hopkins_2016, Johnson_2016 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Dopamine_Dias2024_reference;
