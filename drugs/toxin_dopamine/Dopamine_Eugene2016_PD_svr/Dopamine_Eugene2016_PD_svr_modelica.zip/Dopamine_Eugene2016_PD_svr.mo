model Dopamine_Eugene2016_PD_svr
  "sigmoid_emax exposure-response sweep — Eugene_2016 :: SVR (systemic vascular resistance)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.99954,      // [1; % × 0.01]
    Emax = -0.22894,  // [1; % × 0.01]
    EC50 = 7.2e-12,  // [1/s; mcg/kg/min × 1.66667e-11]
    gamma = 1,
    exposure_per_s = 1.66666666667e-11);   // 1 mcg/kg/min per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.4, Interval = 0.0088),
    Documentation(info = "<html><body><h4>Dopamine_Eugene2016_PD_svr</h4><p>The steady-state exposure-response curve of Eugene AR, <i>Hospital chronicles = Nosokomeiaka chronika 11(1):1–8</i> 2016 (<a href=\"https://doi.org/10.2015/hc.v11i1.736\">doi:10.2015/hc.v11i1.736</a>) — systemic vascular resistance [% SVR] against dopamine mcg/kg/min — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     99.954 %        drug-free response (baseline) (SVR0 (%) (S.E.), Q324)
  Emax  =    -22.894 %        maximal effect term (SVRmax (%) (S.E.), Q323)
  EC50  =      0.432 mcg/kg/min exposure at half of the maximal effect term (ID50 (mcg/kg/min) (S.E.), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mcg/kg/min of dopamine per second of simulated time (exposure is in 1/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.9995   (drug-free)
  exposure = EC50 (0.432 mcg/kg/min)  response 0.8851
  exposure -> infinity  response 0.7706</pre></body></html>"));
end Dopamine_Eugene2016_PD_svr;
