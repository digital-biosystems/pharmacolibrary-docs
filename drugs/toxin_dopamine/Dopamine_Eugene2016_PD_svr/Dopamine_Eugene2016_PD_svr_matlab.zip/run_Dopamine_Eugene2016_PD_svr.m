% run_Dopamine_Eugene2016_PD_svr  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Dopamine_Eugene2016_PD_svr_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mcg/kg/min]'); ylabel('response [% SVR]'); title('Dopamine_Eugene2016_PD_svr', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Dopamine_Eugene2016_PD_svr.csv');
