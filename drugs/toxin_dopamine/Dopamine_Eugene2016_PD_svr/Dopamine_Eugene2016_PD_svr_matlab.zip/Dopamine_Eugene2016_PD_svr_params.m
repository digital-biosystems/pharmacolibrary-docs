function p = Dopamine_Eugene2016_PD_svr_params()
% Dopamine_Eugene2016_PD_svr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dopamine Eugene_2016::SVR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mcg/kg/min per second, in SI inside (kg/m3, s). Response SVR in % SVR. Driver: dopamine (dose_only).
p.E0 = 0.99954;
p.Emax = -0.22893999999999998;
p.EC50 = 7.2e-12;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.66666666667e-11;
p.stop_time = 4.4;
p.form = 'E0 + Emax*frac';
end
