function p = Arginine_Pereira2024_PD_args_params()
% Arginine_Pereira2024_PD_args_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% arginine Pereira_2024::ARGS: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response ARGS in nM. Driver: M6495 (conc_no_pk).
p.E0 = 0.36;
p.Emax = 0.725;
p.EC50 = 0.0011699999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 12.0;
p.form = 'E0*(1 - Emax*frac)';
end
