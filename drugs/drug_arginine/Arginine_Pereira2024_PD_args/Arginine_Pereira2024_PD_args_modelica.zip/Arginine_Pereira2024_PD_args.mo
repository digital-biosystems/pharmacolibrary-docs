model Arginine_Pereira2024_PD_args
  "indirect_response_i exposure-response sweep — Pereira_2024 :: ARGS (ARGS)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.36,      // [nM]
    Emax = 0.725,  // type I effect term
    EC50 = 0.00117,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // off_target_driver: driver compound 'M6495' is not 'arginine' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About arginine</h4><p>Arginine is an amino acid used as an additive to intravenous solutions and as a detoxifying agent during antineoplastic treatment. It is approved and also sold as a nutraceutical, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27277776\">Wikidata Q27277776</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Arginine_Pereira2024_PD_args</h4><p>The steady-state exposure-response curve of Pereira JNS et al., <i>Journal of pharmacokinetics and pharmacodynamics 52(1):8</i> 2024 (<a href=\"https://doi.org/10.1007/s10928-024-09958-z\">doi:10.1007/s10928-024-09958-z</a>) — ARGS [nM] against M6495 mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.36 nM       drug-free response (baseline) (BASE, Q324)
  Emax  =      0.725          maximal effect term (Imax, Q323)
  EC50  =       1.17 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of M6495 per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.36   (drug-free)
  exposure = EC50 (1.17 mg/L)  response 0.2295
  exposure -> infinity  response 0.099</pre></body></html>"));
end Arginine_Pereira2024_PD_args;
