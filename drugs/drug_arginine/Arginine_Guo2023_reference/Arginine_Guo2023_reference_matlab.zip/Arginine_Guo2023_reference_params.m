function p = Arginine_Guo2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arginine   source: Guo_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Arginine_Guo2023_reference_params';
  p.drug  = 'arginine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 160.0;                % central volume [L]
  p.CL = 9.53;                % clearance [L/h]
  p.Vp = [285.0];             % peripheral volumes [L]
  p.Q  = [26.2];             % inter-compartmental clearances [L/h]
  p.ka = 2.31;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
