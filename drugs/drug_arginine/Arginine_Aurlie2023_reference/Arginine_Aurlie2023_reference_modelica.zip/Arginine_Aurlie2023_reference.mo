model Arginine_Aurlie2023_reference
  parameter Real Cl_ref = 3.4333333333333336e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00744 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002861111111111111,
    Tlag = 0.0,
    k12 = 0.0022509707287933093,
    k21 = 0.027011648745519715
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>arginine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Aurélie_2023</td></tr><tr><td>measured_compound:</td><td>arginine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Aurélie_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Arginine_Aurlie2023_reference;
