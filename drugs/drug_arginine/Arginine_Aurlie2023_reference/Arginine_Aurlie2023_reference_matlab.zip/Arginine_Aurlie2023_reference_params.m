function p = Arginine_Aurlie2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arginine   source: Aurélie_2023 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Arginine_Aurlie2023_reference_params';
  p.drug  = 'arginine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.44;                % central volume [L]
  p.CL = 1.236;                % clearance [L/h]
  p.Vp = [0.62];             % peripheral volumes [L]
  p.Q  = [60.29];             % inter-compartmental clearances [L/h]
  p.ka = 1.03;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
