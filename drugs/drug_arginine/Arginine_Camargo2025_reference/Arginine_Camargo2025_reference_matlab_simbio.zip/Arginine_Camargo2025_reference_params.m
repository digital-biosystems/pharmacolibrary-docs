function p = Arginine_Camargo2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arginine   source: Camargo_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Arginine_Camargo2025_reference_params';
  p.drug  = 'arginine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.4;                % central volume [L]
  p.CL = 354.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.226;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
