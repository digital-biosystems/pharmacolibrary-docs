function p = Arginine_Henninger2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arginine   source: Henninger_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Arginine_Henninger2026_reference_params';
  p.drug  = 'arginine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 79.5;                % central volume [L]
  p.CL = 3.44;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.36;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
