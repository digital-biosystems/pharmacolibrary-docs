function p = Palbociclib_Marouille2021_final_final_population_pk_model_wi_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: palbociclib   source: Marouille_2021 / final_final_population_pk_model_with_covariates   route: oral
  p.name  = 'Palbociclib_Marouille2021_final_final_population_pk_model_wi_params';
  p.drug  = 'palbociclib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1580.0;                % central volume [L]
  p.CL = 57.13;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.187;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
