function p = Palbociclib_Marouille2021_PD_anc_params()
% Palbociclib_Marouille2021_PD_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% palbociclib Marouille_2021::ANC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/L per second, in SI inside (kg/m3, s). Response ANC in G/L. Driver: palbociclib (pk_record).
p.E0 = 2.9199999999999995;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1100.0000000000002;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
