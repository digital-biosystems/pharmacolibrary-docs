model Palbociclib_Marouille2021_PD_anc
  "linear exposure-response sweep — Marouille_2021 :: ANC (absolute neutrophil counts)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.92,      // [kg/m3; G/L × 1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 1100   "[meter ** 3 / kilogram; L/µg × 1e+06]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About palbociclib</h4><p>Palbociclib is an anticancer drug used to treat breast cancer, particularly hormone receptor-positive, HER2-negative disease. It is an approved protein kinase inhibitor and is authorised in the European Union for breast cancer treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15269707\">Wikidata Q15269707</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Palbociclib_Marouille2021_PD_anc</h4><p>The steady-state exposure-response curve of Marouille AL et al., <i>Pharmaceutics 13(10)</i> 2021 (<a href=\"https://doi.org/10.3390/pharmaceutics13101708\">doi:10.3390/pharmaceutics13101708</a>) — absolute neutrophil counts [G/L] against palbociclib µg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       2.92 G/L      drug-free response (baseline) (Base, Q324)
  slope =     0.0011 L/µg     change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/L of palbociclib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.92   (drug-free)</pre></body></html>"));
end Palbociclib_Marouille2021_PD_anc;
