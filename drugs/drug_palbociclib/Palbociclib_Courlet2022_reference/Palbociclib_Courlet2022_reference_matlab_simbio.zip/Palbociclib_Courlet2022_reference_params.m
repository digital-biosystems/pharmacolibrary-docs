function p = Palbociclib_Courlet2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: palbociclib   source: Courlet_2022 / reference   route: oral
  p.name  = 'Palbociclib_Courlet2022_reference_params';
  p.drug  = 'palbociclib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.0;                % central volume [L]
  p.CL = 5.0;                % clearance [L/h]
  p.Vp = [9.0];             % peripheral volumes [L]
  p.Q  = [31.0];             % inter-compartmental clearances [L/h]
  p.ka = 30.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
