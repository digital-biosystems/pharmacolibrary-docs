model Palbociclib_Courlet2022_reference
  parameter Real Cl_ref = 1.388888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.007 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4475328,
    adminMass = 7.5e-05,
    ka = 0.008333333333333333,
    Tlag = 0.0,
    k21 = 0.00095679012345679
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About palbociclib</h4><p>Palbociclib is an anticancer drug used to treat breast cancer, particularly hormone receptor-positive, HER2-negative disease. It is an approved protein kinase inhibitor and is authorised in the European Union for breast cancer treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15269707\">Wikidata Q15269707</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>palbociclib</td></tr><tr><td>population:</td><td>patients with advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Courlet_2022</td></tr><tr><td>measured_compound:</td><td>palbociclib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-01317-t002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>palbociclib 447.533 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'ωka (CV%)'; source reconciliation required</li><li>table representations disagree for 'ωka (CV%)'; source reconciliation required</li><li>table representations disagree for 'ALAG (h)'; source reconciliation required</li><li>table representations disagree for 'ALAG (h)'; source reconciliation required</li><li>table representations disagree for 'CL/F (L·h−1)'; source reconciliation required</li><li>table representations disagree for 'CL/F (L·h−1)'; source reconciliation required</li><li>table representations disagree for 'ωCL (CV%)'; source reconciliation required</li><li>table representations disagree for 'ωCL (CV%)'; source reconciliation required</li><li>table representations disagree for 'CL/FPPI,no food (L·h−1)'; source reconciliation required</li><li>table representations disagree for 'CL/FPPI,no food (L·h−1)'; source reconciliation required</li><li>table representations disagree for 'Vc /F(L)'; source reconciliation required</li><li>table representations disagree for 'Vc /F(L)'; source reconciliation required</li><li>table representations disagree for 'ωVc (CV%)'; source reconciliation required</li><li>table representations disagree for 'ωVc (CV%)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Palbociclib_Courlet2022_reference;
