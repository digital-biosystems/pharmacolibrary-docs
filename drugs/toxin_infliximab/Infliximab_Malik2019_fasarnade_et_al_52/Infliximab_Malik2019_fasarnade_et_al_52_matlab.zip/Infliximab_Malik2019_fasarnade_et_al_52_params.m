function p = Infliximab_Malik2019_fasarnade_et_al_52_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Malik_2019 / fasarnade_et_al_52   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Malik2019_fasarnade_et_al_52_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.29;                % central volume [L]
  p.CL = 0.01696;                % clearance [L/h]
  p.Vp = [4.13];             % peripheral volumes [L]
  p.Q  = [0.2975];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
