model Infliximab_Nasr2026_reference
  parameter Real Cl_ref = 1.5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0034700000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.1597222222222224e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>Pediatric patients with Crohn's disease</td></tr><tr><td>source_paper:</td><td>Nasr_2026</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Month 3 clearance ≤ 0.011 L/h', value '9.6') — already have one for this compound</li><li>dropped duplicate Q22 ('Month6 clearance ≤ 0.011L/h', value '9.4') — already have one for this compound</li><li>dropped duplicate Q22 ('Month12 clearance ≤ 0.011 L/h', value '5.3') — already have one for this compound</li><li>dropped duplicate Q37 ('Month 3 trough > 4.7 µg/mL', value '12.8') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>gap-filled Q61 (V) from Maximova_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Démaris_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Démaris_2022, Maximova_2023 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Infliximab_Nasr2026_reference;
