model Infliximab_Dubinsky2023_PD_crp_based_clinical_remission
  "linear exposure-response sweep — Dubinsky_2023 :: CRP-based clinical remission (CRP-based clinical remission status)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.045   "[per µg/mL]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Infliximab_Dubinsky2023_PD_crp_based_clinical_remission</h4><p>The steady-state exposure-response curve of Dubinsky MC et al., <i>Pharmaceutics 15(10):2408</i> 2023 (<a href=\"https://doi.org/10.3390/pharmaceutics15102408\">doi:10.3390/pharmaceutics15102408</a>) — CRP-based clinical remission status against infliximab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.045 per µg/mL change in response per unit of exposure (θconcentration, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/mL of infliximab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Infliximab_Dubinsky2023_PD_crp_based_clinical_remission;
