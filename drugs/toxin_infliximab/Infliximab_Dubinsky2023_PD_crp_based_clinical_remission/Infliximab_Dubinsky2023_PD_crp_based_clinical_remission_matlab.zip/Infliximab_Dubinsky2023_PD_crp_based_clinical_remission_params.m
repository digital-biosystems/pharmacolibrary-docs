function p = Infliximab_Dubinsky2023_PD_crp_based_clinical_remission_params()
% Infliximab_Dubinsky2023_PD_crp_based_clinical_remission_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% infliximab Dubinsky_2023::CRP_based_clinical_remission: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response CRP-based clinical remission in its own unit. Driver: infliximab (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.045;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
