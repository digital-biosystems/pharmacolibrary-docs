function p = Infliximab_Homek20262_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Homšek_2026_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Homek20262_reference_params';
  p.drug  = 'infliximab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.47;                % central volume [L]
  p.CL = 0.010833;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
