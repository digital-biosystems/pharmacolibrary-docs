% Run (SimBiology): build model + dose, simulate 0..1176.0 h, plot.
p = Infliximab_Malik2019_fasarnade_et_al_51_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1176.0);
