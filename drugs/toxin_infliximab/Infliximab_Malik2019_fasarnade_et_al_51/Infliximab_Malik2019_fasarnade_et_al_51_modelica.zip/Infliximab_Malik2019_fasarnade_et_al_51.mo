model Infliximab_Malik2019_fasarnade_et_al_51
  parameter Real Cl_ref = 4.241666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0035800000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-05,
    ka = 3.1597222222222224e-06,
    Tlag = 0.0,
    k12 = 4.725325884543761e-07,
    k21 = 1.3113695090439274e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>Pediatric patients (4-18 years) with inflammatory bowel disease or juvenile idiopathic arthritis</td></tr><tr><td>source_paper:</td><td>Malik_2019</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412456-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'fasarnade et al.51' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fasarnade et al.51' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fasarnade et al.51' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fasarnade et al.51' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fasarnade et al.51' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fasarnade et al.51' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Age, years' — extend the ontology if this is a real PK parameter (source ['Malik_2019_table_3:row1:col2'])</li><li>dropped unlinked row (NIL): 'Weight, kg' — extend the ontology if this is a real PK parameter (source ['Malik_2019_table_3:row1:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>population split: 'fasarnade et al.51' subgroup of Malik_2019 (paper reports 8 populations: aubourg et al.55, brandse et al.39, buurman et al.56, dotan et al.54, fasarnade et al.51, fasarnade et al.52, ternant et al.53, ternant et al.57)</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Démaris_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Infliximab_Malik2019_fasarnade_et_al_51;
