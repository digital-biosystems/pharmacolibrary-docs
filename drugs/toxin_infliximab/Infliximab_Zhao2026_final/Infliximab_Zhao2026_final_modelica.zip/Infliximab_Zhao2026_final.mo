model Infliximab_Zhao2026_final
  parameter Real Cl_ref = 9.709757834757834e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.018523076923076923 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00035,
    ka = 3.1597222222222224e-06,
    Tlag = 0.0,
    k12 = 4.690191645133505e-08,
    k21 = 6.667049280685646e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>paediatric patients with IBD (≤ 10 years old)</td></tr><tr><td>source_paper:</td><td>Zhao_2026</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>dropped unlinked row (NIL): 'ALB on CL' — extend the ontology if this is a real PK parameter (source ['Tab2:row10:col4'])</li><li>dropped duplicate Q22 ('CRP on CL', value '0.0545') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>model-stage split: 'final model estimates / estimate' is the final model of Zhao_2026 (paper reports 4 stages: base model estimates / estimate, base model estimates / shr. (%), final model estimates / estimate, final model estimates / shr. (%)); same population, different model-building step</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Démaris_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Infliximab_Zhao2026_final;
