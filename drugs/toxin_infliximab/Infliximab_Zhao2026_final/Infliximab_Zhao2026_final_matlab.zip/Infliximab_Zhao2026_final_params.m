function p = Infliximab_Zhao2026_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Zhao_2026 / final   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Zhao2026_final_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.523077;                % central volume [L]
  p.CL = 0.034955;                % clearance [L/h]
  p.Vp = [1.303077];             % peripheral volumes [L]
  p.Q  = [0.003128];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
