function p = Infliximab_ClementeBautista2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Clemente-Bautista_2024 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Infliximab_ClementeBautista2024_reference_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.018319;                % central volume [L]
  p.CL = 0.009957;                % clearance [L/h]
  p.Vp = [1.795259];             % peripheral volumes [L]
  p.Q  = [0.008297];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
