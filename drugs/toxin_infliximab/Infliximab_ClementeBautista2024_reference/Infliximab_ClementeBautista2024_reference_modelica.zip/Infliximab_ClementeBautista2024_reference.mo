model Infliximab_ClementeBautista2024_reference
  parameter Real Cl_ref = 2.7658045977011496e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0010183189655172415 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.1597222222222224e-06,
    Tlag = 0.0,
    k12 = 2.2633744855967075e-06,
    k21 = 1.2838468720821663e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>paediatric patients with IBD</td></tr><tr><td>source_paper:</td><td>Clemente-Bautista_2024</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/46.4 kg' (CL)</li><li>unit_dimension_unknown: 'L/h/46.4 kg' (Q)</li><li>unit_dimension_unknown: 'L/h/46.4 kg' (CL)</li><li>dropped duplicate Q22 ('CL3 (genotype 3-GG)', value 0.0081) — already have one for this compound</li><li>unit_dimension_unknown: 'L/h/46.4 kg' (Q)</li><li>dropped duplicate Q30 ('Q', value 0.0029) — already have one for this compound</li><li>unit_dimension_unknown: 'L/46.4 kg' (V1)</li><li>unit_dimension_unknown: 'L/46.4 kg' (V2)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Démaris_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Infliximab_ClementeBautista2024_reference;
