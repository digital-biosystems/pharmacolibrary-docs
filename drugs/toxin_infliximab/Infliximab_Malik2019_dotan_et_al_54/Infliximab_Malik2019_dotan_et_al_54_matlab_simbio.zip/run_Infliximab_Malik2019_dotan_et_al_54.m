% Run (SimBiology): build model + dose, simulate 0..840.0 h, plot.
p = Infliximab_Malik2019_dotan_et_al_54_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 840.0);
