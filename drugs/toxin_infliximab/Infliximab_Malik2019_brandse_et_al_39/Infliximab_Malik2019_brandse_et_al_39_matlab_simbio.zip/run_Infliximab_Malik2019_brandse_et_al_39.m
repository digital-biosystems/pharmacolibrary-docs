% Run (SimBiology): build model + dose, simulate 0..1512.0 h, plot.
p = Infliximab_Malik2019_brandse_et_al_39_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1512.0);
