function p = Infliximab_Malik2019_brandse_et_al_39_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Malik_2019 / brandse_et_al_39   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Malik2019_brandse_et_al_39_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.72;                % central volume [L]
  p.CL = 0.01496;                % clearance [L/h]
  p.Vp = [2.4];             % peripheral volumes [L]
  p.Q  = [0.0029];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
