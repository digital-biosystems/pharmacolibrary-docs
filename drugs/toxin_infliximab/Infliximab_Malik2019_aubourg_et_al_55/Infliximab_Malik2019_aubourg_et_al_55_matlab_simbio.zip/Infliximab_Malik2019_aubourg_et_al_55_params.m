function p = Infliximab_Malik2019_aubourg_et_al_55_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Malik_2019 / aubourg_et_al_55   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Malik2019_aubourg_et_al_55_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.6;                % central volume [L]
  p.CL = 0.014;                % clearance [L/h]
  p.Vp = [4.5];             % peripheral volumes [L]
  p.Q  = [0.083];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
