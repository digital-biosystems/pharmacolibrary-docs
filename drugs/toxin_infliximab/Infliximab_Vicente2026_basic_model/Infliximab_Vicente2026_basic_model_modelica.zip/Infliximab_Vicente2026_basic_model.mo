model Infliximab_Vicente2026_basic_model
  parameter Real Cl_ref = 4.75e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00868 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00012,
    ka = 3.1388888888888887e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>adult patients with inflammatory bowel disease (IBD)</td></tr><tr><td>source_paper:</td><td>Vicente_2026</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-01162-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'V (L)'; source reconciliation required</li><li>table representations disagree for 'F_SC'; source reconciliation required</li><li>table representations disagree for 'IIV_CL (%)'; source reconciliation required</li><li>table representations disagree for 'IIV_V (%)'; source reconciliation required</li><li>table representations disagree for 'IIV_F_SC (%)'; source reconciliation required</li><li>table representations disagree for 'RUV (%)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>status held at route_to_review — not promoted</li><li>population split: 'basic model' subgroup of Vicente_2026 (paper reports 2 populations: basic model, final model)</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Infliximab_Vicente2026_basic_model;
