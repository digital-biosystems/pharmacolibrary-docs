model Infliximab_Song2025_reference
  parameter Real Cl_ref = 2.8703703703703706e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0018700000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.667,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00035,
    ka = 9.60648148148148e-07,
    Tlag = 0.0,
    k12 = 3.7074173103584865e-06,
    k21 = 3.5371787603930464e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>patients with inflammatory bowel disease</td></tr><tr><td>source_paper:</td><td>Song_2025</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped 'θALB-CL' → Q22 = -0.372: a clearance of -0.372 is not a parameter value (source ['T2:row7:col1'])</li><li>dropped duplicate Q22 ('θCRP-CL', value '0.022') — already have one for this compound</li><li>dropped duplicate Q22 ('θADA-CL', value '0.022') — already have one for this compound</li><li>dropped duplicate Q22 ('θBMI-CL', value '0.360') — already have one for this compound</li><li>dropped unlinked row (NIL): 'θADA-F' — extend the ontology if this is a real PK parameter (source ['T2:row11:col1'])</li><li>dropped unlinked row (NIL): 'θBMI-F' — extend the ontology if this is a real PK parameter (source ['T2:row12:col1'])</li><li>dropped unlinked row (NIL): 'CovCL-F' — extend the ontology if this is a real PK parameter (source ['T2:row15:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Infliximab_Song2025_reference;
