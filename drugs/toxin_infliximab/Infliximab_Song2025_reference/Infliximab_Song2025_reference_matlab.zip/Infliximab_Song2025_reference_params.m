function p = Infliximab_Song2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Song_2025 / reference   route: oral
  p.name  = 'Infliximab_Song2025_reference_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.87;                % central volume [L]
  p.CL = 0.010333;                % clearance [L/h]
  p.Vp = [1.96];             % peripheral volumes [L]
  p.Q  = [0.024958];             % inter-compartmental clearances [L/h]
  p.ka = 0.003458;                % absorption rate [1/h]
  p.F  = 0.667;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
