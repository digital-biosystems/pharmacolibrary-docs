model Infliximab_Maximova2023_reference
  parameter Real Cl_ref = 1.6898148148148148e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003433 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    ka = 3.1597222222222224e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>pediatric patients with aGVHD</td></tr><tr><td>source_paper:</td><td>Maximova_2023</td></tr><tr><td>measured_compound:</td><td>Infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cancers-15-03605-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Residual proportional error' routed out of structural estimates ('Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Infliximab</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Démaris_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 8467200, Tolerance = 1e-9, Interval = 1));
end Infliximab_Maximova2023_reference;
