% Run (SimBiology): build model + dose, simulate 0..2352.0 h, plot.
p = Infliximab_Maximova2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2352.0);
