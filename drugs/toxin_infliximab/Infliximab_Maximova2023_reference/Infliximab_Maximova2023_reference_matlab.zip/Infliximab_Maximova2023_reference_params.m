function p = Infliximab_Maximova2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Maximova_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Maximova2023_reference_params';
  p.drug  = 'infliximab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.433;                % central volume [L]
  p.CL = 0.006083;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
