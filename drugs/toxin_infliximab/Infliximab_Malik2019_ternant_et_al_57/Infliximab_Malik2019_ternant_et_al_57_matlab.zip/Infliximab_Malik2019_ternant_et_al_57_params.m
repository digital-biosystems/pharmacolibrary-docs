function p = Infliximab_Malik2019_ternant_et_al_57_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Malik_2019 / ternant_et_al_57   route: oral
  % estimated (absent from source): F
  p.name  = 'Infliximab_Malik2019_ternant_et_al_57_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.3;                % central volume [L]
  p.CL = 0.019;                % clearance [L/h]
  p.Vp = [3.6];             % peripheral volumes [L]
  p.Q  = [0.18];             % inter-compartmental clearances [L/h]
  p.ka = 0.011375;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
