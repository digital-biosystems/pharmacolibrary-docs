model Escitalopram_Liu2022_reference
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.5819 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>Chinese psychiatric patients</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>escitalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'θ Age' — extend the ontology if this is a real PK parameter (source ['tab_2:row6:col1', 'tab_2:row6:col3', 'tab_2:row6:col4'])</li><li>dropped unlinked row (NIL): 'θ IM' — extend the ontology if this is a real PK parameter (source ['tab_2:row7:col1', 'tab_2:row7:col3', 'tab_2:row7:col4'])</li><li>dropped unlinked row (NIL): 'θ PM' — extend the ontology if this is a real PK parameter (source ['tab_2:row8:col1', 'tab_2:row8:col3', 'tab_2:row8:col4'])</li><li>dropped duplicate Q27 ('CL/F', value '0.0520') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '0.090') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=escitalopram</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Liu2022_reference;
