model Escitalopram_Poweleit2023_reference
  parameter Real Cl_ref = 6.823888888888891e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7404400000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3243919,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About escitalopram</h4><p>Escitalopram is a selective serotonin reuptake inhibitor used to treat major depressive disorder and various anxiety disorders. It is taken by mouth in tablet or solution forms.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q423757\">Wikidata Q423757</a>, <a href=\"https://en.wikipedia.org/wiki/Escitalopram?oldid=1384544999\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>psychiatrically hospitalized pediatric patients</td></tr><tr><td>source_paper:</td><td>Poweleit_2023</td></tr><tr><td>measured_compound:</td><td>escitalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.392 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('The final sertraline model estimated CL/F', value 124) — already have one for this compound</li><li>dropped duplicate Q76 ('The final sertraline model estimated V/F', value 4320) — already have one for this compound</li><li>covariate cyp2c19 for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate cyp2c19 for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=escitalopram</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Poweleit2023_reference;
