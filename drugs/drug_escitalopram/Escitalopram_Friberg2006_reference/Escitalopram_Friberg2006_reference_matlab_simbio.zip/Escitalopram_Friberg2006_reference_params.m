function p = Escitalopram_Friberg2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escitalopram   source: Friberg_2006 / reference   route: oral
  p.name  = 'Escitalopram_Friberg2006_reference_params';
  p.drug  = 'escitalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1280.0;                % central volume [L]
  p.CL = 22.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.48;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
