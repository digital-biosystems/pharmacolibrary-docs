function p = Amodiaquine_Stepniewska2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amodiaquine   source: Stepniewska_2009 / reference   route: oral
  p.name  = 'Amodiaquine_Stepniewska2009_reference_params';
  p.drug  = 'amodiaquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2478.0;                % central volume [L]
  p.CL = 43.12;                % clearance [L/h]
  p.Vp = [6153.0];             % peripheral volumes [L]
  p.Q  = [47.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.13;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
