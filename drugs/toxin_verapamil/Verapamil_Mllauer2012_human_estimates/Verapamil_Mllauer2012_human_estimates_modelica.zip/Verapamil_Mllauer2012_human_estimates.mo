model Verapamil_Mllauer2012_human_estimates
  parameter Real Cl_ref = 8.966666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00258 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00024,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k12 = 0.04231266149870801,
    k21 = 0.0018854346574553827
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>verapamil</td></tr><tr><td>population:</td><td>naive and 48-h post status epilepticus rats and healthy human volunteers</td></tr><tr><td>source_paper:</td><td>Müllauer_2012</td></tr><tr><td>measured_compound:</td><td>(R)-[11C]verapamil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>verapamil 454.611 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>'Q2 (ml·min−1)' linked to Q99: a second intercompartmental clearance beside the Q30 already present</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=(R)-[11C]verapamil</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'human estimates' subgroup of Müllauer_2012 (paper reports 4 populations: human estimates, rat / estimates, species / human, species / rat)</li><li>molar mass: none found for '(R)-[11C]verapamil' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Sips_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Verapamil_Mllauer2012_human_estimates;
