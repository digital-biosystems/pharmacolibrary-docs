function p = Verapamil_Mllauer2012_human_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: verapamil   source: Müllauer_2012 / human_estimates   route: oral
  % estimated (absent from source): F
  p.name  = 'Verapamil_Mllauer2012_human_estimates_params';
  p.drug  = 'verapamil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.58;                % central volume [L]
  p.CL = 32.28;                % clearance [L/h]
  p.Vp = [57.9];             % peripheral volumes [L]
  p.Q  = [393.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 240.0;             % dose [mg]
end
