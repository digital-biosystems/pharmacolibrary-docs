model Verapamil_Sips2026_dofetilide_observed
  parameter Real Cl_ref = 6.066666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454611,
    adminMass = 1.25e-07,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>verapamil</td></tr><tr><td>population:</td><td>healthy human subjects (predicted and clinically observed PK and QT modeling), with PKPD parameters from dogs</td></tr><tr><td>source_paper:</td><td>Sips_2026</td></tr><tr><td>measured_compound:</td><td>verapamil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ijms-27-09312-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>verapamil 454.611 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=verapamil</li><li>population split: 'dofetilide observed' subgroup of Sips_2026 (paper reports 2 populations: dofetilide observed, verapamil observed)</li><li>gap-filled Q76 (V/F) from Hong_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Sips_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Verapamil_Sips2026_dofetilide_observed;
