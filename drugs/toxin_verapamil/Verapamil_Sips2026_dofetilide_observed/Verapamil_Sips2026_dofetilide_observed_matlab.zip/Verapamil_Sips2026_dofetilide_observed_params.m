function p = Verapamil_Sips2026_dofetilide_observed_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: verapamil   source: Sips_2026 / dofetilide_observed   route: oral
  p.name  = 'Verapamil_Sips2026_dofetilide_observed_params';
  p.drug  = 'verapamil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 200.0;                % central volume [L]
  p.CL = 21.84;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.125;             % dose [mg]
end
