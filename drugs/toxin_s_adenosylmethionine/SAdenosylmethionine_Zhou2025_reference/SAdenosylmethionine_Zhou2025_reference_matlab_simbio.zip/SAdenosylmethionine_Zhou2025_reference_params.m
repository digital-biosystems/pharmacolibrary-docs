function p = SAdenosylmethionine_Zhou2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: s_adenosylmethionine   source: Zhou_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'SAdenosylmethionine_Zhou2025_reference_params';
  p.drug  = 's_adenosylmethionine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.5;                % central volume [L]
  p.CL = 0.808;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.52;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.463;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
