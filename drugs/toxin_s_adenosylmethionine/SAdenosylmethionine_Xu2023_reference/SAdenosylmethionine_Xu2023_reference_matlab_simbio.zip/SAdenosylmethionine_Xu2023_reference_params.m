function p = SAdenosylmethionine_Xu2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: s_adenosylmethionine   source: Xu_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'SAdenosylmethionine_Xu2023_reference_params';
  p.drug  = 's_adenosylmethionine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1950.0;                % central volume [L]
  p.CL = 8.91;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.745;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
