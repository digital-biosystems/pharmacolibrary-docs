function p = SAdenosylmethionine_Liu2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: s_adenosylmethionine   source: Liu_2019 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'SAdenosylmethionine_Liu2019_reference_params';
  p.drug  = 's_adenosylmethionine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.66;                % central volume [L]
  p.CL = 2.73;                % clearance [L/h]
  p.Vp = [8.53];             % peripheral volumes [L]
  p.Q  = [1.29];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
