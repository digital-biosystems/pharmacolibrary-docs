model SAdenosylmethionine_Piwowarczyk2023_reference
  parameter Real Cl_ref = 3.277777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00359 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399446,
    adminMass = 0.0001,
    ka = 7.888888888888888e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>s_adenosylmethionine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Piwowarczyk_2023</td></tr><tr><td>measured_compound:</td><td>s_adenosylmethionine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>s_adenosylmethionine 399.446 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Piwowarczyk_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SAdenosylmethionine_Piwowarczyk2023_reference;
