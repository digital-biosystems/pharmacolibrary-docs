model Azathioprine_Simon1997_PD_rcr
  "emax exposure-response sweep — Simon_1997 :: RCR (respiratory control ratio)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -10.3,  // [1]
    EC50 = 5.8,  // [10e-9 M]
    gamma = 1,
    exposure_per_s = 1);   // 1 10e-9 M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '10e-9 M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 58, Interval = 0.116),
    Documentation(info = "<html><body><!-- drug-about --><h4>About azathioprine</h4><p>Azathioprine is an immunosuppressive drug used for autoimmune conditions such as Crohn's disease, ulcerative colitis, rheumatoid arthritis, lupus, and to prevent graft rejection. It is widely used, appears on the WHO essential medicines list, and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18939\">Wikidata Q18939</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Azathioprine_Simon1997_PD_rcr</h4><p>The steady-state exposure-response curve of Simon N et al., <i>Life sciences 61(6):659–666</i> 1997 (<a href=\"https://doi.org/10.1016/s0024-3205(97)00442-6\">doi:10.1016/s0024-3205(97)00442-6</a>) — respiratory control ratio against azathioprine 10e-9 M — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       10.3          maximal effect term (Imax, Q323)
  EC50  =        5.8 10e-9 M  exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one 10e-9 M of azathioprine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.8 10e-9 M)  response -5.15
  exposure -> infinity  response -10.3</pre></body></html>"));
end Azathioprine_Simon1997_PD_rcr;
