function p = Azathioprine_Simon1997_PD_rcr_params()
% Azathioprine_Simon1997_PD_rcr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% azathioprine Simon_1997::RCR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one 10e-9 M per second, in SI inside (kg/m3, s). Response RCR in its own unit. Driver: azathioprine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.10300000000000001;
p.EC50 = 5.8;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 58.0;
p.form = 'E0 + Emax*frac';
end
