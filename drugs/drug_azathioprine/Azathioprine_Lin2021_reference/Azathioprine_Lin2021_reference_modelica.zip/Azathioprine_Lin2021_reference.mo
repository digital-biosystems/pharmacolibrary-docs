model Azathioprine_Lin2021_reference
  parameter Real Cl_ref = 3.222222222222222e-06 "Cl [m3/s]";
  parameter Real cov_tpmt_0 = 0 "tpmt covariate";
  parameter Real Vd_ref = 0.809 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.515)*cov_tpmt_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>azathioprine</td></tr><tr><td>population:</td><td>adults with inflammatory bowel disease</td></tr><tr><td>source_paper:</td><td>Lin_2021</td></tr><tr><td>measured_compound:</td><td>6-thioguanine nucleotides</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr></table><h4>Interpretation flags</h4><ul><li>kept covariate coefficient θ MESA=0.802 (covariate MESA) — not an ontology parameter</li><li>covariate level 'θ TPMT' → Q900:tpmt = 0.515 (linear_fractional on Q22)</li><li>dropped duplicate Q22 ('η CL', value '0.342') — already have one for this compound</li><li>dropped diagnostic row 'η CL -shrinkage (%)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped unlinked row (NIL): 'ε' — extend the ontology if this is a real PK parameter (source ['tab_2:row14:col1', 'tab_2:row14:col2', 'tab_2:row14:col3', 'tab_2:row14:col4', 'tab_2:row14:col5'])</li><li>dropped diagnostic row 'ε-shrinkage (%)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=6-thioguanine nucleotides</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Azathioprine_Lin2021_reference;
