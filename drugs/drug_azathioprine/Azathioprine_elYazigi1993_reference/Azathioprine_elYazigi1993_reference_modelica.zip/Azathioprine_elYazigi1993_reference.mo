model Azathioprine_elYazigi1993_reference
  parameter Real Cl_ref = 3.125e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05831 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>azathioprine</td></tr><tr><td>population:</td><td>renal transplant patients</td></tr><tr><td>source_paper:</td><td>el-Yazigi_1993</td></tr><tr><td>measured_compound:</td><td>azathioprine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('2', value '2.11') — already have one for this compound</li><li>dropped duplicate Q61 ('3', value '1.02') — already have one for this compound</li><li>dropped duplicate Q61 ('4', value '0.329') — already have one for this compound</li><li>dropped duplicate Q61 ('5', value '0.291') — already have one for this compound</li><li>dropped duplicate Q61 ('6', value '1.75') — already have one for this compound</li><li>dropped duplicate Q61 ('Mean', value '1.05') — already have one for this compound</li><li>dropped duplicate Q61 ('SEM', value '0.3') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=azathioprine</li><li>gap-filled Q22 (CL) from Colman_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Azathioprine_elYazigi1993_reference;
