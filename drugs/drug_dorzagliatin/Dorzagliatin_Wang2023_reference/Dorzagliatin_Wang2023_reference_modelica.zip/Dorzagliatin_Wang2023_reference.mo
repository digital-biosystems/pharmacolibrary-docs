model Dorzagliatin_Wang2023_reference
  parameter Real Cl_ref = 2.8888888888888894e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08059999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0009138888888888889,
    Tlag = 0.0,
    k12 = 1.0408050730631377e-05,
    k21 = 3.165618448637317e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dorzagliatin</td></tr><tr><td>population:</td><td>healthy subjects and patients with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Wang_2023</td></tr><tr><td>measured_compound:</td><td>dorzagliatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CLSTUDY' — extend the ontology if this is a real PK parameter (source ['Tab3:row8:col2', 'Tab3:row8:col3'])</li><li>dropped duplicate Q310 ('D1,FOOD', value '2.26') — already have one for this compound</li><li>dropped duplicate Q63 ('Vc,GEND', value '0.843') — already have one for this compound</li><li>dropped duplicate Q22 ('Cor_CL,Vc', value '0.0181') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dorzagliatin</li><li>structure disagreement: deterministic 3C vs LLM 2C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dorzagliatin_Wang2023_reference;
