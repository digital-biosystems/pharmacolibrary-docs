function p = AminoAcids_Meera2023_PD_gabaar_mediated_currents_params()
% AminoAcids_Meera2023_PD_gabaar_mediated_currents_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amino_acids Meera_2023::GABAAR_mediated_currents: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response GABAAR-mediated currents in pA. Driver: taurine (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.0021143592;
p.EC50 = 116.0;
p.gamma = 0.87;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1200.0;
p.form = 'E0 + Emax*frac';
end
