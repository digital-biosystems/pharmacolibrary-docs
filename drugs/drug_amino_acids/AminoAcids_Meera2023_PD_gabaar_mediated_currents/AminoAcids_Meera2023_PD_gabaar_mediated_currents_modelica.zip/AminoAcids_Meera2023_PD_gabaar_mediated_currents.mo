model AminoAcids_Meera2023_PD_gabaar_mediated_currents
  "sigmoid_emax exposure-response sweep — Meera_2023 :: GABAAR-mediated currents (GABAAR-mediated currents)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0021143592,  // [s; pA × 3.15576e-05]
    EC50 = 116,  // [μM]
    gamma = 0.87,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1200, Interval = 2.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amino_acids</h4><p>Amino acid solutions are used to provide parenteral nutrition, and an amino acid product is authorised in the European Union for treating maple syrup urine disease. DrugBank classifies amino acids as investigational, so their use as a drug is not established.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q8066\">Wikidata Q8066</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>AminoAcids_Meera2023_PD_gabaar_mediated_currents</h4><p>The steady-state exposure-response curve of Meera P et al., <i>Frontiers in pharmacology 14:1271203</i> 2023 (<a href=\"https://doi.org/10.3389/fphar.2023.1271203\">doi:10.3389/fphar.2023.1271203</a>) — GABAAR-mediated currents [pA] against taurine μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        -67 pA       maximal effect term (Imax, Q320)
  EC50  =        116 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.87          Hill coefficient (Hill Slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of taurine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (116 μM)  response -0.001057
  exposure -> infinity  response -0.002114</pre></body></html>"));
end AminoAcids_Meera2023_PD_gabaar_mediated_currents;
