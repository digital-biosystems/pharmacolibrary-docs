model Ofatumumab_Struemper2014_reference
  parameter Real Cl_ref = 2.083333333333333e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0053 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 6.7e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ofatumumab</h4><p>Ofatumumab is a monoclonal antibody used to treat B-cell blood cancers such as chronic lymphocytic leukemia and lymphoma, and is also used for relapsing-remitting multiple sclerosis. It is authorised in the European Union, where one product remains on the market while another has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410656\">Wikidata Q410656</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ofatumumab</td></tr><tr><td>population:</td><td>patients with chronic lymphocytic leukemia, follicular lymphoma, and rheumatoid arthritis</td></tr><tr><td>source_paper:</td><td>Struemper_2014</td></tr><tr><td>measured_compound:</td><td>ofatumumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ofatumumab</li><li>molar mass: none found for 'ofatumumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Ofatumumab_Struemper2014_reference;
