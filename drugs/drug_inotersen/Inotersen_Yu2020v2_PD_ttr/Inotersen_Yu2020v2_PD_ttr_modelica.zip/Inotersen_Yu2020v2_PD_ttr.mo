model Inotersen_Yu2020v2_PD_ttr
  "indirect_response_i exposure-response sweep — Yu_2020_2 :: TTR (serum TTR (transthyretin) level)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.204,      // [kg/m3; mg/dL × 0.01]
    Emax = 0.913,  // type I effect term
    EC50 = 9.07e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 91, Interval = 0.182),
    Documentation(info = "<html><body><!-- drug-about --><h4>About inotersen</h4><p>Inotersen is a nervous system drug used to treat amyloidosis. It is authorised in the European Union.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Inotersen_Yu2020v2_PD_ttr</h4><p>The steady-state exposure-response curve of Yu RZ et al., <i>Nucleic acid therapeutics 30(3):153–163</i> 2020 (<a href=\"https://doi.org/10.1089/nat.2019.0822\">doi:10.1089/nat.2019.0822</a>) — serum TTR (transthyretin) level [mg/dL] against inotersen ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       20.4 mg/dL    drug-free response (baseline) (Estimated baseline, Q324)
  Emax  =      0.913          maximal effect term (Imax, Q323)
  EC50  =       9.07 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of inotersen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.204   (drug-free)
  exposure = EC50 (9.07 ng/mL)  response 0.1109
  exposure -> infinity  response 0.01775</pre></body></html>"));
end Inotersen_Yu2020v2_PD_ttr;
