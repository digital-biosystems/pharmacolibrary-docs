function p = Inotersen_Yu2020v2_PD_ttr_params()
% Inotersen_Yu2020v2_PD_ttr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% inotersen Yu_2020_2::TTR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TTR in mg/dL. Driver: inotersen (pk_record).
p.E0 = 0.20399999999999996;
p.Emax = 0.913;
p.EC50 = 9.07e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 91.0;
p.form = 'E0*(1 - Emax*frac)';
end
