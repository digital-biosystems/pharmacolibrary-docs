function p = Somatrogon_Wang2025_previous_nonmem_model_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: somatrogon   source: Wang_2025 / previous_nonmem_model_estimates   route: oral
  p.name  = 'Somatrogon_Wang2025_previous_nonmem_model_estimates_params';
  p.drug  = 'somatrogon';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.9;                % central volume [L]
  p.CL = 0.472;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.313;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.353;             % absorption lag [h]
  p.dose = 17.5;             % dose [mg]
end
