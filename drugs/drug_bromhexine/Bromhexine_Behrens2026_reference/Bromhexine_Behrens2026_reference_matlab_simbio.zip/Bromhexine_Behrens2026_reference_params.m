function p = Bromhexine_Behrens2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bromhexine   source: Behrens_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Bromhexine_Behrens2026_reference_params';
  p.drug  = 'bromhexine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.99;                % central volume [L]
  p.CL = 4.13;                % clearance [L/h]
  p.Vp = [293.0];             % peripheral volumes [L]
  p.Q  = [91.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 24.0;             % dose [mg]
end
