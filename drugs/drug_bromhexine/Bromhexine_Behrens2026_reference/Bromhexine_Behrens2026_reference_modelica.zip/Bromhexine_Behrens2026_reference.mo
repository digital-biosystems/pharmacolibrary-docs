model Bromhexine_Behrens2026_reference
  parameter Real Cl_ref = 1.1472222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00799 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37613,
    adminMass = 2.4e-05,
    k12 = 0.003170629954109303,
    k21 = 8.646188850967009e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bromhexine</h4><p>Bromhexine is a mucolytic medicine used to treat cough by helping clear mucus from the airways. It is an approved drug, available in cough and cold preparations, though it is not authorised centrally in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q239778\">Wikidata Q239778</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bromhexine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Behrens_2026</td></tr><tr><td>measured_compound:</td><td>bromhexine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bromhexine 376.13 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Behrens_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bromhexine_Behrens2026_reference;
