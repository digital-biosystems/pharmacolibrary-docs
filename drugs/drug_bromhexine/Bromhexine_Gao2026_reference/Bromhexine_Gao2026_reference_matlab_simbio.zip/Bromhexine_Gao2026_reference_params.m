function p = Bromhexine_Gao2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bromhexine   source: Gao_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Bromhexine_Gao2026_reference_params';
  p.drug  = 'bromhexine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.86;                % central volume [L]
  p.CL = 0.015;                % clearance [L/h]
  p.Vp = [2.88];             % peripheral volumes [L]
  p.Q  = [0.00675];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 24.0;             % dose [mg]
end
