model Pretomanid_Ngara2025_PD_pretomanid
  "emax exposure-response sweep — Ngara_2025 :: Pretomanid (Pretomanid)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.97685185185e-06,  // [1/s; d−1 × 1.15741e-05]
    EC50 = 3.46,  // [mgL−1]
    gamma = 0.38,
    exposure_per_s = 1);   // 1 mgL−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mgL−1' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 35, Interval = 0.07),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pretomanid</h4><p>Pretomanid is an antimycobacterial drug used to treat multidrug-resistant tuberculosis. It is an approved medicine, with one product authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7118312\">Wikidata Q7118312</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pretomanid_Ngara2025_PD_pretomanid</h4><p>The steady-state exposure-response curve of Ngara B et al., <i>The Journal of infectious diseases 231(5):e901–e911</i> 2025 (<a href=\"https://doi.org/10.1093/infdis/jiaf088\">doi:10.1093/infdis/jiaf088</a>) — Pretomanid against Pretomanid mgL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.43 d−1      maximal effect term (Emax, Q323)
  EC50  =       3.46 mgL−1    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.38          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mgL−1 of Pretomanid per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.46 mgL−1)  response -2.488e-06
  exposure -> infinity  response -4.977e-06</pre></body></html>"));
end Pretomanid_Ngara2025_PD_pretomanid;
