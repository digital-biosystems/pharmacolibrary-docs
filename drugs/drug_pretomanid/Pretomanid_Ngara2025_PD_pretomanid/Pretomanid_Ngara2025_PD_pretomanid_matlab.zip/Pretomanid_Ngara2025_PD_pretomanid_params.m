function p = Pretomanid_Ngara2025_PD_pretomanid_params()
% Pretomanid_Ngara2025_PD_pretomanid_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pretomanid Ngara_2025::Pretomanid: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mgL−1 per second, in SI inside (kg/m3, s). Response Pretomanid in its own unit. Driver: Pretomanid (pk_record).
p.E0 = 0.0;
p.Emax = -4.976851851851851e-06;
p.EC50 = 3.46;
p.gamma = 0.38;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 35.0;
p.form = 'E0 + Emax*frac';
end
