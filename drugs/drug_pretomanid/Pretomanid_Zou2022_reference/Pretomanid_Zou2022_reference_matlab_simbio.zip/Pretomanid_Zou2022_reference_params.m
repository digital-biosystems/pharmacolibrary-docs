function p = Pretomanid_Zou2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pretomanid   source: Zou_2022 / reference   route: oral
  p.name  = 'Pretomanid_Zou2022_reference_params';
  p.drug  = 'pretomanid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 68.0;                % central volume [L]
  p.CL = 2.81;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.396;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
