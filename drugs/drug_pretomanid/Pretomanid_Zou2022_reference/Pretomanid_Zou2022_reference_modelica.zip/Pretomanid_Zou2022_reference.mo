model Pretomanid_Zou2022_reference
  parameter Real Cl_ref = 7.805555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.068 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3592574,
    adminMass = 1e-05,
    ka = 0.00011,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pretomanid</h4><p>Pretomanid is an antimycobacterial drug used to treat multidrug-resistant tuberculosis. It is an approved medicine, with one product authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7118312\">Wikidata Q7118312</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pretomanid</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Zou_2022</td></tr><tr><td>measured_compound:</td><td>pretomanid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pretomanid 359.257 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Apparent clearance (CL/F, L/h)' routed out of structural estimates ('IIV or IOV CV%b (RSE%c)')</li><li>table section iiv: 'Apparent volume of distribution (Vd/F, L)' routed out of structural estimates ('IIV or IOV CV%b (RSE%c)')</li><li>table section iiv: 'Mean transit time (MTT, h)' routed out of structural estimates ('IIV or IOV CV%b (RSE%c)')</li><li>table section iiv: 'Absorption rate of DTF (KA, h-1)' routed out of structural estimates ('IIV or IOV CV%b (RSE%c)')</li><li>table section iiv: 'Bioavailability (F)' routed out of structural estimates ('IIV or IOV CV%b (RSE%c)')</li><li>table section residual_error: 'Proportional errorb,c' routed out of structural estimates ('RUV')</li><li>table section residual_error: 'Additive error (ng/mL)b,c' routed out of structural estimates ('RUV')</li><li>table section residual_error: 'Time-varying error term (θ5):d' routed out of structural estimates ('RUV')</li><li>dropped duplicate Q49 ('Proportional effect (θ3) of MF on KA:KAMF=KADTF×θ3', value '1.65') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Dose effect (θ4) on F:F=(Dose200mg)θ4' — extend the ontology if this is a real PK parameter (source ['Tab2:row9:col1'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pretomanid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Pretomanid_Zou2022_reference;
