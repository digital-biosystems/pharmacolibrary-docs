model Pretomanid_Abdelwahab2026_PD_qtcf
  "emax exposure-response sweep — Abdelwahab_2026 :: QTcF (QTcF)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.393,      // [s; ms × 0.001]
    Emax = 0.0445,  // [s; ms × 0.001]
    EC50 = 0.0269,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 270, Interval = 0.54),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pretomanid</h4><p>Pretomanid is an antimycobacterial drug used to treat multidrug-resistant tuberculosis. It is an approved medicine, with one product authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7118312\">Wikidata Q7118312</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pretomanid_Abdelwahab2026_PD_qtcf</h4><p>The steady-state exposure-response curve of Abdelwahab MT et al., <i>Antimicrobial agents and chemotherapy 70(4):e0139925</i> 2026 (<a href=\"https://doi.org/10.1128/aac.01399-25\">doi:10.1128/aac.01399-25</a>) — QTcF [ms] against pretomanid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        393 ms       drug-free response (baseline) (QTcF base, Q324)
  Emax  =       44.5 ms       maximal effect term (Emax, Q320)
  EC50  =       26.9 mg/L     exposure at half of the maximal effect term (EC50 Pa, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of pretomanid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.393   (drug-free)
  exposure = EC50 (26.9 mg/L)  response 0.4153
  exposure -> infinity  response 0.4375</pre></body></html>"));
end Pretomanid_Abdelwahab2026_PD_qtcf;
