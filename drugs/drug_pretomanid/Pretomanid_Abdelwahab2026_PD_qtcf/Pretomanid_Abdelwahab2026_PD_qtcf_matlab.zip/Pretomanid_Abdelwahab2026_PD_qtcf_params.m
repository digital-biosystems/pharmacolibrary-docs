function p = Pretomanid_Abdelwahab2026_PD_qtcf_params()
% Pretomanid_Abdelwahab2026_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pretomanid Abdelwahab_2026::QTcF: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response QTcF in ms. Driver: pretomanid (cited_pk).
p.E0 = 0.393;
p.Emax = 0.0445;
p.EC50 = 0.026899999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 270.0;
p.form = 'E0 + Emax*frac';
end
