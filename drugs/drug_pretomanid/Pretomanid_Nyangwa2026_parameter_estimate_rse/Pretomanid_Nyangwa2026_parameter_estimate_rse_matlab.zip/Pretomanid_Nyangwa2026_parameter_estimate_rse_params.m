function p = Pretomanid_Nyangwa2026_parameter_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pretomanid   source: Nyangwa_2026 / parameter_estimate_rse   route: oral
  p.name  = 'Pretomanid_Nyangwa2026_parameter_estimate_rse_params';
  p.drug  = 'pretomanid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 3.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.316;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
