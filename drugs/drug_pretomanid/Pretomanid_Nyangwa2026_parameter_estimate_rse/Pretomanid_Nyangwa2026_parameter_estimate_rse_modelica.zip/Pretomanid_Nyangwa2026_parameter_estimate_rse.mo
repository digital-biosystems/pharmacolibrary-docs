model Pretomanid_Nyangwa2026_parameter_estimate_rse
  parameter Real Cl_ref = 8.611111111111112e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3592574,
    adminMass = 0.0002,
    ka = 8.777777777777778e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pretomanid</h4><p>Pretomanid is an antimycobacterial drug used to treat multidrug-resistant tuberculosis. It is an approved medicine, with one product authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7118312\">Wikidata Q7118312</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pretomanid</td></tr><tr><td>population:</td><td>rifampicin-resistant tuberculosis patients</td></tr><tr><td>source_paper:</td><td>Nyangwa_2026</td></tr><tr><td>measured_compound:</td><td>pretomanid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pretomanid 359.257 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error parameters')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('Residual error parameters')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pretomanid</li><li>population split: 'parameter estimate (%rse)' subgroup of Nyangwa_2026 (paper reports 2 populations: median, parameter estimate (%rse))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Pretomanid_Nyangwa2026_parameter_estimate_rse;
