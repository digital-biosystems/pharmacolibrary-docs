model Posaconazole_AbdullahKoolmees2024_bone
  parameter Real Cl_ref = 2.2277777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 9.17 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0002,
    ka = 4.4444444444444447e-05,
    Tlag = 6444.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>healthy volunteers and ICU patients</td></tr><tr><td>source_paper:</td><td>Abdullah-Koolmees_2024</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q410 ('Pharmacokinetic input parameters / Kpu Posaconazole', value '5.44') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Pharmacokinetic input parameters / Tissue volume (L) [29]' — extend the ontology if this is a real PK parameter (source ['Tab3:row3:col3'])</li><li>implicit units: 'Pharmacokinetic input parameters / Blood flow (L/h) [29]' → L/h (from the paper text: &quot;Parameter name includes unit in brackets: 'Pharmacokinetic input parameters / Blood flow (L/h)'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Posaconazole</li><li>topology: prose indicates saturable/MM/TMDD/time-varying kinetics — manual_model_class</li><li>status held at route_to_review — not promoted</li><li>population split: 'bone' subgroup of Abdullah-Koolmees_2024 (paper reports 11 populations: adipose, bone, brain, gut, heart, kidney, liver, lung, muscle, rest of the body, spleen)</li><li>gap-filled Q22 (CL) from Abdullah-Koolmees_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Bellmann_2017's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is MANUAL_MODEL_CLASS (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is MANUAL_MODEL_CLASS (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bentley_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Huang_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Bellmann_2017, Bentley_2021, Huang_2022 — borrowed values do not complete its disposition core; nonlinear topology)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 14515200, Tolerance = 1e-9, Interval = 1));
end Posaconazole_AbdullahKoolmees2024_bone;
