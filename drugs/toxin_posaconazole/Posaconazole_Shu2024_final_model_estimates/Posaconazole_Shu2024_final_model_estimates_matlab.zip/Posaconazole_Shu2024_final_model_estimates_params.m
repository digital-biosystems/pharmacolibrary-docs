function p = Posaconazole_Shu2024_final_model_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Shu_2024 / final_model_estimates   route: oral
  % estimated (absent from source): F
  p.name  = 'Posaconazole_Shu2024_final_model_estimates_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 829.0;                % central volume [L]
  p.CL = 11.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
