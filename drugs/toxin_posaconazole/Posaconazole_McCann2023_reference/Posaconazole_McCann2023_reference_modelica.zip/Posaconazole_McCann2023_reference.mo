model Posaconazole_McCann2023_reference
  parameter Real Cl_ref = 1.6666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.146 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 6e-06,
    ka = 4.4444444444444447e-05,
    Tlag = 6444.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>immunocompromised children and adolescents (1-21 years)</td></tr><tr><td>source_paper:</td><td>McCann_2023</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q22 ('The population estimate of clearance'=6.0) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('population estimate (95% CI) of volume of distribution'=146) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Posaconazole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (McCann_2023:discussion_prose, McCann_2023:results_prose, Tab2:footnote); populations base-model estimate (%rse), final-model estimate (%rse) kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bentley_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Huang_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Posaconazole_McCann2023_reference;
