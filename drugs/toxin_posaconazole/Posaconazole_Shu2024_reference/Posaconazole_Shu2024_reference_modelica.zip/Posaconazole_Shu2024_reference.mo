model Posaconazole_Shu2024_reference
  parameter Real Cl_ref = 2.3416666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.8290000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0003,
    ka = 0.00011111111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>Chinese hematopoietic stem cell transplantation (HSCT) patients</td></tr><tr><td>source_paper:</td><td>Shu_2024</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V/F' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'confidence interval'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'absorption rate constant'</li><li>dropped value-less row: 'CLpop'</li><li>dropped value-less row: 'clearance of the typical subject'</li><li>dropped value-less row: 'CCR'</li><li>dropped value-less row: 'creatinine clearance'</li><li>dropped value-less row: 'CLccr'</li><li>dropped value-less row: 'magnitude of the effect of creatinine clearance on CL'</li><li>dropped value-less row: 'Vpop'</li><li>dropped value-less row: 'volume of distribution of the typical subject'</li><li>dropped value-less row: 'WT'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1296000, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Shu2024_reference;
