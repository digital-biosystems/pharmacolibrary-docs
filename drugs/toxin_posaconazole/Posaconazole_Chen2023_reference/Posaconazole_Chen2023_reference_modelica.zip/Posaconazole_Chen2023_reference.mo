model Posaconazole_Chen2023_reference
  parameter Real Cl_ref = 1.8472222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0313 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0001,
    ka = 4.4444444444444447e-05,
    Tlag = 6444.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>Healthy Volunteers</td></tr><tr><td>source_paper:</td><td>Chen_2023</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F_sus^b,c' routed out of structural estimates ('Inter-individual variability in %CV')</li><li>table section iiv: 'F_tab^b,c' routed out of structural estimates ('Inter-individual variability in %CV')</li><li>table section iiv: 'k_tr,sus' routed out of structural estimates ('Inter-individual variability in %CV')</li><li>table section iiv: 'k_tr,tab' routed out of structural estimates ('Inter-individual variability in %CV')</li><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability in %CV')</li><li>table section iiv: 'V_c' routed out of structural estimates ('Inter-individual variability in %CV')</li><li>table section iov: 'F_tab^b' routed out of structural estimates ('Inter-occasion variability^d in %CV')</li><li>table section iov: 'k_tr,tab' routed out of structural estimates ('Inter-occasion variability^d in %CV')</li><li>table section residual_error: 'σ_prop' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ_add; (mg/L)' routed out of structural estimates ('Residual error')</li><li>dropped value-less row: 'F_sus,max,fed [%]' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'D_50,fed [mg]' (captured trailing unit 'mg' for child rows)</li><li>dropped value-less row: 'F_tab,fed [%]' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'F_tab,fasted [%]' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'k_tr,sus,fasted [h^-1]' (captured trailing unit 'h^-1' for child rows)</li><li>dropped value-less row: 'θ_sus,fed,ktr [-]' (captured trailing unit '-' for child rows)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Chen2023_reference;
