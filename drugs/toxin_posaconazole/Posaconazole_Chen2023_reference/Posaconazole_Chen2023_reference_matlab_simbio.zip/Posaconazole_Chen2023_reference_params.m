function p = Posaconazole_Chen2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Chen_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Posaconazole_Chen2023_reference_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 31.3;                % central volume [L]
  p.CL = 6.65;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.79;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
