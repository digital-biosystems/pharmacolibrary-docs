function p = Posaconazole_AbdullahKoolmees2024_brain_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Abdullah-Koolmees_2024 / brain   route: oral
  % estimated (absent from source): F
  p.name  = 'Posaconazole_AbdullahKoolmees2024_brain_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.45;                % central volume [L]
  p.CL = 8.02;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.79;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
