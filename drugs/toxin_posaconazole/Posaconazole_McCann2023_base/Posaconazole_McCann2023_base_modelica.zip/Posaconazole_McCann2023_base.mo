model Posaconazole_McCann2023_base
  parameter Real Cl_ref = 1.6444444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 6e-06,
    ka = 4.4444444444444447e-05,
    Tlag = 6444.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>immunocompromised children and adolescents (1-21 years)</td></tr><tr><td>source_paper:</td><td>McCann_2023</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL' routed out of structural estimates ('BSV in CV% (%RSE)c,d')</li><li>table section iiv: 'ωV' routed out of structural estimates ('BSV in CV% (%RSE)c,d')</li><li>table section iiv: 'ωFs' routed out of structural estimates ('BSV in CV% (%RSE)c,d')</li><li>table section residual_error: 'σProp' routed out of structural estimates ('RUV in CV% (%RSE)')</li><li>unit_dimension_unknown: 'L/70k g' (V)</li><li>dropped unlinked row (NIL): 'Fs' — extend the ontology if this is a real PK parameter (source ['Tab2:row3:col1'])</li><li>dropped duplicate Q22 ('θCL', value '0.75') — already have one for this compound</li><li>kept covariate coefficient θV=1 (covariate V) — not an ontology parameter</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'Vd (L/70k g)' → L (from the paper text: &quot;The text states: 'Volume of distribution ... 146 L for a 70 kg individual'. The column header in the prompt is 'Vd (L/70&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Posaconazole</li><li>model-stage split: 'base-model estimate (%rse)' is the base model of McCann_2023 (paper reports 2 stages: base-model estimate (%rse), final-model estimate (%rse)); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Posaconazole_McCann2023_base;
