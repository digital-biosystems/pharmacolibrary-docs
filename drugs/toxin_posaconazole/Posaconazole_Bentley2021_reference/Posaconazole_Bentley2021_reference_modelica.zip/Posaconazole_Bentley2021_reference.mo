model Posaconazole_Bentley2021_reference
  parameter Real Cl_ref = 2.3416666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.186 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0001,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>children with cystic fibrosis</td></tr><tr><td>source_paper:</td><td>Bentley_2021</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkab312-T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)a' routed out of structural estimates ('IIV %CV (%RSE)')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Posaconazole</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Bentley2021_reference;
