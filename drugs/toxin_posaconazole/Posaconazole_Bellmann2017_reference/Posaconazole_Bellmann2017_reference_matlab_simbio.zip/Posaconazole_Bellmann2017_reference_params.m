function p = Posaconazole_Bellmann2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Bellmann_2017 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Posaconazole_Bellmann2017_reference_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9170.0;                % central volume [L]
  p.CL = 1.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
