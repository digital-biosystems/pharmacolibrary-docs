model Posaconazole_Dvokov2023_reference
  parameter Real Cl_ref = 2.4444444444444447e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.38635 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0003,
    ka = 0.00022222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>lung-transplant recipients</td></tr><tr><td>source_paper:</td><td>Dvořáčková_2023</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-12-01399-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>'β_CL/F_age (L/h per year)' is a β covariate effect on _CL/F_, not Q27 (llm link set aside)</li><li>dropped unlinked row (NIL): 'β_CL/F_age (L/h per year)' — extend the ontology if this is a real PK parameter (source ['antibiotics-12-01399-t002:row5:col1'])</li><li>dropped duplicate Q76 ('Ω_Vd/F', value '0.45') — already have one for this compound</li><li>dropped duplicate Q27 ('Ω_CL/F', value '0.36') — already have one for this compound</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Posaconazole</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Dvokov2023_reference;
