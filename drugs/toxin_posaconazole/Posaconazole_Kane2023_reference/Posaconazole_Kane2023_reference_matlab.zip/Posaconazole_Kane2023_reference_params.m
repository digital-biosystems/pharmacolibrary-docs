function p = Posaconazole_Kane2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Kane_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Posaconazole_Kane2023_reference_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 186.01;                % central volume [L]
  p.CL = 13.47;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.59;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
