model Posaconazole_Kane2023_reference
  parameter Real Cl_ref = 3.741666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.18600999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.00035,
    ka = 0.00016388888888888887,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>hospitalised children</td></tr><tr><td>source_paper:</td><td>Kane_2023</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL sat (L/hr/70kg)' routed out of structural estimates ('IIV %CV (%RSE)')</li><li>table section iiv: 'V (L/70kg)' routed out of structural estimates ('IIV %CV (%RSE)')</li><li>dropped duplicate Q49 ('Ka sus (/hr)', value '0.2') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Tablet F' — extend the ontology if this is a real PK parameter (source ['tab_1:row6:col1'])</li><li>dropped unlinked row (NIL): 'Suspension D 50 (mg/BSA)' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1'])</li><li>dropped unlinked row (NIL): 'θ ppi on F sus' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col1'])</li><li>covariate weight for allometric_exponent from footnote/prose kept as documentation only (['tab_1:footnote'])</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number 0.75 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL sat (L/hr/70kg)); Q61 (V (L/70kg))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Posaconazole</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Kane2023_reference;
