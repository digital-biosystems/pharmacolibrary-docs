function p = Posaconazole_Bego2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Bego_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Posaconazole_Bego2022_reference_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9170.0;                % central volume [L]
  p.CL = 4.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.79;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
