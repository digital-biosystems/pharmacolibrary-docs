model Posaconazole_Bruno2025_reference
  parameter Real Cl_ref = 2.0263375238143562e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.261 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0003,
    ka = 4.4444444444444447e-05,
    Tlag = 6444.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>healthy subjects with normal weight and obesity</td></tr><tr><td>source_paper:</td><td>Bruno_2025</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'MW'; source reconciliation required</li><li>column 'reference' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for '6'; source reconciliation required</li><li>table representations disagree for '1.26'; source reconciliation required</li><li>table representations disagree for 'MW'; source reconciliation required</li><li>column 'reference' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for '2.19'; source reconciliation required</li><li>table representations disagree for '138'; source reconciliation required</li><li>table representations disagree for '0.329'; source reconciliation required</li><li>table representations disagree for '0.00445'; source reconciliation required</li><li>table representations disagree for 'MW'; source reconciliation required</li><li>column 'reference' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for '27.6'; source reconciliation required</li><li>table representations disagree for '2.23'; source reconciliation required</li><li>table representations disagree for '142'; source reconciliation required</li><li>table representations disagree for '0.451'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Bruno2025_reference;
