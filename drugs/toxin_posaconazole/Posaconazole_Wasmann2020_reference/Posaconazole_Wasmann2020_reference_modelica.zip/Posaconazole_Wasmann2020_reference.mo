model Posaconazole_Wasmann2020_reference
  parameter Real Cl_ref = 2.2277777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.15 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7008,
    adminMass = 0.0003,
    ka = 4.4444444444444447e-05,
    Tlag = 6444.0,
    k12 = 0.00011166666666666668,
    k21 = 0.00017411642411642412
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>posaconazole</td></tr><tr><td>population:</td><td>morbidly obese and normal-weight adult subjects</td></tr><tr><td>source_paper:</td><td>Wasmann_2020</td></tr><tr><td>measured_compound:</td><td>Posaconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkz546-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>posaconazole 700.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>salvaged Q63 ('Vc, i'=150) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('Vp, i'=96.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Posaconazole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Abdullah-Koolmees_2024's review values (primary lacked it)</li><li>gap-filled Q30 (Q) from Huang_2022's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Bentley_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Huang_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Abdullah-Koolmees_2024, Bentley_2021, Huang_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Posaconazole_Wasmann2020_reference;
