function p = Posaconazole_Wasmann2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Wasmann_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Posaconazole_Wasmann2020_reference_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 150.0;                % central volume [L]
  p.CL = 8.02;                % clearance [L/h]
  p.Vp = [96.2];             % peripheral volumes [L]
  p.Q  = [60.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.79;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
