function p = Posaconazole_Chen2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: posaconazole   source: Chen_2022_2 / reference   route: oral
  p.name  = 'Posaconazole_Chen2022v2_reference_params';
  p.drug  = 'posaconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 583.0;                % central volume [L]
  p.CL = 10.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.485;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
