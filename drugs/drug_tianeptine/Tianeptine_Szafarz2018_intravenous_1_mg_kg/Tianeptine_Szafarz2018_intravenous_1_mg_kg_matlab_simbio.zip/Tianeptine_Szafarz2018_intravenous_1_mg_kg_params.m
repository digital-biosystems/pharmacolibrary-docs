function p = Tianeptine_Szafarz2018_intravenous_1_mg_kg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tianeptine   source: Szafarz_2018 / intravenous_1_mg_kg   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Tianeptine_Szafarz2018_intravenous_1_mg_kg_params';
  p.drug  = 'tianeptine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2817.5;                % central volume [L]
  p.CL = 1497.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
