% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Tianeptine_Szafarz2018_intraperitoneal_10_mg_kg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
