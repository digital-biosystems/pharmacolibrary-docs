model Moxonidine_Hempel1998_reference
  parameter Real Cl_ref = 9.722222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.132 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.241677,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxonidine</td></tr><tr><td>population:</td><td>patients with hypertension</td></tr><tr><td>source_paper:</td><td>Hempel_1998</td></tr><tr><td>measured_compound:</td><td>moxonidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>moxonidine 241.677 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'kco' — extend the ontology if this is a real PK parameter (source ['Hempel_1998:abstract'])</li><li>dropped PD-category row 'maximum decrease in diastolic blood pressure (Emax)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Hempel_1998:abstract'])</li><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Hempel_1998:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=moxonidine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Moxonidine_Hempel1998_reference;
