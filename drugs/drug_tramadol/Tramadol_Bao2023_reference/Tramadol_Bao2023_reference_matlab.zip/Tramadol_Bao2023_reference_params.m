function p = Tramadol_Bao2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Bao_2023 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Tramadol_Bao2023_reference_params';
  p.drug  = 'tramadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 687.68;                % central volume [L]
  p.CL = 215.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
