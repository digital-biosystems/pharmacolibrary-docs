model Tramadol_SoriaChacartegui2026_estimate
  parameter Real Cl_ref = 1.4194444444444445e-05 "Cl [m3/s]";
  parameter Boolean cov_cyp2d6_0 = false "cyp2d6 level 0";
  parameter Real Vd_ref = 0.126 "Vd [m3]";
  parameter Boolean cov_weight_0 = false "weight level 0";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref + (-5.4999999999999996e-08)*(if cov_cyp2d6_0 then 1 else 0),
    Vd = Vd_ref + (3.11e-05)*(if cov_weight_0 then 1 else 0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0008583333333333333,
    Tlag = 0.0,
    k12 = 0.0003858024691358025,
    k21 = 0.00028427550357374917
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tramadol</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Soria-Chacartegui_2026</td></tr><tr><td>measured_compound:</td><td>tramadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'NCMT' — extend the ontology if this is a real PK parameter (source ['Tab2:row6:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tramadol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'estimate' subgroup of Soria-Chacartegui_2026 (paper reports 3 populations: estimate, relative pe (%), shrinkage (%))</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tramadol_SoriaChacartegui2026_estimate;
