function p = Tramadol_Allegaert2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Allegaert_2015 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Tramadol_Allegaert2015_reference_params';
  p.drug  = 'tramadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 183.4;                % central volume [L]
  p.CL = 3.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.65;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
