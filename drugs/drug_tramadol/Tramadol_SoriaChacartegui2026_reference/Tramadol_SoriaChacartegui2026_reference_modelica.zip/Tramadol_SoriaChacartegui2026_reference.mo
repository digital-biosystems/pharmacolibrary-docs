model Tramadol_SoriaChacartegui2026_reference
  parameter Real Cl_ref = 1.4194444444444445e-05 "Cl [m3/s]";
  parameter Boolean cov_cyp2d6_0 = false "cyp2d6 level 0";
  parameter Real Vd_ref = 0.126 "Vd [m3]";
  parameter Boolean cov_weight_0 = false "weight level 0";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref + (-5.4999999999999996e-08)*(if cov_cyp2d6_0 then 1 else 0),
    Vd = Vd_ref + (3.11e-05)*(if cov_weight_0 then 1 else 0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.263381,
    adminMass = 3.75e-05,
    ka = 0.0008583333333333333,
    Tlag = 0.0,
    k12 = 0.0003858024691358025,
    k21 = 0.00028427550357374917
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tramadol</h4><p>Tramadol is an opioid painkiller used to treat pain. It is an approved medicine and is widely used, available both alone and in combination with non-opioid analgesics.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407592\">Wikidata Q407592</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tramadol</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Soria-Chacartegui_2026</td></tr><tr><td>measured_compound:</td><td>tramadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tramadol 263.381 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'Vc (L)'; source reconciliation required</li><li>table representations disagree for 'Ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'MTT (h)'; source reconciliation required</li><li>table representations disagree for 'NCMT'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>table representations disagree for 'Vp (L)'; source reconciliation required</li><li>table representations disagree for 'Proportional residual error(1)'; source reconciliation required</li><li>table representations disagree for 'Being CYP2D6 IM as covariate for CL'; source reconciliation required</li><li>table representations disagree for 'Weight as covariate for Vc'; source reconciliation required</li><li>table representations disagree for 'IIV CL (%)(2,3)'; source reconciliation required</li><li>table representations disagree for 'IIV Vc (%)(2,3)'; source reconciliation required</li><li>table representations disagree for 'IIV Ka (%)(3)'; source reconciliation required</li><li>table representations disagree for 'IIV MTT (%)(3)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'NCMT' — extend the ontology if this is a real PK parameter (source ['Tab2:row6:col1'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q63 (Vc (L)); Q30 (Q (L/h)); Q64 (Vp (L))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tramadol_SoriaChacartegui2026_reference;
