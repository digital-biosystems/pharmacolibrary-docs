model Tramadol_Yoo2022_reference
  parameter Real Cl_ref = 4.833333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.041999999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.25,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00018055555555555557,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tramadol</td></tr><tr><td>population:</td><td>children aged 3-16 years</td></tr><tr><td>source_paper:</td><td>Yoo_2022</td></tr><tr><td>measured_compound:</td><td>tramadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for kabs from footnote/prose kept as documentation only (['Yoo_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tramadol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Allegaert_2014_2's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Allegaert_2014_2's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ekstrand_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tramadol_Yoo2022_reference;
