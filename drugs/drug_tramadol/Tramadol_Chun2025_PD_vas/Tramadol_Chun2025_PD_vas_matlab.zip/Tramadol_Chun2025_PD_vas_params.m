function p = Tramadol_Chun2025_PD_vas_params()
% Tramadol_Chun2025_PD_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tramadol Chun_2025::VAS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response VAS in its own unit. Driver: (1R,2R)-M1 (conc_no_pk).
p.E0 = 0.464;
p.Emax = -0.908;
p.EC50 = 2.36e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 24.0;
p.form = 'E0 + Emax*frac';
end
