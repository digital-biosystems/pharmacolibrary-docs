function p = Tramadol_Dziubina2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Dziubina_2026 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Tramadol_Dziubina2026_reference_params';
  p.drug  = 'tramadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13122.465553;                % central volume [L]
  p.CL = 2555.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
