function p = Tramadol_Ekstrand2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Ekstrand_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Tramadol_Ekstrand2026_reference_params';
  p.drug  = 'tramadol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.9;                % central volume [L]
  p.CL = 3.5;                % clearance [L/h]
  p.Vp = [18.9];             % peripheral volumes [L]
  p.Q  = [63.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.65;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
