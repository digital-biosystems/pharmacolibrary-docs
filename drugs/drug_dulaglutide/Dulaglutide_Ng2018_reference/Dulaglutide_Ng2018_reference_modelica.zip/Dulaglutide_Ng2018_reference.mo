model Dulaglutide_Ng2018_reference
  parameter Real Cl_ref = 2.6833333333333328e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00777 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.6e-07,
    k12 = 7.865007865007865e-05,
    k21 = 6.87414073240845e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dulaglutide</h4><p>Dulaglutide is a GLP-1 analogue anti-diabetic medicine used to lower blood glucose, mainly in type 2 diabetes. It is authorised in the European Union and is used widely as an approved diabetes treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21011228\">Wikidata Q21011228</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dulaglutide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ng_2018</td></tr><tr><td>measured_compound:</td><td>dulaglutide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ng_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dulaglutide_Ng2018_reference;
