function p = Naproxen_Oliveira2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: naproxen   source: Oliveira_2022_2 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Naproxen_Oliveira2022v2_reference_params';
  p.drug  = 'naproxen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.623244;                % central volume [L]
  p.CL = 0.018;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
