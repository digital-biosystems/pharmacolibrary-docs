function p = Naproxen_Vlitalo2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: naproxen   source: Välitalo_2012 / reference   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Naproxen_Vlitalo2012_reference_params';
  p.drug  = 'naproxen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.5;                % central volume [L]
  p.CL = 0.62;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.237;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
