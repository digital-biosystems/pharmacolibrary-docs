model Naproxen_Bjrnsson2011_reference
  parameter Real Cl_ref = 0.00014305555555555556 "Cl [m3/s]";
  parameter Real Vd_ref = 4.29 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naproxen</td></tr><tr><td>population:</td><td>adults with dental pain</td></tr><tr><td>source_paper:</td><td>Björnsson_2011</td></tr><tr><td>measured_compound:</td><td>naproxen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CLu/F (l h -1 )'</li><li>dropped value-less row: 'Vu/F (l)'</li><li>dropped value-less row: 'MTTnaproxcinod (h)'</li><li>dropped value-less row: 'NNnaproxcinod'</li><li>dropped value-less row: 'MTTnaproxen (h)'</li><li>dropped value-less row: 'NNnaproxen'</li><li>dropped value-less row: 'Bmax (mmol l -1 )'</li><li>dropped value-less row: 'Km (mmol l -1 )'</li><li>dropped value-less row: 'Frel (%)'</li><li>dropped value-less row: 'sT,add (mmol l -1 )'</li><li>dropped value-less row: 'sT,prop (%)'</li><li>dropped value-less row: 'sU,prop (%)'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Naproxen_Bjrnsson2011_reference;
