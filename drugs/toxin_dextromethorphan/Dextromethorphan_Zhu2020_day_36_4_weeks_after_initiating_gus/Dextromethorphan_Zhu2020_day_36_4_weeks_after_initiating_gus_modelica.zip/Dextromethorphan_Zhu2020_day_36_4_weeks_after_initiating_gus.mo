// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Dextromethorphan_Zhu2020_day_36_4_weeks_after_initiating_gus
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {23400.0},
    MM = 0.271404,
    adminMass = 0.0002,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dextromethorphan</td></tr><tr><td>population:</td><td>Patients with psoriasis</td></tr><tr><td>source_paper:</td><td>Zhu_2020</td></tr><tr><td>measured_compound:</td><td>Dextromethorphan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>cts12807-tbl-0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>dextromethorphan 271.404 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'Tmax, hour'; source reconciliation required</li><li>table representations disagree for 'AUCinf, ng·hour/mL'; source reconciliation required</li><li>table representations disagree for 't1/2, hour'; source reconciliation required</li><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'Tmax, hour'; source reconciliation required</li><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'Tmax, hour'; source reconciliation required</li><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'Tmax, hour'; source reconciliation required</li><li>table representations disagree for 'Cmax, ng/mL'; source reconciliation required</li><li>table representations disagree for 'Tmax, hour'; source reconciliation required</li><li>table representations disagree for 'AUCinf, ng·hour/mL'; source reconciliation required</li><li>table representations disagree for 't1/2, hour'; source reconciliation required</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 0.8 (source ['cts12807-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>covariate category for AUC%ext from footnote/prose kept as documentation only (['cts12807-tbl-0002:footnote'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 288.0));
end Dextromethorphan_Zhu2020_day_36_4_weeks_after_initiating_gus;
