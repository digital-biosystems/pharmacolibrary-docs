model Dextromethorphan_Rezaee2025_PD_e
  "sigmoid_emax exposure-response sweep — Rezaee_2025 :: E (cough number)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 10.7,      // [coughs]
    Emax = -0.23,  // [number of coughs]
    EC50 = 3e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.8,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 3, Interval = 0.006),
    Documentation(info = "<html><body><h4>Dextromethorphan_Rezaee2025_PD_e</h4><p>The steady-state exposure-response curve of Rezaee S et al., <i>Journal of clinical pharmacology 65(11):1616-1625</i> 2025 (<a href=\"https://doi.org/10.1002/jcph.70049\">doi:10.1002/jcph.70049</a>) — cough number [number of coughs] against dextromethorphan and dextrorphan ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       10.7 coughs   drug-free response (baseline) (Baseline_cough, Q324)
  Emax  =       0.23 number of coughs maximal effect term (Imax, Q323)
  EC50  =        0.3 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma =        2.8          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of dextromethorphan and dextrorphan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 10.7   (drug-free)
  exposure = EC50 (0.3 ng/mL)  response 10.58
  exposure -> infinity  response 10.47</pre></body></html>"));
end Dextromethorphan_Rezaee2025_PD_e;
