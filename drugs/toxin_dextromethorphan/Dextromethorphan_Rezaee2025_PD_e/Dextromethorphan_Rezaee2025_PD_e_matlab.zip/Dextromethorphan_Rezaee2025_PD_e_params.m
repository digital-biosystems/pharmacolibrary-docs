function p = Dextromethorphan_Rezaee2025_PD_e_params()
% Dextromethorphan_Rezaee2025_PD_e_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dextromethorphan Rezaee_2025::E: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response E in number of coughs. Driver: dextromethorphan and dextrorphan (conc_no_pk).
p.E0 = 10.7;
p.Emax = -0.23;
p.EC50 = 3e-07;
p.gamma = 2.8;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3.0;
p.form = 'E0 + Emax*frac';
end
