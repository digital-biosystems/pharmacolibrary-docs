function p = Dextromethorphan_Zhou2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dextromethorphan   source: Zhou_2011 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Dextromethorphan_Zhou2011_reference_params';
  p.drug  = 'dextromethorphan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3766.0;                % central volume [L]
  p.CL = 47.712;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.42;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 90.0;             % dose [mg]
end
