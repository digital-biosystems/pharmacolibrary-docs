model Dextromethorphan_Zhou2011_reference
  parameter Real Cl_ref = 1.3253333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.766 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.271404,
    adminMass = 9e-05,
    ka = 0.00011666666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dextromethorphan</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Zhou_2011</td></tr><tr><td>measured_compound:</td><td>Dextromethorphan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dextromethorphan 271.404 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('clearance of midazolam (CYP3A) in sham normothermia rats', value 1268.8) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance of chlorzoxazone (CYP2E) in CA hypothermia', value 229.6) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance of chlorzoxazone (CYP2E) in sham normothermia rats', value 561.89) — already have one for this compound</li><li>dropped value-less row: 'decreased clearance of midazolam (CYP3A)' (captured trailing unit 'CYP3A' for child rows)</li><li>dropped value-less row: 'decreased clearance of chlorzoxazone (CYP2E1)' (captured trailing unit 'CYP2E1' for child rows)</li><li>dropped value-less row: 'volume of distribution of midazolam (V(1))'</li><li>dropped value-less row: 'volume of distribution of dextromethorphan (V(1))'</li><li>dropped value-less row: 'peripheral compartment for chlorzoxazone (V(2))'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dextromethorphan</li><li>toxin: 4 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Hanan_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Hanan_2019's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Hanan_2019 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Dextromethorphan_Zhou2011_reference;
