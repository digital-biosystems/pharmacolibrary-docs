function p = Dextromethorphan_Mu2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dextromethorphan   source: Mu_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Dextromethorphan_Mu2022_reference_params';
  p.drug  = 'dextromethorphan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28000.0;                % central volume [L]
  p.CL = 2289.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 90.0;             % dose [mg]
end
