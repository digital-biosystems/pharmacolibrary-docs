// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Dextromethorphan_Stemkens2023_rif40_day_30
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4320.0},
    MM = 0.271404,
    adminMass = 0.0007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dextromethorphan</td></tr><tr><td>population:</td><td>adult participants with pulmonary TB</td></tr><tr><td>source_paper:</td><td>Stemkens_2023</td></tr><tr><td>measured_compound:</td><td>Dextromethorphan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>dextromethorphan 271.404 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q88 ('Isoniazid AUC₀–₂₄ h (mg/L*h)', value '10.9') — already have one for this compound</li><li>dropped duplicate Q32 ('Isoniazid Cₘₐₓ (mg/L)', value '2.5') — already have one for this compound</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 69 (source ['T3:footnote']); the table cell was unparseable — needs review</li><li>covariate effect for Q74 has no base parameter row (kept as unattached equation-variable)</li><li>salvaged Q57 ('elimination half-life was similar with RIF10 and RIF40 (1.3 and 1.2'=1.2) from results prose — parameter table was unreadable</li><li>implicit units: 'elimination half-life was similar with RIF10 and RIF40 (1.3 and 1.2' → h (from the paper text: 'The elimination half-life was similar with RIF10 and RIF40 (1.3 and 1.2 hours).')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dextromethorphan</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>pharmacogenetic covariate 'theta_q74_cyp2c19' (cyp2c19) — PGx domain</li><li>population split: 'rif40 (day 30) n = 25' subgroup of Stemkens_2023 (paper reports 2 populations: rif10 (day 15) n = 25, rif40 (day 30) n = 25)</li><li>gap-filled Q22 (CL) from Mu_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hanan_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Hanan_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Dextromethorphan_Stemkens2023_rif40_day_30;
