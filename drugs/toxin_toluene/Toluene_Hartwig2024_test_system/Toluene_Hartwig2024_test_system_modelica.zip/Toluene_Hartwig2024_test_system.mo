// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Toluene_Hartwig2024_test_system
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {180.0},
    MM = 0.092141,
    adminMass = 0.00154,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>toluene</td></tr><tr><td>population:</td><td>humans and rats</td></tr><tr><td>source_paper:</td><td>Hartwig_2024</td></tr><tr><td>measured_compound:</td><td>Toluene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>toluene 92.141 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'test system' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'test system' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'prophage induction and UMU test' — extend the ontology if this is a real PK parameter (source ['Tab4:row3:col1'])</li><li>dropped unlinked row (NIL): 'human lymphoblasts (MCL-5)' — extend the ontology if this is a real PK parameter (source ['Tab4:row22:col1'])</li><li>salvaged Q59 ('half-life of the alpha phase'=3) from results prose — parameter table was unreadable</li><li>salvaged Q47 ('that of the beta phase'=40) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Toluene</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'test system' subgroup of Hartwig_2024 (paper reports 2 populations: test system, value)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q47 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Toluene_Hartwig2024_test_system;
