% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = PentamidineIsethionate_Hui2016_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
