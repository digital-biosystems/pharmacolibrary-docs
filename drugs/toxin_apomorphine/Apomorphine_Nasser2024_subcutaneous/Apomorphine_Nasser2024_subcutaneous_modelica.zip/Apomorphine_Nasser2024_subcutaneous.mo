model Apomorphine_Nasser2024_subcutaneous
  parameter Real Cl_ref = 5.305555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.153 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26732799999999995,
    adminMass = 1e-06,
    ka = 0.004138888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>apomorphine</td></tr><tr><td>population:</td><td>simulated Parkinson's disease patients</td></tr><tr><td>source_paper:</td><td>Nasser_2024</td></tr><tr><td>measured_compound:</td><td>Apomorphine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>apomorphine 267.328 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Apomorphine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'subcutaneous' subgroup of Nasser_2024 (paper reports 4 populations: subcutaneous, subcutaneous / dose, mg, sublingual, sublingual / dose, mg)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Apomorphine_Nasser2024_subcutaneous;
