function p = Apomorphine_Nasser2024_subcutaneous_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: apomorphine   source: Nasser_2024 / subcutaneous   route: oral
  p.name  = 'Apomorphine_Nasser2024_subcutaneous_params';
  p.drug  = 'apomorphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 153.0;                % central volume [L]
  p.CL = 191.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 14.9;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
