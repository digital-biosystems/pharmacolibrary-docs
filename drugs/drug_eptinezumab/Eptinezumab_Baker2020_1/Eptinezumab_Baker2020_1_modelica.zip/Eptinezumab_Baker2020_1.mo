model Eptinezumab_Baker2020_1
  parameter Real Cl_ref = 1.7222222222222222e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00364 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eptinezumab</h4><p>Eptinezumab is a monoclonal antibody used to prevent migraine attacks. It is an authorised medicine in the European Union and is also approved elsewhere, given as an infusion by healthcare professionals.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28208949\">Wikidata Q28208949</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eptinezumab</td></tr><tr><td>population:</td><td>patients with episodic and chronic migraine and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Baker_2020</td></tr><tr><td>measured_compound:</td><td>eptinezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp2567-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC0-12wk, mean (CV%), h.µg mL⁻¹'</li><li>dropped value-less row: 'Cmax, mean (CV%), µg mL⁻¹'</li><li>dropped value-less row: 'Cavg, mean (CV%), µg mL⁻¹'</li><li>dropped value-less row: 'Ctrough, mean (CV%), µg mL⁻¹'</li><li>dropped value-less row: 'AUC0-τ, mean (CV%), h.µg mL⁻¹'</li><li>dropped value-less row: 'Css,avg, mean (CV%), µg mL⁻¹'</li><li>dropped value-less row: 'Rac(AUC), mean (CV%)' (captured trailing unit 'CV%' for child rows)</li><li>dropped value-less row: 'Rac(Cmax), mean (CV%)' (captured trailing unit 'CV%' for child rows)</li><li>salvaged Q22 ('CL'=0.0062) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central volume of distribution (Vc)'=3.64) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eptinezumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution (Vc)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>population split: '1 (n = 4)' subgroup of Baker_2020 (paper reports 7 populations: 1 (n = 4), 10 (n = 130), 100 (n = 727), 1000 (n = 87), 3 (n = 6), 30 (n = 336), 300 (n = 833))</li><li>molar mass: none found for 'eptinezumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Eptinezumab_Baker2020_1;
