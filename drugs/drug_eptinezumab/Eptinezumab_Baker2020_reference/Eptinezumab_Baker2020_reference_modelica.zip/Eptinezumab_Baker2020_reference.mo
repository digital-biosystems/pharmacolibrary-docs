model Eptinezumab_Baker2020_reference
  parameter Real Cl_ref = 1.7222222222222222e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00364 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>eptinezumab</td></tr><tr><td>population:</td><td>patients with episodic and chronic migraine and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Baker_2020</td></tr><tr><td>measured_compound:</td><td>eptinezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp2567-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '1 (n = 4)' — extend the ontology if this is a real PK parameter (source ['prp2567-tbl-0002:row1:col1', 'prp2567-tbl-0002:row1:col2', 'prp2567-tbl-0002:row1:col3', 'prp2567-tbl-0002:row1:col4', 'prp2567-tbl-0002:row1:col5', 'prp2567-tbl-0002:row1:col6', 'Baker_2020_table_3:row0:col1', 'Baker_2020_table_3:row0:col2', 'Baker_2020_table_3:row0:col3', 'Baker_2020_table_3:row0:col4', 'Baker_2020_table_3:row0:col5', 'Baker_2020_table_3:row0:col6'])</li><li>dropped duplicate Q19 ('AUC0‐τ, mean (CV%), h·μg mL−1', value '183') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Rac(AUCτ), mean (CV%)' — extend the ontology if this is a real PK parameter (source ['Baker_2020_table_3:row3:col1', 'Baker_2020_table_3:row3:col2', 'Baker_2020_table_3:row3:col3', 'Baker_2020_table_3:row3:col4', 'Baker_2020_table_3:row3:col5', 'Baker_2020_table_3:row3:col6', 'Baker_2020_table_3:row3:col7'])</li><li>dropped unlinked row (NIL): 'Rac(C max), mean (CV%)' — extend the ontology if this is a real PK parameter (source ['Baker_2020_table_3:row4:col1', 'Baker_2020_table_3:row4:col2', 'Baker_2020_table_3:row4:col3', 'Baker_2020_table_3:row4:col4', 'Baker_2020_table_3:row4:col5', 'Baker_2020_table_3:row4:col6', 'Baker_2020_table_3:row4:col7'])</li><li>salvaged Q22 ('CL'=0.0062) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('central volume of distribution (Vc)'=3.64) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eptinezumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eptinezumab_Baker2020_reference;
