#!/usr/bin/env python3
"""Simulate Eptinezumab_Baker2020_reference.cellml (0..24.0 h) and write results.

Headless-friendly: writes Eptinezumab_Baker2020_reference.csv, Eptinezumab_Baker2020_reference.json and Eptinezumab_Baker2020_reference.png next to this script
(no interactive window). Requires `libcellml` (pip install libcellml), scipy and matplotlib.
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import numpy as np
import libcellml as lc
from scipy.integrate import solve_ivp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Eptinezumab_Baker2020_reference")

# CellML -> Python. libCellML validates and analyses first; either failing means the model is
# not a solvable ODE system and there is nothing to simulate.
model = lc.Parser().parseModel(open(BASE + ".cellml").read())
validator = lc.Validator(); validator.validateModel(model)
if validator.errorCount():
    raise SystemExit("Eptinezumab_Baker2020_reference.cellml is not valid: " + validator.error(0).description())
analyser = lc.Analyser(); analyser.analyseModel(model)
if analyser.errorCount():
    raise SystemExit("Eptinezumab_Baker2020_reference.cellml is not solvable: " + analyser.error(0).description())
generator = lc.Generator()
generator.setProfile(lc.GeneratorProfile(lc.GeneratorProfile.Profile.PYTHON))
generator.setModel(analyser.model())

ns = {}
exec(compile(generator.implementationCode(), "<generated>", "exec"), ns)
states = ns["create_states_array"]()
variables = ns["create_variables_array"]()
ns["initialise_variables"](states, ns["create_states_array"](), variables)
ns["compute_computed_constants"](variables)

def rhs(t, y):
    r = ns["create_states_array"]()
    ns["compute_rates"](t, list(y), r, variables)
    return list(r)

t_eval = np.linspace(0.0, 24.0, 500)
sol = solve_ivp(rhs, (0.0, 24.0), list(states), t_eval=t_eval,
                method="LSODA", rtol=1e-8, atol=1e-10)
if not sol.success:
    raise SystemExit("integration failed: " + sol.message)

# Cc is algebraic (Cc = A_central/Vc), so it is recomputed along the trajectory rather than
# integrated; its slot comes from the generated VARIABLE_INFO.
names = [v.get("name") if isinstance(v, dict) else str(v) for v in ns.get("VARIABLE_INFO", [])]
idx = names.index("Cc") if "Cc" in names else None
if idx is None:
    raise SystemExit("no Cc variable in Eptinezumab_Baker2020_reference.cellml")
Cc = []
for k, tk in enumerate(sol.t):
    v = list(variables)
    ns["compute_variables"](tk, list(sol.y[:, k]), ns["create_states_array"](), v)
    Cc.append(float(v[idx]))
t = [float(x) for x in sol.t]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Eptinezumab_Baker2020_reference", "stop_time_h": 24.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Eptinezumab_Baker2020_reference"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
