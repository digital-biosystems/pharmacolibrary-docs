model Menadione_Hu1996_reference
  parameter Real Cl_ref = 1.37e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.030833 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.172183,
    adminMass = 1e-05,
    ka = 0.009816666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>menadione</td></tr><tr><td>population:</td><td>rabbits</td></tr><tr><td>source_paper:</td><td>Hu_1996</td></tr><tr><td>measured_compound:</td><td>menadione</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>menadiol sodium diphosphate 530.175 g/mol (pubchem); menadione 172.183 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is menadione; the compartment is menadione. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is menadione, not menadione</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>menadione's own concentration-time course is not produced by this model</li><li>formation is 22x faster than menadione elimination (kfm 35.3/h vs ke 1.6/h), so the metabolite is elimination-rate-limited and the input rate is identifiable</li><li>dropped duplicate Q57 ('mean elimination t1/2 values of menadione in RBCs', value 35.22) — already have one for this compound</li><li>dropped duplicate Q76 ('apparent volume of distribution (Vd/F) in RBCs', value 20.488) — already have one for this compound</li><li>dropped duplicate Q305 ('formation rate constant (kf) of menadione in RBCs', value 1.52) — already have one for this compound</li><li>conflicting Q305 for menadione: 'formation rate constant (kf) of menadione in RBCs' = 1.52 vs 'formation rate constant (kf) of menadione in plasma' = 0.589 — route to review</li><li>metabolite menadione: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite menadione: Q76→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=menadione</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 8/8 row label(s) assigned, 0 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Menadione_Hu1996_reference;
