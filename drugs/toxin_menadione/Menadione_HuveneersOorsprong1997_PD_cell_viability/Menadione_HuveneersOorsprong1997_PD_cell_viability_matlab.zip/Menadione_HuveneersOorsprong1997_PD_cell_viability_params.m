function p = Menadione_HuveneersOorsprong1997_PD_cell_viability_params()
% Menadione_HuveneersOorsprong1997_PD_cell_viability_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% menadione Huveneers-Oorsprong_1997::cell_viability: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µm per second, in SI inside (kg/m3, s). Response cell viability in %. Driver: menadione (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 22.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 220.0;
p.form = 'E0/(1 - Emax*frac)';
end
