model Menadione_HuveneersOorsprong1997_PD_cell_viability
  "indirect_response_ii exposure-response sweep — Huveneers-Oorsprong_1997 :: cell viability (cell viability)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type II effect term
    EC50 = 22,  // [µm]
    gamma = 1,
    exposure_per_s = 1);   // 1 µm per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // exposure_unit_unresolved: 'µm' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 220, Interval = 0.44),
    Documentation(info = "<html><body><h4>Menadione_HuveneersOorsprong1997_PD_cell_viability</h4><p>The steady-state exposure-response curve of Huveneers-Oorsprong MB et al., <i>Toxicology in vitro : an international journal published in association with BIBRA 11(4):385–392</i> 1997 (<a href=\"https://doi.org/10.1016/s0887-2333(97)00022-2\">doi:10.1016/s0887-2333(97)00022-2</a>) — cell viability [%] against menadione µm — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =         22 µm       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one µm of menadione per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (22 µm)  response 0
  exposure -> infinity  response inf</pre></body></html>"));
end Menadione_HuveneersOorsprong1997_PD_cell_viability;
