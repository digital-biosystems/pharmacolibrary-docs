// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Atomoxetine_Kim2018_cyp2d6_wt_wt
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {8064.000000000002},
    MM = 0.255361,
    adminMass = 2e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atomoxetine</td></tr><tr><td>population:</td><td>healthy Korean adults (CYP2D6*wt/*wt and CYP2D6*10/*10), plus simulated CYP2D6 EM and PM populations</td></tr><tr><td>source_paper:</td><td>Kim_2018</td></tr><tr><td>measured_compound:</td><td>Atomoxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>atomoxetine 255.361 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 2. Atomoxetine parameters used for PBPK development in the CYP2D6*wt/*wt genotype group.'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Atomoxetine</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'cyp2d6*wt/*wt' subgroup of Kim_2018 (paper reports 2 populations: cyp2d6*10/*10, cyp2d6*wt/*wt)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Atomoxetine_Kim2018_cyp2d6_wt_wt;
