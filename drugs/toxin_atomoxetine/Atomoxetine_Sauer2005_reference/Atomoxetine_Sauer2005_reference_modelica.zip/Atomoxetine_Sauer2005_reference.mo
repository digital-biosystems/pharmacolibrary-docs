model Atomoxetine_Sauer2005_reference
  parameter Real Cl_ref = 2.2031120322284585e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0595 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.255361,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atomoxetine</td></tr><tr><td>population:</td><td>adults and children/adolescents with ADHD, CYP2D6 extensive and poor metabolisers</td></tr><tr><td>source_paper:</td><td>Sauer_2005</td></tr><tr><td>measured_compound:</td><td>Atomoxetine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>atomoxetine 255.361 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('plasma half-life (poor metabolisers)', value 21.6) — already have one for this compound</li><li>dropped duplicate Q354 ('systemic plasma clearance (poor metabolisers)', value 0.03) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atomoxetine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Morais_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=7.9312 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Atomoxetine_Sauer2005_reference;
