model Atorvastatin_ReigLpez2021_morse_et_al_2019
  parameter Real Cl_ref = 1.4166666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>humans (hypercholesterolemic patients and healthy subjects in published PBPK models)</td></tr><tr><td>source_paper:</td><td>Reig-López_2021</td></tr><tr><td>measured_compound:</td><td>atorvastatin open acid form</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00709-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Molecular weight (g/mol)'; source reconciliation required</li><li>table representations disagree for 'logPo:w'; source reconciliation required</li><li>table representations disagree for 'pKa'; source reconciliation required</li><li>table representations disagree for 'B/P'; source reconciliation required</li><li>table representations disagree for 'fu'; source reconciliation required</li><li>table representations disagree for 'Peff,man (10−4 cm/s)'; source reconciliation required</li><li>table representations disagree for 'Papp (10−6 cm/s)'; source reconciliation required</li><li>table representations disagree for 'Method'; source reconciliation required</li><li>table representations disagree for 'Vss (L/kg)'; source reconciliation required</li><li>table representations disagree for 'Kp scalar (model)'; source reconciliation required</li><li>table representations disagree for 'Km (βM)'; source reconciliation required</li><li>table representations disagree for 'Vmax (pmol/min/pmol isoform)'; source reconciliation required</li><li>table representations disagree for 'Km (µM)'; source reconciliation required</li><li>table representations disagree for 'CLint (µL/min/mg protein)'; source reconciliation required</li><li>table representations disagree for 'CLPD (mL/min/106 cells)'; source reconciliation required</li><li>table representations disagree for 'CLint (µL/min/106 cells)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_ReigLpez2021_morse_et_al_2019;
