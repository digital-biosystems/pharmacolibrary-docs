function p = Atorvastatin_Stillemans2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atorvastatin   source: Stillemans_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Atorvastatin_Stillemans2022_reference_params';
  p.drug  = 'atorvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1960.0;                % central volume [L]
  p.CL = 535.0;                % clearance [L/h]
  p.Vp = [3900.0];             % peripheral volumes [L]
  p.Q  = [1690.0];             % inter-compartmental clearances [L/h]
  p.ka = 2.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
