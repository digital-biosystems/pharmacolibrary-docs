model Atorvastatin_Stillemans2022_reference
  parameter Real Cl_ref = 0.0001486111111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 1.96 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 2e-05,
    ka = 0.0006944444444444445,
    Tlag = 0.0,
    k12 = 0.0002395124716553288,
    k21 = 0.00012037037037037037
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>ambulatory patients at risk of cardiovascular disease and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Stillemans_2022</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13185-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('θCL support (L h−1)', value '400') — already have one for this compound</li><li>dropped unlinked row (NIL): 'θSLCO1B1 521CC' — extend the ontology if this is a real PK parameter (source ['cts13185-tbl-0003:row16:col1'])</li><li>NIL: refused to back-fill base 'equation variable' from footnote/prose loose number None (source ['cts13185-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (θCL investigation (L h−1)); Q30 (θQ (L h−1)); Q63 (θVc (L)); Q64 (θVp (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Stillemans2022_reference;
