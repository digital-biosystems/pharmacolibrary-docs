model Atorvastatin_Storelli2024_aucrhi_cp_c
  parameter Real Cl_ref = 3.277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 2e-05,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>healthy volunteers and hepatic impairment patients (Child-Pugh A/B/C), modeled humans</td></tr><tr><td>source_paper:</td><td>Storelli_2024</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413062-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Asunaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row0:col3'])</li><li>dropped unlinked row (NIL): 'Glecaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row1:col3'])</li><li>dropped unlinked row (NIL): 'Grazoprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row2:col3'])</li><li>dropped unlinked row (NIL): 'Paritaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row3:col3'])</li><li>dropped unlinked row (NIL): 'Elagolix' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row5:col3'])</li><li>dropped unlinked row (NIL): 'Voxilaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row6:col3'])</li><li>dropped unlinked row (NIL): 'Repaglinide' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row8:col3'])</li><li>unit_dimension_unknown: '>80%' (kuptake)</li><li>dropped unlinked row (NIL): 'Pravastatin' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row12:col3'])</li><li>table mostly unlinked (8/9 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: 'aucrhi (cp‐c)' subgroup of Storelli_2024 (paper reports 5 populations: aucrhi (cp‐a), aucrhi (cp‐b), aucrhi (cp‐c), initial value (hvs), simulated value in cp‐c)</li><li>gap-filled Q22 (CL) from Courlet_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Storelli2024_aucrhi_cp_c;
