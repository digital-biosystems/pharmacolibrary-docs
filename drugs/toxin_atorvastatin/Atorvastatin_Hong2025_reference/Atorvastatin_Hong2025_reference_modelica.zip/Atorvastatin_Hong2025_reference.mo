model Atorvastatin_Hong2025_reference
  parameter Real Cl_ref = 3.277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 2e-05,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>virtual population with demographics matched to people with cystic fibrosis (adults, Sim-Healthy volunteers adjusted)</td></tr><tr><td>source_paper:</td><td>Hong_2025</td></tr><tr><td>measured_compound:</td><td>atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-00318-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Atorvastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Atorvastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Pravastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Pravastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Pitavastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Pitavastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Rosuvastatin +/− ETI'; source reconciliation required</li><li>table representations disagree for 'Rosuvastatin +/− ETI'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Pravastatin +/− ETI' — extend the ontology if this is a real PK parameter (source ['Hong_2025_table_3:row2:col2', 'Hong_2025_table_3:row3:col2'])</li><li>dropped unlinked row (NIL): 'Pitavastatin +/− ETI' — extend the ontology if this is a real PK parameter (source ['Hong_2025_table_3:row4:col2', 'Hong_2025_table_3:row5:col2'])</li><li>dropped unlinked row (NIL): 'Rosuvastatin +/− ETI' — extend the ontology if this is a real PK parameter (source ['Hong_2025_table_3:row6:col2', 'Hong_2025_table_3:row7:col2'])</li><li>dropped unlinked row (NIL): 'Midazolam +/− ivacaftor' — extend the ontology if this is a real PK parameter (source ['Hong_2025_table_2:row0:col2', 'Hong_2025_table_2:row0:col3', 'Hong_2025_table_2:row0:col4', 'Hong_2025_table_2:row1:col2', 'Hong_2025_table_2:row1:col3', 'Hong_2025_table_2:row1:col4'])</li><li>dropped unlinked row (NIL): 'Ethinylestradiol +/− ivacaftor' — extend the ontology if this is a real PK parameter (source ['Hong_2025_table_2:row2:col2', 'Hong_2025_table_2:row2:col3', 'Hong_2025_table_2:row2:col4', 'Hong_2025_table_2:row3:col2', 'Hong_2025_table_2:row3:col3', 'Hong_2025_table_2:row3:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atorvastatin</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Courlet_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Hong2025_reference;
