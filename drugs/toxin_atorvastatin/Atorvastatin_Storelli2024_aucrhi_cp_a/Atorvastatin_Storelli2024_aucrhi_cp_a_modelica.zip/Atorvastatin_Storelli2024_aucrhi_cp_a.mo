model Atorvastatin_Storelli2024_aucrhi_cp_a
  parameter Real Cl_ref = 3.277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 2e-05,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>healthy volunteers and hepatic impairment patients (Child-Pugh A/B/C), modeled humans</td></tr><tr><td>source_paper:</td><td>Storelli_2024</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413062-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Asunaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row0:col1'])</li><li>dropped unlinked row (NIL): 'Glecaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Grazoprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row2:col1'])</li><li>dropped unlinked row (NIL): 'Paritaprevir' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row3:col1'])</li><li>unit_dimension_unknown: '>80%' (FH)</li><li>dropped unlinked row (NIL): 'Elagolix' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row5:col1'])</li><li>dropped unlinked row (NIL): 'Fimasartan' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row7:col1'])</li><li>dropped unlinked row (NIL): 'Pitavastatin' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row9:col1'])</li><li>dropped unlinked row (NIL): 'Valsartan' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row10:col1'])</li><li>dropped unlinked row (NIL): 'Gadoxetic acid (i.v.)' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row11:col1'])</li><li>dropped unlinked row (NIL): 'Pravastatin' — extend the ontology if this is a real PK parameter (source ['Storelli_2024_table_1:row12:col1'])</li><li>unit_dimension_unknown: '>80%' (FH)</li><li>dropped duplicate Q42 ('Rosuvastatin', value '1.05') — already have one for this compound</li><li>table mostly unlinked (10/12 table-cell rows NIL) — likely the wrong table was located, not 2 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Storelli2024_aucrhi_cp_a;
