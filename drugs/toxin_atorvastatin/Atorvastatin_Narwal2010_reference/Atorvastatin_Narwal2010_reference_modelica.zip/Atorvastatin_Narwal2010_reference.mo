// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Atorvastatin_Narwal2010_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {3.25, 2.17},
    CLelim = {0.00014, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {0.0, 0.0}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>adults, some with atorvastatin-induced myopathy</td></tr><tr><td>source_paper:</td><td>Narwal_2010</td></tr><tr><td>measured_compound:</td><td>atorvastatin acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>atorvastatin acid 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Q1.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('apparent clearance to atorvastatin acid', value 24) — already have one for this compound</li><li>dropped value-less row: 'aspartate transaminase (covariate for apparent volume of the central compartment for atorvastatin acid)'</li><li>dropped value-less row: 'aspartate transaminase (covariate for apparent total body clearance of atorvastatin lactone)'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=atorvastatin acid</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 0/9 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'atorvastatin lactone' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Narwal2010_reference;
