model Atorvastatin_Lehoux2023_reference
  parameter Real Cl_ref = 3.277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 2e-05,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>cynomolgus monkeys (male and female)</td></tr><tr><td>source_paper:</td><td>Lehoux_2023</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21080-tbl-0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Day' — extend the ontology if this is a real PK parameter (source ['Lehoux_2023_table_3:row0:col3', 'Lehoux_2023_table_3:row1:col3', 'Lehoux_2023_table_3:row2:col3', 'Lehoux_2023_table_3:row3:col3', 'Lehoux_2023_table_3:row4:col3', 'Lehoux_2023_table_3:row5:col3', 'Lehoux_2023_table_3:row6:col3', 'Lehoux_2023_table_3:row7:col3'])</li><li>dropped value-less row: 'TABLE 5. Changes in serum lipid levels following administration of inclisiran (monthly) and atorvastatin (daily) alone or in combination in cynomolgus monkeys.'</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>dropped value-less row: 'HDL‐C'</li><li>dropped value-less row: 'LDL‐C'</li><li>dropped value-less row: 'M'</li><li>dropped value-less row: 'N/A'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>base model from table(s) without population columns (Lehoux_2023:other_prose, Lehoux_2023_table_3, prp21080-tbl-0005:footnote); populations atorvastatin (40/25)a mg/kg (cohort 2), cohort 2 atorvastatin (40/25) mg/kgb, cohort 3 inclisiran 300mg/kg, cohort 6 inclisiran/atorvastatin 300 (40/25) mg/kgb, inclisiran/atorvastatin 100/40/25a mg/kg (cohort 5), inclisiran/atorvastatin 30/40/25a mg/kg (cohort 4), inclisiran/atorvastatin 30/40/25a mg/kg (cohort 5), inclisiran/atorvastatin 300/ (40/25)a mg/kg (cohort 6), inclisiran/atorvastatin 300/40/25a mg/kg (cohort 6) kept as separate records</li><li>gap-filled Q22 (CL) from Courlet_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Stillemans_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Courlet_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Lehoux2023_reference;
