// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Atorvastatin_Lehoux2023_atorvastatin_40_25_a_mg_kg_cohort_2
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {16236.000000000002},
    MM = 0.55865,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>cynomolgus monkeys (male and female)</td></tr><tr><td>source_paper:</td><td>Lehoux_2023</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>prp21080-tbl-0005</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'TABLE 5. Changes in serum lipid levels following administration of inclisiran (monthly) and atorvastatin (daily) alone or in combination in cynomolgus monkeys.'</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>dropped value-less row: 'HDL‐C'</li><li>dropped value-less row: 'LDL‐C'</li><li>dropped value-less row: 'M'</li><li>dropped value-less row: 'N/A'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'atorvastatin (40/25)a mg/kg (cohort 2)' subgroup of Lehoux_2023 (paper reports 9 populations: atorvastatin (40/25)a mg/kg (cohort 2), cohort 2 atorvastatin (40/25) mg/kgb, cohort 3 inclisiran 300mg/kg, cohort 6 inclisiran/atorvastatin 300 (40/25) mg/kgb, inclisiran/atorvastatin 100/40/25a mg/kg (cohort 5), inclisiran/atorvastatin 30/40/25a mg/kg (cohort 4), inclisiran/atorvastatin 30/40/25a mg/kg (cohort 5), inclisiran/atorvastatin 300/ (40/25)a mg/kg (cohort 6), inclisiran/atorvastatin 300/40/25a mg/kg (cohort 6))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Atorvastatin_Lehoux2023_atorvastatin_40_25_a_mg_kg_cohort_2;
