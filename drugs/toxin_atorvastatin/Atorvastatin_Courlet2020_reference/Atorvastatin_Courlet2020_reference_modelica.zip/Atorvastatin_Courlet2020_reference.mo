model Atorvastatin_Courlet2020_reference
  parameter Real Cl_ref = 6.38888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.91 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 5e-06,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>aging people living with HIV</td></tr><tr><td>source_paper:</td><td>Courlet_2020</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>compound tags: 1 row(s) → ortho-OH-atorvastatin (abbreviation 1)</li><li>dropped duplicate Q22 ('CLo-OH-ator (L/h)', value '116') — already have one for this compound</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'FR' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CLator (L/h)); Q63 (Vcator=Vcmet (L)); Q64 (Vpator (L)); Q30 (Q (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>template fit: PK_3M_3C — first-pass formation; parent 2 + hepatic, metabolites [0] (site presystemic: 'Metabolite concentrations were described by considering both linear metabolism from atorvastatin and presystemic metabol')</li><li>row roles (LLM): model_class=compartmental; 0/18 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'ortho-OH-atorvastatin' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Courlet2020_reference;
