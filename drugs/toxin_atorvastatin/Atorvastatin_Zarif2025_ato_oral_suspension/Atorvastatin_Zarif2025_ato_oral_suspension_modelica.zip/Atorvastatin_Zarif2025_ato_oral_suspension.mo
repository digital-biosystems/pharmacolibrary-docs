model Atorvastatin_Zarif2025_ato_oral_suspension
  parameter Real Cl_ref = 3.277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 2e-05,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>rabbits receiving intranasal ATO-NLC hydrogel and oral ATO suspension</td></tr><tr><td>source_paper:</td><td>Zarif_2025</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-18-00421-t005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'ato-oral suspension' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'ato-oral suspension' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'ato-oral suspension' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'ato-oral suspension' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'ato-oral suspension' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 3 (source ['pharmaceuticals-18-00421-t005:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Atorvastatin</li><li>population split: 'ato-oral suspension' subgroup of Zarif_2025 (paper reports 2 populations: ato-nlc f2 nasal gel, ato-oral suspension)</li><li>gap-filled Q22 (CL) from Courlet_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Stillemans_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Courlet_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Courlet_2020, Stillemans_2022 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Zarif2025_ato_oral_suspension;
