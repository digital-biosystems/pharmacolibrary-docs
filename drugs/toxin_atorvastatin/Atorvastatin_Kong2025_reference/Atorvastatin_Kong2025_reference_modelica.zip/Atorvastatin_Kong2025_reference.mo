model Atorvastatin_Kong2025_reference
  parameter Real Cl_ref = 0.00010083333333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 0.835 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.55865,
    adminMass = 1e-08,
    ka = 0.0020916666666666666,
    Tlag = 0.0,
    k21 = 2.8945612278945614e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>Chinese healthy volunteers and end-stage renal disease (ESRD) patients</td></tr><tr><td>source_paper:</td><td>Kong_2025</td></tr><tr><td>measured_compound:</td><td>Atorvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt3546-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Atorvastatin 558.65 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'k a' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V p/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V c/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'V p/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('IIV% (RSE%)')</li><li>table representations disagree for 'CL/F'; source reconciliation required</li><li>table representations disagree for 'DISPTV on CL/F'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Kong2025_reference;
