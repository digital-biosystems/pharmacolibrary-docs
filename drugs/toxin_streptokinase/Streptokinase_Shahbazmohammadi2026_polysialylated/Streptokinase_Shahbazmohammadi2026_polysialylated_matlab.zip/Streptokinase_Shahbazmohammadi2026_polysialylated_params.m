function p = Streptokinase_Shahbazmohammadi2026_polysialylated_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: streptokinase   source: Shahbazmohammadi_2026 / polysialylated   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Streptokinase_Shahbazmohammadi2026_polysialylated_params';
  p.drug  = 'streptokinase';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1633.1;                % central volume [L]
  p.CL = 2675.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
