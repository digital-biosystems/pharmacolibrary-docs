model Streptokinase_Shahbazmohammadi2026_polysialylated
  parameter Real Cl_ref = 0.0007431666666666666 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6331 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>streptokinase</td></tr><tr><td>population:</td><td>polysialylated</td></tr><tr><td>source_paper:</td><td>Shahbazmohammadi_2026</td></tr><tr><td>measured_compound:</td><td>Streptokinase</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Shahbazmohammadi_2026_table_1: rows are variants (Native, Polysialylated), the parameters are the column headers (EC 50 (IU)) — read one record per variant</li><li>dropped PD-category row 'EC 50 (IU)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Shahbazmohammadi_2026_table_1:row2:col2'])</li><li>salvaged Q57 ('Native Half-Life'=0.5) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Native Volume of distribution'=23.33) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Native Clearance'=38.22) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Streptokinase</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'Polysialylated' is one of 2 estimates of Shahbazmohammadi_2026's substance matrix (Native, Polysialylated); same population, different estimation method</li><li>molar mass: none found for 'streptokinase' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Streptokinase_Shahbazmohammadi2026_polysialylated;
