% Run (SimBiology): build model + dose, simulate 0..37.0 h, plot.
p = Hydroxocobalamin_de1994_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 37.0);
