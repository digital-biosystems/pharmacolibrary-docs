function p = Doripenem_Tanaka2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doripenem   source: Tanaka_2017 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doripenem_Tanaka2017_reference_params';
  p.drug  = 'doripenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.6;                % central volume [L]
  p.CL = 10.8;                % clearance [L/h]
  p.Vp = [5.2];             % peripheral volumes [L]
  p.Q  = [4.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
