function p = Doripenem_Nonoshita2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doripenem   source: Nonoshita_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doripenem_Nonoshita2020_reference_params';
  p.drug  = 'doripenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.2;                % central volume [L]
  p.CL = 7.3;                % clearance [L/h]
  p.Vp = [24.2];             % peripheral volumes [L]
  p.Q  = [12.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
