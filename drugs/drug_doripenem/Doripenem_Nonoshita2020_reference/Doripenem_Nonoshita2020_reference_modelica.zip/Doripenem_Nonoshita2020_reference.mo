model Doripenem_Nonoshita2020_reference
  parameter Real Cl_ref = 2.027777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0132 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42050400000000004,
    adminMass = 0.00025,
    k12 = 0.00026725589225589226,
    k21 = 0.00014577594123048668
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doripenem</h4><p>Doripenem is a carbapenem antibiotic that was used to treat bacterial infections, including pneumonia, urinary tract infections, and hospital-acquired infections. It is no longer marketed in the European Union, where its product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411552\">Wikidata Q411552</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doripenem</td></tr><tr><td>population:</td><td>Japanese patients in intensive care unit</td></tr><tr><td>source_paper:</td><td>Nonoshita_2020</td></tr><tr><td>measured_compound:</td><td>doripenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doripenem 420.504 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CLbody(non-CRRT) (L h-1)'; source reconciliation required</li><li>competing summary columns for 'CLbody(non-CRRT) (L h-1)'; not population strata</li><li>table representations disagree for 'CLbody(non-CRRT) (L h-1)'; source reconciliation required</li><li>competing summary columns for 'CLbody(non-CRRT) (L h-1)'; not population strata</li><li>table representations disagree for 'CLbody(non-CRRT) (L h-1)'; source reconciliation required</li><li>table representations disagree for 'CLbody(CRRT) (L h-1)'; source reconciliation required</li><li>competing summary columns for 'CLbody(CRRT) (L h-1)'; not population strata</li><li>table representations disagree for 'CLbody(CRRT) (L h-1)'; source reconciliation required</li><li>competing summary columns for 'CLbody(CRRT) (L h-1)'; not population strata</li><li>table representations disagree for 'CLbody(CRRT) (L h-1)'; source reconciliation required</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>competing summary columns for 'V1 (L)'; not population strata</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>competing summary columns for 'V1 (L)'; not population strata</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>table representations disagree for 'V2 (L)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doripenem_Nonoshita2020_reference;
