% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Doripenem_Nonoshita2020_base_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
