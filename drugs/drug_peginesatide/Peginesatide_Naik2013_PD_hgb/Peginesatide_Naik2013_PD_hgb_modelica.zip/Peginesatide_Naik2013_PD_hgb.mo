model Peginesatide_Naik2013_PD_hgb
  "indirect_response_ii exposure-response sweep — Naik_2013 :: Hgb (hemoglobin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 115,      // [kg/m3; g/dL × 10]
    Emax = 1,  // type II effect term
    EC50 = 0.000401,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4100, Interval = 8.2),
    Documentation(info = "<html><body><h4>Peginesatide_Naik2013_PD_hgb</h4><p>The steady-state exposure-response curve of Naik H et al., <i>PloS one 8(6):e66422</i> 2013 (<a href=\"https://doi.org/10.1371/journal.pone.0066422\">doi:10.1371/journal.pone.0066422</a>) — hemoglobin [g/dL] against peginesatide ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       11.5 g/dL     drug-free response (baseline) (Hemoglobin at baseline, in g/dL — Final Estimate (% SEM), Q324)
  Emax  = (library default) maximal effect term
  EC50  =        401 ng/mL    exposure at half of the maximal effect term (Drug concentration required for 50% of maximumresponse (EC50), in ng/mL — Final Estimate (% SEM), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of peginesatide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 115   (drug-free)
  exposure = EC50 (401 ng/mL)  response 230
  exposure -> infinity  response inf</pre></body></html>"));
end Peginesatide_Naik2013_PD_hgb;
