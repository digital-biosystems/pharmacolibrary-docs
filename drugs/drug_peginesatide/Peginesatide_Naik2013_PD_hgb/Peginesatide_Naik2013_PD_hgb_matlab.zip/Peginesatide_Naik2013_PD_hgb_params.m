function p = Peginesatide_Naik2013_PD_hgb_params()
% Peginesatide_Naik2013_PD_hgb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% peginesatide Naik_2013::Hgb: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Hgb in g/dL. Driver: peginesatide (pk_record).
p.E0 = 114.99999999999999;
p.Emax = 1.0;
p.EC50 = 0.000401;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4100.0;
p.form = 'E0/(1 - Emax*frac)';
end
