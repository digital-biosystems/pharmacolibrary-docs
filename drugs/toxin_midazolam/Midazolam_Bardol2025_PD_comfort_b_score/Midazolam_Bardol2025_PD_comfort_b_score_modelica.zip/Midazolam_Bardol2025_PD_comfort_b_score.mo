model Midazolam_Bardol2025_PD_comfort_b_score
  "sigmoid_emax exposure-response sweep — Bardol_2025 :: COMFORT-B score (COMFORT-B score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6,      // [score]
    Emax = -6,  // [score]
    EC50 = 0.000186,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1900, Interval = 3.8),
    Documentation(info = "<html><body><h4>Midazolam_Bardol2025_PD_comfort_b_score</h4><p>The steady-state exposure-response curve of Bardol M et al., <i>Paediatric anaesthesia 35(12):1053-1062</i> 2025 (<a href=\"https://doi.org/10.1111/pan.70050\">doi:10.1111/pan.70050</a>) — COMFORT-B score [score] against midazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          6 score    drug-free response (baseline) (BASE, Q324)
  Emax  =          6 score    maximal effect term (Emax, Q320)
  EC50  =        186 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6   (drug-free)
  exposure = EC50 (186 ng/mL)  response 3
  exposure -> infinity  response 0</pre></body></html>"));
end Midazolam_Bardol2025_PD_comfort_b_score;
