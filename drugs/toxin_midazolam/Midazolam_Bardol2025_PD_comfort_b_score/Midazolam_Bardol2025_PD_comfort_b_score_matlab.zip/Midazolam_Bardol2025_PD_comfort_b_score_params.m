function p = Midazolam_Bardol2025_PD_comfort_b_score_params()
% Midazolam_Bardol2025_PD_comfort_b_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Bardol_2025::COMFORT_B_score: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response COMFORT-B score in score. Driver: midazolam (pk_record).
p.E0 = 6.0;
p.Emax = -6.0;
p.EC50 = 0.000186;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1900.0;
p.form = 'E0 + Emax*frac';
end
