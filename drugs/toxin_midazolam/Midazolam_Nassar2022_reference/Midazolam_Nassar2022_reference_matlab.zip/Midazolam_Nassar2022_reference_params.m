function p = Midazolam_Nassar2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Nassar_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Nassar2022_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 56.7;                % central volume [L]
  p.CL = 43.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.0027;             % dose [mg]
end
