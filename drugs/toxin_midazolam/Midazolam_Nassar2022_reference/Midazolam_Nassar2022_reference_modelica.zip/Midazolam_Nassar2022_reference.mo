model Midazolam_Nassar2022_reference
  parameter Real Cl_ref = 1.2194444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05670000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32577100000000003,
    adminMass = 2.7e-09,
    ka = 0.0017777777777777779,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>24 healthy individuals (12 males, 12 females)</td></tr><tr><td>source_paper:</td><td>Nassar_2022</td></tr><tr><td>measured_compound:</td><td>Midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>1'-Hydroxymidazolam 341.77 g/mol (pubchem); Midazolam 325.771 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>PK_3M template not built: formation of 1'-Hydroxymidazolam is not quantified (no CLfm, fm, kfm)</li><li>PK_3M template not built: formation of 1'-Hydroxymidazolam is not quantified (no CLfm, fm, kfm)</li><li>table section iiv: 'ω2 CLMDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 CLMDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 VMDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 VMDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 CL 1’-OH-MDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 CL 1’-OH-MDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 V 1’-OH-MDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section iiv: 'ω2 V 1’-OH-MDZ' routed out of structural estimates ('Interindividual variability [%CV]')</li><li>table section residual_error: 'MDZ' routed out of structural estimates ('Residual variability [proportional, %CV]')</li><li>table section residual_error: 'MDZ' routed out of structural estimates ('Residual variability [proportional, %CV]')</li><li>table section residual_error: '1’-OH-MDZ' routed out of structural estimates ('Residual variability [proportional, %CV]')</li><li>table section residual_error: '1’-OH-MDZ' routed out of structural estimates ('Residual variability [proportional, %CV]')</li><li>table representations disagree for 'CLMDZ [L/h]'; source reconciliation required</li><li>conflicting source units for 'CLMDZ [L/h]': [{'unit': 'L/h', 'source': 'Nassar_2022_table_p7_1:row1:col0', 'scope': 'label'}, {'unit': '22] h', 'source': 'Nassar_2022_table_p7_1:row1:col1', 'scope': 'description'}]</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Nassar2022_reference;
