function p = Midazolam_Kim2026_final_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: midazolam   source: Kim_2026 / final   PK_3M_9C parent + 1 metabolite(s), 3 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=325.771 g/mol C_M1=341.77 g/mol
  p.name  = 'Midazolam_Kim2026_final_params';
  p.drug  = 'midazolam';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1', 'peripheral_M1'};
  p.V = [8.25, 2.71, 98.0];          % compartment volumes [L]
  p.K = [-0.6593939393939394, 0.0, 0.0;
         0.6917775574457722, -21.30627306273063, 0.011632653061224489;
         0.0, 0.4206642066420664, -0.011632653061224489];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 15.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'Midazolam', '1-hydroxymidazolam'};
end
