function p = Midazolam_Wiebe2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Wiebe_2020 / reference   route: oral
  p.name  = 'Midazolam_Wiebe2020_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.5;                % central volume [L]
  p.CL = 24.1;                % clearance [L/h]
  p.Vp = [41.0];             % peripheral volumes [L]
  p.Q  = [8.0];             % inter-compartmental clearances [L/h]
  p.ka = 2.31;                % absorption rate [1/h]
  p.F  = 0.276;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
