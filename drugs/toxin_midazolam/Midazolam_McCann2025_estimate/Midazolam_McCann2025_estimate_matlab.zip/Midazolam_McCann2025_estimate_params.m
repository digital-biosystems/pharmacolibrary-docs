function p = Midazolam_McCann2025_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: McCann_2025 / estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_McCann2025_estimate_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.09;                % central volume [L]
  p.CL = 14.9;                % clearance [L/h]
  p.Vp = [34.5];             % peripheral volumes [L]
  p.Q  = [45.7];             % inter-compartmental clearances [L/h]
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
