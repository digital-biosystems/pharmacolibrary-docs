model Midazolam_McCann2025_estimate
  parameter Real Cl_ref = 4.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00609 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32577100000000003,
    adminMass = 1.5e-05,
    ka = 0.0017777777777777779,
    Tlag = 0.0,
    k12 = 0.0020844736361977745,
    k21 = 0.0003679549114331723
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>Children (2-18 years) with and without obesity</td></tr><tr><td>source_paper:</td><td>McCann_2025</td></tr><tr><td>measured_compound:</td><td>Midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70247-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>midazolam 325.771 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>dropped value-less row: 'CL'</li><li>NIL: refused to back-fill base 'IIV' from footnote/prose loose number None (source ['cts70247-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'V1'</li><li>dropped value-less row: 'V2'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Midazolam</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'estimate' subgroup of McCann_2025 (paper reports 3 populations: estimate, unknown, with obesity)</li><li>gap-filled Q49 (kabs) from le_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_McCann2025_estimate;
