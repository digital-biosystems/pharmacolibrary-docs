function p = Midazolam_Neupane2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Neupane_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Neupane2022_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.82;                % central volume [L]
  p.CL = 29.4;                % clearance [L/h]
  p.Vp = [9.89];             % peripheral volumes [L]
  p.Q  = [13.7];             % inter-compartmental clearances [L/h]
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.75;             % dose [mg]
end
