// parent + metabolites (1-hydroxymidazolam): PK_3M_9C — formed from central; parent 1, metabolites [2]
model Midazolam_Kim2026_final_on_ecmo_support_final_model_estimate
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0367,
    q12 = 8.611111111111112e-07,
    q21 = 8.611111111111112e-07,
    q1_m11 = 9.055555555555556e-07,
    CL1 = 0.0,
    Vd1m1 = 0.00642,
    CLm1 = 1.3805555555555556e-05,
    Vd2m1 = 0.127,
    qm11_m12 = 1.2305555555555556e-07,
    qm12_m11 = 1.2305555555555556e-07,
    MW = 0.32577100000000003,
    MW_m1 = 0.34176999999999996,
    F = 0.9,
    ka = 0.0017777777777777779,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>adult patients receiving venoarterial ECMO</td></tr><tr><td>source_paper:</td><td>Kim_2026</td></tr><tr><td>measured_compound:</td><td>Midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; parent clearance = Σ formation clearances (no other elimination route); formation of 1-hydroxymidazolam: CLfm; dose 15 mg (WHO ATC DDD 15 mg oral (N05CD08))</td></tr><tr><td>molar_masses:</td><td>1-hydroxymidazolam 341.77 g/mol (pubchem); Midazolam 325.771 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ2 Parent' routed out of structural estimates ('Residual variability†')</li><li>table section residual_error: 'σ2 Metabolite' routed out of structural estimates ('Residual variability†')</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'on ecmo support / final model estimate(rse or cv %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Kim2026_final_on_ecmo_support_final_model_estimate;
