// parent + metabolites (1-hydroxymidazolam): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Midazolam_Xie2025_final
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.016,
    q1_m11 = 3.766666666666667e-06,
    CL1 = 2.5111111111111114e-06,
    Vd1m1 = 0.0862,
    CLm1 = 1.8638888888888886e-05,
    MW = 0.32577100000000003,
    MW_m1 = 0.34176999999999996,
    F = 1,
    adminMass = 0,
    infusionMass = 3e-06,
    infusionDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>mechanically ventilated ICU patients</td></tr><tr><td>source_paper:</td><td>Xie_2025</td></tr><tr><td>measured_compound:</td><td>Midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_3M_9C: IV / parenteral into the parent central compartment; formation of 1-hydroxymidazolam: fm=0.6 × CL; dose 3 mg (paper)</td></tr><tr><td>molar_masses:</td><td>1-hydroxymidazolam 341.77 g/mol (paper); Midazolam 325.771 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLMDZ (CV%)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'CL1-OH-MDZ (CV%)' routed out of structural estimates ('IIV')</li><li>table representations disagree for 'CLMDZ (L/h)'; source reconciliation required</li><li>table representations disagree for 'VMDZ (L)'; source reconciliation required</li><li>table representations disagree for 'CL1-OH-MDZ (L/h)'; source reconciliation required</li><li>table representations disagree for 'V1-OH-MDZ (L)'; source reconciliation required</li><li>table representations disagree for 'FMET'; source reconciliation required</li><li>table representations disagree for 'AST on CLMDZ'; source reconciliation required</li><li>table representations disagree for 'rs2461817 on CLMDZ'; source reconciliation required</li><li>table representations disagree for 'BW on CL1-OH-MDZ'; source reconciliation required</li><li>table representations disagree for 'Proportional (CV%)'; source reconciliation required</li><li>table representations disagree for 'Additive (ng/mL)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'AST on CLMDZ' — extend the ontology if this is a real PK parameter (source ['t0002:row10:col3'])</li><li>dropped 'rs2461817 on CLMDZ' → Q22 = -0.405: a clearance of -0.405 is not a parameter value (source ['t0002:row11:col3'])</li><li>dropped unlinked row (NIL): 'BW on CL1-OH-MDZ' — extend the ontology if this is a real PK parameter (source ['t0002:row12:col3'])</li><li>dropped unlinked row (NIL): 'Proportional (CV%)' — extend the ontology if this is a real PK parameter (source ['t0002:row18:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Xie2025_final;
