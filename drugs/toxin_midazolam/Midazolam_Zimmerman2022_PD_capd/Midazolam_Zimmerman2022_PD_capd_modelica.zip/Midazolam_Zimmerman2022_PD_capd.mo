model Midazolam_Zimmerman2022_PD_capd
  "linear exposure-response sweep — Zimmerman_2022 :: CAPD (Cornell Assessment of Pediatric Delirium (CAPD) score)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1.78,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Midazolam_Zimmerman2022_PD_capd</h4><p>The steady-state exposure-response curve of Zimmerman KO et al., <i>Journal of pediatric intensive care 11(4):300–307</i> 2022 (<a href=\"https://doi.org/10.1055/s-0041-1725148\">doi:10.1055/s-0041-1725148</a>) — Cornell Assessment of Pediatric Delirium (CAPD) score against midazolam — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       1.78          change in response per unit of exposure (coefficient (concentration), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of midazolam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Midazolam_Zimmerman2022_PD_capd;
