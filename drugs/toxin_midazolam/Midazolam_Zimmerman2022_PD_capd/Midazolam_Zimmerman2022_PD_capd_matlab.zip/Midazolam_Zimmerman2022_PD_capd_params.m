function p = Midazolam_Zimmerman2022_PD_capd_params()
% Midazolam_Zimmerman2022_PD_capd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Zimmerman_2022::CAPD: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response CAPD in its own unit. Driver: midazolam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.78;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
