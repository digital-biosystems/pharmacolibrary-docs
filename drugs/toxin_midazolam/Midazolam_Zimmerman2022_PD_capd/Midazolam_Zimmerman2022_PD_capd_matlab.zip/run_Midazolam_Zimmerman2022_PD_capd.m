% run_Midazolam_Zimmerman2022_PD_capd  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Midazolam_Zimmerman2022_PD_capd_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [SI]'); ylabel('response []'); title('Midazolam_Zimmerman2022_PD_capd', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Midazolam_Zimmerman2022_PD_capd.csv');
