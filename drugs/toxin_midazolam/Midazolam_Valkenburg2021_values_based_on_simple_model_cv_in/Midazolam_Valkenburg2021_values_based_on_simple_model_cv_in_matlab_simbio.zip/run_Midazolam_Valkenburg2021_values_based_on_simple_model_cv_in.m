% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Midazolam_Valkenburg2021_values_based_on_simple_model_cv_in_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
