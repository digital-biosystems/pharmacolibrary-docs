function p = Midazolam_Valkenburg2021_values_based_on_simple_model_cv_in_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Valkenburg_2021 / values_based_on_simple_model_cv_in   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Valkenburg2021_values_based_on_simple_model_cv_in_params';
  p.drug  = 'midazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.55;                % central volume [L]
  p.CL = 0.516;                % clearance [L/h]
  p.Vp = [12.9];             % peripheral volumes [L]
  p.Q  = [4.2];             % inter-compartmental clearances [L/h]
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.5;             % dose [mg]
end
