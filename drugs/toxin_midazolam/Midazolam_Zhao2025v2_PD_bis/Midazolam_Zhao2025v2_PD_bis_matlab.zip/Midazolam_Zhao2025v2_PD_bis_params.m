function p = Midazolam_Zhao2025v2_PD_bis_params()
% Midazolam_Zhao2025v2_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Zhao_2025_2::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: midazolam (pk_record).
p.E0 = 0.0;
p.Emax = -100.0;
p.EC50 = 6.41e-06;
p.gamma = 0.27;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 65.0;
p.form = 'E0 + Emax*frac';
end
