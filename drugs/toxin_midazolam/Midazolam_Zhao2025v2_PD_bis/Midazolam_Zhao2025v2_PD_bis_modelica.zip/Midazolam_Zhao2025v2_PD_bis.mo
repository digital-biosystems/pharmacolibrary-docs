model Midazolam_Zhao2025v2_PD_bis
  "sigmoid_emax exposure-response sweep — Zhao_2025_2 :: BIS (Bispectral Index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -100,  // [BIS scale]
    EC50 = 6.41e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.27,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 65, Interval = 0.13),
    Documentation(info = "<html><body><h4>Midazolam_Zhao2025v2_PD_bis</h4><p>The steady-state exposure-response curve of Zhao T et al., <i>Clinical pharmacology in drug development 14(6):415–427</i> 2025 (<a href=\"https://doi.org/10.1002/cpdd.1531\">doi:10.1002/cpdd.1531</a>) — Bispectral Index against midazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 BIS scale maximal effect term (Maximum effect, Q323)
  EC50  =       6.41 ng/mL    exposure at half of the maximal effect term (Half-maximal effective concentration, Q321)
  gamma =       0.27          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.41 ng/mL)  response -50
  exposure -> infinity  response -100</pre></body></html>"));
end Midazolam_Zhao2025v2_PD_bis;
