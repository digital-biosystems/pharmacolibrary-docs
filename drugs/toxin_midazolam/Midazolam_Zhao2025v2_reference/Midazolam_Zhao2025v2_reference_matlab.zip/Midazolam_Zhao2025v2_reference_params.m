function p = Midazolam_Zhao2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Zhao_2025_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Zhao2025v2_reference_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 88.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
