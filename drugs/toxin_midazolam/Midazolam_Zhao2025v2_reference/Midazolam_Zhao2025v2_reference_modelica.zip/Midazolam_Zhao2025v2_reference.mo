model Midazolam_Zhao2025v2_reference
  parameter Real Cl_ref = 2.45e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32577100000000003,
    adminMass = 1.5e-05,
    ka = 0.0017777777777777779,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>neonates, infants, children, adults</td></tr><tr><td>source_paper:</td><td>Zhao_2025_2</td></tr><tr><td>measured_compound:</td><td>Midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1; Table S1; Table S2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>midazolam 325.771 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Solubility' — extend the ontology if this is a real PK parameter (source ['Zhao_2025_2_table_1:row1:col2'])</li><li>dropped unlinked row (NIL): 'ccLogP' — extend the ontology if this is a real PK parameter (source ['Zhao_2025_2_table_1:row2:col2'])</li><li>'fu,p' → Q46: printed without a unit and above 1 — read as a percentage</li><li>covariate effect for Q1 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q66 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Midazolam</li><li>topology: prose indicates saturable/MM/TMDD/time-varying kinetics — manual_model_class</li><li>pharmacogenetic covariate 'theta_q1_cyp3a4' (cyp3a4) — PGx domain</li><li>pharmacogenetic covariate 'theta_q66_cyp3a4' (cyp3a4) — PGx domain</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Bickel_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is MANUAL_MODEL_CLASS (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is MANUAL_MODEL_CLASS (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from le_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bickel_2024, Cavallaro_2026, le_2024 — borrowed values do not complete its disposition core; nonlinear topology)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Zhao2025v2_reference;
