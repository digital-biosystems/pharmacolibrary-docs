model Midazolam_McCann2025_with_obesity
  parameter Real Cl_ref = 3.88888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32577100000000003,
    adminMass = 1.5e-05,
    ka = 0.0017777777777777779,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>Children (2-18 years) with and without obesity</td></tr><tr><td>source_paper:</td><td>McCann_2025</td></tr><tr><td>measured_compound:</td><td>Midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70247-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>midazolam 325.771 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Total Body Weight (kg)' — extend the ontology if this is a real PK parameter (source ['McCann_2025_table_S5:row2:col2', 'McCann_2025_table_S5:row5:col2', 'McCann_2025_table_S5:row9:col2', 'McCann_2025_table_S5:row13:col2'])</li><li>dropped duplicate Q22 ('CL (L/h/70kg)', value '11.40') — already have one for this compound</li><li>dropped value-less row: 'CL'</li><li>NIL: refused to back-fill base 'IIV' from footnote/prose loose number None (source ['cts70247-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'V1'</li><li>dropped value-less row: 'V2'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Midazolam</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'with obesity' subgroup of McCann_2025 (paper reports 3 populations: estimate, unknown, with obesity)</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from le_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Cavallaro_2026, le_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Midazolam_McCann2025_with_obesity;
