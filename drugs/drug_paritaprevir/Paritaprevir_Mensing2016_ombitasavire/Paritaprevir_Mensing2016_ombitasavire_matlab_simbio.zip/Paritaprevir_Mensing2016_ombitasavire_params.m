function p = Paritaprevir_Mensing2016_ombitasavire_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paritaprevir   source: Mensing_2016 / ombitasavire   route: oral
  p.name  = 'Paritaprevir_Mensing2016_ombitasavire_params';
  p.drug  = 'paritaprevir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 164.0;                % central volume [L]
  p.CL = 24.125;                % clearance [L/h]
  p.Vp = [345.0];             % peripheral volumes [L]
  p.Q  = [9.333333];             % inter-compartmental clearances [L/h]
  p.ka = 0.207083;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
