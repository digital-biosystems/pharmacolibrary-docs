% Run (SimBiology): build model + dose, simulate 0..27.0 h, plot.
p = Paritaprevir_Mensing2016_paritaprevira_b_c_d_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 27.0);
