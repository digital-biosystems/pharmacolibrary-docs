function p = Paritaprevir_Mensing2016_paritaprevira_b_c_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paritaprevir   source: Mensing_2016 / paritaprevira_b_c_d   route: oral
  p.name  = 'Paritaprevir_Mensing2016_paritaprevira_b_c_d_params';
  p.drug  = 'paritaprevir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 638.0;                % central volume [L]
  p.CL = 157.083333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.24875;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
