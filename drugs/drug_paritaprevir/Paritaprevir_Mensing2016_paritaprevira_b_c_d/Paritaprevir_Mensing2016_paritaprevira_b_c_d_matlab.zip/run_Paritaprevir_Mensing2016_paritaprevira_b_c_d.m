% Run: build params, simulate 0..27.0 h, plot + save Paritaprevir_Mensing2016_paritaprevira_b_c_d.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Paritaprevir_Mensing2016_paritaprevira_b_c_d.m
here = fileparts(mfilename('fullpath'));
p = Paritaprevir_Mensing2016_paritaprevira_b_c_d_params();
out = simulate_pk(p, 0:0.05:27.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('paritaprevir — Mensing_2016 (oral)');
print(fig, fullfile(here, 'Paritaprevir_Mensing2016_paritaprevira_b_c_d.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Paritaprevir_Mensing2016_paritaprevira_b_c_d.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Paritaprevir_Mensing2016_paritaprevira_b_c_d.json'), 'w');
try
  s.model = 'Paritaprevir_Mensing2016_paritaprevira_b_c_d'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Paritaprevir_Mensing2016_paritaprevira_b_c_d","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Paritaprevir_Mensing2016_paritaprevira_b_c_d.png, Paritaprevir_Mensing2016_paritaprevira_b_c_d.csv, Paritaprevir_Mensing2016_paritaprevira_b_c_d.json\n');
