model Paritaprevir_Mensing2016_paritaprevira_b_c_d
  parameter Real Cl_ref = 4.363425925925926e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.638 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.76589,
    adminMass = 0.0001,
    ka = 6.909722222222221e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paritaprevir</h4><p>Paritaprevir is an antiviral used to treat hepatitis C. It is given orally in tablet form. It is approved for use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q16824572\">Wikidata Q16824572</a>, <a href=\"https://en.wikipedia.org/wiki/Paritaprevir?oldid=1259356335\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paritaprevir</td></tr><tr><td>population:</td><td>patients with HCV genotype 1 infection</td></tr><tr><td>source_paper:</td><td>Mensing_2016</td></tr><tr><td>measured_compound:</td><td>paritaprevir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paritaprevir 765.89 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'paritaprevira,b,c,d' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'paritaprevira,b,c,d' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'paritaprevira,b,c,d' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'paritaprevira,b,c,d' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'paritaprevira,b,c,d' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'paritaprevira,b,c,d' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=paritaprevir</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F, L' is the general volume)</li><li>population split: 'paritaprevira,b,c,d' subgroup of Mensing_2016 (paper reports 2 populations: ombitasavire, paritaprevira,b,c,d)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Paritaprevir_Mensing2016_paritaprevira_b_c_d;
