model Paritaprevir_Mensing2016_reference
  parameter Real Cl_ref = 4.363425925925926e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.638 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.76589,
    adminMass = 2.5e-05,
    ka = 6.909722222222221e-05,
    Tlag = 0.0,
    k12 = 4.063624753279926e-06,
    k21 = 7.514761137949543e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paritaprevir</h4><p>Paritaprevir is an antiviral drug used to treat hepatitis C virus infections. It is an approved medicine and has been included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q16824572\">Wikidata Q16824572</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paritaprevir</td></tr><tr><td>population:</td><td>adults with chronic HCV genotype 1 infection</td></tr><tr><td>source_paper:</td><td>Mensing_2016</td></tr><tr><td>measured_compound:</td><td>paritaprevir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paritaprevir 765.89 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('k a , day -1'=5.97) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F, L/day'=3770) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F, L'=638) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F, L/day'=224) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('Vp/F, L'=345) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=paritaprevir</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Paritaprevir_Mensing2016_reference;
