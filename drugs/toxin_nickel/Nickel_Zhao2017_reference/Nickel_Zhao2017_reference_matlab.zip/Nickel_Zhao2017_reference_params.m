function p = Nickel_Zhao2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nickel   source: Zhao_2017 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Nickel_Zhao2017_reference_params';
  p.drug  = 'nickel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.86;                % central volume [L]
  p.CL = 0.135;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
