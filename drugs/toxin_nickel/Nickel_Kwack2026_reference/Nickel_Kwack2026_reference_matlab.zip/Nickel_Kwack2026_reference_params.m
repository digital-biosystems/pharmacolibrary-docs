function p = Nickel_Kwack2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nickel   source: Kwack_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Nickel_Kwack2026_reference_params';
  p.drug  = 'nickel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.86;                % central volume [L]
  p.CL = 0.135;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.15;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.825;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
