function p = Nickel_van2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nickel   source: van_2026 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Nickel_van2026_reference_params';
  p.drug  = 'nickel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.94;                % central volume [L]
  p.CL = 0.005917;                % clearance [L/h]
  p.Vp = [4.18];             % peripheral volumes [L]
  p.Q  = [0.0105];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
