function p = Camrelizumab_Wang2021_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: camrelizumab   source: Wang_2021 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Camrelizumab_Wang2021_final_params';
  p.drug  = 'camrelizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.07;                % central volume [L]
  p.CL = 0.009625;                % clearance [L/h]
  p.Vp = [2.9];             % peripheral volumes [L]
  p.Q  = [0.01725];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
