model Camrelizumab_Wang2021_base
  parameter Real Cl_ref = 2.800925925925926e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0030800000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-05,
    k12 = 1.4467592592592592e-06,
    k21 = 1.5472286522633747e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About camrelizumab</h4><p>Camrelizumab is a programmed cell death protein 1 inhibitor used to treat cancers. It is currently an investigational drug.</p><p><small><b>Unverified</b> — written by qwen3.8-27b from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>camrelizumab</td></tr><tr><td>population:</td><td>patients with advanced melanoma, relapsed or refractory classical Hodgkin lymphoma, and other solid tumor types</td></tr><tr><td>source_paper:</td><td>Wang_2021</td></tr><tr><td>measured_compound:</td><td>camrelizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL linear (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'V m (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'V 1 (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error (mg/L)' routed out of structural estimates ('Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=camrelizumab</li><li>model-stage split: 'base model / parameter estimates' is the base model of Wang_2021 (paper reports 2 stages: base model / parameter estimates, final model / parameter estimates); same population, different model-building step</li><li>molar mass: none found for 'camrelizumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Camrelizumab_Wang2021_base;
