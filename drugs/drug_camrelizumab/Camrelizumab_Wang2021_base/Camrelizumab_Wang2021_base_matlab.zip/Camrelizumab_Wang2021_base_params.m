function p = Camrelizumab_Wang2021_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: camrelizumab   source: Wang_2021 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Camrelizumab_Wang2021_base_params';
  p.drug  = 'camrelizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.08;                % central volume [L]
  p.CL = 0.010083;                % clearance [L/h]
  p.Vp = [2.88];             % peripheral volumes [L]
  p.Q  = [0.016042];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
