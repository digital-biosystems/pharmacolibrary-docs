model Rifabutin_Kawuma2023_reference
  parameter Real Cl_ref = 2.8611111111111115e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.847,
    adminMass = 0.00015,
    ka = 0.0001388888888888889,
    Tlag = 738.0,
    k12 = 1.4097744360902254e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifabutin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kawuma_2023</td></tr><tr><td>measured_compound:</td><td>rifabutin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>rifabutin 847 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kawuma_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Rifabutin_Kawuma2023_reference;
