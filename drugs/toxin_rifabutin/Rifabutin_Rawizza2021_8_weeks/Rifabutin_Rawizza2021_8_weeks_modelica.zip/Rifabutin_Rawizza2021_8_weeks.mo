// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Rifabutin_Rawizza2021_8_weeks
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {162000.0},
    MM = 0.847,
    adminMass = 0.000175,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifabutin</td></tr><tr><td>population:</td><td>TB/HIV-coinfected children</td></tr><tr><td>source_paper:</td><td>Rawizza_2021</td></tr><tr><td>measured_compound:</td><td>Rifabutin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>dkaa512-T4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Rifabutin 847 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table dkaa512-T4: rows are variants (Median (IQR)a, 2 weeks, 4 weeks, 8 weeks), the parameters are the column headers (C max (μg/mL), T max (h)) — read one record per variant</li><li>salvaged Q57 ('rifabutin half-life'=45) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Rifabutin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: '8 weeks' is one of 4 estimates of Rawizza_2021's substance matrix (Median (IQR)a, 2 weeks, 4 weeks, 8 weeks); same population, different estimation method</li><li>row roles (LLM): model_class=noncompartmental; 6/6 row label(s) assigned, 0 linked by role; re-tagged Rifabutin→parent ×24</li><li>molar mass: no plausible PubChem entry for '25-hydroxy-desacetyl rifabutin' ('25-hydroxy-desacetyl rifabutin') — left in mass units</li><li>molar mass: none found for '25-hydroxy-desacetyl rifabutin' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Semere_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Kawuma_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1728.0));
end Rifabutin_Rawizza2021_8_weeks;
