model Rifabutin_Chang2023_PD_log10_cfu_lung
  "linear exposure-response sweep — Chang_2023 :: log10 CFU/lung (Mycobacterium tuberculosis bacterial load)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 4.46,      // [log 10 CFU/lung]
    slope = -1.4880952381e-07,  // [1 / second; wk^-1 × 1.65344e-06]
    exposure_per_s = 1);   // 1 mg/mL per second
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Rifabutin_Chang2023_PD_log10_cfu_lung</h4><p>The steady-state exposure-response curve of Chang YS et al., <i>bioRxiv : the preprint server for biology</i> 2023 (<a href=\"https://doi.org/10.1101/2023.04.12.536604\">doi:10.1101/2023.04.12.536604</a>) — Mycobacterium tuberculosis bacterial load [log 10 CFU/lung] against rifabutin mg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       4.46 log 10 CFU/lung drug-free response (baseline) (RFB 0.75 mg/kg BID Initial log10 CFU/lung, Q324)
  slope =      -0.09 wk^-1    change in response per unit of exposure (RFB 0.75 mg/kg BID k_net, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/mL of rifabutin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.46   (drug-free)</pre></body></html>"));
end Rifabutin_Chang2023_PD_log10_cfu_lung;
