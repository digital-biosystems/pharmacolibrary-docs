function p = Rifabutin_Chang2023_PD_log10_cfu_lung_params()
% Rifabutin_Chang2023_PD_log10_cfu_lung_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifabutin Chang_2023::log10_CFU_lung: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/mL per second, in SI inside (kg/m3, s). Response log10 CFU/lung in log 10 CFU/lung. Driver: rifabutin (cited_pk).
p.E0 = 4.46;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -1.488095238095238e-07;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
