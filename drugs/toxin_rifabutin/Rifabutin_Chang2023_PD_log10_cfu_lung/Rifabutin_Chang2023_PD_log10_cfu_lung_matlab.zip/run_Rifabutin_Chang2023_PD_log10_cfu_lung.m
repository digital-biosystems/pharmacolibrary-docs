% run_Rifabutin_Chang2023_PD_log10_cfu_lung  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Rifabutin_Chang2023_PD_log10_cfu_lung_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/mL]'); ylabel('response [log 10 CFU/lung]'); title('Rifabutin_Chang2023_PD_log10_cfu_lung', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Rifabutin_Chang2023_PD_log10_cfu_lung.csv');
