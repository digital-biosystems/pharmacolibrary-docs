function p = Rifabutin_Semere2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifabutin   source: Semere_2024 / reference   route: oral
  p.name  = 'Rifabutin_Semere2024_reference_params';
  p.drug  = 'rifabutin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 185.0;                % central volume [L]
  p.CL = 1.03;                % clearance [L/h]
  p.Vp = [232.0];             % peripheral volumes [L]
  p.Q  = [25.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.27;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
