function p = Amikacin_Alqahtani2018_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amikacin   source: Alqahtani_2018 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amikacin_Alqahtani2018_final_params';
  p.drug  = 'amikacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.5;                % central volume [L]
  p.CL = 1.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1610.0;             % dose [mg]
end
