model Amikacin_Alqahtani2018_final
  parameter Real Cl_ref = 3.333333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006500000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856024999999999,
    adminMass = 0.00161
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amikacin</h4><p>Amikacin is an aminoglycoside antibiotic used to treat serious bacterial infections, including gram-negative and Pseudomonas infections, sepsis, meningitis, endocarditis, and mycobacterial infections. It is widely used and appears on the WHO essential medicines list, with authorised products in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408529\">Wikidata Q408529</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amikacin</td></tr><tr><td>population:</td><td>non-critical pediatric patients with suspected or proven Gram-negative infection</td></tr><tr><td>source_paper:</td><td>Alqahtani_2018</td></tr><tr><td>measured_compound:</td><td>amikacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amikacin 585.602 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amikacin</li><li>model-stage split: 'final model estimate' is the final model of Alqahtani_2018 (paper reports 2 stages: base model estimate, final model estimate); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amikacin_Alqahtani2018_final;
