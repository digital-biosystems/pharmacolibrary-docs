model Amikacin_Alhadab2018_reference
  parameter Real Cl_ref = 3.0833333333333336e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0302 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856024999999999,
    adminMass = 0.00105,
    k12 = 3.918322295805739e-05,
    k21 = 7.941834451901566e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amikacin</h4><p>Amikacin is an aminoglycoside antibiotic used to treat serious bacterial infections, including gram-negative and Pseudomonas infections, sepsis, meningitis, endocarditis, and mycobacterial infections. It is widely used and appears on the WHO essential medicines list, with authorised products in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408529\">Wikidata Q408529</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amikacin</td></tr><tr><td>population:</td><td>pediatric cancer patients</td></tr><tr><td>source_paper:</td><td>Alhadab_2018</td></tr><tr><td>measured_compound:</td><td>amikacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amikacin 585.602 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'RE (% CV)' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amikacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amikacin_Alhadab2018_reference;
