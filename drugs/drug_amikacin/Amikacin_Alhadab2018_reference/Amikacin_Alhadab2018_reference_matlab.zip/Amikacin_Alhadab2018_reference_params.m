function p = Amikacin_Alhadab2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amikacin   source: Alhadab_2018 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amikacin_Alhadab2018_reference_params';
  p.drug  = 'amikacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 30.2;                % central volume [L]
  p.CL = 11.1;                % clearance [L/h]
  p.Vp = [14.9];             % peripheral volumes [L]
  p.Q  = [4.26];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
