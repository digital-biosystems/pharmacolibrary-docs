model Amikacin_Srivastava2016_PD_cfu_ml_2
  "sigmoid_emax exposure-response sweep — Srivastava_2016 :: CFU/ml (M. tuberculosis bacterial CFU per ml)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 4.87,  // [log 10 CFU/ml]
    EC50 = 0.58,  // [times the MIC]
    gamma = 5.88,
    exposure_per_s = 1);   // 1 times the MIC per second
  // exposure_unit_unresolved: 'times the MIC' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 5.8, Interval = 0.0116),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amikacin</h4><p>Amikacin is an aminoglycoside antibiotic used to treat serious bacterial infections, including gram-negative and Pseudomonas infections, sepsis, meningitis, endocarditis, and mycobacterial infections. It is widely used and appears on the WHO essential medicines list, with authorised products in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408529\">Wikidata Q408529</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Amikacin_Srivastava2016_PD_cfu_ml_2</h4><p>The steady-state exposure-response curve of Srivastava S et al., <i>Antimicrobial agents and chemotherapy 60(10):5922–5927</i> 2016 (<a href=\"https://doi.org/10.1128/AAC.00961-16\">doi:10.1128/AAC.00961-16</a>) — M. tuberculosis bacterial CFU per ml [log 10 CFU/ml] against amikacin times the MIC — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.87 log 10 CFU/ml maximal effect term (E max, Q320)
  EC50  =       0.58 times the MIC exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       5.88          Hill coefficient (H, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one times the MIC of amikacin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.58 times the MIC)  response 2.435
  exposure -> infinity  response 4.87</pre></body></html>"));
end Amikacin_Srivastava2016_PD_cfu_ml_2;
