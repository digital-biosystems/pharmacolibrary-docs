function p = Amikacin_Srivastava2016_PD_cfu_ml_2_params()
% Amikacin_Srivastava2016_PD_cfu_ml_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amikacin Srivastava_2016::CFU_ml::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one times the MIC per second, in SI inside (kg/m3, s). Response CFU/ml in log 10 CFU/ml. Driver: amikacin (cited_pk).
p.E0 = 0.0;
p.Emax = 4.87;
p.EC50 = 0.58;
p.gamma = 5.88;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 5.8;
p.form = 'E0 + Emax*frac';
end
