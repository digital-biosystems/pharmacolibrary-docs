model Amikacin_Illamola2018_reference
  parameter Real Cl_ref = 7.194444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03339 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856024999999999,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amikacin</h4><p>Amikacin is an aminoglycoside antibiotic used to treat serious bacterial infections, including gram-negative and Pseudomonas infections, sepsis, meningitis, endocarditis, and mycobacterial infections. It is widely used and appears on the WHO essential medicines list, with authorised products in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408529\">Wikidata Q408529</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amikacin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Illamola_2018</td></tr><tr><td>measured_compound:</td><td>amikacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amikacin 585.602 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Illamola_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Amikacin_Illamola2018_reference;
