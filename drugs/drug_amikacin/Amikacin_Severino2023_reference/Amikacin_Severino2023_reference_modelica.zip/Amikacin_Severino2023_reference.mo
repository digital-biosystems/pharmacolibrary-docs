model Amikacin_Severino2023_reference
  parameter Real Cl_ref = 4.972222222222223e-07 "Cl [m3/s]";
  parameter Real cov_creatinine = 70.0 "creatinine covariate (reference 70.0)";
  parameter Real Vd_ref = 0.0251 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_creatinine/70.0)^(0.21),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856024999999999,
    adminMass = 0.00105,
    k12 = 2.0252324037184595e-05,
    k21 = 1.517412935323383e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amikacin</h4><p>Amikacin is an aminoglycoside antibiotic used to treat serious bacterial infections like sepsis, meningitis, and resistant tuberculosis. Blood levels are routinely measured to guide dosing. It is listed on the WHO Essential Medicines list and has authorized products in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q408529\">Wikidata Q408529</a>, <a href=\"https://en.wikipedia.org/wiki/Amikacin?oldid=1335943276\">Wikipedia</a> (CC BY-SA 4.0), the WHO ATC classification, the EMA medicines list and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amikacin</td></tr><tr><td>population:</td><td>newborns with suspected sepsis</td></tr><tr><td>source_paper:</td><td>Severino_2023</td></tr><tr><td>measured_compound:</td><td>amikacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amikacin 585.602 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L per 70 kg' (V1)</li><li>unit_dimension_unknown: 'L per 70 kg' (V2)</li><li>dropped duplicate Q22 ('PMA CL', value '2.61') — already have one for this compound</li><li>dropped duplicate Q22 ('Shock CL', value '0.76') — already have one for this compound</li><li>dropped duplicate Q22 ('Sepsis CL', value '1.33') — already have one for this compound</li><li>implicit units: 'Central volume of distribution, (L per 70 kg)' → L (from the paper text: &quot;The paper states 'Estimated parameters for a typical subject (2.8 kg, 38.3 weeks) were ... volume of distribution of the&quot;)</li><li>implicit units: 'Peripheral volume of distribution, (L per 70 kg)' → L (from the paper text: &quot;The paper states 'Estimated parameters for a typical subject (2.8 kg, 38.3 weeks) were ... peripheral volume of distribu&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amikacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Amikacin_Severino2023_reference;
