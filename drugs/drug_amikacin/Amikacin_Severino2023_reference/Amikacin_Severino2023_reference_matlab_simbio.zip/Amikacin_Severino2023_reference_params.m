function p = Amikacin_Severino2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amikacin   source: Severino_2023 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Amikacin_Severino2023_reference_params';
  p.drug  = 'amikacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.1;                % central volume [L]
  p.CL = 1.79;                % clearance [L/h]
  p.Vp = [33.5];             % peripheral volumes [L]
  p.Q  = [1.83];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
