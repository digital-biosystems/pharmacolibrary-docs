function p = Amikacin_Srivastava2016_PD_cfu_ml_4_params()
% Amikacin_Srivastava2016_PD_cfu_ml_4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amikacin Srivastava_2016::CFU_ml::4: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one times the MIC per second, in SI inside (kg/m3, s). Response CFU/ml in log 10 CFU/ml. Driver: amikacin (cited_pk).
p.E0 = 0.0;
p.Emax = 2.92;
p.EC50 = 1.68;
p.gamma = 2.7;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 17.0;
p.form = 'E0 + Emax*frac';
end
