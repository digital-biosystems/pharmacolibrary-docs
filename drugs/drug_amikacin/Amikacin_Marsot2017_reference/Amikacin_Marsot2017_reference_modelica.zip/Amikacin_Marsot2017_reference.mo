model Amikacin_Marsot2017_reference
  parameter Real Cl_ref = 1.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.018600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amikacin</td></tr><tr><td>population:</td><td>critically ill patients</td></tr><tr><td>source_paper:</td><td>Marsot_2017</td></tr><tr><td>measured_compound:</td><td>amikacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '[19]' — extend the ontology if this is a real PK parameter (source ['tab_2:row4:col4', 'tab_2:row4:col5', 'tab_2:row4:col7'])</li><li>dropped unlinked row (NIL): '[20]' — extend the ontology if this is a real PK parameter (source ['tab_2:row7:col4'])</li><li>dropped unlinked row (NIL): '[21]' — extend the ontology if this is a real PK parameter (source ['tab_2:row9:col4'])</li><li>dropped unlinked row (NIL): '[22]' — extend the ontology if this is a real PK parameter (source ['tab_2:row21:col4'])</li><li>dropped unlinked row (NIL): '[24]' — extend the ontology if this is a real PK parameter (source ['tab_2:row25:col4', 'tab_2:row25:col5'])</li><li>dropped unlinked row (NIL): '[26]' — extend the ontology if this is a real PK parameter (source ['tab_2:row29:col4'])</li><li>dropped unlinked row (NIL): '[27]' — extend the ontology if this is a real PK parameter (source ['tab_2:row36:col4', 'tab_2:row36:col5'])</li><li>dropped unlinked row (NIL): '[28]' — extend the ontology if this is a real PK parameter (source ['tab_2:row42:col4'])</li><li>dropped value-less row: 'APACHE'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'CL CR'</li><li>dropped value-less row: 'ICU'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amikacin_Marsot2017_reference;
