model Amikacin_MedellnGaribay2022_reference
  parameter Real Cl_ref = 7.638888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0174 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856024999999999,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amikacin</h4><p>Amikacin is an aminoglycoside antibiotic used to treat serious bacterial infections, including gram-negative and Pseudomonas infections, sepsis, meningitis, endocarditis, and mycobacterial infections. It is widely used and appears on the WHO essential medicines list, with authorised products in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408529\">Wikidata Q408529</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amikacin</td></tr><tr><td>population:</td><td>elderly patients with severe infections</td></tr><tr><td>source_paper:</td><td>Medellín-Garibay_2022</td></tr><tr><td>measured_compound:</td><td>amikacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amikacin 585.602 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/80 mL/min' (CL)</li><li>unit_dimension_unknown: 'L/25 kg/m2' (V1)</li><li>implicit units: 'drug clearance' → L/h (from the popPK convention: 'Clearance is conventionally expressed in L/h in population PK; 2.75 is consistent with that unit.')</li><li>implicit units: 'central volume of distribution' → L (from the popPK convention: 'A compartment volume is conventionally expressed in L in population PK; 17.4 is consistent with that unit.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amikacin</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amikacin_MedellnGaribay2022_reference;
