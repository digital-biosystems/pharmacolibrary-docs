model Clonazepam_Kruizinga2022_parameter
  parameter Real Cl_ref = 8.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1095 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.00015568239472349063,
    k21 = 0.00013053003232941978
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonazepam</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Kruizinga_2022</td></tr><tr><td>measured_compound:</td><td>clonazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp15152-tbl-0002</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'θ Prob. slow group' — extend the ontology if this is a real PK parameter (source ['bcp15152-tbl-0002:row2:col1'])</li><li>kept covariate coefficient θ RatioMAX=0.195 (covariate RatioMAX) — not an ontology parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clonazepam</li><li>population split: 'parameter' subgroup of Kruizinga_2022 (paper reports 2 populations: estimate (shrinkage %), parameter)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clonazepam_Kruizinga2022_parameter;
