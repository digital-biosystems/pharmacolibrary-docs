function p = Clonazepam_Kruizinga2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clonazepam   source: Kruizinga_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Clonazepam_Kruizinga2022_reference_params';
  p.drug  = 'clonazepam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.5;                % central volume [L]
  p.CL = 0.16;                % clearance [L/h]
  p.Vp = [12.9];             % peripheral volumes [L]
  p.Q  = [11.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
