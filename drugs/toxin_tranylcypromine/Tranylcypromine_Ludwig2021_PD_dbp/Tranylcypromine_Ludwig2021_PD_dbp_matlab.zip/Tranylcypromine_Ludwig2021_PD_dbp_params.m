function p = Tranylcypromine_Ludwig2021_PD_dbp_params()
% Tranylcypromine_Ludwig2021_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tranylcypromine Ludwig_2021::DBP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one dose per second, in SI inside (kg/m3, s). Response ΔDBP in mmHg. Driver: tranylcypromine (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.21;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
