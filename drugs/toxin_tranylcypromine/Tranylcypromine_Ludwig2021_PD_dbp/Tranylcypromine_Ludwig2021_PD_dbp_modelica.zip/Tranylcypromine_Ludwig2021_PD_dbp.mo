model Tranylcypromine_Ludwig2021_PD_dbp
  "linear exposure-response sweep — Ludwig_2021 :: ΔDBP (diastolic blood pressure change)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.21,  // [1]
    exposure_per_s = 1);   // 1 dose per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Tranylcypromine_Ludwig2021_PD_dbp</h4><p>The steady-state exposure-response curve of Ludwig VM et al., <i>CNS drugs 35(8):881–892</i> 2021 (<a href=\"https://doi.org/10.1007/s40263-021-00837-6\">doi:10.1007/s40263-021-00837-6</a>) — diastolic blood pressure change [mmHg] against tranylcypromine dose — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.21          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one dose of tranylcypromine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Tranylcypromine_Ludwig2021_PD_dbp;
