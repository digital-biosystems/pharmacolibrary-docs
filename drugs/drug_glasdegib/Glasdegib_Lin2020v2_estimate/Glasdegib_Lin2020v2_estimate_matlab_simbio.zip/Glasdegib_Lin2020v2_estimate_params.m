function p = Glasdegib_Lin2020v2_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glasdegib   source: Lin_2020_2 / estimate   route: oral
  p.name  = 'Glasdegib_Lin2020v2_estimate_params';
  p.drug  = 'glasdegib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.52;                % central volume [L]
  p.CL = 6.23;                % clearance [L/h]
  p.Vp = [296.04];             % peripheral volumes [L]
  p.Q  = [1.58];             % inter-compartmental clearances [L/h]
  p.ka = 0.06;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
