model Entacapone_Heikkinen2001_reference
  parameter Real Cl_ref = 1.3649999999999996e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005600000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.305286,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About entacapone</h4><p>Entacapone is a COMT inhibitor used to treat Parkinson's disease. It is administered orally as a tablet and is well absorbed by mouth. It is widely used in combination with other medications and is authorised in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q416444\">Wikidata Q416444</a>, <a href=\"https://en.wikipedia.org/wiki/Entacapone?oldid=1368193947\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>entacapone</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Heikkinen_2001</td></tr><tr><td>measured_compound:</td><td>entacapone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>entacapone 305.286 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'The terminal elimination phase accounted for only 9% of the total area under the plasma concentration-time curve (AUC), which was' — extend the ontology if this is a real PK parameter (source ['Heikkinen_2001:abstract'])</li><li>unit_dimension_unknown: '% of the i.v.' (fe)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=entacapone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'The volume of the central compartment (Vc)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Entacapone_Heikkinen2001_reference;
