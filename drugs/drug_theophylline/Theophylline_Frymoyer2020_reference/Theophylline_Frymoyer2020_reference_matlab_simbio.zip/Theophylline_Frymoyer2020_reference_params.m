function p = Theophylline_Frymoyer2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: theophylline   source: Frymoyer_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Theophylline_Frymoyer2020_reference_params';
  p.drug  = 'theophylline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.7;                % central volume [L]
  p.CL = 0.049;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 34.8;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 126.0;             % dose [mg]
end
