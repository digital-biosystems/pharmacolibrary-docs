model Chloroxylenol_Dorantes1992_reference
  parameter Real Cl_ref = 4.055555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0224 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.15661000000000003,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About chloroxylenol</h4><p>Chloroxylenol is a phenol derivative used as an antiseptic and local anti-infective. It is given topically in various forms such as liquids, soaps, and lotions. The drug is listed as a WHO essential medicine.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q426460\">Wikidata Q426460</a>, <a href=\"https://en.wikipedia.org/wiki/Chloroxylenol?oldid=1385044768\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroxylenol</td></tr><tr><td>population:</td><td>healthy mongrel dogs</td></tr><tr><td>source_paper:</td><td>Dorantes_1992</td></tr><tr><td>measured_compound:</td><td>chloroxylenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>chloroxylenol 156.61 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=chloroxylenol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Chloroxylenol_Dorantes1992_reference;
