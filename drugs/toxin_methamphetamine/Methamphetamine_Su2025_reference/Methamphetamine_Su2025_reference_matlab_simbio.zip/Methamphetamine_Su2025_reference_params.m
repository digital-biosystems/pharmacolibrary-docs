function p = Methamphetamine_Su2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methamphetamine   source: Su_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Methamphetamine_Su2025_reference_params';
  p.drug  = 'methamphetamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 168.0;                % central volume [L]
  p.CL = 198.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
