model Methamphetamine_Cook1993_reference
  parameter Real Cl_ref = 1.611111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2611 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.149237,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methamphetamine</td></tr><tr><td>population:</td><td>Male human volunteers</td></tr><tr><td>source_paper:</td><td>Cook_1993</td></tr><tr><td>measured_compound:</td><td>Methamphetamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Amphetamine 135.21 g/mol (pubchem); Methamphetamine 149.237 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'for the intravenous drug.' — extend the ontology if this is a real PK parameter (source ['Cook_1993:abstract'])</li><li>dropped unlinked row (NIL): 'respectively,' — extend the ontology if this is a real PK parameter (source ['Cook_1993:abstract'])</li><li>dropped value-less row: 'were excreted in urine as methamphetamine and lesser amounts'</li><li>dropped unlinked row (NIL): 'as amphetamine.' — extend the ontology if this is a real PK parameter (source ['Cook_1993:abstract'])</li><li>implicit units: 'Metabolic clearance represented' → L/h (from the popPK convention: 'The parameter is total clearance (CL). In population pharmacokinetics, unless body weight scaling is explicitly indicate')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methamphetamine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles: 2 per-group rows of S-(+)-methamphetamine hydrochloride summary_statistic but 0 reference group(s) — kept as printed</li><li>row roles: 2 per-group rows of Methamphetamine summary_statistic but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=noncompartmental; 8/8 row label(s) assigned, 0 linked by role; re-tagged Methamphetamine→parent ×3, Methamphetamine→Amphetamine ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Methamphetamine_Cook1993_reference;
