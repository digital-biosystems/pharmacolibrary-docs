model AmphotericinB_Stott2022_reference
  parameter Real Cl_ref = 1.1555555555555555e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004566 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.924079,
    adminMass = 3.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amphotericin_b</h4><p>Amphotericin B is an antifungal antibiotic used to treat serious fungal infections such as aspergillosis, candidiasis, cryptococcosis, histoplasmosis, and blastomycosis, as well as visceral leishmaniasis. It is widely used and appears on the WHO list of essential medicines, given systemically and also locally in oral, intestinal, and gynecological preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412223\">Wikidata Q412223</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amphotericin_b</td></tr><tr><td>population:</td><td>adults with HIV-associated cryptococcal meningoencephalitis</td></tr><tr><td>source_paper:</td><td>Stott_2022</td></tr><tr><td>measured_compound:</td><td>liposomal amphotericin B</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>amphotericin_b 924.079 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q302 ('from peripheral to central compartment', value 2.951) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=liposomal amphotericin B</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end AmphotericinB_Stott2022_reference;
