function p = Vortioxetine_Wilson2015_PD_trem_params()
% Vortioxetine_Wilson2015_PD_trem_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vortioxetine Wilson_2015::TREM: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TREM in min. Driver: vortioxetine (cited_pk).
p.E0 = -540.0;
p.Emax = -8940.0;
p.EC50 = 3.6e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 360.0;
p.form = 'E0 + Emax*frac';
end
