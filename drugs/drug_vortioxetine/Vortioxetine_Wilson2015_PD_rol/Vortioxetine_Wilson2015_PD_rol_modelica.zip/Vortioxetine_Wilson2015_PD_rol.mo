model Vortioxetine_Wilson2015_PD_rol
  "sigmoid_emax exposure-response sweep — Wilson_2015 :: ROL (REM onset latency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 144,      // [s; min × 60]
    Emax = 15000,  // [s; min × 60]
    EC50 = 2.1e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.5,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  annotation(experiment(StartTime = 0, StopTime = 210, Interval = 0.42),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vortioxetine</h4><p>Vortioxetine is an antidepressant used to treat major depressive disorder and, according to some sources, anxiety. It is authorised in the European Union and is used as an approved medicine, though it also remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3563148\">Wikidata Q3563148</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Vortioxetine_Wilson2015_PD_rol</h4><p>The steady-state exposure-response curve of Wilson S et al., <i>Journal of psychopharmacology (Oxford, England) 29(10):1085–1091</i> 2015 (<a href=\"https://doi.org/10.1177/0269881115599387\">doi:10.1177/0269881115599387</a>) — REM onset latency [min] against vortioxetine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.4 min      drug-free response (baseline) (E0, Q324)
  Emax  =        250 min      maximal effect term (Emax, Q320)
  EC50  =         21 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        2.5          Hill coefficient (Γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of vortioxetine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 144   (drug-free)
  exposure = EC50 (21 ng/mL)  response 7644
  exposure -> infinity  response 1.514e+04</pre></body></html>"));
end Vortioxetine_Wilson2015_PD_rol;
