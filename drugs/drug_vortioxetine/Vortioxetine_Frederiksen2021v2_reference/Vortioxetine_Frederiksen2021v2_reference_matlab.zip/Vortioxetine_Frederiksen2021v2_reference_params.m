function p = Vortioxetine_Frederiksen2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vortioxetine   source: Frederiksen_2021_2 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Vortioxetine_Frederiksen2021v2_reference_params';
  p.drug  = 'vortioxetine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1510.0;                % central volume [L]
  p.CL = 22.5;                % clearance [L/h]
  p.Vp = [571.0];             % peripheral volumes [L]
  p.Q  = [21.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
