// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Alprazolam_Yamamoto2019_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {142920.0},
    MM = 0.308769,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alprazolam</td></tr><tr><td>population:</td><td>pregnant woman and neonate (one case, PBPK simulated)</td></tr><tr><td>source_paper:</td><td>Yamamoto_2019</td></tr><tr><td>measured_compound:</td><td>Alprazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>alprazolam 308.769 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q59 ('calculated half-life of alprazolam in the neonate ... in the first 24 h'=39.7) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('calculated half-life of alprazolam in the neonate ... in 24 to 48 h after delivery'=20.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Alprazolam</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Klein_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Klein_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1555.2));
end Alprazolam_Yamamoto2019_reference;
