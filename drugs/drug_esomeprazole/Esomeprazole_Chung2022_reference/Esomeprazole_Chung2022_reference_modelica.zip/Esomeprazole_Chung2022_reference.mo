model Esomeprazole_Chung2022_reference
  parameter Real Cl_ref = 6.138888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.121 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345416,
    adminMass = 3e-05,
    ka = 0.00026388888888888886,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About esomeprazole</h4><p>Esomeprazole is a proton-pump inhibitor used for acid-related stomach problems such as gastroesophageal reflux disease, peptic and duodenal ulcers, gastritis, esophagitis, and heartburn. It is an approved medicine with an authorised product in the European Union and is widely used for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q553223\">Wikidata Q553223</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>esomeprazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chung_2022</td></tr><tr><td>measured_compound:</td><td>esomeprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>esomeprazole 345.416 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chung_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Esomeprazole_Chung2022_reference;
