function p = IsopropylAlcohol_Rada2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: isopropyl_alcohol   source: Rada_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'IsopropylAlcohol_Rada2015_reference_params';
  p.drug  = 'isopropyl_alcohol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 81.4;                % central volume [L]
  p.CL = 35.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
