function p = Indinavir_Kappelhoff2005_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: indinavir   source: Kappelhoff_2005 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Indinavir_Kappelhoff2005_reference_params';
  p.drug  = 'indinavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 96.6;                % central volume [L]
  p.CL = 10.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.871;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.485;             % absorption lag [h]
  p.dose = 2400.0;             % dose [mg]
end
