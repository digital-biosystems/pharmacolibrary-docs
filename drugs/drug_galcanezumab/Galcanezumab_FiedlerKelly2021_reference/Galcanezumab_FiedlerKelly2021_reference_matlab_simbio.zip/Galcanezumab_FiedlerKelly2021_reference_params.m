function p = Galcanezumab_FiedlerKelly2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: galcanezumab   source: Fiedler-Kelly_2021 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Galcanezumab_FiedlerKelly2021_reference_params';
  p.drug  = 'galcanezumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.2;                % central volume [L]
  p.CL = 0.0106;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0192;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.202;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
