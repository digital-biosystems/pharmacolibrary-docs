function p = Anakinra_Ngo2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anakinra   source: Ngo_2020 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Anakinra_Ngo2020_reference_params';
  p.drug  = 'anakinra';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.3;                % central volume [L]
  p.CL = 0.208;                % clearance [L/h]
  p.Vp = [5.06];             % peripheral volumes [L]
  p.Q  = [0.0288];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.312;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
