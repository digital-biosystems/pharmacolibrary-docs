function p = Anakinra_Urien2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anakinra   source: Urien_2013 / reference   route: oral
  p.name  = 'Anakinra_Urien2013_reference_params';
  p.drug  = 'anakinra';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 65.2;                % central volume [L]
  p.CL = 436.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
