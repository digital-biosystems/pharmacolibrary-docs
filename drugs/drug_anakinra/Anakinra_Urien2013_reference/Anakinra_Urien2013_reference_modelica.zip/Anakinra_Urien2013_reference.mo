model Anakinra_Urien2013_reference
  parameter Real Cl_ref = 0.00012133333333333335 "Cl [m3/s]";
  parameter Real cov_tv_cl_bw_70_cl_0 = 0 "TV(CL)∙(BW/70)βCL covariate";
  parameter Real Vd_ref = 0.06520000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.47)*cov_tv_cl_bw_70_cl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00014,
    ka = 0.00010555555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About anakinra</h4><p>Anakinra, an interleukin-1 receptor antagonist, is used to treat rheumatoid arthritis, systemic-onset juvenile idiopathic arthritis, and pericarditis, and has also been used for COVID-19. It is an approved medicine with an authorised product in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415411\">Wikidata Q415411</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>anakinra</td></tr><tr><td>population:</td><td>children and adolescents with systemic-onset juvenile idiopathic arthritis and autoinflammatory syndromes</td></tr><tr><td>source_paper:</td><td>Urien_2013</td></tr><tr><td>measured_compound:</td><td>anakinra</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>'βCL, TV(CL)∙(BW/70)βCL' is a β covariate effect on CL, not Q22 (llm_confirmed link set aside)</li><li>covariate level 'βCL, TV(CL)∙(BW/70)βCL' → Q900:cl_tv_cl_bw_70_cl = 0.47 (linear_fractional on Q27)</li><li>'βV, TV(V)∙(BW/70)βV' is a β covariate effect on V, not Q319 (llm link set aside)</li><li>dropped unlinked row (NIL): 'βV, TV(V)∙(BW/70)βV' — extend the ontology if this is a real PK parameter (source ['T1:row4:col1'])</li><li>dropped duplicate Q27 ('ηCL/F', value '0.28') — already have one for this compound</li><li>routed 'ϵ, mg/L' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=anakinra</li><li>molar mass: none found for 'anakinra' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Anakinra_Urien2013_reference;
