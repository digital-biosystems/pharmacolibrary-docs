// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Pentamidine_Conte1987_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {22391.999999999996},
    MM = 0.34042700000000004,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentamidine</td></tr><tr><td>population:</td><td>patients with AIDS with impaired renal function</td></tr><tr><td>source_paper:</td><td>Conte_1987</td></tr><tr><td>measured_compound:</td><td>Pentamidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>pentamidine 340.427 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'pentamidine elimination half-life (mean +/- SD)' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'plasma clearance (mean +/- SD)' — extend the ontology if this is a real PK parameter (source ['Conte_1987:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pentamidine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Kip_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kip_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 230.4));
end Pentamidine_Conte1987_reference;
