model Pentamidine_Conte1991_reference
  parameter Real Cl_ref = 7.444444444444444e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.015300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34042700000000004,
    adminMass = 0.0001,
    ka = 0.0017416666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentamidine</td></tr><tr><td>population:</td><td>patients with normal renal function or receiving hemodialysis, intravenous pentamidine therapy</td></tr><tr><td>source_paper:</td><td>Conte_1991</td></tr><tr><td>measured_compound:</td><td>Pentamidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pentamidine 340.427 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('elimination half-life after the last dose', value 12.0) — already have one for this compound</li><li>covariate renal for fe from footnote/prose kept as documentation only (['Conte_1991:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pentamidine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Kip_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kip_2018's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Kip_2018 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Pentamidine_Conte1991_reference;
