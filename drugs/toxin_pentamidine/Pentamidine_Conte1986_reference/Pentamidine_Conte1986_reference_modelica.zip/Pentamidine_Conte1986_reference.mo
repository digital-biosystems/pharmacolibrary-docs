model Pentamidine_Conte1986_reference
  parameter Real Cl_ref = 1.9007241062363176e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.924 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34042700000000004,
    adminMass = 0.0001,
    ka = 0.0017416666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentamidine</td></tr><tr><td>population:</td><td>patients with AIDS</td></tr><tr><td>source_paper:</td><td>Conte_1986</td></tr><tr><td>measured_compound:</td><td>pentamidine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pentamidine 340.427 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('plasma clearance (intravenously treated patients)', value 248) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life (intravenously treated patients)', value 6.4) — already have one for this compound</li><li>dropped duplicate Q76 ('apparent volume of distribution (intravenously treated patients)', value 140) — already have one for this compound</li><li>dropped duplicate Q65 ('apparent volume at steady state (intravenously treated patients)', value 821) — already have one for this compound</li><li>unit_dimension_unknown: 'intramuscularly treated patients' (CLR)</li><li>unit_dimension_unknown: 'intravenously treated patients' (CLR)</li><li>dropped duplicate Q26 ('Renal clearance of pentamidine (intravenously treated patients)', value 2.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pentamidine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kip_2018's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q26 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Pentamidine_Conte1986_reference;
