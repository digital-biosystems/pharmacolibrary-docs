% Run (SimBiology): build model + dose, simulate 0..4320.0 h, plot.
p = Terbutaline_Singh2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4320.0);
