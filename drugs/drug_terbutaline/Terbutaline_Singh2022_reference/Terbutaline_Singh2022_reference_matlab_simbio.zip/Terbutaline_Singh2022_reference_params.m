function p = Terbutaline_Singh2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: terbutaline   source: Singh_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Terbutaline_Singh2022_reference_params';
  p.drug  = 'terbutaline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.11;                % central volume [L]
  p.CL = 0.003333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
