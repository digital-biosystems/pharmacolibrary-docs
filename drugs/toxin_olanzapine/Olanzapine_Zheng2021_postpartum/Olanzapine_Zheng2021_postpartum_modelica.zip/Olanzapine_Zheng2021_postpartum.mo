model Olanzapine_Zheng2021_postpartum
  parameter Real Cl_ref = 4.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.106 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31239999999999996,
    adminMass = 1e-05,
    ka = 0.00023916666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>olanzapine</td></tr><tr><td>population:</td><td>pregnant women</td></tr><tr><td>source_paper:</td><td>Zheng_2021</td></tr><tr><td>measured_compound:</td><td>Olanzapine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T5</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>olanzapine 312.4 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'CLss/F' → L/h (from the popPK convention: 'The paper provides text evidence for CLint in L/min (Priority 1), but does not explicitly state the unit for CLss/F. Fol')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Olanzapine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'postpartum' subgroup of Zheng_2021 (paper reports 5 populations: 1st trimester, 2nd trimester, 3rd trimester, postpartum, values/methods)</li><li>gap-filled Q76 (V/F) from Chen_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chen_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Olanzapine_Zheng2021_postpartum;
