model Olanzapine_Perlstein2026_PD_d2ro
  "emax exposure-response sweep — Perlstein_2026 :: D2RO (dopamine D2 receptor occupancy)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 1.1e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><h4>Olanzapine_Perlstein2026_PD_d2ro</h4><p>The steady-state exposure-response curve of Perlstein I et al., <i>Journal of clinical pharmacology 66(1):e70144</i> 2026 (<a href=\"https://doi.org/10.1002/jcph.70144\">doi:10.1002/jcph.70144</a>) — dopamine D2 receptor occupancy [%] against olanzapine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (maximal receptor occupancy, Q320)
  EC50  =         11 ng/mL    exposure at half of the maximal effect term (estimated plasma olanzapine concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of olanzapine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (11 ng/mL)  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Olanzapine_Perlstein2026_PD_d2ro;
