function p = Olanzapine_Perlstein2026_PD_d2ro_params()
% Olanzapine_Perlstein2026_PD_d2ro_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% olanzapine Perlstein_2026::D2RO: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response D2RO in %. Driver: olanzapine (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.1e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 110.0;
p.form = 'E0 + Emax*frac';
end
