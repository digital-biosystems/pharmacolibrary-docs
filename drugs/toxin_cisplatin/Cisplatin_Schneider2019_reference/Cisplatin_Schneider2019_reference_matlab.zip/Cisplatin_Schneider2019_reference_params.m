function p = Cisplatin_Schneider2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cisplatin   source: Schneider_2019 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cisplatin_Schneider2019_reference_params';
  p.drug  = 'cisplatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 12.9;                % central volume [L]
  p.CL = 5.495833;                % clearance [L/h]
  p.Vp = [3.38];             % peripheral volumes [L]
  p.Q  = [0.8625];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
