function p = Cisplatin_MoritaOgawa2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cisplatin   source: Morita-Ogawa_2020 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Cisplatin_MoritaOgawa2020_reference_params';
  p.drug  = 'cisplatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.8;                % central volume [L]
  p.CL = 19.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.48;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
