// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cisplatin_Morrison1986_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5198.6038541995895},
    MM = 0.300042,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisplatin</td></tr><tr><td>population:</td><td>rat brain (data of Kroin and Penn, rat)</td></tr><tr><td>source_paper:</td><td>Morrison_1986</td></tr><tr><td>measured_compound:</td><td>cisplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cisplatin 300.042 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'half-time to steady state' Q72 → Q57: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cisplatin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>amount-only peripheral compartment: a peripheral output rate (kout_peripheral) is present with no reported volume — model its AMOUNT; concentration is not identifiable without an assumed volume</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Cisplatin_Morrison1986_reference;
