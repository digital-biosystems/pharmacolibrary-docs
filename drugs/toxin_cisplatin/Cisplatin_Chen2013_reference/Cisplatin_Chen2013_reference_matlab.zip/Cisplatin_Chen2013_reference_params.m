function p = Cisplatin_Chen2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cisplatin   source: Chen_2013 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Cisplatin_Chen2013_reference_params';
  p.drug  = 'cisplatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.2;                % central volume [L]
  p.CL = 0.463;                % clearance [L/h]
  p.Vp = [32.0];             % peripheral volumes [L]
  p.Q  = [10.2];             % inter-compartmental clearances [L/h]
  p.ka = 9.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.48;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
