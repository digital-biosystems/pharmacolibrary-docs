model Cisplatin_Chen2013_reference
  parameter Real Cl_ref = 1.2861111111111113e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0242 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.300042,
    adminMass = 0.0001,
    ka = 0.0026027777777777776,
    Tlag = 1728.0,
    k12 = 0.00011707988980716253,
    k21 = 8.854166666666666e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisplatin</td></tr><tr><td>population:</td><td>patients with non-small-cell lung carcinoma receiving cisplatin chemotherapy</td></tr><tr><td>source_paper:</td><td>Chen_2013</td></tr><tr><td>measured_compound:</td><td>Cisplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cisplatin 300.042 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q63 ('central distribution volume (V₁), unbound drug', value 20.5) — already have one for this compound</li><li>dropped duplicate Q30 ('intercompartmental clearance (Q), unbound drug', value 9.82) — already have one for this compound</li><li>dropped duplicate Q64 ('peripheral compartment volume (V₂), unbound drug', value 6.77) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cisplatin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Fountzilas_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Fountzilas_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Cisplatin_Chen2013_reference;
