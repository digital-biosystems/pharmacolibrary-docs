model PotassiumChloride_Adachi2021_reference
  parameter Real Cl_ref = 7.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.074548,
    adminMass = 0.003,
    ka = 0.0013722222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>potassium_chloride</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Adachi_2021</td></tr><tr><td>measured_compound:</td><td>potassium_chloride</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>potassium_chloride 74.548 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Adachi_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end PotassiumChloride_Adachi2021_reference;
