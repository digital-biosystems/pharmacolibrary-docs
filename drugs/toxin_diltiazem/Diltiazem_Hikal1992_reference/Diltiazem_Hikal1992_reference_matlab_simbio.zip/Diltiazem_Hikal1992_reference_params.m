function p = Diltiazem_Hikal1992_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diltiazem   source: Hikal_1992 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Diltiazem_Hikal1992_reference_params';
  p.drug  = 'diltiazem';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 80.0;                % central volume [L]
  p.CL = 53.363;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.2;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 240.0;             % dose [mg]
end
