model Diltiazem_LeBoeuf1987_reference
  parameter Real Cl_ref = 1.4823055555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.372483,
    adminMass = 0.00024,
    ka = 0.0012444444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diltiazem</td></tr><tr><td>population:</td><td>rat liver microsomes</td></tr><tr><td>source_paper:</td><td>LeBoeuf_1987</td></tr><tr><td>measured_compound:</td><td>Deacetyldiltiazem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Deacetyldiltiazem 372.483 g/mol (pubchem); Diltiazem 414.52 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'X 10(-3) M' (Km)</li><li>unit_dimension_unknown: 'mumol/mg of protein/min' (Vmax)</li><li>implicit units: 'Apparent Km' → mg/L (from the popPK convention: 'Michaelis-Menten parameter Km represents substrate concentration. In population PK modeling, concentration parameters ar')</li><li>implicit units: 'Vmax' → mg/h (from the popPK convention: 'Michaelis-Menten parameter Vmax represents the maximum rate of metabolism (mass per time). It is typically paired with K')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Deacetyldiltiazem</li><li>topology: prose indicates saturable/MM/TMDD/time-varying kinetics — manual_model_class</li><li>template fit: none — nonlinear / manual model class</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=other; 2/2 row label(s) assigned, 0 linked by role; re-tagged Deacetyldiltiazem→parent ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Deb_2021's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Shaikh_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is MANUAL_MODEL_CLASS (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is MANUAL_MODEL_CLASS (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Huang_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Deb_2021, Huang_2020, Shaikh_2024 — borrowed values do not complete its disposition core; nonlinear topology)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diltiazem_LeBoeuf1987_reference;
