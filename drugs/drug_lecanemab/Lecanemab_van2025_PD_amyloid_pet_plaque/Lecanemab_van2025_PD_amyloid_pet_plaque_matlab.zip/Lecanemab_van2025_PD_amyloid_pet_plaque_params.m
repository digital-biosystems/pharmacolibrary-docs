function p = Lecanemab_van2025_PD_amyloid_pet_plaque_params()
% Lecanemab_van2025_PD_amyloid_pet_plaque_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lecanemab van_2025::amyloid_PET_plaque: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one % per second, in SI inside (kg/m3, s). Response amyloid PET plaque in CL. Driver: lecanemab (dose_only).
p.E0 = 96.55172413793103;
p.Emax = 1.0;
p.EC50 = 0.787;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.01;
p.stop_time = 400.0;
p.form = 'E0/(1 + Emax*frac)';
end
