model Lecanemab_van2025_PD_amyloid_pet_plaque
  "indirect_response_iv exposure-response sweep — van_2025 :: amyloid PET plaque (amyloid plaque burden)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 96.5517241379,      // [CL]
    Emax = 1,  // type IV effect term
    EC50 = 0.787,  // [1; % × 0.01]
    gamma = 1,
    exposure_per_s = 0.01);   // 1 % per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.028/0.00029 = 96.55) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 400, Interval = 0.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lecanemab</h4><p>Lecanemab is a monoclonal antibody used to treat Alzheimer's disease. It is authorised in the European Union and is an approved anti-dementia medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q56274769\">Wikidata Q56274769</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lecanemab_van2025_PD_amyloid_pet_plaque</h4><p>The steady-state exposure-response curve of van Maanen E et al., <i>Alzheimer's &amp; dementia (New York, N. Y.) 11(4):e70169</i> 2025 (<a href=\"https://doi.org/10.1002/trc2.70169\">doi:10.1002/trc2.70169</a>) — amyloid plaque burden [CL] against lecanemab % — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 96.5517241379 CL       drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       78.7 %        exposure at half of the maximal effect term (inhibition at 11.9 mg, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one % of lecanemab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96.55   (drug-free)
  exposure = EC50 (78.7 %)  response 64.37
  exposure -> infinity  response 48.28</pre></body></html>"));
end Lecanemab_van2025_PD_amyloid_pet_plaque;
