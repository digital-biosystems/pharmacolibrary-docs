function p = Lecanemab_Bhagunde2026v2_PD_gfap_params()
% Lecanemab_Bhagunde2026v2_PD_gfap_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lecanemab Bhagunde_2026_2::GFAP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response GFAP in pg/mL. Driver: lecanemab (cited_pk).
p.E0 = 3.15e-07;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.37e-10;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
