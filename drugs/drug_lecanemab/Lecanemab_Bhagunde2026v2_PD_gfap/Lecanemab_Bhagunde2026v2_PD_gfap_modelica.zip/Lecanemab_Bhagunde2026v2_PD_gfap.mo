model Lecanemab_Bhagunde2026v2_PD_gfap
  "linear exposure-response sweep — Bhagunde_2026_2 :: GFAP (plasma GFAP)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 3.15e-07,      // [kg/m3; pg/mL × 1e-09]
    slope = 2.37e-10,  // [(kg/m3)/(1); logit × 1e-09]
    exposure_per_s = 1);   // 1 unit per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  // slope_unit_assumed: slope unit 'logit' read as pg/mL per exposure unit
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lecanemab</h4><p>Lecanemab is a monoclonal antibody used to treat Alzheimer's disease. It is authorised in the European Union and is an approved anti-dementia medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q56274769\">Wikidata Q56274769</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lecanemab_Bhagunde2026v2_PD_gfap</h4><p>The steady-state exposure-response curve of Bhagunde P et al., <i>Alzheimer's &amp; dementia (New York, N. Y.) 12:e70246</i> 2026 (<a href=\"https://doi.org/10.1002/trc2.70246\">doi:10.1002/trc2.70246</a>) — plasma GFAP [pg/mL] against lecanemab — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        315 pg/mL    drug-free response (baseline) (Baseline GFAP (pg/mL), Q324)
  slope =      0.237 logit    change in response per unit of exposure (SLP (logit), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of lecanemab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.15e-07   (drug-free)</pre></body></html>"));
end Lecanemab_Bhagunde2026v2_PD_gfap;
