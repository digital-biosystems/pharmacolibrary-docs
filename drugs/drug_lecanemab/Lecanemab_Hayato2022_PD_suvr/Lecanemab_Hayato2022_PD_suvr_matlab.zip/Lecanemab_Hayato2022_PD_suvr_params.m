function p = Lecanemab_Hayato2022_PD_suvr_params()
% Lecanemab_Hayato2022_PD_suvr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lecanemab Hayato_2022::SUVr: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response SUVr in its own unit. Driver: lecanemab (pk_record).
p.E0 = 1.34;
p.Emax = 1.54;
p.EC50 = 0.07499999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 300.0;
p.form = 'E0/(1 + Emax*frac)';
end
