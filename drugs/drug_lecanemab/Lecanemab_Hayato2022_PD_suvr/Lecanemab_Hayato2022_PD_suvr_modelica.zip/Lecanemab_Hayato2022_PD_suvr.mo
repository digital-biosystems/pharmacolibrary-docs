model Lecanemab_Hayato2022_PD_suvr
  "indirect_response_iv exposure-response sweep — Hayato_2022 :: SUVr (Amyloid PET standard uptake ratio)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 1.34,      // [1]
    Emax = 1.54,  // type IV effect term
    EC50 = 0.075,  // [kg/m3; μg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/ml per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 300, Interval = 0.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lecanemab</h4><p>Lecanemab is a monoclonal antibody used to treat Alzheimer's disease. It is authorised in the European Union and is an approved anti-dementia medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q56274769\">Wikidata Q56274769</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lecanemab_Hayato2022_PD_suvr</h4><p>The steady-state exposure-response curve of Hayato S et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(12):1578–1591</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12862\">doi:10.1002/psp4.12862</a>) — Amyloid PET standard uptake ratio against lecanemab μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.34          drug-free response (baseline) (Baseline SUVr, Q324)
  Emax  =       1.54          maximal effect term (E max, Q320)
  EC50  =         75 μg/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one μg/ml of lecanemab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.34   (drug-free)
  exposure = EC50 (75 μg/ml)  response 0.7571
  exposure -> infinity  response 0.5276</pre></body></html>"));
end Lecanemab_Hayato2022_PD_suvr;
