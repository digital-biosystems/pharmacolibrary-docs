model Lecanemab_Bhagunde2026v2_PD_p_tau181
  "indirect_response_i exposure-response sweep — Bhagunde_2026_2 :: p-tau181 (plasma p‐tau181)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 3.4e-09,      // [kg/m3; pg/mL × 1e-09]
    Emax = 0.48,  // type I effect term
    EC50 = 31.4,  // [kg/m3; mg/mL × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 320, Interval = 0.64),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lecanemab</h4><p>Lecanemab is a monoclonal antibody used to treat Alzheimer's disease. It is authorised in the European Union and is an approved anti-dementia medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q56274769\">Wikidata Q56274769</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lecanemab_Bhagunde2026v2_PD_p_tau181</h4><p>The steady-state exposure-response curve of Bhagunde P et al., <i>Alzheimer's &amp; dementia (New York, N. Y.) 12:e70246</i> 2026 (<a href=\"https://doi.org/10.1002/trc2.70246\">doi:10.1002/trc2.70246</a>) — plasma p‐tau181 [pg/mL] against lecanemab mg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        3.4 pg/mL    drug-free response (baseline) (Baseline p‐tau181 (pg/mL), Q324)
  Emax  =       0.48          maximal effect term (E max, Q323)
  EC50  =       31.4 mg/mL    exposure at half of the maximal effect term (EC50 (mg/mL), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/mL of lecanemab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.4e-09   (drug-free)
  exposure = EC50 (31.4 mg/mL)  response 2.584e-09
  exposure -> infinity  response 1.768e-09</pre></body></html>"));
end Lecanemab_Bhagunde2026v2_PD_p_tau181;
