function p = Lecanemab_Bhagunde2026v2_PD_p_tau181_params()
% Lecanemab_Bhagunde2026v2_PD_p_tau181_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lecanemab Bhagunde_2026_2::p_tau181: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/mL per second, in SI inside (kg/m3, s). Response p-tau181 in pg/mL. Driver: lecanemab (cited_pk).
p.E0 = 3.4000000000000003e-09;
p.Emax = 0.48;
p.EC50 = 31.399999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 320.0;
p.form = 'E0*(1 - Emax*frac)';
end
