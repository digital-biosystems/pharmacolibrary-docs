function p = Famotidine_McCann2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: famotidine   source: McCann_2023 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Famotidine_McCann2023_reference_params';
  p.drug  = 'famotidine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 226.0;                % central volume [L]
  p.CL = 6.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.325;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
