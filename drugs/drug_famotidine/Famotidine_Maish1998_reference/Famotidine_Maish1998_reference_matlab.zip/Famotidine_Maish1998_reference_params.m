function p = Famotidine_Maish1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: famotidine   source: Maish_1998 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Famotidine_Maish1998_reference_params';
  p.drug  = 'famotidine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 93.1;                % central volume [L]
  p.CL = 55.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.956;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.745;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
