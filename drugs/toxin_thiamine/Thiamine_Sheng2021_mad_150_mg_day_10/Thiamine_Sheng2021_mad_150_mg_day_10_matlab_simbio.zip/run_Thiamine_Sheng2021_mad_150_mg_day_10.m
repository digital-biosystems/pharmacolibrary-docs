% Run (SimBiology): build model + dose, simulate 0..168.0 h, plot.
p = Thiamine_Sheng2021_mad_150_mg_day_10_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 168.0);
