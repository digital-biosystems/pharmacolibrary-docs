function p = Thiamine_Sheng2021_sad_300_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: thiamine   source: Sheng_2021 / sad_300_mg   route: oral
  % estimated (absent from source): ka
  p.name  = 'Thiamine_Sheng2021_sad_300_mg_params';
  p.drug  = 'thiamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 403.0;                % central volume [L]
  p.CL = 42.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
