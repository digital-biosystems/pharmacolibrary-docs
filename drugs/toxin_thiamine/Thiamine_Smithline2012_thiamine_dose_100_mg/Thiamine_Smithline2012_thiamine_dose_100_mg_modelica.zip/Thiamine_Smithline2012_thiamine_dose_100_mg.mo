// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Thiamine_Smithline2012_thiamine_dose_100_mg
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {17208.0},
    MM = 0.265355,
    adminMass = 0.0001,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thiamine</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Smithline_2012</td></tr><tr><td>measured_compound:</td><td>Thiamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>thiamine 265.355 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'whole blood'; source reconciliation required</li><li>table representations disagree for 'plasma'; source reconciliation required</li><li>dropped unlinked row (NIL): 'whole blood' — extend the ontology if this is a real PK parameter (source ['T2:row5:col1', 'T2:row11:col1', 'T2:row17:col1'])</li><li>dropped unlinked row (NIL): 'plasma' — extend the ontology if this is a real PK parameter (source ['T2:row7:col1', 'T2:row13:col1', 'T2:row19:col1'])</li><li>salvaged Q57 ('half-life (t1\\2)'=4.78) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Thiamine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'thiamine dose / 100 mg' subgroup of Smithline_2012 (paper reports 3 populations: thiamine dose / 100 mg, thiamine dose / 1500 mg, thiamine dose / 500 mg)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Thiamine_Smithline2012_thiamine_dose_100_mg;
