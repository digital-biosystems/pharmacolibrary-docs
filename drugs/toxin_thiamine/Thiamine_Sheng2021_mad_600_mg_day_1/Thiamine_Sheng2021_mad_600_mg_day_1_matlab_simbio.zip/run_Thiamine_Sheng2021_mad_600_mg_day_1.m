% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Thiamine_Sheng2021_mad_600_mg_day_1_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
