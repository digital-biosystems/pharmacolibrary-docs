% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Thiamine_Sheng2021_mad_300_mg_day_1_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
