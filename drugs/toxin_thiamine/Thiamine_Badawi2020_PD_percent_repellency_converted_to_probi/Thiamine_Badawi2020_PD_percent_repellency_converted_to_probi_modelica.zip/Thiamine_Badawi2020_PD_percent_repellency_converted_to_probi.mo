model Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi
  "linear exposure-response sweep — Badawi_2020 :: Percent Repellency (converted to probit values) (Percent Repellency (converted to probit values))"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1640000,  // [1]
    exposure_per_s = 1e-06);   // 1 mg per second
  // slope_unit_assumed: slope unit '(none)' read as response per mg
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi</h4><p>The steady-state exposure-response curve of Badawi A et al., <i>Biological &amp; pharmaceutical bulletin 43(2):284–288</i> 2020 (<a href=\"https://doi.org/10.1248/bpb.b19-00538\">doi:10.1248/bpb.b19-00538</a>) — Percent Repellency (converted to probit values) [%] against Thiamine Hydrochloride mg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       1.64          change in response per unit of exposure (Log dose, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg of Thiamine Hydrochloride per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi;
