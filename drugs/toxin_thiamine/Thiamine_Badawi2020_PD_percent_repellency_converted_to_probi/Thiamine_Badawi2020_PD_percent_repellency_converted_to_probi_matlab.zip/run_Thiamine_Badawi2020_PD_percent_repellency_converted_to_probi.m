% run_Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg]'); ylabel('response [%]'); title('Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi.csv');
