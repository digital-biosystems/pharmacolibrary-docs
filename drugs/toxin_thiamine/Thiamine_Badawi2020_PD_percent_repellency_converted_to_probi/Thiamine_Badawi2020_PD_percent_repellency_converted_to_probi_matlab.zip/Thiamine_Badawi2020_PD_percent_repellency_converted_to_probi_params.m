function p = Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi_params()
% Thiamine_Badawi2020_PD_percent_repellency_converted_to_probi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% thiamine Badawi_2020::Percent_Repellency_converted_to_probit_values: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response Percent Repellency (converted to probit values) in %. Driver: Thiamine Hydrochloride (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1640000.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
