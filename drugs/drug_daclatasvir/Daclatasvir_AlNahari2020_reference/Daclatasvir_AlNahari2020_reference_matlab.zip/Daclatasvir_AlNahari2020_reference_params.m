function p = Daclatasvir_AlNahari2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daclatasvir   source: Al-Nahari_2020 / reference   route: oral
  p.name  = 'Daclatasvir_AlNahari2020_reference_params';
  p.drug  = 'daclatasvir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 55.0;                % central volume [L]
  p.CL = 4.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
