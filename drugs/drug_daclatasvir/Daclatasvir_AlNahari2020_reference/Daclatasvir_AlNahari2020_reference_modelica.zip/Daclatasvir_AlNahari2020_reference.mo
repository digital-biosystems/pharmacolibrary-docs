model Daclatasvir_AlNahari2020_reference
  parameter Real Cl_ref = 1.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.055 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7388899999999999,
    adminMass = 6e-05,
    ka = 0.00041666666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About daclatasvir</h4><p>Daclatasvir is an antiviral drug used to treat chronic hepatitis C, including in patients with liver cirrhosis. It was authorised in the European Union but that authorisation has expired, so it is no longer marketed there, though it has been included in the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5207712\">Wikidata Q5207712</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>daclatasvir</td></tr><tr><td>population:</td><td>adolescents with genotype-4 HCV infection</td></tr><tr><td>source_paper:</td><td>Al-Nahari_2020</td></tr><tr><td>measured_compound:</td><td>daclatasvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>daclatasvir 738.89 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'maximum plasma concentration (Cmax)' (captured trailing unit 'Cmax' for child rows)</li><li>dropped value-less row: 'area under the curve (AUC)' (captured trailing unit 'AUC' for child rows)</li><li>dropped duplicate Q76 ('V/F', value '52') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F', value '4.7') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=daclatasvir</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Daclatasvir_AlNahari2020_reference;
