model Daclatasvir_Ueno2018_PD_svr12
  "linear exposure-response sweep — Ueno_2018 :: SVR12 (sustained virologic response at 12 weeks after treatment (SVR12))"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 3680,  // [1]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // slope_unit_assumed: slope unit '(none)' read as response per ng/mL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About daclatasvir</h4><p>Daclatasvir is an antiviral medication used to treat hepatitis C and liver cirrhosis. It is given orally in tablet form. The brand is being withdrawn in countries where it is not typically prescribed.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q5207712\">Wikidata Q5207712</a>, <a href=\"https://en.wikipedia.org/wiki/Daclatasvir?oldid=1322611182\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Daclatasvir_Ueno2018_PD_svr12</h4><p>The steady-state exposure-response curve of Ueno T et al., <i>Journal of clinical pharmacology 58(11):1479–1488</i> 2018 (<a href=\"https://doi.org/10.1002/jcph.1262\">doi:10.1002/jcph.1262</a>) — sustained virologic response at 12 weeks after treatment (SVR12) against daclatasvir (with asunaprevir interaction) ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    0.00368          change in response per unit of exposure (Slope of DCV, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of daclatasvir (with asunaprevir interaction) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Daclatasvir_Ueno2018_PD_svr12;
