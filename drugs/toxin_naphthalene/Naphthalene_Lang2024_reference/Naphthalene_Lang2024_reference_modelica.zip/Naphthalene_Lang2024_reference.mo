// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Naphthalene_Lang2024_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {27720.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>naphthalene</td></tr><tr><td>population:</td><td>male non-smoking firefighting instructors</td></tr><tr><td>source_paper:</td><td>Lang_2024</td></tr><tr><td>measured_compound:</td><td>1,2-dihydroxynaphthalene (DHN)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>1-naphthol (1-NAP) 144.173 g/mol (pubchem); 2-naphthol (2-NAP) 144.173 g/mol (pubchem); Naphthalene 128.174 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'Estimated half-life, mean (h)' Q47 → Q57: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1,2-dihydroxynaphthalene (DHN)</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 4 linked by role; re-tagged parent→1,2-dihydroxynaphthalene (DHN) ×8</li><li>molar mass: none of 1 PubChem candidate(s) is '1,2-dihydroxynaphthalene (DHN)' (LLM) — left in mass units</li><li>molar mass: none found for '1,2-dihydroxynaphthalene (DHN)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 280.8));
end Naphthalene_Lang2024_reference;
