model Methotrexate_Tan2024_PD_das_28_3
  "linear exposure-response sweep — Tan_2024 :: DAS-28-3 (modified 28-joint Disease Activity Score incorporating erythrocyte sedimentation rate (DAS-28-3))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 6.34,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.025   "[1]";
equation
  response = E0 + slope*exposure;
  // off_target_driver: driver compound 'ery-MTX-PG 3-5' is not 'methotrexate' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methotrexate</h4><p>Methotrexate is a folic acid antagonist used as an anticancer drug for various cancers such as leukemia and lymphoma, and as an immunosuppressive disease-modifying antirheumatic drug for conditions like rheumatoid arthritis, psoriasis, and other inflammatory diseases. It is widely used and is included on the WHO essential medicines list; in the European Union several products are authorised for psoriasis and various forms of arthritis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422232\">Wikidata Q422232</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Methotrexate_Tan2024_PD_das_28_3</h4><p>The steady-state exposure-response curve of Tan JM et al., <i>British journal of clinical pharmacology 90(11):2763–2780</i> 2024 (<a href=\"https://doi.org/10.1111/bcp.16158\">doi:10.1111/bcp.16158</a>) — modified 28-joint Disease Activity Score incorporating erythrocyte sedimentation rate (DAS-28-3) against ery-MTX-PG 3-5 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.34          drug-free response (baseline) (E 0, Q324)
  slope =      0.025          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of ery-MTX-PG 3-5 per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.34   (drug-free)</pre></body></html>"));
end Methotrexate_Tan2024_PD_das_28_3;
