function p = Methotrexate_Tan2024_PD_das_28_3_params()
% Methotrexate_Tan2024_PD_das_28_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methotrexate Tan_2024::DAS_28_3: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response DAS-28-3 in its own unit. Driver: ery-MTX-PG 3-5 (not_resolved).
p.E0 = 6.34;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.025;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
