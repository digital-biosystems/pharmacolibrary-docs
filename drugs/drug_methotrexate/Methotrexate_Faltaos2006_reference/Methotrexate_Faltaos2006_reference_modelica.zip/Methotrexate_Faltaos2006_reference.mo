model Methotrexate_Faltaos2006_reference
  parameter Real Cl_ref = 1.972222222222222e-06 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real Vd_ref = 0.0251 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (-0.22)*cov_age_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4544393,
    adminMass = 2.5e-06,
    ka = 3.101851851851852e-06,
    Tlag = 1296.0,
    k12 = 1.6600265604249666e-06,
    k21 = 1.535249324490297e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methotrexate</h4><p>Methotrexate is a folic acid antagonist used as an anticancer drug for various cancers such as leukemia and lymphoma, and as an immunosuppressive disease-modifying antirheumatic drug for conditions like rheumatoid arthritis, psoriasis, and other inflammatory diseases. It is widely used and is included on the WHO essential medicines list; in the European Union several products are authorised for psoriasis and various forms of arthritis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422232\">Wikidata Q422232</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>patients with lymphoid malignancy</td></tr><tr><td>source_paper:</td><td>Faltaos_2006</td></tr><tr><td>measured_compound:</td><td>methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.439 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Exponential part (%)' routed out of structural estimates ('Residual variability combined model')</li><li>table section residual_error: 'Additive part (µmol l⁻¹)' routed out of structural estimates ('Residual variability combined model')</li><li>column 'precision' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'precision' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'precision' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'precision' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'precision' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'SCr on CL' — extend the ontology if this is a real PK parameter (source ['Faltaos_2006_table_p7_1:row6:col1'])</li><li>dropped duplicate Q63 ('ISV (V1) (%)', value '22.5') — already have one for this compound</li><li>dropped duplicate Q22 ('ISV (CL) (%)', value '22') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ISV (Q) (%)' — extend the ontology if this is a real PK parameter (source ['Faltaos_2006_table_p7_1:row11:col1'])</li><li>dropped duplicate Q64 ('ISV (V2) (%)', value '64') — already have one for this compound</li><li>routed 'Inter-occasion variability on CL (%)' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>dropped duplicate Q63 ('V1 (l)', value '25.672') — already have one for this compound</li><li>dropped duplicate Q22 ('CL (l h À1 )', value '7.094') — already have one for this compound</li><li>dropped duplicate Q30 ('Q (l h À1 )', value '0.144') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Faltaos2006_reference;
