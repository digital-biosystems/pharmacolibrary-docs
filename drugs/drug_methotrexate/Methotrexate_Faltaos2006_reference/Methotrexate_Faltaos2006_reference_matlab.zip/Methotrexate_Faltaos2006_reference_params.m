function p = Methotrexate_Faltaos2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Faltaos_2006 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methotrexate_Faltaos2006_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.1;                % central volume [L]
  p.CL = 7.1;                % clearance [L/h]
  p.Vp = [2.714];             % peripheral volumes [L]
  p.Q  = [0.15];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
