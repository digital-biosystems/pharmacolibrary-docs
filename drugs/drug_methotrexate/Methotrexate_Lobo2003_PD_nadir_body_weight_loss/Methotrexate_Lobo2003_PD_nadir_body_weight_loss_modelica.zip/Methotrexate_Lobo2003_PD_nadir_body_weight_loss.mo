model Methotrexate_Lobo2003_PD_nadir_body_weight_loss
  "sigmoid_emax exposure-response sweep — Lobo_2003 :: % Nadir body weight loss (Mean percent nadir body weight loss)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0041,  // [1; % × 0.01]
    EC50 = 2.2e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 4,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.22, Interval = 0.00044),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methotrexate</h4><p>Methotrexate is a folic acid antagonist used as an anticancer drug for various cancers such as leukemia and lymphoma, and as an immunosuppressive disease-modifying antirheumatic drug for conditions like rheumatoid arthritis, psoriasis, and other inflammatory diseases. It is widely used and is included on the WHO essential medicines list; in the European Union several products are authorised for psoriasis and various forms of arthritis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422232\">Wikidata Q422232</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Methotrexate_Lobo2003_PD_nadir_body_weight_loss</h4><p>The steady-state exposure-response curve of Lobo ED et al., <i>Journal of pharmaceutical sciences 92(8):1654–1664</i> 2003 (<a href=\"https://doi.org/10.1002/jps.10431\">doi:10.1002/jps.10431</a>) — Mean percent nadir body weight loss [%] against methotrexate mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.41 %        maximal effect term (E1max, Q320)
  EC50  =      0.022 mg/L     exposure at half of the maximal effect term (EC150, Q321)
  gamma =          4          Hill coefficient (gamma1, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of methotrexate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.022 mg/L)  response 0.00205
  exposure -> infinity  response 0.0041</pre></body></html>"));
end Methotrexate_Lobo2003_PD_nadir_body_weight_loss;
