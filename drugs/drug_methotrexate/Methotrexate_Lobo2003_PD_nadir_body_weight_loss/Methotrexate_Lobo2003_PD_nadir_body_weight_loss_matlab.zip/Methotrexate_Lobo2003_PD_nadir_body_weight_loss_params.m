function p = Methotrexate_Lobo2003_PD_nadir_body_weight_loss_params()
% Methotrexate_Lobo2003_PD_nadir_body_weight_loss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methotrexate Lobo_2003::Nadir_body_weight_loss: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response % Nadir body weight loss in %. Driver: methotrexate (pk_record).
p.E0 = 0.0;
p.Emax = 0.0040999999999999995;
p.EC50 = 2.1999999999999996e-05;
p.gamma = 4.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.22;
p.form = 'E0 + Emax*frac';
end
