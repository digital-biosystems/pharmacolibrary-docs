function p = Methotrexate_Blackman2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Blackman_2026 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Methotrexate_Blackman2026_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 17.88;                % central volume [L]
  p.CL = 7.63;                % clearance [L/h]
  p.Vp = [5.32];             % peripheral volumes [L]
  p.Q  = [0.75];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
