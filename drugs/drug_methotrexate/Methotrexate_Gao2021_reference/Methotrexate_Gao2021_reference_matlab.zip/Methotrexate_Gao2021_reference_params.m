function p = Methotrexate_Gao2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Gao_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methotrexate_Gao2021_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 20.7;                % central volume [L]
  p.CL = 6.9;                % clearance [L/h]
  p.Vp = [41.0];             % peripheral volumes [L]
  p.Q  = [0.255];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
