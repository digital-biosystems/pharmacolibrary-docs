function p = Methotrexate_Wei2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Wei_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Methotrexate_Wei2025_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 33.52;                % central volume [L]
  p.CL = 8.5;                % clearance [L/h]
  p.Vp = [5.32];             % peripheral volumes [L]
  p.Q  = [0.04];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
