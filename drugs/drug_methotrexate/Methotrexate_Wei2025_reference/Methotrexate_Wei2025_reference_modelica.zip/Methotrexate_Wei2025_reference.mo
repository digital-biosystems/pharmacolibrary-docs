model Methotrexate_Wei2025_reference
  parameter Real Cl_ref = 2.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03352 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.101851851851852e-06,
    Tlag = 1296.0,
    k12 = 3.314770617873243e-07,
    k21 = 2.0885547201336676e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>adult patients with primary central nervous system lymphoma</td></tr><tr><td>source_paper:</td><td>Wei_2025</td></tr><tr><td>measured_compound:</td><td>methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q 2 (L/h)', value '0.09') — already have one for this compound</li><li>dropped duplicate Q63 ('V P1 (L)', value '18.32') — already have one for this compound</li><li>dropped unlinked row (NIL): 'θ eGFR' — extend the ontology if this is a real PK parameter (source ['tab_3:row8:col1', 'tab_3:row8:col3', 'tab_3:row8:col5', 'tab_3:row8:col7'])</li><li>dropped unlinked row (NIL): 'Θ BUN' — extend the ontology if this is a real PK parameter (source ['tab_3:row9:col1', 'tab_3:row9:col3', 'tab_3:row9:col5', 'tab_3:row9:col7'])</li><li>dropped unlinked row (NIL): 'θ ALT' — extend the ontology if this is a real PK parameter (source ['tab_3:row10:col1', 'tab_3:row10:col3', 'tab_3:row10:col5', 'tab_3:row10:col7'])</li><li>dropped unlinked row (NIL): 'θ TP' — extend the ontology if this is a real PK parameter (source ['tab_3:row11:col1', 'tab_3:row11:col5', 'tab_3:row11:col7'])</li><li>dropped unlinked row (NIL): 'θ ABCC4-ABCG2-ADORA2A' — extend the ontology if this is a real PK parameter (source ['tab_3:row12:col7'])</li><li>unit_dimension_unknown: 'proportional' (prop_error)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methotrexate</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q64 (V2) from Blackman_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Wei2025_reference;
