model Methotrexate_Zhan2022_reference
  parameter Real Cl_ref = 2.5916666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.024980000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4544393,
    adminMass = 2.5e-06,
    ka = 3.101851851851852e-06,
    Tlag = 1296.0,
    k12 = 2.0016012810248197e-06,
    k21 = 1.0638297872340424e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methotrexate</h4><p>Methotrexate is a folic acid antagonist used as an anticancer drug for various cancers such as leukemia and lymphoma, and as an immunosuppressive disease-modifying antirheumatic drug for conditions like rheumatoid arthritis, psoriasis, and other inflammatory diseases. It is widely used and is included on the WHO essential medicines list; in the European Union several products are authorised for psoriasis and various forms of arthritis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422232\">Wikidata Q422232</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>paediatric patients with acute lymphoblastic leukaemia and malignant lymphoma</td></tr><tr><td>source_paper:</td><td>Zhan_2022</td></tr><tr><td>measured_compound:</td><td>methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.439 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'CL' → L/h (from the popPK convention: 'No unit is stated in the paper. By convention, total clearance (CL) in population PK is expressed in L/h, which is consi')</li><li>implicit units: 'Vc' → L (from the popPK convention: 'No unit is stated in the paper. By convention, the volume of distribution of the central compartment (Vc) is expressed i')</li><li>implicit units: 'Q' → L/h (from the popPK convention: 'No unit is stated in the paper. By convention, intercompartmental clearance (Q) is expressed in L/h, which is consistent')</li><li>implicit units: 'Vp' → L (from the popPK convention: 'No unit is stated in the paper. By convention, the volume of distribution of the peripheral compartment (Vp) is expresse')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methotrexate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Pan_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Tan_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Zhan2022_reference;
