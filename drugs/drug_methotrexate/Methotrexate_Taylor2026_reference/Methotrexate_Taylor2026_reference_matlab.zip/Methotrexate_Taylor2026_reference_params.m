function p = Methotrexate_Taylor2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Taylor_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methotrexate_Taylor2026_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.2;                % central volume [L]
  p.CL = 11.8;                % clearance [L/h]
  p.Vp = [6.67];             % peripheral volumes [L]
  p.Q  = [0.35];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
