model Methotrexate_Kamel1988_reference
  parameter Real Cl_ref = 2.1194444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.35000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 3.101851851851852e-06,
    Tlag = 1296.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>patients with psoriasis</td></tr><tr><td>source_paper:</td><td>Kamel_1988</td></tr><tr><td>measured_compound:</td><td>methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methotrexate</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Blackman_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hernández-Gago_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Pan_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Tan_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Kamel1988_reference;
