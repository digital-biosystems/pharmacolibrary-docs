function p = Methotrexate_Pan2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Pan_2026 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Methotrexate_Pan2026_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.8;                % central volume [L]
  p.CL = 0.016083;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
