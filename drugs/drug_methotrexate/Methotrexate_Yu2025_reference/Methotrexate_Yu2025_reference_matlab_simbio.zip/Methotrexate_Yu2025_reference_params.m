function p = Methotrexate_Yu2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Yu_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Methotrexate_Yu2025_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.84;                % central volume [L]
  p.CL = 4.23;                % clearance [L/h]
  p.Vp = [4.89];             % peripheral volumes [L]
  p.Q  = [0.124];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
