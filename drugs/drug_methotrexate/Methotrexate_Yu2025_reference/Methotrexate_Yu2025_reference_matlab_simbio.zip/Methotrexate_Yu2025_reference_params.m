function p = Methotrexate_Yu2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Yu_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methotrexate_Yu2025_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.9;                % central volume [L]
  p.CL = 4.46;                % clearance [L/h]
  p.Vp = [7.23];             % peripheral volumes [L]
  p.Q  = [0.149];             % inter-compartmental clearances [L/h]
  p.ka = 0.877917;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
