function p = Methotrexate_Zang2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Zang_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methotrexate_Zang2019_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 67.88;                % central volume [L]
  p.CL = 6.53;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
