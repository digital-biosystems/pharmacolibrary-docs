function p = Phenol_Tan2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenol   source: Tan_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Phenol_Tan2024_reference_params';
  p.drug  = 'phenol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1183.415331;                % central volume [L]
  p.CL = 244.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
