function p = Selexipag_Ruehs2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: selexipag   source: Ruehs_2021 / reference   route: oral
  p.name  = 'Selexipag_Ruehs2021_reference_params';
  p.drug  = 'selexipag';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.9;                % central volume [L]
  p.CL = 1.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.8;             % dose [mg]
end
