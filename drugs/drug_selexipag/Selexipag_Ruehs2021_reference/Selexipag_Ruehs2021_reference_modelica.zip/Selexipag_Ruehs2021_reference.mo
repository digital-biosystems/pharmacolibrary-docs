model Selexipag_Ruehs2021_reference
  parameter Real Cl_ref = 3.611111111111112e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0389 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.49663,
    adminMass = 1.8000000000000001e-06,
    ka = 0.00041666666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About selexipag</h4><p>Selexipag is a drug used to treat pulmonary hypertension. It is an approved antithrombotic medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15424759\">Wikidata Q15424759</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>selexipag</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ruehs_2021</td></tr><tr><td>measured_compound:</td><td>selexipag</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>selexipag 496.63 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ruehs_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Selexipag_Ruehs2021_reference;
