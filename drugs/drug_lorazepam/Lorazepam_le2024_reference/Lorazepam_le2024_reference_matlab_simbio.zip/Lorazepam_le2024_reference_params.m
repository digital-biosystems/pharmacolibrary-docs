function p = Lorazepam_le2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorazepam   source: le_2024 / reference   route: oral
  p.name  = 'Lorazepam_le2024_reference_params';
  p.drug  = 'lorazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 184.8;                % central volume [L]
  p.CL = 10.626;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
