model Lorazepam_Greenblatt2000_PD_eeg
  "sigmoid_emax exposure-response sweep — Greenblatt_2000 :: EEG (electroencephalographic activity in the 13- to 30-Hz range)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -12.7,  // [% over baseline]
    EC50 = 1.31e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lorazepam</h4><p>Lorazepam is a benzodiazepine medication used for anxiety disorders, insomnia, and seizures. It is given orally, intravenously, or intramuscularly, and is well absorbed by mouth. It is widely used as a generic medication and is on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q408265\">Wikidata Q408265</a>, <a href=\"https://en.wikipedia.org/wiki/Lorazepam?oldid=1381176124\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Lorazepam_Greenblatt2000_PD_eeg</h4><p>The steady-state exposure-response curve of Greenblatt DJ et al., <i>Critical care medicine 28(8):2750–2757</i> 2000 (<a href=\"https://doi.org/10.1097/00003246-200008000-00011\">doi:10.1097/00003246-200008000-00011</a>) — electroencephalographic activity in the 13- to 30-Hz range [%] against lorazepam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       12.7 % over baseline maximal effect term (maximum electroencephalographic effect, Q323)
  EC50  =       13.1 ng/mL    exposure at half of the maximal effect term (50% effective concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of lorazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13.1 ng/mL)  response -6.35
  exposure -> infinity  response -12.7</pre></body></html>"));
end Lorazepam_Greenblatt2000_PD_eeg;
