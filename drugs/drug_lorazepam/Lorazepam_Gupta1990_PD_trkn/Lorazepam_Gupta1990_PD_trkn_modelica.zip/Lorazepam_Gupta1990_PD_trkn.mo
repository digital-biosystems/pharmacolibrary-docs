model Lorazepam_Gupta1990_PD_trkn
  "sigmoid_emax exposure-response sweep — Gupta_1990 :: TRKN (computerized continuous tracking (TRKN))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -418,  // [1]
    EC50 = 3.58e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 6.29,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 360, Interval = 0.72),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lorazepam</h4><p>Lorazepam is a benzodiazepine medication used for anxiety disorders, insomnia, and seizures. It is given orally, intravenously, or intramuscularly, and is well absorbed by mouth. It is widely used as a generic medication and is on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q408265\">Wikidata Q408265</a>, <a href=\"https://en.wikipedia.org/wiki/Lorazepam?oldid=1381176124\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Lorazepam_Gupta1990_PD_trkn</h4><p>The steady-state exposure-response curve of Gupta SK et al., <i>Journal of pharmacokinetics and biopharmaceutics 18(2):89–102</i> 1990 (<a href=\"https://doi.org/10.1007/BF01063553\">doi:10.1007/BF01063553</a>) — computerized continuous tracking (TRKN) against lorazepam ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        418          maximal effect term (Emax, Q323)
  EC50  =       35.8 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       6.29          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of lorazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (35.8 ng/ml)  response -209
  exposure -> infinity  response -418</pre></body></html>"));
end Lorazepam_Gupta1990_PD_trkn;
