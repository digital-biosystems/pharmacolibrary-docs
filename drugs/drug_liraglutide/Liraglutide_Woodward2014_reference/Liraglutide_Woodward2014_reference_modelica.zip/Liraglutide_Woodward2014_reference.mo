model Liraglutide_Woodward2014_reference
  parameter Real Cl_ref = 1.9083333333333335e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0126 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 3.751262,
    adminMass = 1.5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About liraglutide</h4><p>Liraglutide is a GLP-1 analogue used as an anti-diabetic medicine to treat type 2 diabetes and glucose intolerance, and is also authorised for obesity and overweight. It is approved and authorised in the European Union, and is widely used for diabetes care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2526479\">Wikidata Q2526479</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>liraglutide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Woodward_2014</td></tr><tr><td>measured_compound:</td><td>liraglutide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>liraglutide 3751.26 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Woodward_2014) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Liraglutide_Woodward2014_reference;
