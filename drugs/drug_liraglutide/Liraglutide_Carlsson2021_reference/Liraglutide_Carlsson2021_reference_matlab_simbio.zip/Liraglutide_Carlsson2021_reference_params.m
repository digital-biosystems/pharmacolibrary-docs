function p = Liraglutide_Carlsson2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: liraglutide   source: Carlsson_2021 / reference   route: oral
  p.name  = 'Liraglutide_Carlsson2021_reference_params';
  p.drug  = 'liraglutide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.1;                % central volume [L]
  p.CL = 1.07;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0804;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
