function p = Liraglutide_Overgaard2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: liraglutide   source: Overgaard_2016 / reference   route: oral
  p.name  = 'Liraglutide_Overgaard2016_reference_params';
  p.drug  = 'liraglutide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.6;                % central volume [L]
  p.CL = 0.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.09;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
