model Liraglutide_Inoue2019_PD_fpg
  "indirect_response_i exposure-response sweep — Inoue_2019 :: FPG (fasting plasma glucose)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.65,      // [kg/m3; mg dl À1 × 0.01]
    Emax = 0.266,  // type I effect term
    EC50 = 4.36342592593e-12,  // [kg/s; mg day À1 × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg day À1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.8, Interval = 0.0076),
    Documentation(info = "<html><body><!-- drug-about --><h4>About liraglutide</h4><p>Liraglutide is a GLP-1 analogue used as an anti-diabetic medicine to treat type 2 diabetes and glucose intolerance, and is also authorised for obesity and overweight. It is approved and authorised in the European Union, and is widely used for diabetes care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2526479\">Wikidata Q2526479</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Liraglutide_Inoue2019_PD_fpg</h4><p>The steady-state exposure-response curve of Inoue H et al., <i>British journal of clinical pharmacology 85(2):393–402</i> 2019 (<a href=\"https://doi.org/10.1111/bcp.13807\">doi:10.1111/bcp.13807</a>) — fasting plasma glucose [mg dl À1] against liraglutide mg day À1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        165 mg dl À1 drug-free response (baseline) (Baseline FPG, Q324)
  Emax  =      0.266          maximal effect term (E max, GLP-1r, Q323)
  EC50  =      0.377 mg day À1 exposure at half of the maximal effect term (ED 50, liraglutide, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg day À1 of liraglutide per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.65   (drug-free)
  exposure = EC50 (0.377 mg day À1)  response 1.431
  exposure -> infinity  response 1.211</pre></body></html>"));
end Liraglutide_Inoue2019_PD_fpg;
