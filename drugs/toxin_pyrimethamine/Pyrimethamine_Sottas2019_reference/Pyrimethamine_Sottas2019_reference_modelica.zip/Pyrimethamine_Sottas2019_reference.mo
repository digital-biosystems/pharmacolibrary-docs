model Pyrimethamine_Sottas2019_reference
  parameter Real Cl_ref = 1.3027777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.896 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.248714,
    adminMass = 7.5e-05,
    ka = 3.611111111111111e-05,
    Tlag = 0.0,
    k12 = 2.821180555555556e-05,
    k21 = 4.108203766906839e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pyrimethamine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Sottas_2019</td></tr><tr><td>measured_compound:</td><td>pyrimethamine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pyrimethamine 248.714 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Sottas_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Pyrimethamine_Sottas2019_reference;
