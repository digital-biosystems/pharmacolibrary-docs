function p = Pyrimethamine_Sottas2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pyrimethamine   source: Sottas_2019 / reference   route: oral
  p.name  = 'Pyrimethamine_Sottas2019_reference_params';
  p.drug  = 'pyrimethamine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 896.0;                % central volume [L]
  p.CL = 46.9;                % clearance [L/h]
  p.Vp = [6153.0];             % peripheral volumes [L]
  p.Q  = [91.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.13;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
