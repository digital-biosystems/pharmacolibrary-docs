% Run (SimBiology): build model + dose, simulate 0..408.0 h, plot.
p = Pyrimethamine_de2018_pyrimethamine_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 408.0);
