function p = Pyrimethamine_de2018_pyrimethamine_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pyrimethamine   source: de_2018 / pyrimethamine_estimate   route: oral
  p.name  = 'Pyrimethamine_de2018_pyrimethamine_estimate_params';
  p.drug  = 'pyrimethamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 91.4;                % central volume [L]
  p.CL = 0.829;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
