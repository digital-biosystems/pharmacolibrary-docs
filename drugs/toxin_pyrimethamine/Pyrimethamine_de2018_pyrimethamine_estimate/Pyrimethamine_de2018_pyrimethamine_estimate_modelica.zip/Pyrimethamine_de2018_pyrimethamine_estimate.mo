model Pyrimethamine_de2018_pyrimethamine_estimate
  parameter Real Cl_ref = 2.3027777777777776e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09140000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.248714,
    adminMass = 2.5e-05,
    ka = 0.00038888888888888887,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pyrimethamine</td></tr><tr><td>population:</td><td>pediatric and adult patients with uncomplicated P. falciparum infection</td></tr><tr><td>source_paper:</td><td>de_2018</td></tr><tr><td>measured_compound:</td><td>Pyrimethamine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pyrimethamine 248.714 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'ka' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'V' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'CL' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Correlation in CL of the two drugs (%)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Additive error (μg/ml for sulfadoxine; ng/ml for pyrimethamine)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Proportional error (%)' routed out of structural estimates ('BSV (%)c in:')</li><li>table representations disagree for 'F'; source reconciliation required</li><li>table representations disagree for 'CL/F (liters/h)b'; source reconciliation required</li><li>table representations disagree for 'V/F (liters)b'; source reconciliation required</li><li>table representations disagree for 'ka (/h)'; source reconciliation required</li><li>table representations disagree for 'Change in F for each point in Z-score below −2 (%)'; source reconciliation required</li><li>table representations disagree for 'PGA50 (mo after conception)'; source reconciliation required</li><li>table representations disagree for 'γ (Hill coefficient)'; source reconciliation required</li><li>table representations disagree for 'Difference from clearance in reference 5 (%)'; source reconciliation required</li><li>table representations disagree for 'Bancoumana, Bela Vista, Catuanee'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end Pyrimethamine_de2018_pyrimethamine_estimate;
