function p = Repotrectinib_Du2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: repotrectinib   source: Du_2025 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Repotrectinib_Du2025_reference_params';
  p.drug  = 'repotrectinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 19.8;                % central volume [L]
  p.CL = 7.1;                % clearance [L/h]
  p.Vp = [221.0];             % peripheral volumes [L]
  p.Q  = [4.98];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.52;                 % bioavailability [0-1]
  p.Tlag = 0.421;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
