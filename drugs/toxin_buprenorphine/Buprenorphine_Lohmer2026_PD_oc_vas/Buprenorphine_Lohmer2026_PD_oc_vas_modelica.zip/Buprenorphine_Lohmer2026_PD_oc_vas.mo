model Buprenorphine_Lohmer2026_PD_oc_vas
  "emax exposure-response sweep — Lohmer_2026 :: OC-VAS (opioid craving)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.65,  // [mm]
    EC50 = 3.65e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.7, Interval = 0.0074),
    Documentation(info = "<html><body><h4>Buprenorphine_Lohmer2026_PD_oc_vas</h4><p>The steady-state exposure-response curve of Lohmer LRL et al., <i>Frontiers in pharmacology 17:1839067</i> 2026 (<a href=\"https://doi.org/10.3389/fphar.2026.1839067\">doi:10.3389/fphar.2026.1839067</a>) — opioid craving [mm] against buprenorphine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.65 mm       maximal effect term (Emax Study 1, Q323)
  EC50  =      0.365 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.365 ng/mL)  response -1.325
  exposure -> infinity  response -2.65</pre></body></html>"));
end Buprenorphine_Lohmer2026_PD_oc_vas;
