function p = Buprenorphine_Lohmer2026_PD_oc_vas_params()
% Buprenorphine_Lohmer2026_PD_oc_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Lohmer_2026::OC_VAS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response OC-VAS in mm. Driver: buprenorphine (cited_pk).
p.E0 = 0.0;
p.Emax = -2.65;
p.EC50 = 3.65e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3.7;
p.form = 'E0 + Emax*frac';
end
