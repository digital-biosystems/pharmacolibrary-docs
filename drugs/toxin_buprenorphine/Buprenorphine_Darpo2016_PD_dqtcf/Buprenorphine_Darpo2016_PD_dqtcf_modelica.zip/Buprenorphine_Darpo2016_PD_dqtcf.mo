model Buprenorphine_Darpo2016_PD_dqtcf
  "linear exposure-response sweep — Darpo_2016 :: dQTcF (naltrexone-corrected QTcF change from baseline)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 650,  // [meter ** 3 * second / kilogram; msec per nanogram/milliliter × 1000]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Buprenorphine_Darpo2016_PD_dqtcf</h4><p>The steady-state exposure-response curve of Darpo B et al., <i>Clinical therapeutics 38(2):315–326</i> 2016 (<a href=\"https://doi.org/10.1016/j.clinthera.2015.12.004\">doi:10.1016/j.clinthera.2015.12.004</a>) — naltrexone-corrected QTcF change from baseline [msec] against buprenorphine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.65 msec per nanogram/milliliter change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Buprenorphine_Darpo2016_PD_dqtcf;
