model Buprenorphine_Bjrnsson2023_reference
  parameter Real Cl_ref = 1.4472222222222223e-05 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real Vd_ref = 0.0643 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.413)*cov_wt_0)*(1 + (0.576)*cov_sex_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4676,
    adminMass = 8e-06,
    ka = 0.00047777777777777776,
    Tlag = 615.6,
    k12 = 0.0008035251425609124,
    k21 = 0.0003974358974358974
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>buprenorphine</td></tr><tr><td>population:</td><td>healthy participants and participants with Opioid Use Disorder (OUD)</td></tr><tr><td>source_paper:</td><td>Björnsson_2023</td></tr><tr><td>measured_compound:</td><td>Buprenorphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>buprenorphine 467.6 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL(L/h)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'CL(L/h)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'Vc(L)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'Vc(L)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'Q3(L/h)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'Q3(L/h)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'V3(L)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'V3(L)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'FSL(%)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'FSL(%)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'ka,SL2(h–1)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'ka,SL2(h–1)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'FSL1(%)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'FSL1(%)' routed out of structural estimates ('IIV / RSE (%)')</li><li>table section iiv: 'ka,q1w2(h–1)' routed out of structural estimates ('IIV / CV (%)')</li><li>table section iiv: 'ka,q1w2(h–1)' routed out of structural estimates ('IIV / RSE (%)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Buprenorphine_Bjrnsson2023_reference;
