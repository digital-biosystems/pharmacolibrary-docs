function p = Buprenorphine_Bjrnsson2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: buprenorphine   source: Björnsson_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Buprenorphine_Bjrnsson2023_reference_params';
  p.drug  = 'buprenorphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 64.3;                % central volume [L]
  p.CL = 52.1;                % clearance [L/h]
  p.Vp = [130.0];             % peripheral volumes [L]
  p.Q  = [186.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.72;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.171;             % absorption lag [h]
  p.dose = 8.0;             % dose [mg]
end
