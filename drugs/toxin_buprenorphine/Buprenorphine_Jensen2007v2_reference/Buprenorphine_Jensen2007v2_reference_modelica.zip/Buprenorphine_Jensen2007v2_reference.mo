model Buprenorphine_Jensen2007v2_reference
  parameter Real Cl_ref = 6.527777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0818 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4676,
    adminMass = 0.0001,
    ka = 0.0007055555555555555,
    Tlag = 0.0,
    k12 = 0.00011817440912795436,
    k21 = 0.00040787623066104083
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>buprenorphine</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Jensen_2007_2</td></tr><tr><td>measured_compound:</td><td>Buprenorphine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>buprenorphine 467.6 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'apparent clearance' → L/h (from the popPK convention: 'Apparent clearance values in population PK are conventionally expressed in L/h, consistent with the magnitude of 23.5.')</li><li>implicit units: 'central distribution volume' → L (from the popPK convention: 'Volume of distribution values in population PK are conventionally expressed in L, consistent with the magnitude of 81.8.')</li><li>implicit units: 'peripheral distribution volume 1' → L (from the popPK convention: 'Volume of distribution values in population PK are conventionally expressed in L, consistent with the magnitude of 23.7.')</li><li>implicit units: 'inter-compartmental clearances between V(1) and V(2)' → L/h (from the popPK convention: 'Intercompartmental clearances in population PK are conventionally expressed in L/h, consistent with the magnitude of 34.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Buprenorphine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Santiago_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Buprenorphine_Jensen2007v2_reference;
