function p = Buprenorphine_Jensen2007v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: buprenorphine   source: Jensen_2007_2 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Buprenorphine_Jensen2007v2_reference_params';
  p.drug  = 'buprenorphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 81.8;                % central volume [L]
  p.CL = 23.5;                % clearance [L/h]
  p.Vp = [23.7];             % peripheral volumes [L]
  p.Q  = [34.8];             % inter-compartmental clearances [L/h]
  p.ka = 2.54;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
