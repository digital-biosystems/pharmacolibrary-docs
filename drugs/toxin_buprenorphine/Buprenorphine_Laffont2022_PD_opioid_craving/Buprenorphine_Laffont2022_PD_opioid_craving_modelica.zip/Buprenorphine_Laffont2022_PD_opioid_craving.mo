model Buprenorphine_Laffont2022_PD_opioid_craving
  "emax exposure-response sweep — Laffont_2022 :: Opioid craving (Opioid craving)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.87,  // [VAS]
    EC50 = 2.45e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 25, Interval = 0.05),
    Documentation(info = "<html><body><h4>Buprenorphine_Laffont2022_PD_opioid_craving</h4><p>The steady-state exposure-response curve of Laffont CM et al., <i>Frontiers in pharmacology 13:1052113</i> 2022 (<a href=\"https://doi.org/10.3389/fphar.2022.1052113\">doi:10.3389/fphar.2022.1052113</a>) — Opioid craving [VAS] against buprenorphine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.87 VAS      maximal effect term (Emax, Q323)
  EC50  =       2.45 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.45 ng/ml)  response -1.435
  exposure -> infinity  response -2.87</pre></body></html>"));
end Buprenorphine_Laffont2022_PD_opioid_craving;
