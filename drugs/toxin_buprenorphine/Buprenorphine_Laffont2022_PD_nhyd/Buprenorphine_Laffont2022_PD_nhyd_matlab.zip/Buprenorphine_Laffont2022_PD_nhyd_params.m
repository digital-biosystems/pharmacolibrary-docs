function p = Buprenorphine_Laffont2022_PD_nhyd_params()
% Buprenorphine_Laffont2022_PD_nhyd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Laffont_2022::NHYD: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response NHYD in units. Driver: buprenorphine (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 7.2e-07;
p.gamma = 2.04;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 7.2;
p.form = 'E0 + Emax*frac';
end
