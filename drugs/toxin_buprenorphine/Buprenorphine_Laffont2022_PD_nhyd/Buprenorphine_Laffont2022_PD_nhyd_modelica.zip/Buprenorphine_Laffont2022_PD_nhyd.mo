model Buprenorphine_Laffont2022_PD_nhyd
  "emax exposure-response sweep — Laffont_2022 :: NHYD (Number of hydromorphone units earned)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [fixed]
    EC50 = 7.2e-07,  // [kg/m3; ng/ml × 1e-06]
    gamma = 2.04,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 7.2, Interval = 0.0144),
    Documentation(info = "<html><body><h4>Buprenorphine_Laffont2022_PD_nhyd</h4><p>The steady-state exposure-response curve of Laffont CM et al., <i>Frontiers in pharmacology 13:1052113</i> 2022 (<a href=\"https://doi.org/10.3389/fphar.2022.1052113\">doi:10.3389/fphar.2022.1052113</a>) — Number of hydromorphone units earned [units] against buprenorphine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1 fixed    maximal effect term (Emax, Q323)
  EC50  =       0.72 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.04          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.72 ng/ml)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Buprenorphine_Laffont2022_PD_nhyd;
