model Buprenorphine_Jones2021_reference
  parameter Real Cl_ref = 1.45e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.432 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4676,
    adminMass = 0.0001,
    ka = 0.0007055555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>buprenorphine</td></tr><tr><td>population:</td><td>subjects with opioid use disorder</td></tr><tr><td>source_paper:</td><td>Jones_2021</td></tr><tr><td>measured_compound:</td><td>Buprenorphine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>buprenorphine 467.6 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is buprenorphine; the compartment is Buprenorphine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Buprenorphine, not buprenorphine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>buprenorphine's own concentration-time course is not produced by this model</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'V4/F' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'Q/F' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'V5/F' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'k14' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'k24' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'k36' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'k64' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'F1' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'PROP' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>table section iiv: 'ADD' routed out of structural estimates ('Inter-individual variability (%CV)')</li><li>dropped duplicate Q347 ('k36', value '0.00392') — already have one for this compound</li><li>dropped duplicate Q347 ('k64', value '0.000507') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Buprenorphine_Jones2021_reference;
