function p = Buprenorphine_Jones2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: buprenorphine   source: Jones_2021 / reference   route: oral
  p.name  = 'Buprenorphine_Jones2021_reference_params';
  p.drug  = 'buprenorphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1110.0;                % central volume [L]
  p.CL = 52.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.54;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
