model Buprenorphine_Gu2023_PD_oro
  "emax exposure-response sweep — Gu_2023 :: μORO (μ-opioid receptor occupancy)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.914,  // [1; % × 0.01]
    EC50 = 6.7e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 6.7, Interval = 0.0134),
    Documentation(info = "<html><body><h4>Buprenorphine_Gu2023_PD_oro</h4><p>The steady-state exposure-response curve of Gu M et al., <i>Frontiers in pharmacology 14:1089862</i> 2023 (<a href=\"https://doi.org/10.3389/fphar.2023.1089862\">doi:10.3389/fphar.2023.1089862</a>) — μ-opioid receptor occupancy [%] against buprenorphine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       91.4 %        maximal effect term (Emax, Q320)
  EC50  =       0.67 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.67 ng/mL)  response 0.457
  exposure -> infinity  response 0.914</pre></body></html>"));
end Buprenorphine_Gu2023_PD_oro;
