function p = Buprenorphine_Gu2023_PD_oro_params()
% Buprenorphine_Gu2023_PD_oro_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Gu_2023::ORO: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response μORO in %. Driver: buprenorphine (pk_record).
p.E0 = 0.0;
p.Emax = 0.914;
p.EC50 = 6.7e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 6.7;
p.form = 'E0 + Emax*frac';
end
