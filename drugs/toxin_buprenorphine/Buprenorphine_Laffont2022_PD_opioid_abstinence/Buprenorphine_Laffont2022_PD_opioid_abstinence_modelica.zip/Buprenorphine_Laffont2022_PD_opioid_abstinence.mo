model Buprenorphine_Laffont2022_PD_opioid_abstinence
  "emax exposure-response sweep — Laffont_2022 :: Opioid abstinence (Opioid abstinence)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 4.86,  // [1]
    EC50 = 1.21e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><h4>Buprenorphine_Laffont2022_PD_opioid_abstinence</h4><p>The steady-state exposure-response curve of Laffont CM et al., <i>Frontiers in pharmacology 13:1052113</i> 2022 (<a href=\"https://doi.org/10.3389/fphar.2022.1052113\">doi:10.3389/fphar.2022.1052113</a>) — Opioid abstinence against buprenorphine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.86          maximal effect term (Emax, Q320)
  EC50  =       1.21 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.21 ng/ml)  response 2.43
  exposure -> infinity  response 4.86</pre></body></html>"));
end Buprenorphine_Laffont2022_PD_opioid_abstinence;
