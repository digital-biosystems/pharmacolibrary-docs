function p = Buprenorphine_Laffont2022_PD_opioid_abstinence_params()
% Buprenorphine_Laffont2022_PD_opioid_abstinence_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Laffont_2022::Opioid_abstinence: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response Opioid abstinence in its own unit. Driver: buprenorphine (cited_pk).
p.E0 = 0.0;
p.Emax = 4.86;
p.EC50 = 1.2099999999999998e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 13.0;
p.form = 'E0 + Emax*frac';
end
