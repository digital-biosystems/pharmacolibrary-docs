// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SodiumPerchlorate_Yu2002_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {115200.0},
    MM = 0.09944599999999999,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_perchlorate</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Yu_2002</td></tr><tr><td>measured_compound:</td><td>Perchlorate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Perchlorate 99.446 g/mol (pubchem); sodium_perchlorate 122.436 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'half-lives of (36)ClO(-)(4) from the skin' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('half-lives of (36)ClO(-)(4) from the thyroid', value 7.6) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of (36)ClO(-)(4) from the plasma', value 7.3) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of (36)ClO(-)(4) from the GT', value 10.0) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of (36)ClO(-)(4) from the GT contents', value 8.6) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Perchlorate</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Perchlorate', not sodium_perchlorate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end SodiumPerchlorate_Yu2002_reference;
