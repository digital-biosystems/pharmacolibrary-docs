model Maraviroc_Courlet2021_reference
  parameter Real Cl_ref = 4.722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5136655,
    adminMass = 0.0006,
    ka = 0.00019166666666666665,
    Tlag = 3132.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About maraviroc</h4><p>Maraviroc is an antiviral drug used to treat HIV infection and AIDS. It is authorised in the European Union for HIV infections and remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421369\">Wikidata Q421369</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>maraviroc</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Courlet_2021</td></tr><tr><td>measured_compound:</td><td>maraviroc</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>maraviroc 513.665 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Courlet_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Maraviroc_Courlet2021_reference;
