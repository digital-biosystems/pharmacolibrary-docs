model Maraviroc_Davis2008_PD_qt
  "linear exposure-response sweep — Davis_2008 :: QT (QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.97   "[micros ml ng(-1)]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About maraviroc</h4><p>Maraviroc is an antiviral drug used to treat HIV infection and AIDS. It is authorised in the European Union for HIV infections and remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421369\">Wikidata Q421369</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Maraviroc_Davis2008_PD_qt</h4><p>The steady-state exposure-response curve of Davis JD et al., <i>British journal of clinical pharmacology 65 Suppl 1(Suppl 1):68–75</i> 2008 (<a href=\"https://doi.org/10.1111/j.1365-2125.2008.03138.x\">doi:10.1111/j.1365-2125.2008.03138.x</a>) — QT interval [ms] against maraviroc ng ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.97 micros ml ng(-1) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng ml(-1) of maraviroc per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Maraviroc_Davis2008_PD_qt;
