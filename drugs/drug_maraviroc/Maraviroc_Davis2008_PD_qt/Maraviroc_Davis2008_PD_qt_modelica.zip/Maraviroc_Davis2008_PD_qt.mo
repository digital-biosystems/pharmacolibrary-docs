model Maraviroc_Davis2008_PD_qt
  "linear exposure-response sweep — Davis_2008 :: QT (QT interval)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.97,  // [meter ** 3 * second / kilogram; micros ml ng(-1) × 1]
    exposure_per_s = 1e-06);   // 1 ng ml(-1) per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About maraviroc</h4><p>Maraviroc is a CCR5 receptor antagonist used to treat HIV infection. It is taken by mouth. It is authorised in the European Union and the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421369\">Wikidata Q421369</a>, <a href=\"https://en.wikipedia.org/wiki/Maraviroc?oldid=1329260707\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Maraviroc_Davis2008_PD_qt</h4><p>The steady-state exposure-response curve of Davis JD et al., <i>British journal of clinical pharmacology 65 Suppl 1(Suppl 1):68–75</i> 2008 (<a href=\"https://doi.org/10.1111/j.1365-2125.2008.03138.x\">doi:10.1111/j.1365-2125.2008.03138.x</a>) — QT interval [ms] against maraviroc ng ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.97 micros ml ng(-1) change in response per unit of exposure (slope describing the QT-concentration relationship, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng ml(-1) of maraviroc per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Maraviroc_Davis2008_PD_qt;
