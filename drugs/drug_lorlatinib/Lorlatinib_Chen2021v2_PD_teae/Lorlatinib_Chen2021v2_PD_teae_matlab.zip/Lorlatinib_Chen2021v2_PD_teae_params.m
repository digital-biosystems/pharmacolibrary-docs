function p = Lorlatinib_Chen2021v2_PD_teae_params()
% Lorlatinib_Chen2021v2_PD_teae_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lorlatinib Chen_2021_2::TEAE: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TEAE in its own unit. Driver: lorlatinib (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1167000.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
