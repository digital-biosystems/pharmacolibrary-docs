model Lorlatinib_Chen2021v2_PD_teae
  "linear exposure-response sweep — Chen_2021_2 :: TEAE (TEAEs grade ≥ 3)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1167000,  // [1]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // slope_unit_assumed: slope unit '(none)' read as response per ng/mL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lorlatinib</h4><p>Lorlatinib is a protein kinase inhibitor used to treat non-small-cell lung carcinoma. It is taken by mouth. It is authorised in the European Union and sold in the United States, Canada, and Japan.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q27285820\">Wikidata Q27285820</a>, <a href=\"https://en.wikipedia.org/wiki/Lorlatinib?oldid=1329260404\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lorlatinib_Chen2021v2_PD_teae</h4><p>The steady-state exposure-response curve of Chen J et al., <i>Clinical pharmacology and therapeutics 110(5):1273–1281</i> 2021 (<a href=\"https://doi.org/10.1002/cpt.2228\">doi:10.1002/cpt.2228</a>) — TEAEs grade ≥ 3 against lorlatinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      1.167          change in response per unit of exposure (log(Ctrough ss), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of lorlatinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Lorlatinib_Chen2021v2_PD_teae;
