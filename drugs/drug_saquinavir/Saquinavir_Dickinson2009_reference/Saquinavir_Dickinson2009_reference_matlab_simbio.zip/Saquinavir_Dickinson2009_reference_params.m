function p = Saquinavir_Dickinson2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: saquinavir   source: Dickinson_2009 / reference   route: oral
  p.name  = 'Saquinavir_Dickinson2009_reference_params';
  p.drug  = 'saquinavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 103.0;                % central volume [L]
  p.CL = 7.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.96;             % absorption lag [h]
  p.dose = 1800.0;             % dose [mg]
end
