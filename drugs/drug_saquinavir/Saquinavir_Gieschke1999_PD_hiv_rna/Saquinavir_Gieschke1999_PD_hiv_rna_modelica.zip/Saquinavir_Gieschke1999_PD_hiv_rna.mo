model Saquinavir_Gieschke1999_PD_hiv_rna
  "emax exposure-response sweep — Gieschke_1999 :: HIV RNA (plasma HIV RNA level)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.94,  // [log10 copies/ml]
    EC50 = 5e-05,  // [kg/m3; micrograms/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 micrograms/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 500, Interval = 1),
    Documentation(info = "<html><body><!-- drug-about --><h4>About saquinavir</h4><p>Saquinavir is a protease inhibitor antiviral drug used to treat HIV infection and HIV/AIDS. It is an approved medicine and has been included on the WHO essential medicines list, although its marketing authorisations in the European Union have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422654\">Wikidata Q422654</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Saquinavir_Gieschke1999_PD_hiv_rna</h4><p>The steady-state exposure-response curve of Gieschke R et al., <i>Clinical pharmacokinetics 37(1):75–86</i> 1999 (<a href=\"https://doi.org/10.2165/00003088-199937010-00005\">doi:10.2165/00003088-199937010-00005</a>) — plasma HIV RNA level [log10 copies/ml] against saquinavir micrograms/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.94 log10 copies/ml maximal effect term (maximum reduction in viral load, Q323)
  EC50  =         50 micrograms/L exposure at half of the maximal effect term (half-maximal antiviral response concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micrograms/L of saquinavir per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (50 micrograms/L)  response -0.97
  exposure -> infinity  response -1.94</pre></body></html>"));
end Saquinavir_Gieschke1999_PD_hiv_rna;
