function p = Saquinavir_Gieschke1999_PD_hiv_rna_params()
% Saquinavir_Gieschke1999_PD_hiv_rna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% saquinavir Gieschke_1999::HIV_RNA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms/L per second, in SI inside (kg/m3, s). Response HIV RNA in log10 copies/ml. Driver: saquinavir (cited_pk).
p.E0 = 0.0;
p.Emax = -1.94;
p.EC50 = 4.999999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 500.0;
p.form = 'E0 + Emax*frac';
end
