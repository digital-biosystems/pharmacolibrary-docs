function p = EthyleneGlycol_Harry1994_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethylene_glycol   source: Harry_1994 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'EthyleneGlycol_Harry1994_reference_params';
  p.drug  = 'ethylene_glycol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 49.91;                % central volume [L]
  p.CL = 1.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
