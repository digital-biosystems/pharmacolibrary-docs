model EthyleneGlycol_Boreak2026_reference
  parameter Real Cl_ref = 1.0175666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.049909999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.062068,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethylene_glycol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Boreak_2026</td></tr><tr><td>measured_compound:</td><td>ethylene_glycol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ethylene_glycol 62.068 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Boreak_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end EthyleneGlycol_Boreak2026_reference;
