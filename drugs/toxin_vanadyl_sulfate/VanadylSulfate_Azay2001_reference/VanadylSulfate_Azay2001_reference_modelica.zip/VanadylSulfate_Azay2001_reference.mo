model VanadylSulfate_Azay2001_reference
  parameter Real Cl_ref = 1.0444444444444444e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17010000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vanadyl_sulfate</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Azay_2001</td></tr><tr><td>measured_compound:</td><td>vanadium (element, measured in blood)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vanadyl_sulfate 162.997 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life (i.v., phase 2)', value 24.8) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life (i.v., phase 3)', value 201) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life (oral, 15.12 mg V/kg, terminal log-linear part)', value 173.5) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life (oral, 7.56 mg V/kg, terminal log-linear part)', value 172) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vanadium (element, measured in blood)</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Initial volume of distribution' is the general volume)</li><li>molar mass: none found for 'vanadium (element, measured in blood)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'vanadium (element, measured in blood)', not vanadyl_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end VanadylSulfate_Azay2001_reference;
