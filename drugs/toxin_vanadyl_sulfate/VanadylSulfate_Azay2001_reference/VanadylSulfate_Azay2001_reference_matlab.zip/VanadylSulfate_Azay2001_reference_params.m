function p = VanadylSulfate_Azay2001_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vanadyl_sulfate   source: Azay_2001 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'VanadylSulfate_Azay2001_reference_params';
  p.drug  = 'vanadyl_sulfate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 170.1;                % central volume [L]
  p.CL = 0.0376;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.125;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
