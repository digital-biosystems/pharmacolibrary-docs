model Exenatide_Cirincione2017_single_dose_model_iv
  parameter Real Cl_ref = 3.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>exenatide</td></tr><tr><td>population:</td><td>patients with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Cirincione_2017</td></tr><tr><td>measured_compound:</td><td>exenatide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'N1' — extend the ontology if this is a real PK parameter (source ['Cirincione_2017_table_p6_1:row10:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=exenatide</li><li>population split: 'single-dose model iv (%)' subgroup of Cirincione_2017 (paper reports 4 populations: combined single- and multiple-dose models iv (%), combined single- and multiple-dose models parameter estimate, single-dose model iv (%), single-dose model parameter estimate)</li><li>gap-filled Q22 (CL) from Admiraal_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Admiraal_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Exenatide_Cirincione2017_single_dose_model_iv;
