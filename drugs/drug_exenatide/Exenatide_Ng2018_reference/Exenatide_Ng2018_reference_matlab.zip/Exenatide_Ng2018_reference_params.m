function p = Exenatide_Ng2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: exenatide   source: Ng_2018 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Exenatide_Ng2018_reference_params';
  p.drug  = 'exenatide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.77;                % central volume [L]
  p.CL = 9.66;                % clearance [L/h]
  p.Vp = [8.89];             % peripheral volumes [L]
  p.Q  = [2.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
