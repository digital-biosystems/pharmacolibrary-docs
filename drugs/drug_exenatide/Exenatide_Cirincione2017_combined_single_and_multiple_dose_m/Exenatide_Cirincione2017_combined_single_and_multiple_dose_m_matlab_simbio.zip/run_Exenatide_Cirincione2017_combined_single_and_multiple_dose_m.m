% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Exenatide_Cirincione2017_combined_single_and_multiple_dose_m_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
