model Exenatide_Gao2011_PD_ins
  "indirect_response_iii exposure-response sweep — Gao_2011 :: Ins (insulin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 6.91,  // type III effect term
    EC50 = 1.29,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><!-- drug-about --><h4>About exenatide</h4><p>Exenatide is a GLP-1 agonist used as an anti-diabetic medication, notably for type 2 diabetes. It is authorised in the European Union and widely used for diabetes, with some additional investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417762\">Wikidata Q417762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Exenatide_Gao2011_PD_ins</h4><p>The steady-state exposure-response curve of Gao W et al., <i>The Journal of pharmacology and experimental therapeutics 336(3):881–890</i> 2011 (<a href=\"https://doi.org/10.1124/jpet.110.175752\">doi:10.1124/jpet.110.175752</a>) — insulin [ng/ml] against exendin-4 nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       6.91          maximal effect term (Maximum insulintropic response factor, Q320)
  EC50  =       1.29 nM       exposure at half of the maximal effect term (Concentration for 50% of insulintropic effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of exendin-4 per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.29 nM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Exenatide_Gao2011_PD_ins;
