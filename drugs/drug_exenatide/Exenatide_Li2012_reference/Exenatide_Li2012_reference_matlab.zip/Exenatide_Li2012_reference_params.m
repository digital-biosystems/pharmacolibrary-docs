function p = Exenatide_Li2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: exenatide   source: Li_2012 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Exenatide_Li2012_reference_params';
  p.drug  = 'exenatide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.18;                % central volume [L]
  p.CL = 0.198;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
