model Exenatide_Li2012_reference
  parameter Real Cl_ref = 5.5e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00118 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 2.0244821092278714e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>exenatide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2012</td></tr><tr><td>measured_compound:</td><td>exenatide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2012) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Exenatide_Li2012_reference;
