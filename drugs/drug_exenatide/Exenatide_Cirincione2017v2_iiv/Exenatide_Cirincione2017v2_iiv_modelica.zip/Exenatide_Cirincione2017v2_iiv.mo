model Exenatide_Cirincione2017v2_iiv
  parameter Real Cl_ref = 1.4055555555555553e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.6666666666666667e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>exenatide</td></tr><tr><td>population:</td><td>adults with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Cirincione_2017_2</td></tr><tr><td>measured_compound:</td><td>exenatide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp13135-tbl-0002</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Cl_int (l h −1 )' (captured trailing unit 'l h −1' for child rows)</li><li>dropped value-less row: 'Cl = Cl_int ⋅eGFR80 Cl_eGFR'</li><li>dropped value-less row: 'K m (pg ml −1 )' (captured trailing unit 'pg ml −1' for child rows)</li><li>dropped value-less row: 'Vc_int (l)' (captured trailing unit 'l' for child rows)</li><li>dropped value-less row: 'Vc=Vc_int⋅weight84.8Vc_wtkg'</li><li>salvaged Q22 ('linear clearance'=5.06) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=exenatide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'iiv(%)' subgroup of Cirincione_2017_2 (paper reports 2 populations: iiv(%), parameter estimate)</li><li>gap-filled Q61 (V) from Admiraal_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Exenatide_Cirincione2017v2_iiv;
