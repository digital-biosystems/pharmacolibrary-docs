function p = Exenatide_Cirincione2017v2_iiv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: exenatide   source: Cirincione_2017_2 / iiv   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Exenatide_Cirincione2017v2_iiv_params';
  p.drug  = 'exenatide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.0;                % central volume [L]
  p.CL = 5.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.006;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
