function p = Hydromorphone_Guedes2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydromorphone   source: Guedes_2008 / reference   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Hydromorphone_Guedes2008_reference_params';
  p.drug  = 'hydromorphone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 504.0;                % central volume [L]
  p.CL = 313.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
