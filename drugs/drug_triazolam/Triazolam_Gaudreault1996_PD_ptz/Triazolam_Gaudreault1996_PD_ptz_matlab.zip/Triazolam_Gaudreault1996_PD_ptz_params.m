function p = Triazolam_Gaudreault1996_PD_ptz_params()
% Triazolam_Gaudreault1996_PD_ptz_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% triazolam Gaudreault_1996::PTZ: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PTZ in its own unit. Driver: triazolam (pk_record).
p.E0 = 0.0;
p.Emax = 9.9;
p.EC50 = 9.999999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 100.0;
p.form = 'E0 + Emax*frac';
end
