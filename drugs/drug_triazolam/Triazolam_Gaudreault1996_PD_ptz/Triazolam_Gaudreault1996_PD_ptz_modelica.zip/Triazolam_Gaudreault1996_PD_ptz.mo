model Triazolam_Gaudreault1996_PD_ptz
  "emax exposure-response sweep — Gaudreault_1996 :: PTZ (pentylenetetrazol-induced seizures)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 9.9,  // [1]
    EC50 = 1e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 100, Interval = 0.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About triazolam</h4><p>Triazolam is a benzodiazepine derivative used primarily to treat severe insomnia. It is administered orally in forms such as tablets, capsules, or liquid solutions. It is authorized for use in the United States and serves as a central nervous system depressant.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412143\">Wikidata Q412143</a>, <a href=\"https://en.wikipedia.org/wiki/Triazolam?oldid=1384270135\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Triazolam_Gaudreault1996_PD_ptz</h4><p>The steady-state exposure-response curve of Gaudreault J et al., <i>Journal of pharmaceutical sciences 85(9):999–1004</i> 1996 (<a href=\"https://doi.org/10.1021/js9503183\">doi:10.1021/js9503183</a>) — pentylenetetrazol-induced seizures against triazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        9.9          maximal effect term (Emax, Q320)
  EC50  =         10 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of triazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (10 ng/mL)  response 4.95
  exposure -> infinity  response 9.9</pre></body></html>"));
end Triazolam_Gaudreault1996_PD_ptz;
