function p = Triazolam_van2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: triazolam   source: van_2011 / reference   route: oral
  p.name  = 'Triazolam_van2011_reference_params';
  p.drug  = 'triazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3210.0;                % central volume [L]
  p.CL = 50.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.468;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.487;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
