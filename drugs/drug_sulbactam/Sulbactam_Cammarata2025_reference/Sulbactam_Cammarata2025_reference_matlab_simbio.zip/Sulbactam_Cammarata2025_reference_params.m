function p = Sulbactam_Cammarata2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulbactam   source: Cammarata_2025 / reference   route: oral
  p.name  = 'Sulbactam_Cammarata2025_reference_params';
  p.drug  = 'sulbactam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.9;                % central volume [L]
  p.CL = 14.0;                % clearance [L/h]
  p.Vp = [9.29];             % peripheral volumes [L]
  p.Q  = [18.9];             % inter-compartmental clearances [L/h]
  p.ka = 8.28;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
