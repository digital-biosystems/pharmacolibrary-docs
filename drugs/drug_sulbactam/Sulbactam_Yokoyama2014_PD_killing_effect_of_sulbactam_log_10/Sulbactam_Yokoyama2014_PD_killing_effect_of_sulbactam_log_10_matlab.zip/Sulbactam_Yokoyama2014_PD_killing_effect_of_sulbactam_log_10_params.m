function p = Sulbactam_Yokoyama2014_PD_killing_effect_of_sulbactam_log_10_params()
% Sulbactam_Yokoyama2014_PD_killing_effect_of_sulbactam_log_10_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sulbactam Yokoyama_2014::killing_effect_of_sulbactam_log_10_CFU_of_the_A_baumannii_per_thigh_or_lung_at_24_h: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one % per second, in SI inside (kg/m3, s). Response killing effect of sulbactam (log 10 CFU of the A. baumannii per thigh or lung at 24 h) in log 10 CFU/thigh. Driver: sulbactam (cited_pk).
p.E0 = 0.52;
p.Emax = -5.19;
p.EC50 = 0.446;
p.gamma = 2.93;
p.slope = 0.0;
p.exposure_per_s = 0.01;
p.stop_time = 450.0;
p.form = 'E0 + Emax*frac';
end
