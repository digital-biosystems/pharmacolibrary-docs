model Sulbactam_Yokoyama2014_PD_killing_effect_of_sulbactam_log_10
  "sigmoid_emax exposure-response sweep — Yokoyama_2014 :: killing effect of sulbactam (log 10 CFU of the A. baumannii per thigh or lung at 24 h) (killing effect of sulbactam (log 10 CFU of the A. baumannii per thigh or lung at 24 h))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.52,      // [log 10 CFU/Organ]
    Emax = -5.19,  // [log 10 CFU/Organ]
    EC50 = 0.446,  // [1; % × 0.01]
    gamma = 2.93,
    exposure_per_s = 0.01);   // 1 % per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 450, Interval = 0.9),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sulbactam</h4><p>Sulbactam is an antibiotic that works as a beta-lactamase inhibitor, used in combination with other antibacterials to treat bacterial infections. It is an approved medicine and is used in clinical practice, though it is not an authorised EU medicine via the EMA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423393\">Wikidata Q423393</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sulbactam_Yokoyama2014_PD_killing_effect_of_sulbactam_log_10</h4><p>The steady-state exposure-response curve of Yokoyama Y et al., <i>International journal of antimicrobial agents 43(6):547–552</i> 2014 (<a href=\"https://doi.org/10.1016/j.ijantimicag.2014.02.012\">doi:10.1016/j.ijantimicag.2014.02.012</a>) — killing effect of sulbactam (log 10 CFU of the A. baumannii per thigh or lung at 24 h) [log 10 CFU/thigh] against sulbactam % — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.52 log 10 CFU/Organ drug-free response (baseline) (E 0, Q324)
  Emax  =       5.19 log 10 CFU/Organ maximal effect term (E max, Q323)
  EC50  =       44.6 %        exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       2.93          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one % of sulbactam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.52   (drug-free)
  exposure = EC50 (44.6 %)  response -2.075
  exposure -> infinity  response -4.67</pre></body></html>"));
end Sulbactam_Yokoyama2014_PD_killing_effect_of_sulbactam_log_10;
