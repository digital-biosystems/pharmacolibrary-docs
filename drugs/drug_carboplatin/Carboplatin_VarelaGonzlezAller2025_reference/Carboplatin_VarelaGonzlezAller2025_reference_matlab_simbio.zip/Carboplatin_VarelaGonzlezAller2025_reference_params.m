function p = Carboplatin_VarelaGonzlezAller2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carboplatin   source: Varela-González-Aller_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Carboplatin_VarelaGonzlezAller2025_reference_params';
  p.drug  = 'carboplatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 41.2;                % central volume [L]
  p.CL = 3.6;                % clearance [L/h]
  p.Vp = [14.5];             % peripheral volumes [L]
  p.Q  = [4.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
