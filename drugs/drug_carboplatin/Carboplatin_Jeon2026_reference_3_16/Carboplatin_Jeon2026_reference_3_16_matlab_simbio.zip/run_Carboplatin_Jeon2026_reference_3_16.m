% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Carboplatin_Jeon2026_reference_3_16_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
