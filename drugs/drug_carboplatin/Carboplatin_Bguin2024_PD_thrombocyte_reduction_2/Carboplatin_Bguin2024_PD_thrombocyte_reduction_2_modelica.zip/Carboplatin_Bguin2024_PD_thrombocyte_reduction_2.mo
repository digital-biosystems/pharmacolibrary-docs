model Carboplatin_Bguin2024_PD_thrombocyte_reduction_2
  "sigmoid_emax exposure-response sweep — Béguin_2024 :: Thrombocyte reduction (Thrombocyte reduction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0076,  // [1; % × 0.01]
    EC50 = 9e-06,  // [1; mg/kg × 1e-06]
    gamma = 17.8,
    exposure_per_s = 1e-06);   // 1 mg/kg per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 90, Interval = 0.18),
    Documentation(info = "<html><body><!-- drug-about --><h4>About carboplatin</h4><p>Carboplatin is a platinum-based anticancer drug used to treat many cancers, including ovarian, breast, lung, head and neck, and brain cancers. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415588\">Wikidata Q415588</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Carboplatin_Bguin2024_PD_thrombocyte_reduction_2</h4><p>The steady-state exposure-response curve of Béguin J et al., <i>BMC veterinary research 20(1):575</i> 2024 (<a href=\"https://doi.org/10.1186/s12917-024-04404-1\">doi:10.1186/s12917-024-04404-1</a>) — Thrombocyte reduction [%] against carboplatin mg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.76 %        maximal effect term (Emax, Q320)
  EC50  =          9 mg/kg    exposure at half of the maximal effect term (E50, Q321)
  gamma =       17.8          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/kg of carboplatin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (9 mg/kg)  response 0.0038
  exposure -> infinity  response 0.0076</pre></body></html>"));
end Carboplatin_Bguin2024_PD_thrombocyte_reduction_2;
