function p = Carboplatin_Bguin2024_PD_thrombocyte_reduction_2_params()
% Carboplatin_Bguin2024_PD_thrombocyte_reduction_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carboplatin Béguin_2024::Thrombocyte_reduction::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg per second, in SI inside (kg/m3, s). Response Thrombocyte reduction in %. Driver: carboplatin (dose_only).
p.E0 = 0.0;
p.Emax = 0.0076;
p.EC50 = 9e-06;
p.gamma = 17.8;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 90.0;
p.form = 'E0 + Emax*frac';
end
