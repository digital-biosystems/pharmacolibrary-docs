function p = Carboplatin_Bguin2024_PD_thrombocyte_reduction_params()
% Carboplatin_Bguin2024_PD_thrombocyte_reduction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carboplatin Béguin_2024::Thrombocyte_reduction: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg.h/L per second, in SI inside (kg/m3, s). Response Thrombocyte reduction in %. Driver: carboplatin (pk_record).
p.E0 = 0.0;
p.Emax = 0.0099;
p.EC50 = 2679.0;
p.gamma = 3.35;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 27000.0;
p.form = 'E0 + Emax*frac';
end
