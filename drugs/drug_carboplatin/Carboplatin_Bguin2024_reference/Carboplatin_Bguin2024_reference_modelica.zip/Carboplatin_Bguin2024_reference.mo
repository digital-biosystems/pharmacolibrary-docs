model Carboplatin_Bguin2024_reference
  parameter Real Cl_ref = 0.00048027777777777777 "Cl [m3/s]";
  parameter Boolean cov_creatinine_0 = false "creatinine level 0";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Real Vd_ref = 0.4228 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref + (0.0009780555555555556)*(if cov_creatinine_0 then 1 else 0) + (0.0006650000000000001)*(if cov_category_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37125400000000003,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carboplatin</h4><p>Carboplatin is a platinum-based antineoplastic agent used to treat various cancers, including ovarian, lung, head and neck, and brain tumors. It is given by intravenous injection, either directly into a vein or through a port.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q415588\">Wikidata Q415588</a>, <a href=\"https://en.wikipedia.org/wiki/Carboplatin?oldid=1381050383\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carboplatin</td></tr><tr><td>population:</td><td>client owned dogs</td></tr><tr><td>source_paper:</td><td>Béguin_2024</td></tr><tr><td>measured_compound:</td><td>carboplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carboplatin 371.254 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV of Cl' routed out of structural estimates ('IIV of V ωv 0.1a -')</li><li>table section iiv: 'IIV of Cl' routed out of structural estimates ('IIV of V ωv 0.1a -')</li><li>table section iov: 'IOV of Cl' routed out of structural estimates ('IOV of V γV 0.1a -')</li><li>table section iov: 'IOV of Cl' routed out of structural estimates ('IOV of V γV 0.1a -')</li><li>table section residual_error: 'Additive constant of the combined error model' routed out of structural estimates ('Residual error model')</li><li>table section residual_error: 'Additive constant of the combined error model' routed out of structural estimates ('Residual error model')</li><li>table section residual_error: 'Proportional constant of the combined error model' routed out of structural estimates ('Residual error model')</li><li>table section residual_error: 'Proportional constant of the combined error model' routed out of structural estimates ('Residual error model')</li><li>covariate level 'Coefficient for the effect of creatinine plasma concentration (log-transformed) on clearance' → Q900:coefficient_for_the_effect_of_creatinine_plasma_concentration_log_transformed_on_clearance = 50.3 (additive_shift on Q22)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=carboplatin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carboplatin_Bguin2024_reference;
