function p = Carboplatin_Jeon2026_reference_2_15_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carboplatin   source: Jeon_2026 / reference_2_15   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Carboplatin_Jeon2026_reference_2_15_params';
  p.drug  = 'carboplatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.4;                % central volume [L]
  p.CL = 6.99;                % clearance [L/h]
  p.Vp = [24.8];             % peripheral volumes [L]
  p.Q  = [1.22];             % inter-compartmental clearances [L/h]
  p.ka = 0.26;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.058;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
