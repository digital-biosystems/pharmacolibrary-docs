model Carboplatin_Jeon2026_reference_2_15
  parameter Real Cl_ref = 1.941666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.014400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37125400000000003,
    adminMass = 0.0001,
    ka = 7.222222222222222e-05,
    Tlag = 208.8,
    k12 = 2.353395061728395e-05,
    k21 = 1.3664874551971325e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carboplatin</h4><p>Carboplatin is a platinum-based anticancer drug used to treat many cancers, including ovarian, breast, lung, head and neck, and brain cancers. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415588\">Wikidata Q415588</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carboplatin</td></tr><tr><td>population:</td><td>adult breast cancer patients with preserved renal function</td></tr><tr><td>source_paper:</td><td>Jeon_2026</td></tr><tr><td>measured_compound:</td><td>carboplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00398-t001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>carboplatin 371.254 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'reference 2 [15]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=carboplatin</li><li>population split: 'reference 2 [15]' subgroup of Jeon_2026 (paper reports 3 populations: reference 1 [14], reference 2 [15], reference 3 [16])</li><li>gap-filled Q49 (kabs) from Yang_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Centanni_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carboplatin_Jeon2026_reference_2_15;
