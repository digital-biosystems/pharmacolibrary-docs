function p = Carboplatin_Jeon2026_reference_1_14_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carboplatin   source: Jeon_2026 / reference_1_14   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Carboplatin_Jeon2026_reference_1_14_params';
  p.drug  = 'carboplatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.3;                % central volume [L]
  p.CL = 8.33;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.26;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.058;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
