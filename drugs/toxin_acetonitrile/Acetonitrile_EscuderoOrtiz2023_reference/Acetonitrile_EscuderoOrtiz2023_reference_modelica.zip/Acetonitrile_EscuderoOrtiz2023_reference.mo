model Acetonitrile_EscuderoOrtiz2023_reference
  parameter Real Cl_ref = 7.777777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10139260747367634 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.041053,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 2.79441805860346e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acetonitrile</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Escudero-Ortiz_2023</td></tr><tr><td>measured_compound:</td><td>acetonitrile</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>acetonitrile 41.053 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Escudero-Ortiz_2023) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Acetonitrile_EscuderoOrtiz2023_reference;
