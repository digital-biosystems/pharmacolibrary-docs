model Temazepam_Hua2025_temazepam_experimental_group
  parameter Real Cl_ref = 0.003251694444444444 "Cl [m3/s]";
  parameter Real Vd_ref = 28.6314 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.300742,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>temazepam</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Hua_2025</td></tr><tr><td>measured_compound:</td><td>Temazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>A164825TBL2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Temazepam 300.742 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is temazepam; the compartment is Temazepam. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Temazepam, not temazepam</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>temazepam's own concentration-time course is not produced by this model</li><li>conflicting source units for 'AUC (0 - t)': [{'unit': 'ug/L × h', 'source': 'A164825TBL2:row2:col1', 'scope': 'unit_column'}, {'unit': '0 - t', 'source': 'A164825TBL2:row2:col0', 'scope': 'label'}]</li><li>conflicting source units for 'MRT (0 - t)': [{'unit': 'h', 'source': 'A164825TBL2:row4:col1', 'scope': 'unit_column'}, {'unit': '0 - t', 'source': 'A164825TBL2:row4:col0', 'scope': 'label'}]</li><li>dropped duplicate Q88 ('AUC (0 - ∞)', value '71.84') — already have one for this compound</li><li>dropped duplicate Q53 ('MRT (0 - ∞)', value '2.51') — already have one for this compound</li><li>dropped value-less row: 'a Values are expressed as mean ± SD.'</li><li>dropped value-less row: 'b Significantly different from the control, P < 0.05.'</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 1 column 422 (char 421)) — units left missing</li><li>metabolite temazepam: Q76→Q376 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>metabolite temazepam: Q27→Q375 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Temazepam</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Temazepam_Hua2025_temazepam_experimental_group;
