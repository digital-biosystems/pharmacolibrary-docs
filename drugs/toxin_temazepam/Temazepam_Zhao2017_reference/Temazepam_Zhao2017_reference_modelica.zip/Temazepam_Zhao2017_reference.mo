// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Temazepam_Zhao2017_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {198900.0},
    MM = 0.300742,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>temazepam</td></tr><tr><td>population:</td><td>bluegill sunfish (Lepomis macrochirus)</td></tr><tr><td>source_paper:</td><td>Zhao_2017</td></tr><tr><td>measured_compound:</td><td>temazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>temazepam 300.742 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'temazepam' (equation variable)</li><li>dropped unlinked row (NIL): 'BCFs (methocarbamol)' — extend the ontology if this is a real PK parameter (source ['Zhao_2017:abstract'])</li><li>routed 'r2 (liver)' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'r2 (brain)' — extend the ontology if this is a real PK parameter (source ['Zhao_2017:abstract'])</li><li>relinked 'Ku' Q50 → Q47: a pool's clearance rate constant, not excretion into urine or faeces (the unit decides, not the label)</li><li>dropped duplicate Q47 ('Ke', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=temazepam</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: uptake rate constants, half-lives printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end Temazepam_Zhao2017_reference;
