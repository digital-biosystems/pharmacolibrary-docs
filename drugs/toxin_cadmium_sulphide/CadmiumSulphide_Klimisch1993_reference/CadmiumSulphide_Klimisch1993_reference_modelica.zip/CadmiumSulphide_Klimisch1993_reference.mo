// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model CadmiumSulphide_Klimisch1993_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {86400.0},
    MM = 0.11241,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cadmium_sulphide</td></tr><tr><td>population:</td><td>Rats</td></tr><tr><td>source_paper:</td><td>Klimisch_1993</td></tr><tr><td>measured_compound:</td><td>Cadmium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cadmium 112.41 g/mol (pubchem); cadmium_sulphide 144.47 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'null' (CL)</li><li>dropped unlinked row (NIL): 'deposited material was cleared during the 10-day exposure period' — extend the ontology if this is a real PK parameter (source ['Klimisch_1993:abstract'])</li><li>dropped unlinked row (NIL): 'CdCl2, only ... of the lung burden was cleared rapidly after the last exposure' — extend the ontology if this is a real PK parameter (source ['Klimisch_1993:abstract'])</li><li>dropped unlinked row (NIL): '47% slowly' — extend the ontology if this is a real PK parameter (source ['Klimisch_1993:abstract'])</li><li>dropped unlinked row (NIL): 'CdS, ... of the lung burden was cleared rapidly' — extend the ontology if this is a real PK parameter (source ['Klimisch_1993:abstract'])</li><li>dropped unlinked row (NIL): '40% slowly' — extend the ontology if this is a real PK parameter (source ['Klimisch_1993:abstract'])</li><li>dropped unlinked row (NIL): 'final residue' — extend the ontology if this is a real PK parameter (source ['Klimisch_1993:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cadmium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Cadmium', not cadmium_sulphide — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end CadmiumSulphide_Klimisch1993_reference;
