model Levamisole_KreeftmeijerVegter2015_reference
  parameter Real Cl_ref = 1.222222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.204291,
    adminMass = 0.00015,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levamisole</h4><p>Levamisole is an anthelmintic medication used to treat parasitic worm infections such as ascariasis and hookworm. It is given by mouth, usually as tablets, and is well absorbed from the gut. It is listed as an essential medicine but has been recommended for withdrawal from the European Union market.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417097\">Wikidata Q417097</a>, <a href=\"https://en.wikipedia.org/wiki/Levamisole?oldid=1374865877\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levamisole</td></tr><tr><td>population:</td><td>children with steroid-sensitive nephrotic syndrome</td></tr><tr><td>source_paper:</td><td>Kreeftmeijer-Vegter_2015</td></tr><tr><td>measured_compound:</td><td>levamisole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>levamisole 204.291 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'proportional effect of age on CL/F' — extend the ontology if this is a real PK parameter (source ['Kreeftmeijer-Vegter_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=levamisole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levamisole_KreeftmeijerVegter2015_reference;
