model Doravirine_Thoueille2024_reference
  parameter Real Cl_ref = 1.1055555555555557e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08220000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42574900000000004,
    adminMass = 0.0001,
    ka = 0.0005277777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doravirine</h4><p>Doravirine is an antiviral medicine used to treat HIV infections, acting as a non-nucleoside reverse transcriptase inhibitor. It is authorised in the European Union and is used in combination antiviral treatment for HIV.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6885419\">Wikidata Q6885419</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doravirine</td></tr><tr><td>population:</td><td>people with HIV (PWH)</td></tr><tr><td>source_paper:</td><td>Thoueille_2024</td></tr><tr><td>measured_compound:</td><td>doravirine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>doravirine 425.749 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimate (rse, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>kept covariate coefficient theta_Age=-0.670 (covariate Age) — not an ontology parameter</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (V (L)); Q22 (TVCL (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doravirine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Doravirine_Thoueille2024_reference;
