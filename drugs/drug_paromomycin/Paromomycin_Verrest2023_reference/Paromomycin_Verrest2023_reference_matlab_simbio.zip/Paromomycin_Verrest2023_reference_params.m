function p = Paromomycin_Verrest2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: paromomycin   source: Verrest_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Paromomycin_Verrest2023_reference_params';
  p.drug  = 'paromomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.6;                % central volume [L]
  p.CL = 2.62;                % clearance [L/h]
  p.Vp = [2.22];             % peripheral volumes [L]
  p.Q  = [0.26];             % inter-compartmental clearances [L/h]
  p.ka = 2.05;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1400.0;             % dose [mg]
end
