model Paromomycin_Verrest2023_reference
  parameter Real Cl_ref = 7.277777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0136 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6156285,
    adminMass = 0.0014,
    ka = 0.0005694444444444444,
    Tlag = 0.0,
    k12 = 5.31045751633987e-06,
    k21 = 3.253253253253253e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paromomycin</h4><p>Paromomycin is an antibiotic used to treat intestinal infections such as amebiasis and cryptosporidiosis. It is an approved medicine and appears on the WHO list of essential medicines, used mainly as an intestinal antiinfective.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415625\">Wikidata Q415625</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paromomycin</td></tr><tr><td>population:</td><td>children and adults with visceral leishmaniasis</td></tr><tr><td>source_paper:</td><td>Verrest_2023</td></tr><tr><td>measured_compound:</td><td>paromomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkad286-T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paromomycin 615.629 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'COVF,W1 (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'COVF,W1 (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'COVF,W1 (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'COVCL,neutrc (fractional change/103 cells/µL)' — extend the ontology if this is a real PK parameter (source ['dkad286-T3:row8:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paromomycin_Verrest2023_reference;
