% Run (SimBiology): build model + dose, simulate 0..34.0 h, plot.
p = Tolvaptan_Lanke2019_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 34.0);
