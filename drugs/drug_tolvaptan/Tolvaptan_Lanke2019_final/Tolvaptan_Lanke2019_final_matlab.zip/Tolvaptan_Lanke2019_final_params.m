function p = Tolvaptan_Lanke2019_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tolvaptan   source: Lanke_2019 / final   route: oral
  p.name  = 'Tolvaptan_Lanke2019_final_params';
  p.drug  = 'tolvaptan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 110.0;                % central volume [L]
  p.CL = 12.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.34;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
