model Tolvaptan_Lanke2019_final
  parameter Real Cl_ref = 3.5e-06 "Cl [m3/s]";
  parameter Real cov_egfr = 1.0 "egfr covariate (reference 1.0)";
  parameter Real cov_wt = 1.0 "wt covariate (reference 1.0)";
  parameter Real Vd_ref = 0.11 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_egfr/1.0)^(0.52)*(cov_wt/1.0)^(0.23),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.448941,
    adminMass = 1.5e-05,
    ka = 0.00037222222222222225,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tolvaptan</h4><p>Tolvaptan is a vasopressin receptor antagonist used to treat low blood sodium (hyponatremia) linked to heart failure, cirrhosis, or inappropriate antidiuretic hormone secretion, and is also authorised for autosomal dominant polycystic kidney disease. It remains in use, with authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426132\">Wikidata Q426132</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolvaptan</td></tr><tr><td>population:</td><td>adults with autosomal dominant polycystic kidney disease</td></tr><tr><td>source_paper:</td><td>Lanke_2019</td></tr><tr><td>measured_compound:</td><td>tolvaptan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1370-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tolvaptan 448.941 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'Covariance CL/F on Vd/F' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'Vd/F' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'Covariance CL/F on D1' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'Covariance V/F on D1' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'D1' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'Dose50' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section iiv: 'Dosemax' routed out of structural estimates ('Interindividual variability Mean (CV)')</li><li>table section residual_error: 'Additive' routed out of structural estimates ('Residual variability Mean (%CV) …')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual variability Mean (%CV) …')</li><li>covariate level 'Power coefficient eGFR on CL/F' → Q900:power_coefficient_egfr_on_cl_f = 0.52 (power on Q27)</li><li>dropped duplicate Q27 ('Fractional change of CL/F with Inha', value '-0.23') — already have one for this compound</li><li>covariate level 'Power coefficient WT on Vd/F' → Q900:power_coefficient_wt_on_vd_f = 0.23 (power on Q27)</li><li>dropped unlinked row (NIL): 'Dose50 (mg)' — extend the ontology if this is a real PK parameter (source ['jcph1370-tbl-0003:row9:col2'])</li><li>dropped unlinked row (NIL): 'Dosemax (mg)' — extend the ontology if this is a real PK parameter (source ['jcph1370-tbl-0003:row10:col2'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Tolvaptan_Lanke2019_final;
