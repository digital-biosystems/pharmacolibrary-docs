function p = Tolvaptan_Shoaf2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tolvaptan   source: Shoaf_2017 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Tolvaptan_Shoaf2017_reference_params';
  p.drug  = 'tolvaptan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 125.324898;                % central volume [L]
  p.CL = 20.202;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
