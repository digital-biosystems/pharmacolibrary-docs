function p = Tolvaptan_Van2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tolvaptan   source: Van_2013 / reference   route: oral
  p.name  = 'Tolvaptan_Van2013_reference_params';
  p.drug  = 'tolvaptan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 111.0;                % central volume [L]
  p.CL = 16.0;                % clearance [L/h]
  p.Vp = [31.2];             % peripheral volumes [L]
  p.Q  = [2.93];             % inter-compartmental clearances [L/h]
  p.ka = 0.832;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.154;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
