model Tolvaptan_Van2013_reference
  parameter Real Cl_ref = 4.444444444444444e-06 "Cl [m3/s]";
  parameter Boolean cov_nyha_class_1_or_2_0 = false "Nyha Class 1 Or 2";
  parameter Boolean cov_nyha_class_3_or_4_1 = false "Nyha Class 3 Or 4";
  parameter Boolean cov_child_pugh_score_6_l_h_2 = false "Child-Pugh Score ≥ 6 (L/H)";
  parameter Boolean cov_moderate_hyponatremia_3 = false "Moderate Hyponatremia";
  parameter Real Vd_ref = 0.111 "Vd [m3]";
  parameter Boolean cov_child_pugh_score_10_l_2 = false "Child-Pugh Score ≥ 10 (L)";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref + (-1.8583333333333333e-06)*(if cov_nyha_class_1_or_2_0 then 1 else 0) + (-2.4222222222222223e-06)*(if cov_nyha_class_3_or_4_1 then 1 else 0) + (-1.8666666666666664e-06)*(if cov_child_pugh_score_6_l_h_2 then 1 else 0) + (-8.11111111111111e-07)*(if cov_moderate_hyponatremia_3 then 1 else 0),
    Vd = Vd_ref + (-0.0445)*(if cov_nyha_class_1_or_2_0 then 1 else 0) + (-0.0541)*(if cov_nyha_class_3_or_4_1 then 1 else 0) + (0.0719)*(if cov_child_pugh_score_10_l_2 then 1 else 0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3e-05,
    ka = 0.0002311111111111111,
    Tlag = 554.4,
    k12 = 7.332332332332333e-06,
    k21 = 2.608618233618234e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolvaptan</td></tr><tr><td>population:</td><td>healthy subjects and patients with hyponatremia secondary to congestive heart failure or hepatic cirrhosis</td></tr><tr><td>source_paper:</td><td>Van_2013</td></tr><tr><td>measured_compound:</td><td>tolvaptan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'ω^2 for k_3'</li><li>dropped value-less row: 'ω^2 for CL/F'</li><li>dropped value-less row: 'ω^2 for V_c/F'</li><li>dropped value-less row: 'ω^2 for CL_d/F'</li><li>dropped value-less row: 'ω^2 for V_p/F'</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>theta_v1_f_cirrhosis_child_pugh_score_ge_10_l: label says 'decrease' but the reported value is 71.9 (positive) — curated as an INCREASE, per the printed number</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tolvaptan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tolvaptan_Van2013_reference;
