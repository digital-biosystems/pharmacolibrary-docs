model Tolvaptan_Bhatt2014_reference
  parameter Real Cl_ref = 6.253333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3702486386696127 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.448941,
    adminMass = 3e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tolvaptan</h4><p>Tolvaptan is a vasopressin receptor antagonist used to treat low blood sodium (hyponatremia) linked to heart failure, cirrhosis, or inappropriate antidiuretic hormone secretion, and is also authorised for autosomal dominant polycystic kidney disease. It remains in use, with authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426132\">Wikidata Q426132</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolvaptan</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bhatt_2014</td></tr><tr><td>measured_compound:</td><td>tolvaptan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tolvaptan 448.941 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bhatt_2014) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Tolvaptan_Bhatt2014_reference;
