model Metoprolol_Kir2025_reference
  parameter Real Cl_ref = 1.8713333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0987 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metoprolol</td></tr><tr><td>population:</td><td>malnourished and non-malnourished rats</td></tr><tr><td>source_paper:</td><td>Kir_2025</td></tr><tr><td>measured_compound:</td><td>atenolol and metoprolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('CL (mL/min/kg) Total clearance'=16.04) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('k 01 C (mg/min/kg) Apparent zero-order absorption rate constant 1 (t = 0-120 min)'=1.19) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V ss (L/kg) d Volume of distribution at steady-state'=1.41) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atenolol and metoprolol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metoprolol_Kir2025_reference;
