// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model LCarnitine_Haarhuis2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {28080.0},
    MM = 0.07511100000000001,
    adminMass = 0.0015,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_carnitine</td></tr><tr><td>population:</td><td>healthy, omnivorous adults</td></tr><tr><td>source_paper:</td><td>Haarhuis_2026</td></tr><tr><td>measured_compound:</td><td>TMAO</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>L-Carnitine 161.201 g/mol (pubchem); TMAO 75.111 g/mol (pubchem); Trimethylamine (TMA) 59.112 g/mol (pubchem); Trimethylamine N-oxide (TMAO) 75.111 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q47 ('β'=0.0067) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('TMAO t1/2 estimates placebo intervention'=7.8) from results prose — parameter table was unreadable</li><li>implicit units: 'β' → 1/h (from the popPK convention: 'The parameter is identified as an elimination rate constant (kel). For first-order rate constants, the standard unit in ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=TMAO</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>review gap-fill skipped: this record measures 'TMAO', not l_carnitine — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 280.8));
end LCarnitine_Haarhuis2026_reference;
