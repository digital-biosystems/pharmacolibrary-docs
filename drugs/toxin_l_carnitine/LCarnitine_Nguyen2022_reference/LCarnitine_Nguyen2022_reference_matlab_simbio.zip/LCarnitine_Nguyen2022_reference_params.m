function p = LCarnitine_Nguyen2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: l_carnitine   source: Nguyen_2022 / reference   route: oral
  p.name  = 'LCarnitine_Nguyen2022_reference_params';
  p.drug  = 'l_carnitine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 39.9;                % central volume [L]
  p.CL = 1.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
