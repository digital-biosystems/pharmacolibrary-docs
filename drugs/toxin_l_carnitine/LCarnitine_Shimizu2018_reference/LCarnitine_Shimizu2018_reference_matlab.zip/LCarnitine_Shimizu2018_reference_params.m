function p = LCarnitine_Shimizu2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: l_carnitine   source: Shimizu_2018 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'LCarnitine_Shimizu2018_reference_params';
  p.drug  = 'l_carnitine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.2;                % central volume [L]
  p.CL = 0.568;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
