function p = Ketoprofen_De1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketoprofen   source: De_1996 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ketoprofen_De1996_reference_params';
  p.drug  = 'ketoprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.7;                % central volume [L]
  p.CL = 11.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.63;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
