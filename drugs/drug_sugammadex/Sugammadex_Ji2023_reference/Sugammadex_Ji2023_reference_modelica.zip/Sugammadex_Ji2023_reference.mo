model Sugammadex_Ji2023_reference
  parameter Real Cl_ref = 1.1133333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00149 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 2.0021199999999997,
    adminMass = 0.00014,
    k12 = 0.0021029082774049216,
    k21 = 0.0013864306784660769
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sugammadex</h4><p>Sugammadex is an antidote used to reverse neuromuscular blockade caused by muscle relaxants during anaesthesia. It is approved and authorised in the European Union, where several sugammadex products are on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q81987842\">Wikidata Q81987842</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sugammadex</td></tr><tr><td>population:</td><td>Korean children aged 2-17 years</td></tr><tr><td>source_paper:</td><td>Ji_2023</td></tr><tr><td>measured_compound:</td><td>sugammadex</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13429-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sugammadex 2002.12 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q 2 (L∙min−1)', value '0.0247') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sugammadex</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sugammadex_Ji2023_reference;
