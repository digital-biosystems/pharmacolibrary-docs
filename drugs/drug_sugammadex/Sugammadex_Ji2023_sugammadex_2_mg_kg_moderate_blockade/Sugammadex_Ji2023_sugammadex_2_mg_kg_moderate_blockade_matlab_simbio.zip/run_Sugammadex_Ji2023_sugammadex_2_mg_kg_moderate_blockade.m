% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Sugammadex_Ji2023_sugammadex_2_mg_kg_moderate_blockade_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
