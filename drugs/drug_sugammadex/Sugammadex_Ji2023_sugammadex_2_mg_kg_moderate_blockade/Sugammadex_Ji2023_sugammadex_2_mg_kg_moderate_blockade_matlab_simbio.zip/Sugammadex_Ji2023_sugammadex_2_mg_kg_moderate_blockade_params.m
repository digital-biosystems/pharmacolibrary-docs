function p = Sugammadex_Ji2023_sugammadex_2_mg_kg_moderate_blockade_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sugammadex   source: Ji_2023 / sugammadex_2_mg_kg_moderate_blockade   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Sugammadex_Ji2023_sugammadex_2_mg_kg_moderate_blockade_params';
  p.drug  = 'sugammadex';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.9;                % central volume [L]
  p.CL = 4.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
