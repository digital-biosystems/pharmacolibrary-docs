model Sugammadex_Ji2023_sugammadex_2_mg_kg_moderate_blockade
  parameter Real Cl_ref = 1.1666666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0119 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 2.0021199999999997,
    adminMass = 0.00014
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sugammadex</h4><p>Sugammadex is an antidote used to reverse neuromuscular blockade. It is administered as an intravenous injection. The drug is authorised in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q81987842\">Wikidata Q81987842</a>, DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sugammadex</td></tr><tr><td>population:</td><td>Korean children</td></tr><tr><td>source_paper:</td><td>Ji_2023</td></tr><tr><td>measured_compound:</td><td>sugammadex</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13429-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sugammadex 2002.12 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'n = 8' (AUClast)</li><li>unit_dimension_unknown: 'n = 8' (AUC∞)</li><li>implicit units: 'AUClast (h-µg/mL)' → h·µg/mL (from the popPK convention: 'The paper text does not explicitly state the units for AUClast in Table 2, but defines AUClast as the area under the pla')</li><li>implicit units: 'AUCinf (h-µg/mL)' → h·µg/mL (from the popPK convention: 'Similar to AUClast, AUCinf represents the area under the curve from time zero to infinity. Since the drug concentration ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sugammadex</li><li>population split: 'sugammadex 2 mg/kg / moderate blockadeᵇ
(n = 8)' subgroup of Ji_2023 (paper reports 11 populations: age group 12 to <17 (yrs), age group 2 to <6 (yrs), age group 6 to <12 (yrs), placebo / intense blockadeᵃ
(n = 10), placebo / moderate blockadeᵇ
(n = 8), sugammadex 2 mg/kg / intense blockadeᵃ
(n = 10), sugammadex 2 mg/kg / moderate blockadeᵇ
(n = 8), sugammadex 4 mg/kg / intense blockadeᵃ
(n = 10), sugammadex 4 mg/kg / moderate blockadeᵇ
(n = 6), sugammadex 8 mg/kg / intense blockadeᵃ
(n = 10), sugammadex 8 mg/kg / moderate blockadeᵇ
(n = 7))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sugammadex_Ji2023_sugammadex_2_mg_kg_moderate_blockade;
