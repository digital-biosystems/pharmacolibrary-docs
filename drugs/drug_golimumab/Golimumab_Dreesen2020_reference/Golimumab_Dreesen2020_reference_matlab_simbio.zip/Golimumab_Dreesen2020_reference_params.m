function p = Golimumab_Dreesen2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: golimumab   source: Dreesen_2020 / reference   route: oral
  p.name  = 'Golimumab_Dreesen2020_reference_params';
  p.drug  = 'golimumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.64;                % central volume [L]
  p.CL = 0.018417;                % clearance [L/h]
  p.Vp = [4.48];             % peripheral volumes [L]
  p.Q  = [0.017917];             % inter-compartmental clearances [L/h]
  p.ka = 0.019708;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
