% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Labetalol_van2022_ferguson_et_al_63_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
