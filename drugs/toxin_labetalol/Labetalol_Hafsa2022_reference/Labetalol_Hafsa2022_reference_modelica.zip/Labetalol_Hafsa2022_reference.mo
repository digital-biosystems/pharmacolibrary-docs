model Labetalol_Hafsa2022_reference
  parameter Real Cl_ref = 1.75e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.328412,
    adminMass = 0.0006,
    ka = 0.0055000000000000005,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>labetalol</td></tr><tr><td>population:</td><td>Healthy and diseased (renal and hepatic) patients</td></tr><tr><td>source_paper:</td><td>Hafsa_2022</td></tr><tr><td>measured_compound:</td><td>Labetalol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-02362-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>labetalol 328.412 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'pKa' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-02362-t002:row3:col1'])</li><li>dropped unlinked row (NIL): 'Lipophilicity (log units)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-02362-t002:row4:col1'])</li><li>dropped unlinked row (NIL): 'Specific organ permeability (L/min)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-02362-t002:row8:col1'])</li><li>dropped duplicate Q22 ('Specific clearance (L/h)', value '6') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Labetalol</li><li>gap-filled Q61 (V) from Bouchard_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Reimerink_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Bouchard_2021, Reimerink_2023 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Labetalol_Hafsa2022_reference;
