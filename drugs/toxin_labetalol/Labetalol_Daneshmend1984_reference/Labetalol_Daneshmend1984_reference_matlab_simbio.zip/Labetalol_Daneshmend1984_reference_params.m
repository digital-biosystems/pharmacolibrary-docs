function p = Labetalol_Daneshmend1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: labetalol   source: Daneshmend_1984 / reference   route: oral
  p.name  = 'Labetalol_Daneshmend1984_reference_params';
  p.drug  = 'labetalol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 520.0;                % central volume [L]
  p.CL = 0.48;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 19.8;                % absorption rate [1/h]
  p.F  = 0.303;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
