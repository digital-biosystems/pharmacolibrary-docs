model Labetalol_van2022_marin_et_al_67
  parameter Real Cl_ref = 4.047222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.43400000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.328412,
    adminMass = 1e-05,
    ka = 0.0055000000000000005,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>labetalol</td></tr><tr><td>population:</td><td>pregnant women</td></tr><tr><td>source_paper:</td><td>van_2022</td></tr><tr><td>measured_compound:</td><td>Labetalol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>labetalol 328.412 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Oral dose' — extend the ontology if this is a real PK parameter (source ['Tab5:row1:col2'])</li><li>dropped unlinked row (NIL): 'Maternal mean nifedipine concentration' — extend the ontology if this is a real PK parameter (source ['Tab5:row7:col2'])</li><li>salvaged Q57 ('Elimination half-life (t1/2)'=81) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Volume of distribution (Vd)'=6.2) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('mean CL/F of nifedipine at steady state'=145.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Labetalol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'marin et al. [67]' subgroup of van_2022 (paper reports 6 populations: ferguson et al. [63], haas et al. [60], haas et al. [64], marin et al. [67], papatsonis et al. [58], ter laak et al. [56])</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Reimerink_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Labetalol_van2022_marin_et_al_67;
