function p = Labetalol_van2022_marin_et_al_67_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: labetalol   source: van_2022 / marin_et_al_67   route: oral
  p.name  = 'Labetalol_van2022_marin_et_al_67_params';
  p.drug  = 'labetalol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 434.0;                % central volume [L]
  p.CL = 145.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 19.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
