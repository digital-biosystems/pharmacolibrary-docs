model Roxadustat_Czock2022_parameter_value
  parameter Real Cl_ref = 6.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>roxadustat</td></tr><tr><td>population:</td><td>chronic kidney disease patients</td></tr><tr><td>source_paper:</td><td>Czock_2022</td></tr><tr><td>measured_compound:</td><td>roxadustat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Dynamics E1 peak = Cpeak EPO', value None) — already have one for this compound</li><li>dropped PD-category row 'CE50 = roxadustat concentration producing half-maximum E1 EPO = 150 IU/L' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab2:row24:col3'])</li><li>dropped PD-category row 'Hill coefficient' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab2:row29:col3'])</li><li>dropped unlinked row (NIL): 'CE05 EPO = Cthreshold ROXA' — extend the ontology if this is a real PK parameter (source ['Tab2:row30:col3'])</li><li>dropped unlinked row (NIL): 'AUEC1 EPO' — extend the ontology if this is a real PK parameter (source ['Tab2:row31:col4', 'Tab2:row38:col3', 'Tab2:row38:col4'])</li><li>dropped unlinked row (NIL): 'Dose' — extend the ontology if this is a real PK parameter (source ['Czock_2022_table_1:row1:col7'])</li><li>unit_dimension_unknown: 'h·ng/mL per mg' (AUC)</li><li>unit_dimension_unknown: 'ng/mL per mg' (Cmax)</li><li>dropped duplicate Q32 ('Cmax (ng/mL per mg)', value '65') — already have one for this compound</li><li>dropped duplicate Q57 ('t½ or t½α and t½ß (h)', value '15.7') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=roxadustat</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Roxadustat_Czock2022_parameter_value;
