model Roxadustat_Czock2022_liver_cirrhosis_cp_b
  parameter Real Cl_ref = 6.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>roxadustat</td></tr><tr><td>population:</td><td>chronic kidney disease patients</td></tr><tr><td>source_paper:</td><td>Czock_2022</td></tr><tr><td>measured_compound:</td><td>roxadustat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Dose' — extend the ontology if this is a real PK parameter (source ['Czock_2022_table_1:row1:col7'])</li><li>unit_dimension_unknown: 'h·ng/mL per mg' (AUC)</li><li>unit_dimension_unknown: 'ng/mL per mg' (Cmax)</li><li>dropped unlinked row (NIL): 'UR (%)' — extend the ontology if this is a real PK parameter (source ['Czock_2022_table_1:row9:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=roxadustat</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'liver cirrhosis cp b' subgroup of Czock_2022 (paper reports 6 populations: eskd, healthy, liver cirrhosis cp b, parameter value, pharmacodynamics, severe renal impairment)</li><li>gap-filled Q76 (V/F) from Czock_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Roxadustat_Czock2022_liver_cirrhosis_cp_b;
