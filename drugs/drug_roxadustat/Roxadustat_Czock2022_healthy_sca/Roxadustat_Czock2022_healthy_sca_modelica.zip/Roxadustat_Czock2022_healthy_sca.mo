model Roxadustat_Czock2022_healthy_sca
  parameter Real Cl_ref = 6.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.352346,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About roxadustat</h4><p>Roxadustat is an antianemic medicine used to treat anemia in people with chronic kidney disease. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27088611\">Wikidata Q27088611</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>roxadustat</td></tr><tr><td>population:</td><td>healthy volunteers and chronic kidney disease patients</td></tr><tr><td>source_paper:</td><td>Czock_2022</td></tr><tr><td>measured_compound:</td><td>roxadustat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>roxadustat 352.346 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h·ng/mL per mg' (AUC)</li><li>unit_dimension_unknown: 'ng/mL per mg' (Cmax)</li><li>implicit units: 'AUC (h·ng/mL per mg)' → h·ng/mL (from the paper text: &quot;The table caption and footnotes define 'AUC area under the concentration-time curve'. The text explicitly reports Cmax i&quot;)</li><li>implicit units: 'Cmax (ng/mL per mg)' → ng/mL (from the paper text: &quot;The text explicitly states: 'an average peak roxadustat concentration of 69 ng/mL/mg... can be measured... (Table 1)' an&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=roxadustat</li><li>population split: 'healthy, sca' subgroup of Czock_2022 (paper reports 9 populations: eskd, healthy, healthy, fasting, healthy, fed, healthy, sca, kidney function - failure, kidney function - normal, liver cirrhosis cp b, severe renal impairment)</li><li>gap-filled Q76 (V/F) from Czock_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Roxadustat_Czock2022_healthy_sca;
