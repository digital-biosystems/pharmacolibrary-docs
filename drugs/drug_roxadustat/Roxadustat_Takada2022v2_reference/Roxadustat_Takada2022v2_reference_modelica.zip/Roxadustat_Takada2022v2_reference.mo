model Roxadustat_Takada2022v2_reference
  parameter Real Cl_ref = 2.538888888888889e-07 "Cl [m3/s]";
  parameter Boolean cov_age_0 = false "age level 0";
  parameter Real Vd_ref = 0.014400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref + (2.1972222222222227e-07)*(if cov_age_0 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.352346,
    adminMass = 2e-05,
    ka = 0.0001775,
    Tlag = 0.0,
    k12 = 2.5270061728395063e-06,
    k21 = 1.259131103421761e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About roxadustat</h4><p>Roxadustat is an antianemic medicine used to treat anemia in people with chronic kidney disease. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27088611\">Wikidata Q27088611</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>roxadustat</td></tr><tr><td>population:</td><td>Japanese dialysis-dependent chronic kidney disease patients with anaemia</td></tr><tr><td>source_paper:</td><td>Takada_2022_2</td></tr><tr><td>measured_compound:</td><td>roxadustat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp15023-tbl-0004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>roxadustat 352.346 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'SBUSE on F1' — extend the ontology if this is a real PK parameter (source ['bcp15023-tbl-0004:row7:col1', 'bcp15023-tbl-0004:row7:col2', 'bcp15023-tbl-0004:row7:col5', 'bcp15023-tbl-0004:row7:col6'])</li><li>dropped unlinked row (NIL): 'CUSE on F1' — extend the ontology if this is a real PK parameter (source ['bcp15023-tbl-0004:row8:col1', 'bcp15023-tbl-0004:row8:col2', 'bcp15023-tbl-0004:row8:col5', 'bcp15023-tbl-0004:row8:col6'])</li><li>dropped unlinked row (NIL): 'LUSE on F1' — extend the ontology if this is a real PK parameter (source ['bcp15023-tbl-0004:row9:col1', 'bcp15023-tbl-0004:row9:col2', 'bcp15023-tbl-0004:row9:col5', 'bcp15023-tbl-0004:row9:col6'])</li><li>dropped unlinked row (NIL): 'FUSE on F1' — extend the ontology if this is a real PK parameter (source ['bcp15023-tbl-0004:row10:col1', 'bcp15023-tbl-0004:row10:col2', 'bcp15023-tbl-0004:row10:col5', 'bcp15023-tbl-0004:row10:col6'])</li><li>dropped unlinked row (NIL): 'SCUSE on F1' — extend the ontology if this is a real PK parameter (source ['bcp15023-tbl-0004:row11:col1', 'bcp15023-tbl-0004:row11:col2', 'bcp15023-tbl-0004:row11:col5', 'bcp15023-tbl-0004:row11:col6'])</li><li>dropped unlinked row (NIL): 'No time separation of PBs in phase 2 on F1' — extend the ontology if this is a real PK parameter (source ['bcp15023-tbl-0004:row12:col1', 'bcp15023-tbl-0004:row12:col2', 'bcp15023-tbl-0004:row12:col5', 'bcp15023-tbl-0004:row12:col6'])</li><li>covariate level 'Age ≥65 y for CL' → Q900:age_ge_65_y_for_cl = 0.791 (additive_shift on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=roxadustat</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Roxadustat_Takada2022v2_reference;
