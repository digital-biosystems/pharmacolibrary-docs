function p = Roxadustat_Takada2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: roxadustat   source: Takada_2022_2 / reference   route: oral
  p.name  = 'Roxadustat_Takada2022v2_reference_params';
  p.drug  = 'roxadustat';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.4;                % central volume [L]
  p.CL = 0.914;                % clearance [L/h]
  p.Vp = [2.89];             % peripheral volumes [L]
  p.Q  = [0.131];             % inter-compartmental clearances [L/h]
  p.ka = 0.639;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
