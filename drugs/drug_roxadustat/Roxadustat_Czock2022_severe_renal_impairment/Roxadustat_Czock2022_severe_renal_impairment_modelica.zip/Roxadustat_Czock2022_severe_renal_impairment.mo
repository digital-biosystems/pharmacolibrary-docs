model Roxadustat_Czock2022_severe_renal_impairment
  parameter Real Cl_ref = 3.5000000000000004e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.034 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>roxadustat</td></tr><tr><td>population:</td><td>chronic kidney disease patients</td></tr><tr><td>source_paper:</td><td>Czock_2022</td></tr><tr><td>measured_compound:</td><td>roxadustat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Dose' — extend the ontology if this is a real PK parameter (source ['Czock_2022_table_1:row1:col7'])</li><li>unit_dimension_unknown: 'h·ng/mL per mg' (AUC)</li><li>unit_dimension_unknown: 'ng/mL per mg' (Cmax)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=roxadustat</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'severe renal impairment' subgroup of Czock_2022 (paper reports 6 populations: eskd, healthy, liver cirrhosis cp b, parameter value, pharmacodynamics, severe renal impairment)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Roxadustat_Czock2022_severe_renal_impairment;
