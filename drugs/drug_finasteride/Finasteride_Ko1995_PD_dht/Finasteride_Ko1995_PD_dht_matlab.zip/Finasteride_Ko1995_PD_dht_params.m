function p = Finasteride_Ko1995_PD_dht_params()
% Finasteride_Ko1995_PD_dht_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% finasteride Ko_1995::DHT: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response DHT in its own unit. Driver: finasteride (conc_no_pk).
p.E0 = 99.99999999999999;
p.Emax = 0.7;
p.EC50 = 1.2e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.12;
p.form = 'E0*(1 - Emax*frac)';
end
