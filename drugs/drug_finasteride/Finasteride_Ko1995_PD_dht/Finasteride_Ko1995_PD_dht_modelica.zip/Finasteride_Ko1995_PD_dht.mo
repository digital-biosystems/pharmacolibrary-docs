model Finasteride_Ko1995_PD_dht
  "indirect_response_i exposure-response sweep — Ko_1995 :: DHT (DHT concentrations)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 100,      // [1]
    Emax = 0.7,  // type I effect term
    EC50 = 1.2e-08,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (28/0.28 = 100) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.12, Interval = 0.00024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About finasteride</h4><p>Finasteride is used for prostate conditions such as benign prostatic enlargement and prostate cancer, and also for male pattern baldness. It is an approved medicine, widely used in urology and dermatology.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424167\">Wikidata Q424167</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Finasteride_Ko1995_PD_dht</h4><p>The steady-state exposure-response curve of Ko HC et al., <i>Pharmacotherapy 15(4):509–511</i> 1995 — DHT concentrations against finasteride ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        100          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =        0.7          maximal effect term (Emax, Q323)
  EC50  =      0.012 ng/ml    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of finasteride per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 100   (drug-free)
  exposure = EC50 (0.012 ng/ml)  response 65
  exposure -> infinity  response 30</pre></body></html>"));
end Finasteride_Ko1995_PD_dht;
