model Methylphenidate_Teuscher2018_PD_skamp_cs
  "emax exposure-response sweep — Teuscher_2018 :: SKAMP-CS (Swanson, Kotkin, Agler, M-Flynn, and Pelham Scale Combined score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -38,  // [units]
    EC50 = 1.424e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 150, Interval = 0.3),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methylphenidate</h4><p>Methylphenidate is a central nervous system stimulant prescribed for attention deficit hyperactivity disorder and narcolepsy. It is typically given orally, while a topical form exists for skin application. The medication is widely used and available as a generic option.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422112\">Wikidata Q422112</a>, <a href=\"https://en.wikipedia.org/wiki/Methylphenidate?oldid=1383115339\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Methylphenidate_Teuscher2018_PD_skamp_cs</h4><p>The steady-state exposure-response curve of Teuscher NS et al., <i>Journal of clinical psychopharmacology 38(5):467–474</i> 2018 (<a href=\"https://doi.org/10.1097/JCP.0000000000000944\">doi:10.1097/JCP.0000000000000944</a>) — Swanson, Kotkin, Agler, M-Flynn, and Pelham Scale Combined score [units] against methylphenidate ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         38 units    maximal effect term (maximal reduction in the Swanson, Kotkin, Agler, M-Flynn, and Pelham Scale Combined score, Q323)
  EC50  =      14.24 ng/mL    exposure at half of the maximal effect term (MPH concentration required to achieve 50% of the maximal reduction, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of methylphenidate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (14.24 ng/mL)  response -19
  exposure -> infinity  response -38</pre></body></html>"));
end Methylphenidate_Teuscher2018_PD_skamp_cs;
