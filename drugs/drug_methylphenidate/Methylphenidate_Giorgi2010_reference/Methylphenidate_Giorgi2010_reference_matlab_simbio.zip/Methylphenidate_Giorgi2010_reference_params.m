function p = Methylphenidate_Giorgi2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methylphenidate   source: Giorgi_2010 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methylphenidate_Giorgi2010_reference_params';
  p.drug  = 'methylphenidate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.7;                % central volume [L]
  p.CL = 18.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
