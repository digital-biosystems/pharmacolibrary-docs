function p = Tegafur_Kim2017_multiple_dose_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tegafur   source: Kim_2017 / multiple_dose   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Tegafur_Kim2017_multiple_dose_params';
  p.drug  = 'tegafur';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 35.0;                % central volume [L]
  p.CL = 7.56;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
