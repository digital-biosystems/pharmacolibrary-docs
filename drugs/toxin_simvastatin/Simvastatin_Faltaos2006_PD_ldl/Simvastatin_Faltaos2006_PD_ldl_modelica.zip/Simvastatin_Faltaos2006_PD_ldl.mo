model Simvastatin_Faltaos2006_PD_ldl
  "indirect_response_i exposure-response sweep — Faltaos_2006 :: LDL (LDL cholesterol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.21,  // type I effect term
    EC50 = 1.3e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><h4>Simvastatin_Faltaos2006_PD_ldl</h4><p>The steady-state exposure-response curve of Faltaos DW et al., <i>Fundamental &amp; clinical pharmacology 20(3):321-330</i> 2006 (<a href=\"https://doi.org/10.1111/j.1472-8206.2006.00404.x\">doi:10.1111/j.1472-8206.2006.00404.x</a>) — LDL cholesterol [g/L] against simvastatin mg — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.21          maximal effect term (Inhibition fraction, Q323)
  EC50  =        1.3 mg       exposure at half of the maximal effect term (Dose producing 50% increase of LDL removal, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg of simvastatin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.3 mg)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Simvastatin_Faltaos2006_PD_ldl;
