function p = Simvastatin_Faltaos2006_PD_ldl_params()
% Simvastatin_Faltaos2006_PD_ldl_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% simvastatin Faltaos_2006::LDL: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response LDL in g/L. Driver: simvastatin (dose_only).
p.E0 = 0.0;
p.Emax = 0.21;
p.EC50 = 1.3e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 13.0;
p.form = 'E0*(1 - Emax*frac)';
end
