// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Simvastatin_Wu2016_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {57600.0},
    MM = 0.418574,
    adminMass = 5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>simvastatin</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Wu_2016</td></tr><tr><td>measured_compound:</td><td>Simvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table6</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Simvastatin 418.574 g/mol (pubchem); Simvastatin acid 436.589 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for '9'; source reconciliation required</li><li>table representations disagree for '3'; source reconciliation required</li><li>table representations disagree for 'S'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>dropped unlinked row (NIL): '9' — extend the ontology if this is a real PK parameter (source ['Table6:row2:col2', 'Table6:row5:col2', 'Table6:row8:col2', 'Table6:row11:col2', 'Table6:row14:col2', 'Table6:row17:col2', 'Table6:row20:col2', 'Table6:row21:col2', 'Table6:row23:col2'])</li><li>dropped unlinked row (NIL): '3' — extend the ontology if this is a real PK parameter (source ['Table6:row3:col2', 'Table6:row6:col2', 'Table6:row9:col2', 'Table6:row12:col2', 'Table6:row15:col2', 'Table6:row18:col2', 'Table6:row24:col2'])</li><li>dropped PD-category row 'S' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Table6:row4:col2', 'Table6:row7:col2', 'Table6:row10:col2', 'Table6:row16:col2', 'Table6:row19:col2', 'Table6:row22:col2'])</li><li>dropped value-less row: '1S'</li><li>dropped value-less row: '2comparison of parameters with and without co-administration of GSK2647544 for the 9 subjects who received simvastatin with GSK26476544 (A1+S) and simvastatin alone (S)' (captured trailing unit 'S' for child rows)</li><li>dropped value-less row: '3'</li><li>dropped value-less row: '4'</li><li>salvaged Q57 ('t1/2'=16) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Simvastatin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Simvastatin_Wu2016_reference;
