model Simvastatin_Aggarwal2024_PD_ldl_c
  "emax exposure-response sweep — Aggarwal_2024 :: LDL-C (LDL-C)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.496,      // [kg/m3; mg/dL × 0.01]
    Emax = -0.798,  // [kg/m3; mg/dL × 0.01]
    EC50 = 1.31e-05,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><h4>Simvastatin_Aggarwal2024_PD_ldl_c</h4><p>The steady-state exposure-response curve of Aggarwal SK et al., <i>JACC. Advances 3(4)</i> 2024 (<a href=\"https://doi.org/10.1016/j.jacadv.2024.100894\">doi:10.1016/j.jacadv.2024.100894</a>) — LDL-C [mg/dL] against simvastatin mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      149.6 mg/dL    drug-free response (baseline) (E0, Q324)
  Emax  =       79.8 mg/dL    maximal effect term (Emax, Q323)
  EC50  =       13.1 mg       exposure at half of the maximal effect term (ED50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of simvastatin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.496   (drug-free)
  exposure = EC50 (13.1 mg)  response 1.097
  exposure -> infinity  response 0.698</pre></body></html>"));
end Simvastatin_Aggarwal2024_PD_ldl_c;
