function p = Simvastatin_Aggarwal2024_PD_ldl_c_params()
% Simvastatin_Aggarwal2024_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% simvastatin Aggarwal_2024::LDL_C: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response LDL-C in mg/dL. Driver: simvastatin (dose_only).
p.E0 = 1.4959999999999998;
p.Emax = -0.7979999999999998;
p.EC50 = 1.3099999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 140.0;
p.form = 'E0 + Emax*frac';
end
