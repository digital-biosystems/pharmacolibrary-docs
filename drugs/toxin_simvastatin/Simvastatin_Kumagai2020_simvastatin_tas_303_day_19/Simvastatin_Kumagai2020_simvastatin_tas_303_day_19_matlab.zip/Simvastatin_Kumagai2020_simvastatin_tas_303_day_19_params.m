function p = Simvastatin_Kumagai2020_simvastatin_tas_303_day_19_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Kumagai_2020 / simvastatin_tas_303_day_19   route: oral
  p.name  = 'Simvastatin_Kumagai2020_simvastatin_tas_303_day_19_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4452.0;                % central volume [L]
  p.CL = 1196.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.226;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
