% Run: build params, simulate 0..24.0 h, plot + save Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.m
here = fileparts(mfilename('fullpath'));
p = Simvastatin_Kumagai2020_simvastatin_tas_303_day_19_params();
out = simulate_pk(p, 0:0.05:24.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('simvastatin — Kumagai_2020 (oral)');
print(fig, fullfile(here, 'Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.json'), 'w');
try
  s.model = 'Simvastatin_Kumagai2020_simvastatin_tas_303_day_19'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Simvastatin_Kumagai2020_simvastatin_tas_303_day_19","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.png, Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.csv, Simvastatin_Kumagai2020_simvastatin_tas_303_day_19.json\n');
