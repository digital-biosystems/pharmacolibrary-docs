model Simvastatin_Kumagai2020_simvastatin_tas_303_day_19
  parameter Real Cl_ref = 0.00033224999999999997 "Cl [m3/s]";
  parameter Real Vd_ref = 4.452 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.418574,
    adminMass = 1e-06,
    ka = 0.0011738888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>simvastatin</td></tr><tr><td>population:</td><td>12 healthy participants</td></tr><tr><td>source_paper:</td><td>Kumagai_2020</td></tr><tr><td>measured_compound:</td><td>Simvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1583-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>simvastatin 418.574 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'AUC0–t, ng•h/mL' → ng·h/mL (from the paper text: &quot;The paper states: 'Corresponding values on day 19 ... for simvastatin ... AUC0‐t ... 4.527 ± 1.730 ng·h/mL'&quot;)</li><li>implicit units: 'AUC0–inf, ng•h/mL' → ng·h/mL (from the paper text: &quot;The paper states: 'Corresponding values on day 19 ... for simvastatin ... AUC0‐inf ... 4.878 ± 1.818 ng·h/mL'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Simvastatin</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'simvastatin + tas-303 (day 19)' subgroup of Kumagai_2020 (paper reports 2 populations: simvastatin + tas-303 (day 19), simvastatin alone (day 1))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chang_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Simvastatin_Kumagai2020_simvastatin_tas_303_day_19;
