% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Simvastatin_Kumagai2020_simvastatin_tas_303_day_19_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
