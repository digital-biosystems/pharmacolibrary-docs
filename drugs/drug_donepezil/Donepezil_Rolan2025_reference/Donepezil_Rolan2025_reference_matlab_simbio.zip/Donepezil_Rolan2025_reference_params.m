function p = Donepezil_Rolan2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Rolan_2025 / reference   route: oral
  p.name  = 'Donepezil_Rolan2025_reference_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 64.3;                % central volume [L]
  p.CL = 4.76;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.74;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.9;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
