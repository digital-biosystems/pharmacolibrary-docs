function p = Donepezil_Khwarg2024_final_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Khwarg_2024 / final_model   route: oral
  % estimated (absent from source): F
  p.name  = 'Donepezil_Khwarg2024_final_model_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 40.737;                % central volume [L]
  p.CL = 14.35;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.21;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.931;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
