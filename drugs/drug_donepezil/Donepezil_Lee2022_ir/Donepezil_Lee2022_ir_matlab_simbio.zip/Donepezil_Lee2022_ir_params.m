function p = Donepezil_Lee2022_ir_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Lee_2022 / ir   route: oral
  p.name  = 'Donepezil_Lee2022_ir_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2679.87;                % central volume [L]
  p.CL = 356.5074;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.73;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.54;             % absorption lag [h]
  p.dose = 4.562;             % dose [mg]
end
