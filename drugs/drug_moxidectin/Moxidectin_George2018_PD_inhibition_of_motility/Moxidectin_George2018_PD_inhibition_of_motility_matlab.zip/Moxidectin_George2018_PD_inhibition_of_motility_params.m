function p = Moxidectin_George2018_PD_inhibition_of_motility_params()
% Moxidectin_George2018_PD_inhibition_of_motility_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moxidectin George_2018::inhibition_of_motility: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response inhibition of motility in %. Driver: moxidectin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.8763;
p.EC50 = 5.22;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 53.0;
p.form = 'E0 + Emax*frac';
end
