model Moxidectin_George2018_PD_inhibition_of_motility
  "sigmoid_emax exposure-response sweep — George_2018 :: inhibition of motility (inhibition of motility)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.8763,  // [1; % × 0.01]
    EC50 = 5.22,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 53, Interval = 0.106),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moxidectin</h4><p>Moxidectin is an anthelmintic used to prevent or control parasitic worms in animals. It is administered orally in solution or tablet form. It is a veterinary agent used in dogs, cats, horses, and other livestock.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q903824\">Wikidata Q903824</a>, <a href=\"https://en.wikipedia.org/wiki/Moxidectin?oldid=1369662158\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moxidectin_George2018_PD_inhibition_of_motility</h4><p>The steady-state exposure-response curve of George MM et al., <i>International journal for parasitology. Drugs and drug resistance 8(1):22–30</i> 2018 (<a href=\"https://doi.org/10.1016/j.ijpddr.2017.12.002\">doi:10.1016/j.ijpddr.2017.12.002</a>) — inhibition of motility [%] against moxidectin μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      87.63 %        maximal effect term (MI(%), Q323)
  EC50  =       5.22 μM       exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of moxidectin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.22 μM)  response -0.4381
  exposure -> infinity  response -0.8763</pre></body></html>"));
end Moxidectin_George2018_PD_inhibition_of_motility;
