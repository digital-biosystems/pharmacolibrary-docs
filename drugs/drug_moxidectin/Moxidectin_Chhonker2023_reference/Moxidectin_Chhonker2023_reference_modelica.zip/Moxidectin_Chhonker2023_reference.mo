model Moxidectin_Chhonker2023_reference
  parameter Real Cl_ref = 1.0000000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.4108 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.63983,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moxidectin</h4><p>Moxidectin is an anthelmintic used to prevent or control parasitic worms in animals. It is administered orally in solution or tablet form. It is a veterinary agent used in dogs, cats, horses, and other livestock.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q903824\">Wikidata Q903824</a>, <a href=\"https://en.wikipedia.org/wiki/Moxidectin?oldid=1369662158\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxidectin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chhonker_2023</td></tr><tr><td>measured_compound:</td><td>moxidectin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>moxidectin 639.83 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chhonker_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end Moxidectin_Chhonker2023_reference;
