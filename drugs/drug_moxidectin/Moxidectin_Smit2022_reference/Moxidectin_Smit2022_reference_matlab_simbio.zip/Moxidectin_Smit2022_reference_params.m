function p = Moxidectin_Smit2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxidectin   source: Smit_2022 / reference   route: oral
  p.name  = 'Moxidectin_Smit2022_reference_params';
  p.drug  = 'moxidectin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 136.0;                % central volume [L]
  p.CL = 4.47;                % clearance [L/h]
  p.Vp = [1172.0];             % peripheral volumes [L]
  p.Q  = [10.0];             % inter-compartmental clearances [L/h]
  p.ka = 3.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.64;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
