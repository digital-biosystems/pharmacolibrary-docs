model Haloperidol_Li2022_reference
  parameter Real Cl_ref = 1.4361111111111113e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.49 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375868,
    adminMass = 5e-07,
    ka = 0.0003805555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>critically ill adult ICU patients with delirium</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>Haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00549-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.868 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CRP: C-reactive protein, CL: clearance, IIV-CL: inter-variability on clearance, Vd: volume of distribution.' routed out of structural estimates ('CRP: C-reactive protein, CL: clearance, IIV-CL: inter-variability on clearance, Vd: volume of distribution.')</li><li>salvaged Q22 ('The clearance of haloperidol'=51.7) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=1490) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Haloperidol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Li_2022:discussion_prose, Li_2022:other_prose, pharmaceutics-14-00549-t002:footnote); populations base model, final model kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Johnson_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Li2022_reference;
