function p = Haloperidol_Franken2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Franken_2017 / reference   route: oral
  p.name  = 'Haloperidol_Franken2017_reference_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1260.0;                % central volume [L]
  p.CL = 29.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.861;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 8.0;             % dose [mg]
end
