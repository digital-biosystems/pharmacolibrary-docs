model Haloperidol_Franken2017_reference
  parameter Real Cl_ref = 8.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.26 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.861,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375868,
    adminMass = 8e-06,
    ka = 0.0003805555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>terminally ill adult patients</td></tr><tr><td>source_paper:</td><td>Franken_2017</td></tr><tr><td>measured_compound:</td><td>Haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.868 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vd' routed out of structural estimates ('IIV (%)')</li><li>table representations disagree for 'F'; source reconciliation required</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'Vd (L)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Haloperidol</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Johnson_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Franken2017_reference;
