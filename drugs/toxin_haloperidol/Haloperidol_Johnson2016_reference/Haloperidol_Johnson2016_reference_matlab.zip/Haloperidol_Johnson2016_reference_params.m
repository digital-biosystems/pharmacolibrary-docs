function p = Haloperidol_Johnson2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Johnson_2016 / reference   route: oral
  p.name  = 'Haloperidol_Johnson2016_reference_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 719.0;                % central volume [L]
  p.CL = 8.58;                % clearance [L/h]
  p.Vp = [1500.0];             % peripheral volumes [L]
  p.Q  = [140.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 8.0;             % dose [mg]
end
