function p = Haloperidol_Li2022_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Li_2022 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'Haloperidol_Li2022_base_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1450.0;                % central volume [L]
  p.CL = 54.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
