model Haloperidol_Li2022_final
  parameter Real Cl_ref = 1.4361111111111113e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.49 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375868,
    adminMass = 5e-07,
    ka = 0.0003805555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>critically ill adult ICU patients with delirium</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>Haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00549-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.868 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CRP: C-reactive protein, CL: clearance, IIV-CL: inter-variability on clearance, Vd: volume of distribution.' routed out of structural estimates ('CRP: C-reactive protein, CL: clearance, IIV-CL: inter-variability on clearance, Vd: volume of distribution.')</li><li>dropped unlinked row (NIL): 'CRP' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00549-t002:row4:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Haloperidol</li><li>model-stage split: 'final model' is the final model of Li_2022 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Johnson_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Li2022_final;
