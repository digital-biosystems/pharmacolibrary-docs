// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Digitoxin_Bodem1975_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {734400.0},
    MM = 0.76495,
    adminMass = 1.0000000000000001e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>digitoxin</td></tr><tr><td>population:</td><td>patients</td></tr><tr><td>source_paper:</td><td>Bodem_1975</td></tr><tr><td>measured_compound:</td><td>digitoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>digitoxin 764.95 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '63% (i.v.) and 53% (p.o.) of the chlorofrom-extracted 3H-activity in the urine could be attributed to digitoxin by means of thin-layer chromatography' — extend the ontology if this is a real PK parameter (source ['Bodem_1975:abstract', 'Bodem_1975:abstract'])</li><li>dropped unlinked row (NIL): 'The volatile content of plasma radioactivity was 4.07 +/- 0.1% (i.v.) and 6.78 +/- 0.2% (p.o.)' — extend the ontology if this is a real PK parameter (source ['Bodem_1975:abstract', 'Bodem_1975:abstract'])</li><li>implicit units: '20.9 +/- 3.6% (i.v.) and 21.3 +/- 2.9% (p.o.) of the radioactive dose were excreted into the urine in 6 days' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=digitoxin</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Jin_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 8467.2));
end Digitoxin_Bodem1975_reference;
