// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Digitoxin_Bauer1987_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {788400.0},
    MM = 0.76495,
    adminMass = 1.0000000000000001e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>digitoxin</td></tr><tr><td>population:</td><td>cats</td></tr><tr><td>source_paper:</td><td>Bauer_1987</td></tr><tr><td>measured_compound:</td><td>Digitoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Digitoxin 764.95 g/mol (pubchem); Dihydro-digitoxin (DHD) 766.966 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'digitoxin to DHD' — extend the ontology if this is a real PK parameter (source ['Bauer_1987:abstract'])</li><li>dropped unlinked row (NIL): 'P' — extend the ontology if this is a real PK parameter (source ['Bauer_1987:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Digitoxin</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 0 linked by role; re-tagged Digitoxin→Digitoxin-bisdigitoxoside (Dt-2) ×1</li><li>molar mass: no plausible PubChem entry for 'Digitoxin-bisdigitoxoside (Dt-2)' ('Digitoxin-bisdigitoxoside') — left in mass units</li><li>molar mass: none found for 'Digitoxin-bisdigitoxoside (Dt-2)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Jin_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 8467.2));
end Digitoxin_Bauer1987_reference;
