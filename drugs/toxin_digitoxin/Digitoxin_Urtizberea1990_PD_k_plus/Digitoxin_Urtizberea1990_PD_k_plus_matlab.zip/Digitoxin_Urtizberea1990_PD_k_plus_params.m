function p = Digitoxin_Urtizberea1990_PD_k_plus_params()
% Digitoxin_Urtizberea1990_PD_k_plus_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% digitoxin Urtizberea_1990::K_plus: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response K_plus in its own unit. Driver: digitoxin (cited_pk).
p.E0 = 0.455;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0196;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
