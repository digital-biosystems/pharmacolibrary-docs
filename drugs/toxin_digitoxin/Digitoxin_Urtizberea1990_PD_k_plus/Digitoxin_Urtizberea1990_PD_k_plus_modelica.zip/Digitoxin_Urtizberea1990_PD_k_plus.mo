model Digitoxin_Urtizberea1990_PD_k_plus
  "linear exposure-response sweep — Urtizberea_1990 :: K_plus (plasma potassium)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0.455,      // [1]
    slope = 0.0196,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Digitoxin_Urtizberea1990_PD_k_plus</h4><p>The steady-state exposure-response curve of Urtizberea M et al., <i>Toxicology in vitro : an international journal published in association with BIBRA 4(4-5):526–531</i> 1990 (<a href=\"https://doi.org/10.1016/0887-2333(90)90112-7\">doi:10.1016/0887-2333(90)90112-7</a>) — plasma potassium against digitoxin — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.455          drug-free response (baseline) (b, Q324)
  slope =     0.0196          change in response per unit of exposure (a, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of digitoxin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.455   (drug-free)</pre></body></html>"));
end Digitoxin_Urtizberea1990_PD_k_plus;
