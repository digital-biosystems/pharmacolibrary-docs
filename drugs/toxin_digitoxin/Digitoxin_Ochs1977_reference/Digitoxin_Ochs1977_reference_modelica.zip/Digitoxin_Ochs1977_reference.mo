model Digitoxin_Ochs1977_reference
  parameter Real Cl_ref = 1.5e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0861 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.76495,
    adminMass = 1.0000000000000001e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>digitoxin</td></tr><tr><td>population:</td><td>male rhesus monkeys</td></tr><tr><td>source_paper:</td><td>Ochs_1977</td></tr><tr><td>measured_compound:</td><td>Digitoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>digitoxin 764.95 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'tb, h' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'tp, h' — extend the ontology if this is a real PK parameter (source ['Ochs_1977:table ii_flattened', 'Ochs_1977:table ii_flattened', 'Ochs_1977:table ii_flattened'])</li><li>dropped unlinked row (NIL): 'VI, literlkg' — extend the ontology if this is a real PK parameter (source ['Ochs_1977:table ii_flattened', 'Ochs_1977:table ii_flattened', 'Ochs_1977:table ii_flattened'])</li><li>unit_dimension_unknown: 'literlkg' (V)</li><li>unit_dimension_unknown: 'mllmin' (CL)</li><li>implicit units: 'Vd, literlkg' → L/kg (from the paper text: &quot;TABLE II explicitly lists 'Vd, literlkg' and the value '1.23' under the column 'Mean (+SEM) ... (n=6)'. The unit 'literl&quot;)</li><li>implicit units: 'Clearance' → mL/min (from the paper text: &quot;TABLE II explicitly lists 'Clearance mllmin' and the value '0.90' under the column 'Mean (+SEM) ... (n=6)'. The unit 'ml&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Digitoxin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Digitoxin_Ochs1977_reference;
