// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Plutonium_Dumit2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7485989.550047409},
    MM = 0.2440642,
    adminMass = 0.001,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>plutonium</td></tr><tr><td>population:</td><td>female former nuclear worker</td></tr><tr><td>source_paper:</td><td>Dumit_2025</td></tr><tr><td>measured_compound:</td><td>Plutonium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>plutonium 244.064 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Intake (Bq)'; source reconciliation required</li><li>table representations disagree for 'Intake (Bq)'; source reconciliation required</li><li>table representations disagree for 'AMAD (μm)'; source reconciliation required</li><li>table representations disagree for 'AMAD (μm)'; source reconciliation required</li><li>table representations disagree for 'sp (d−1)'; source reconciliation required</li><li>table representations disagree for 'sp (d−1)'; source reconciliation required</li><li>table representations disagree for 'spl (d−1)'; source reconciliation required</li><li>table representations disagree for 'spl (d−1)'; source reconciliation required</li><li>table representations disagree for 'st (d−1)'; source reconciliation required</li><li>table representations disagree for 'st (d−1)'; source reconciliation required</li><li>table representations disagree for 'Effective dose, E(50)'; source reconciliation required</li><li>table representations disagree for 'Effective dose, E(50)'; source reconciliation required</li><li>table representations disagree for 'Equivalent dose to the bone surfaces, HBSS(50)'; source reconciliation required</li><li>table representations disagree for 'Equivalent dose to the bone surfaces, HBSS(50)'; source reconciliation required</li><li>table representations disagree for 'Equivalent dose to the liver, HLI(50)'; source reconciliation required</li><li>table representations disagree for 'Equivalent dose to the liver, HLI(50)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Plutonium_Dumit2025_reference;
