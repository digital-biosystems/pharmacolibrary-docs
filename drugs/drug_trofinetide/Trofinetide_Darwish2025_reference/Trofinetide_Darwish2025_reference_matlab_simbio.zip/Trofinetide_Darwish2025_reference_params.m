function p = Trofinetide_Darwish2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trofinetide   source: Darwish_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Trofinetide_Darwish2025_reference_params';
  p.drug  = 'trofinetide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.89;                % central volume [L]
  p.CL = 2.02;                % clearance [L/h]
  p.Vp = [5.46];             % peripheral volumes [L]
  p.Q  = [6.17];             % inter-compartmental clearances [L/h]
  p.ka = 4.09;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 6000.0;             % dose [mg]
end
