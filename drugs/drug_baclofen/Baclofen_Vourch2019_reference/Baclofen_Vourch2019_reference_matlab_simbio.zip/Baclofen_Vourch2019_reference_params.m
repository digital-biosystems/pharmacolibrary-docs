function p = Baclofen_Vourch2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: baclofen   source: Vourch_2019 / reference   route: oral
  p.name  = 'Baclofen_Vourch2019_reference_params';
  p.drug  = 'baclofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 105.0;                % central volume [L]
  p.CL = 13.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.37;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
