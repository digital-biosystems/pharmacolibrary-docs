// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Nordiazepam_Wang2022_og
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1931184.0000000002},
    MM = 0.270716,
    adminMass = 5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nordiazepam</td></tr><tr><td>population:</td><td>healthy Chinese adult volunteers</td></tr><tr><td>source_paper:</td><td>Wang_2022</td></tr><tr><td>measured_compound:</td><td>nordiazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>nordiazepam 270.716 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'TG temazepam glucuronide, OG oxazepam glucuronide, AUCt area under the curve, t½z elimination half-life, Tmax time to Cmax, Cmax maximum concentration, CLz/F clearance'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nordiazepam</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'og' subgroup of Wang_2022 (paper reports 3 populations: diazepam, nordiazepam, og)</li><li>row roles (LLM): model_class=noncompartmental; 0/6 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'diazepam' — its concentrations stay mass-only</li><li>molar mass: none found for 'temazepam glucuronide' — its concentrations stay mass-only</li><li>molar mass: none found for 'oxazepam glucuronide' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9676800, Tolerance = 1e-9, Interval = 19353.6));
end Nordiazepam_Wang2022_og;
