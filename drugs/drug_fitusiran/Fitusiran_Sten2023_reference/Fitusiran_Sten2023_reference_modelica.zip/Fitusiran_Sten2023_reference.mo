model Fitusiran_Sten2023_reference
  parameter Real Cl_ref = 7.694444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027899999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00017638888888888888,
    Tlag = 0.0,
    k12 = 2.60852250099562e-05,
    k21 = 4.950869236583523e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fitusiran</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Sten_2023</td></tr><tr><td>measured_compound:</td><td>fitusiran</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Sten_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fitusiran_Sten2023_reference;
