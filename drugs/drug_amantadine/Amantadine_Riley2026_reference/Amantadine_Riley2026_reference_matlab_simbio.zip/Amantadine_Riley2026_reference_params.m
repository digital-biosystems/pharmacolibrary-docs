function p = Amantadine_Riley2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amantadine   source: Riley_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amantadine_Riley2026_reference_params';
  p.drug  = 'amantadine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 223.3;                % central volume [L]
  p.CL = 94.08;                % clearance [L/h]
  p.Vp = [151.9];             % peripheral volumes [L]
  p.Q  = [28.476];             % inter-compartmental clearances [L/h]
  p.ka = 3.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 210.0;             % dose [mg]
end
