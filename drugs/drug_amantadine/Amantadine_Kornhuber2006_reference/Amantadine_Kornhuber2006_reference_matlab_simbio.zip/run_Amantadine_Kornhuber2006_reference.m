% Run (SimBiology): build model + dose, simulate 0..840.0 h, plot.
p = Amantadine_Kornhuber2006_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 840.0);
