model Deoxynivalenol_Kang2023_reference
  parameter Real Cl_ref = 6.805555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1974 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29631,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>deoxynivalenol</td></tr><tr><td>population:</td><td>Dezhou male donkeys</td></tr><tr><td>source_paper:</td><td>Kang_2023</td></tr><tr><td>measured_compound:</td><td>Deoxynivalenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>toxins-15-00426-t004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>deoxynivalenol 296.31 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'DON intake (mg)' — extend the ontology if this is a real PK parameter (source ['toxins-15-00426-t004:row1:col1'])</li><li>dropped duplicate Q91 ('DON excretion through urine (mg)', value '13.12') — already have one for this compound</li><li>dropped duplicate Q44 ('DON excretion through urine (%)', value '19.98') — already have one for this compound</li><li>dropped 'Absorption rate (%)' → Q49: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a rate — the row is a variability or a ratio, not the estimate</li><li>dropped unlinked row (NIL): 'Body weight (kg)' — extend the ontology if this is a real PK parameter (source ['Kang_2023_table_3:row0:col1'])</li><li>dropped unlinked row (NIL): 'Single oral dose of DON (μg·kg·BW−1)' — extend the ontology if this is a real PK parameter (source ['Kang_2023_table_3:row1:col1'])</li><li>unit_dimension_unknown: 'L·kg·BW−1·h−1' (CL)</li><li>unit_dimension_unknown: 'L·kg·BW−1' (V)</li><li>implicit units: 'Cl (L·kg·BW−1·h−1)' → L/kg/h (from the paper text: 'The parameter label provided in the prompt explicitly states the unit as (L·kg·BW−1·h−1), which is equivalent to L/kg/h.')</li><li>implicit units: 'Vd (L·kg·BW−1)' → L/kg (from the paper text: 'The parameter label provided in the prompt explicitly states the unit as (L·kg·BW−1), which is equivalent to L/kg.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Deoxynivalenol</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Deoxynivalenol_Kang2023_reference;
