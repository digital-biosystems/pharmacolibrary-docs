// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Deoxynivalenol_Lo2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3185.4},
    MM = 0.29631,
    adminMass = 0.028,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>deoxynivalenol</td></tr><tr><td>population:</td><td>broiler chickens</td></tr><tr><td>source_paper:</td><td>Lo_2022</td></tr><tr><td>measured_compound:</td><td>Deoxynivalenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Deoxynivalenol 296.31 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q47 ('ke'=0.013) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('T1/2e'=53.09) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Deoxynivalenol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'Deoxynivalenol-sulphate' ('Deoxynivalenol-sulphate') — left in mass units</li><li>molar mass: none found for 'Deoxynivalenol-sulphate' — its concentrations stay mass-only</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Deoxynivalenol_Lo2022_reference;
