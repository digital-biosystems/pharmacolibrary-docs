// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Chlorambucil_AlNadaf2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6480.0},
    MM = 0.304211,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chlorambucil</td></tr><tr><td>population:</td><td>cats with indolent lymphoproliferative malignancies</td></tr><tr><td>source_paper:</td><td>Al-Nadaf_2022</td></tr><tr><td>measured_compound:</td><td>chlorambucil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>chlorambucil 304.211 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'percent coefficient of variation (%CV)' — extend the ontology if this is a real PK parameter (source ['Al-Nadaf_2022:abstract'])</li><li>unit_dimension_mismatch: 'peak plasma concentration ... within' → Q32 (unit '[time]' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q32 ('peak plasma concentration ... within', value 15) — already have one for this compound</li><li>routed '%CV' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=chlorambucil</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Yasuda_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Chlorambucil_AlNadaf2022_reference;
