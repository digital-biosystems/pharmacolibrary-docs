function p = Ziprasidone_Huang2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ziprasidone   source: Huang_2021 / reference   route: oral
  p.name  = 'Ziprasidone_Huang2021_reference_params';
  p.drug  = 'ziprasidone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1720.0;                % central volume [L]
  p.CL = 61.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.18;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
