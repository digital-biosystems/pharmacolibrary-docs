function p = Ziprasidone_Bao2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ziprasidone   source: Bao_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ziprasidone_Bao2024_reference_params';
  p.drug  = 'ziprasidone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 110.24;                % central volume [L]
  p.CL = 18.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
