function p = Ticagrelor_Amilon2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ticagrelor   source: Amilon_2019 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ticagrelor_Amilon2019_reference_params';
  p.drug  = 'ticagrelor';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.0;                % central volume [L]
  p.CL = 8.51;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.48;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
