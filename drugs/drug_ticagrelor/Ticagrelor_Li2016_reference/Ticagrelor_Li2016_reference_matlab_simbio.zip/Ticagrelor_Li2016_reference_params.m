function p = Ticagrelor_Li2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ticagrelor   source: Li_2016 / reference   route: oral
  p.name  = 'Ticagrelor_Li2016_reference_params';
  p.drug  = 'ticagrelor';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 221.0;                % central volume [L]
  p.CL = 14.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.67;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 180.0;             % dose [mg]
end
