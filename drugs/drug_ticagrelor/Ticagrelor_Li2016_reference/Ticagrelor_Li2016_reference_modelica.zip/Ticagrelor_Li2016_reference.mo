model Ticagrelor_Li2016_reference
  parameter Real Cl_ref = 3.888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.221 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.522568,
    adminMass = 0.00018,
    ka = 0.00018611111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ticagrelor</h4><p>Ticagrelor is an antiplatelet medicine used to prevent blood clots in people with acute coronary syndrome, including heart attack and unstable angina. It is an approved drug authorised in the European Union and widely used for these heart conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420542\">Wikidata Q420542</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ticagrelor</td></tr><tr><td>population:</td><td>patients with acute coronary syndromes</td></tr><tr><td>source_paper:</td><td>Li_2016</td></tr><tr><td>measured_compound:</td><td>ticagrelor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>AR-C124910XX 478.518 g/mol (pubchem); ticagrelor 522.568 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'apparent ticagrelor clearance' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('apparent ticagrelor clearance', value 110) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ticagrelor</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 6/6 row label(s) assigned, 6 linked by role; re-tagged ticagrelor→parent ×9</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ticagrelor_Li2016_reference;
