// parent + metabolites (AR-C124910XX): PK_3M_9C — formed from central; parent 2, metabolites [2]
model Ticagrelor_strand2019_reference
  parameter Real Q27_ref = 4.611111111111111e-06 "CL/F (l h –1 ) [SI]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.156,
    Vd2 = 0.055799999999999995,
    q12 = 2.8888888888888894e-06,
    q21 = 2.8888888888888894e-06,
    q1_m11 = 0.22*(Q27_ref*(cov_weight/1.0)^(0.48)),
    CL1 = max((Q27_ref*(cov_weight/1.0)^(0.48)) - (0.22*(Q27_ref*(cov_weight/1.0)^(0.48))), 0),
    Vd1m1 = 0.00704,
    CLm1 = 2.833333333333333e-06,
    Vd2m1 = 0.0423,
    qm11_m12 = 1.225e-06,
    qm12_m11 = 1.225e-06,
    MW = 0.522568,
    MW_m1 = 0.478518,
    F = 1,
    ka = 0.0028055555555555555,
    Tlag = 1728.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 6e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ticagrelor</td></tr><tr><td>population:</td><td>stable coronary artery disease and prior myocardial infarction patients</td></tr><tr><td>source_paper:</td><td>Åstrand_2019</td></tr><tr><td>measured_compound:</td><td>ticagrelor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp13812-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of AR-C124910XX: fm=0.22 × CL; covariate effects applied (1): exponent_for_pru_error — typical subject by default</td></tr><tr><td>molar_masses:</td><td>ticagrelor 522.568 g/mol (drugbank); AR-C124910XX 478.518 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bsv (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped PD-category row 'PRU baseline ONSET/OFFSET' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row15:col3'])</li><li>dropped PD-category row 'EC 50 (nmol l –1 )' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row17:col1', 'bcp13812-tbl-0002:row17:col3'])</li><li>dropped unlinked row (NIL): 'PRU baseline ‐EC 50 correlation' — extend the ontology if this is a real PK parameter (source ['bcp13812-tbl-0002:row18:col3'])</li><li>dropped PD-category row 'E max (%)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row19:col1', 'bcp13812-tbl-0002:row19:col3'])</li><li>dropped PD-category row 'Steepness of exposure‐response (γ)' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row20:col1'])</li><li>covariate level 'Exponent for PRU error (α)' → Q900:exponent_for_pru_error = 0.48 (power on Q27)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Ticagrelor_strand2019_reference;
