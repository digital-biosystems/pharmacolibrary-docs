// parent + metabolites (AR-C124910XX): PK_3M_9C — formed from central; parent 2, metabolites [2]
model Ticagrelor_strand2019_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.156,
    Vd2 = 0.055799999999999995,
    q12 = 2.8888888888888894e-06,
    q21 = 2.8888888888888894e-06,
    q1_m11 = 1.0144444444444444e-06,
    CL1 = 3.596666666666667e-06,
    Vd1m1 = 0.00704,
    CLm1 = 2.833333333333333e-06,
    Vd2m1 = 0.0423,
    qm11_m12 = 1.225e-06,
    qm12_m11 = 1.225e-06,
    MW = 0.522568,
    MW_m1 = 0.478518,
    F = 1,
    ka = 0.0028055555555555555,
    Tlag = 1728.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 9e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ticagrelor</h4><p>Ticagrelor is an antiplatelet medicine used to prevent blood clots in people with acute coronary syndrome, including heart attack and unstable angina. It is an approved drug authorised in the European Union and widely used for these heart conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420542\">Wikidata Q420542</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ticagrelor</td></tr><tr><td>population:</td><td>adults with stable coronary artery disease or prior myocardial infarction</td></tr><tr><td>source_paper:</td><td>Åstrand_2019</td></tr><tr><td>measured_compound:</td><td>ticagrelor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp13812-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of AR-C124910XX: fm=0.22 × CL; dose 90 mg (paper)</td></tr><tr><td>molar_masses:</td><td>AR-C124910XX 478.518 g/mol (pubchem); ticagrelor 522.568 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (l h –1 )' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'Q/F (l h –1 )' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'KTR (h −1 )' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'F rel' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'CL m /F (l h –1 )' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'Vp m /F (l)' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'PRU baseline ONSET/OFFSET' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'EC 50 (nmol l –1 )' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'PRU baseline ‐EC 50 correlation' routed out of structural estimates ('BSV (%)')</li><li>table section iiv: 'E max (%)' routed out of structural estimates ('BSV (%)')</li><li>dropped PD-category row 'EC 50 (nmol l –1 )' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row17:col1'])</li><li>dropped PD-category row 'E max (%)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row19:col1'])</li><li>dropped PD-category row 'Steepness of exposure‐response (γ)' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp13812-tbl-0002:row20:col1'])</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ticagrelor</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [2]</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Ticagrelor_strand2019_reference;
