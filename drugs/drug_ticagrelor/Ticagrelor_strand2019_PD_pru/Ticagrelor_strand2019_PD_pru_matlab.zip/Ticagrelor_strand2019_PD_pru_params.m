function p = Ticagrelor_strand2019_PD_pru_params()
% Ticagrelor_strand2019_PD_pru_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ticagrelor Åstrand_2019::PRU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol l –1 per second, in SI inside (kg/m3, s). Response PRU in PRU. Driver: ticagrelor (pk_record).
p.E0 = 0.0;
p.Emax = -98.5;
p.EC50 = 0.000116;
p.gamma = 1.59;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1200.0;
p.form = 'E0 + Emax*frac';
end
