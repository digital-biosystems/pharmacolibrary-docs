model Ticagrelor_strand2019_PD_pru
  "sigmoid_emax exposure-response sweep — Åstrand_2019 :: PRU (P2Y12 reaction units)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -98.5,  // [PRU]
    EC50 = 0.000116,  // [mol/m3; nmol l –1 × 1e-06]
    gamma = 1.59,
    exposure_per_s = 1e-06);   // 1 nmol l –1 per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1160, Interval = 2.32));
end Ticagrelor_strand2019_PD_pru;
