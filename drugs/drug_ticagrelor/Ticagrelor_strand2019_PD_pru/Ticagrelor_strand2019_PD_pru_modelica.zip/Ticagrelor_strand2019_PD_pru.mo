model Ticagrelor_strand2019_PD_pru
  "sigmoid_emax exposure-response sweep — Åstrand_2019 :: PRU (P2Y12 reaction units)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -98.5,  // [PRU]
    EC50 = 0.000116,  // [mol/m3; nmol l –1 × 1e-06]
    gamma = 1.59,
    exposure_per_s = 1e-06);   // 1 nmol l –1 per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1200, Interval = 2.4),
    Documentation(info = "<html><body><h4>Ticagrelor_strand2019_PD_pru</h4><p>The steady-state exposure-response curve of Åstrand M et al., <i>British journal of clinical pharmacology 85(2):413–421</i> 2019 (<a href=\"https://doi.org/10.1111/bcp.13812\">doi:10.1111/bcp.13812</a>) — P2Y12 reaction units [PRU] against ticagrelor nmol l –1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       98.5 PRU      maximal effect term (E max (%) — Estimate, Q320)
  EC50  =        116 nmol l –1 exposure at half of the maximal effect term (EC 50 (nmol l –1 ) — Estimate, Q321)
  gamma =       1.59          Hill coefficient (Steepness of exposure‐response (γ) — Estimate, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol l –1 of ticagrelor per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (116 nmol l –1)  response -49.25
  exposure -> infinity  response -98.5</pre></body></html>"));
end Ticagrelor_strand2019_PD_pru;
