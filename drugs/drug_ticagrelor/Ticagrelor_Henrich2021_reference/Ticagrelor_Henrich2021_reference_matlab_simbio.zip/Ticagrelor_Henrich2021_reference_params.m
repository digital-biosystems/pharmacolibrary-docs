function p = Ticagrelor_Henrich2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ticagrelor   source: Henrich_2021 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ticagrelor_Henrich2021_reference_params';
  p.drug  = 'ticagrelor';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.0;                % central volume [L]
  p.CL = 8.51;                % clearance [L/h]
  p.Vp = [51.4];             % peripheral volumes [L]
  p.Q  = [3.19];             % inter-compartmental clearances [L/h]
  p.ka = 5.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
