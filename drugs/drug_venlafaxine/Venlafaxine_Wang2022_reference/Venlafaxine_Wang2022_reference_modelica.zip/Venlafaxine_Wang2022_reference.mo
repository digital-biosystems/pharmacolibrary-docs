model Venlafaxine_Wang2022_reference
  parameter Real Cl_ref = 6.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23800000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.000175,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>venlafaxine</td></tr><tr><td>population:</td><td>healthy volunteers and psychiatric patients</td></tr><tr><td>source_paper:</td><td>Wang_2022</td></tr><tr><td>measured_compound:</td><td>venlafaxine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is venlafaxine; the compartment is venlafaxine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is venlafaxine, not venlafaxine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>venlafaxine's own concentration-time course is not produced by this model</li><li>dropped unlinked row (NIL): 'FP' — extend the ontology if this is a real PK parameter (source ['T2:row6:col1'])</li><li>dropped unlinked row (NIL): 'θmorbid state on CL/F' — extend the ontology if this is a real PK parameter (source ['T2:row7:col1'])</li><li>dropped unlinked row (NIL): 'θamisulpride on CL/F' — extend the ontology if this is a real PK parameter (source ['T2:row8:col1'])</li><li>dropped duplicate Q351 ('θamisulpride on CLM/F', value '0.593') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F', value '0.219') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '0.106') — already have one for this compound</li><li>dropped duplicate Q351 ('CLM/F', value '0.156') — already have one for this compound</li><li>dropped duplicate Q367 ('V M/F', value '1.38') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=venlafaxine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Venlafaxine_Wang2022_reference;
