function p = Venlafaxine_Wang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: venlafaxine   source: Wang_2022 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Venlafaxine_Wang2022_reference_params';
  p.drug  = 'venlafaxine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 628.0;                % central volume [L]
  p.CL = 80.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.63;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
