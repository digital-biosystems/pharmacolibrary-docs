model Venlafaxine_Liu2022_reference
  parameter Real Cl_ref = 9.333333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.8150000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00016666666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>venlafaxine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>venlafaxine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Liu_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Venlafaxine_Liu2022_reference;
