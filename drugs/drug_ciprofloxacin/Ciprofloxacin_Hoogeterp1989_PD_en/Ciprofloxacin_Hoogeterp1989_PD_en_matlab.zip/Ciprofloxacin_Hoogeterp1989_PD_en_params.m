function p = Ciprofloxacin_Hoogeterp1989_PD_en_params()
% Ciprofloxacin_Hoogeterp1989_PD_en_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Hoogeterp_1989::EN: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response EN in log CFU. Driver: ciprofloxacin (cited_pk).
p.E0 = 0.0;
p.Emax = -4.4;
p.EC50 = 0.00038799999999999994;
p.gamma = 2.06;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.9;
p.form = 'E0 + Emax*frac';
end
