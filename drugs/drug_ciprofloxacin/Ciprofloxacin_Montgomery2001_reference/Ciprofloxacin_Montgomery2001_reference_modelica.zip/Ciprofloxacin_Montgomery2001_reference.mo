model Ciprofloxacin_Montgomery2001_reference
  parameter Real Cl_ref = 6.6111111111111115e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0203 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3313415,
    adminMass = 0.0004,
    ka = 0.0005277777777777777,
    Tlag = 1188.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>adult patients with cystic fibrosis</td></tr><tr><td>source_paper:</td><td>Montgomery_2001</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.341 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'V 1 (liters/kg)'; source reconciliation required</li><li>table representations disagree for 'V ss (liters/kg)'; source reconciliation required</li><li>table representations disagree for 'CL T (liters/h/kg)'; source reconciliation required</li><li>table representations disagree for 'CL D (liters/h/kg)'; source reconciliation required</li><li>table representations disagree for 'k 10 (h Ϫ1 )'; source reconciliation required</li><li>table representations disagree for 't 1/2␣ (h)'; source reconciliation required</li><li>table representations disagree for 't 1/2␤ (h)'; source reconciliation required</li><li>competing summary columns for 'AUC 0-24 (mg ⅐ h/liter) for 400 mg q12h 400 mg q8h'; not population strata</li><li>table representations disagree for 'AUC 0-24 (mg ⅐ h/liter) for 400 mg q12h 400 mg q8h'; source reconciliation required</li><li>competing summary columns for 'AUC 0-24 (mg ⅐ h/liter) for 400 mg q12h 400 mg q8h'; not population strata</li><li>table representations disagree for 'AUC 0-24 (mg ⅐ h/liter) for 400 mg q12h 400 mg q8h'; source reconciliation required</li><li>covariate effect for Q19 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V 1 (liters/kg)' is the general volume)</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Montgomery2001_reference;
