model Ciprofloxacin_Xiao2018_PD_in_vivo_effectiveness_bacteria_loa
  "sigmoid_emax exposure-response sweep — Xiao_2018 :: in vivo effectiveness (bacteria loading reduction) (in vivo effectiveness (bacteria loading reduction))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.78,      // [Log 10 cfu/mL]
    Emax = -5.8,  // [Log 10 cfu/mL]
    EC50 = 18.28,  // [1]
    gamma = 4.19,
    exposure_per_s = 1);   // 1 unit per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 190, Interval = 0.38),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ciprofloxacin_Xiao2018_PD_in_vivo_effectiveness_bacteria_loa</h4><p>The steady-state exposure-response curve of Xiao X et al., <i>BMC veterinary research 14(1):374</i> 2018 (<a href=\"https://doi.org/10.1186/s12917-018-1698-3\">doi:10.1186/s12917-018-1698-3</a>) — in vivo effectiveness (bacteria loading reduction) [Log 10 cfu/mL] against enrofloxacin and ciprofloxacin — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.78 Log 10 cfu/mL drug-free response (baseline) (E0, Q324)
  Emax  =       -5.8 Log 10 cfu/mL maximal effect term (Emax, Q323)
  EC50  =      18.28          exposure at half of the maximal effect term (EC50, Q321)
  gamma =       4.19          Hill coefficient (Slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of enrofloxacin and ciprofloxacin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.78   (drug-free)
  exposure = EC50 (18.28 )  response -1.12
  exposure -> infinity  response -4.02</pre></body></html>"));
end Ciprofloxacin_Xiao2018_PD_in_vivo_effectiveness_bacteria_loa;
