function p = Ciprofloxacin_Xiao2018_PD_in_vivo_effectiveness_bacteria_loa_params()
% Ciprofloxacin_Xiao2018_PD_in_vivo_effectiveness_bacteria_loa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Xiao_2018::in_vivo_effectiveness_bacteria_loading_reduction: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response in vivo effectiveness (bacteria loading reduction) in Log 10 cfu/mL. Driver: enrofloxacin and ciprofloxacin (not_resolved).
p.E0 = 1.78;
p.Emax = -5.8;
p.EC50 = 18.28;
p.gamma = 4.19;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 190.0;
p.form = 'E0 + Emax*frac';
end
