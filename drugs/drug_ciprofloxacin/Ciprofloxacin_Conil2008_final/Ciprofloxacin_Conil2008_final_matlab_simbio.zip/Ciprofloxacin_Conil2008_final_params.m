function p = Ciprofloxacin_Conil2008_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Conil_2008 / final   route: oral
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Conil2008_final_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 62.0;                % central volume [L]
  p.CL = 13.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.33;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
