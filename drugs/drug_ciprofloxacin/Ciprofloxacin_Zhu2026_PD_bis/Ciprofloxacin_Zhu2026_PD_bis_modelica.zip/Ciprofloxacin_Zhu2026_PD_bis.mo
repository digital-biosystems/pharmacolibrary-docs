model Ciprofloxacin_Zhu2026_PD_bis
  "sigmoid_emax exposure-response sweep — Zhu_2026 :: BIS (Bispectral Index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 93.4,      // [1]
    Emax = -45.77,  // [1]
    EC50 = 0.00023391,  // [kg/m3; ng·ml-1 × 1e-06]
    gamma = 3,
    exposure_per_s = 1e-06);   // 1 ng·ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 2400, Interval = 4.8),
    Documentation(info = "<html><body><h4>Ciprofloxacin_Zhu2026_PD_bis</h4><p>The steady-state exposure-response curve of Zhu J et al., <i>Frontiers in pharmacology 17:1764590</i> 2026 (<a href=\"https://doi.org/10.3389/fphar.2026.1764590\">doi:10.3389/fphar.2026.1764590</a>) — Bispectral Index against ciprofol ng·ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       93.4          drug-free response (baseline) (E0, Q324)
  Emax  =      45.77          maximal effect term (Imax, Q323)
  EC50  =     233.91 ng·ml-1  exposure at half of the maximal effect term (IC50, Q322)
  gamma =          3          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng·ml-1 of ciprofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 93.4   (drug-free)
  exposure = EC50 (233.91 ng·ml-1)  response 70.52
  exposure -> infinity  response 47.63</pre></body></html>"));
end Ciprofloxacin_Zhu2026_PD_bis;
