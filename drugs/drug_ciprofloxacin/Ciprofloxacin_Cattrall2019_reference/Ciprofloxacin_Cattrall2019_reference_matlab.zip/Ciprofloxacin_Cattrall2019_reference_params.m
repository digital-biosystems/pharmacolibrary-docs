function p = Ciprofloxacin_Cattrall2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Cattrall_2019 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ciprofloxacin_Cattrall2019_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.7;                % central volume [L]
  p.CL = 21.3;                % clearance [L/h]
  p.Vp = [3.02];             % peripheral volumes [L]
  p.Q  = [1.7];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
