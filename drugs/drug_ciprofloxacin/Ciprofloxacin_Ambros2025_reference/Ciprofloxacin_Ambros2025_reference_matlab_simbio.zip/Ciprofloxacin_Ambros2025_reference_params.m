function p = Ciprofloxacin_Ambros2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Ambros_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ciprofloxacin_Ambros2025_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.5;                % central volume [L]
  p.CL = 56.7;                % clearance [L/h]
  p.Vp = [198.1];             % peripheral volumes [L]
  p.Q  = [19.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.25;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
