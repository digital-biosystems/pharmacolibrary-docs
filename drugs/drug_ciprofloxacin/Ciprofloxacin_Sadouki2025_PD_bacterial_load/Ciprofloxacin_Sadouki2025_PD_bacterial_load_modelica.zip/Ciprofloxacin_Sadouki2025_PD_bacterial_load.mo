model Ciprofloxacin_Sadouki2025_PD_bacterial_load
  "sigmoid_emax exposure-response sweep — Sadouki_2025 :: bacterial load (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -4.18,  // [CFU/mL]
    EC50 = 7.809999999999999e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 2.76,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.781, Interval = 0.001562));
end Ciprofloxacin_Sadouki2025_PD_bacterial_load;
