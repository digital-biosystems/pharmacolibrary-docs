function p = Ciprofloxacin_Hirt2021_building_dataset_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Hirt_2021 / building_dataset   route: oral
  p.name  = 'Ciprofloxacin_Hirt2021_building_dataset_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 161.0;                % central volume [L]
  p.CL = 8.99;                % clearance [L/h]
  p.Vp = [24.8];             % peripheral volumes [L]
  p.Q  = [4.59];             % inter-compartmental clearances [L/h]
  p.ka = 0.893;                % absorption rate [1/h]
  p.F  = 0.342;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
