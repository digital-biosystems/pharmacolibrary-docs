function p = Ciprofloxacin_Sadouki2025_PD_cfu_ml_params()
% Ciprofloxacin_Sadouki2025_PD_cfu_ml_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Sadouki_2025::CFU_mL: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response CFU/mL in continuous. Driver: meropenem, gentamicin, ciprofloxacin (conc_no_pk).
p.E0 = 0.0;
p.Emax = -4.18;
p.EC50 = 7.809999999999999e-05;
p.gamma = 2.76;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 0.781;
p.form = 'E0 + Emax*frac';
end
