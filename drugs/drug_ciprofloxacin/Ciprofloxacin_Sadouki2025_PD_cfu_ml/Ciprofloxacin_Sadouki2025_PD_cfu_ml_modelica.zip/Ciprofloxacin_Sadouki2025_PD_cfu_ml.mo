model Ciprofloxacin_Sadouki2025_PD_cfu_ml
  "sigmoid_emax exposure-response sweep — Sadouki_2025 :: CFU/mL (Bacterial load (colony forming units, CFU/mL) of E. coli NCTC 12,241 under ciprofloxacin exposure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.55,  // [CFU/mL]
    EC50 = 1.06e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 3.58,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.11, Interval = 0.00022),
    Documentation(info = "<html><body><h4>Ciprofloxacin_Sadouki2025_PD_cfu_ml</h4><p>The steady-state exposure-response curve of Sadouki Z et al., <i>Scientific reports 15(1):45244</i> 2025 (<a href=\"https://doi.org/10.1038/s41598-025-29354-y\">doi:10.1038/s41598-025-29354-y</a>) — Bacterial load (colony forming units, CFU/mL) of E. coli NCTC 12,241 under ciprofloxacin exposure [CFU/mL] against ciprofloxacin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.55 CFU/mL   maximal effect term (EMAX, Q320)
  EC50  =     0.0106 mg/L     exposure at half of the maximal effect term (IC50 (mg/L), Q322)
  gamma =       3.58          Hill coefficient (hill, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of ciprofloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0106 mg/L)  response -2.275
  exposure -> infinity  response -4.55</pre></body></html>"));
end Ciprofloxacin_Sadouki2025_PD_cfu_ml;
