function p = Ciprofloxacin_Zhu2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Zhu_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Zhu2026_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.78;                % central volume [L]
  p.CL = 58.8;                % clearance [L/h]
  p.Vp = [42.8];             % peripheral volumes [L]
  p.Q  = [43.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
