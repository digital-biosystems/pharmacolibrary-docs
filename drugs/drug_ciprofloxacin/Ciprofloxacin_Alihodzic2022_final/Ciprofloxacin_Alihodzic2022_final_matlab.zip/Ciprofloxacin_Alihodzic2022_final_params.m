function p = Ciprofloxacin_Alihodzic2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Alihodzic_2022 / final   route: oral
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Alihodzic2022_final_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 73.4;                % central volume [L]
  p.CL = 12.9;                % clearance [L/h]
  p.Vp = [87.6];             % peripheral volumes [L]
  p.Q  = [38.8];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.33;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
