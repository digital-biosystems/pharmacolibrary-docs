function p = Ciprofloxacin_Alihodzic2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Alihodzic_2022 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ciprofloxacin_Alihodzic2022_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 53.3;                % central volume [L]
  p.CL = 11.2;                % clearance [L/h]
  p.Vp = [66.1];             % peripheral volumes [L]
  p.Q  = [25.7];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
