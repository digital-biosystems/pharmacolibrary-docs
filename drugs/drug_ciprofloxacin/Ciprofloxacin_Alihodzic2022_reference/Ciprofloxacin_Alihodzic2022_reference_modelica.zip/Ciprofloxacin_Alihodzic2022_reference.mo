model Ciprofloxacin_Alihodzic2022_reference
  parameter Real Cl_ref = 3.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0533 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k12 = 0.00013393787784031686,
    k21 = 0.00010800134476382587
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>critically ill adults undergoing ECMO</td></tr><tr><td>source_paper:</td><td>Alihodzic_2022</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'COV_CL_BICARB (L/mmol)' — extend the ontology if this is a real PK parameter (source ['tab_2:row7:col3', 'tab_2:row7:col5'])</li><li>unit_dimension_mismatch: 'COV_CL_eGFR (min/mL)' → Q22 (unit '[time] / [length] ** 3' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('COV_CL_eGFR (min/mL)', value '0.0003') — already have one for this compound</li><li>dropped value-less row: 'OFV'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'V1'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'V2'</li><li>dropped value-less row: 'COV_CL_BICARB'</li><li>dropped value-less row: 'COV_CL_eGFR'</li><li>dropped value-less row: 'Prop. σ 2'</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['tab_2:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'LLP-SIR'</li><li>dropped value-less row: 'CI'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Alihodzic2022_reference;
