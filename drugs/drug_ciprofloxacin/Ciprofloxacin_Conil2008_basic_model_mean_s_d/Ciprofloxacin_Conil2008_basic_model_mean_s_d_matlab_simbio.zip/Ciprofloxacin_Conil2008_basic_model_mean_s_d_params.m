function p = Ciprofloxacin_Conil2008_basic_model_mean_s_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Conil_2008 / basic_model_mean_s_d   route: oral
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Conil2008_basic_model_mean_s_d_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 60.2;                % central volume [L]
  p.CL = 12.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.33;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
