model Ciprofloxacin_Guo2022_v1
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061200000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k12 = 0.00020379448075526509,
    k21 = 0.00017419304779639976
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>ICU patients</td></tr><tr><td>source_paper:</td><td>Guo_2022</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'v1' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'v1' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'v1' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'v1' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'v1' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Posterior mean' — extend the ontology if this is a real PK parameter (source ['Guo_2022_table_3:row3:col3'])</li><li>routed 'Posterior inter-individual variability' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>salvaged Q22 ('CL'=14.7) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V1'=61.2) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q'=44.9) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2'=71.6) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Guo2022_v1;
