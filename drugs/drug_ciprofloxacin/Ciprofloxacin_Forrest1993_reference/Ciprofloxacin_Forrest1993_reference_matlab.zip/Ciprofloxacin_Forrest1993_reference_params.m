function p = Ciprofloxacin_Forrest1993_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Forrest_1993 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Forrest1993_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.3;                % central volume [L]
  p.CL = 17.0;                % clearance [L/h]
  p.Vp = [35.7];             % peripheral volumes [L]
  p.Q  = [38.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
