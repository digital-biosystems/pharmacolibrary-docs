model Ciprofloxacin_Forrest1993_reference
  parameter Real Cl_ref = 4.722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.048299999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3313415,
    adminMass = 0.0002,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k12 = 0.000218541522889349,
    k21 = 0.0002956738250855898
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>acutely ill patients</td></tr><tr><td>source_paper:</td><td>Forrest_1993</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.341 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'gold standard b' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'gold standard b' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'gold standard b' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'gold standard b' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: 'liters/h/1.73 m2' (Q)</li><li>unit_dimension_unknown: 'liters/h/1.73 m2' (CL)</li><li>dropped duplicate Q22 ('CL T (liters/h)', value '17') — already have one for this compound</li><li>dropped duplicate Q30 ('CL D (liters/h)', value '35') — already have one for this compound</li><li>dropped duplicate Q63 ('V 1 (liters)', value '46') — already have one for this compound</li><li>dropped duplicate Q65 ('V ss (liters)', value '113') — already have one for this compound</li><li>implicit units: 'CLD (liters/h/1.73 m2)' → L/h (from the popPK convention: &quot;CLD represents intercompartmental clearance. The paper text identifies it as such ('CLD' in Figure 5 caption context imp&quot;)</li><li>implicit units: 'CLT (liters/h/1.73 m2)' → L/h (from the popPK convention: &quot;CLT represents total clearance. The paper text states 'Apparent distribution volumes and clearances were significantly r&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li><li>gap-filled Q49 (kabs) from Alonso_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Forrest1993_reference;
