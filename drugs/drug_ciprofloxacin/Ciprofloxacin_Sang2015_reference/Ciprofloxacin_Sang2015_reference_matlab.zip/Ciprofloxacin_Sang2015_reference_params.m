function p = Ciprofloxacin_Sang2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Sang_2015 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Ciprofloxacin_Sang2015_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.9114;                % central volume [L]
  p.CL = 3.3929;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.79;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
