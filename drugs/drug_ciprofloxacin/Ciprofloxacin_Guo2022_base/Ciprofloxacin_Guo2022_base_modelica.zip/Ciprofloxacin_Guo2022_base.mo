model Ciprofloxacin_Guo2022_base
  parameter Real Cl_ref = 4.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061700000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3313415,
    adminMass = 0.0004,
    ka = 0.0005277777777777777,
    Tlag = 1188.0,
    k12 = 0.00019944174320187284,
    k21 = 0.0001706734473724765
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>ICU patients</td></tr><tr><td>source_paper:</td><td>Guo_2022</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.341 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'AddStudy1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'PropStudy1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'PropStudy2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'PropStudy3' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li><li>model-stage split: 'base model' is the base model of Guo_2022 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>gap-filled Q49 (kabs) from Cattrall_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Papich_2012's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Guo2022_base;
