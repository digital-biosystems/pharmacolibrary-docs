function p = Ciprofloxacin_Hffken1985_50_mg_orally_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Höffken_1985 / 50_mg_orally   route: oral
  % estimated (absent from source): dose
  p.name  = 'Ciprofloxacin_Hffken1985_50_mg_orally_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 212.8;                % central volume [L]
  p.CL = 56.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.77;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
