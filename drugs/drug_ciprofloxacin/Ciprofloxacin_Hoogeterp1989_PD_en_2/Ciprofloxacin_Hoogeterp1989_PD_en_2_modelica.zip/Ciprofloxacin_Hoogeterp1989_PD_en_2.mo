model Ciprofloxacin_Hoogeterp1989_PD_en_2
  "sigmoid_emax exposure-response sweep — Hoogeterp_1989 :: EN (Number of CFU of Staphylococcus aureus)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.7,  // [log CFU]
    EC50 = 0.000264,  // [kg/m3; mg/l × 0.001]
    gamma = 1.18,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2.7, Interval = 0.0054),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ciprofloxacin_Hoogeterp1989_PD_en_2</h4><p>The steady-state exposure-response curve of Hoogeterp JJ et al., <i>Scandinavian journal of infectious diseases 21(1):95–101</i> 1989 (<a href=\"https://doi.org/10.3109/00365548909035686\">doi:10.3109/00365548909035686</a>) — Number of CFU of Staphylococcus aureus [log CFU] against ciprofloxacin mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        4.7 log CFU  maximal effect term (EN,max, Q323)
  EC50  =      0.264 mg/l     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.18          Hill coefficient (s, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of ciprofloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.264 mg/l)  response -2.35
  exposure -> infinity  response -4.7</pre></body></html>"));
end Ciprofloxacin_Hoogeterp1989_PD_en_2;
