function p = Ciprofloxacin_Abada1994_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Abadía_1994 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ciprofloxacin_Abada1994_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 210.0;                % central volume [L]
  p.CL = 56.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
