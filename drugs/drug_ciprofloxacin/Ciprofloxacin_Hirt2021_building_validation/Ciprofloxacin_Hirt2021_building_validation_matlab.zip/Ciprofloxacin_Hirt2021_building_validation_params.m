function p = Ciprofloxacin_Hirt2021_building_validation_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Hirt_2021 / building_validation   route: oral
  p.name  = 'Ciprofloxacin_Hirt2021_building_validation_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 161.0;                % central volume [L]
  p.CL = 9.07;                % clearance [L/h]
  p.Vp = [26.5];             % peripheral volumes [L]
  p.Q  = [3.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.667;                % absorption rate [1/h]
  p.F  = 0.374;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
