% Run (SimBiology): build model + dose, simulate 0..27.0 h, plot.
p = Ciprofloxacin_Hffken1985_750_mg_orally_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 27.0);
