model Ciprofloxacin_Hffken1985_750_mg_orally
  parameter Real Cl_ref = 1.575e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.24709999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Höffken_1985</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: '750 mg orally' subgroup of Höffken_1985 (paper reports 7 populations: 100 mg, 100 mg i.v., 100 mg orally, 50 mg, 50 mg i.v., 50 mg orally, 750 mg orally)</li><li>gap-filled Q22 (CL) from Ambros_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alonso_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Hffken1985_750_mg_orally;
