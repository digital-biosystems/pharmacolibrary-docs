function p = Ciprofloxacin_Abdulla2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Abdulla_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Abdulla2020_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 91.1;                % central volume [L]
  p.CL = 25.4;                % clearance [L/h]
  p.Vp = [164.0];             % peripheral volumes [L]
  p.Q  = [91.9];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.33;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
