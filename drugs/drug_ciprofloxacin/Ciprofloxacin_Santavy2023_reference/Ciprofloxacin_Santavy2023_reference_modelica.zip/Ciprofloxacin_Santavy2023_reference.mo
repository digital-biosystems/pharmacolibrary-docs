model Ciprofloxacin_Santavy2023_reference
  parameter Real Cl_ref = 2.472222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01009 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k21 = 3.922111480251016e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>adults undergoing cardiac surgery with extracorporeal circulation</td></tr><tr><td>source_paper:</td><td>Santavy_2023</td></tr><tr><td>measured_compound:</td><td>ampicillin, cefazolin, ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('β_CL_eGFR', value '0.39') — already have one for this compound</li><li>dropped duplicate Q22 ('Ω_CL', value '0.2') — already have one for this compound</li><li>dropped duplicate Q63 ('Ω_V1', value '0.25') — already have one for this compound</li><li>dropped duplicate Q30 ('Ω_Q', value '0.16') — already have one for this compound</li><li>dropped duplicate Q64 ('Ω_V2', value '0.37') — already have one for this compound</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ampicillin, cefazolin, ciprofloxacin</li><li>gap-filled Q49 (kabs) from Alonso_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Santavy2023_reference;
