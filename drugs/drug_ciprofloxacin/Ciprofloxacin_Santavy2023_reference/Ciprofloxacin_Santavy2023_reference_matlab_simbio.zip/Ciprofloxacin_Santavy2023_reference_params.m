function p = Ciprofloxacin_Santavy2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Santavy_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Santavy2023_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.09;                % central volume [L]
  p.CL = 0.089;                % clearance [L/h]
  p.Vp = [12.04];             % peripheral volumes [L]
  p.Q  = [1.7];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.79;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
