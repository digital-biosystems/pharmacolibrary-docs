model Ciprofloxacin_Papich2017_reference
  parameter Real Cl_ref = 3.325e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.749 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3313415,
    adminMass = 0.00175,
    ka = 0.00010833333333333334,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>clinical canine patients</td></tr><tr><td>source_paper:</td><td>Papich_2017</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvim14788-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.341 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'dVdWeight' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q95 ('K e T 1/2', value '4.35') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ciprofloxacin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Papich2017_reference;
