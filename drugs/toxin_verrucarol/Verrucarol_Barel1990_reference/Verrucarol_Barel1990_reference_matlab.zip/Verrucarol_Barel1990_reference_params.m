function p = Verrucarol_Barel1990_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: verrucarol   source: Barel_1990 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Verrucarol_Barel1990_reference_params';
  p.drug  = 'verrucarol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 84.0;                % central volume [L]
  p.CL = 46.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.44;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
