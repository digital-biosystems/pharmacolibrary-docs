function p = Amlodipine_Courlet2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Courlet_2021 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Amlodipine_Courlet2021_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1000.0;                % central volume [L]
  p.CL = 17.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.69;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.87;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
