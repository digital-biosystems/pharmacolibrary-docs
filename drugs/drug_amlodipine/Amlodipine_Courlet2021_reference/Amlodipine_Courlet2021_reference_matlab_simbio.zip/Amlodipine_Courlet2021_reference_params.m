function p = Amlodipine_Courlet2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Courlet_2021 / reference   route: oral
  p.name  = 'Amlodipine_Courlet2021_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.0;                % central volume [L]
  p.CL = 9.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 25.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 28.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
