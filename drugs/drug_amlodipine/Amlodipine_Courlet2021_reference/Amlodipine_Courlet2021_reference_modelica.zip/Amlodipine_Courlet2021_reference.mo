model Amlodipine_Courlet2021_reference
  parameter Real Cl_ref = 4.722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00019166666666666665,
    Tlag = 3132.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>elderly people living with HIV</td></tr><tr><td>source_paper:</td><td>Courlet_2021</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'θCYP3A4 inhibitors' — extend the ontology if this is a real PK parameter (source ['Tab2:row7:col1', 'Tab2:row7:col2', 'Tab2:row7:col3'])</li><li>kept covariate coefficient θefavirenz=1.40 (covariate efavirenz) — not an ontology parameter</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number 17.0 (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number -0.49 (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 1.4 (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amlodipine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Courlet2021_reference;
