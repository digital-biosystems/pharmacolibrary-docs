function p = Amlodipine_Choi2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Choi_2020 / reference   route: oral
  p.name  = 'Amlodipine_Choi2020_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.89;                % central volume [L]
  p.CL = 36.4;                % clearance [L/h]
  p.Vp = [910.0];             % peripheral volumes [L]
  p.Q  = [118.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.563;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
