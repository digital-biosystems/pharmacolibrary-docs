model Amlodipine_Choi2020_reference
  parameter Real Cl_ref = 1.0111111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005889999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.00015638888888888888,
    Tlag = 0.0,
    k12 = 0.005564987738162611,
    k21 = 3.601953601953602e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>human pharmacology study</td></tr><tr><td>source_paper:</td><td>Choi_2020</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL/F2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωCL/F2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωVc/F2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωVc/F2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωVp/F2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωVp/F2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωka2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωka2' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωALAG12' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωALAG12' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωF12' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωF12' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'σprop' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σprop' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'D2 (h)' — extend the ontology if this is a real PK parameter (source ['T0002:row8:col2', 'T0002:row8:col3'])</li><li>dropped unlinked row (NIL): 'ALAG1 (h)' — extend the ontology if this is a real PK parameter (source ['T0002:row9:col2', 'T0002:row9:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Choi2020_reference;
