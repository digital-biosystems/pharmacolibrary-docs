% Run (SimBiology): build model + dose, simulate 0..192.0 h, plot.
p = Amlodipine_van2020_8_to_10_years_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 192.0);
