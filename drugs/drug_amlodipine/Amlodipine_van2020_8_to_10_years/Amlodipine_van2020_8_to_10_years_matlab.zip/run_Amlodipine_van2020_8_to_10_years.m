% Run: build params, simulate 0..192.0 h, plot + save Amlodipine_van2020_8_to_10_years.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Amlodipine_van2020_8_to_10_years.m
here = fileparts(mfilename('fullpath'));
p = Amlodipine_van2020_8_to_10_years_params();
out = simulate_pk(p, 0:0.05:192.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('amlodipine — van_2020 (oral)');
print(fig, fullfile(here, 'Amlodipine_van2020_8_to_10_years.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Amlodipine_van2020_8_to_10_years.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Amlodipine_van2020_8_to_10_years.json'), 'w');
try
  s.model = 'Amlodipine_van2020_8_to_10_years'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Amlodipine_van2020_8_to_10_years","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Amlodipine_van2020_8_to_10_years.png, Amlodipine_van2020_8_to_10_years.csv, Amlodipine_van2020_8_to_10_years.json\n');
