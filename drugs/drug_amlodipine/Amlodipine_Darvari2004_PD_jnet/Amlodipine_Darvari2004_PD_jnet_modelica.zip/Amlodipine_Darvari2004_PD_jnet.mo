model Amlodipine_Darvari2004_PD_jnet
  "sigmoid_emax exposure-response sweep — Darvari_2004 :: Jnet (net flux of doxorubicin)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.02,      // [nM cm À2 h À1]
    Emax = 55.11,  // [nM cm À2 h À1]
    EC50 = 4.64,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 47, Interval = 0.094),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amlodipine_Darvari2004_PD_jnet</h4><p>The steady-state exposure-response curve of Darvari R et al., <i>The Journal of pharmacy and pharmacology 56(8):985–991</i> 2004 (<a href=\"https://doi.org/10.1211/0022357043941\">doi:10.1211/0022357043941</a>) — net flux of doxorubicin [nM cm À2 h À1] against amlodipine M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.02 nM cm À2 h À1 drug-free response (baseline) (E0, Q324)
  Emax  =      55.11 nM cm À2 h À1 maximal effect term (Emax, Q320)
  EC50  =       4.64 M        exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of amlodipine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.02   (drug-free)
  exposure = EC50 (4.64 M)  response 33.58
  exposure -> infinity  response 61.13</pre></body></html>"));
end Amlodipine_Darvari2004_PD_jnet;
