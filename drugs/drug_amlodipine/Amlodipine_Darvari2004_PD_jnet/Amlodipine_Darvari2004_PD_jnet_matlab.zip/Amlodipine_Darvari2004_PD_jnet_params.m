function p = Amlodipine_Darvari2004_PD_jnet_params()
% Amlodipine_Darvari2004_PD_jnet_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Darvari_2004::Jnet: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response Jnet in nM cm À2 h À1. Driver: amlodipine (cited_pk).
p.E0 = 6.02;
p.Emax = 55.11;
p.EC50 = 4.64;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 47.0;
p.form = 'E0 + Emax*frac';
end
