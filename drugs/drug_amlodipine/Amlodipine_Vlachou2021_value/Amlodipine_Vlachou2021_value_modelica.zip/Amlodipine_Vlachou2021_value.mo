model Amlodipine_Vlachou2021_value
  parameter Real Cl_ref = 3.8333333333333326e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.98 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Vlachou_2021</td></tr><tr><td>measured_compound:</td><td>amlodipine, irbesartan, hydrochlorothiazide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>materials-14-00555-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Amlodipine' — extend the ontology if this is a real PK parameter (source ['materials-14-00555-t004:row1:col3'])</li><li>dropped unlinked row (NIL): '4.5' — extend the ontology if this is a real PK parameter (source ['materials-14-00555-t004:row3:col3', 'materials-14-00555-t004:row9:col3', 'materials-14-00555-t004:row15:col3'])</li><li>dropped unlinked row (NIL): '6.8' — extend the ontology if this is a real PK parameter (source ['materials-14-00555-t004:row5:col3', 'materials-14-00555-t004:row11:col3', 'materials-14-00555-t004:row17:col3'])</li><li>dropped unlinked row (NIL): 'Irbesartan' — extend the ontology if this is a real PK parameter (source ['materials-14-00555-t004:row7:col3'])</li><li>dropped unlinked row (NIL): 'Hydrochlorthiazide' — extend the ontology if this is a real PK parameter (source ['materials-14-00555-t004:row13:col3'])</li><li>dropped unlinked row (NIL): 'Literature 1' — extend the ontology if this is a real PK parameter (source ['Vlachou_2021_table_5:row1:col2'])</li><li>dropped unlinked row (NIL): 'In vitro fittings' — extend the ontology if this is a real PK parameter (source ['Vlachou_2021_table_5:row4:col2', 'Vlachou_2021_table_5:row16:col2', 'Vlachou_2021_table_5:row28:col2'])</li><li>dropped unlinked row (NIL): 'Literature 2' — extend the ontology if this is a real PK parameter (source ['Vlachou_2021_table_5:row10:col2'])</li><li>dropped unlinked row (NIL): 'Literature 3' — extend the ontology if this is a real PK parameter (source ['Vlachou_2021_table_5:row22:col2'])</li><li>table mostly unlinked (9/10 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amlodipine, irbesartan, hydrochlorothiazide</li><li>status held at route_to_review — not promoted</li><li>population split: 'value' subgroup of Vlachou_2021 (paper reports 4 populations: buffer, parameter, parameter 4, value)</li><li>gap-filled Q22 (CL) from Angeloni_2016's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Courlet_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Vlachou2021_value;
