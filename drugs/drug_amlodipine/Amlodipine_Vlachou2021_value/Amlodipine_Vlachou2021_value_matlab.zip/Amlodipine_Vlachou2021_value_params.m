function p = Amlodipine_Vlachou2021_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Vlachou_2021 / value   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'Amlodipine_Vlachou2021_value_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 980.0;                % central volume [L]
  p.CL = 0.138;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
