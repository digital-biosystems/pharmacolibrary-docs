model Amlodipine_Hong2021_mb1_estimates
  parameter Real Cl_ref = 7.111111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.884 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.00024277777777777777,
    Tlag = 0.0,
    k12 = 1.9984917043740574e-05,
    k21 = 3.961136023916293e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Hong_2021</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ωV2' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ωF1' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ρCL-V2' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section residual_error: 'σAdd' routed out of structural estimates ('Intra-individual variability (residual error)')</li><li>unit_dimension_unknown: 'Period 1*' (CL/F)</li><li>dropped unlinked row (NIL): 'ALAG 1' — extend the ontology if this is a real PK parameter (source ['T3:row9:col1'])</li><li>unit_dimension_unknown: 'Period 1*' (Fab)</li><li>implicit units: 'CL/F (Period 1*)' → L/h (from the paper text: 'clearance (CL/F) = 25.6 L/h')</li><li>implicit units: 'V2/F' → L (from the paper text: 'central volume (V2/F) = 884 L')</li><li>implicit units: 'V3/F' → L (from the paper text: 'peripheral volume (V3/F) = 446 L')</li><li>implicit units: 'Q/F' → L/h (from the paper text: 'intercompartmental clearance (Q/F) = 63.6 L/h')</li><li>implicit units: 'K a' → 1/h (from the popPK convention: 'Absorption rate constant (Ka) is a first-order rate constant; the paper does not explicitly state the unit for this spec')</li><li>implicit units: 'D 2' → h (from the paper text: 'duration of zero-order absorption (D2) = 3.31 h')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amlodipine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Hong2021_mb1_estimates;
