function p = Amlodipine_Hong2021_mb1_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Hong_2021 / mb1_estimates   route: oral
  p.name  = 'Amlodipine_Hong2021_mb1_estimates_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 884.0;                % central volume [L]
  p.CL = 25.6;                % clearance [L/h]
  p.Vp = [446.0];             % peripheral volumes [L]
  p.Q  = [63.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.874;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
