function p = Amlodipine_Heo2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Heo_2016 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Amlodipine_Heo2016_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.8;                % central volume [L]
  p.CL = 39.4;                % clearance [L/h]
  p.Vp = [14.2];             % peripheral volumes [L]
  p.Q  = [2.02];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
