model Amlodipine_Karalis2023_drug_amlodipine
  parameter Real Cl_ref = 6.166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0013 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.00023616666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>virtual subjects (in silico)</td></tr><tr><td>source_paper:</td><td>Karalis_2023</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-16-00725-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amlodipine</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F (mL)' is the general volume)</li><li>population split: 'drug / amlodipine' subgroup of Karalis_2023 (paper reports 3 populations: drug / amlodipine, drug / donepezil, drug / hydrochlorothiazide)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Karalis2023_drug_amlodipine;
