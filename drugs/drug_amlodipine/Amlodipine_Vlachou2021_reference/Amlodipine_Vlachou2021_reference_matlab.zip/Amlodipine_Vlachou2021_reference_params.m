function p = Amlodipine_Vlachou2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Vlachou_2021 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Amlodipine_Vlachou2021_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.3;                % central volume [L]
  p.CL = 22.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.8502;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.68;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
