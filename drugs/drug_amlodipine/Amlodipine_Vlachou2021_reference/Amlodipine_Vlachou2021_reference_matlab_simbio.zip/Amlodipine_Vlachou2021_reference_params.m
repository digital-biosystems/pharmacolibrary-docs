function p = Amlodipine_Vlachou2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Vlachou_2021 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Amlodipine_Vlachou2021_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.3;                % central volume [L]
  p.CL = 22.2;                % clearance [L/h]
  p.Vp = [85.8];             % peripheral volumes [L]
  p.Q  = [17.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
