function p = Amlodipine_Rohatagi2008_population_mean_se_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Rohatagi_2008 / population_mean_se   route: oral
  % estimated (absent from source): F
  p.name  = 'Amlodipine_Rohatagi2008_population_mean_se_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.0;                % central volume [L]
  p.CL = 1.7;                % clearance [L/h]
  p.Vp = [2.5];             % peripheral volumes [L]
  p.Q  = [2.02];             % inter-compartmental clearances [L/h]
  p.ka = 2.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
