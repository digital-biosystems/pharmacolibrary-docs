model Amlodipine_Rohatagi2008_population_mean_se
  parameter Real Cl_ref = 4.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.0006388888888888888,
    Tlag = 0.0,
    k21 = 0.00022444444444444443
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>adults with hypertension</td></tr><tr><td>source_paper:</td><td>Rohatagi_2008</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Multiplicative, ng/mL²' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive, ng/mL²' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Multiplicative, ng/mL²' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive phase I, ng/mL²' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive phase III, ng/mL²' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Body weight (CL_WT)' — extend the ontology if this is a real PK parameter (source ['Rohatagi_2008_table_p6_1:row7:col2', 'Rohatagi_2008_table_p6_1:row22:col2'])</li><li>dropped unlinked row (NIL): 'Age (CL_AGE)' — extend the ontology if this is a real PK parameter (source ['Rohatagi_2008_table_p6_1:row8:col2'])</li><li>dropped unlinked row (NIL): 'Subject status (CL_HV)' — extend the ontology if this is a real PK parameter (source ['Rohatagi_2008_table_p6_1:row20:col2'])</li><li>dropped unlinked row (NIL): 'Sex (CL_SEX)' — extend the ontology if this is a real PK parameter (source ['Rohatagi_2008_table_p6_1:row21:col2'])</li><li>dropped unlinked row (NIL): 'Serum creatinine (CL_SCr)' — extend the ontology if this is a real PK parameter (source ['Rohatagi_2008_table_p6_1:row23:col2'])</li><li>covariate effect for Q25 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL₁,₁, L/h); Q61 (V, L); Q64 (V2, L)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amlodipine</li><li>population split: 'population mean seᵃ' subgroup of Rohatagi_2008 (paper reports 2 populations: population mean estimate, population mean seᵃ)</li><li>gap-filled Q30 (Q) from Heo_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Rohatagi2008_population_mean_se;
