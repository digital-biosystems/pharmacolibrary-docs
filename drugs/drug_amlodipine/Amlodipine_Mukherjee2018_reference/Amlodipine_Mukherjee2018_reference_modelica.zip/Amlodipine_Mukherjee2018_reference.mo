model Amlodipine_Mukherjee2018_reference
  parameter Real Cl_ref = 3.8333333333333326e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.98 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00040555555555555554,
    Tlag = 3096.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Mukherjee_2018</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Faulkner et al. (IV) [32]' — extend the ontology if this is a real PK parameter (source ['Tab4:row1:col2', 'Tab4:row1:col3', 'Tab4:row1:col4'])</li><li>dropped unlinked row (NIL): 'Faulkner et al. (oral) [32]' — extend the ontology if this is a real PK parameter (source ['Tab4:row3:col2', 'Tab4:row3:col3', 'Tab4:row3:col4'])</li><li>dropped unlinked row (NIL): 'Glesby et al.a (DDI) [11]' — extend the ontology if this is a real PK parameter (source ['Tab4:row8:col2', 'Tab4:row8:col3', 'Tab4:row8:col4'])</li><li>dropped unlinked row (NIL): 'Menon et al.b (DDI) [12]' — extend the ontology if this is a real PK parameter (source ['Tab4:row10:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amlodipine</li><li>gap-filled Q22 (CL) from Angeloni_2016's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Courlet_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Courlet_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Mukherjee2018_reference;
