function p = Amlodipine_Rohatagi2008_PD_sedbp_params()
% Amlodipine_Rohatagi2008_PD_sedbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Rohatagi_2008::SeDBP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC per second, in SI inside (kg/m3, s). Response ΔSeDBP in mm Hg. Driver: amlodipine (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -2.2200000000000003e-06;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
