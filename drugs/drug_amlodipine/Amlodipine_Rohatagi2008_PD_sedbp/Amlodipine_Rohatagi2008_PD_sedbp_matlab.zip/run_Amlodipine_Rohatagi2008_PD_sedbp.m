% run_Amlodipine_Rohatagi2008_PD_sedbp  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Amlodipine_Rohatagi2008_PD_sedbp_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [AUC]'); ylabel('response [mm Hg]'); title('Amlodipine_Rohatagi2008_PD_sedbp', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Amlodipine_Rohatagi2008_PD_sedbp.csv');
