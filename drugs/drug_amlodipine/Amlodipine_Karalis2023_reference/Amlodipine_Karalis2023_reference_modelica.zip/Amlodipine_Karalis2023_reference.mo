model Amlodipine_Karalis2023_reference
  parameter Real Cl_ref = 6.166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0013 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00023616666666666667,
    Tlag = 0.0,
    k21 = 4.8325342465753424e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>virtual subjects</td></tr><tr><td>source_paper:</td><td>Karalis_2023</td></tr><tr><td>measured_compound:</td><td>hydrochlorothiazide, donepezil, and amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-16-00725-t002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hydrochlorothiazide, donepezil, and amlodipine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Karalis2023_reference;
