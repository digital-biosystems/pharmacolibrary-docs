function sd = simulate_sb(model, variant, dose, tstop)
% Simulate a SimBiology PK model to tstop hours; plot and return SimData.
  cs = getconfigset(model);
  cs.StopTime = tstop;
  cs.SolverType = 'ode15s';
  sd = sbiosimulate(model, cs, variant, dose);
  sbioplot(sd);
  % Non-compartmental metrics (Cmax/Tmax/AUC/t1/2): nca = sbionca(sd);
end
