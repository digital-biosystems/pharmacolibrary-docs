function [model, dose, variant, obs] = build_sb_pk(p)
% Build a SimBiology PK model from a parameter struct p (see *_params.m).
% Requires the SimBiology toolbox. Uses PKModelDesign for a 1..N-compartment,
% linear-clearance model with IV-bolus or first-order-oral dosing.
  isOral = strcmp(p.route, 'oral');
  pkm = PKModelDesign;
  addCompartment(pkm, 'Central', ...
      'DosingType',          ternary(isOral, 'FirstOrder', 'Bolus'), ...
      'EliminationType',     'linear-clearance', ...
      'HasResponseVariable', true, ...
      'HasLag',              p.Tlag > 0);
  for j = 1:(p.ncmt - 1)
      addCompartment(pkm, sprintf('Peripheral%d', j), ...
          'DosingType', '', 'EliminationType', '', 'HasResponseVariable', false);
  end
  [model, pkmap] = construct(pkm);

  % Parameter values via a Variant (PKModelDesign's canonical names; adjust via
  % pkmap / get(model,'Parameters') if a SimBiology version renames them).
  variant = addvariant(model, [p.name '_params']);
  addcontent(variant, {'compartment', 'Central', 'Capacity', p.Vc});
  addcontent(variant, {'parameter',   'Cl_Central', 'Value', p.CL});
  if isOral
      addcontent(variant, {'parameter', 'ka_Central', 'Value', p.ka});
  end
  for j = 1:(p.ncmt - 1)
      addcontent(variant, {'compartment', sprintf('Peripheral%d', j), 'Capacity', p.Vp(j)});
      addcontent(variant, {'parameter',   sprintf('Q%d', j+1),        'Value',    p.Q(j)});
  end

  % Dose (IV bolus or first-order oral; bioavailability folded into the amount).
  dose = sbiodose('dose');
  dose.TargetName = pkmap.dosingTargetNames{1};
  if isOral
      dose.Amount = p.F * p.dose;
  else
      dose.Amount = p.dose;
  end
  dose.StartTime = 0;
  % Repeated dosing: set dose.Interval = tau; dose.RepeatCount = n-1;

  obs = pkmap.observableNames{1};
end

function y = ternary(c, a, b)
  if c, y = a; else, y = b; end
end
