function p = Amlodipine_Mao2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Mao_2024 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Amlodipine_Mao2024_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 496.0;                % central volume [L]
  p.CL = 7.09;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.75;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
