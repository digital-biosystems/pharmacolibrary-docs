% Run (SimBiology): build model + dose, simulate 0..264.0 h, plot.
p = Amlodipine_Mao2024_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 264.0);
