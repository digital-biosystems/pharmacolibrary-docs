% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Amlodipine_van2020_point_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
