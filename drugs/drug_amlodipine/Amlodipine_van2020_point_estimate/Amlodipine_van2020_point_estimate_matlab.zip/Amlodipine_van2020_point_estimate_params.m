function p = Amlodipine_van2020_point_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: van_2020 / point_estimate   route: oral
  p.name  = 'Amlodipine_van2020_point_estimate_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 345.0;                % central volume [L]
  p.CL = 10.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.582;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.5;             % dose [mg]
end
