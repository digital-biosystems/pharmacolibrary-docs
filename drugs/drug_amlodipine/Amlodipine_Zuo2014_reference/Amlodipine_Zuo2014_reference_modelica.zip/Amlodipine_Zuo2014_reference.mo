model Amlodipine_Zuo2014_reference
  parameter Real Cl_ref = 8.000000000000001e-06 "Cl [m3/s]";
  parameter Real cov_abcb1_0 = 0 "abcb1 covariate";
  parameter Real Vd_ref = 0.858 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.503)*cov_abcb1_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 6.361111111111111e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>adult Chinese patients with mild to moderate essential hypertension</td></tr><tr><td>source_paper:</td><td>Zuo_2014</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CL/F (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'CV (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'CV (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'SD (µg/L)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'SD (µg/L)' routed out of structural estimates ('Residual variability')</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'Ka (h ¹1 )'; source reconciliation required</li><li>table representations disagree for 'GNDR CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'ABCB1 CL/F (L/h)'; source reconciliation required</li><li>unit_dimension_unknown: 'h ¹1' (kabs)</li><li>dropped duplicate Q27 ('GNDR CL/F (L/h)', value '26.4') — already have one for this compound</li><li>implicit units: 'Ka (h ¹1 )' → 1/h (from the paper text: &quot;The abstract explicitly defines the unit for the oral clearance parameter in the context of the model: 'CL/F (L/h) = 28.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amlodipine</li><li>pharmacogenetic covariate 'theta_cl_f_abcb1' (abcb1) — PGx domain</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Zuo2014_reference;
