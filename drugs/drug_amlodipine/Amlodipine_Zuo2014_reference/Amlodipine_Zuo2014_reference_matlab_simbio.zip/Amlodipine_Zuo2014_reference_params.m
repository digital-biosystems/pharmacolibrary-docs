function p = Amlodipine_Zuo2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Zuo_2014 / reference   route: oral
  p.name  = 'Amlodipine_Zuo2014_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 858.0;                % central volume [L]
  p.CL = 28.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.229;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
