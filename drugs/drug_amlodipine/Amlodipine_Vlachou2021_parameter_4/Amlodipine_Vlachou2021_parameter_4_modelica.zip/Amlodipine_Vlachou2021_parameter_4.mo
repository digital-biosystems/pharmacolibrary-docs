model Amlodipine_Vlachou2021_parameter_4
  parameter Real Cl_ref = 6.166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0013 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00024883333333333333,
    Tlag = 0.0,
    k21 = 5.730380730380729e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Vlachou_2021</td></tr><tr><td>measured_compound:</td><td>amlodipine, irbesartan, hydrochlorothiazide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>materials-14-00555-t004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Kd_R (min−1)' — extend the ontology if this is a real PK parameter (source ['Vlachou_2021_table_5:row5:col1', 'Vlachou_2021_table_5:row17:col1', 'Vlachou_2021_table_5:row29:col1'])</li><li>dropped unlinked row (NIL): 'Kat_R (min−1)' — extend the ontology if this is a real PK parameter (source ['Vlachou_2021_table_5:row7:col1', 'Vlachou_2021_table_5:row19:col1', 'Vlachou_2021_table_5:row31:col1'])</li><li>dropped duplicate Q49 ('Ka (min−1)', value '0.00507') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amlodipine, irbesartan, hydrochlorothiazide</li><li>population split: 'parameter 4' subgroup of Vlachou_2021 (paper reports 4 populations: buffer, parameter, parameter 4, value)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Vlachou2021_parameter_4;
