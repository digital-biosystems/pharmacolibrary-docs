function p = Amlodipine_Tan2025_PD_total_worm_burden_params()
% Amlodipine_Tan2025_PD_total_worm_burden_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Tan_2025::total_worm_burden: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response total worm burden in its own unit. Driver: amlodipine (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.010537;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 110.0;
p.form = 'E0 + Emax*frac';
end
