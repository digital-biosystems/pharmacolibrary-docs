function p = Amlodipine_Flynn2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Flynn_2006 / reference   route: oral
  p.name  = 'Amlodipine_Flynn2006_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 757.0;                % central volume [L]
  p.CL = 17.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.79;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
