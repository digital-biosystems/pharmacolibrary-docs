model Amlodipine_Hong2021_mb2_estimates
  parameter Real Cl_ref = 7.083333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.9430000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.00027527777777777777,
    Tlag = 0.0,
    k12 = 1.402144456227171e-05,
    k21 = 3.280948442238765e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Hong_2021</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ωV2' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ωF1' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ωBIO' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section iiv: 'ρCL-V2' routed out of structural estimates ('Between-subject variability (CV%, covariance for ρ)')</li><li>table section residual_error: 'σAdd' routed out of structural estimates ('Intra-individual variability (residual error)')</li><li>unit_dimension_unknown: 'Period 1*' (CL/F)</li><li>dropped unlinked row (NIL): 'ALAG 1' — extend the ontology if this is a real PK parameter (source ['T3:row9:col5'])</li><li>unit_dimension_unknown: 'Period 1*' (Fab)</li><li>unit_dimension_unknown: 'Period 2' (Fab)</li><li>dropped duplicate Q40 ('F1 (Period 2)', value '0.468') — already have one for this compound</li><li>dropped unlinked row (NIL): 'BIO' — extend the ontology if this is a real PK parameter (source ['T3:row13:col5'])</li><li>implicit units: 'CL/F (Period 1*)' → L/h (from the paper text: &quot;The paper text explicitly states the value for the same parameter in the final model context as 'clearance (CL/F) = 25.5&quot;)</li><li>implicit units: 'CL change' → L/h (from the paper text: &quot;The paper text explicitly states the value as 'change in CL = 3.90 L/h'.&quot;)</li><li>implicit units: 'V2/F' → L (from the paper text: &quot;The paper text explicitly states the value as 'central volume (V2/F) = 943 L'.&quot;)</li><li>implicit units: 'V3/F' → L (from the paper text: &quot;The paper text explicitly states the value as 'peripheral volume (V3/F) = 403 L'.&quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Hong2021_mb2_estimates;
