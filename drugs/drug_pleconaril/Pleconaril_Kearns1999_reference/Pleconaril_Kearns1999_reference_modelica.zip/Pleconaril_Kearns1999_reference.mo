model Pleconaril_Kearns1999_reference
  parameter Real Cl_ref = 1.575e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3276 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.381349,
    adminMass = 0.0001,
    ka = 0.00020833333333333332,
    Tlag = 2700.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pleconaril</h4><p>Pleconaril is an investigational antiviral drug being developed to prevent asthma exacerbations and common cold symptoms caused by picornavirus respiratory infections. It is administered orally or intranasally to treat infections caused by viruses in the Picornaviridae family. Pleconaril is currently an investigational medication that has not yet been authorized for general use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q770293\">Wikidata Q770293</a>, <a href=\"https://en.wikipedia.org/wiki/Pleconaril?oldid=1328745875\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pleconaril</td></tr><tr><td>population:</td><td>children aged 2 to 12 years</td></tr><tr><td>source_paper:</td><td>Kearns_1999</td></tr><tr><td>measured_compound:</td><td>pleconaril</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pleconaril 381.349 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pleconaril</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Pleconaril_Kearns1999_reference;
