% Run (SimBiology): build model + dose, simulate 0..33.0 h, plot.
p = Pleconaril_Kearns1999_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 33.0);
