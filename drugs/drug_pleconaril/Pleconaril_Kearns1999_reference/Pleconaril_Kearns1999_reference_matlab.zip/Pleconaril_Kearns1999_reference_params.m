function p = Pleconaril_Kearns1999_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pleconaril   source: Kearns_1999 / reference   route: oral
  % estimated (absent from source): dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Pleconaril_Kearns1999_reference_params';
  p.drug  = 'pleconaril';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 327.6;                % central volume [L]
  p.CL = 56.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.75;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.75;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
