% Run (SimBiology): build model + dose, simulate 0..4320.0 h, plot.
p = Diazepam_Yau2023v2_2b_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4320.0);
