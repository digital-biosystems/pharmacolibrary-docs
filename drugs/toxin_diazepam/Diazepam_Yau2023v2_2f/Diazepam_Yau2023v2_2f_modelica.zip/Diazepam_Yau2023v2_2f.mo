model Diazepam_Yau2023v2_2f
  parameter Real Cl_ref = 2.0166666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 9.73 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28474299999999997,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazepam</td></tr><tr><td>population:</td><td>male rats, male cynomolgus monkeys, healthy male and female humans</td></tr><tr><td>source_paper:</td><td>Yau_2023_2</td></tr><tr><td>measured_compound:</td><td>Diazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412915-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diazepam 284.743 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'RSE%' (Kp)</li><li>unit_dimension_unknown: 'RSE%' (Kp)</li><li>dropped duplicate Q410 ('Kpu2/SF2 (RSE%)', value '334') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Kpu3/SF3 (RSE%)' — extend the ontology if this is a real PK parameter (source ['psp412915-tbl-0002:row7:col4'])</li><li>dropped unlinked row (NIL): 'Kpu4/SF4 (RSE%)' — extend the ontology if this is a real PK parameter (source ['psp412915-tbl-0002:row7:col5'])</li><li>salvaged Q22 ('CL'=7.26) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('human unbound volume of distribution in plasma (Vuss,p)'=139) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Diazepam</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: '2f' subgroup of Yau_2023_2 (paper reports 9 populations: 2a, 2b, 2c, 2d, 2e, 2f, human, monkey, rat)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Diazepam_Yau2023v2_2f;
