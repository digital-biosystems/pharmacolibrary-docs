function p = Diazepam_Yau2023v2_2f_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diazepam   source: Yau_2023_2 / 2f   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Diazepam_Yau2023v2_2f_params';
  p.drug  = 'diazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9730.0;                % central volume [L]
  p.CL = 7.26;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
