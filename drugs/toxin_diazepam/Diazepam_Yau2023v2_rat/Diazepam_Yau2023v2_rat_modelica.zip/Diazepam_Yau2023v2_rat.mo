model Diazepam_Yau2023v2_rat
  parameter Real Cl_ref = 2.0166666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 9.73 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28474299999999997,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazepam</td></tr><tr><td>population:</td><td>male rats, male cynomolgus monkeys, healthy male and female humans</td></tr><tr><td>source_paper:</td><td>Yau_2023_2</td></tr><tr><td>measured_compound:</td><td>Diazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412915-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diazepam 284.743 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Adipose' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row1:col1'])</li><li>dropped unlinked row (NIL): 'Arterial' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row2:col1'])</li><li>dropped unlinked row (NIL): 'Bone' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row3:col1'])</li><li>dropped unlinked row (NIL): 'Gut' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row5:col1'])</li><li>dropped unlinked row (NIL): 'Heart' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row6:col1'])</li><li>dropped unlinked row (NIL): 'Kidney' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row7:col1'])</li><li>dropped unlinked row (NIL): 'Liver' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row8:col1'])</li><li>dropped unlinked row (NIL): 'Lung' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row9:col1'])</li><li>dropped unlinked row (NIL): 'Muscle' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row10:col1'])</li><li>dropped unlinked row (NIL): 'Pancreas' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row11:col1'])</li><li>dropped unlinked row (NIL): 'RoB' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row12:col1'])</li><li>dropped unlinked row (NIL): 'Spleen' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row14:col1'])</li><li>dropped unlinked row (NIL): 'Stomach' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row15:col1'])</li><li>dropped unlinked row (NIL): 'Venous' — extend the ontology if this is a real PK parameter (source ['Yau_2023_2_table_S7:row16:col1'])</li><li>salvaged Q22 ('CL'=7.26) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('human unbound volume of distribution in plasma (Vuss,p)'=139) from results prose — parameter table was unreadable</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Diazepam_Yau2023v2_rat;
