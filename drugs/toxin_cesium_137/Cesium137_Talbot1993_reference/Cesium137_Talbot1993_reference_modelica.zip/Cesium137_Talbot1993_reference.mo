// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cesium137_Talbot1993_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {8812800.0},
    MM = 0.13291,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cesium_137</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Talbot_1993</td></tr><tr><td>measured_compound:</td><td>Cesium-137</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cesium-137 132.91 g/mol (pubchem); cesium_137 132.91 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'The fraction cleared with this half-time was' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('The fraction cleared with this half-time was', value 80) — already have one for this compound</li><li>dropped unlinked row (NIL): &quot;ICRP's assumption of&quot; — extend the ontology if this is a real PK parameter (source ['Talbot_1993:abstract'])</li><li>dropped unlinked row (NIL): 'with a' — extend the ontology if this is a real PK parameter (source ['Talbot_1993:abstract'])</li><li>dropped unlinked row (NIL): 'average uptake (f1) of' — extend the ontology if this is a real PK parameter (source ['Talbot_1993:abstract'])</li><li>dropped duplicate Q57 ('half-time', value '119') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cesium-137</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Cesium137_Talbot1993_reference;
