// retention function (2 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cesium137_Jo2024_muscle_and_skin_tissues
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 2,
    A = {0.3846153846153846, 0.6153846153846153},
    Tb = {25702.968412179947, 565056.0},
    MM = 0.13291,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cesium_137</td></tr><tr><td>population:</td><td>flower chafer larvae (Protaetia orientalis)</td></tr><tr><td>source_paper:</td><td>Jo_2024</td></tr><tr><td>measured_compound:</td><td>137Cs</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pone.0310088.t002</td></tr><tr><td>input:</td><td>retention, 2 pool(s): coefficients in Bq/g-dry normalised to their sum — the pools describe the measured curve's shape, C(t)/C(0), not a share of the intake</td></tr><tr><td>molar_masses:</td><td>137Cs 132.91 g/mol (pubchem); cesium_137 132.91 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Bq/g-dry' (A1)</li><li>unit_dimension_unknown: 'Bq/g-dry' (A2)</li><li>implicit units: 'λ1' → 1/d (from the printed half-life: 'λ1 = 2.33 and Tb1 (day) = 0.30 day: λ·t½ = ln2 only in 1/d')</li><li>implicit units: 'λ2' → 1/d (from the printed half-life: 'λ2 = 0.11 and Tb2 (day) = 6.54 day: λ·t½ = ln2 only in 1/d')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=137Cs</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'muscle and skin tissues' subgroup of Jo_2024 (paper reports 2 populations: digestive tract, muscle and skin tissues)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 6048.0));
end Cesium137_Jo2024_muscle_and_skin_tissues;
