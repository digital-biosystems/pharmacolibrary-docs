// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cesium137_Thomas2018_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {299439.58200189634},
    MM = 0.13291,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cesium_137</td></tr><tr><td>population:</td><td>marine and freshwater plankton and planktivorous fish</td></tr><tr><td>source_paper:</td><td>Thomas_2018</td></tr><tr><td>measured_compound:</td><td>Cesium-137</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cesium-137 132.91 g/mol (pubchem); cesium_137 132.91 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for body_burden from footnote/prose kept as documentation only (['Thomas_2018:abstract'])</li><li>covariate category for body_burden from footnote/prose kept as documentation only (['Thomas_2018:abstract'])</li><li>dropped duplicate Q47 ('Rate constants of 137Cs loss from fish following aqueous exposure ... in ... freshwater conditions', value 0.4) — already have one for this compound</li><li>relinked 'Rate constants of 137Cs loss from fish ... following dietary exposure ... marine' Q100 → Q47: a rate constant in 'd-1' (the unit decides, not the label)</li><li>dropped duplicate Q47 ('Rate constants of 137Cs loss from fish ... following dietary exposure ... marine', value 0.06) — already have one for this compound</li><li>dropped duplicate Q47 ('Rate constants of 137Cs loss from fish ... following dietary exposure ... freshwater', value 0.3) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cesium-137</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 3110.4));
end Cesium137_Thomas2018_reference;
