function p = Lanadelumab_Wang2020_PD_chmwk_params()
% Lanadelumab_Wang2020_PD_chmwk_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lanadelumab Wang_2020::cHMWK: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response cHMWK in its own unit. Driver: lanadelumab (pk_record).
p.E0 = 32.152588555858316;
p.Emax = 53.7;
p.EC50 = 0.005709999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 8.6;
p.form = 'E0/(1 + Emax*frac)';
end
