model Lanadelumab_Wang2020_PD_chmwk
  "indirect_response_i exposure-response sweep — Wang_2020 :: cHMWK (cHMWK)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 32.1525885559,      // [1]
    Emax = 53.7,  // type IV effect term
    EC50 = 0.00571,  // [kg/m3; µg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (11.8/0.367 = 32.15) — the paper's stated baseline may differ
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 53.7; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8.6, Interval = 0.0172),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lanadelumab</h4><p>Lanadelumab, a monoclonal antibody, is used to treat hereditary angioedema. It is authorised in the European Union and is an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25326708\">Wikidata Q25326708</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lanadelumab_Wang2020_PD_chmwk</h4><p>The steady-state exposure-response curve of Wang Y et al., <i>Clinical and translational science 13(6):1208–1216</i> 2020 (<a href=\"https://doi.org/10.1111/cts.12806\">doi:10.1111/cts.12806</a>) — cHMWK against lanadelumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 32.1525885559          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       53.7          maximal effect term (Imax, Q323)
  EC50  =       5.71 µg/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of lanadelumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 32.15   (drug-free)
  exposure = EC50 (5.71 µg/mL)  response 1.154
  exposure -> infinity  response 0.5878</pre></body></html>"));
end Lanadelumab_Wang2020_PD_chmwk;
