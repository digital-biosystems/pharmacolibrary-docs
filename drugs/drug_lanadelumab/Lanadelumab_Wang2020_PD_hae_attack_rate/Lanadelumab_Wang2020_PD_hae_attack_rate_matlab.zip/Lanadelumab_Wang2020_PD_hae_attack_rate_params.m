function p = Lanadelumab_Wang2020_PD_hae_attack_rate_params()
% Lanadelumab_Wang2020_PD_hae_attack_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lanadelumab Wang_2020::HAE_attack_rate: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response HAE attack rate in attacks/month. Driver: lanadelumab (pk_record).
p.E0 = 0.0;
p.Emax = -3.74;
p.EC50 = 0.00403;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 41.0;
p.form = 'E0 + Emax*frac';
end
