model Lanadelumab_Wang2020_PD_hae_attack_rate
  "emax exposure-response sweep — Wang_2020 :: HAE attack rate (HAE attack rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -3.74,  // [attacks/month]
    EC50 = 0.00403,  // [kg/m3; µg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 41, Interval = 0.082),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lanadelumab</h4><p>Lanadelumab, a monoclonal antibody, is used to treat hereditary angioedema. It is authorised in the European Union and is an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25326708\">Wikidata Q25326708</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lanadelumab_Wang2020_PD_hae_attack_rate</h4><p>The steady-state exposure-response curve of Wang Y et al., <i>Clinical and translational science 13(6):1208–1216</i> 2020 (<a href=\"https://doi.org/10.1111/cts.12806\">doi:10.1111/cts.12806</a>) — HAE attack rate [attacks/month] against lanadelumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      -3.74 attacks/month maximal effect term (Emax, Q323)
  EC50  =       4.03 µg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of lanadelumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.03 µg/mL)  response -1.87
  exposure -> infinity  response -3.74</pre></body></html>"));
end Lanadelumab_Wang2020_PD_hae_attack_rate;
