model Benzylideneacetone_Sauer1997_reference
  parameter Real Cl_ref = 0.0006183333333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2331 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>benzylideneacetone</td></tr><tr><td>population:</td><td>female B6C3F1 mice</td></tr><tr><td>source_paper:</td><td>Sauer_1997</td></tr><tr><td>measured_compound:</td><td>trans-methyl styryl ketone ([14C]-equivalents)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>benzylideneacetone 146.189 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trans-methyl styryl ketone ([14C]-equivalents)</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/4 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'trans-methyl styryl ketone' — its concentrations stay mass-only</li><li>molar mass: none found for 'N-phenylacetyl-L-glycine' — its concentrations stay mass-only</li><li>molar mass: none found for 'N-benzyl-L-glycine' — its concentrations stay mass-only</li><li>molar mass: none found for 'trans-methyl styryl ketone ([14C]-equivalents)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Benzylideneacetone_Sauer1997_reference;
