model Caplacizumab_Fan2025_reference
  parameter Real Cl_ref = 6.8055555555555556e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0018829999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001277777777777778,
    Tlag = 0.0,
    k12 = 2.7438484687555324e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>caplacizumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Fan_2025</td></tr><tr><td>measured_compound:</td><td>caplacizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Fan_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Caplacizumab_Fan2025_reference;
