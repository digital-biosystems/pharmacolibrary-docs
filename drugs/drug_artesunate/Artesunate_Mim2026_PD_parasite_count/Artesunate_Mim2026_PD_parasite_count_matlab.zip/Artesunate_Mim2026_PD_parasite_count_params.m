function p = Artesunate_Mim2026_PD_parasite_count_params()
% Artesunate_Mim2026_PD_parasite_count_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artesunate Mim_2026::parasite_count: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response parasite count in %. Driver: artesunate (pk_record).
p.E0 = 0.17800000000000002;
p.Emax = 1.0;
p.EC50 = 10.93;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 110.0;
p.form = 'E0*(1 - Emax*frac)';
end
