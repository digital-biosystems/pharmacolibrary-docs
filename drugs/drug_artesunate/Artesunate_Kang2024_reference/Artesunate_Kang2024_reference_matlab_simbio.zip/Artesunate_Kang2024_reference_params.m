function p = Artesunate_Kang2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: artesunate   source: Kang_2024 / reference   route: oral
  p.name  = 'Artesunate_Kang2024_reference_params';
  p.drug  = 'artesunate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2312.1;                % central volume [L]
  p.CL = 933.1;                % clearance [L/h]
  p.Vp = [33673.5];             % peripheral volumes [L]
  p.Q  = [5788.3];             % inter-compartmental clearances [L/h]
  p.ka = 1.54;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4200.0;             % dose [mg]
end
