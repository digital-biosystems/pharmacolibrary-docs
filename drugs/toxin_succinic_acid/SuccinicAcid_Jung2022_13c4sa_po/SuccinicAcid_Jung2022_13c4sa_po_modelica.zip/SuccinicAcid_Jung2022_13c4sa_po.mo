// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SuccinicAcid_Jung2022_13c4sa_po
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2988.0},
    adminMass = 0.0007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>succinic_acid</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Jung_2022</td></tr><tr><td>measured_compound:</td><td>Succinic acid-13C4</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>nutrients-14-04757-t005</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>succinic_acid 118.088 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'MRT4h (h)' → Q19 (unit '[time]' vs ontology '[mass] * [time] / [length] ** 3') — route to review</li><li>dropped duplicate Q19 ('MRT4h (h)', value '0.44') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Succinic acid-13C4</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: '13c4sa / po' subgroup of Jung_2022 (paper reports 2 populations: 13c4sa / iv, 13c4sa / po)</li><li>molar mass: no plausible PubChem entry for 'Succinic acid-13C4' ('succinic acid-13C4') — left in mass units</li><li>molar mass: none found for 'Succinic acid-13C4' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end SuccinicAcid_Jung2022_13c4sa_po;
