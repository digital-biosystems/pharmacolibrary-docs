model Sulpiride_Bressolle1984_reference
  parameter Real Cl_ref = 1.4966666666666664e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01015 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.341426,
    adminMass = 0.0008
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulpiride</h4><p>Sulpiride is a benzamide antipsychotic used mainly for psychosis in schizophrenia and major depressive disorder. Sulpiride is used widely in Europe, Asia, and the Americas but is not approved in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422418\">Wikidata Q422418</a>, <a href=\"https://en.wikipedia.org/wiki/Sulpiride?oldid=1383537304\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulpiride</td></tr><tr><td>population:</td><td>healthy adult males</td></tr><tr><td>source_paper:</td><td>Bressolle_1984</td></tr><tr><td>measured_compound:</td><td>sulpiride</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sulpiride 341.426 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q65 ('steady-state volume of distribution', value 0.639) — already have one for this compound</li><li>dropped duplicate Q26 ('renal clearance of unbound drug', value 97.6) — already have one for this compound</li><li>dropped unlinked row (NIL): 'recovered unchanged in urine' — extend the ontology if this is a real PK parameter (source ['Bressolle_1984:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulpiride</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulpiride_Bressolle1984_reference;
