function p = Sulpiride_Bressolle1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulpiride   source: Bressolle_1984 / reference   route: oral
  p.name  = 'Sulpiride_Bressolle1984_reference_params';
  p.drug  = 'sulpiride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.15;                % central volume [L]
  p.CL = 5.388;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.66;                % absorption rate [1/h]
  p.F  = 0.15;                 % bioavailability [0-1]
  p.Tlag = 1.5;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
