model FusaricAcid_Stack2014_reference
  parameter Real Cl_ref = 7.104999999999999e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01834 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.179219,
    adminMass = 0.00175
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fusaric_acid</td></tr><tr><td>population:</td><td>Male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Stack_2014</td></tr><tr><td>measured_compound:</td><td>Fusaric Acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Fusaric Acid 179.219 g/mol (pubchem); fusaric_acid 179.219 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC IV'</li><li>dropped value-less row: 'AUC PO'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'C max'</li><li>dropped value-less row: 'IV'</li><li>dropped value-less row: 'PO'</li><li>dropped value-less row: 'T ½'</li><li>dropped value-less row: 'T max'</li><li>dropped value-less row: 'Vd'</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>salvaged Q57 ('elimination half-life IV'=33) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Rat 1 IV Vd'=262) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Rat 1 IV CL'=6.09) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fusaric Acid</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end FusaricAcid_Stack2014_reference;
