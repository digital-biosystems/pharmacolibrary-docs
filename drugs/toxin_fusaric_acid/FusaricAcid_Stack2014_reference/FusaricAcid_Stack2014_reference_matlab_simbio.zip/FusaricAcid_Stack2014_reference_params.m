function p = FusaricAcid_Stack2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fusaric_acid   source: Stack_2014 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'FusaricAcid_Stack2014_reference_params';
  p.drug  = 'fusaric_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 18.34;                % central volume [L]
  p.CL = 25.578;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1750.0;             % dose [mg]
end
