function p = Epcoritamab_Li2022_PD_orr_params()
% Epcoritamab_Li2022_PD_orr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% epcoritamab Li_2022::ORR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response ORR in its own unit. Driver: epcoritamab (cited_pk).
p.E0 = 0.0;
p.Emax = 0.762;
p.EC50 = 0.788;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 7.9;
p.form = 'E0 + Emax*frac';
end
