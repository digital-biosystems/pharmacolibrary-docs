model Epcoritamab_Li2022_PD_orr
  "emax exposure-response sweep — Li_2022 :: ORR (clinical response rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.762,  // [1; % × 0.01]
    EC50 = 0.788,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7.9, Interval = 0.0158),
    Documentation(info = "<html><body><!-- drug-about --><h4>About epcoritamab</h4><p>Epcoritamab is a monoclonal antibody used to treat diffuse large B-cell lymphoma. It is administered via subcutaneous injection. The drug is authorised in the European Union and approved for use in the United States and Canada.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q119025940\">Wikidata Q119025940</a>, <a href=\"https://en.wikipedia.org/wiki/Epcoritamab?oldid=1372906024\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Epcoritamab_Li2022_PD_orr</h4><p>The steady-state exposure-response curve of Li T et al., <i>Clinical pharmacology and therapeutics 112(5):1108–1119</i> 2022 (<a href=\"https://doi.org/10.1002/cpt.2729\">doi:10.1002/cpt.2729</a>) — clinical response rate against epcoritamab nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       76.2 %        maximal effect term (model‐predicted Emax, Q320)
  EC50  =      0.788 nM       exposure at half of the maximal effect term (estimated half‐maximal effective concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of epcoritamab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.788 nM)  response 0.381
  exposure -> infinity  response 0.762</pre></body></html>"));
end Epcoritamab_Li2022_PD_orr;
