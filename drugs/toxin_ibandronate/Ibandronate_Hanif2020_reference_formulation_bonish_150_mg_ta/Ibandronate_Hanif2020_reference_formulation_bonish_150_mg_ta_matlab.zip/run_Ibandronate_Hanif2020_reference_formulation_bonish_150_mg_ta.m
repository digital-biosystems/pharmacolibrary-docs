% Run: build params, simulate 0..31.0 h, plot every molecule + save Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.m
here = fileparts(mfilename('fullpath'));
p = Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta_params();
out = simulate_network(p, 0:0.05:31.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('ibandronate — Hanif_2020 (retention function)');
print(fig, fullfile(here, 'Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.json'), 'w');
try
  s.model = 'Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.png, Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.csv, Ibandronate_Hanif2020_reference_formulation_bonish_150_mg_ta.json\n');
