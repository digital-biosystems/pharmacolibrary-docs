% Run: build params, simulate 0..48.0 h, plot every molecule + save Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.m
here = fileparts(mfilename('fullpath'));
p = Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis_params();
out = simulate_network(p, 0:0.05:48.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('ibandronate — Nakai_2016 (retention function)');
print(fig, fullfile(here, 'Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.json'), 'w');
try
  s.model = 'Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.png, Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.csv, Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis.json\n');
