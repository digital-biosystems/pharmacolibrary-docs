// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {34524.0},
    MM = 0.319231,
    adminMass = 2.5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibandronate</td></tr><tr><td>population:</td><td>Japanese patients with osteoporosis, healthy postmenopausal Japanese women, and postmenopausal Japanese women with osteopenia</td></tr><tr><td>source_paper:</td><td>Nakai_2016</td></tr><tr><td>measured_compound:</td><td>Ibandronate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ibandronate 319.231 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Administration / Number'; source reconciliation required</li><li>table representations disagree for 'AUCinf (ng h/mL)'; source reconciliation required</li><li>table representations disagree for 'C max or C 5min (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'T max (h)'; source reconciliation required</li><li>table representations disagree for 't 1/2 (h)'; source reconciliation required</li><li>table representations disagree for 'CLr (mL/min)'; source reconciliation required</li><li>table representations disagree for 'Fe (%)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Administration / Number' — extend the ontology if this is a real PK parameter (source ['Tab2:row6:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ibandronate</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'postmenopausal women with osteoporosis' subgroup of Nakai_2016 (paper reports 4 populations: healthy postmenopausal women, postmenopausal healthy women + postmenopausal women with osteoporosis, postmenopausal women with osteopenia, postmenopausal women with osteoporosis)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 345.6));
end Ibandronate_Nakai2016_postmenopausal_women_with_osteoporosis;
