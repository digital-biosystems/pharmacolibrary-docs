model Dexrazoxane_Mody2023_PD_k_dexi
  "emax exposure-response sweep — Mody_2023 :: K_DEXi (Cardioprotection (Inhibition of DOX-induced cell death stimulation))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.73611111111e-05,  // [1/s; hour−1 × 0.000277778]
    EC50 = 39,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 390, Interval = 0.78),
    Documentation(info = "<html><body><h4>Dexrazoxane_Mody2023_PD_k_dexi</h4><p>The steady-state exposure-response curve of Mody H et al., <i>Scientific reports 13(1):3100</i> 2023 (<a href=\"https://doi.org/10.1038/s41598-023-29964-4\">doi:10.1038/s41598-023-29964-4</a>) — Cardioprotection (Inhibition of DOX-induced cell death stimulation) [hour−1] against dexrazoxane µM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0625 hour−1   maximal effect term (Imax, DEXi, Q323)
  EC50  =         39 µM       exposure at half of the maximal effect term (IC50, DEXi, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of dexrazoxane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (39 µM)  response -8.681e-06
  exposure -> infinity  response -1.736e-05</pre></body></html>"));
end Dexrazoxane_Mody2023_PD_k_dexi;
