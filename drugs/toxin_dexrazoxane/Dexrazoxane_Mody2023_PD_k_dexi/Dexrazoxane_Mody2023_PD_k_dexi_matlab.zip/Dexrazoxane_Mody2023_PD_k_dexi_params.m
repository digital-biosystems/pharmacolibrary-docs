function p = Dexrazoxane_Mody2023_PD_k_dexi_params()
% Dexrazoxane_Mody2023_PD_k_dexi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexrazoxane Mody_2023::K_DEXi: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response K_DEXi in hour−1. Driver: dexrazoxane (pk_record).
p.E0 = 0.0;
p.Emax = -1.736111111111111e-05;
p.EC50 = 39.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 390.0;
p.form = 'E0 + Emax*frac';
end
