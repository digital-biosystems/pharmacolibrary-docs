model Dexrazoxane_Mody2023_PD_r
  "linear exposure-response sweep — Mody_2023 :: R (Cell viability)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 1.01,      // [1; % × 0.01]
    slope = 9680,  // [1 / meter; µM−1 × 1e+06]
    exposure_per_s = 1);   // 1 µM per second
  // family_inferred: the record's model family is unknown; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Dexrazoxane_Mody2023_PD_r</h4><p>The steady-state exposure-response curve of Mody H et al., <i>Scientific reports 13(1):3100</i> 2023 (<a href=\"https://doi.org/10.1038/s41598-023-29964-4\">doi:10.1038/s41598-023-29964-4</a>) — Cell viability [%] against dexrazoxane µM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        101 %        drug-free response (baseline) (R0, Q324)
  slope =    0.00968 µM−1     change in response per unit of exposure (S_DEX, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µM of dexrazoxane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.01   (drug-free)</pre></body></html>"));
end Dexrazoxane_Mody2023_PD_r;
