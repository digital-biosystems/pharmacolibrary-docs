model Dexrazoxane_Mody2023v2_PD_r
  "indirect_response_iv exposure-response sweep — Mody_2023_2 :: R (% cell viability)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 1.06,      // [1; % × 0.01]
    Emax = 0.74,  // type IV effect term
    EC50 = 21.2,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><h4>Dexrazoxane_Mody2023v2_PD_r</h4><p>The steady-state exposure-response curve of Mody H et al., <i>Frontiers in pharmacology 14:1239141</i> 2023 (<a href=\"https://doi.org/10.3389/fphar.2023.1239141\">doi:10.3389/fphar.2023.1239141</a>) — % cell viability [%] against Dexrazoxane µM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        106 %        drug-free response (baseline) (Baseline (JIMT-1), Q324)
  Emax  =       0.74          maximal effect term (Imax (JIMT-1), Q320)
  EC50  =       21.2 µM       exposure at half of the maximal effect term (SC50 (JIMT-1), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one µM of Dexrazoxane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.06   (drug-free)
  exposure = EC50 (21.2 µM)  response 0.7737
  exposure -> infinity  response 0.6092</pre></body></html>"));
end Dexrazoxane_Mody2023v2_PD_r;
