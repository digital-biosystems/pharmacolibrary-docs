function p = Amitriptyline_Mayer2016_PD_inhibition_of_3h_qnb_binding_params()
% Amitriptyline_Mayer2016_PD_inhibition_of_3h_qnb_binding_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amitriptyline Mayer_2016::inhibition_of_3H_QNB_binding: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response % inhibition of 3H-QNB binding in %. Driver: amitriptyline (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.36;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3.6;
p.form = 'E0 + Emax*frac';
end
