model Amitriptyline_Mayer2016_PD_inhibition_of_3h_qnb_binding
  "sigmoid_emax exposure-response sweep — Mayer_2016 :: % inhibition of 3H-QNB binding (% inhibition of 3H-QNB binding)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 0.36,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.6, Interval = 0.0072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amitriptyline</h4><p>Amitriptyline is a tricyclic antidepressant prescribed for major depressive disorder and various pain conditions, including neuropathic pain, migraine, and fibromyalgia. It is widely used as a generic medication and is listed as an essential medicine by the World Health Organization.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q58397\">Wikidata Q58397</a>, <a href=\"https://en.wikipedia.org/wiki/Amitriptyline?oldid=1383658662\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amitriptyline_Mayer2016_PD_inhibition_of_3h_qnb_binding</h4><p>The steady-state exposure-response curve of Mayer T et al., <i>The American journal of geriatric psychiatry : official journal of the American Association for Geriatric Psychiatry 24(12):1182–1188</i> 2016 (<a href=\"https://doi.org/10.1016/j.jagp.2016.07.024\">doi:10.1016/j.jagp.2016.07.024</a>) — % inhibition of 3H-QNB binding [%] against amitriptyline μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q323)
  EC50  =       0.36 μM       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of amitriptyline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.36 μM)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Amitriptyline_Mayer2016_PD_inhibition_of_3h_qnb_binding;
