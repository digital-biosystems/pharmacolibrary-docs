function p = CertolizumabPegol_Menshykau2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: certolizumab_pegol   source: Menshykau_2024 / reference   route: oral
  p.name  = 'CertolizumabPegol_Menshykau2024_reference_params';
  p.drug  = 'certolizumab_pegol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.86;                % central volume [L]
  p.CL = 0.017333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.009833;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
