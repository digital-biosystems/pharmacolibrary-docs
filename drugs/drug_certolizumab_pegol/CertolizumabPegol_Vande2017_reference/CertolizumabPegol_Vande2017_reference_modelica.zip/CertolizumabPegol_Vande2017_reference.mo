model CertolizumabPegol_Vande2017_reference
  parameter Real Cl_ref = 6.099537037037037e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00833 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 2.1180555555555556e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About certolizumab_pegol</h4><p>Certolizumab pegol is a TNF-alpha inhibitor used to treat inflammatory conditions such as rheumatoid arthritis, Crohn's disease, and ankylosing spondylitis. It is an approved medicine, authorised in the European Union, and is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412909\">Wikidata Q412909</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>certolizumab_pegol</td></tr><tr><td>population:</td><td>patients with Crohn's disease</td></tr><tr><td>source_paper:</td><td>Vande_2017</td></tr><tr><td>measured_compound:</td><td>certolizumab_pegol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'ADAb concentration'</li><li>dropped value-less row: 'body weight'</li><li>dropped value-less row: 'Albumin'</li><li>dropped value-less row: 'C-reactive protein'</li><li>routed 'Between-patient variability of CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=certolizumab_pegol</li><li>molar mass: none found for 'certolizumab_pegol' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end CertolizumabPegol_Vande2017_reference;
