function p = CertolizumabPegol_Wade2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: certolizumab_pegol   source: Wade_2015 / reference   route: oral
  p.name  = 'CertolizumabPegol_Wade2015_reference_params';
  p.drug  = 'certolizumab_pegol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.61;                % central volume [L]
  p.CL = 0.028542;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.008333;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
