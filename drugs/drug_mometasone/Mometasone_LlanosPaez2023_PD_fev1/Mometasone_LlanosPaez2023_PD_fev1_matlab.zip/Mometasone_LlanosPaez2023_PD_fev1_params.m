function p = Mometasone_LlanosPaez2023_PD_fev1_params()
% Mometasone_LlanosPaez2023_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mometasone Llanos-Paez_2023::FEV1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ug per second, in SI inside (kg/m3, s). Response FEV1 in L. Driver: mometasone (dose_only).
p.E0 = 0.0;
p.Emax = 6.88e-05;
p.EC50 = 7.500000000000001e-10;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 7.5;
p.form = 'E0 + Emax*frac';
end
