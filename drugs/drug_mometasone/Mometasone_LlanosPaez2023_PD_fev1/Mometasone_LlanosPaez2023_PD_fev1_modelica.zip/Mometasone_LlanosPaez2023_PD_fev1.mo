model Mometasone_LlanosPaez2023_PD_fev1
  "emax exposure-response sweep — Llanos-Paez_2023 :: FEV1 (FEV1)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 6.88e-05,  // [m3; mL × 1e-06]
    EC50 = 7.5e-10,  // [kg; ug × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 ug per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7.5, Interval = 0.015),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mometasone</h4><p>Mometasone is a corticosteroid used to treat nasal conditions such as rhinitis, sinusitis, and nasal polyps, and is also applied to the skin as a potent topical corticosteroid. It is an approved medicine, available in nasal, inhalation, and skin preparations, and is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28208887\">Wikidata Q28208887</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mometasone_LlanosPaez2023_PD_fev1</h4><p>The steady-state exposure-response curve of Llanos-Paez C et al., <i>Journal of pharmacokinetics and pharmacodynamics 50(4):297-314</i> 2023 (<a href=\"https://doi.org/10.1007/s10928-023-09853-z\">doi:10.1007/s10928-023-09853-z</a>) — FEV1 [L] against mometasone ug — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       68.8 mL       maximal effect term (Effref, Q320)
  EC50  =       0.75 ug       exposure at half of the maximal effect term (Arformoterol 25 (b.i.d.) ED50 (95%CI)[ug], Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ug of mometasone per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.75 ug)  response 3.44e-05
  exposure -> infinity  response 6.88e-05</pre></body></html>"));
end Mometasone_LlanosPaez2023_PD_fev1;
