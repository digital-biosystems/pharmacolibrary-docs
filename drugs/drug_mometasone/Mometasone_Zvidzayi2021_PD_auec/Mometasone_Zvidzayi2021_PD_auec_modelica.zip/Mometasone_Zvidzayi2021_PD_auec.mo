model Mometasone_Zvidzayi2021_PD_auec
  "emax exposure-response sweep — Zvidzayi_2021 :: AUEC (skin blanching response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -94.45,  // [1]
    EC50 = 13546.2,  // [s; min × 60]
    gamma = 1,
    exposure_per_s = 60);   // 1 min per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2300, Interval = 4.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mometasone</h4><p>Mometasone is a corticosteroid used to treat nasal conditions such as rhinitis, sinusitis, and nasal polyps, and is also applied to the skin as a potent topical corticosteroid. It is an approved medicine, available in nasal, inhalation, and skin preparations, and is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28208887\">Wikidata Q28208887</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mometasone_Zvidzayi2021_PD_auec</h4><p>The steady-state exposure-response curve of Zvidzayi M et al., <i>Pharmaceutics 13(9)</i> 2021 (<a href=\"https://doi.org/10.3390/pharmaceutics13091456\">doi:10.3390/pharmaceutics13091456</a>) — skin blanching response against mometasone furoate min — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     -94.45          maximal effect term (Emax, Q323)
  EC50  =     225.77 min      exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one min of mometasone furoate per second of simulated time (exposure is in s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (225.77 min)  response -47.23
  exposure -> infinity  response -94.45</pre></body></html>"));
end Mometasone_Zvidzayi2021_PD_auec;
