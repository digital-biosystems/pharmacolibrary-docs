function p = Mometasone_Zvidzayi2021_PD_auec_params()
% Mometasone_Zvidzayi2021_PD_auec_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mometasone Zvidzayi_2021::AUEC: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one min per second, in SI inside (kg/m3, s). Response AUEC in its own unit. Driver: mometasone furoate (dose_only).
p.E0 = 0.0;
p.Emax = -94.45;
p.EC50 = 13546.2;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 60.0;
p.stop_time = 2300.0;
p.form = 'E0 + Emax*frac';
end
