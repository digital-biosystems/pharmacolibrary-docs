model Mometasone_Vlachou2021_reference
  parameter Real Cl_ref = 6.166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0013 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.427361,
    adminMass = 0.0001,
    ka = 0.00023616666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mometasone</h4><p>Mometasone is a corticosteroid used to treat nasal conditions such as rhinitis, sinusitis, and nasal polyps, and is also applied to the skin as a potent topical corticosteroid. It is an approved medicine, available in nasal, inhalation, and skin preparations, and is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28208887\">Wikidata Q28208887</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mometasone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Vlachou_2021</td></tr><tr><td>measured_compound:</td><td>mometasone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mometasone 427.361 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Vlachou_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mometasone_Vlachou2021_reference;
