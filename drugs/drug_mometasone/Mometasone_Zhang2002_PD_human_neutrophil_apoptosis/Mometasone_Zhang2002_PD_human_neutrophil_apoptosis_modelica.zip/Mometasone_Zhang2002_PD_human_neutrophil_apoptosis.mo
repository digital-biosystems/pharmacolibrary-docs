model Mometasone_Zhang2002_PD_human_neutrophil_apoptosis
  "emax exposure-response sweep — Zhang_2002 :: human neutrophil apoptosis (human neutrophil apoptosis)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.5,  // [1; % × 0.01]
    EC50 = 0.17,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.7, Interval = 0.0034),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mometasone</h4><p>Mometasone is a corticosteroid used to treat nasal conditions such as rhinitis, sinusitis, and nasal polyps, and is also applied to the skin as a potent topical corticosteroid. It is an approved medicine, available in nasal, inhalation, and skin preparations, and is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28208887\">Wikidata Q28208887</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mometasone_Zhang2002_PD_human_neutrophil_apoptosis</h4><p>The steady-state exposure-response curve of Zhang X et al., <i>Life sciences 71(13):1523–1534</i> 2002 (<a href=\"https://doi.org/10.1016/s0024-3205(02)01921-5\">doi:10.1016/s0024-3205(02)01921-5</a>) — human neutrophil apoptosis against mometasone nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         50 %        maximal effect term (maximal inhibition, Q323)
  EC50  =       0.17 nM       exposure at half of the maximal effect term (EC(50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of mometasone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.17 nM)  response -0.25
  exposure -> infinity  response -0.5</pre></body></html>"));
end Mometasone_Zhang2002_PD_human_neutrophil_apoptosis;
