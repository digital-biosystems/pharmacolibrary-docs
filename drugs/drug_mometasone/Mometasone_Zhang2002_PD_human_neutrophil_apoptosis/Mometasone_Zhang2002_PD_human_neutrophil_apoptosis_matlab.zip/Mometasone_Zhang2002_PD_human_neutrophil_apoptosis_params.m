function p = Mometasone_Zhang2002_PD_human_neutrophil_apoptosis_params()
% Mometasone_Zhang2002_PD_human_neutrophil_apoptosis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mometasone Zhang_2002::human_neutrophil_apoptosis: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response human neutrophil apoptosis in its own unit. Driver: mometasone (cited_pk).
p.E0 = 0.0;
p.Emax = -0.5;
p.EC50 = 0.17;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.7;
p.form = 'E0 + Emax*frac';
end
