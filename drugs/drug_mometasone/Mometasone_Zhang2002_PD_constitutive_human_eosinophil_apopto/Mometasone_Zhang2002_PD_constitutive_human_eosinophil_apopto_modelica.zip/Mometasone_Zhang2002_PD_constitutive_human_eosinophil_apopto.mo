model Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto
  "emax exposure-response sweep — Zhang_2002 :: constitutive human eosinophil apoptosis (constitutive human eosinophil apoptosis)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.1,  // [fold]
    EC50 = 5.63,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 57, Interval = 0.114),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mometasone</h4><p>Mometasone is a corticosteroid used to treat nasal conditions such as rhinitis, sinusitis, and nasal polyps, and is also applied to the skin as a potent topical corticosteroid. It is an approved medicine, available in nasal, inhalation, and skin preparations, and is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28208887\">Wikidata Q28208887</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto</h4><p>The steady-state exposure-response curve of Zhang X et al., <i>Life sciences 71(13):1523–1534</i> 2002 (<a href=\"https://doi.org/10.1016/s0024-3205(02)01921-5\">doi:10.1016/s0024-3205(02)01921-5</a>) — constitutive human eosinophil apoptosis against mometasone nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        2.1 fold     maximal effect term (maximal enhancement, Q320)
  EC50  =       5.63 nM       exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of mometasone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.63 nM)  response 1.05
  exposure -> infinity  response 2.1</pre></body></html>"));
end Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto;
