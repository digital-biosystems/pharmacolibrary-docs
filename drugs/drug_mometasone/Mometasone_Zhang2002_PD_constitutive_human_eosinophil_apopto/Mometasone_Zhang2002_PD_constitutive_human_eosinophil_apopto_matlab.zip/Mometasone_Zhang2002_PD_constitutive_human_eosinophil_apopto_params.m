function p = Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto_params()
% Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mometasone Zhang_2002::constitutive_human_eosinophil_apoptosis: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response constitutive human eosinophil apoptosis in its own unit. Driver: mometasone (cited_pk).
p.E0 = 0.0;
p.Emax = 2.1;
p.EC50 = 5.63;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 57.0;
p.form = 'E0 + Emax*frac';
end
