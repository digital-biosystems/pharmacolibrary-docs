% run_Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [nM]'); ylabel('response []'); title('Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Mometasone_Zhang2002_PD_constitutive_human_eosinophil_apopto.csv');
