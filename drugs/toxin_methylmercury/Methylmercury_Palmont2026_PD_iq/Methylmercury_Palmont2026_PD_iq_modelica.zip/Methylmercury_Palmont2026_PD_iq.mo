model Methylmercury_Palmont2026_PD_iq
  "linear exposure-response sweep — Palmont_2026 :: IQ (IQ)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -0.17   "[IQ points per µg/g]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Methylmercury_Palmont2026_PD_iq</h4><p>The steady-state exposure-response curve of Palmont P et al., <i>Environment international 215:110446</i> 2026 (<a href=\"https://doi.org/10.1016/j.envint.2026.110446\">doi:10.1016/j.envint.2026.110446</a>) — IQ against methylmercury µg/g — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -0.17 IQ points per µg/g change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/g of methylmercury per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Methylmercury_Palmont2026_PD_iq;
