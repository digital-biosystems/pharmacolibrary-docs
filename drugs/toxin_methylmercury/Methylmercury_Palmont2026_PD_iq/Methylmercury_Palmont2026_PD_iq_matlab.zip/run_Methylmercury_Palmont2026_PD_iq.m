% run_Methylmercury_Palmont2026_PD_iq  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Methylmercury_Palmont2026_PD_iq_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [µg/g]'); ylabel('response []'); title('Methylmercury_Palmont2026_PD_iq', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Methylmercury_Palmont2026_PD_iq.csv');
