function p = Methylmercury_Tuomisto2020_PD_child_s_iq_params()
% Methylmercury_Tuomisto2020_PD_child_s_iq_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylmercury Tuomisto_2020::Child_s_IQ: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg/day per second, in SI inside (kg/m3, s). Response Child's IQ in IQ points. Driver: Methylmercury (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 6.6;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
