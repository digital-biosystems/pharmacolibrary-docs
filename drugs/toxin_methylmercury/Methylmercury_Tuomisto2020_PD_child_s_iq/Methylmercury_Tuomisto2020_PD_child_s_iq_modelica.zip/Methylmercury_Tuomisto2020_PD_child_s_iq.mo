model Methylmercury_Tuomisto2020_PD_child_s_iq
  "linear exposure-response sweep — Tuomisto_2020 :: Child's IQ (loss in child’s IQ points)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1.15740740741e-11);
  parameter Real slope = 6.6   "[IQ points per mg/kg/day]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Methylmercury_Tuomisto2020_PD_child_s_iq</h4><p>The steady-state exposure-response curve of Tuomisto JT et al., <i>BMC public health 20(1):64</i> 2020 (<a href=\"https://doi.org/10.1186/s12889-019-8094-1\">doi:10.1186/s12889-019-8094-1</a>) — loss in child’s IQ points [IQ points] against Methylmercury mg/kg/day — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        6.6 IQ points per mg/kg/day change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/kg/day of Methylmercury per second of simulated time (exposure is in 1/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Methylmercury_Tuomisto2020_PD_child_s_iq;
