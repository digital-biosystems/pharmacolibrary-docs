model Tislelizumab_Kim2025_reference
  parameter Real Cl_ref = 1.7708333333333335e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00642 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tislelizumab</h4><p>Tislelizumab is a monoclonal antibody that blocks PD-1 and is used to treat several cancers, including esophageal, lung, nasopharyngeal, and stomach cancers. It is an approved medicine, with one product currently authorised in the European Union, though another EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209583\">Wikidata Q28209583</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tislelizumab</td></tr><tr><td>population:</td><td>patients with non-small cell lung cancer</td></tr><tr><td>source_paper:</td><td>Kim_2025</td></tr><tr><td>measured_compound:</td><td>tislelizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('steady-state volume of distribution'=6.42) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('mean clearance'=0.153) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tislelizumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'tislelizumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 12700800, Tolerance = 1e-9, Interval = 1));
end Tislelizumab_Kim2025_reference;
