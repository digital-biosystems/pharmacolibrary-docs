// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2234455Heptachlorobiphenyl_Verner2009_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {867834000.0},
    MM = 0.395306,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2234455_heptachlorobiphenyl</td></tr><tr><td>population:</td><td>Northern Québec Inuit mothers and their infants</td></tr><tr><td>source_paper:</td><td>Verner_2009</td></tr><tr><td>measured_compound:</td><td>2,2',3,4,4',5,5'-Heptachlorobiphenyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t3-ehp-117-481</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,2',3,4,4',5,5'-Heptachlorobiphenyl 395.306 g/mol (pubchem); 2234455_heptachlorobiphenyl 395.306 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/hr/kg liver' (CLint)</li><li>implicit units: 'Intrinsic clearance (L/hr/kg liver)' — the LLM proposed 'L/hr/kg liver', whose dimension does not fit Q3; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,2',3,4,4',5,5'-Heptachlorobiphenyl</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q3 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end D_2234455Heptachlorobiphenyl_Verner2009_reference;
