model Sertraline_Poweleit2023_reference
  parameter Real Cl_ref = 3.944444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.428 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 1080.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>psychiatrically hospitalized pediatric patients aged 5-18 years</td></tr><tr><td>source_paper:</td><td>Poweleit_2023</td></tr><tr><td>measured_compound:</td><td>Sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/1.73 m<sup>2</sup>' (CL/F)</li><li>unit_dimension_unknown: 'L/1.73 m<sup>2</sup>' (V/F)</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'No unit stated in text. Population PK convention for total clearance (CL/F) is L/h, and the value 14.2 is consistent wit')</li><li>implicit units: 'V/F' → L (from the popPK convention: 'No unit stated in text. Population PK convention for volume of distribution (V/F) is L, and the value 428 is consistent ')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sertraline</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gandara_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Sertraline_Poweleit2023_reference;
