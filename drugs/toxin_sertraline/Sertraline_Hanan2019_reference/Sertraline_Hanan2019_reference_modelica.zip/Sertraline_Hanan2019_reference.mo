model Sertraline_Hanan2019_reference
  parameter Real Cl_ref = 2.7222222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.766 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 1.25e-05,
    ka = 0.000125,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>HIV-infected and uninfected youth (>6 to <25 years old)</td></tr><tr><td>source_paper:</td><td>Hanan_2019</td></tr><tr><td>measured_compound:</td><td>Sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>N-desmethylsertraline 292.203 g/mol (pubchem); Sertraline 306.23 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'ALWT'</li><li>dropped value-less row: 'WT'</li><li>dropped value-less row: 'θ1'</li><li>dropped value-less row: 'θ2'</li><li>dropped value-less row: 'θ3'</li><li>dropped value-less row: 'K'</li><li>salvaged Q27 ('CL/F HIV(–)'=1.4) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F typical population PK values'=53.8) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('ka typical population PK values'=0.45) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('estimated a clearance of'=83.1) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('men had an elimination half-life approximately'=1.5) from results prose — parameter table was unreadable</li><li>implicit units: 'men had an elimination half-life approximately' → h (from the paper text: 'The paper text explicitly states units for sertraline half-life values, such as &quot;elimination half-life of about 27 h&quot; an')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sertraline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sertraline_Hanan2019_reference;
