function p = Sertraline_Hanan2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sertraline   source: Hanan_2019 / reference   route: oral
  p.name  = 'Sertraline_Hanan2019_reference_params';
  p.drug  = 'sertraline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3766.0;                % central volume [L]
  p.CL = 98.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.45;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.5;             % dose [mg]
end
