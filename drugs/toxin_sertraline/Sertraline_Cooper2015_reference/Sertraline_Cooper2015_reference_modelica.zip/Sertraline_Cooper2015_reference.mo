// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Sertraline_Cooper2015_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {90000.0},
    MM = 0.30623,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>patients presenting to a toxicology unit with sertraline overdoses</td></tr><tr><td>source_paper:</td><td>Cooper_2015</td></tr><tr><td>measured_compound:</td><td>Sertraline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'absorption rate constant' routed out of structural estimates ('Including BSV on both lag time and relative fraction absorbed improved the model.')</li><li>table section iiv: 'volume of distribution' routed out of structural estimates ('Including BSV on both lag time and relative fraction absorbed improved the model.')</li><li>table section iiv: 'clearance' routed out of structural estimates ('Including BSV on both lag time and relative fraction absorbed improved the model.')</li><li>table section iiv: 'calculated half-life of sertraline following overdose' routed out of structural estimates ('Including BSV on both lag time and relative fraction absorbed improved the model.')</li><li>table section iiv: 'clearance of sertraline' routed out of structural estimates ('Including BSV on both lag time and relative fraction absorbed improved the model.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sertraline</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Yang_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Li_2013's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gandara_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end Sertraline_Cooper2015_reference;
