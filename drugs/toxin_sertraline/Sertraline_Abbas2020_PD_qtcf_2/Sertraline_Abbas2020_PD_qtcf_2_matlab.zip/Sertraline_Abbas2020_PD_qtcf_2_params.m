function p = Sertraline_Abbas2020_PD_qtcf_2_params()
% Sertraline_Abbas2020_PD_qtcf_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sertraline Abbas_2020::QTcF::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ΔQTcF in ms. Driver: N-desmethylsertraline (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 36.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
