model Sertraline_Gandara2026_reference
  parameter Real Cl_ref = 1.6583333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.2 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 5e-05,
    ka = 0.006944444444444444,
    Tlag = 0.0,
    k12 = 3.726851851851852e-05,
    k21 = 3.31275720164609e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>pediatric patients with anxiety disorders</td></tr><tr><td>source_paper:</td><td>Gandara_2026</td></tr><tr><td>measured_compound:</td><td>Sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 'V1/F (L)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 'Q/F (L/h)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 'V2/F (L)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 'Tlag (h)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 'Ka (h-1)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 'Cmax (ng/mL)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>table section iiv: 't½ (h)' routed out of structural estimates ('Interindividual variability (CV, %)')</li><li>salvaged Q27 ('CL/F'=59.7) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V1/F'=1200) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('V2/F'=1350) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=161) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('coefficients of variation of Ka'=25) from results prose — parameter table was unreadable</li><li>implicit units: 'coefficients of variation of Ka' → 1/h (from the popPK convention: 'The parameter is Ka (absorption rate constant). The text states interindividual variability is expressed as CV (%), so t')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sertraline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Sertraline_Gandara2026_reference;
