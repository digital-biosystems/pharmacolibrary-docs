function p = Sertraline_Gandara2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sertraline   source: Gandara_2026 / reference   route: oral
  p.name  = 'Sertraline_Gandara2026_reference_params';
  p.drug  = 'sertraline';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1200.0;                % central volume [L]
  p.CL = 59.7;                % clearance [L/h]
  p.Vp = [1350.0];             % peripheral volumes [L]
  p.Q  = [161.0];             % inter-compartmental clearances [L/h]
  p.ka = 25.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
