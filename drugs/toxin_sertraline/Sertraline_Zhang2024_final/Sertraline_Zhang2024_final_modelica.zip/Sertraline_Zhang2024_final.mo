model Sertraline_Zhang2024_final
  parameter Real Cl_ref = 2.113888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.803 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 1080.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>Chinese patients with psychiatric disorders</td></tr><tr><td>source_paper:</td><td>Zhang_2024</td></tr><tr><td>measured_compound:</td><td>Sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PRO (CV%)' — extend the ontology if this is a real PK parameter (source ['Zhang_2024_table_p4_1:row4:col1'])</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'The paper does not specify the unit for CL/F in the text or table footnotes. Population pharmacokinetic clearance values')</li><li>implicit units: 'V/F' → L (from the popPK convention: 'The paper does not specify the unit for V/F. Volumes of distribution in population PK models are conventionally expresse')</li><li>implicit units: 'K' → 1/h (from the popPK convention: 'The paper mentions a half-life of about 24 h in the introduction but does not list the unit for the rate constant K in t')</li><li>implicit units: 'θCL–AGE' — the LLM proposed '1/year', whose dimension does not fit Q22; left unset</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Sertraline</li><li>model-stage split: 'final model estimate' is the final model of Zhang_2024 (paper reports 2 stages: final model estimate, final model iiv (cv%)); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gandara_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q22 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Sertraline_Zhang2024_final;
