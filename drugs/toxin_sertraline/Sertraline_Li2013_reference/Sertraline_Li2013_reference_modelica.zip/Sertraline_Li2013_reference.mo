model Sertraline_Li2013_reference
  parameter Real Cl_ref = 1.2166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 6.47 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 2.5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>Alzheimer's disease patients</td></tr><tr><td>source_paper:</td><td>Li_2013</td></tr><tr><td>measured_compound:</td><td>Sertraline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLsite=C, L/h' routed out of structural estimates ('Inter-individual variability (% SE)')</li><li>table section iiv: 'CLsite=others, L/h' routed out of structural estimates ('Inter-individual variability (% SE)')</li><li>dropped duplicate Q22 ('CLsite=others, L/h', value '89.1') — already have one for this compound</li><li>unit_dimension_unknown: 'fixed' (kabs)</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'CLsite=others;'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'Ka'</li><li>implicit units: 'Ka, 1/h (fixed)' → 1/h (from the paper text: &quot;The text states 'The mean elimination rate constant of 0.013 1/h is consistent with other literature reported values'. W&quot;)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CLsite=C, L/h); Q61 (V, L)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sertraline</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Sertraline_Li2013_reference;
