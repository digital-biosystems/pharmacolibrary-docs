function p = Sertraline_Li2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sertraline   source: Li_2013 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Sertraline_Li2013_reference_params';
  p.drug  = 'sertraline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6470.0;                % central volume [L]
  p.CL = 43.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
