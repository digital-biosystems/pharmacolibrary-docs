function p = Zanubrutinib_Ou2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zanubrutinib   source: Ou_2021 / reference   route: oral
  p.name  = 'Zanubrutinib_Ou2021_reference_params';
  p.drug  = 'zanubrutinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 112.0;                % central volume [L]
  p.CL = 170.0;                % clearance [L/h]
  p.Vp = [345.0];             % peripheral volumes [L]
  p.Q  = [26.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.526;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
