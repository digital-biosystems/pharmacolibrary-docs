function p = Ivermectin_Kobylinski2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ivermectin   source: Kobylinski_2017 / reference   route: oral
  p.name  = 'Ivermectin_Kobylinski2017_reference_params';
  p.drug  = 'ivermectin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 115.0;                % central volume [L]
  p.CL = 9.02;                % clearance [L/h]
  p.Vp = [157.0];             % peripheral volumes [L]
  p.Q  = [16.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.317;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 14.0;             % dose [mg]
end
