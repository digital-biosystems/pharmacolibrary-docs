// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Allopurinol_Hande1978_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2340.0},
    MM = 0.13611,
    adminMass = 0.0004,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>allopurinol</td></tr><tr><td>population:</td><td>adult patients receiving allopurinol (man)</td></tr><tr><td>source_paper:</td><td>Hande_1978</td></tr><tr><td>measured_compound:</td><td>Allopurinol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Allopurinol 136.11 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Serum half-lives of oxipurinol', value 13.6) — already have one for this compound</li><li>covariate renal for CLR from footnote/prose kept as documentation only (['Hande_1978:abstract', 'Hande_1978:abstract'])</li><li>covariate renal for CLR from footnote/prose kept as documentation only (['Hande_1978:abstract', 'Hande_1978:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Allopurinol</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/4 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Oxipurinol' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Aksenov_2018's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Chu_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Okada_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 180.0));
end Allopurinol_Hande1978_reference;
