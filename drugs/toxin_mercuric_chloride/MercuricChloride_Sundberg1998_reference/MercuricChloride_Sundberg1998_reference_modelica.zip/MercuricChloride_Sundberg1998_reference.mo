// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model MercuricChloride_Sundberg1998_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {612000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mercuric_chloride</td></tr><tr><td>population:</td><td>lactating and nonlactating mice</td></tr><tr><td>source_paper:</td><td>Sundberg_1998</td></tr><tr><td>measured_compound:</td><td>Mercury (total, inorganic, and methylmercury species)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>mercuric_chloride 271.49 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for Vss from footnote/prose kept as documentation only (['Sundberg_1998:abstract'])</li><li>dropped duplicate Q57 ('terminal half-lives of methylmercury in plasma were similar, in nonlactating mice', value 158) — already have one for this compound</li><li>dropped duplicate Q57 ('Mercury concentrations in milk following an iv dose of inorganic mercury decreased with a terminal half-life of', value 107) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mercury (total, inorganic, and methylmercury species)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'Mercury (total, inorganic, and methylmercury species)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Mercury (total, inorganic, and methylmercury species)', not mercuric_chloride — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 7257.6));
end MercuricChloride_Sundberg1998_reference;
