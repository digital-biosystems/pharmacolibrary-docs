// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model MercuricChloride_KomstaSzumska1984_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2039040.0000000002},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mercuric_chloride</td></tr><tr><td>population:</td><td>guinea pigs</td></tr><tr><td>source_paper:</td><td>Komsta-Szumska_1984</td></tr><tr><td>measured_compound:</td><td>methylmercury</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>mercuric_chloride 271.49 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methylmercury</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 1/1 row label(s) assigned, 0 linked by role; re-tagged methylmercury→parent ×3</li><li>molar mass: no plausible PubChem entry for 'methylmercury' ('methylmercury') — left in mass units</li><li>molar mass: PubChem entry choice failed (JSONDecodeError)</li><li>molar mass: none of 1 PubChem candidate(s) is 'methylmercuric chloride' (LLM) — left in mass units</li><li>molar mass: none found for 'methylmercuric chloride' — its concentrations stay mass-only</li><li>molar mass: none found for 'methylmercury' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'methylmercury', not mercuric_chloride — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 10281600, Tolerance = 1e-9, Interval = 20563.2));
end MercuricChloride_KomstaSzumska1984_reference;
