function p = VonWillebrandFactor_Valke2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: von_willebrand_factor   source: Valke_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'VonWillebrandFactor_Valke2024_reference_params';
  p.drug  = 'von_willebrand_factor';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.91;                % central volume [L]
  p.CL = 0.307;                % clearance [L/h]
  p.Vp = [0.916];             % peripheral volumes [L]
  p.Q  = [0.109];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
