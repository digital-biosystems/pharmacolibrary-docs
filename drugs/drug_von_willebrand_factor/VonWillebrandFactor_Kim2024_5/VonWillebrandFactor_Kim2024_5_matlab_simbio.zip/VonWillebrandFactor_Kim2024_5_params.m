function p = VonWillebrandFactor_Kim2024_5_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: von_willebrand_factor   source: Kim_2024 / 5   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'VonWillebrandFactor_Kim2024_5_params';
  p.drug  = 'von_willebrand_factor';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.8;                % central volume [L]
  p.CL = 0.000321;                % clearance [L/h]
  p.Vp = [1150.0];             % peripheral volumes [L]
  p.Q  = [0.0342];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
