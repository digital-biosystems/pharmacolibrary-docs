function p = VonWillebrandFactor_Kim2024_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: von_willebrand_factor   source: Kim_2024 / 1   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'VonWillebrandFactor_Kim2024_1_params';
  p.drug  = 'von_willebrand_factor';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.35;                % central volume [L]
  p.CL = 0.000242;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
