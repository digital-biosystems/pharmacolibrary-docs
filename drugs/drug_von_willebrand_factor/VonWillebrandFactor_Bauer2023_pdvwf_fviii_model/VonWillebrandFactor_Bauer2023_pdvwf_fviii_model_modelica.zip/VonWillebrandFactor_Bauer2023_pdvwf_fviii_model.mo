model VonWillebrandFactor_Bauer2023_pdvwf_fviii_model
  parameter Real Cl_ref = 1.15e-07 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real Vd_ref = 0.0047 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.75)*cov_wt_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k21 = 6.433506044905008e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>von_willebrand_factor</td></tr><tr><td>population:</td><td>patients with von Willebrand disease</td></tr><tr><td>source_paper:</td><td>Bauer_2023</td></tr><tr><td>measured_compound:</td><td>von_willebrand_factor</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'EVWF, VWD type 3, IU/dL' — extend the ontology if this is a real PK parameter (source ['t0004:row7:col3'])</li><li>covariate level 'WT effect on CL and Q' → Q900:wt_effect_on_cl_and_q = 0.750 (linear_fractional on Q22)</li><li>dropped duplicate Q63 ('Hematocrit effect on Vc', value '-0.334') — already have one for this compound</li><li>dropped PD-category row 'Baseline FVIII, IU/dLc,d' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0004:row16:col3'])</li><li>dropped PD-category row 'kout, h−1 c' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0004:row17:col3'])</li><li>dropped PD-category row 'Imax' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0004:row18:col3', 't0004:row18:col4'])</li><li>dropped PD-category row 'IC50, IU/dL' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0004:row19:col3', 't0004:row19:col4'])</li><li>dropped unlinked row (NIL): 'Hematocrit effect on baseline FVIII' — extend the ontology if this is a real PK parameter (source ['t0004:row20:col3'])</li><li>covariate effect for Q61 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=von_willebrand_factor</li><li>population split: 'pdvwf/fviii model' subgroup of Bauer_2023 (paper reports 2 populations: pdvwf/fviii model, rvwf model)</li><li>gap-filled Q49 (kabs) from Schöning_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end VonWillebrandFactor_Bauer2023_pdvwf_fviii_model;
