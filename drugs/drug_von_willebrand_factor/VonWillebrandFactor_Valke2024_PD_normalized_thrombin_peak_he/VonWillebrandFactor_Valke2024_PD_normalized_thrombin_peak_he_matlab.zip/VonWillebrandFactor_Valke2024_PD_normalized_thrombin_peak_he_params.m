function p = VonWillebrandFactor_Valke2024_PD_normalized_thrombin_peak_he_params()
% VonWillebrandFactor_Valke2024_PD_normalized_thrombin_peak_he_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% von_willebrand_factor Valke_2024::Normalized_thrombin_peak_height: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one IU/dl per second, in SI inside (kg/m3, s). Response Normalized thrombin peak height in % of NPP. Driver: factor VIII activity level (not_resolved).
p.E0 = 11.2;
p.Emax = 8.06;
p.EC50 = 51.6;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 520.0;
p.form = 'E0 + Emax*frac';
end
