% run_VonWillebrandFactor_Valke2024_PD_normalized_thrombin_peak_he  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = VonWillebrandFactor_Valke2024_PD_normalized_thrombin_peak_he_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [IU/dl]'); ylabel('response [% of NPP]'); title('VonWillebrandFactor_Valke2024_PD_normalized_thrombin_peak_he', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'VonWillebrandFactor_Valke2024_PD_normalized_thrombin_peak_he.csv');
