function p = VonWillebrandFactor_Bauer2023_rvwf_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: von_willebrand_factor   source: Bauer_2023 / rvwf_model   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'VonWillebrandFactor_Bauer2023_rvwf_model_params';
  p.drug  = 'von_willebrand_factor';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.35;                % central volume [L]
  p.CL = 0.21;                % clearance [L/h]
  p.Vp = [1.58];             % peripheral volumes [L]
  p.Q  = [0.229];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
