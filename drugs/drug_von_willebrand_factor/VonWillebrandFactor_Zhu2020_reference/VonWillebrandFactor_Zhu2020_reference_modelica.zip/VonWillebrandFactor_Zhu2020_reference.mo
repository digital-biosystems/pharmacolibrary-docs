model VonWillebrandFactor_Zhu2020_reference
  parameter Real Cl_ref = 9.061111111111112e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003871 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>von_willebrand_factor</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhu_2020</td></tr><tr><td>measured_compound:</td><td>von_willebrand_factor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhu_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end VonWillebrandFactor_Zhu2020_reference;
