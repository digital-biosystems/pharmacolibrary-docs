function p = VonWillebrandFactor_Kim2024_14_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: von_willebrand_factor   source: Kim_2024 / 14   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'VonWillebrandFactor_Kim2024_14_params';
  p.drug  = 'von_willebrand_factor';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.09;                % central volume [L]
  p.CL = 0.0222;                % clearance [L/h]
  p.Vp = [0.24];             % peripheral volumes [L]
  p.Q  = [1.99];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
