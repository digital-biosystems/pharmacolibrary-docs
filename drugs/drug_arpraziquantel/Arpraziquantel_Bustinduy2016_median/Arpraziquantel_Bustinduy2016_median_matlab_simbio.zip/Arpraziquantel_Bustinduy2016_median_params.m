function p = Arpraziquantel_Bustinduy2016_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arpraziquantel   source: Bustinduy_2016 / median   route: oral
  p.name  = 'Arpraziquantel_Bustinduy2016_median_params';
  p.drug  = 'arpraziquantel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 503.9;                % central volume [L]
  p.CL = 677.59;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.88;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2800.0;             % dose [mg]
end
