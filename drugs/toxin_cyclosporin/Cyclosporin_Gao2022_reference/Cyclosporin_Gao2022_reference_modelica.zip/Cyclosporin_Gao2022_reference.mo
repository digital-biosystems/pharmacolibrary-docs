model Cyclosporin_Gao2022_reference
  parameter Real Cl_ref = 8.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.325 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.2026,
    adminMass = 0.00025,
    ka = 0.00035,
    Tlag = 0.0,
    k12 = 2.64957264957265e-06,
    k21 = 3.286683630195081e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>Chinese pediatric patients with acquired aplastic anemia</td></tr><tr><td>source_paper:</td><td>Gao_2022</td></tr><tr><td>measured_compound:</td><td>Cyclosporin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('CV for IIV')</li><li>table section iiv: 'VC/F (L)' routed out of structural estimates ('CV for IIV')</li><li>dropped 'TBIL on CL (%)' → Q22 = -1.07: a clearance of -1.07 is not a parameter value (source ['T2:row6:col1'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyclosporin</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Gao2022_reference;
