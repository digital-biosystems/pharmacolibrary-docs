% Run (SimBiology): build model + dose, simulate 0..42.0 h, plot.
p = Cyclosporin_Gao2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 42.0);
