model Cyclosporin_Umpirrez2021_reference
  parameter Real Cl_ref = 8.416666666666667e-06 "Cl [m3/s]";
  parameter Real cov_clcr_0 = 0 "CLCr covariate";
  parameter Real Vd_ref = 0.0179 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.204)*cov_clcr_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.202635,
    adminMass = 0.00025,
    ka = 0.00014527777777777778,
    Tlag = 1843.2,
    k12 = 0.0002638112973308504,
    k21 = 1.1805555555555555e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>Uruguayan patients under treatment with cyclosporine</td></tr><tr><td>source_paper:</td><td>Umpiérrez_2021</td></tr><tr><td>measured_compound:</td><td>Cyclosporine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Cyclosporine 1202.63 g/mol (pubchem); cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'β CL-CLCr' → Q900:cl_clcr = -0.204 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'Ka-Cl' — extend the ontology if this is a real PK parameter (source ['tab2:row13:col1'])</li><li>routed 'Prop (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'Add (ng/mL)' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyclosporine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Umpirrez2021_reference;
