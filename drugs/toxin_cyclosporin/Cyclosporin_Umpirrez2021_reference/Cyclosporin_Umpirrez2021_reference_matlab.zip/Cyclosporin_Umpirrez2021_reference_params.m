function p = Cyclosporin_Umpirrez2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cyclosporin   source: Umpiérrez_2021 / reference   route: oral
  p.name  = 'Cyclosporin_Umpirrez2021_reference_params';
  p.drug  = 'cyclosporin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.9;                % central volume [L]
  p.CL = 30.3;                % clearance [L/h]
  p.Vp = [400.0];             % peripheral volumes [L]
  p.Q  = [17.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.523;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.512;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
