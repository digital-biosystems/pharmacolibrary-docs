model Cyclosporin_Kauv2025_reference
  parameter Real Cl_ref = 3.972222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0274 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.2026,
    adminMass = 0.00025,
    ka = 0.0003361111111111111,
    Tlag = 900.0,
    k12 = 0.0003213706407137064,
    k21 = 1.3347818031765279e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kauv_2025</td></tr><tr><td>measured_compound:</td><td>cyclosporin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kauv_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Kauv2025_reference;
