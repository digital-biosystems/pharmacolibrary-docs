% Run: build params, simulate 0..672.0 h, plot + save Cyclosporin_Zhai2024_ag_heterozygous.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Cyclosporin_Zhai2024_ag_heterozygous.m
here = fileparts(mfilename('fullpath'));
p = Cyclosporin_Zhai2024_ag_heterozygous_params();
out = simulate_pk(p, 0:0.05:672.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('cyclosporin — Zhai_2024 (oral)');
print(fig, fullfile(here, 'Cyclosporin_Zhai2024_ag_heterozygous.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Cyclosporin_Zhai2024_ag_heterozygous.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Cyclosporin_Zhai2024_ag_heterozygous.json'), 'w');
try
  s.model = 'Cyclosporin_Zhai2024_ag_heterozygous'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Cyclosporin_Zhai2024_ag_heterozygous","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Cyclosporin_Zhai2024_ag_heterozygous.png, Cyclosporin_Zhai2024_ag_heterozygous.csv, Cyclosporin_Zhai2024_ag_heterozygous.json\n');
