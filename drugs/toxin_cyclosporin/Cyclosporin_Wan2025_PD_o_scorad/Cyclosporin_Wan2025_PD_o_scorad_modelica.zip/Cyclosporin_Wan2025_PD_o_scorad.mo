model Cyclosporin_Wan2025_PD_o_scorad
  "linear exposure-response sweep — Wan_2025 :: o-SCORAD (o-SCORAD score)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -4.495,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Cyclosporin_Wan2025_PD_o_scorad</h4><p>The steady-state exposure-response curve of Wan M et al., <i>Clinical and experimental dermatology 50(8):1623–1627</i> 2025 (<a href=\"https://doi.org/10.1093/ced/llaf147\">doi:10.1093/ced/llaf147</a>) — o-SCORAD score against ciclosporin — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -4.495          change in response per unit of exposure (β, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of ciclosporin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Cyclosporin_Wan2025_PD_o_scorad;
