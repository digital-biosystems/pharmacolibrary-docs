function p = Cyclosporin_Roganovi2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cyclosporin   source: Roganović_2026 / reference   route: oral
  p.name  = 'Cyclosporin_Roganovi2026_reference_params';
  p.drug  = 'cyclosporin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 124.425;                % central volume [L]
  p.CL = 26.25;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.68;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
