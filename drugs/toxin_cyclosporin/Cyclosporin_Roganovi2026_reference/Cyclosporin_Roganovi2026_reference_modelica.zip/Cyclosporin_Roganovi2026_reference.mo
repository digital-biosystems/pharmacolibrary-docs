model Cyclosporin_Roganovi2026_reference
  parameter Real Cl_ref = 7.291666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.124425 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.2026,
    adminMass = 0.00035,
    ka = 0.0001888888888888889,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>children and young adults who underwent kidney transplantation</td></tr><tr><td>source_paper:</td><td>Roganović_2026</td></tr><tr><td>measured_compound:</td><td>Cyclosporin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00099-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Wp (%)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-18-00099-t003:row3:col1'])</li><li>kept covariate coefficient θ_ALL=0.89 (covariate ALL) — not an ontology parameter</li><li>kept covariate coefficient θ_HGB=-0.00279 (covariate HGB) — not an ontology parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyclosporin</li><li>bound model equation to Q40 (Fab): F = 71.1*(WTi/4)^1</li><li>Q40 (Fab) is equation-defined: value moved to equation-variable 'F'; equation kept verbatim</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kauv_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Roganovi2026_reference;
