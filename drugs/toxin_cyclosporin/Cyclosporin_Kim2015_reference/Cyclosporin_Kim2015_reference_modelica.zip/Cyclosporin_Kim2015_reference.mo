model Cyclosporin_Kim2015_reference
  parameter Real Cl_ref = 5.888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.43 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.49,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.2026,
    adminMass = 0.00025,
    ka = 0.0001888888888888889,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>adult allo-HSCT patients</td></tr><tr><td>source_paper:</td><td>Kim_2015</td></tr><tr><td>measured_compound:</td><td>Cyclosporin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate weight for allometric_exponent from footnote/prose kept as documentation only (['Kim_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyclosporin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kauv_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Kim2015_reference;
