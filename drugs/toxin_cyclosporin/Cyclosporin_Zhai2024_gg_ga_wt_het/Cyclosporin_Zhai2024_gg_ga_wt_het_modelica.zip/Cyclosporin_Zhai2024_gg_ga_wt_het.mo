model Cyclosporin_Zhai2024_gg_ga_wt_het
  parameter Real Cl_ref = 9.791666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 6.55 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00028,
    ka = 0.0001888888888888889,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>kidney transplant recipients</td></tr><tr><td>source_paper:</td><td>Zhai_2024</td></tr><tr><td>measured_compound:</td><td>Cyclosporine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13729-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('Multivariate model / CL/F, median (L/h)', value '35.03') — already have one for this compound</li><li>dropped duplicate Q27 ('Base model / CL/F in men, median (range, l/h)', value '35.74') — already have one for this compound</li><li>dropped duplicate Q27 ('Base model / CL/F in womene, median (range, l/h)', value '32.64') — already have one for this compound</li><li>dropped duplicate Q27 ('Multivariate model / CL/F in men, median (range, l/h)', value '35.97') — already have one for this compound</li><li>dropped duplicate Q27 ('Multivariate model / CL/F in women, median (range, l/h)', value '32.36') — already have one for this compound</li><li>dropped value-less row: 'CL/F'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyclosporine</li><li>population split: 'gg/ga (wt + het)' subgroup of Zhai_2024 (paper reports 4 populations: aa (homozygous), ag (heterozygous), gg (wildtype), gg/ga (wt + het))</li><li>molar mass: none of 1 PubChem candidate(s) is 'Cyclosporine' (LLM) — left in mass units</li><li>molar mass: none found for 'Cyclosporine' — its concentrations stay mass-only</li><li>gap-filled Q76 (V/F) from Chen_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kauv_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chen_2020, Kauv_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Zhai2024_gg_ga_wt_het;
