model Cyclosporin_Zhai2024_reference
  parameter Real Cl_ref = 8.369444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 6.55 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.202635,
    adminMass = 0.00028,
    ka = 0.0001888888888888889,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclosporin</td></tr><tr><td>population:</td><td>kidney transplant recipients</td></tr><tr><td>source_paper:</td><td>Zhai_2024</td></tr><tr><td>measured_compound:</td><td>Cyclosporine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13729-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Cyclosporine 1202.63 g/mol (pubchem); cyclosporin 1202.6 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CL/F'</li><li>salvaged Q27 ('homozygous carriers of rs3828743 CL/F'=30.13) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('cyclosporine clearance'=18) from results prose — parameter table was unreadable</li><li>implicit units: 'homozygous carriers of rs3828743 CL/F' → L/h (from the paper text: &quot;The text explicitly states: 'The influence of TSPYL variants on cyclosporine clearance (L/h) was analyzed...' and later &quot;)</li><li>implicit units: 'cyclosporine clearance' → L/h (from the paper text: &quot;The text explicitly states: 'The influence of TSPYL variants on cyclosporine clearance (L/h) was analyzed...'. Although &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cyclosporine</li><li>base model from table(s) without population columns (Zhai_2024:other_prose, cts13729-tbl-0003:footnote); populations aa (homozygous), ag (heterozygous), gg (wildtype), gg/ga (wt + het) kept as separate records</li><li>gap-filled Q76 (V/F) from Chen_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kauv_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chen_2020, Kauv_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Cyclosporin_Zhai2024_reference;
