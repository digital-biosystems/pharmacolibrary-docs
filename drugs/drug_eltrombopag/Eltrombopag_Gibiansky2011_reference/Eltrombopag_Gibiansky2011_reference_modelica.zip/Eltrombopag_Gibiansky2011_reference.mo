model Eltrombopag_Gibiansky2011_reference
  parameter Real Cl_ref = 1.8555555555555557e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00876 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 1.2652207001522072e-05,
    k21 = 9.80825958702065e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>eltrombopag</td></tr><tr><td>population:</td><td>healthy subjects and patients with chronic idiopathic thrombocytopenic purpura</td></tr><tr><td>source_paper:</td><td>Gibiansky_2011</td></tr><tr><td>measured_compound:</td><td>eltrombopag</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'typical eltrombopag CL/F' → Q27 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('typical eltrombopag CL/F', value 33) — already have one for this compound</li><li>unit_dimension_mismatch: 'CL/F' → Q27 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('CL/F', value 68) — already have one for this compound</li><li>unit_dimension_mismatch: 'Vc/F' → Q290 (unit 'dimensionless' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q290 ('Vc/F', value 55) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=eltrombopag</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eltrombopag_Gibiansky2011_reference;
