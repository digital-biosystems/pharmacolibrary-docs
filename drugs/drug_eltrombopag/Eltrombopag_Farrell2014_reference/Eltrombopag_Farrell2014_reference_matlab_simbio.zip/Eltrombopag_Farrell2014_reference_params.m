function p = Eltrombopag_Farrell2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eltrombopag   source: Farrell_2014 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Eltrombopag_Farrell2014_reference_params';
  p.drug  = 'eltrombopag';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.14;                % central volume [L]
  p.CL = 15.1;                % clearance [L/h]
  p.Vp = [9.82];             % peripheral volumes [L]
  p.Q  = [8.94];             % inter-compartmental clearances [L/h]
  p.ka = 20.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
