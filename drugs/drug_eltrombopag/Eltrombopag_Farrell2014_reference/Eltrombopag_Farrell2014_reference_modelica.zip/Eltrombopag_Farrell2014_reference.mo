model Eltrombopag_Farrell2014_reference
  parameter Real Cl_ref = 4.194444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00914 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.005611111111111111,
    Tlag = 0.0,
    k21 = 0.00025288526816021723
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>eltrombopag</td></tr><tr><td>population:</td><td>healthy volunteers and subjects with chronic liver disease</td></tr><tr><td>source_paper:</td><td>Farrell_2014</td></tr><tr><td>measured_compound:</td><td>eltrombopag</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ALAG1 (h)' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col1', 'tab_1:row8:col2', 'tab_1:row8:col3', 'tab_1:row8:col5', 'tab_1:row8:col6'])</li><li>unit_dimension_mismatch: 'CL/F ∼Females' → Q27 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('CL/F ∼Females', value '10.4') — already have one for this compound</li><li>unit_dimension_mismatch: 'CL/F ∼CP Score 5' → Q27 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('CL/F ∼CP Score 5', value '16.5') — already have one for this compound</li><li>unit_dimension_mismatch: 'CL/F ∼East Asians' → Q27 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('CL/F ∼East Asians', value '8.63') — already have one for this compound</li><li>unit_dimension_mismatch: 'CL/F ∼ CP Score > 5 †' → Q27 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('CL/F ∼ CP Score > 5 †', value '16.2') — already have one for this compound</li><li>unit_dimension_mismatch: 'Vc/F ∼South/Central Asians' → Q290 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q290 ('Vc/F ∼South/Central Asians', value '13.2') — already have one for this compound</li><li>routed 'Covar ωCL, ωVc' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=eltrombopag</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eltrombopag_Farrell2014_reference;
