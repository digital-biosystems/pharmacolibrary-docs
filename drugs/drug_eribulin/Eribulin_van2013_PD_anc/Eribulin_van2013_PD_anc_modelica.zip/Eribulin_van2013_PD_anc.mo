model Eribulin_van2013_PD_anc
  "linear exposure-response sweep — van_2013 :: ANC (absolute neutrophil counts)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4.03,      // [10^9 neutrophils l(-1)]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 4.51e-08   "[kilogram / meter ** 3; μg l(-1) × 1e-06]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eribulin</h4><p>Eribulin is an anticancer medicine used to treat breast cancer and a type of soft-tissue sarcoma called liposarcoma. It is authorised in the European Union and used as an antineoplastic agent for these cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408717\">Wikidata Q408717</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Eribulin_van2013_PD_anc</h4><p>The steady-state exposure-response curve of van Hasselt JG et al., <i>British journal of clinical pharmacology 76(3):412–424</i> 2013 (<a href=\"https://doi.org/10.1111/bcp.12143\">doi:10.1111/bcp.12143</a>) — absolute neutrophil counts [10^9 neutrophils l(-1)] against eribulin μg l(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       4.03 10^9 neutrophils l(-1) drug-free response (baseline) (baseline neutrophil count, Q324)
  slope =     0.0451 μg l(-1) change in response per unit of exposure (linear drug effect coefficient, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg l(-1) of eribulin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.03   (drug-free)</pre></body></html>"));
end Eribulin_van2013_PD_anc;
