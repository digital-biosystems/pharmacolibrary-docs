function p = Eribulin_van2013_PD_anc_params()
% Eribulin_van2013_PD_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eribulin van_2013::ANC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg l(-1) per second, in SI inside (kg/m3, s). Response ANC in 10^9 neutrophils l(-1). Driver: eribulin (not_resolved).
p.E0 = 4.03;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 4.509999999999999e-08;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
