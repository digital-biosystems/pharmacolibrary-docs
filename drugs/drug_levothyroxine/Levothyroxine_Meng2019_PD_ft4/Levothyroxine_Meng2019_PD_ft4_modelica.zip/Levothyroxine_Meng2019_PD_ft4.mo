model Levothyroxine_Meng2019_PD_ft4
  "indirect_response_i exposure-response sweep — Meng_2019 :: FT4 (free thyroxine)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 17.3333333333,      // [pmol l−1]
    Emax = 1,  // type I effect term
    EC50 = 5.8151e-05,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.052/0.003 = 17.33) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 590, Interval = 1.18),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levothyroxine</h4><p>Levothyroxine is a thyroid hormone used to treat hypothyroidism and other thyroid conditions such as goiter, thyroiditis, myxedema, and thyroid carcinoma. It is an approved medicine and is widely used as standard thyroid hormone therapy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q773449\">Wikidata Q773449</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Levothyroxine_Meng2019_PD_ft4</h4><p>The steady-state exposure-response curve of Meng F et al., <i>Journal of the Royal Society, Interface 16(155):20190083</i> 2019 (<a href=\"https://doi.org/10.1098/rsif.2019.0083\">doi:10.1098/rsif.2019.0083</a>) — free thyroxine [pmol l−1] against anti-thyroid drug mg — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 17.3333333333 pmol l−1 drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =     58.151 mg       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg of anti-thyroid drug per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 17.33   (drug-free)
  exposure = EC50 (58.151 mg)  response 8.667
  exposure -> infinity  response 0</pre></body></html>"));
end Levothyroxine_Meng2019_PD_ft4;
