#!/usr/bin/env python3
"""Simulate Levothyroxine_Younis2018_reference.sbml (0..24.0 h) with Tellurium/libRoadRunner and write results.

Headless-friendly: writes Levothyroxine_Younis2018_reference.csv, Levothyroxine_Younis2018_reference.json and Levothyroxine_Younis2018_reference.png next to this script
(no interactive window). Requires `tellurium` (bundles libRoadRunner + matplotlib).
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Levothyroxine_Younis2018_reference")

r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 24.0, 500, ["time", "Cc"])   # Cc = central concentration [mg/L]
t = [float(x) for x in res[:, 0]]
Cc = [float(x) for x in res[:, 1]]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Levothyroxine_Younis2018_reference", "stop_time_h": 24.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Levothyroxine_Younis2018_reference"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
