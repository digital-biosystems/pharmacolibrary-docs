function p = Cinobufagin_Jin2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cinobufagin   source: Jin_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cinobufagin_Jin2021_reference_params';
  p.drug  = 'cinobufagin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 39.309833;                % central volume [L]
  p.CL = 121.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
