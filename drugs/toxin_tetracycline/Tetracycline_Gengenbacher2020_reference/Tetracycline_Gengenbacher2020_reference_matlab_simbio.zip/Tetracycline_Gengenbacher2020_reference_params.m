function p = Tetracycline_Gengenbacher2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetracycline   source: Gengenbacher_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tetracycline_Gengenbacher2020_reference_params';
  p.drug  = 'tetracycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.388678;                % central volume [L]
  p.CL = 1.56;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
