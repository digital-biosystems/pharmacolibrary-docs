function p = Rivaroxaban_Liu2022_simultaneous_modeling_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rivaroxaban   source: Liu_2022 / simultaneous_modeling   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rivaroxaban_Liu2022_simultaneous_modeling_params';
  p.drug  = 'rivaroxaban';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 40.3;                % central volume [L]
  p.CL = 5.03;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.617;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
