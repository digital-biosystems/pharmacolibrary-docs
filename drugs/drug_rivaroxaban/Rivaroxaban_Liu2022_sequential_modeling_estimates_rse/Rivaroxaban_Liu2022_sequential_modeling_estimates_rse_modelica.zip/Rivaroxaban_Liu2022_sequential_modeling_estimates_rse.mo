model Rivaroxaban_Liu2022_sequential_modeling_estimates_rse
  parameter Real Cl_ref = 1.4000000000000001e-06 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "egfr covariate";
  parameter Real cov_egfr_1 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.0404 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.54)*cov_egfr_0)*(1 + (-0.0868)*cov_egfr_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43588099999999996,
    adminMass = 1e-05,
    ka = 0.0001713888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rivaroxaban</h4><p>Rivaroxaban is an anticoagulant that directly inhibits factor Xa and is used to prevent and treat blood clots, including venous thromboembolism, pulmonary embolism, and stroke prevention in atrial fibrillation. It is widely used and authorised in the European Union, with several approved products on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420262\">Wikidata Q420262</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivaroxaban</td></tr><tr><td>population:</td><td>Chinese patients with non-valvular atrial fibrillation</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>rivaroxaban</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rivaroxaban 435.881 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω CL' routed out of structural estimates ('Between-subject variability (%CV)')</li><li>table section iiv: 'ω PTbase' routed out of structural estimates ('Between-subject variability (%CV)')</li><li>table section iiv: 'ω slope' routed out of structural estimates ('Between-subject variability (%CV)')</li><li>table representations disagree for 'k a (h -1 )'; source reconciliation required</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'eGFR on CL/F'; source reconciliation required</li><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'Proportional error'; source reconciliation required</li><li>table representations disagree for 'PT base (s)'; source reconciliation required</li><li>table representations disagree for 'TBIL on PT base'; source reconciliation required</li><li>table representations disagree for 'eGFR on PT base'; source reconciliation required</li><li>table representations disagree for 'slope (s•L•μg -1 )'; source reconciliation required</li><li>covariate level 'eGFR on CL/F' → Q900:egfr_on_cl_f = 0.54 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'PT base (s)' — extend the ontology if this is a real PK parameter (source ['tab_2:row12:col1'])</li><li>dropped unlinked row (NIL): 'TBIL on PT base' — extend the ontology if this is a real PK parameter (source ['tab_2:row13:col1'])</li><li>covariate level 'eGFR on PT base' → Q900:egfr_on_pt_base = -0.0868 (linear_fractional on Q27)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Rivaroxaban_Liu2022_sequential_modeling_estimates_rse;
