function p = Rivaroxaban_Ren2026_caucasian_vte_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rivaroxaban   source: Ren_2026 / caucasian_vte   route: oral
  p.name  = 'Rivaroxaban_Ren2026_caucasian_vte_params';
  p.drug  = 'rivaroxaban';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 101.0;                % central volume [L]
  p.CL = 8.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
