model Rivaroxaban_Liu2022_sequential_modeling
  parameter Real Cl_ref = 1.4000000000000001e-06 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "egfr covariate";
  parameter Real cov_egfr_1 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.0404 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.54)*cov_egfr_0)*(1 + (-0.0868)*cov_egfr_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001713888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivaroxaban</td></tr><tr><td>population:</td><td>Chinese patients with non-valvular atrial fibrillation</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>rivaroxaban</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'eGFR on CL/F' → Q900:egfr_on_cl_f = 0.54 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'PT base (s)' — extend the ontology if this is a real PK parameter (source ['tab_2:row12:col1', 'tab_2:row12:col5', 'tab_2:row12:col6'])</li><li>dropped unlinked row (NIL): 'TBIL on PT base' — extend the ontology if this is a real PK parameter (source ['tab_2:row13:col1', 'tab_2:row13:col5', 'tab_2:row13:col6'])</li><li>covariate level 'eGFR on PT base' → Q900:egfr_on_pt_base = -0.0868 (linear_fractional on Q27)</li><li>dropped PD-category row 'slope (s•L•μg -1 )' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_2:row15:col1', 'tab_2:row15:col5', 'tab_2:row15:col6'])</li><li>routed 'ω PTbase' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'ω slope' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['tab_2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['tab_2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rivaroxaban</li><li>population split: 'sequential modeling' subgroup of Liu_2022 (paper reports 2 populations: sequential modeling, simultaneous modeling)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rivaroxaban_Liu2022_sequential_modeling;
