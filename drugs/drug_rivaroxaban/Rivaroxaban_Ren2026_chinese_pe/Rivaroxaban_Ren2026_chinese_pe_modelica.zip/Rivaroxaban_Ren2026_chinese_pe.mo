model Rivaroxaban_Ren2026_chinese_pe
  parameter Real Cl_ref = 1.7027777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.053 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43588099999999996,
    adminMass = 5e-06,
    ka = 0.00034722222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rivaroxaban</h4><p>Rivaroxaban is an anticoagulant that directly inhibits factor Xa and is used to prevent and treat blood clots, including venous thromboembolism, pulmonary embolism, and stroke prevention in atrial fibrillation. It is widely used and authorised in the European Union, with several approved products on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420262\">Wikidata Q420262</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivaroxaban</td></tr><tr><td>population:</td><td>patients with pulmonary embolism</td></tr><tr><td>source_paper:</td><td>Ren_2026</td></tr><tr><td>measured_compound:</td><td>rivaroxaban</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rivaroxaban 435.881 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'chinese pe' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'chinese pe' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'chinese pe' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'chinese pe' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'chinese pe' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Baselines(s)' — extend the ontology if this is a real PK parameter (source ['Ren_2026_table_5:row5:col1'])</li><li>dropped PD-category row 'Slope (s/[μg/L])' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ren_2026_table_5:row6:col1'])</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'V/F'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rivaroxaban</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Central V/F (L)' is the general volume)</li><li>population split: 'chinese pe' subgroup of Ren_2026 (paper reports 7 populations: caucasian dvt, caucasian nvaf, caucasian vte, chinese dvt, chinese nvaf, chinese pe, japanese nvaf)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Rivaroxaban_Ren2026_chinese_pe;
