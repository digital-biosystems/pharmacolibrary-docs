model Rivaroxaban_Jia2026_reference
  parameter Real Cl_ref = 2.077777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00475 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43588099999999996,
    adminMass = 5e-06,
    ka = 3.888888888888889e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rivaroxaban</h4><p>Rivaroxaban is an anticoagulant that directly inhibits factor Xa and is used to prevent and treat blood clots, including venous thromboembolism, pulmonary embolism, and stroke prevention in atrial fibrillation. It is widely used and authorised in the European Union, with several approved products on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420262\">Wikidata Q420262</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivaroxaban</td></tr><tr><td>population:</td><td>adults with transjugular intrahepatic portosystemic shunt (TIPS)</td></tr><tr><td>source_paper:</td><td>Jia_2026</td></tr><tr><td>measured_compound:</td><td>rivaroxaban</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rivaroxaban 435.881 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ALAG1 (h)' — extend the ontology if this is a real PK parameter (source ['tab_0:row6:col1', 'tab_0:row6:col2', 'tab_0:row6:col3', 'tab_0:row6:col4', 'tab_0:row6:col5'])</li><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: 'The paper text explicitly states: &quot;absorption rate constant (Ka) = 0.140 /h&quot;')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rivaroxaban</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rivaroxaban_Jia2026_reference;
