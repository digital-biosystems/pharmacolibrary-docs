model Rivaroxaban_Jia2026_reference
  parameter Real Cl_ref = 2.0055555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0049299999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivaroxaban</td></tr><tr><td>population:</td><td>adults with TIPS</td></tr><tr><td>source_paper:</td><td>Jia_2026</td></tr><tr><td>measured_compound:</td><td>rivaroxaban</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ALAG1 (h)' — extend the ontology if this is a real PK parameter (source ['tab_0:row6:col1', 'tab_0:row6:col2', 'tab_0:row6:col3', 'tab_0:row6:col4', 'tab_0:row6:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rivaroxaban</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rivaroxaban_Jia2026_reference;
