% Run: build params, simulate 0..672.0 h, plot + save Rivaroxaban_Li2025_final.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Rivaroxaban_Li2025_final.m
here = fileparts(mfilename('fullpath'));
p = Rivaroxaban_Li2025_final_params();
out = simulate_pk(p, 0:0.05:672.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('rivaroxaban — Li_2025 (iv_bolus)');
print(fig, fullfile(here, 'Rivaroxaban_Li2025_final.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Rivaroxaban_Li2025_final.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Rivaroxaban_Li2025_final.json'), 'w');
try
  s.model = 'Rivaroxaban_Li2025_final'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Rivaroxaban_Li2025_final","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Rivaroxaban_Li2025_final.png, Rivaroxaban_Li2025_final.csv, Rivaroxaban_Li2025_final.json\n');
