% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Rivaroxaban_Ren2026_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
