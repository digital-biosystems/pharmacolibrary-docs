model Rivaroxaban_Esmaeili2022_reference
  parameter Real Cl_ref = 1.0222222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061200000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43588099999999996,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rivaroxaban</h4><p>Rivaroxaban is an anticoagulant that directly inhibits factor Xa and is used to prevent and treat blood clots, including venous thromboembolism, pulmonary embolism, and stroke prevention in atrial fibrillation. It is widely used and authorised in the European Union, with several approved products on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420262\">Wikidata Q420262</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivaroxaban</td></tr><tr><td>population:</td><td>Iranian patients</td></tr><tr><td>source_paper:</td><td>Esmaeili_2022</td></tr><tr><td>measured_compound:</td><td>rivaroxaban</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rivaroxaban 435.881 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'slope of the relationship between apTT, prothrombin time, and rivaroxaban concentration' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Esmaeili_2022:abstract', 'Esmaeili_2022:abstract'])</li><li>dropped PD-category row 'maximum level of inhibition (Emax )' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Esmaeili_2022:abstract', 'Esmaeili_2022:abstract'])</li><li>dropped PD-category row 'concentration of rivaroxaban producing 50% of the maximum inhibitory effect (EC50 )' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Esmaeili_2022:abstract'])</li><li>dropped PD-category row 'Hill coefficient (γ)' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Esmaeili_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=rivaroxaban</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Rivaroxaban_Esmaeili2022_reference;
