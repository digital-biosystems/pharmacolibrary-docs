% Run (SimBiology): build model + dose, simulate 0..37.0 h, plot.
p = Rivaroxaban_Ren2026_japanese_nvaf_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 37.0);
