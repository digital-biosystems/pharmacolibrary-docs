% Run (SimBiology): build model + dose, simulate 0..41.0 h, plot.
p = Formoterol_Back2020_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 41.0);
