model Alprazolam_Witt2026_PD_rgr
  "sigmoid_emax exposure-response sweep — Witt_2026 :: RGR (relative growth rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 0.000465351,  // [kg/m3; ng L−1 × 1e-09]
    gamma = -0.4585,
    exposure_per_s = 1e-09);   // 1 ng L−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 4.7e+06, Interval = 9400),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alprazolam</h4><p>Alprazolam is a short-acting benzodiazepine anxiolytic used to treat anxiety and panic disorders, and also for conditions such as insomnia. It is an approved medicine that is widely used, though it carries a boxed warning and is also encountered as an illicit drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q319877\">Wikidata Q319877</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Alprazolam_Witt2026_PD_rgr</h4><p>The steady-state exposure-response curve of Witt NGPM et al., <i>Toxics 14(5)</i> 2026 (<a href=\"https://doi.org/10.3390/toxics14050420\">doi:10.3390/toxics14050420</a>) — relative growth rate [% of control] against alprazolam ng L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Max. Inhibition (%), Q323)
  EC50  =     465351 ng L−1   exposure at half of the maximal effect term (EC50, Q321)
  gamma =    -0.4585          Hill coefficient (Hill Slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng L−1 of alprazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (465351 ng L−1)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Alprazolam_Witt2026_PD_rgr;
