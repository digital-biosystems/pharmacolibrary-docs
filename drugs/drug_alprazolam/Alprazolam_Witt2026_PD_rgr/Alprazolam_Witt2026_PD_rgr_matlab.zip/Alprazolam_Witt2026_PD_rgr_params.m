function p = Alprazolam_Witt2026_PD_rgr_params()
% Alprazolam_Witt2026_PD_rgr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alprazolam Witt_2026::RGR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng L−1 per second, in SI inside (kg/m3, s). Response RGR in % of control. Driver: alprazolam (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.000465351;
p.gamma = -0.4585;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 4700000.0;
p.form = 'E0 + Emax*frac';
end
