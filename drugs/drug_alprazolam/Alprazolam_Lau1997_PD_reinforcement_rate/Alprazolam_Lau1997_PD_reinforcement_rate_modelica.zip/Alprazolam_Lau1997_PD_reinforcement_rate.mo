model Alprazolam_Lau1997_PD_reinforcement_rate
  "indirect_response_i exposure-response sweep — Lau_1997 :: reinforcement rate (reinforcement rate)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 2e-05,  // [kg/m3; microg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 microg/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.2, Interval = 0.0004),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alprazolam</h4><p>Alprazolam is a triazolobenzodiazepine tranquilizer used to treat anxiety disorders, specifically panic and generalized anxiety, as well as insomnia. It is generally taken orally in tablet or liquid forms, and is well-absorbed by the body. The drug is widely used and available as a generic medication.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q319877\">Wikidata Q319877</a>, <a href=\"https://en.wikipedia.org/wiki/Alprazolam?oldid=1369242307\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Alprazolam_Lau1997_PD_reinforcement_rate</h4><p>The steady-state exposure-response curve of Lau CE et al., <i>The Journal of pharmacology and experimental therapeutics 283(3):1119–1129</i> 1997 — reinforcement rate against alprazolam microg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       0.02 microg/ml exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one microg/ml of alprazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.02 microg/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Alprazolam_Lau1997_PD_reinforcement_rate;
