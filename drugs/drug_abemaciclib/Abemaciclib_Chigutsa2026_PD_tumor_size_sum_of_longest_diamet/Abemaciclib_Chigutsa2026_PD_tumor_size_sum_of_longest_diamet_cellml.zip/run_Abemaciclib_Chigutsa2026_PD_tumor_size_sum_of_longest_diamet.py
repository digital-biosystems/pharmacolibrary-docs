#!/usr/bin/env python3
"""Sweep Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet")
E0, Emax, EC50, gamma, slope, exposure_per_s = 36.7, 0.0, 1.0, 1.0, 6.597222222222222e-08, 1e-06
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0 + slope*exposure
x = [exposure_per_s * 1000.0 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [ng/mL]"); plt.ylabel("response [mm]")
plt.title("Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
