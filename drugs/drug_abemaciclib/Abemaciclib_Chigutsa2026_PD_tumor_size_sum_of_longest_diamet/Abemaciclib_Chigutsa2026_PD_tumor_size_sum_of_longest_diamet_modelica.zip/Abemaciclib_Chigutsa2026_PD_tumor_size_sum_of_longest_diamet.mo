model Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet
  "linear exposure-response sweep — Chigutsa_2026 :: Tumor size (sum of longest diameters of target lesions) (Tumor size (sum of longest diameters of target lesions))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 36.7,      // [mm]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 6.59722222222e-08   "[1 / second; week −1 × 1.65344e-06]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About abemaciclib</h4><p>Abemaciclib is a CDK inhibitor used to treat breast cancer. It is an approved medicine and is authorised in the European Union for breast cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23901483\">Wikidata Q23901483</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet</h4><p>The steady-state exposure-response curve of Chigutsa E et al., <i>Clinical pharmacology and therapeutics 119(4):1070–1079</i> 2026 (<a href=\"https://doi.org/10.1002/cpt.70212\">doi:10.1002/cpt.70212</a>) — Tumor size (sum of longest diameters of target lesions) [mm] against abemaciclib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       36.7 mm       drug-free response (baseline) (Baseline tumor size, Q324)
  slope =     0.0399 week −1  change in response per unit of exposure (Abemaciclib drug effect per unit plasma concentration, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of abemaciclib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 36.7   (drug-free)</pre></body></html>"));
end Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet;
