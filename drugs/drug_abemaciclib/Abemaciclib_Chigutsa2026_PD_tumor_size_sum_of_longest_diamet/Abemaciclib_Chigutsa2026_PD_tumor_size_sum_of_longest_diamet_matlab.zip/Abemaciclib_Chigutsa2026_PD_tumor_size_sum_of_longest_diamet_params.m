function p = Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet_params()
% Abemaciclib_Chigutsa2026_PD_tumor_size_sum_of_longest_diamet_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% abemaciclib Chigutsa_2026::Tumor_size_sum_of_longest_diameters_of_target_lesions: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Tumor size (sum of longest diameters of target lesions) in mm. Driver: abemaciclib (cited_pk).
p.E0 = 36.7;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 6.597222222222222e-08;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
