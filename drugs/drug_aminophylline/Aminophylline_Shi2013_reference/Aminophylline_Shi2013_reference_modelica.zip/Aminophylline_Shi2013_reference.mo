model Aminophylline_Shi2013_reference
  parameter Real Cl_ref = 4.966666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0651 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4204264,
    adminMass = 0.0006,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminophylline</h4><p>Aminophylline is a bronchodilator used to treat breathing problems such as asthma, pulmonary emphysema, and acute bronchitis, and it has also been used for bradycardia. It is an approved medicine, though not authorised in the European Union, and is now used less often than newer inhaled treatments, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q471763\">Wikidata Q471763</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminophylline</td></tr><tr><td>population:</td><td>very low birth weight infants</td></tr><tr><td>source_paper:</td><td>Shi_2013</td></tr><tr><td>measured_compound:</td><td>aminophylline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>aminophylline 420.426 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'kg x h' (CL)</li><li>dropped PD-category row 'related coefficient (aminophylline plasma clearance related to creatinine clearance)' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Shi_2013:abstract'])</li><li>unit_dimension_unknown: 'aminophylline plasma clearance related to gestational age' (CL)</li><li>dropped duplicate Q22 ('related coefficient (aminophylline plasma clearance related to gestational age)', value 0.62) — already have one for this compound</li><li>unit_dimension_unknown: 'aminophylline plasma clearance related to days of age after birth' (equation variable)</li><li>unit_dimension_unknown: 'apparent volume of distribution related to birth weight' (Vnorm)</li><li>implicit units: 'plasma clearance' → L/h (from the popPK convention: 'No unit stated in text or footnotes; clearance in population PK is conventionally L/h, consistent with value 17.88.')</li><li>implicit units: 'related coefficient (apparent volume of distribution related to birth weight)' → L/kg (from the popPK convention: 'No unit stated; Vnorm is volume of distribution normalized to body size (birth weight), conventionally L/kg, consistent ')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=aminophylline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Aminophylline_Shi2013_reference;
