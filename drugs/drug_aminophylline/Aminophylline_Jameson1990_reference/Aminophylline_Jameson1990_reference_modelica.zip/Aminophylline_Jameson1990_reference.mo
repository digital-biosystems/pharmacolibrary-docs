model Aminophylline_Jameson1990_reference
  parameter Real Cl_ref = 7.233333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0385 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminophylline</h4><p>Aminophylline is a bronchodilator used to treat breathing problems such as asthma, pulmonary emphysema, and acute bronchitis, and it has also been used for bradycardia. It is an approved medicine, though not authorised in the European Union, and is now used less often than newer inhaled treatments, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q471763\">Wikidata Q471763</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminophylline</td></tr><tr><td>population:</td><td>healthy black Zimbabwean male adults</td></tr><tr><td>source_paper:</td><td>Jameson_1990</td></tr><tr><td>measured_compound:</td><td>theophylline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aminophylline 420.426 g/mol (drugbank); theophylline 180.167 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'mean weight' — extend the ontology if this is a real PK parameter (source ['Jameson_1990:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=theophylline</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'theophylline', not aminophylline — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Aminophylline_Jameson1990_reference;
