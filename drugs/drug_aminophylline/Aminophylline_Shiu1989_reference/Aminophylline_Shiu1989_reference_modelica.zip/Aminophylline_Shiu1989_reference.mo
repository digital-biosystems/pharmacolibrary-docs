model Aminophylline_Shiu1989_reference
  parameter Real Cl_ref = 2.4888888888888886e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.056 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminophylline</h4><p>Aminophylline is a bronchodilator and phosphodiesterase inhibitor used for asthma and obstructive airway diseases. It is given orally or intravenously, with rectal administration also available. It is an approved medication used for respiratory conditions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q471763\">Wikidata Q471763</a>, <a href=\"https://en.wikipedia.org/wiki/Aminophylline?oldid=1329963873\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminophylline</td></tr><tr><td>population:</td><td>beagle dogs</td></tr><tr><td>source_paper:</td><td>Shiu_1989</td></tr><tr><td>measured_compound:</td><td>theophylline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aminophylline 420.426 g/mol (drugbank); theophylline 180.167 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=theophylline</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Aminophylline_Shiu1989_reference;
