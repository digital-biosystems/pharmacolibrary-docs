function p = Aminophylline_Shiu1989_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aminophylline   source: Shiu_1989 / reference   route: iv_bolus
  p.name  = 'Aminophylline_Shiu1989_reference_params';
  p.drug  = 'aminophylline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 56.0;                % central volume [L]
  p.CL = 8.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.31;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
