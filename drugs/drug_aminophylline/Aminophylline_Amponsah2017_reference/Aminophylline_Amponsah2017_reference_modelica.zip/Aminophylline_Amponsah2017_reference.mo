model Aminophylline_Amponsah2017_reference
  parameter Real Cl_ref = 4.2500000000000003e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00294 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4204264,
    adminMass = 0.0006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminophylline</h4><p>Aminophylline is a bronchodilator used to treat breathing problems such as asthma, pulmonary emphysema, and acute bronchitis, and it has also been used for bradycardia. It is an approved medicine, though not authorised in the European Union, and is now used less often than newer inhaled treatments, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q471763\">Wikidata Q471763</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminophylline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Amponsah_2017</td></tr><tr><td>measured_compound:</td><td>aminophylline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aminophylline 420.426 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Amponsah_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Aminophylline_Amponsah2017_reference;
