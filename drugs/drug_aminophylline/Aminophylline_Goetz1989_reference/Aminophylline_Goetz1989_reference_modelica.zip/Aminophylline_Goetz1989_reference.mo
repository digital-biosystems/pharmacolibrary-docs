model Aminophylline_Goetz1989_reference
  parameter Real Cl_ref = 1.0888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.056 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0006,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminophylline</h4><p>Aminophylline is a bronchodilator used to treat breathing problems such as asthma, pulmonary emphysema, and acute bronchitis, and it has also been used for bradycardia. It is an approved medicine, though not authorised in the European Union, and is now used less often than newer inhaled treatments, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q471763\">Wikidata Q471763</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminophylline</td></tr><tr><td>population:</td><td>healthy adult horses</td></tr><tr><td>source_paper:</td><td>Goetz_1989</td></tr><tr><td>measured_compound:</td><td>theophylline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>aminophylline 420.426 g/mol (drugbank); theophylline 180.167 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=theophylline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'theophylline', not aminophylline — the review values are the parent's</li><li>derived CL/F=3.92 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Aminophylline_Goetz1989_reference;
