model Ifosfamide_Boddy1995_reference
  parameter Real Cl_ref = 6.555546666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039200000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.261083,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ifosfamide</td></tr><tr><td>population:</td><td>patients with metastatic or locally advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Boddy_1995</td></tr><tr><td>measured_compound:</td><td>Ifosfamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>2-dechloroethylifosfamide 198.587 g/mol (pubchem); 3-dechloroethylifosfamide 198.587 g/mol (pubchem); Ifosfamide 261.083 g/mol (pubchem); carboxyifosfamide 293.081 g/mol (pubchem); isophosphoramide mustard 221.018 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'Clearance' Q22 → Q47: a rate constant in '1/h/m2' (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ifosfamide</li><li>toxin: 4 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 2 linked by role; re-tagged Ifosfamide→parent ×3</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=236 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ifosfamide_Boddy1995_reference;
