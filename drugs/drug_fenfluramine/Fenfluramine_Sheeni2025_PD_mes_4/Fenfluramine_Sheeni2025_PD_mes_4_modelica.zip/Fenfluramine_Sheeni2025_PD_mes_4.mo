model Fenfluramine_Sheeni2025_PD_mes_4
  "sigmoid_emax exposure-response sweep — Sheeni_2025 :: MES (seizure protection)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1; % × 0.01]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 3.4e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 340, Interval = 0.68),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fenfluramine</h4><p>Fenfluramine is a serotonergic medicine that was once used as a centrally acting antiobesity drug and is now used as an antiepileptic for certain epilepsies. Its antiobesity use was withdrawn because it caused heart valve damage, but it remains authorised in the European Union for epilepsy, with use restricted to specialist care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418928\">Wikidata Q418928</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Fenfluramine_Sheeni2025_PD_mes_4</h4><p>The steady-state exposure-response curve of Sheeni Y et al., <i>Epilepsia 66(11):4501–4512</i> 2025 (<a href=\"https://doi.org/10.1111/epi.18542\">doi:10.1111/epi.18542</a>) — seizure protection [%] against d-norfenfluramine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          0 %        drug-free response (baseline) (Bottom, Q324)
  Emax  =        100 %        maximal effect term (Top, Q320)
  EC50  =         34 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of d-norfenfluramine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (34 ng/mL)  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Fenfluramine_Sheeni2025_PD_mes_4;
