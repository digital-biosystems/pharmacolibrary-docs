model SilveriSelenide_Tang2016_reference
  parameter Real Cl_ref = 8.925000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.018830000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>silveri_selenide</td></tr><tr><td>population:</td><td>Male CD-1 (ICR) mice</td></tr><tr><td>source_paper:</td><td>Tang_2016</td></tr><tr><td>measured_compound:</td><td>Silver(I) selenide quantum dots (Ag2Se QDs-PEG)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Selenium 78.971 g/mol (pubchem); Silver 107.87 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Silver(I) selenide quantum dots (Ag2Se QDs-PEG)</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>base model from table(s) without population columns (Tang_2016_table_1); populations day 28: control, day 28: qds-peg, day 7: control, day 7: qds-peg kept as separate records</li><li>row roles (LLM): model_class=noncompartmental; 18/18 row label(s) assigned, 0 linked by role</li><li>molar mass: no plausible PubChem entry for 'Ag2Se QDs-PEG' ('Ag2Se QDs-PEG') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'Silver(I) selenide quantum dots (Ag2Se QDs-PEG)' ('Silver(I) selenide quantum dots (Ag2Se QDs-PEG)') — left in mass units</li><li>molar mass: none found for 'Ag2Se QDs-PEG' — its concentrations stay mass-only</li><li>molar mass: none found for 'Silver(I) selenide quantum dots (Ag2Se QDs-PEG)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SilveriSelenide_Tang2016_reference;
