model Anidulafungin_Caballero2023_PD_n
  "sigmoid_emax exposure-response sweep — Caballero_2023 :: N (Fungal burden)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 8,      // [log CFU/mL]
    Emax = -7.55555555556e-06,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.000176,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 1.8, Interval = 0.0036),
    Documentation(info = "<html><body><h4>Anidulafungin_Caballero2023_PD_n</h4><p>The steady-state exposure-response curve of Caballero U et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(6):770-782</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12949\">doi:10.1002/psp4.12949</a>) — Fungal burden [log CFU/mL] against anidulafungin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          8 log CFU/mL drug-free response (baseline) (Maximum fungal density, Q324)
  Emax  =     0.0272 h-1      maximal effect term (Emax of the echinocandin (ANF), Q323)
  EC50  =      0.176 mg/L     exposure at half of the maximal effect term (EC50 of the echinocandin (ANF), Q321)
  gamma =          1          Hill coefficient (Hill factor for the echinocandin (ANF), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of anidulafungin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8   (drug-free)
  exposure = EC50 (0.176 mg/L)  response 8
  exposure -> infinity  response 8</pre></body></html>"));
end Anidulafungin_Caballero2023_PD_n;
