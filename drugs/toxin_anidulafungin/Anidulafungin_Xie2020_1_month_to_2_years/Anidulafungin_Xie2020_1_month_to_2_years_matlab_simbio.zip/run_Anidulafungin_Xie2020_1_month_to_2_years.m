% Run (SimBiology): build model + dose, simulate 0..4320.0 h, plot.
p = Anidulafungin_Xie2020_1_month_to_2_years_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4320.0);
