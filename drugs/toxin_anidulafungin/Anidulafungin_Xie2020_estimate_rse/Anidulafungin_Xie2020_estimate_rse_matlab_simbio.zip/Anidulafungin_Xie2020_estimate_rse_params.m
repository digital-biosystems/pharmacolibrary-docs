function p = Anidulafungin_Xie2020_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anidulafungin   source: Xie_2020 / estimate_rse   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Anidulafungin_Xie2020_estimate_rse_params';
  p.drug  = 'anidulafungin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 26.7;                % central volume [L]
  p.CL = 1.16;                % clearance [L/h]
  p.Vp = [4.87];             % peripheral volumes [L]
  p.Q  = [2.37];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
