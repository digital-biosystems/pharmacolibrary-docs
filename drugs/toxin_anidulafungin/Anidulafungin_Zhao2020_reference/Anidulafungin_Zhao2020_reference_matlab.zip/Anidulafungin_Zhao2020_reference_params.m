function p = Anidulafungin_Zhao2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anidulafungin   source: Zhao_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Anidulafungin_Zhao2020_reference_params';
  p.drug  = 'anidulafungin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 95.2;                % central volume [L]
  p.CL = 1.33;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
