function p = Anidulafungin_Elkayal2025_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anidulafungin   source: Elkayal_2025 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Anidulafungin_Elkayal2025_base_params';
  p.drug  = 'anidulafungin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 32.2;                % central volume [L]
  p.CL = 0.68;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
