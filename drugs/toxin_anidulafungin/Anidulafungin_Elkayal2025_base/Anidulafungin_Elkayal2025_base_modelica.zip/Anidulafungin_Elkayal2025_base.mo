model Anidulafungin_Elkayal2025_base
  parameter Real Cl_ref = 1.888888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032200000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.1402539999999999,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>anidulafungin</td></tr><tr><td>population:</td><td>critically ill adults</td></tr><tr><td>source_paper:</td><td>Elkayal_2025</td></tr><tr><td>measured_compound:</td><td>Anidulafungin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>anidulafungin 1140.25 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'on CL (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'on Vc (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'on Vp (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error (%CV)' routed out of structural estimates ('Residual variability')</li><li>dropped value-less row: 'CL (L/h)' (captured trailing unit 'L/h' for child rows)</li><li>dropped value-less row: 'Vc (L)' (captured trailing unit 'L' for child rows)</li><li>dropped value-less row: 'Q (L/h)' (captured trailing unit 'L/h' for child rows)</li><li>dropped value-less row: 'Vp (L)' (captured trailing unit 'L' for child rows)</li><li>salvaged Q22 ('CL at 50 kg (min)'=0.68) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('terminal elimination half-life at 50 kg'=35.4) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('Vc at 20.2 g/L (min)'=32.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Anidulafungin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc at 20.2 g/L (min)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'base model estimates (%rse) [%shrinkage] (ofv = 257.6, cn = 99.4)' is the base model of Elkayal_2025 (paper reports 2 stages: base model estimates (%rse) [%shrinkage] (ofv = 257.6, cn = 99.4), final model estimates (%rse) [%shrinkage] (ofv = 236.5, cn = 160.0)); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Anidulafungin_Elkayal2025_base;
