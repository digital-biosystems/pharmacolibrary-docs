model Anidulafungin_Elkayal2025_final
  parameter Real Cl_ref = 2.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00581 "Vd [m3]";
  parameter Real cov_albumin_0 = 0 "albumin covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (-5.32)*cov_albumin_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 1.1402539999999999,
    adminMass = 0.0001,
    k12 = 0.0009992350353796135,
    k21 = 0.00021034621578099836
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>anidulafungin</td></tr><tr><td>population:</td><td>critically ill adults</td></tr><tr><td>source_paper:</td><td>Elkayal_2025</td></tr><tr><td>measured_compound:</td><td>Anidulafungin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>anidulafungin 1140.25 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'on CL (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'on Vc (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'on Vp (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error (%CV)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Bodyweight on CL' — extend the ontology if this is a real PK parameter (source ['Elkayal_2025_table_p23_1:row6:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Anidulafungin</li><li>model-stage split: 'final model estimates (%rse) [%shrinkage] (ofv = 236.5, cn = 160.0)' is the final model of Elkayal_2025 (paper reports 2 stages: base model estimates (%rse) [%shrinkage] (ofv = 257.6, cn = 99.4), final model estimates (%rse) [%shrinkage] (ofv = 236.5, cn = 160.0)); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Anidulafungin_Elkayal2025_final;
