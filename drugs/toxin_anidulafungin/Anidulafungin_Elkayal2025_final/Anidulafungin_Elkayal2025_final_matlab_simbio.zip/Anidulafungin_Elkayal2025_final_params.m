function p = Anidulafungin_Elkayal2025_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anidulafungin   source: Elkayal_2025 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Anidulafungin_Elkayal2025_final_params';
  p.drug  = 'anidulafungin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.81;                % central volume [L]
  p.CL = 0.98;                % clearance [L/h]
  p.Vp = [27.6];             % peripheral volumes [L]
  p.Q  = [20.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
