model Zolmitriptan_ElNabarawy2019_group_3_ntg_commercial_zomig_2_5
  parameter Real Cl_ref = 3.115e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0029 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.287363,
    adminMass = 0.00035
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zolmitriptan</td></tr><tr><td>population:</td><td>adult male Wistar albino rats</td></tr><tr><td>source_paper:</td><td>El-Nabarawy_2019</td></tr><tr><td>measured_compound:</td><td>Zolmitriptan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T0003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zolmitriptan 287.363 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'µg hr2 mL−1' (AUMC)</li><li>unit_dimension_unknown: 'µg hr2 mL−1' (AUMC)</li><li>dropped duplicate Q20 ('AUMC0–∞ (µg hr2 mL−1)', value '17.48') — already have one for this compound</li><li>dropped value-less row: '\\bar X'</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 6 (source ['T0003:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'AUMC0–6 (µg hr2 mL−1)' — the LLM proposed 'µg hr² mL⁻¹', whose dimension does not fit Q20; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zolmitriptan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'group 3, ntg+commercial zomig® 2.5 mg tablet (peroral)' subgroup of El-Nabarawy_2019 (paper reports 3 populations: group 3, ntg+commercial zomig® 2.5 mg tablet (peroral), group 4, ntg+zolmitriptan solution (intranasal), group 5, ntg+zolmitriptan spanlastic dispersion (intranasal))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q20 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zolmitriptan_ElNabarawy2019_group_3_ntg_commercial_zomig_2_5;
