function p = Zolmitriptan_ElNabarawy2019_group_3_ntg_commercial_zomig_2_5_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zolmitriptan   source: El-Nabarawy_2019 / group_3_ntg_commercial_zomig_2_5_mg_tablet_peroral   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Zolmitriptan_ElNabarawy2019_group_3_ntg_commercial_zomig_2_5_params';
  p.drug  = 'zolmitriptan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.9;                % central volume [L]
  p.CL = 1.1214;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
