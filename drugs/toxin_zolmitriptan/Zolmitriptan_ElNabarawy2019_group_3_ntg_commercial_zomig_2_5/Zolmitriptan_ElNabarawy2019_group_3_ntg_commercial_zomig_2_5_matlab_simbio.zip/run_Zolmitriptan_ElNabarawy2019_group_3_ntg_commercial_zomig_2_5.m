% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Zolmitriptan_ElNabarawy2019_group_3_ntg_commercial_zomig_2_5_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
