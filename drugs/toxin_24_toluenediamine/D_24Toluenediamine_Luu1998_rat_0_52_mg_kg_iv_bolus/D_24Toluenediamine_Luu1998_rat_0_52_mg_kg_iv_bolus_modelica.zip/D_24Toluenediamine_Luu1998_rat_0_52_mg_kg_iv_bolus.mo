// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_24Toluenediamine_Luu1998_rat_0_52_mg_kg_iv_bolus
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {266.4},
    MM = 0.122171,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>24_toluenediamine</td></tr><tr><td>population:</td><td>58 kg human (simulated)</td></tr><tr><td>source_paper:</td><td>Luu_1998</td></tr><tr><td>measured_compound:</td><td>2,4-Toluenediamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,4-Toluenediamine 122.171 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Feces' — extend the ontology if this is a real PK parameter (source ['Luu_1998_table_2:row1:col1'])</li><li>dropped unlinked row (NIL): 'Urine' — extend the ontology if this is a real PK parameter (source ['Luu_1998_table_2:row2:col1'])</li><li>dropped unlinked row (NIL): 'Kidney' — extend the ontology if this is a real PK parameter (source ['Luu_1998_table_2:row4:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,4-Toluenediamine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>population split: 'rat, 0.52 mg/kg iv bolus' subgroup of Luu_1998 (paper reports 4 populations: human, 4.872 g implant, rat, 0.021 g implant, rat, 0.52 mg/kg feeding, rat, 0.52 mg/kg iv bolus)</li><li>row roles (LLM): model_class=pbpk; 10/10 row label(s) assigned, 0 linked by role; re-tagged 2,4-Toluenediamine→parent ×2, 2,4-Toluenediamine→4-AAT ×2</li><li>molar mass: no plausible PubChem entry for '4-AAT' ('4-N-acetyl-2-amino toluene') — left in mass units</li><li>molar mass: none found for '4-AAT' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_24Toluenediamine_Luu1998_rat_0_52_mg_kg_iv_bolus;
