// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flupenthixol_Wu2019_fed_state
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {87012.0},
    MM = 0.436536,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flupenthixol</td></tr><tr><td>population:</td><td>healthy Chinese volunteers</td></tr><tr><td>source_paper:</td><td>Wu_2019</td></tr><tr><td>measured_compound:</td><td>flupentixol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T0007</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>flupenthixol 436.536 g/mol (pubchem); flupentixol 436.536 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Any adverse event'; source reconciliation required</li><li>table representations disagree for 'Serum triglyceride increased'; source reconciliation required</li><li>table representations disagree for 'Leukopenia'; source reconciliation required</li><li>table representations disagree for 'Neutropenia'; source reconciliation required</li><li>table representations disagree for 'Serum ALT increased'; source reconciliation required</li><li>table representations disagree for 'γ-glutamyltransferase increased'; source reconciliation required</li><li>table representations disagree for 'Serum creatine kinase increased'; source reconciliation required</li><li>table representations disagree for 'Uric acid increased'; source reconciliation required</li><li>table representations disagree for 'Hyperkalemia'; source reconciliation required</li><li>table representations disagree for 'Urinary tract infection'; source reconciliation required</li><li>table representations disagree for 'Fever'; source reconciliation required</li><li>table representations disagree for 'Drowsiness'; source reconciliation required</li><li>table representations disagree for 'Dizziness'; source reconciliation required</li><li>table representations disagree for 'Dermatitis'; source reconciliation required</li><li>table representations disagree for 'Hypertension'; source reconciliation required</li><li>table representations disagree for 'Periodontitis'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end Flupenthixol_Wu2019_fed_state;
