// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flupenthixol_Levron1987_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1641600.0},
    MM = 0.436536,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flupenthixol</td></tr><tr><td>population:</td><td>patients treated with depot neuroleptics</td></tr><tr><td>source_paper:</td><td>Levron_1987</td></tr><tr><td>measured_compound:</td><td>flupenthixol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>flupenthixol 436.536 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('T 1/2 of haloperidol decanoate', value 21) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of flupenthixol decanoate', value 17) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of fluphenazine enanthate', value 4) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life of fluphenazine decanoate', value 14) — already have one for this compound</li><li>dropped duplicate Q57 ('T 1/2', value '20') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flupenthixol</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 8467200, Tolerance = 1e-9, Interval = 16934.4));
end Flupenthixol_Levron1987_reference;
