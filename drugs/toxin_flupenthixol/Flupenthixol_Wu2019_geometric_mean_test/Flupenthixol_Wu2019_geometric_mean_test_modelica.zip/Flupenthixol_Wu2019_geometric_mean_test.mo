// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flupenthixol_Wu2019_geometric_mean_test
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {87012.0},
    MM = 0.436536,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flupenthixol</td></tr><tr><td>population:</td><td>healthy Chinese volunteers</td></tr><tr><td>source_paper:</td><td>Wu_2019</td></tr><tr><td>measured_compound:</td><td>flupentixol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T0007</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>flupenthixol 436.536 g/mol (pubchem); flupentixol 436.536 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 7. Total Number Of Adverse Events And Percentage Of Healthy Subjects Experiencing Adverse Events In The Fasted Or Fed Study. Values Are Given As No. (%)' (captured trailing unit '%' for child rows)</li><li>salvaged Q57 ('t½, h (Fasted, Flupentixol Test)'=24.17) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flupentixol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'geometric mean (test)' subgroup of Wu_2019 (paper reports 7 populations: fasted state (n=24), fed state (n=24), flupentixol / reference (n=22c), flupentixol / reference (n=24), flupentixol / test (n=24), geometric mean (reference), geometric mean (test))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end Flupenthixol_Wu2019_geometric_mean_test;
