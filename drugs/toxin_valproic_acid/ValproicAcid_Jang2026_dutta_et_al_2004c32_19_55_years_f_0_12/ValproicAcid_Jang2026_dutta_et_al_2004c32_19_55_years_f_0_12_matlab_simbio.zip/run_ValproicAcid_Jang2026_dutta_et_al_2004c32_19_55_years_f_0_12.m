% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = ValproicAcid_Jang2026_dutta_et_al_2004c32_19_55_years_f_0_12_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
