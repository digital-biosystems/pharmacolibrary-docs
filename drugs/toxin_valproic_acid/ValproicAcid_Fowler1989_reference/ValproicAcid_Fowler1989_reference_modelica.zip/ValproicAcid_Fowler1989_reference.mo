model ValproicAcid_Fowler1989_reference
  parameter Real Cl_ref = 1.1166666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010499999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    ka = 0.0007222222222222223,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>perfused term human placenta (dual recirculation and dual single pass)</td></tr><tr><td>source_paper:</td><td>Fowler_1989</td></tr><tr><td>measured_compound:</td><td>valproic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.214 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('VPA-GR antipyrine clearance transfer', value 17) — already have one for this compound</li><li>dropped duplicate Q410 ('VPA-G logarithm of the octanol/water partition coefficient', value -1.85) — already have one for this compound</li><li>dropped duplicate Q410 ('VPA-GR logarithm of the octanol/water partition coefficient', value -1.66) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=valproic acid</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles: LLM call failed (JSONDecodeError) — deterministic compound tags kept</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'valproic acid (VPA)' — its concentrations stay mass-only</li><li>molar mass: none found for 'valproic acid acyl glucuronide (VPA-G)' — its concentrations stay mass-only</li><li>molar mass: none found for 'valproic acid acyl glucuronide rearrangement isomers (VPA-GR)' — its concentrations stay mass-only</li><li>molar mass: none found for 'valproic acid' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Ma_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hernández-Gago_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Fowler1989_reference;
