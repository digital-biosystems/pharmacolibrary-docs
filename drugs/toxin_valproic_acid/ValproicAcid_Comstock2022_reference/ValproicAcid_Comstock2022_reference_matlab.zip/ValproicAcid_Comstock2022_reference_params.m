function p = ValproicAcid_Comstock2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valproic_acid   source: Comstock_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'ValproicAcid_Comstock2022_reference_params';
  p.drug  = 'valproic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.5;                % central volume [L]
  p.CL = 40.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
