function p = ValproicAcid_Zhang2023_model_one_binding_site_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valproic_acid   source: Zhang_2023 / model_one_binding_site_model   route: oral
  p.name  = 'ValproicAcid_Zhang2023_model_one_binding_site_model_params';
  p.drug  = 'valproic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13000.0;                % central volume [L]
  p.CL = 132.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
