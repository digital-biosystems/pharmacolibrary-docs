% Run (SimBiology): build model + dose, simulate 0..408.0 h, plot.
p = ValproicAcid_Zhang2023_model_linear_non_saturable_binding_eq_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 408.0);
