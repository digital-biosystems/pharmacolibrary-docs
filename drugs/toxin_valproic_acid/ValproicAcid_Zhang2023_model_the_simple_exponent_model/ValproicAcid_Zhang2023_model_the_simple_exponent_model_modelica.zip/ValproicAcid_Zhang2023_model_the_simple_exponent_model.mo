model ValproicAcid_Zhang2023_model_the_simple_exponent_model
  parameter Real Cl_ref = 9.194444444444445e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0172 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    ka = 0.0007222222222222223,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>children with epilepsy</td></tr><tr><td>source_paper:</td><td>Zhang_2023</td></tr><tr><td>measured_compound:</td><td>valproic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3 (prediction metrics); parameter estimates in Supplementary Table S3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.214 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Objective function value' — extend the ontology if this is a real PK parameter (source ['Zhang_2023_table_S3:row0:col6'])</li><li>dropped unlinked row (NIL): 'CL_DD' — extend the ontology if this is a real PK parameter (source ['Zhang_2023_table_S3:row3:col6'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=valproic acid</li><li>population split: 'model ⅴ: the simple exponent model' subgroup of Zhang_2023 (paper reports 6 populations: base model, model ⅰ: one-binding site model, model ⅱ: langmuir equation, model ⅲ: dose-dependent maximum effect model, model ⅳ: linear non-saturable binding equation, model ⅴ: the simple exponent model)</li><li>molar mass: none found for 'valproic acid' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Damnjanović_2023's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Ruijs_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Zhang2023_model_the_simple_exponent_model;
