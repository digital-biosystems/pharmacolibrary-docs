% Run (SimBiology): build model + dose, simulate 0..192.0 h, plot.
p = ValproicAcid_Zhang2023_model_the_simple_exponent_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 192.0);
