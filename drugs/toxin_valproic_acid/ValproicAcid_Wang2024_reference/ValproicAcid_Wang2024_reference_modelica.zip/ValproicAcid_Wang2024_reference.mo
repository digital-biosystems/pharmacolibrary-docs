model ValproicAcid_Wang2024_reference
  parameter Real Cl_ref = 5.444444444444445e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00209 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>children with epilepsy (pediatric patients)</td></tr><tr><td>source_paper:</td><td>Wang_2024</td></tr><tr><td>measured_compound:</td><td>Valproic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413191-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.214 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'RV prop' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'RV prop' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'RV add' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'RV add' routed out of structural estimates ('Residual variability')</li><li>column 'bias (%) a' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%) a' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%) a' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%) a' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%) a' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%) a' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'BW on V/F' — extend the ontology if this is a real PK parameter (source ['psp413191-tbl-0003:row6:col1', 'psp413191-tbl-0003:row6:col5'])</li><li>dropped duplicate Q49 ('K a2', value '0.46') — already have one for this compound</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Valproic acid</li><li>molar mass: none found for 'Valproic acid' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Wang2024_reference;
