% Run (SimBiology): build model + dose, simulate 0..312.0 h, plot.
p = ValproicAcid_Zhang2023_base_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 312.0);
