% Run (SimBiology): build model + dose, simulate 0..360.0 h, plot.
p = ValproicAcid_Zhang2023_model_langmuir_equation_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 360.0);
