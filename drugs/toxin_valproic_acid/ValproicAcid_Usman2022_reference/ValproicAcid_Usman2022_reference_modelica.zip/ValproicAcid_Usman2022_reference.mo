model ValproicAcid_Usman2022_reference
  parameter Real Cl_ref = 2.5861111111111115e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0166 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    ka = 0.0007222222222222223,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>Pakistani and South Korean patients on valproic acid therapy</td></tr><tr><td>source_paper:</td><td>Usman_2022</td></tr><tr><td>measured_compound:</td><td>valproic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone.0272622.t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.214 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 6 column 4 (char 325)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=valproic acid</li><li>molar mass: none found for 'valproic acid' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Damnjanović_2023's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Ruijs_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q22, Q354, Q352 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Usman2022_reference;
