function p = ValproicAcid_Usman2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valproic_acid   source: Usman_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'ValproicAcid_Usman2022_reference_params';
  p.drug  = 'valproic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.6;                % central volume [L]
  p.CL = 0.931;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
