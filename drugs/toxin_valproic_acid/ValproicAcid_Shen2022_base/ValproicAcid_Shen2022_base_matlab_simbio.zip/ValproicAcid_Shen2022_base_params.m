function p = ValproicAcid_Shen2022_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valproic_acid   source: Shen_2022 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'ValproicAcid_Shen2022_base_params';
  p.drug  = 'valproic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.43;                % central volume [L]
  p.CL = 0.205;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
