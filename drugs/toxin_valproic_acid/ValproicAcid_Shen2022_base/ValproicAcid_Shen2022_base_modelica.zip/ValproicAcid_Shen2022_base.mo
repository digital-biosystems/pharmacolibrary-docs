model ValproicAcid_Shen2022_base
  parameter Real Cl_ref = 5.694444444444444e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0034300000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    ka = 0.0007222222222222223,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>pediatric patients with epilepsy in southern China</td></tr><tr><td>source_paper:</td><td>Shen_2022</td></tr><tr><td>measured_compound:</td><td>Valproic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.214 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'θCL'; source reconciliation required</li><li>table representations disagree for 'θV'; source reconciliation required</li><li>table representations disagree for 'ωCL'; source reconciliation required</li><li>table representations disagree for 'ηshrinkage'; source reconciliation required</li><li>table representations disagree for 'σadditive'; source reconciliation required</li><li>table representations disagree for 'εshrinkage'; source reconciliation required</li><li>dropped diagnostic row 'εshrinkage' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Valproic acid</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'base model estimate' is the base model of Shen_2022 (paper reports 2 stages: base model estimate, final model estimate); same population, different model-building step</li><li>molar mass: none found for 'Valproic acid' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Damnjanović_2023's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Ruijs_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Shen2022_base;
