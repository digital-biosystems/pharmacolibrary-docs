% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = ValproicAcid_Huang2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
