model ValproicAcid_Huang2023_reference
  parameter Real Cl_ref = 9.483333333333333e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010499999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.125e-05,
    ka = 0.0007222222222222223,
    Tlag = 1800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>healthy volunteers and pediatric patients (neonates to adults) treated with valproic acid</td></tr><tr><td>source_paper:</td><td>Huang_2023</td></tr><tr><td>measured_compound:</td><td>valproic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table S1 and Table S2 (VPA and 4-ene-VPA PBPK input parameters)</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.214 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>compound tags: 1 row(s) → 4-ene-VPA (name 1)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'input value' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'pK a' — extend the ontology if this is a real PK parameter (source ['Huang_2023_table_S1:row3:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=valproic acid</li><li>topology: prose indicates saturable/MM/TMDD/time-varying kinetics — manual_model_class</li><li>template fit: none — nonlinear / manual model class</li><li>status held at route_to_review — not promoted</li><li>row roles: LLM call failed (JSONDecodeError) — deterministic compound tags kept</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Huang2023_reference;
