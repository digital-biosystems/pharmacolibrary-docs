% Run (SimBiology): build model + dose, simulate 0..2352.0 h, plot.
p = ValproicAcid_Zhang2023_model_dose_dependent_maximum_effect_m_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2352.0);
