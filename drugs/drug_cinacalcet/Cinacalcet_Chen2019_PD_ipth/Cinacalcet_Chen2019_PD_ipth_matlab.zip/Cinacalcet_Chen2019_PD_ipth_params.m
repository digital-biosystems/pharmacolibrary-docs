function p = Cinacalcet_Chen2019_PD_ipth_params()
% Cinacalcet_Chen2019_PD_ipth_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cinacalcet Chen_2019::iPTH: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one L mM−1 per second, in SI inside (kg/m3, s). Response iPTH in pM. Driver: cinacalcet (pk_record).
p.E0 = 54.29;
p.Emax = 1.0;
p.EC50 = 0.072;
p.gamma = -3.3;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.72;
p.form = 'E0*(1 - Emax*frac)';
end
