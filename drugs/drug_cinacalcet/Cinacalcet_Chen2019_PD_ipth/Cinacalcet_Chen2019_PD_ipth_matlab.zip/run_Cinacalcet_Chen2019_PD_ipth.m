% run_Cinacalcet_Chen2019_PD_ipth  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Cinacalcet_Chen2019_PD_ipth_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0.*(1 - Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [L mM−1]'); ylabel('response [pM]'); title('Cinacalcet_Chen2019_PD_ipth', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Cinacalcet_Chen2019_PD_ipth.csv');
