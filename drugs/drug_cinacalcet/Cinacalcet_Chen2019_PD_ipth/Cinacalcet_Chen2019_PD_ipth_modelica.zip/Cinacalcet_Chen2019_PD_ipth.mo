model Cinacalcet_Chen2019_PD_ipth
  "indirect_response_i exposure-response sweep — Chen_2019 :: iPTH (intact parathyroid hormone (iPTH))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 54.29,      // [pM]
    Emax = 1,  // type I effect term
    EC50 = 0.072,  // [L mM−1]
    gamma = -3.3,
    exposure_per_s = 1);   // 1 L mM−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'L mM−1' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 0.72, Interval = 0.00144),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cinacalcet</h4><p>Cinacalcet is a calcimimetic anti-parathyroid medicine used to treat hyperparathyroidism, including secondary hyperparathyroidism, and related calcium disorders such as hypercalcemia. It is an approved medicine with authorised products in the European Union, and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q193978\">Wikidata Q193978</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cinacalcet_Chen2019_PD_ipth</h4><p>The steady-state exposure-response curve of Chen P et al., <i>British journal of clinical pharmacology 85(6):1312–1325</i> 2019 (<a href=\"https://doi.org/10.1111/bcp.13900\">doi:10.1111/bcp.13900</a>) — intact parathyroid hormone (iPTH) [pM] against cinacalcet L mM−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      54.29 pM       drug-free response (baseline) (PTH0 Patient, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      0.072 L mM−1   exposure at half of the maximal effect term (RatioPatient, Q321)
  gamma =       -3.3          Hill coefficient (Power on ROPatient, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one L mM−1 of cinacalcet per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 54.29   (drug-free)
  exposure = EC50 (0.072 L mM−1)  response 27.14
  exposure -> infinity  response 0</pre></body></html>"));
end Cinacalcet_Chen2019_PD_ipth;
