function p = Levodopa_Nelson1989_PD_global_assessment_of_motor_function_params()
% Levodopa_Nelson1989_PD_global_assessment_of_motor_function_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levodopa Nelson_1989::global_assessment_of_motor_function: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms/ml per second, in SI inside (kg/m3, s). Response global assessment of motor function in its own unit. Driver: levodopa (pk_record).
p.E0 = 0.0;
p.Emax = 5.0;
p.EC50 = 0.0025299999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 26.0;
p.form = 'E0 + Emax*frac';
end
