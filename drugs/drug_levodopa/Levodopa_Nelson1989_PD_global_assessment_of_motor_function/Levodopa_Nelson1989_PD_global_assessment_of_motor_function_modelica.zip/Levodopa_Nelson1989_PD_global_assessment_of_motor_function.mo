model Levodopa_Nelson1989_PD_global_assessment_of_motor_function
  "emax exposure-response sweep — Nelson_1989 :: global assessment of motor function (global assessment of motor function)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 5,  // [1]
    EC50 = 0.00253,  // [kg/m3; micrograms/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 micrograms/ml per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 26, Interval = 0.052),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levodopa</h4><p>Levodopa is a dopaminergic agent used primarily to treat Parkinson's disease and related movement disorders. It is typically given by mouth in tablet or capsule forms, with inhalation available as an alternative route. The drug is authorised in the European Union for the treatment of Parkinson disease.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q300989\">Wikidata Q300989</a>, <a href=\"https://en.wikipedia.org/wiki/L-DOPA?oldid=1380015676\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Levodopa_Nelson1989_PD_global_assessment_of_motor_function</h4><p>The steady-state exposure-response curve of Nelson MV et al., <i>Clinical neuropharmacology 12(2):91–97</i> 1989 (<a href=\"https://doi.org/10.1097/00002826-198904000-00002\">doi:10.1097/00002826-198904000-00002</a>) — global assessment of motor function against levodopa micrograms/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          5          maximal effect term (Emax, Q320)
  EC50  =       2.53 micrograms/ml exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micrograms/ml of levodopa per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.53 micrograms/ml)  response 2.5
  exposure -> infinity  response 5</pre></body></html>"));
end Levodopa_Nelson1989_PD_global_assessment_of_motor_function;
