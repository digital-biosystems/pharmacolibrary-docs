function p = Levodopa_Westin2011_PD_motor_rating_params()
% Levodopa_Westin2011_PD_motor_rating_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levodopa Westin_2011::motor_rating: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response motor rating in U. Driver: levodopa (pk_record).
p.E0 = 0.0;
p.Emax = 3.9686883747188e-27;
p.EC50 = 0.0015499999999999997;
p.gamma = 11.6;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 16.0;
p.form = 'E0 + Emax*frac';
end
