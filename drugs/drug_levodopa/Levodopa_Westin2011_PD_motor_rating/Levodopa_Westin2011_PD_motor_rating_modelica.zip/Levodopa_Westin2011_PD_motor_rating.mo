model Levodopa_Westin2011_PD_motor_rating
  "sigmoid_emax exposure-response sweep — Westin_2011 :: motor rating (motor ratings (clinical assessment of motor function on a 7-point treatment response scale ranging from "very off" to "very hyperkinetic"))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 3.96868837472e-27,  // [kg; U × 1.66054e-27]
    EC50 = 0.00155,  // [kg/m3; mg/L × 0.001]
    gamma = 11.6,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 16, Interval = 0.032),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levodopa</h4><p>Levodopa is a dopaminergic medicine used to treat Parkinson's disease. It is an approved anti-Parkinson drug and remains widely used, with an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q300989\">Wikidata Q300989</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Levodopa_Westin2011_PD_motor_rating</h4><p>The steady-state exposure-response curve of Westin J et al., <i>Clinical neuropharmacology 34(2):61–65</i> 2011 (<a href=\"https://doi.org/10.1097/WNF.0b013e31820b570a\">doi:10.1097/WNF.0b013e31820b570a</a>) — motor ratings (clinical assessment of motor function on a 7-point treatment response scale ranging from &quot;very off&quot; to &quot;very hyperkinetic&quot;) [U] against levodopa mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.39 U        maximal effect term (Emax, Q320)
  EC50  =       1.55 mg/L     exposure at half of the maximal effect term (concentration at 50% effect, Q321)
  gamma =       11.6          Hill coefficient (sigmoidicity of the Emax function, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of levodopa per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.55 mg/L)  response 1.984e-27
  exposure -> infinity  response 3.969e-27</pre></body></html>"));
end Levodopa_Westin2011_PD_motor_rating;
