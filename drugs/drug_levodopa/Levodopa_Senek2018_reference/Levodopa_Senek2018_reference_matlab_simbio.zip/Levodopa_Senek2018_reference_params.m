function p = Levodopa_Senek2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levodopa   source: Senek_2018 / reference   route: oral
  p.name  = 'Levodopa_Senek2018_reference_params';
  p.drug  = 'levodopa';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 168.0;                % central volume [L]
  p.CL = 48.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 45.0;             % dose [mg]
end
