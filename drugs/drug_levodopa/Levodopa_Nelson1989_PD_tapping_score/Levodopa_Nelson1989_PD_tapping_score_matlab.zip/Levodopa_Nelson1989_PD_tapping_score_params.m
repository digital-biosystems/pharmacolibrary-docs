function p = Levodopa_Nelson1989_PD_tapping_score_params()
% Levodopa_Nelson1989_PD_tapping_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levodopa Nelson_1989::tapping_score: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microgram/ml per second, in SI inside (kg/m3, s). Response tapping score in taps/60 s. Driver: levodopa (pk_record).
p.E0 = 0.0;
p.Emax = 53.2;
p.EC50 = 0.0005799999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.8;
p.form = 'E0 + Emax*frac';
end
