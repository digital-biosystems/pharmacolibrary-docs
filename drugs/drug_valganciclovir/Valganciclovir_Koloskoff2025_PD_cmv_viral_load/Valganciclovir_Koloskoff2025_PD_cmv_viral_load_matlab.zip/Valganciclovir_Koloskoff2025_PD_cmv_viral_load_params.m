function p = Valganciclovir_Koloskoff2025_PD_cmv_viral_load_params()
% Valganciclovir_Koloskoff2025_PD_cmv_viral_load_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% valganciclovir Koloskoff_2025::CMV_viral_load: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg.h/L per second, in SI inside (kg/m3, s). Response CMV viral load in log10 copies/mL. Driver: ganciclovir (dose_only).
p.E0 = 3.782608695652174;
p.Emax = 16.3;
p.EC50 = 23.5;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 36.0;
p.form = 'E0/(1 + Emax*frac)';
end
