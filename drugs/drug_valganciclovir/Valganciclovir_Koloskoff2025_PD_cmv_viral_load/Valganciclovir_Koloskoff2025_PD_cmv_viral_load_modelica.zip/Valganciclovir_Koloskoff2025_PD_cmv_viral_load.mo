model Valganciclovir_Koloskoff2025_PD_cmv_viral_load
  "indirect_response_iv exposure-response sweep — Koloskoff_2025 :: CMV viral load (CMV viral load in plasma)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 3.78260869565,      // [log10 copies/mL]
    Emax = 16.3,  // type IV effect term
    EC50 = 23.5,  // [mg.h/L]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg.h/L per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.00087/0.00023 = 3.783) — the paper's stated baseline may differ
  // exposure_unit_unresolved: 'mg.h/L' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About valganciclovir</h4><p>Valganciclovir is an antiviral drug used to treat cytomegalovirus retinitis. It is an approved medicine and is included on the WHO list of essential medicines, so it is used widely around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423384\">Wikidata Q423384</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Valganciclovir_Koloskoff2025_PD_cmv_viral_load</h4><p>The steady-state exposure-response curve of Koloskoff K et al., <i>Clinical pharmacokinetics 64(7):1061–1069</i> 2025 (<a href=\"https://doi.org/10.1007/s40262-025-01526-z\">doi:10.1007/s40262-025-01526-z</a>) — CMV viral load in plasma [log10 copies/mL] against ganciclovir mg.h/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 3.78260869565 log10 copies/mL drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       16.3          maximal effect term (Emax, Q320)
  EC50  =       23.5 mg.h/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg.h/L of ganciclovir per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.783   (drug-free)
  exposure = EC50 (23.5 mg.h/L)  response 0.4134
  exposure -> infinity  response 0.2186</pre></body></html>"));
end Valganciclovir_Koloskoff2025_PD_cmv_viral_load;
