model Valganciclovir_Itohara2025_reference
  parameter Real Cl_ref = 2.6666666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0805 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3543617,
    adminMass = 0.0009,
    ka = 0.00016416666666666665,
    Tlag = 0.0,
    k12 = 4.796411318150449e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About valganciclovir</h4><p>Valganciclovir is an antiviral drug used to treat cytomegalovirus retinitis. It is an approved medicine and is included on the WHO list of essential medicines, so it is used widely around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423384\">Wikidata Q423384</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>valganciclovir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Itohara_2025</td></tr><tr><td>measured_compound:</td><td>valganciclovir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valganciclovir 354.362 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Itohara_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Valganciclovir_Itohara2025_reference;
