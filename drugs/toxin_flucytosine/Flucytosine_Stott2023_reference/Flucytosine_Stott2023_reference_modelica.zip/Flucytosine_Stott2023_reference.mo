model Flucytosine_Stott2023_reference
  parameter Real Cl_ref = 1.4749999999999999e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01476 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129094,
    adminMass = 0.00175,
    ka = 0.00028055555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>adults with HIV-associated cryptococcal meningoencephalitis</td></tr><tr><td>source_paper:</td><td>Stott_2023</td></tr><tr><td>measured_compound:</td><td>Flucytosine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkad038-T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>flucytosine 129.094 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>competing summary columns for 'Ka (h−1)'; not population strata</li><li>competing summary columns for 'Ka (h−1)'; not population strata</li><li>competing summary columns for 'CL/F (L/h)'; not population strata</li><li>competing summary columns for 'CL/F (L/h)'; not population strata</li><li>competing summary columns for 'V/F (L)'; not population strata</li><li>competing summary columns for 'V/F (L)'; not population strata</li><li>competing summary columns for 'K23 (h−1)'; not population strata</li><li>competing summary columns for 'K23 (h−1)'; not population strata</li><li>competing summary columns for 'K32 (h−1)'; not population strata</li><li>competing summary columns for 'K32 (h−1)'; not population strata</li><li>competing summary columns for 'K24 (h−1)'; not population strata</li><li>competing summary columns for 'K24 (h−1)'; not population strata</li><li>competing summary columns for 'K42 (h−1)'; not population strata</li><li>competing summary columns for 'K42 (h−1)'; not population strata</li><li>competing summary columns for 'Vcns/F (L)'; not population strata</li><li>competing summary columns for 'Vcns/F (L)'; not population strata</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flucytosine_Stott2023_reference;
