// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flucytosine_Ibnou2024_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {71.29513857188009},
    MM = 0.129094,
    adminMass = 0.0015,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>healthy participants</td></tr><tr><td>source_paper:</td><td>Ibnou_2024</td></tr><tr><td>measured_compound:</td><td>Flucytosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>cts13908-tbl-0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>flucytosine 129.094 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'C max (μg/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC(0–t) (h μg/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC(0–∞) (h μg/mL)'; source reconciliation required</li><li>table representations disagree for 'λ z (/h)'; source reconciliation required</li><li>table representations disagree for 't ½ (h)'; source reconciliation required</li><li>table representations disagree for 't max (h) (median and range)'; source reconciliation required</li><li>dropped duplicate Q88 ('AUC(0–∞) (h μg/mL)', value '35') — already have one for this compound</li><li>dropped unlinked row (NIL): 't max (h) (median and range)' — extend the ontology if this is a real PK parameter (source ['cts13908-tbl-0002:row8:col1', 'cts13908-tbl-0002:row8:col2', 'cts13908-tbl-0002:row8:col3', 'cts13908-tbl-0002:row8:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flucytosine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Kim_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Flucytosine_Ibnou2024_reference;
