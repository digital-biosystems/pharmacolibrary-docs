model Flucytosine_Kunka2015_reference
  parameter Real Cl_ref = 7.000000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.063 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129094,
    adminMass = 0.0025
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>critically ill patient receiving continuous renal replacement therapy</td></tr><tr><td>source_paper:</td><td>Kunka_2015</td></tr><tr><td>measured_compound:</td><td>Flucytosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flucytosine 129.094 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('half-life can increase up to'=250) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd has been reported as up to'=0.9) from results prose — parameter table was unreadable</li><li>salvaged Q47 ('elimination rate constant (ke)'=0.04) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flucytosine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=2.52 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Flucytosine_Kunka2015_reference;
