function p = Vorozole_Piotrovsky1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vorozole   source: Piotrovsky_1998 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vorozole_Piotrovsky1998_reference_params';
  p.drug  = 'vorozole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 30.1;                % central volume [L]
  p.CL = 4.8;                % clearance [L/h]
  p.Vp = [44.8];             % peripheral volumes [L]
  p.Q  = [0.17];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
