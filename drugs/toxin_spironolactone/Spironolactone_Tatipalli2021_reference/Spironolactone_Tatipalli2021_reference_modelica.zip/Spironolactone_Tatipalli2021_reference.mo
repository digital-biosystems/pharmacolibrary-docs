// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Spironolactone_Tatipalli2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.001, 0.517},
    CLelim = {0.00017472222222222222, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {2.4972222222222226e-05, 2.4972222222222226e-05}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>spironolactone</td></tr><tr><td>population:</td><td>healthy adult male subjects of South Asian descent (Indian), extrapolated to pediatric subjects 2 to <17 years</td></tr><tr><td>source_paper:</td><td>Tatipalli_2021</td></tr><tr><td>measured_compound:</td><td>Spironolactone (also canrenone)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00849-t003</td></tr><tr><td>molar_masses:</td><td>Spironolactone 416.576 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>compound tags: 18 row(s) → Canrenone (m_suffix 18)</li><li>table section iiv: 'ka (1/h)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'V2 (L)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'CL, V2 (covariance)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'Q (L/h)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'CLM1 (L/h)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'CLM (L/h)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'V4 (L)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'Q1 (L/h)' routed out of structural estimates ('Between Subject Variability')</li><li>table section iiv: 'V5 (L)' routed out of structural estimates ('Between Subject Variability')</li><li>table section residual_error: 'EPS1' routed out of structural estimates ('Residual Error')</li><li>table section residual_error: 'EPS2' routed out of structural estimates ('Residual Error')</li><li>table representations disagree for 'ALAG1'; source reconciliation required</li><li>table representations disagree for 'ka(1/h)'; source reconciliation required</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Spironolactone_Tatipalli2021_reference;
