model Antimony_Ling2025_PD_mmse
  "linear exposure-response sweep — Ling_2025 :: MMSE (cognitive function)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 4.67,  // [score]
    exposure_per_s = 1);   // 1 μg/m3 per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Antimony_Ling2025_PD_mmse</h4><p>The steady-state exposure-response curve of Ling HT et al., <i>Zhonghua yu fang yi xue za zhi [Chinese journal of preventive medicine] 59(4):416–424</i> 2025 (<a href=\"https://doi.org/10.3760/cma.j.cn112150-20241028-00853\">doi:10.3760/cma.j.cn112150-20241028-00853</a>) — cognitive function [score] against antimony (Sb) μg/m3 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       4.67 score    change in response per unit of exposure (MMSE score decrease per IQR increase in Sb, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/m3 of antimony (Sb) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Antimony_Ling2025_PD_mmse;
