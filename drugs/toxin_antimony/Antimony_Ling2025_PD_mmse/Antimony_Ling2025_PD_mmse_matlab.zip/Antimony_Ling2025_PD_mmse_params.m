function p = Antimony_Ling2025_PD_mmse_params()
% Antimony_Ling2025_PD_mmse_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% antimony Ling_2025::MMSE: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/m3 per second, in SI inside (kg/m3, s). Response MMSE in score. Driver: antimony (Sb) (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 4.67;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
