% Run: build params, simulate 0..120.0 h, plot every molecule + save Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.m
here = fileparts(mfilename('fullpath'));
p = Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d_params();
out = simulate_network(p, 0:0.05:120.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('antimony — Coelho_2014 (retention function)');
print(fig, fullfile(here, 'Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.json'), 'w');
try
  s.model = 'Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.png, Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.csv, Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d.json\n');
