function p = Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: antimony   source: Coelho_2014 / time_after_the_last_injection_of_ma_21_days   TK_Retention retention function, 2 pools (V = 1 L each: A/V = burden in mg)
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
  p.name  = 'Antimony_Coelho2014_time_after_the_last_injection_of_ma_21_d_params';
  p.drug  = 'antimony';
  p.kind  = 'network';
  p.template = 'TK_Retention';
  p.states = {'pool_1', 'pool_2'};
  p.V = [1.0, 1.0];          % compartment volumes [L]
  p.K = [-1.1552453009332422, 0.0;
         0.0, -0.028881132523331052];
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;
  p.dose_into = [1.0, 2.0];   % pools
  p.dose_frac = [0.5, 0.5];   % fraction A_i of the intake
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 5250.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'burden_pool_1', 'burden_pool_2'};
  p.out_labels = {'burden of pool_1 (mg; A = 0.5, Tb = 0.025 d)', 'burden of pool_2 (mg; A = 0.5, Tb = 1 d)'};
end
