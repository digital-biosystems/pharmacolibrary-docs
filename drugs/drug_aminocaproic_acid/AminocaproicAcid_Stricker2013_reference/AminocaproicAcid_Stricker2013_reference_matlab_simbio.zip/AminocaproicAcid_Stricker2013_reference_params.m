function p = AminocaproicAcid_Stricker2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: aminocaproic_acid   source: Stricker_2013 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'AminocaproicAcid_Stricker2013_reference_params';
  p.drug  = 'aminocaproic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.27;                % central volume [L]
  p.CL = 1.92;                % clearance [L/h]
  p.Vp = [2.53];             % peripheral volumes [L]
  p.Q  = [2.544];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 16000.0;             % dose [mg]
end
