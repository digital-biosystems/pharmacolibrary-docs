function p = Apomorphine_Patel1995_PD_single_pulse_stimulated_dopamine_re_params()
% Apomorphine_Patel1995_PD_single_pulse_stimulated_dopamine_re_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% apomorphine Patel_1995::single_pulse_stimulated_dopamine_release: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response single pulse stimulated dopamine release in its own unit. Driver: apomorphine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.9309999999999999;
p.EC50 = 82.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 820.0;
p.form = 'E0 + Emax*frac';
end
