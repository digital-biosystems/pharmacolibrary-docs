model Apomorphine_Patel1995_PD_single_pulse_stimulated_dopamine_re
  "emax exposure-response sweep — Patel_1995 :: single pulse stimulated dopamine release (single pulse stimulated dopamine release)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.931,  // [1; % × 0.01]
    EC50 = 82,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 820, Interval = 1.64),
    Documentation(info = "<html><body><!-- drug-about --><h4>About apomorphine</h4><p>Apomorphine is a dopamine agonist used to treat Parkinson's disease and has also been used for erectile dysfunction. It remains an approved medicine, used mainly for Parkinson's disease, though some European products for erectile dysfunction have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q269111\">Wikidata Q269111</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Apomorphine_Patel1995_PD_single_pulse_stimulated_dopamine_re</h4><p>The steady-state exposure-response curve of Patel J et al., <i>British journal of pharmacology 115(3):421–426</i> 1995 (<a href=\"https://doi.org/10.1111/j.1476-5381.1995.tb16350.x\">doi:10.1111/j.1476-5381.1995.tb16350.x</a>) — single pulse stimulated dopamine release against apomorphine nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       93.1 %        maximal effect term (maximum inhibition, Q323)
  EC50  =         82 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of apomorphine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (82 nM)  response -0.4655
  exposure -> infinity  response -0.931</pre></body></html>"));
end Apomorphine_Patel1995_PD_single_pulse_stimulated_dopamine_re;
