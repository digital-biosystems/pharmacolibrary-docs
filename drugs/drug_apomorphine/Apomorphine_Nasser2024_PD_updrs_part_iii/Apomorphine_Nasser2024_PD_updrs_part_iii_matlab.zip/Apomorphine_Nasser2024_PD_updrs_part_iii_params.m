function p = Apomorphine_Nasser2024_PD_updrs_part_iii_params()
% Apomorphine_Nasser2024_PD_updrs_part_iii_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% apomorphine Nasser_2024::UPDRS_Part_III: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response UPDRS Part III in its own unit. Driver: apomorphine (pk_record).
p.E0 = 24.3;
p.Emax = -1.0;
p.EC50 = 1.07e-05;
p.gamma = 3.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 110.0;
p.form = 'E0 + Emax*frac';
end
