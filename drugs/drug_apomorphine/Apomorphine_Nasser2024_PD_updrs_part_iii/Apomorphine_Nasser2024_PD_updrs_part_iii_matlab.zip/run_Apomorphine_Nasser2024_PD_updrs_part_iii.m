% run_Apomorphine_Nasser2024_PD_updrs_part_iii  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Apomorphine_Nasser2024_PD_updrs_part_iii_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/mL]'); ylabel('response []'); title('Apomorphine_Nasser2024_PD_updrs_part_iii', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Apomorphine_Nasser2024_PD_updrs_part_iii.csv');
