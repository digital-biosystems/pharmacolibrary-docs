model Apomorphine_Nasser2024_PD_updrs_part_iii
  "sigmoid_emax exposure-response sweep — Nasser_2024 :: UPDRS Part III (UPDRS motor scores)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 24.3,      // [1]
    Emax = -1,  // [1]
    EC50 = 1.07e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 3,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About apomorphine</h4><p>Apomorphine is a dopamine agonist used to treat Parkinson's disease and has also been used for erectile dysfunction. It remains an approved medicine, used mainly for Parkinson's disease, though some European products for erectile dysfunction have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q269111\">Wikidata Q269111</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Apomorphine_Nasser2024_PD_updrs_part_iii</h4><p>The steady-state exposure-response curve of Nasser A et al., <i>Journal of pharmacokinetics and pharmacodynamics 51(4):385–393</i> 2024 (<a href=\"https://doi.org/10.1007/s10928-024-09914-x\">doi:10.1007/s10928-024-09914-x</a>) — UPDRS motor scores against apomorphine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       24.3          drug-free response (baseline) (B0, Q324)
  Emax  =          1          maximal effect term (Emax, Q323)
  EC50  =       10.7 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =          3          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of apomorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 24.3   (drug-free)
  exposure = EC50 (10.7 ng/mL)  response 23.8
  exposure -> infinity  response 23.3</pre></body></html>"));
end Apomorphine_Nasser2024_PD_updrs_part_iii;
