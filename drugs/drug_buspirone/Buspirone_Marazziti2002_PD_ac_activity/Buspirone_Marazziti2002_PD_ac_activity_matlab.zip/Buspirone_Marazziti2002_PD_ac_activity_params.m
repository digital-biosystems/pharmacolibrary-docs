function p = Buspirone_Marazziti2002_PD_ac_activity_params()
% Buspirone_Marazziti2002_PD_ac_activity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buspirone Marazziti_2002::AC_activity: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response AC activity in %. Driver: buspirone (cited_pk).
p.E0 = 0.0;
p.Emax = -0.12;
p.EC50 = 3.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 30.0;
p.form = 'E0 + Emax*frac';
end
