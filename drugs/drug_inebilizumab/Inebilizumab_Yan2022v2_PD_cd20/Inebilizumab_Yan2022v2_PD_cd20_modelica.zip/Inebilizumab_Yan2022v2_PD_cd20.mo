model Inebilizumab_Yan2022v2_PD_cd20
  "linear exposure-response sweep — Yan_2022_2 :: CD20+ (CD20+ B-cell count)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 135,      // [cells μL−1]
    slope = 0.014,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About inebilizumab</h4><p>Inebilizumab is a monoclonal antibody used to treat neuromyelitis optica. It is an approved immunosuppressant authorised in the European Union, though not yet widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25326696\">Wikidata Q25326696</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Inebilizumab_Yan2022v2_PD_cd20</h4><p>The steady-state exposure-response curve of Yan L et al., <i>British journal of clinical pharmacology 88(8):3803–3812</i> 2022 (<a href=\"https://doi.org/10.1111/bcp.15332\">doi:10.1111/bcp.15332</a>) — CD20+ B-cell count [cells μL−1] against inebilizumab — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        135 cells μL−1 drug-free response (baseline) (Baseline CD20, Q324)
  slope =      0.014          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of inebilizumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 135   (drug-free)</pre></body></html>"));
end Inebilizumab_Yan2022v2_PD_cd20;
