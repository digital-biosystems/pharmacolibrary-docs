function p = Inebilizumab_Yan2022v2_PD_cd20_params()
% Inebilizumab_Yan2022v2_PD_cd20_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% inebilizumab Yan_2022_2::CD20: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response CD20+ in cells μL−1. Driver: inebilizumab (cited_pk).
p.E0 = 135.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.014;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
