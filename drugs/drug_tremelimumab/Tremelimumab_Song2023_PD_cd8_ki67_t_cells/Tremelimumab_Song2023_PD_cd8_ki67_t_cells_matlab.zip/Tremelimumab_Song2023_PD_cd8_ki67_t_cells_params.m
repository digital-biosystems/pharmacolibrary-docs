function p = Tremelimumab_Song2023_PD_cd8_ki67_t_cells_params()
% Tremelimumab_Song2023_PD_cd8_ki67_t_cells_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tremelimumab Song_2023::CD8_Ki67_T_cells: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response CD8+Ki67+ T cells in %CFB. Driver: tremelimumab (cited_pk).
p.E0 = 0.0;
p.Emax = 3.41;
p.EC50 = 0.005239999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 53.0;
p.form = 'E0 + Emax*frac';
end
