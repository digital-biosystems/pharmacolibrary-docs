model Tremelimumab_Song2023_PD_cd8_ki67_t_cells
  "emax exposure-response sweep — Song_2023 :: CD8+Ki67+ T cells (CD8+Ki67+ T-cell count)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 3.41,  // [1; % × 0.01]
    EC50 = 0.00524,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 53, Interval = 0.106),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tremelimumab</h4><p>Tremelimumab is a monoclonal antibody used as an anticancer medicine, notably for liver cancer and non-small-cell lung cancer. It is authorised in the European Union and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7838098\">Wikidata Q7838098</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tremelimumab_Song2023_PD_cd8_ki67_t_cells</h4><p>The steady-state exposure-response curve of Song X et al., <i>Clinical cancer research : an official journal of the American Association for Cancer Research 29(4):754–763</i> 2023 (<a href=\"https://doi.org/10.1158/1078-0432.CCR-22-1983\">doi:10.1158/1078-0432.CCR-22-1983</a>) — CD8+Ki67+ T-cell count [%CFB] against tremelimumab μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        341 %        maximal effect term (Emax, Q320)
  EC50  =       5.24 μg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of tremelimumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.24 μg/mL)  response 1.705
  exposure -> infinity  response 3.41</pre></body></html>"));
end Tremelimumab_Song2023_PD_cd8_ki67_t_cells;
