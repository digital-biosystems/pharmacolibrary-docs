model Ximelagatran_Eriksson2003_reference
  parameter Real Cl_ref = 1.4722222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0155 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42952100000000004,
    adminMass = 4.8e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ximelagatran</h4><p>Ximelagatran is an anticoagulant (direct thrombin inhibitor) that was studied extensively as a possible replacement for warfarin, including for atrial fibrillation. It is no longer used: it was withdrawn from the market, and its marketing application in the European Union was withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3570984\">Wikidata Q3570984</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ximelagatran</td></tr><tr><td>population:</td><td>orthopaedic surgery patients</td></tr><tr><td>source_paper:</td><td>Eriksson_2003</td></tr><tr><td>measured_compound:</td><td>melagatran</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>melagatran 429.521 g/mol (pubchem); ximelagatran 473.565 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is ximelagatran; the compartment is melagatran. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is melagatran, not ximelagatran</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>ximelagatran's own concentration-time course is not produced by this model</li><li>metabolite melagatran: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite volume: 'median population estimates ... subcutaneous' Q63→Q61 for melagatran — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=melagatran</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [1]</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 5/5 row label(s) assigned, 4 linked by role; re-tagged melagatran→ximelagatran ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'melagatran', not ximelagatran — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ximelagatran_Eriksson2003_reference;
