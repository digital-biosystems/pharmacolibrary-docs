// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Perhexiline_Amoah1986_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {44640.0},
    MM = 0.27749599999999996,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>perhexiline</td></tr><tr><td>population:</td><td>young volunteers</td></tr><tr><td>source_paper:</td><td>Amoah_1986</td></tr><tr><td>measured_compound:</td><td>Perhexiline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Perhexiline 277.496 g/mol (pubchem); cis-Monohydroxyperhexiline 293.495 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Amoah_1986:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Perhexiline</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 0 linked by role; re-tagged Perhexiline→cis-Monohydroxyperhexiline ×1</li><li>molar mass: no plausible PubChem entry for 'trans-Monohydroxyperhexiline' ('trans-hydroxyperhexilline') — left in mass units</li><li>molar mass: none found for 'trans-Monohydroxyperhexiline' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Perhexiline_Amoah1986_reference;
