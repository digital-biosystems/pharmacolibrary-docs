model AflatoxinG_Rejeb2020_reference
  parameter Real Cl_ref = 0.0005541666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 1.5763999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aflatoxin_g</td></tr><tr><td>population:</td><td>broiler chickens</td></tr><tr><td>source_paper:</td><td>Rejeb_2020</td></tr><tr><td>measured_compound:</td><td>AFG1</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>toxins-12-00660-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aflatoxin_g 328.276 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC0−t'</li><li>dropped value-less row: 'AUC0−∞'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'C0'</li><li>dropped value-less row: 'tmax'</li><li>dropped value-less row: 'kel'</li><li>dropped value-less row: 't1/2el'</li><li>dropped value-less row: 'Cl'</li><li>dropped value-less row: 'Vd'</li><li>dropped value-less row: 'p'</li><li>dropped value-less row: 'SD'</li><li>salvaged Q57 ('T1/2el (PO)'=1.36) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd (IV)'=22.52) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Cl (IV)'=28.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=AFG1</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AflatoxinG_Rejeb2020_reference;
