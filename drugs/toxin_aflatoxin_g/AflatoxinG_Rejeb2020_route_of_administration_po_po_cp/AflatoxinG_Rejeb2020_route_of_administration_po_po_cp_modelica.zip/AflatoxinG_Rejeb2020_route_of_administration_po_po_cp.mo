// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model AflatoxinG_Rejeb2020_route_of_administration_po_po_cp
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7740.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>aflatoxin_g</td></tr><tr><td>population:</td><td>broiler chickens</td></tr><tr><td>source_paper:</td><td>Rejeb_2020</td></tr><tr><td>measured_compound:</td><td>AFG1</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>toxins-12-00660-t002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>aflatoxin_g 328.276 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC0−t'</li><li>dropped value-less row: 'AUC0−∞'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'C0'</li><li>dropped value-less row: 'tmax'</li><li>dropped value-less row: 'kel'</li><li>dropped value-less row: 't1/2el'</li><li>dropped value-less row: 'Cl'</li><li>dropped value-less row: 'Vd'</li><li>dropped value-less row: 'p'</li><li>dropped value-less row: 'SD'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=AFG1</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'route of administration / po / po + cp' subgroup of Rejeb_2020 (paper reports 4 populations: route of administration / po, route of administration / po / po + cc, route of administration / po / po + cp, toxicokinetic parameters / iv)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end AflatoxinG_Rejeb2020_route_of_administration_po_po_cp;
