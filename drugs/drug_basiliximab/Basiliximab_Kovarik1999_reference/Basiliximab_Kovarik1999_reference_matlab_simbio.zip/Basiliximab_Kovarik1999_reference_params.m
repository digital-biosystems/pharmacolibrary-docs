function p = Basiliximab_Kovarik1999_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: basiliximab   source: Kovarik_1999 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Basiliximab_Kovarik1999_reference_params';
  p.drug  = 'basiliximab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.0;                % central volume [L]
  p.CL = 0.0367;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
