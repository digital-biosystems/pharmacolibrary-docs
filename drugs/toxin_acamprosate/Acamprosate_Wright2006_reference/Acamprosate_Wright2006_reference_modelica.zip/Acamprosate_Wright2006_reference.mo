model Acamprosate_Wright2006_reference
  parameter Real Cl_ref = 5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.18120599999999998,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acamprosate</td></tr><tr><td>population:</td><td>adults with alcohol dependence, including those with renal or hepatic impairment</td></tr><tr><td>source_paper:</td><td>Wright_2006</td></tr><tr><td>measured_compound:</td><td>Acamprosate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t2-ndt-2-445</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>acamprosate 181.206 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('Volume of distribution'=1) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('creatinine clearance of'=30) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Acamprosate</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Acamprosate_Wright2006_reference;
