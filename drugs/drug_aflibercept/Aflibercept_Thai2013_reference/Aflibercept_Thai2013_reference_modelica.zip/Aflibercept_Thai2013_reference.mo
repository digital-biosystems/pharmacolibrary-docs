model Aflibercept_Thai2013_reference
  parameter Real Cl_ref = 1.0185185185185186e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aflibercept</h4><p>Aflibercept is used to treat several eye conditions involving abnormal blood vessel growth or swelling in the retina, such as wet macular degeneration, diabetic retinopathy, macular edema and retinal vein occlusion, and is also used for colorectal cancer. It is an approved medicine, authorised in the European Union for multiple eye and cancer indications, and is widely used in ophthalmology.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4689286\">Wikidata Q4689286</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aflibercept</td></tr><tr><td>population:</td><td>patients with advanced solid tumors</td></tr><tr><td>source_paper:</td><td>Thai_2013</td></tr><tr><td>measured_compound:</td><td>aflibercept</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL(b)', value 0.19) — already have one for this compound</li><li>dropped duplicate Q61 ('V(b)', value 4) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=aflibercept</li><li>molar mass: none found for 'aflibercept' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 1));
end Aflibercept_Thai2013_reference;
