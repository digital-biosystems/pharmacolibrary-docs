% Run (SimBiology): build model + dose, simulate 0..384.0 h, plot.
p = Aflibercept_Thai2013_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 384.0);
