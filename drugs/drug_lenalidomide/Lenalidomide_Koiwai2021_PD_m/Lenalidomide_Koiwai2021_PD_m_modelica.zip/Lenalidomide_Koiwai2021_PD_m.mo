model Lenalidomide_Koiwai2021_PD_m
  "linear exposure-response sweep — Koiwai_2021 :: M (serum M-protein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 23.8,      // [kg/m3; g/L × 1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1000);
  parameter Real slope = 0.0193   "[mol-1·d-1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lenalidomide</h4><p>Lenalidomide is an immunomodulating and anti-angiogenic drug used to treat blood cancers and related disorders, including multiple myeloma, myelodysplastic syndromes, and several types of lymphoma and leukemia. It is approved and widely used, with several authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425681\">Wikidata Q425681</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lenalidomide_Koiwai2021_PD_m</h4><p>The steady-state exposure-response curve of Koiwai K et al., <i>CPT: pharmacometrics &amp; systems pharmacology 10(8):928–940</i> 2021 (<a href=\"https://doi.org/10.1002/psp4.12666\">doi:10.1002/psp4.12666</a>) — serum M-protein [g/L] against lenalidomide mol/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       23.8 g/L      drug-free response (baseline) (M0, Q324)
  slope =     0.0193 mol-1·d-1 change in response per unit of exposure (KD, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mol/L of lenalidomide per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 23.8   (drug-free)</pre></body></html>"));
end Lenalidomide_Koiwai2021_PD_m;
