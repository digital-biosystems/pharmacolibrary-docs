function p = Lenalidomide_Koiwai2021_PD_m_params()
% Lenalidomide_Koiwai2021_PD_m_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lenalidomide Koiwai_2021::M: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mol/L per second, in SI inside (kg/m3, s). Response M in g/L. Driver: lenalidomide (cited_pk).
p.E0 = 23.799999999999997;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0193;
p.exposure_per_s = 1000.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
