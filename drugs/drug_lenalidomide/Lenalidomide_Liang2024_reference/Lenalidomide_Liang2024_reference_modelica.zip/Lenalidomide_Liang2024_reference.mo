model Lenalidomide_Liang2024_reference
  parameter Real Cl_ref = 1.972222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0099 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2592606,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lenalidomide</h4><p>Lenalidomide is an immunomodulating and anti-angiogenic drug used to treat blood cancers and related disorders, including multiple myeloma, myelodysplastic syndromes, and several types of lymphoma and leukemia. It is approved and widely used, with several authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425681\">Wikidata Q425681</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lenalidomide</td></tr><tr><td>population:</td><td>Chinese patients with lymphoma, myelodysplastic syndrome, or myeloma</td></tr><tr><td>source_paper:</td><td>Liang_2024</td></tr><tr><td>measured_compound:</td><td>lenalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>lenalidomide 259.261 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ABCBA 3435 C > T = CT' — extend the ontology if this is a real PK parameter (source ['Tab4:row6:col2'])</li><li>dropped unlinked row (NIL): 'ABCBA 3435 C > T = TT' — extend the ontology if this is a real PK parameter (source ['Tab4:row7:col2'])</li><li>kept covariate coefficient θCHFY=24.4 (covariate CHFY) — not an ontology parameter</li><li>unit_dimension_mismatch: 'ηCL/F(%)' → Q27 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('ηCL/F(%)', value '17.1') — already have one for this compound</li><li>unit_dimension_mismatch: 'ηV/F(%)' → Q76 (unit 'dimensionless' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q76 ('ηV/F(%)', value '17.0') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ε(ng/mL)' — extend the ontology if this is a real PK parameter (source ['Tab4:row11:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lenalidomide</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lenalidomide_Liang2024_reference;
