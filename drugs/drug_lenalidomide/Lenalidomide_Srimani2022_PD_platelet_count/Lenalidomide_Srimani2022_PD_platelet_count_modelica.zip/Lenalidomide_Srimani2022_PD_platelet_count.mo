model Lenalidomide_Srimani2022_PD_platelet_count
  "linear exposure-response sweep — Srimani_2022 :: platelet count (platelet count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 2.24   "[/week/(len conc.)]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lenalidomide</h4><p>Lenalidomide is an immunomodulating and anti-angiogenic drug used to treat blood cancers and related disorders, including multiple myeloma, myelodysplastic syndromes, and several types of lymphoma and leukemia. It is approved and widely used, with several authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425681\">Wikidata Q425681</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lenalidomide_Srimani2022_PD_platelet_count</h4><p>The steady-state exposure-response curve of Srimani JK et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(8):1085–1099</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12815\">doi:10.1002/psp4.12815</a>) — platelet count against lenalidomide — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       2.24 /week/(len conc.) change in response per unit of exposure (slpLEN, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of lenalidomide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Lenalidomide_Srimani2022_PD_platelet_count;
