function p = EdeticAcid_Levitt2003_morphine_6_glucuronide_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: edetic_acid   source: Levitt_2003 / morphine_6_glucuronide   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'EdeticAcid_Levitt2003_morphine_6_glucuronide_params';
  p.drug  = 'edetic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.85;                % central volume [L]
  p.CL = 0.00576;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
