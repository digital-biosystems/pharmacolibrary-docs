model Thiotepa_Kondo2019_thiotepa
  parameter Real Cl_ref = 4.325000000000001e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.015570000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.18921700000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thiotepa</td></tr><tr><td>population:</td><td>Japanese pediatric patients with solid tumors or brain tumors and adult patients with malignant lymphoma undergoing autologous HSCT</td></tr><tr><td>source_paper:</td><td>Kondo_2019</td></tr><tr><td>measured_compound:</td><td>thiotepa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>thiotepa 189.217 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=thiotepa</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'thiotepa' subgroup of Kondo_2019 (paper reports 5 populations: adult malignant lymphoman = 10, pediatric solid tumor or pediatric brain tumorn = 9, tepa, thiotepa, totaln = 19)</li><li>row roles (LLM): model_class=noncompartmental; 0/54 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'TEPA (triethylene phosphoramide)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Thiotepa_Kondo2019_thiotepa;
