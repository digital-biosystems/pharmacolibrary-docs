function p = Thiotepa_Kondo2019_thiotepa_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: thiotepa   source: Kondo_2019 / thiotepa   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Thiotepa_Kondo2019_thiotepa_params';
  p.drug  = 'thiotepa';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15.57;                % central volume [L]
  p.CL = 15.57;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
