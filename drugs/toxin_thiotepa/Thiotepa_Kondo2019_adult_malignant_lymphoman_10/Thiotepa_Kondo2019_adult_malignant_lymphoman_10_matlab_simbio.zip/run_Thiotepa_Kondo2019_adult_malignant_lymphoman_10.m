% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Thiotepa_Kondo2019_adult_malignant_lymphoman_10_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
