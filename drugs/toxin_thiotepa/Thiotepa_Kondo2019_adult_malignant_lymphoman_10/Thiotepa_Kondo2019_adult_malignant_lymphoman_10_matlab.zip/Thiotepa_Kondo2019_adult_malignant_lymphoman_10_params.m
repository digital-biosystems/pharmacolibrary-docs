function p = Thiotepa_Kondo2019_adult_malignant_lymphoman_10_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: thiotepa   source: Kondo_2019 / adult_malignant_lymphoman_10   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Thiotepa_Kondo2019_adult_malignant_lymphoman_10_params';
  p.drug  = 'thiotepa';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.258;                % central volume [L]
  p.CL = 11.591;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
