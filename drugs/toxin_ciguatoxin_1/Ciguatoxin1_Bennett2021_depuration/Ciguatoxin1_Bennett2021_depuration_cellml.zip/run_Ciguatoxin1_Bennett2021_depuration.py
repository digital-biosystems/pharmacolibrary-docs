#!/usr/bin/env python3
"""Simulate Ciguatoxin1_Bennett2021_depuration.cellml (0..4320.0 h) — a toxin retention function — and write
Ciguatoxin1_Bennett2021_depuration.csv, Ciguatoxin1_Bennett2021_depuration.json and Ciguatoxin1_Bennett2021_depuration.png. Requires libcellml, scipy and matplotlib."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import libcellml as lc
from scipy.integrate import solve_ivp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Ciguatoxin1_Bennett2021_depuration")
OUT = {'burden': 'whole-body burden (mg)'}                        # output -> molecule
EDGES = [0.016666666666666666, 0.18333333333333332]                     # the dose pulse [h]: integrated piecewise across it

model = lc.Parser().parseModel(open(BASE + ".cellml").read())
validator = lc.Validator(); validator.validateModel(model)
if validator.errorCount():
    raise SystemExit("Ciguatoxin1_Bennett2021_depuration.cellml is not valid: " + validator.error(0).description())
analyser = lc.Analyser(); analyser.analyseModel(model)
if analyser.errorCount():
    raise SystemExit("Ciguatoxin1_Bennett2021_depuration.cellml is not solvable: " + analyser.error(0).description())
generator = lc.Generator()
generator.setProfile(lc.GeneratorProfile(lc.GeneratorProfile.Profile.PYTHON))
generator.setModel(analyser.model())
ns = {}
exec(compile(generator.implementationCode(), "<generated>", "exec"), ns)
states = ns["create_states_array"]()
variables = ns["create_variables_array"]()
ns["initialise_variables"](states, ns["create_states_array"](), variables)
ns["compute_computed_constants"](variables)

def rhs(t, y):
    r = ns["create_states_array"]()
    ns["compute_rates"](t, list(y), r, variables)
    return list(r)

t_eval = np.linspace(0.0, 4320.0, 2001)
cuts = sorted({0.0, 4320.0, *[e for e in EDGES if 0.0 < e < 4320.0]})
ts, ys, y0 = [], [], list(states)
for a, b in zip(cuts[:-1], cuts[1:]):
    te = t_eval[(t_eval >= a) & (t_eval <= b)]
    sol = solve_ivp(rhs, (a, b), y0, t_eval=np.unique(np.r_[a, te, b]),
                    method="LSODA", rtol=1e-10, atol=1e-12)
    if not sol.success:
        raise SystemExit("integration failed: " + sol.message)
    keep = np.isin(sol.t, t_eval) & ((sol.t > a) if ts else True)
    ts += list(sol.t[keep]); ys += list(sol.y[:, keep].T); y0 = list(sol.y[:, -1])

names = [v.get("name") if isinstance(v, dict) else str(v) for v in ns.get("VARIABLE_INFO", [])]
cols = {o: [] for o in OUT}
for tk, yk in zip(ts, ys):
    v = list(variables)
    ns["compute_variables"](tk, list(yk), ns["create_states_array"](), v)
    for o in OUT:
        cols[o].append(float(v[names.index(o)]))
t = [float(x) for x in ts]

with open(BASE + ".csv", "w") as f:
    f.write("time_h," + ",".join(o + "_mg" for o in OUT) + "\n")
    for k, ti in enumerate(t):
        f.write("%r," % ti + ",".join("%r" % cols[o][k] for o in OUT) + "\n")
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Ciguatoxin1_Bennett2021_depuration", "stop_time_h": 4320.0, "labels": OUT, "time_h": t,
               **{o + "_mg": cols[o] for o in OUT}}, f, indent=2)
plt.figure()
for o in OUT:
    plt.semilogy(t, [max(c, 1e-12) for c in cols[o]], linewidth=1.5, label=f"{OUT[o]} ({o})")
plt.xlabel("time [h]"); plt.ylabel("body burden [mg]"); plt.legend()
plt.title("Ciguatoxin1_Bennett2021_depuration"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
