function p = Donepezil_Park2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Park_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Donepezil_Park2025_reference_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 58.2;                % central volume [L]
  p.CL = 9.57;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.00173;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
