model Donepezil_Park2025_reference
  parameter Real Cl_ref = 2.6583333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0582 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3795,
    adminMass = 7.5e-06,
    ka = 4.805555555555556e-07,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>donepezil</td></tr><tr><td>population:</td><td>healthy male Korean adults</td></tr><tr><td>source_paper:</td><td>Park_2025</td></tr><tr><td>measured_compound:</td><td>Donepezil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-01517-t006</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>donepezil 379.5 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('KA4, 1/h', value '0.0113') — already have one for this compound</li><li>dropped unlinked row (NIL): 'F3' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-01517-t006:row8:col1'])</li><li>dropped duplicate Q83 ('ALAG4', value '1130') — already have one for this compound</li><li>routed 'ε1 (additive), ng/mL' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'ε2 (proportional) a' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL, L/h); Q63 (V1, L); Q64 (V2, L); Q30 (Q)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Donepezil</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q30, Q310, Q83 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Donepezil_Park2025_reference;
