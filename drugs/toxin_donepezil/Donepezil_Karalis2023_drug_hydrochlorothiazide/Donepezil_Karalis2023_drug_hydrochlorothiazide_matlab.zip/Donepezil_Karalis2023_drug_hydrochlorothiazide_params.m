function p = Donepezil_Karalis2023_drug_hydrochlorothiazide_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Karalis_2023 / drug_hydrochlorothiazide   route: oral
  p.name  = 'Donepezil_Karalis2023_drug_hydrochlorothiazide_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2700.0;                % central volume [L]
  p.CL = 34.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7728;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
