function p = Donepezil_Karalis2023_drug_donepezil_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Karalis_2023 / drug_donepezil   route: oral
  p.name  = 'Donepezil_Karalis2023_drug_donepezil_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2700.0;                % central volume [L]
  p.CL = 8.5998;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3002;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
