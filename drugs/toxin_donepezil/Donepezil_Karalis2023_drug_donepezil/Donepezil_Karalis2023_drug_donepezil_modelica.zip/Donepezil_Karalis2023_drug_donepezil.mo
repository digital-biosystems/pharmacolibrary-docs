model Donepezil_Karalis2023_drug_donepezil
  parameter Real Cl_ref = 2.3888333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.7 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3795,
    adminMass = 1e-06,
    ka = 0.00036116666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>donepezil</td></tr><tr><td>population:</td><td>drug / donepezil</td></tr><tr><td>source_paper:</td><td>Karalis_2023</td></tr><tr><td>measured_compound:</td><td>Donepezil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-16-00725-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>donepezil 379.5 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Donepezil</li><li>population split: 'drug / donepezil' subgroup of Karalis_2023 (paper reports 3 populations: drug / amlodipine, drug / donepezil, drug / hydrochlorothiazide)</li><li>gap-filled Q76 (V/F) from Khwarg_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Khwarg_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Donepezil_Karalis2023_drug_donepezil;
