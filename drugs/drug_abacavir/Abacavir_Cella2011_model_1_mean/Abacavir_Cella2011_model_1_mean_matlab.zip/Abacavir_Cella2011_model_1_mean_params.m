function p = Abacavir_Cella2011_model_1_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: Cella_2011 / model_1_mean   route: oral
  p.name  = 'Abacavir_Cella2011_model_1_mean_params';
  p.drug  = 'abacavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 69.1;                % central volume [L]
  p.CL = 40.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.58;                % absorption rate [1/h]
  p.F  = 0.83;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
