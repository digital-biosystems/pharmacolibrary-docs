function p = Abacavir_van2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: van_2021 / reference   route: oral
  p.name  = 'Abacavir_van2021_reference_params';
  p.drug  = 'abacavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.7;                % central volume [L]
  p.CL = 10.8;                % clearance [L/h]
  p.Vp = [12.0];             % peripheral volumes [L]
  p.Q  = [0.048];             % inter-compartmental clearances [L/h]
  p.ka = 1.07;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
