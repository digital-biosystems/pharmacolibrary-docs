model Abacavir_Fauchet2014_reference
  parameter Real Cl_ref = 1.1472222222222221e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11900000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2863323,
    adminMass = 0.0006,
    ka = 0.0001277777777777778,
    Tlag = 1656.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About abacavir</h4><p>Abacavir is an antiviral medicine used to treat HIV infection and HIV/AIDS. It is widely used, appears on the WHO essential medicines list, and is authorised in the European Union, typically in combination products for HIV treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304330\">Wikidata Q304330</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>abacavir</td></tr><tr><td>population:</td><td>HIV-infected pregnant and nonpregnant women</td></tr><tr><td>source_paper:</td><td>Fauchet_2014</td></tr><tr><td>measured_compound:</td><td>abacavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>abacavir 286.332 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'liter • h Ϫ1' (CL/F)</li><li>unit_dimension_mismatch: 'CL/F' → Q27 (unit '1 / [time]' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('CL/F', value '0.167') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ABC' — extend the ontology if this is a real PK parameter (source ['tab_0:row5:col1', 'tab_0:row5:col2', 'tab_0:row5:col3'])</li><li>implicit units: 'CL/F (liter • h Ϫ1 )' → L/h (from the paper text: &quot;The prompt text for parameter 1 explicitly includes the unit in parentheses immediately following the symbol: 'CL/F (lit&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=abacavir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chupradit_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chupradit_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Abacavir_Fauchet2014_reference;
