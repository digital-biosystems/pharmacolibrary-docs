function p = Abacavir_Rabie2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: Rabie_2020 / reference   route: oral
  p.name  = 'Abacavir_Rabie2020_reference_params';
  p.drug  = 'abacavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.76;                % central volume [L]
  p.CL = 9.67;                % clearance [L/h]
  p.Vp = [3.32];             % peripheral volumes [L]
  p.Q  = [1.35];             % inter-compartmental clearances [L/h]
  p.ka = 2.22;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 560.0;             % dose [mg]
end
