model Abacavir_Chupradit2023_reference
  parameter Real Cl_ref = 3.225667527993109e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03906976744186047 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2863323,
    adminMass = 6e-05,
    ka = 0.00010277777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About abacavir</h4><p>Abacavir is an antiviral medicine used to treat HIV infection and HIV/AIDS. It is widely used, appears on the WHO essential medicines list, and is authorised in the European Union, typically in combination products for HIV treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304330\">Wikidata Q304330</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>abacavir</td></tr><tr><td>population:</td><td>African children with HIV weighing <14 kg</td></tr><tr><td>source_paper:</td><td>Chupradit_2023</td></tr><tr><td>measured_compound:</td><td>abacavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>abacavir 286.332 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional (%)' routed out of structural estimates ('Residual variability')</li><li>unit_dimension_unknown: 'L/h/12.9kg' (CL/F)</li><li>unit_dimension_unknown: 'L/12.9kg' (V/F)</li><li>dropped PD-category row 'HILL' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row6:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=abacavir</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Abacavir_Chupradit2023_reference;
