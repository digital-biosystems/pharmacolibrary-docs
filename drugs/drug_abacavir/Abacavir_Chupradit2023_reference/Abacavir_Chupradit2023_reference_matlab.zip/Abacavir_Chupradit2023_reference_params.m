function p = Abacavir_Chupradit2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: Chupradit_2023 / reference   route: oral
  p.name  = 'Abacavir_Chupradit2023_reference_params';
  p.drug  = 'abacavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 39.069767;                % central volume [L]
  p.CL = 116.124031;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.37;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
