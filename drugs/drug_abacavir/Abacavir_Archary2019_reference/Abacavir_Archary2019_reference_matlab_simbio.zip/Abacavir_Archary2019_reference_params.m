function p = Abacavir_Archary2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: Archary_2019 / reference   route: oral
  p.name  = 'Abacavir_Archary2019_reference_params';
  p.drug  = 'abacavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.3;                % central volume [L]
  p.CL = 33.3;                % clearance [L/h]
  p.Vp = [1.65];             % peripheral volumes [L]
  p.Q  = [0.63];             % inter-compartmental clearances [L/h]
  p.ka = 0.97;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
