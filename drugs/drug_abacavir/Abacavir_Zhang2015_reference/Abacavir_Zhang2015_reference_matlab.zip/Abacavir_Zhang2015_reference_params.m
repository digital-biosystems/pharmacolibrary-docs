function p = Abacavir_Zhang2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: Zhang_2015 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Abacavir_Zhang2015_reference_params';
  p.drug  = 'abacavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.4;                % central volume [L]
  p.CL = 0.901;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.24;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.263;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
