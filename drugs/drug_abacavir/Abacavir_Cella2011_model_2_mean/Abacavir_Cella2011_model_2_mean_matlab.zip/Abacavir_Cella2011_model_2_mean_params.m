function p = Abacavir_Cella2011_model_2_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abacavir   source: Cella_2011 / model_2_mean   route: oral
  p.name  = 'Abacavir_Cella2011_model_2_mean_params';
  p.drug  = 'abacavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.94;                % central volume [L]
  p.CL = 13.4;                % clearance [L/h]
  p.Vp = [8.12];             % peripheral volumes [L]
  p.Q  = [1.25];             % inter-compartmental clearances [L/h]
  p.ka = 0.758;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
