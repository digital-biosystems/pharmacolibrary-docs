model Ranitidine_Hawwa2013_reference
  parameter Real Cl_ref = 8.916666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28500000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 27.5,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0003638888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ranitidine</td></tr><tr><td>population:</td><td>critically ill children</td></tr><tr><td>source_paper:</td><td>Hawwa_2013</td></tr><tr><td>measured_compound:</td><td>ranitidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'factor' (CL)</li><li>dropped duplicate Q22 ('clearance', value 0.46) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ranitidine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ranitidine_Hawwa2013_reference;
