function p = Ranitidine_Hawwa2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ranitidine   source: Hawwa_2013 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Ranitidine_Hawwa2013_reference_params';
  p.drug  = 'ranitidine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 285.0;                % central volume [L]
  p.CL = 32.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.31;                % absorption rate [1/h]
  p.F  = 27.5;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
