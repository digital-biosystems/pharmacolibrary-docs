// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Dexfenfluramine_Cheymol1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.9697000000000001},
    CLelim = {1.2194444444444445e-05},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexfenfluramine</td></tr><tr><td>population:</td><td>obese and non-obese healthy volunteers</td></tr><tr><td>source_paper:</td><td>Cheymol_1995</td></tr><tr><td>measured_compound:</td><td>Dexfenfluramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>Dexfenfluramine 231.261 g/mol (pubchem); Dexnorfenfluramine 203.207 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'aged' — extend the ontology if this is a real PK parameter (source ['Cheymol_1995:abstract'])</li><li>dropped unlinked row (NIL): 'infused over' — extend the ontology if this is a real PK parameter (source ['Cheymol_1995:abstract'])</li><li>relinked 't1/2,z' Q47 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('t1/2,z', value 16.5) — already have one for this compound</li><li>covariate category for AUC ratio from footnote/prose kept as documentation only (['Cheymol_1995:abstract', 'Cheymol_1995:abstract', 'Cheymol_1995:abstract', 'Cheymol_1995:abstract'])</li><li>implicit units: 'tmax' → h (from the popPK convention: 'No unit provided in text. tmax is a time-to-peak concentration parameter. The value 3.5 is consistent with hours (h) in ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dexfenfluramine</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 9/9 row label(s) assigned, 8 linked by role; re-tagged Dexfenfluramine→parent ×12</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Dexfenfluramine_Cheymol1995_reference;
