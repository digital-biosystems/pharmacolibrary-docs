% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Dexfenfluramine_Cheymol1995_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
