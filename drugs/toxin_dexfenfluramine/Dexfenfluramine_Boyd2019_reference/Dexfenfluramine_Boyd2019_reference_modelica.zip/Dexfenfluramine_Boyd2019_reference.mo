// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Dexfenfluramine_Boyd2019_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {84600.00000000001},
    MM = 0.231261,
    adminMass = 5.6e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexfenfluramine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Boyd_2019</td></tr><tr><td>measured_compound:</td><td>Fenfluramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Fenfluramine 231.261 g/mol (pubchem); Norclobazam 286.715 g/mol (pubchem); Norfenfluramine 203.207 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>compound tags: 6 row(s) → Norclobazam (name 6)</li><li>unit_dimension_unknown: 'ng×h/mL' (AUCt)</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 0.8 (source ['Table3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 3 (source ['Table3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 20 (source ['Table3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 25 (source ['Table3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Cmax' from footnote/prose loose number 1 (source ['Table3:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q57 ('terminal half-life'=23.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fenfluramine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles: per-genotype parameters — typical value from the reference group: tmax (h)b, AUC0-t (ng×h/mL)</li><li>row roles: 4 row(s) kept on the molecule their table section names, against the LLM's assignment</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Dexfenfluramine_Boyd2019_reference;
