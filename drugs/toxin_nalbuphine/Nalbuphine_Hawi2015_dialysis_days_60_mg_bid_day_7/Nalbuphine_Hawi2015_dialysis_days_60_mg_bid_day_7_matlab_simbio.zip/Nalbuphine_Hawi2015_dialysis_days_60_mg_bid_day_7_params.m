function p = Nalbuphine_Hawi2015_dialysis_days_60_mg_bid_day_7_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Hawi_2015 / dialysis_days_60_mg_bid_day_7   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Nalbuphine_Hawi2015_dialysis_days_60_mg_bid_day_7_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 137.69;                % central volume [L]
  p.CL = 33.42;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.81;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
