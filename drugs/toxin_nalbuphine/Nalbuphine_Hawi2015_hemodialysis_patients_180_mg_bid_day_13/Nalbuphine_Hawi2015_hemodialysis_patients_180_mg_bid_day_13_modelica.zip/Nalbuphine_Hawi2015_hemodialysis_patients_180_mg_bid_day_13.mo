// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Nalbuphine_Hawi2015_hemodialysis_patients_180_mg_bid_day_13
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {14400.0},
    MM = 0.35745,
    adminMass = 8e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>hemodialysis patients with uremic pruritus and matched healthy subjects</td></tr><tr><td>source_paper:</td><td>Hawi_2015</td></tr><tr><td>measured_compound:</td><td>nalbuphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.45 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nalbuphine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'hemodialysis patients 180 mg bid day 13' subgroup of Hawi_2015 (paper reports 15 populations: days corresponding to cohort 1 dialysis days, days corresponding to cohort 1 non-dialysis days, dialysis days 120 mg bid day 10, dialysis days 180 mg bid day 12, dialysis days 240 mg bid day 14, dialysis days 30 mg bid day 3, dialysis days 60 mg bid day 7, geometric means, hemodialysis patients 180 mg bid day 13, hemodialysis patients 30 mg qd day 1, non-dialysis days 120 mg bid day 9, non-dialysis days 180 mg bid day 13, non-dialysis days 240 mg bid day 15, non-dialysis days 30 mg bid day 4, non-dialysis days 60 mg bid day 6)</li><li>gap-filled Q22 (CL) from Nie_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Nie_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Pfiffner_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Nalbuphine_Hawi2015_hemodialysis_patients_180_mg_bid_day_13;
