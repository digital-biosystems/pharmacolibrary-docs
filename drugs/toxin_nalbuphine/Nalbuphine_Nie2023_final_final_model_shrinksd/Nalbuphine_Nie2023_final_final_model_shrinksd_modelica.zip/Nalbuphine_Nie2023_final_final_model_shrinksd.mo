model Nalbuphine_Nie2023_final_final_model_shrinksd
  parameter Real Cl_ref = 9.13888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0325 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35745,
    adminMass = 0.0001,
    ka = 0.00022500000000000002,
    Tlag = 0.0,
    k12 = 0.0020940170940170937,
    k21 = 0.0008150365934797071
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>adult patients undergoing general anesthesia surgery</td></tr><tr><td>source_paper:</td><td>Nie_2023</td></tr><tr><td>measured_compound:</td><td>Nalbuphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_3C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.45 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k13, k31.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (%CV)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωV1 (%CV)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωQ (%CV)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωV2 (%CV)' routed out of structural estimates ('Between-subject variability')</li><li>salvaged Q22 ('CL'=32.9) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V1'=32.5) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q'=245) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2'=83.5) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd'=137.69) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nalbuphine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 3C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>model-stage split: 'final model / shrinksd (%)' is the final model of Nie_2023 (paper reports 3 stages: estimates, final model / estimates, final model / shrinksd (%)); same population, different model-building step</li><li>gap-filled Q49 (kabs) from Pfiffner_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nalbuphine_Nie2023_final_final_model_shrinksd;
