% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Nalbuphine_Hawi2015_non_dialysis_days_30_mg_bid_day_4_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
