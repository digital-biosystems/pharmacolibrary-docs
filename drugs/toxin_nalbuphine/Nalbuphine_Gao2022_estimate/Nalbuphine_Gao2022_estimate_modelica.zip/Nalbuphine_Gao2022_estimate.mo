model Nalbuphine_Gao2022_estimate
  parameter Real Cl_ref = 9.283333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13769 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35745,
    adminMass = 1.5e-05,
    ka = 0.00022500000000000002,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>surgical patients undergoing general anesthesia with varying degrees of liver dysfunction</td></tr><tr><td>source_paper:</td><td>Gao_2022</td></tr><tr><td>measured_compound:</td><td>Nalbuphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0007</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.45 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Intercept'; source reconciliation required</li><li>table representations disagree for 'Weight'; source reconciliation required</li><li>table representations disagree for 'ALT'; source reconciliation required</li><li>table representations disagree for 'ALP'; source reconciliation required</li><li>table representations disagree for 'PLT'; source reconciliation required</li><li>table representations disagree for 'Intercept'; source reconciliation required</li><li>table representations disagree for 'Weight'; source reconciliation required</li><li>table representations disagree for 'PLT'; source reconciliation required</li><li>table representations disagree for 'T1/2'; source reconciliation required</li><li>table representations disagree for 'Intercept'; source reconciliation required</li><li>table representations disagree for 'Age'; source reconciliation required</li><li>table representations disagree for 'TBIL'; source reconciliation required</li><li>table representations disagree for 'ALB'; source reconciliation required</li><li>table representations disagree for 'Intercept'; source reconciliation required</li><li>table representations disagree for 'ALT'; source reconciliation required</li><li>table representations disagree for 'TBIL'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nalbuphine_Gao2022_estimate;
