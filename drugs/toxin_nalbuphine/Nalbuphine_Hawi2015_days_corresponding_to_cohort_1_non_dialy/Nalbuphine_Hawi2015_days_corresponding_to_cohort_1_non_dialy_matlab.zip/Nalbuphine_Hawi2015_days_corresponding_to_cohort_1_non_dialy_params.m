function p = Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_non_dialy_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Hawi_2015 / days_corresponding_to_cohort_1_non_dialysis_days   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_non_dialy_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 315.5;                % central volume [L]
  p.CL = 33.42;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.81;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
