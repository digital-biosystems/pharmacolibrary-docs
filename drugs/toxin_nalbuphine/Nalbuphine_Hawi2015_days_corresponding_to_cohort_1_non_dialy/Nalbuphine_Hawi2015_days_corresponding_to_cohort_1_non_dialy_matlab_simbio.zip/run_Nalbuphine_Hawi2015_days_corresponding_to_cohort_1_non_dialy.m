% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_non_dialy_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
