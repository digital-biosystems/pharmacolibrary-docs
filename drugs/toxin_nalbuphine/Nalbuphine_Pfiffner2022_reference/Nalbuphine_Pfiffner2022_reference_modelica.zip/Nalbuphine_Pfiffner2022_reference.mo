model Nalbuphine_Pfiffner2022_reference
  parameter Real Cl_ref = 9.283333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13769 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.41,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35745,
    adminMass = 0.0001,
    ka = 0.00022500000000000002,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>infants 1-3 months old undergoing painful procedures</td></tr><tr><td>source_paper:</td><td>Pfiffner_2022</td></tr><tr><td>measured_compound:</td><td>Nalbuphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.45 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'Res. Error' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>covariate effect for Q22 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q63 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q30 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nalbuphine</li><li>gap-filled Q22 (CL) from Nie_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Nie_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Nie_2023 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nalbuphine_Pfiffner2022_reference;
