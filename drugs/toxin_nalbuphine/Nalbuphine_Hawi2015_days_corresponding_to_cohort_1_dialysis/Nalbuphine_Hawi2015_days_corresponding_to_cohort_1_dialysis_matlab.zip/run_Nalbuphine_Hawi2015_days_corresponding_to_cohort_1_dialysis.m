% Run: build params, simulate 0..72.0 h, plot + save Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.m
here = fileparts(mfilename('fullpath'));
p = Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis_params();
out = simulate_pk(p, 0:0.05:72.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('nalbuphine — Hawi_2015 (oral)');
print(fig, fullfile(here, 'Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.json'), 'w');
try
  s.model = 'Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.png, Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.csv, Nalbuphine_Hawi2015_days_corresponding_to_cohort_1_dialysis.json\n');
