model Nalbuphine_Hawi2015_dialysis_days_180_mg_bid_day_12
  parameter Real Cl_ref = 9.283333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13769 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35745,
    adminMass = 0.0001,
    ka = 0.00022500000000000002,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>hemodialysis patients with uremic pruritus and matched healthy subjects</td></tr><tr><td>source_paper:</td><td>Hawi_2015</td></tr><tr><td>measured_compound:</td><td>nalbuphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.45 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '%Arem' — extend the ontology if this is a real PK parameter (source ['Hawi_2015_table_2:row16:col10', 'Hawi_2015_table_2:row17:col10', 'Hawi_2015_table_2:row18:col10', 'Hawi_2015_table_2:row19:col10'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nalbuphine</li><li>population split: 'dialysis days 180 mg bid day 12' subgroup of Hawi_2015 (paper reports 15 populations: days corresponding to cohort 1 dialysis days, days corresponding to cohort 1 non-dialysis days, dialysis days 120 mg bid day 10, dialysis days 180 mg bid day 12, dialysis days 240 mg bid day 14, dialysis days 30 mg bid day 3, dialysis days 60 mg bid day 7, geometric means, hemodialysis patients 180 mg bid day 13, hemodialysis patients 30 mg qd day 1, non-dialysis days 120 mg bid day 9, non-dialysis days 180 mg bid day 13, non-dialysis days 240 mg bid day 15, non-dialysis days 30 mg bid day 4, non-dialysis days 60 mg bid day 6)</li><li>gap-filled Q22 (CL) from Nie_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Nie_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Pfiffner_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Nie_2023, Pfiffner_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nalbuphine_Hawi2015_dialysis_days_180_mg_bid_day_12;
