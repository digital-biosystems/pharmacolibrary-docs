% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Nalbuphine_Hawi2015_dialysis_days_180_mg_bid_day_12_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
