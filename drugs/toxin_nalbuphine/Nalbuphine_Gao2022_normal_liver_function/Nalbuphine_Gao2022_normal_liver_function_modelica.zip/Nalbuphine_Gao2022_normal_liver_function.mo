model Nalbuphine_Gao2022_normal_liver_function
  parameter Real Cl_ref = 7.611111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10008 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35745,
    adminMass = 1.5e-05,
    ka = 0.00022500000000000002,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>surgical patients undergoing general anesthesia with varying degrees of liver dysfunction</td></tr><tr><td>source_paper:</td><td>Gao_2022</td></tr><tr><td>measured_compound:</td><td>Nalbuphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0007</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.45 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q88 ('AUC(0→∞)', value '509.12') — already have one for this compound</li><li>dropped duplicate Q53 ('MRT(0→∞)', value '3.41') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nalbuphine</li><li>population split: 'normal liver function (n=13)' subgroup of Gao_2022 (paper reports 6 populations: estimate, mild liver dysfunction (n=5), moderate/severe liver dysfunction (n=6), normal liver function (n=13), t value, total (n=24))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Pfiffner_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nalbuphine_Gao2022_normal_liver_function;
