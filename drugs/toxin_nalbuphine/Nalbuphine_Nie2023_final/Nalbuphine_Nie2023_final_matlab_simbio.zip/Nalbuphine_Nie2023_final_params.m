function p = Nalbuphine_Nie2023_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Nie_2023 / final   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Nalbuphine_Nie2023_final_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.5;                % central volume [L]
  p.CL = 32.9;                % clearance [L/h]
  p.Vp = [83.5];             % peripheral volumes [L]
  p.Q  = [245.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.81;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
