function p = Nalbuphine_Gao2022_total_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Gao_2022 / total   route: oral
  % estimated (absent from source): F
  p.name  = 'Nalbuphine_Gao2022_total_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 137.69;                % central volume [L]
  p.CL = 33.42;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.81;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
