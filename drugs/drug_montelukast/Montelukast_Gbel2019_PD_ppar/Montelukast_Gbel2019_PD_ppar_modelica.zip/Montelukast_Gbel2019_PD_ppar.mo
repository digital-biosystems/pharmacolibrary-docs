model Montelukast_Gbel2019_PD_ppar
  "sigmoid_emax exposure-response sweep — Göbel_2019 :: PPARγ (PPARγ activity (reporter gene assay))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.219,  // [1; % × 0.01]
    EC50 = 1.17,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About montelukast</h4><p>Montelukast is a leukotriene receptor antagonist used to treat asthma and allergic rhinitis, and also rhinitis and urticaria. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417767\">Wikidata Q417767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Montelukast_Gbel2019_PD_ppar</h4><p>The steady-state exposure-response curve of Göbel T et al., <i>Frontiers in pharmacology 10:263</i> 2019 (<a href=\"https://doi.org/10.3389/fphar.2019.00263\">doi:10.3389/fphar.2019.00263</a>) — PPARγ activity (reporter gene assay) [%] against montelukast μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       21.9 %        maximal effect term (max. activation, Q320)
  EC50  =       1.17 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of montelukast per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.17 μM)  response 0.1095
  exposure -> infinity  response 0.219</pre></body></html>"));
end Montelukast_Gbel2019_PD_ppar;
