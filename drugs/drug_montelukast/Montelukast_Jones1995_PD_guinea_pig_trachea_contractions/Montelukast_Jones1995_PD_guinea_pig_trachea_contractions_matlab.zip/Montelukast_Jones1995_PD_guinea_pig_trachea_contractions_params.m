function p = Montelukast_Jones1995_PD_guinea_pig_trachea_contractions_params()
% Montelukast_Jones1995_PD_guinea_pig_trachea_contractions_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% montelukast Jones_1995::Guinea_pig_trachea_contractions: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response Guinea pig trachea contractions in its own unit. Driver: montelukast (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.8;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
