model Montelukast_Jones1995_PD_guinea_pig_trachea_contractions
  "linear exposure-response sweep — Jones_1995 :: Guinea pig trachea contractions (contractions of guinea pig trachea induced by leukotriene D4)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.8   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is unknown; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About montelukast</h4><p>Montelukast is a leukotriene receptor antagonist used to treat asthma and allergic rhinitis, and also rhinitis and urticaria. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417767\">Wikidata Q417767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Montelukast_Jones1995_PD_guinea_pig_trachea_contractions</h4><p>The steady-state exposure-response curve of Jones TR et al., <i>Canadian journal of physiology and pharmacology 73(2):191–201</i> 1995 (<a href=\"https://doi.org/10.1139/y95-028\">doi:10.1139/y95-028</a>) — contractions of guinea pig trachea induced by leukotriene D4 against montelukast — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        0.8          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of montelukast per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Montelukast_Jones1995_PD_guinea_pig_trachea_contractions;
