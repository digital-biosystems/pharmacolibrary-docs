model Montelukast_Durdagi2022_PD_mpro_activity
  "sigmoid_emax exposure-response sweep — Durdagi_2022 :: Mpro activity (3CL Protease activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.7404,  // [1; % × 0.01]
    EC50 = 28.36,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 290, Interval = 0.58),
    Documentation(info = "<html><body><!-- drug-about --><h4>About montelukast</h4><p>Montelukast is a leukotriene receptor antagonist used to treat asthma and allergic rhinitis, and also rhinitis and urticaria. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417767\">Wikidata Q417767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Montelukast_Durdagi2022_PD_mpro_activity</h4><p>The steady-state exposure-response curve of Durdagi S et al., <i>Molecular therapy : the journal of the American Society of Gene Therapy 30(2):963–974</i> 2022 (<a href=\"https://doi.org/10.1016/j.ymthe.2021.10.014\">doi:10.1016/j.ymthe.2021.10.014</a>) — 3CL Protease activity [%] against montelukast μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      74.04 %        maximal effect term (Imax, Q323)
  EC50  =      28.36 μM       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of montelukast per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (28.36 μM)  response -0.3702
  exposure -> infinity  response -0.7404</pre></body></html>"));
end Montelukast_Durdagi2022_PD_mpro_activity;
