function p = Montelukast_Durdagi2022_PD_mpro_activity_params()
% Montelukast_Durdagi2022_PD_mpro_activity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% montelukast Durdagi_2022::Mpro_activity: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response Mpro activity in %. Driver: montelukast (cited_pk).
p.E0 = 0.0;
p.Emax = -0.7404000000000001;
p.EC50 = 28.36;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 290.0;
p.form = 'E0 + Emax*frac';
end
