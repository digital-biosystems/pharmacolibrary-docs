model Montelukast_Zhu2024_reference
  parameter Real Cl_ref = 4.1388888888888884e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.57 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.586183,
    adminMass = 1e-05,
    ka = 9.916666666666666e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About montelukast</h4><p>Montelukast is a leukotriene receptor antagonist used to treat asthma and allergic rhinitis, and also rhinitis and urticaria. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417767\">Wikidata Q417767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>montelukast</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhu_2024</td></tr><tr><td>measured_compound:</td><td>montelukast</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>montelukast 586.183 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhu_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Montelukast_Zhu2024_reference;
