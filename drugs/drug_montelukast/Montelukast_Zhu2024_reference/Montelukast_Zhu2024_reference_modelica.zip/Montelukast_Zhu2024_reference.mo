model Montelukast_Zhu2024_reference
  parameter Real Cl_ref = 4.1388888888888884e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.57 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.916666666666666e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>montelukast</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhu_2024</td></tr><tr><td>measured_compound:</td><td>montelukast</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhu_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Montelukast_Zhu2024_reference;
