function p = Montelukast_Ramakrishnan2005_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: montelukast   source: Ramakrishnan_2005 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Montelukast_Ramakrishnan2005_reference_params';
  p.drug  = 'montelukast';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.2;                % central volume [L]
  p.CL = 2.58;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.357;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.5;             % dose [mg]
end
