model Montelukast_Ramakrishnan2005_reference
  parameter Real Cl_ref = 7.166666666666665e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008199999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.586183,
    adminMass = 3.5e-06,
    ka = 9.916666666666666e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About montelukast</h4><p>Montelukast is a leukotriene receptor antagonist used to treat asthma and allergic rhinitis, and also rhinitis and urticaria. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417767\">Wikidata Q417767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>montelukast</td></tr><tr><td>population:</td><td>adults and children aged 6 to 14 years</td></tr><tr><td>source_paper:</td><td>Ramakrishnan_2005</td></tr><tr><td>measured_compound:</td><td>montelukast</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>montelukast 586.183 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('steady-state volume of distribution in a 70-kg adult'=8.2) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance in a 70-kg adult'=43) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=montelukast</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Zhu_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Montelukast_Ramakrishnan2005_reference;
