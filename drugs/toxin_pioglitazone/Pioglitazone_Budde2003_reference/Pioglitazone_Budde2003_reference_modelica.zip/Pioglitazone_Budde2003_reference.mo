model Pioglitazone_Budde2003_reference
  parameter Real Cl_ref = 1.3333333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0192 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35644,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pioglitazone</td></tr><tr><td>population:</td><td>patients with impaired renal function and healthy subjects with normal renal function</td></tr><tr><td>source_paper:</td><td>Budde_2003</td></tr><tr><td>measured_compound:</td><td>Pioglitazone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Pioglitazone 356.44 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pioglitazone</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=other; 1/1 row label(s) assigned, 0 linked by role</li><li>molar mass: no plausible PubChem entry for 'M-IV' ('Pioglitazone metabolite M-IV') — left in mass units</li><li>molar mass: none of 2 PubChem candidate(s) is 'M-III' (LLM) — left in mass units</li><li>molar mass: none found for 'M-III' — its concentrations stay mass-only</li><li>molar mass: none found for 'M-IV' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Thompson_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Thompson_2016 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pioglitazone_Budde2003_reference;
