function p = Dihydroergotamine_Albrecht2020_migranal_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dihydroergotamine   source: Albrecht_2020 / migranal   route: oral
  % estimated (absent from source): ka
  p.name  = 'Dihydroergotamine_Albrecht2020_migranal_params';
  p.drug  = 'dihydroergotamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8393.0;                % central volume [L]
  p.CL = 478.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
