model Dihydroergotamine_Albrecht2020_migranal
  parameter Real Cl_ref = 0.00013277777777777778 "Cl [m3/s]";
  parameter Real Vd_ref = 8.393 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.583689,
    adminMass = 1e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dihydroergotamine</td></tr><tr><td>population:</td><td>Healthy Adult Subjects</td></tr><tr><td>source_paper:</td><td>Albrecht_2020</td></tr><tr><td>measured_compound:</td><td>Dihydroergotamine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>head13737-tbl-0004</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>8'-OH-DHE 599.688 g/mol (pubchem); Dihydroergotamine 583.689 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'Cmax, CV (%)' → Q32 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q32 ('Cmax, CV (%)', value '76') — already have one for this compound</li><li>unit_dimension_mismatch: 'AUC0-2 h, CV (%)' → Q88 (unit 'dimensionless' vs ontology '[mass] * [time] / [length] ** 3') — route to review</li><li>dropped duplicate Q88 ('AUC0-2 h, CV (%)', value '75') — already have one for this compound</li><li>dropped duplicate Q74 ('AUC0-last, h × pg/mL', value '5973') — already have one for this compound</li><li>unit_dimension_mismatch: 'AUC0-inf, CV (%)' → Q17 (unit 'dimensionless' vs ontology '[mass] * [time] / [length] ** 3') — route to review</li><li>dropped duplicate Q17 ('AUC0-inf, CV (%)', value '55') — already have one for this compound</li><li>implicit units: 'AUC0-30 min' → h × pg/mL (from the paper text: &quot;In the Results section describing Part 1 data, the text states: 'Mean AUC0-2 h was 956, 1683, and 2549 h × pg/mL...'. Ad&quot;)</li><li>implicit units: 'AUC0-2 h' → h × pg/mL (from the paper text: &quot;The Results section for Part 2 explicitly states: 'The mean AUC0-2 h was 2979, 4791 and 1316 h × pg/mL...'. The value 13&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Dihydroergotamine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'migranal (n = 26)' subgroup of Albrecht_2020 (paper reports 7 populations: im dhe (n = 26), mean ± standard deviation / im dhe (n = 26), mean ± standard deviation / migranal (n = 26), mean ± standard deviation / sts101 5.2 mg (n = 27), migranal (n = 26), ratio of geometric means (%), sts101 5.2 mg (n = 27))</li><li>row roles (LLM): model_class=noncompartmental; 19/19 row label(s) assigned, 0 linked by role; re-tagged parent→8'-OH-DHE ×21</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Dihydroergotamine_Albrecht2020_migranal;
