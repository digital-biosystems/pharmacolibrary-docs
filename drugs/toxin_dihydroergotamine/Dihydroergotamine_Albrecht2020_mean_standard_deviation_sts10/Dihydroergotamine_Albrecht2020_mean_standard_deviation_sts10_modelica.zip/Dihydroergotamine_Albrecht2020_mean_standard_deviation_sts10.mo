// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Dihydroergotamine_Albrecht2020_mean_standard_deviation_sts10
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {68400.0},
    MM = 0.583689,
    adminMass = 1e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dihydroergotamine</td></tr><tr><td>population:</td><td>Healthy Adult Subjects</td></tr><tr><td>source_paper:</td><td>Albrecht_2020</td></tr><tr><td>measured_compound:</td><td>Dihydroergotamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>head13737-tbl-0004</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Dihydroergotamine 583.689 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'C max CV (%)' → Q32 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q32 ('C max CV (%)', value '45') — already have one for this compound</li><li>unit_dimension_unknown: 'median [min, max]' (tmax)</li><li>implicit units: 'T max, h (median [min, max])' → h (from the popPK convention: 'No explicit unit is stated in the text for Tmax in the context of the specific value 2.00. The text mentions Tmax in min')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dihydroergotamine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'mean ± standard deviation / sts101 5.2 mg (n = 27)' subgroup of Albrecht_2020 (paper reports 7 populations: im dhe (n = 26), mean ± standard deviation / im dhe (n = 26), mean ± standard deviation / migranal (n = 26), mean ± standard deviation / sts101 5.2 mg (n = 27), migranal (n = 26), ratio of geometric means (%), sts101 5.2 mg (n = 27))</li><li>row roles (LLM): model_class=noncompartmental; 19/19 row label(s) assigned, 0 linked by role; re-tagged parent→8'-OH-DHE ×21</li><li>molar mass: no plausible PubChem entry for &quot;8'-OH-DHE&quot; ('no full name in the paper') — left in mass units</li><li>molar mass: none found for &quot;8'-OH-DHE&quot; — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Dihydroergotamine_Albrecht2020_mean_standard_deviation_sts10;
