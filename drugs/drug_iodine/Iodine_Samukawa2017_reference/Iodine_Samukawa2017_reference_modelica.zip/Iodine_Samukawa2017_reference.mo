model Iodine_Samukawa2017_reference
  parameter Real Cl_ref = 7.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2538089,
    adminMass = 0.0001,
    ka = 0.0056388888888888895,
    Tlag = 626.4,
    k12 = 4.857819905213271e-05,
    k21 = 5.423280423280424e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iodine</h4><p>Iodine is used as a topical antiseptic and disinfectant for the skin. It is an approved drug, widely available for skin antisepsis, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2064483\">Wikidata Q2064483</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iodine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Samukawa_2017</td></tr><tr><td>measured_compound:</td><td>iodine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>iodine 253.809 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Samukawa_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Iodine_Samukawa2017_reference;
