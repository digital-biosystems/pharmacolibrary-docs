function p = Iodine_Samukawa2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iodine   source: Samukawa_2017 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Iodine_Samukawa2017_reference_params';
  p.drug  = 'iodine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.1;                % central volume [L]
  p.CL = 2.78;                % clearance [L/h]
  p.Vp = [18.9];             % peripheral volumes [L]
  p.Q  = [3.69];             % inter-compartmental clearances [L/h]
  p.ka = 20.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.174;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
