function p = Cefoperazone_Soback1989_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefoperazone   source: Soback_1989 / reference   route: iv_bolus
  p.name  = 'Cefoperazone_Soback1989_reference_params';
  p.drug  = 'cefoperazone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.9;                % central volume [L]
  p.CL = 8.16;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.763;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4000.0;             % dose [mg]
end
