function p = Cefoperazone_Zhou2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefoperazone   source: Zhou_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefoperazone_Zhou2022_reference_params';
  p.drug  = 'cefoperazone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.97;                % central volume [L]
  p.CL = 4.45;                % clearance [L/h]
  p.Vp = [9.03];             % peripheral volumes [L]
  p.Q  = [12.03];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
