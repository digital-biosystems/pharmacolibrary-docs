// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Iron_Landschulz1985_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0036200000000000004},
    CLelim = {1.325e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>iron</td></tr><tr><td>population:</td><td>kidney tubules (in vitro/proliferation study)</td></tr><tr><td>source_paper:</td><td>Landschulz_1985</td></tr><tr><td>measured_compound:</td><td>Iron</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>iron 55.845 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'The octanol/saline partition coefficients of radioactive iron in solution with transferrin, nitrilotriacetic acid, or chloride' — extend the ontology if this is a real PK parameter (source ['Landschulz_1985:abstract'])</li><li>unit_dimension_unknown: 'null' (Kp)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Iron</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 1 first-order transfer(s) across 3 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Zhang_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Zhang_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Wang_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Wang_2026, Zhang_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Iron_Landschulz1985_reference;
