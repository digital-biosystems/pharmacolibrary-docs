model Iron_Cao2025v2_PD_rbc
  "indirect_response_iii exposure-response sweep — Cao_2025_2 :: RBC (RBC)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 7.141,      // [×1012 cells/L]
    Emax = 12.63,  // type III effect term
    EC50 = 3.14e-05,  // [kg/m3; μg/dL × 1e-05]
    gamma = 1,
    exposure_per_s = 1e-05);   // 1 μg/dL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 32, Interval = 0.064),
    Documentation(info = "<html><body><h4>Iron_Cao2025v2_PD_rbc</h4><p>The steady-state exposure-response curve of Cao K et al., <i>ACS pharmacology &amp; translational science 8(6):1711-1725</i> 2025 (<a href=\"https://doi.org/10.1021/acsptsci.5c00097\">doi:10.1021/acsptsci.5c00097</a>) — RBC [×1012 cells/L] against iron μg/dL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      7.141 ×1012 cells/L drug-free response (baseline) (RBC0, Q324)
  Emax  =      12.63          maximal effect term (SmaxIron, Q320)
  EC50  =       3.14 μg/dL    exposure at half of the maximal effect term (SC50Iron, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/dL of iron per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.141   (drug-free)
  exposure = EC50 (3.14 μg/dL)  response 52.24
  exposure -> infinity  response 97.33</pre></body></html>"));
end Iron_Cao2025v2_PD_rbc;
