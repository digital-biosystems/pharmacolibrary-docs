function p = Iron_Cao2025v2_PD_rbc_params()
% Iron_Cao2025v2_PD_rbc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% iron Cao_2025_2::RBC: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/dL per second, in SI inside (kg/m3, s). Response RBC in ×1012 cells/L. Driver: iron (cited_pk).
p.E0 = 7.141;
p.Emax = 12.63;
p.EC50 = 3.14e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-05;
p.stop_time = 32.0;
p.form = 'E0*(1 + Emax*frac)';
end
