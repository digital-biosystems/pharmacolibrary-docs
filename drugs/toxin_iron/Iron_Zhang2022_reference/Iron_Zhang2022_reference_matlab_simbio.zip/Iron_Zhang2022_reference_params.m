function p = Iron_Zhang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iron   source: Zhang_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Iron_Zhang2022_reference_params';
  p.drug  = 'iron';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.32;                % central volume [L]
  p.CL = 0.982;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.458333;             % absorption lag [h]
  p.dose = 0.15;             % dose [mg]
end
