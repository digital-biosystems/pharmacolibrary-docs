model Iron_Zhang2022_reference
  parameter Real Cl_ref = 2.727777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00332 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.055845,
    adminMass = 1.5e-07,
    ka = 0.0001388888888888889,
    Tlag = 1650.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>iron</td></tr><tr><td>population:</td><td>healthy subjects and patients with hemodialysis-dependent stage 5 chronic kidney disease (CKD-5HD)</td></tr><tr><td>source_paper:</td><td>Zhang_2022</td></tr><tr><td>measured_compound:</td><td>iron</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ferric pyrophosphate citrate 1321.57 g/mol (pubchem); iron 55.845 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω1 (CL, %)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 (Vd, %)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ (add), ng/ml' routed out of structural estimates ('Residual error')</li><li>table section iiv: 'ω1 (CL, %)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 (Vd, %)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ1 (prop), %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ2 (add), ng/ml' routed out of structural estimates ('Residual error')</li><li>table section iiv: 'ω1 (CL, %)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 (Vd, %)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ1 (prop), %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ2 (add), ng/ml' routed out of structural estimates ('Residual error')</li><li>table representations disagree for 'CL, L/h'; source reconciliation required</li><li>table representations disagree for 'Vd, L'; source reconciliation required</li><li>table representations disagree for 'LBM on Vd'; source reconciliation required</li><li>table representations disagree for 'Fe.av on Vd (× 10−4)'; source reconciliation required</li><li>table representations disagree for 'θsex on Vd'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iron_Zhang2022_reference;
