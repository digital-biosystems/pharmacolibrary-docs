function p = Iron_Cao2025v2_PD_hgb_params()
% Iron_Cao2025v2_PD_hgb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% iron Cao_2025_2::HGB: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/dL per second, in SI inside (kg/m3, s). Response HGB in g/dL. Driver: iron (cited_pk).
p.E0 = 89.89999999999999;
p.Emax = 0.72;
p.EC50 = 0.00016239999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-05;
p.stop_time = 170.0;
p.form = 'E0*(1 + Emax*frac)';
end
