model Iron_Cao2025v2_PD_hgb
  "indirect_response_iii exposure-response sweep — Cao_2025_2 :: HGB (HGB)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 89.9,      // [kg/m3; g/dL × 10]
    Emax = 0.72,  // type III effect term
    EC50 = 0.0001624,  // [kg/m3; μg/dL × 1e-05]
    gamma = 1,
    exposure_per_s = 1e-05);   // 1 μg/dL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 170, Interval = 0.34),
    Documentation(info = "<html><body><h4>Iron_Cao2025v2_PD_hgb</h4><p>The steady-state exposure-response curve of Cao K et al., <i>ACS pharmacology &amp; translational science 8(6):1711-1725</i> 2025 (<a href=\"https://doi.org/10.1021/acsptsci.5c00097\">doi:10.1021/acsptsci.5c00097</a>) — HGB [g/dL] against iron μg/dL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       8.99 g/dL     drug-free response (baseline) (HGB0, Q324)
  Emax  =       0.72          maximal effect term (SmaxHGB, Q320)
  EC50  =      16.24 μg/dL    exposure at half of the maximal effect term (SC50HGB, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/dL of iron per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 89.9   (drug-free)
  exposure = EC50 (16.24 μg/dL)  response 122.3
  exposure -> infinity  response 154.6</pre></body></html>"));
end Iron_Cao2025v2_PD_hgb;
