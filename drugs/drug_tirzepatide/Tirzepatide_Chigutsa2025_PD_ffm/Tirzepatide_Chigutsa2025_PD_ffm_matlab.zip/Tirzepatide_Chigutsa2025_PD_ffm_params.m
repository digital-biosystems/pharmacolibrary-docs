function p = Tirzepatide_Chigutsa2025_PD_ffm_params()
% Tirzepatide_Chigutsa2025_PD_ffm_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tirzepatide Chigutsa_2025::FFM: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response FFM in kg. Driver: tirzepatide (cited_pk).
p.E0 = 73.5;
p.Emax = 0.144;
p.EC50 = 0.0017599999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 18000.0;
p.form = 'E0*(1 - Emax*frac)';
end
