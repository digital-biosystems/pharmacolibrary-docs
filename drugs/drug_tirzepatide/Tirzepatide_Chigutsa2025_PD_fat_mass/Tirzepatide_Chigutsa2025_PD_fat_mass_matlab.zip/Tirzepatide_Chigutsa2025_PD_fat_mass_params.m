function p = Tirzepatide_Chigutsa2025_PD_fat_mass_params()
% Tirzepatide_Chigutsa2025_PD_fat_mass_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tirzepatide Chigutsa_2025::fat_mass: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response fat mass in kg. Driver: tirzepatide (cited_pk).
p.E0 = 45.0;
p.Emax = 0.319;
p.EC50 = 0.000518;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5200.0;
p.form = 'E0*(1 - Emax*frac)';
end
