model Tirzepatide_Chigutsa2025_PD_fat_mass
  "indirect_response_i exposure-response sweep — Chigutsa_2025 :: fat mass (fat mass)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 45,      // [kg; kg × 1]
    Emax = 0.319,  // type I effect term
    EC50 = 0.000518,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5200, Interval = 10.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tirzepatide</h4><p>Tirzepatide is a blood glucose lowering drug used to treat type 2 diabetes, and also obesity and overweight. It is an approved medicine authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q108324770\">Wikidata Q108324770</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tirzepatide_Chigutsa2025_PD_fat_mass</h4><p>The steady-state exposure-response curve of Chigutsa E et al., <i>Clinical pharmacology and therapeutics 118(6):1489–1498</i> 2025 (<a href=\"https://doi.org/10.1002/cpt.3750\">doi:10.1002/cpt.3750</a>) — fat mass [kg] against tirzepatide ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         45 kg       drug-free response (baseline) (Baseline fat mass, Q324)
  Emax  =      0.319          maximal effect term (Maximum effect for drug inhibiting formation of fat mass, Q323)
  EC50  =        518 ng/mL    exposure at half of the maximal effect term (IC50 for drug inhibiting formation of fat mass, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of tirzepatide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 45   (drug-free)
  exposure = EC50 (518 ng/mL)  response 37.82
  exposure -> infinity  response 30.65</pre></body></html>"));
end Tirzepatide_Chigutsa2025_PD_fat_mass;
