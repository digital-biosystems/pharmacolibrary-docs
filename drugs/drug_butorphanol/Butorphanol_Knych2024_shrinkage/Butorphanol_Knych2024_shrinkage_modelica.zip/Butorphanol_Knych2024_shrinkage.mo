model Butorphanol_Knych2024_shrinkage
  parameter Real Cl_ref = 1.1491666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03255 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0017444444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>butorphanol</td></tr><tr><td>population:</td><td>exercised Thoroughbred horses</td></tr><tr><td>source_paper:</td><td>Knych_2024</td></tr><tr><td>measured_compound:</td><td>butorphanol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'tvKa (1/h)' (captured trailing unit '1/h' for child rows)</li><li>dropped value-less row: 'tvV/F (L/kg)' (captured trailing unit 'L/kg' for child rows)</li><li>dropped value-less row: 'tvV2/F (L/kg)' (captured trailing unit 'L/kg' for child rows)</li><li>dropped value-less row: 'tvV3/F (L/kg)' (captured trailing unit 'L/kg' for child rows)</li><li>dropped value-less row: 'tvCl/F (mL/min/kg)' (captured trailing unit 'mL/min/kg' for child rows)</li><li>dropped value-less row: 'tvCl2/F (mL/min/kg)' (captured trailing unit 'mL/min/kg' for child rows)</li><li>dropped value-less row: 'tvCl3/F (mL/min/kg)' (captured trailing unit 'mL/min/kg' for child rows)</li><li>salvaged Q49 ('tvKa (1/h)'=6.28) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('tvV/F (L/kg)'=0.465) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('tvV2/F (L/kg)'=0.42) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('tvCl/F (mL/min/kg)'=9.85) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V'=0.144) from results prose — parameter table was unreadable</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Butorphanol_Knych2024_shrinkage;
