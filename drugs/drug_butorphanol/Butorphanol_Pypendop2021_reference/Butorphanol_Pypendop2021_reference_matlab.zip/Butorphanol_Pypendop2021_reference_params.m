function p = Butorphanol_Pypendop2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: butorphanol   source: Pypendop_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Butorphanol_Pypendop2021_reference_params';
  p.drug  = 'butorphanol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 16.17;                % central volume [L]
  p.CL = 77.28;                % clearance [L/h]
  p.Vp = [76.58];             % peripheral volumes [L]
  p.Q  = [715.26];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
