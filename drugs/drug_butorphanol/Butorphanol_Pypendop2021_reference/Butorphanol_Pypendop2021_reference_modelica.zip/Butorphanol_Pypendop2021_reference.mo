model Butorphanol_Pypendop2021_reference
  parameter Real Cl_ref = 2.1466666666666662e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016169999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.01228715728715729,
    k21 = 0.0025944546008531385
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>butorphanol</td></tr><tr><td>population:</td><td>male neutered cats anesthetized with isoflurane</td></tr><tr><td>source_paper:</td><td>Pypendop_2021</td></tr><tr><td>measured_compound:</td><td>butorphanol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp13014-tbl-0001</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=butorphanol</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Butorphanol_Pypendop2021_reference;
