function p = Butorphanol_Knych2024_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: butorphanol   source: Knych_2024 / estimate   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Butorphanol_Knych2024_estimate_params';
  p.drug  = 'butorphanol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.55;                % central volume [L]
  p.CL = 41.37;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
