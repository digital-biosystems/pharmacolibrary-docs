model Butorphanol_Knych2024_estimate
  parameter Real Cl_ref = 1.1491666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03255 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>butorphanol</td></tr><tr><td>population:</td><td>exercised Thoroughbred horses</td></tr><tr><td>source_paper:</td><td>Knych_2024</td></tr><tr><td>measured_compound:</td><td>butorphanol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q309 ('tvCl3/F (mL/min/kg)', value '2.98') — already have one for this compound</li><li>routed 'stdev0' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped duplicate Q49 ('Ka', value '0.412') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=butorphanol</li><li>population split: 'estimate' subgroup of Knych_2024 (paper reports 2 populations: estimate, shrinkage)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Butorphanol_Knych2024_estimate;
