model Colecalciferol_Hoeben2026_reference
  parameter Real Cl_ref = 6.805555555555555e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0017800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>colecalciferol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Hoeben_2026</td></tr><tr><td>measured_compound:</td><td>colecalciferol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Hoeben_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Colecalciferol_Hoeben2026_reference;
