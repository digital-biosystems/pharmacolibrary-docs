function p = Methadone_Ward2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methadone   source: Ward_2014 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Methadone_Ward2014_reference_params';
  p.drug  = 'methadone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.5;                % central volume [L]
  p.CL = 9.45;                % clearance [L/h]
  p.Vp = [75.1];             % peripheral volumes [L]
  p.Q  = [325.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
