function p = Methadone_Shin2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methadone   source: Shin_2024 / reference   route: iv_bolus
  p.name  = 'Methadone_Shin2024_reference_params';
  p.drug  = 'methadone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 686.0;                % central volume [L]
  p.CL = 78.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
