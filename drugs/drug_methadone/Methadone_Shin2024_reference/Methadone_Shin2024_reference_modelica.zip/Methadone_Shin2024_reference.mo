model Methadone_Shin2024_reference
  parameter Real Cl_ref = 9.205000000000001e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.686 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3094452,
    adminMass = 2.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methadone</h4><p>Methadone is a synthetic opioid used to treat chronic pain and opioid dependence. It is typically given orally, which results in good absorption, or by injection into a muscle or vein.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q179996\">Wikidata Q179996</a>, <a href=\"https://en.wikipedia.org/wiki/Methadone?oldid=1376375440\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methadone</td></tr><tr><td>population:</td><td>healthy adult ferrets</td></tr><tr><td>source_paper:</td><td>Shin_2024</td></tr><tr><td>measured_compound:</td><td>methadone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>methadone 309.445 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methadone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methadone_Shin2024_reference;
