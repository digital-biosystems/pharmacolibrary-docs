model FumonisinB1_Schertz2018_reference
  parameter Real Cl_ref = 3.5000000000000004e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.126 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7218,
    adminMass = 3.934e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fumonisin_b1</td></tr><tr><td>population:</td><td>barrows</td></tr><tr><td>source_paper:</td><td>Schertz_2018</td></tr><tr><td>measured_compound:</td><td>Fumonisin B1</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1, Table 2, Table 3, Table 4, Table 5</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Fumonisin B1 721.8 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q59 ('t1/2α'=0.08) from results prose — parameter table was unreadable</li><li>salvaged Q60 ('t1/2β'=0.57) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd'=1.8) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Cl'=1.8) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('t1/2ke for FB1−m'=22.8) from results prose — parameter table was unreadable</li><li>salvaged Q89 ('elimination γ-phase t1/2'=182.6) from results prose — parameter table was unreadable</li><li>implicit units: 'Cl' → L/kg/h (from the paper text: 'The serum clearance (Cl) of FB1−m was 1.8 ± 1.1 L/kg BW/h.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fumonisin B1</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 15 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'Hydrolyzed Fumonisin B1' ('completely hydrolyzed fumonisin B1') — left in mass units</li><li>molar mass: none found for 'Hydrolyzed Fumonisin B1' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end FumonisinB1_Schertz2018_reference;
