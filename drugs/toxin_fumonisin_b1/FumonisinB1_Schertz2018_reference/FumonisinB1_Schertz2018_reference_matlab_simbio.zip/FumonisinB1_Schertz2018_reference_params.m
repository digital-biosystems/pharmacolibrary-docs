function p = FumonisinB1_Schertz2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fumonisin_b1   source: Schertz_2018 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'FumonisinB1_Schertz2018_reference_params';
  p.drug  = 'fumonisin_b1';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 126.0;                % central volume [L]
  p.CL = 126.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.934;             % dose [mg]
end
