model GlycolicAcid_Gabow1986_reference
  parameter Real Cl_ref = 1.7499999999999998e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.8680260000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.07605100000000001,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>glycolic_acid</td></tr><tr><td>population:</td><td>patients with ethylene glycol intoxication</td></tr><tr><td>source_paper:</td><td>Gabow_1986</td></tr><tr><td>measured_compound:</td><td>Glycolic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Ethylene glycol 62.068 g/mol (pubchem); Glycolic acid 76.051 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is glycolic_acid; the compartment is Glycolic acid. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Glycolic acid, not glycolic_acid</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>glycolic_acid's own concentration-time course is not produced by this model</li><li>dropped value-less row: '159 meq'</li><li>dropped unlinked row (NIL): 'removed in 3 hours' — extend the ontology if this is a real PK parameter (source ['Gabow_1986:abstract'])</li><li>metabolite glycolic acid: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Glycolic acid</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=other; 3/3 row label(s) assigned, 1 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q27 (CL/F) from Pereira_2021's review values (primary lacked it)</li><li>gap-filled Q76 (V/F) from Pereira_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Pereira_2021 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end GlycolicAcid_Gabow1986_reference;
