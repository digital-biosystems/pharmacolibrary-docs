model Mepivacaine_Burm1997_reference
  parameter Real Cl_ref = 1.3166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mepivacaine</td></tr><tr><td>population:</td><td>10 healthy volunteers</td></tr><tr><td>source_paper:</td><td>Burm_1997</td></tr><tr><td>measured_compound:</td><td>R(-)-mepivacaine and S(+)-mepivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mepivacaine 246.354 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q65 ('volume of distribution of unbound drug at steady state', value 290) — already have one for this compound</li><li>dropped duplicate Q22 ('CL', value 0.35) — already have one for this compound</li><li>dropped duplicate Q65 ('Vss', value 57) — already have one for this compound</li><li>dropped duplicate Q24 ('CLu', value 1.43) — already have one for this compound</li><li>dropped duplicate Q65 ('Vuss', value 232) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2,Z', value 123) — already have one for this compound</li><li>dropped duplicate Q53 ('MRT', value 165) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=R(-)-mepivacaine and S(+)-mepivacaine</li><li>molar mass: no plausible PubChem entry for 'R(-)-mepivacaine and S(+)-mepivacaine' ('R(-)-mepivacaine and S(+)-mepivacaine') — left in mass units</li><li>molar mass: none found for 'R(-)-mepivacaine and S(+)-mepivacaine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mepivacaine_Burm1997_reference;
