model Mepivacaine_Copeland2008_reference
  parameter Real Cl_ref = 1.4444444444444446e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.033 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24635400000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mepivacaine</td></tr><tr><td>population:</td><td>chronically instrumented ewes</td></tr><tr><td>source_paper:</td><td>Copeland_2008</td></tr><tr><td>measured_compound:</td><td>Mepivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mepivacaine 246.354 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '% of values when conscious' (Vss)</li><li>unit_dimension_unknown: '% of values when conscious' (CL)</li><li>implicit units: 'whole body distribution' → L (from the popPK convention: 'The paper text and table footnotes provide no specific unit. Volume of distribution at steady state (Vss) is a volume pa')</li><li>implicit units: 'whole body clearance' → L/h (from the popPK convention: 'The paper text and table footnotes provide no specific unit. Total clearance (CL) is conventionally reported in Liters p')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mepivacaine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mepivacaine_Copeland2008_reference;
