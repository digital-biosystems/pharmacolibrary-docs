function p = Clofazimine_Zhang2022_PD_rr_params()
% Clofazimine_Zhang2022_PD_rr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clofazimine Zhang_2022::RR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response RR in log(oocysts)/mg feces/day. Driver: clofazimine (cited_pk).
p.E0 = -0.67;
p.Emax = -3.46;
p.EC50 = 0.000316;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3200.0;
p.form = 'E0 + Emax*frac';
end
