% run_Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/mL]'); ylabel('response [days]'); title('Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction.csv');
