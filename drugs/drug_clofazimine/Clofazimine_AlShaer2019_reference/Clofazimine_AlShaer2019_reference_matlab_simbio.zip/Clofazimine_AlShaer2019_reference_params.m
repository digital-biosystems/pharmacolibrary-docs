function p = Clofazimine_AlShaer2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clofazimine   source: Al-Shaer_2019 / reference   route: oral
  p.name  = 'Clofazimine_AlShaer2019_reference_params';
  p.drug  = 'clofazimine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 60.5;                % central volume [L]
  p.CL = 6.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.95;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
