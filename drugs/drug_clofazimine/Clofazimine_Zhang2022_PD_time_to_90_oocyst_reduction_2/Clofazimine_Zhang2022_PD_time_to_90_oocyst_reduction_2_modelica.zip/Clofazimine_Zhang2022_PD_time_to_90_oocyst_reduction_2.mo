model Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction_2
  "linear exposure-response sweep — Zhang_2022 :: Time to >90% oocyst reduction (Time to >90% oocyst reduction)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -2270,  // [1]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // slope_unit_assumed: slope unit '(none)' read as response per ng/mL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clofazimine</h4><p>Clofazimine is an antibacterial drug used to treat leprosy, and has also been used for other mycobacterial infections and inflammatory skin conditions such as pyoderma gangrenosum. It remains in use and is included on the WHO list of essential medicines, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418611\">Wikidata Q418611</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction_2</h4><p>The steady-state exposure-response curve of Zhang CX et al., <i>Antimicrobial agents and chemotherapy 66(1):e0156021</i> 2022 (<a href=\"https://doi.org/10.1128/AAC.01560-21\">doi:10.1128/AAC.01560-21</a>) — Time to &gt;90% oocyst reduction [days] against clofazimine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =   -0.00227          change in response per unit of exposure (Slope for Cavg96-108, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of clofazimine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Clofazimine_Zhang2022_PD_time_to_90_oocyst_reduction_2;
