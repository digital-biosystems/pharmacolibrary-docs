function p = Clofazimine_Zhang2022_PD_tte_params()
% Clofazimine_Zhang2022_PD_tte_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clofazimine Zhang_2022::TTE: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response TTE in days. Driver: clofazimine (cited_pk).
p.E0 = 561600.0;
p.Emax = -475200.0;
p.EC50 = 0.000227;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2300.0;
p.form = 'E0 + Emax*frac';
end
