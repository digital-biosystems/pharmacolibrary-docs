model Clofazimine_Zhang2022_PD_tte
  "emax exposure-response sweep — Zhang_2022 :: TTE (time to achieve 90% reduction in oocyst shedding)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 561600,      // [s; days × 86400]
    Emax = -475200,  // [s; days × 86400]
    EC50 = 0.000227,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  annotation(experiment(StartTime = 0, StopTime = 2300, Interval = 4.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clofazimine</h4><p>Clofazimine is an antibacterial drug used to treat leprosy, and has also been used for other mycobacterial infections and inflammatory skin conditions such as pyoderma gangrenosum. It remains in use and is included on the WHO list of essential medicines, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418611\">Wikidata Q418611</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clofazimine_Zhang2022_PD_tte</h4><p>The steady-state exposure-response curve of Zhang CX et al., <i>Antimicrobial agents and chemotherapy 66(1):e0156021</i> 2022 (<a href=\"https://doi.org/10.1128/AAC.01560-21\">doi:10.1128/AAC.01560-21</a>) — time to achieve 90% reduction in oocyst shedding [days] against clofazimine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        6.5 days     drug-free response (baseline) (E0, Q324)
  Emax  =       -5.5 days     maximal effect term (Emax, Q320)
  EC50  =        227 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of clofazimine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5.616e+05   (drug-free)
  exposure = EC50 (227 ng/ml)  response 3.24e+05
  exposure -> infinity  response 8.64e+04</pre></body></html>"));
end Clofazimine_Zhang2022_PD_tte;
