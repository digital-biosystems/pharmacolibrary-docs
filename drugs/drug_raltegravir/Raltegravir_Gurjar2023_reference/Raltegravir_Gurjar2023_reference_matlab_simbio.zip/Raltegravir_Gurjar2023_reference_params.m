function p = Raltegravir_Gurjar2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: raltegravir   source: Gurjar_2023 / reference   route: oral
  p.name  = 'Raltegravir_Gurjar2023_reference_params';
  p.drug  = 'raltegravir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 194.0;                % central volume [L]
  p.CL = 55.8;                % clearance [L/h]
  p.Vp = [117.0];             % peripheral volumes [L]
  p.Q  = [13.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.12;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
