model Raltegravir_Gurjar2023_reference
  parameter Real Cl_ref = 1.5499999999999997e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.194 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4444163,
    adminMass = 0.0004,
    ka = 0.0003111111111111111,
    Tlag = 0.0,
    k12 = 1.861397479954181e-05,
    k21 = 3.08641975308642e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About raltegravir</h4><p>Raltegravir is an antiviral drug used to treat HIV infection and HIV/AIDS. It is an authorised medicine in the European Union and is included on the WHO list of essential medicines, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421552\">Wikidata Q421552</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>raltegravir</td></tr><tr><td>population:</td><td>HIV-infected adults</td></tr><tr><td>source_paper:</td><td>Gurjar_2023</td></tr><tr><td>measured_compound:</td><td>raltegravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>raltegravir 444.416 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional (%)' routed out of structural estimates ('Residual error')</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'Vc/F'</li><li>dropped value-less row: 'Q/F'</li><li>dropped value-less row: 'Vp/F'</li><li>dropped value-less row: 'ka'</li><li>dropped value-less row: 'covariates tested'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=raltegravir</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Raltegravir_Gurjar2023_reference;
