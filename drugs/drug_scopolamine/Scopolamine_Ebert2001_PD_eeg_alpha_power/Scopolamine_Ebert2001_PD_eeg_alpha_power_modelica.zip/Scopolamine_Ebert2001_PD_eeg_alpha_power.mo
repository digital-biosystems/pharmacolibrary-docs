model Scopolamine_Ebert2001_PD_eeg_alpha_power
  "sigmoid_emax exposure-response sweep — Ebert_2001 :: EEG alpha power (total power in alpha frequency band)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.58,      // [microV2]
    Emax = -0.29,  // [microV2]
    EC50 = 6e-07,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1.17,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 6, Interval = 0.012),
    Documentation(info = "<html><body><!-- drug-about --><h4>About scopolamine</h4><p>Scopolamine is an anticholinergic used for conditions such as motion sickness, iridocyclitis, and other disorders listed in its treatment records. It remains an approved medicine and is included on the WHO essential medicines list, used in ophthalmic, antiemetic, and sedative roles.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q337188\">Wikidata Q337188</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Scopolamine_Ebert2001_PD_eeg_alpha_power</h4><p>The steady-state exposure-response curve of Ebert U et al., <i>Journal of clinical pharmacology 41(1):51–60</i> 2001 (<a href=\"https://doi.org/10.1177/00912700122009836\">doi:10.1177/00912700122009836</a>) — total power in alpha frequency band [microV2] against scopolamine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.58 microV2  drug-free response (baseline) (E0, Q324)
  Emax  =       0.29 microV2  maximal effect term (Emax, Q323)
  EC50  =        0.6 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.17          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of scopolamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.58   (drug-free)
  exposure = EC50 (0.6 ng/ml)  response 0.435
  exposure -> infinity  response 0.29</pre></body></html>"));
end Scopolamine_Ebert2001_PD_eeg_alpha_power;
