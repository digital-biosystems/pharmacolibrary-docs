// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Uranium235_Kathren1986_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {432000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_235</td></tr><tr><td>population:</td><td>three men accidentally exposed</td></tr><tr><td>source_paper:</td><td>Kathren_1986</td></tr><tr><td>measured_compound:</td><td>Uranium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>uranium_235 238.03 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '3' — extend the ontology if this is a real PK parameter (source ['Kathren_1986_table_p9_1:row0:col4', 'Kathren_1986_table_p9_1:row0:col5', 'Kathren_1986_table_p9_1:row0:col6'])</li><li>dropped unlinked row (NIL): '4' — extend the ontology if this is a real PK parameter (source ['Kathren_1986_table_p9_1:row1:col4', 'Kathren_1986_table_p9_1:row1:col5', 'Kathren_1986_table_p9_1:row1:col6'])</li><li>dropped unlinked row (NIL): '5' — extend the ontology if this is a real PK parameter (source ['Kathren_1986_table_p9_1:row2:col4', 'Kathren_1986_table_p9_1:row2:col5', 'Kathren_1986_table_p9_1:row2:col6'])</li><li>salvaged Q57 ('half-time'=5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: half-time printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>molar mass: none of 1 PubChem candidate(s) is 'Uranium' (LLM) — left in mass units</li><li>molar mass: none found for 'Uranium' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Uranium', not uranium_235 — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 4838.4));
end Uranium235_Kathren1986_reference;
