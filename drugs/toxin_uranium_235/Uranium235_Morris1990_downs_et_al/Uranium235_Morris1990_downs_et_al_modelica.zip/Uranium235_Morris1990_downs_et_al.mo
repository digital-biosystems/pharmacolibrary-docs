// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Uranium235_Morris1990_downs_et_al
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {14606808.878141286},
    MM = 0.23803,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_235</td></tr><tr><td>population:</td><td>Fischer-344 rats</td></tr><tr><td>source_paper:</td><td>Morris_1990</td></tr><tr><td>measured_compound:</td><td>Uranium-235</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Uranium-235 238.03 g/mol (pubchem); uranium_235 238.03 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q414 ('INITIAL LUNG BURDEN μg', value '595') — already have one for this compound</li><li>dropped unlinked row (NIL): 'TIMES (d) t_0' — extend the ontology if this is a real PK parameter (source ['Morris_1990_table_5:row1:col4', 'Morris_1990_table_5:row2:col4', 'Morris_1990_table_5:row3:col4'])</li><li>dropped unlinked row (NIL): 'TIMES (d) t_f' — extend the ontology if this is a real PK parameter (source ['Morris_1990_table_5:row1:col5', 'Morris_1990_table_5:row2:col5', 'Morris_1990_table_5:row3:col5'])</li><li>dropped unlinked row (NIL): 't_1/2 IN LUNG (d)' — extend the ontology if this is a real PK parameter (source ['Morris_1990_table_5:row1:col8', 'Morris_1990_table_5:row2:col8', 'Morris_1990_table_5:row3:col8'])</li><li>implicit units: 'INITIAL LUNG BURDEN kBq' — the LLM proposed 'kBq', whose dimension does not fit Q414; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium-235</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'downs et al. (1967)' subgroup of Morris_1990 (paper reports 6 populations: batchelor (1989), downs et al. (1967), morris et al. (this study), rhoads et al. (1986), sanders et al. (1976), stanley et al. (1982))</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q414 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Uranium235_Morris1990_downs_et_al;
