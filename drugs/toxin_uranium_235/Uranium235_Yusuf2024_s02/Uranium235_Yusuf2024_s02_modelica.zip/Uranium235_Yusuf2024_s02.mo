// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Uranium235_Yusuf2024_s02
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3456000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_235</td></tr><tr><td>population:</td><td>retired nuclear fuel workers</td></tr><tr><td>source_paper:</td><td>Yusuf_2024</td></tr><tr><td>measured_compound:</td><td>Uranium-238</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>TA1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>uranium_235 238.03 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Bq d−1' (equation variable)</li><li>dropped unlinked row (NIL): 'One Compartment Non-Linear Regression Fit / SE (Bq d−1)' — extend the ontology if this is a real PK parameter (source ['Yusuf_2024_table_2:row2:col2', 'Yusuf_2024_table_2:row7:col2'])</li><li>dropped unlinked row (NIL): 'One Compartment Non-Linear Regression Fit / SE (d)' — extend the ontology if this is a real PK parameter (source ['Yusuf_2024_table_2:row2:col6', 'Yusuf_2024_table_2:row7:col6'])</li><li>dropped unlinked row (NIL): 'One Compartment Non-Linear Regression Fit / R2 (p-value)' — extend the ontology if this is a real PK parameter (source ['Yusuf_2024_table_2:row2:col7', 'Yusuf_2024_table_2:row2:col8', 'Yusuf_2024_table_2:row2:col9', 'Yusuf_2024_table_2:row7:col7', 'Yusuf_2024_table_2:row7:col8', 'Yusuf_2024_table_2:row7:col9'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium-238</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 's02 (n = 18)' subgroup of Yusuf_2024 (paper reports 2 populations: s01 (n = 24), s02 (n = 18))</li><li>molar mass: none of 2 PubChem candidate(s) is 'Uranium-238' (LLM) — left in mass units</li><li>molar mass: none found for 'Uranium-238' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Uranium-238', not uranium_235 — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Uranium235_Yusuf2024_s02;
