// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Uranium235_Morris1989_batchelor_priv_comm
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4320000.0},
    MM = 0.23803,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>uranium_235</td></tr><tr><td>population:</td><td>Male HMT rats and male Fischer-344 rats</td></tr><tr><td>source_paper:</td><td>Morris_1989</td></tr><tr><td>measured_compound:</td><td>Uranium-235</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Uranium-235 238.03 g/mol (pubchem); uranium_235 238.03 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'batchelor (priv. comm.)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'batchelor (priv. comm.)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'batchelor (priv. comm.)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>relinked 't1/2 IN LUNG (d)' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Uranium-235</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'batchelor (priv. comm.)' subgroup of Morris_1989 (paper reports 7 populations: batchelor (priv. comm.), james et al (1977), morris et al (this study), morris et al (unpubl.), rhoads et al (1986), sanders et al (1976), stanley et al (1982))</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Uranium235_Morris1989_batchelor_priv_comm;
