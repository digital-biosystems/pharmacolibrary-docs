function p = Vernakalant_Mao2011_PD_qtcf_params()
% Vernakalant_Mao2011_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vernakalant Mao_2011::QTcF: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response QTcF in ms. Driver: vernakalant (cited_pk).
p.E0 = 0.0;
p.Emax = 0.020300000000000002;
p.EC50 = 0.004222;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 43000.0;
p.form = 'E0 + Emax*frac';
end
