model Vernakalant_Mao2011_PD_qtcf
  "sigmoid_emax exposure-response sweep — Mao_2011 :: QTcF (QT interval prolongation corrected for heart rate by Fridericia's formula)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0203,  // [s; ms × 0.001]
    EC50 = 0.004222,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 43000, Interval = 86),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vernakalant</h4><p>Vernakalant is an antiarrhythmic drug used to treat atrial fibrillation. It is an approved medicine, available in some countries, mainly for hospital use in restoring normal heart rhythm.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q665725\">Wikidata Q665725</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Vernakalant_Mao2011_PD_qtcf</h4><p>The steady-state exposure-response curve of Mao Z et al., <i>Journal of pharmacokinetics and pharmacodynamics 38(5):541–562</i> 2011 (<a href=\"https://doi.org/10.1007/s10928-011-9207-3\">doi:10.1007/s10928-011-9207-3</a>) — QT interval prolongation corrected for heart rate by Fridericia's formula [ms] against vernakalant ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       20.3 ms       maximal effect term (Emax, Q320)
  EC50  =       4222 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of vernakalant per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4222 ng/ml)  response 0.01015
  exposure -> infinity  response 0.0203</pre></body></html>"));
end Vernakalant_Mao2011_PD_qtcf;
