model Vernakalant_Mao2012_estimate
  parameter Real Cl_ref = 3.88888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0357 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.349471,
    adminMass = 0.00014,
    k12 = 0.001432461873638344,
    k21 = 0.000702457264957265
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vernakalant</h4><p>Vernakalant is an antiarrhythmic drug used to treat atrial fibrillation. It is an approved medicine, available in some countries, mainly for hospital use in restoring normal heart rhythm.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q665725\">Wikidata Q665725</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vernakalant</td></tr><tr><td>population:</td><td>patients with atrial fibrillation or atrial flutter and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Mao_2012</td></tr><tr><td>measured_compound:</td><td>vernakalant</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vernakalant 349.471 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL, L/h', value '16.40') — already have one for this compound</li><li>dropped duplicate Q30 ('Q, L/h', value '210.4') — already have one for this compound</li><li>dropped duplicate Q63 ('Vc, L', value '40.94') — already have one for this compound</li><li>dropped duplicate Q64 ('Vp, L', value '83.11') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vernakalant</li><li>population split: 'estimate' subgroup of Mao_2012 (paper reports 2 populations: estimate, parameter estimate ± se)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vernakalant_Mao2012_estimate;
