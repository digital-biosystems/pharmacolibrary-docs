function p = Vernakalant_Mao2012_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vernakalant   source: Mao_2012 / estimate   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Vernakalant_Mao2012_estimate_params';
  p.drug  = 'vernakalant';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 35.7;                % central volume [L]
  p.CL = 14.0;                % clearance [L/h]
  p.Vp = [72.8];             % peripheral volumes [L]
  p.Q  = [184.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
