function p = Cilazapril_Williams1989_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cilazapril   source: Williams_1989 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cilazapril_Williams1989_reference_params';
  p.drug  = 'cilazapril';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.4;                % central volume [L]
  p.CL = 14.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.2;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
