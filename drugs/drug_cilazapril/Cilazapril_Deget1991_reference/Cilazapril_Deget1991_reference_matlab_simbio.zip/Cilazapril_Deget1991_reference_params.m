function p = Cilazapril_Deget1991_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cilazapril   source: Deget_1991 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cilazapril_Deget1991_reference_params';
  p.drug  = 'cilazapril';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.54156;                % central volume [L]
  p.CL = 2.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
