// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Amantadine_Horadam1981_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {42480.00000000001},
    MM = 0.151253,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amantadine</td></tr><tr><td>population:</td><td>subjects with normal and impaired renal function, including hemodialysis patients</td></tr><tr><td>source_paper:</td><td>Horadam_1981</td></tr><tr><td>measured_compound:</td><td>amantadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>amantadine 151.253 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'half-life of elimination in subjects with normal renal function (range)' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('half-life of elimination in subjects with normal renal function (range)', value 9.7) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of elimination in patients with various degrees of renal insufficiency (from)', value 18.5) — already have one for this compound</li><li>dropped duplicate Q57 ('half-lives of elimination in patients with various degrees of renal insufficiency (to)', value 33.8) — already have one for this compound</li><li>dropped duplicate Q57 ('mean half-life of elimination during chronic hemodialysis', value 8.3) — already have one for this compound</li><li>relinked 'mean half-life of elimination during chronic hemodialysis (range)' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('mean half-life of elimination during chronic hemodialysis (range)', value 7.0) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amantadine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Wang_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Amantadine_Horadam1981_reference;
