function p = Amantadine_Kornhuber2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amantadine   source: Kornhuber_2006 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Amantadine_Kornhuber2006_reference_params';
  p.drug  = 'amantadine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 65.5;                % central volume [L]
  p.CL = 169.2236;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
