model Amantadine_Kornhuber2006_reference
  parameter Real Cl_ref = 8.084248633667453e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0655 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.151253,
    adminMass = 0.0002,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amantadine</td></tr><tr><td>population:</td><td>human patients (brain tissue samples)</td></tr><tr><td>source_paper:</td><td>Kornhuber_2006</td></tr><tr><td>measured_compound:</td><td>Amantadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>amantadine 151.253 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Amantadine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q27 (CL/F) from Wang_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL/F=0.291033 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Amantadine_Kornhuber2006_reference;
