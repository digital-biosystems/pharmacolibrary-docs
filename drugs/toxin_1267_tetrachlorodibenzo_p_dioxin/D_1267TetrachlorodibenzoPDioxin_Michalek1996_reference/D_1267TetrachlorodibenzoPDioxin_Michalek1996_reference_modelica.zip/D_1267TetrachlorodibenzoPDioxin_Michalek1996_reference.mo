// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_1267TetrachlorodibenzoPDioxin_Michalek1996_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {274551120.0},
    MM = 0.32196199999999997,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>1267_tetrachlorodibenzo_p_dioxin</td></tr><tr><td>population:</td><td>Air Force veterans of Operation Ranch Hand</td></tr><tr><td>source_paper:</td><td>Michalek_1996</td></tr><tr><td>measured_compound:</td><td>1,2,6,7-Tetrachlorodibenzo-p-dioxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>TABLE 2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>1267_tetrachlorodibenzo_p_dioxin 321.962 g/mol (pubchem); 1,2,6,7-Tetrachlorodibenzo-p-dioxin 321.962 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Statistic' — extend the ontology if this is a real PK parameter (source ['Michalek_1996_table_1:row0:col1', 'Michalek_1996_table_1:row0:col2'])</li><li>dropped PD-category row 'SD' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Michalek_1996_table_1:row3:col1', 'Michalek_1996_table_1:row3:col2'])</li><li>dropped unlinked row (NIL): '0' — extend the ontology if this is a real PK parameter (source ['Michalek_1996_table_1:row5:col1', 'Michalek_1996_table_1:row5:col2'])</li><li>salvaged Q57 ('TCD D half-life'=8.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1,2,6,7-Tetrachlorodibenzo-p-dioxin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end D_1267TetrachlorodibenzoPDioxin_Michalek1996_reference;
