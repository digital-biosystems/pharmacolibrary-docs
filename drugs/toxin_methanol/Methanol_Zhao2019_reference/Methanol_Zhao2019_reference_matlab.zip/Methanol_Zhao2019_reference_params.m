function p = Methanol_Zhao2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methanol   source: Zhao_2019 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Methanol_Zhao2019_reference_params';
  p.drug  = 'methanol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1351.0;                % central volume [L]
  p.CL = 494.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
