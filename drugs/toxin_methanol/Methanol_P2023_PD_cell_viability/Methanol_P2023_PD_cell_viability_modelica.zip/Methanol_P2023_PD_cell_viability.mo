model Methanol_P2023_PD_cell_viability
  "linear exposure-response sweep — P_2023 :: Cell viability (Cell viability)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -126.4,  // [1]
    exposure_per_s = 0.001);   // 1 µg/ml per second
  // slope_unit_assumed: slope unit '(none)' read as response per µg/ml
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Methanol_P2023_PD_cell_viability</h4><p>The steady-state exposure-response curve of P NK et al., <i>Cureus 15(2):e34545</i> 2023 (<a href=\"https://doi.org/10.7759/cureus.34545\">doi:10.7759/cureus.34545</a>) — Cell viability [%] against methanolic root extract µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    -0.1264          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µg/ml of methanolic root extract per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Methanol_P2023_PD_cell_viability;
