function p = Methanol_P2023_PD_cell_viability_2_params()
% Methanol_P2023_PD_cell_viability_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methanol P_2023::Cell_viability::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response Cell viability in %. Driver: methanolic petiole extract (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -218.70000000000005;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
