function p = Methanol_Yu2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methanol   source: Yu_2014 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Methanol_Yu2014_reference_params';
  p.drug  = 'methanol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1526.0;                % central volume [L]
  p.CL = 6237.0;                % clearance [L/h]
  p.Vp = [1218.0];             % peripheral volumes [L]
  p.Q  = [1855.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
