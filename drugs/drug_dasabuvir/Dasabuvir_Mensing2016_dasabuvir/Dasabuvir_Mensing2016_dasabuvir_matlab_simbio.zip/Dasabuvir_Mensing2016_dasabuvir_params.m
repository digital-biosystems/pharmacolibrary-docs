function p = Dasabuvir_Mensing2016_dasabuvir_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dasabuvir   source: Mensing_2016 / dasabuvir   route: oral
  p.name  = 'Dasabuvir_Mensing2016_dasabuvir_params';
  p.drug  = 'dasabuvir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 417.0;                % central volume [L]
  p.CL = 70.416667;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.583333;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
