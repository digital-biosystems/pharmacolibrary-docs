model Dasabuvir_Mensing2016_dasabuvir
  parameter Real Cl_ref = 1.9560185185185185e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.417 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.49357999999999996,
    adminMass = 2.5e-05,
    ka = 0.00016203703703703703,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dasabuvir</h4><p>Dasabuvir is a direct-acting antiviral agent used to treat chronic hepatitis C. It is administered orally, typically as a tablet.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q19462214\">Wikidata Q19462214</a>, <a href=\"https://en.wikipedia.org/wiki/Dasabuvir?oldid=1346943437\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dasabuvir</td></tr><tr><td>population:</td><td>adults with chronic hepatitis C virus genotype 1 infection</td></tr><tr><td>source_paper:</td><td>Mensing_2016</td></tr><tr><td>measured_compound:</td><td>dasabuvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dasabuvir 493.58 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'dasabuvir' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'dasabuvir' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'dasabuvir' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'dasabuvir' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'dasabuvir' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'dasabuvir' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dasabuvir</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F, L' is the general volume)</li><li>population split: 'dasabuvir' subgroup of Mensing_2016 (paper reports 2 populations: dasabuvir, paritaprevir/r)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Dasabuvir_Mensing2016_dasabuvir;
