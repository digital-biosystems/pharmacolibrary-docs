function p = Dasabuvir_Mensing2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dasabuvir   source: Mensing_2016 / reference   route: oral
  p.name  = 'Dasabuvir_Mensing2016_reference_params';
  p.drug  = 'dasabuvir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 638.0;                % central volume [L]
  p.CL = 157.083333;                % clearance [L/h]
  p.Vp = [5110.0];             % peripheral volumes [L]
  p.Q  = [10.583333];             % inter-compartmental clearances [L/h]
  p.ka = 0.24875;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
