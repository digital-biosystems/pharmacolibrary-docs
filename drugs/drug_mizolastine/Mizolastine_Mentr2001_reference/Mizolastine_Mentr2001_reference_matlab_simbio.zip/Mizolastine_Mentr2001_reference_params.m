function p = Mizolastine_Mentr2001_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mizolastine   source: Mentré_2001 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Mizolastine_Mentr2001_reference_params';
  p.drug  = 'mizolastine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.6;                % central volume [L]
  p.CL = 0.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
