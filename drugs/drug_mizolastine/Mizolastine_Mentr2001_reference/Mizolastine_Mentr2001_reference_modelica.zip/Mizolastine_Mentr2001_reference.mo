model Mizolastine_Mentr2001_reference
  parameter Real Cl_ref = 2.777777777777778e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43250299999999997,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mizolastine</h4><p>Mizolastine is a non-sedating antihistamine used to relieve symptoms of allergic conditions such as allergic rhinitis and hives. It is an approved medicine that has been used mainly in European countries, though it is not authorised across the whole European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417830\">Wikidata Q417830</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mizolastine</td></tr><tr><td>population:</td><td>children 6 to 12 years old</td></tr><tr><td>source_paper:</td><td>Mentré_2001</td></tr><tr><td>measured_compound:</td><td>mizolastine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>mizolastine 432.503 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/hr per kg' (CL/F)</li><li>dropped PD-category row 'lambda 1' → Q342 (lambda_hazard, category G14) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Mentré_2001:abstract'])</li><li>dropped PD-category row 'lambda 2' → Q342 (lambda_hazard, category G14) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Mentré_2001:abstract'])</li><li>dropped unlinked row (NIL): 'Tabs' — extend the ontology if this is a real PK parameter (source ['Mentré_2001:abstract'])</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'The paper text and captions are not provided, so no unit is explicitly stated. Clearances in population pharmacokinetics')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=mizolastine</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Mizolastine_Mentr2001_reference;
