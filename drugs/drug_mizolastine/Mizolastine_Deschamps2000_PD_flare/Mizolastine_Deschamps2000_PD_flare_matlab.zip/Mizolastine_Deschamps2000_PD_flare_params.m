function p = Mizolastine_Deschamps2000_PD_flare_params()
% Mizolastine_Deschamps2000_PD_flare_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mizolastine Deschamps_2000::flare: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response flare in cm2. Driver: mizolastine (cited_pk).
p.E0 = 20.735294117647058;
p.Emax = 0.92;
p.EC50 = 2.11e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 220.0;
p.form = 'E0*(1 - Emax*frac)';
end
