model Mizolastine_Deschamps2000_PD_flare
  "indirect_response_i exposure-response sweep — Deschamps_2000 :: flare (flare)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 20.7352941176,      // [cm2]
    Emax = 0.92,  // type I effect term
    EC50 = 2.11e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (14.1/0.68 = 20.74) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 220, Interval = 0.44),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mizolastine</h4><p>Mizolastine is a non-sedating antihistamine used to relieve symptoms of allergic conditions such as allergic rhinitis and hives. It is an approved medicine that has been used mainly in European countries, though it is not authorised across the whole European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417830\">Wikidata Q417830</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mizolastine_Deschamps2000_PD_flare</h4><p>The steady-state exposure-response curve of Deschamps C et al., <i>Clinical pharmacology and therapeutics 68(6):647–657</i> 2000 (<a href=\"https://doi.org/10.1067/mcp.2000.112341\">doi:10.1067/mcp.2000.112341</a>) — flare [cm2] against mizolastine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 20.7352941176 cm2      drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       0.92          maximal effect term (maximum attainable inhibition of the effect production, Q323)
  EC50  =       21.1 ng/mL    exposure at half of the maximal effect term (mizolastine concentration that produced 50% suppression of the maximum attainable inhibition of k(in), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of mizolastine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 20.74   (drug-free)
  exposure = EC50 (21.1 ng/mL)  response 11.2
  exposure -> infinity  response 1.659</pre></body></html>"));
end Mizolastine_Deschamps2000_PD_flare;
