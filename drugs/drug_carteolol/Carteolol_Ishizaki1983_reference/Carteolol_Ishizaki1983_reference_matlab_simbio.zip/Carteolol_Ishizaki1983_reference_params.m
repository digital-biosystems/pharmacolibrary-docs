function p = Carteolol_Ishizaki1983_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carteolol   source: Ishizaki_1983 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Carteolol_Ishizaki1983_reference_params';
  p.drug  = 'carteolol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 51.8;                % central volume [L]
  p.CL = 42.546;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.837;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
