function p = Aripiprazole_Hermans2023_PD_bmi_z_score_params()
% Aripiprazole_Hermans2023_PD_bmi_z_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% aripiprazole Hermans_2023::BMI_z_score: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response BMI z-score in its own unit. Driver: aripiprazole plus dehydro-aripiprazole (conc_no_pk).
p.E0 = 0.689;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 8000.000000000002;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
