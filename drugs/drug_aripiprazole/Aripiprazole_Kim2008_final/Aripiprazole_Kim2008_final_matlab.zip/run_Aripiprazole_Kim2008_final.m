% Run: build params, simulate 0..216.0 h, plot every molecule + save Aripiprazole_Kim2008_final.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Aripiprazole_Kim2008_final.m
here = fileparts(mfilename('fullpath'));
p = Aripiprazole_Kim2008_final_params();
out = simulate_network(p, 0:0.05:216.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('concentration [mg/L]');
title('aripiprazole — Kim_2008 (parent + metabolites)');
print(fig, fullfile(here, 'Aripiprazole_Kim2008_final.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Aripiprazole_Kim2008_final.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg_per_L', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Aripiprazole_Kim2008_final.json'), 'w');
try
  s.model = 'Aripiprazole_Kim2008_final'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg_per_L']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Aripiprazole_Kim2008_final"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): Cmax=%.4g mg/L  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Aripiprazole_Kim2008_final.png, Aripiprazole_Kim2008_final.csv, Aripiprazole_Kim2008_final.json\n');
