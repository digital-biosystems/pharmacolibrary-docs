// parent + metabolites (dehydroaripiprazole): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Aripiprazole_Kim2008_final
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.193,
    q1_m11 = 8.75e-07,
    CL1 = 0.0,
    Vd1m1 = 0.587,
    CLm1 = 2.2277777777777777e-06,
    MW = 0.448385,
    MW_m1 = 0.446372,
    F = 1,
    ka = 0.00029444444444444445,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aripiprazole</h4><p>Aripiprazole is an atypical antipsychotic used primarily for schizophrenia, bipolar disorder, and autism-related irritability. It is given orally as tablets or solutions, which have good absorption, or by intramuscular injection for extended-release treatment. Aripiprazole is widely used and authorized in the European Union, where it is indicated for schizophrenia and bipolar disorder.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411188\">Wikidata Q411188</a>, <a href=\"https://en.wikipedia.org/wiki/Aripiprazole?oldid=1384689224\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aripiprazole</td></tr><tr><td>population:</td><td>psychiatric patients with schizophrenia, schizophreniform disorder, and schizoaffective disorder</td></tr><tr><td>source_paper:</td><td>Kim_2008</td></tr><tr><td>measured_compound:</td><td>aripiprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of dehydroaripiprazole: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; dose 5 mg (paper)</td></tr><tr><td>molar_masses:</td><td>aripiprazole 448.385 g/mol (drugbank); dehydroaripiprazole 446.372 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 's 2' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>routed 's 2 m' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=aripiprazole</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [1]</li><li>model-stage split: 'final model / estimate (se)' is the final model of Kim_2008 (paper reports 2 stages: base model / estimate (se), final model / estimate (se)); same population, different model-building step</li><li>row roles: per-genotype parameters — typical value from the reference group: CL/FI (l h -1 ) †</li><li>row roles (LLM): model_class=compartmental; 14/14 row label(s) assigned, 10 linked by role; re-tagged parent→dehydroaripiprazole ×8</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Aripiprazole_Kim2008_final;
