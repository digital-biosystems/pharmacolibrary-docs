function p = Aripiprazole_Kim2011_PD_bp_params()
% Aripiprazole_Kim2011_PD_bp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% aripiprazole Kim_2011::BP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BP in its own unit. Driver: aripiprazole (cited_pk).
p.E0 = 0.0;
p.Emax = -1.8;
p.EC50 = 1.4199999999999998e-05;
p.gamma = 0.9;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 150.0;
p.form = 'E0 + Emax*frac';
end
