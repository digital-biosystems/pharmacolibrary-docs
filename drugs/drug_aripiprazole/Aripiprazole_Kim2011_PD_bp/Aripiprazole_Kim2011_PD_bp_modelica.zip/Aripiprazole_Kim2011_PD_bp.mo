model Aripiprazole_Kim2011_PD_bp
  "sigmoid_emax exposure-response sweep — Kim_2011 :: BP (binding potential)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.8,  // [1]
    EC50 = 1.42e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.9,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 150, Interval = 0.3),
    Documentation(info = "<html><body><!-- drug-about --><h4>About aripiprazole</h4><p>Aripiprazole is an atypical antipsychotic used primarily for schizophrenia, bipolar disorder, and autism-related irritability. It is given orally as tablets or solutions, which have good absorption, or by intramuscular injection for extended-release treatment. Aripiprazole is widely used and authorized in the European Union, where it is indicated for schizophrenia and bipolar disorder.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411188\">Wikidata Q411188</a>, <a href=\"https://en.wikipedia.org/wiki/Aripiprazole?oldid=1384689224\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Aripiprazole_Kim2011_PD_bp</h4><p>The steady-state exposure-response curve of Kim E et al., <i>Journal of cerebral blood flow and metabolism : official journal of the International Society of Cerebral Blood Flow and Metabolism 31(8):1760–1767</i> 2011 (<a href=\"https://doi.org/10.1038/jcbfm.2011.54\">doi:10.1038/jcbfm.2011.54</a>) — binding potential against aripiprazole ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        1.8          maximal effect term (I max, Q323)
  EC50  =       14.2 ng/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma =        0.9          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of aripiprazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (14.2 ng/mL)  response -0.9
  exposure -> infinity  response -1.8</pre></body></html>"));
end Aripiprazole_Kim2011_PD_bp;
