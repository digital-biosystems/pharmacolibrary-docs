model Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl
  "sigmoid_emax exposure-response sweep — McKay_1993 :: baseline tension of diaphragm muscle (baseline tension of diaphragm muscle)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.00061,  // [kg; g × 0.001]
    EC50 = 88,  // [pM]
    gamma = 1,
    exposure_per_s = 1);   // 1 pM per second
  // exposure_unit_unresolved: 'pM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 880, Interval = 1.76),
    Documentation(info = "<html><body><h4>Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl</h4><p>The steady-state exposure-response curve of McKay DB et al., <i>Proceedings of the Society for Experimental Biology and Medicine. Society for Experimental Biology and Medicine (New York, N.Y.) 203(3):372–376</i> 1993 (<a href=\"https://doi.org/10.3181/00379727-203-43614\">doi:10.3181/00379727-203-43614</a>) — baseline tension of diaphragm muscle [g] against vinblastine pM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.61 g        maximal effect term (Emax, Q320)
  EC50  =         88 pM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pM of vinblastine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (88 pM)  response 0.000305
  exposure -> infinity  response 0.00061</pre></body></html>"));
end Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl;
