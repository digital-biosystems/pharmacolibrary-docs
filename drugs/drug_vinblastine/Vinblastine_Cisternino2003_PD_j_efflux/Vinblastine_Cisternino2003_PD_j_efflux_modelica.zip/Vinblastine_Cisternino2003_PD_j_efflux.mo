model Vinblastine_Cisternino2003_PD_j_efflux
  "sigmoid_emax exposure-response sweep — Cisternino_2003 :: J_efflux (P-gp-mediated efflux component of the compound transported through the rat BBB)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -8.8,  // [pmol s -1 g -1]
    EC50 = 71.3,  // [M]
    gamma = 1.7,
    exposure_per_s = 1);   // 1 M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 720, Interval = 1.44),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vinblastine</h4><p>Vinblastine, a Vinca alkaloid, is a cancer medicine used against tumours such as Hodgkin's lymphoma, breast, testicular and kidney cancer, Kaposi's sarcoma, and also certain blood and immune disorders. It remains an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q282629\">Wikidata Q282629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Vinblastine_Cisternino2003_PD_j_efflux</h4><p>The steady-state exposure-response curve of Cisternino S et al., <i>Pharmaceutical research 20(10):1607–1611</i> 2003 (<a href=\"https://doi.org/10.1023/a:1026187301648\">doi:10.1023/a:1026187301648</a>) — P-gp-mediated efflux component of the compound transported through the rat BBB [pmol s -1 g -1] against vinblastine M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        8.8 pmol s -1 g -1 maximal effect term (V max, Q323)
  EC50  =       71.3 M        exposure at half of the maximal effect term (IC 50, Q322)
  gamma =        1.7          Hill coefficient (Hill slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of vinblastine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (71.3 M)  response -4.4
  exposure -> infinity  response -8.8</pre></body></html>"));
end Vinblastine_Cisternino2003_PD_j_efflux;
