function p = Vinblastine_Cisternino2003_PD_j_efflux_params()
% Vinblastine_Cisternino2003_PD_j_efflux_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vinblastine Cisternino_2003::J_efflux: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response J_efflux in pmol s -1 g -1. Driver: vinblastine (cited_pk).
p.E0 = 0.0;
p.Emax = -8.8;
p.EC50 = 71.3;
p.gamma = 1.7;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 720.0;
p.form = 'E0 + Emax*frac';
end
