function p = Vinblastine_Zhou1990_first_exponential_at1_2_g_ml_h_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vinblastine   source: Zhou_1990 / first_exponential_at1_2_g_ml_h   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vinblastine_Zhou1990_first_exponential_at1_2_g_ml_h_params';
  p.drug  = 'vinblastine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4900.0;                % central volume [L]
  p.CL = 46.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.17;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
