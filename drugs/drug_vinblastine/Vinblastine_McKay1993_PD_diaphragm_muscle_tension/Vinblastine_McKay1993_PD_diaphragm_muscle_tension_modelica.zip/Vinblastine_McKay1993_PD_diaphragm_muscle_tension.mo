model Vinblastine_McKay1993_PD_diaphragm_muscle_tension
  "sigmoid_emax exposure-response sweep — McKay_1993 :: diaphragm muscle tension (diaphragm muscle tension)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.00061,  // [kg; g × 0.001]
    EC50 = 88,  // [pM]
    gamma = 1,
    exposure_per_s = 1);   // 1 pM per second
  // exposure_unit_unresolved: 'pM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 880, Interval = 1.76),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vinblastine</h4><p>Vinblastine, a Vinca alkaloid, is a cancer medicine used against tumours such as Hodgkin's lymphoma, breast, testicular and kidney cancer, Kaposi's sarcoma, and also certain blood and immune disorders. It remains an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q282629\">Wikidata Q282629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Vinblastine_McKay1993_PD_diaphragm_muscle_tension</h4><p>The steady-state exposure-response curve of McKay DB et al., <i>Proceedings of the Society for Experimental Biology and Medicine. Society for Experimental Biology and Medicine (New York, N.Y.) 203(3):372–376</i> 1993 (<a href=\"https://doi.org/10.3181/00379727-203-43614\">doi:10.3181/00379727-203-43614</a>) — diaphragm muscle tension [g] against vinblastine pM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.61 g        maximal effect term (Emax, Q320)
  EC50  =         88 pM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pM of vinblastine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (88 pM)  response 0.000305
  exposure -> infinity  response 0.00061</pre></body></html>"));
end Vinblastine_McKay1993_PD_diaphragm_muscle_tension;
