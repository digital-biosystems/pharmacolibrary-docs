function p = Vinblastine_Nelson1982_vinblastine_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vinblastine   source: Nelson_1982 / vinblastine   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Vinblastine_Nelson1982_vinblastine_params';
  p.drug  = 'vinblastine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 48.72;                % central volume [L]
  p.CL = 51.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
