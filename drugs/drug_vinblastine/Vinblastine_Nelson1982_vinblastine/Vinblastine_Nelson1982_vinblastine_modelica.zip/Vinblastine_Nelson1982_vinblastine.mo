model Vinblastine_Nelson1982_vinblastine
  parameter Real Cl_ref = 1.438888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04872 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8109741,
    adminMass = 2e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vinblastine</h4><p>Vinblastine, a Vinca alkaloid, is a cancer medicine used against tumours such as Hodgkin's lymphoma, breast, testicular and kidney cancer, Kaposi's sarcoma, and also certain blood and immune disorders. It remains an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q282629\">Wikidata Q282629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>patients with cancer</td></tr><tr><td>source_paper:</td><td>Nelson_1982</td></tr><tr><td>measured_compound:</td><td>vinblastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table v</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vinblastine 810.974 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vinblastine</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'vinblastine' subgroup of Nelson_1982 (paper reports 1 populations: vinblastine)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Nelson1982_vinblastine;
