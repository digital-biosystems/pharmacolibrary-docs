model Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi
  "sigmoid_emax exposure-response sweep — Piwnica-Worms_1995 :: Tc-SESTAMIBI (Tc-SESTAMIBI cellular accumulation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -72,  // [fmol (mg of protein)-1 (nM,)-1]
    EC50 = 13,  // [pM]
    gamma = 1.1,
    exposure_per_s = 1);   // 1 pM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'pM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><h4>Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi</h4><p>The steady-state exposure-response curve of Piwnica-Worms D et al., <i>Biochemistry 34(38):12210–12220</i> 1995 (<a href=\"https://doi.org/10.1021/bi00038a015\">doi:10.1021/bi00038a015</a>) — Tc-SESTAMIBI cellular accumulation [fmol (mg of protein)-1 (nM,)-1] against vinblastine pM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         72 fmol (mg of protein)-1 (nM,)-1 maximal effect term (Cmax, Q323)
  EC50  =         13 pM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.1          Hill coefficient (y, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pM of vinblastine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13 pM)  response -36
  exposure -> infinity  response -72</pre></body></html>"));
end Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi;
