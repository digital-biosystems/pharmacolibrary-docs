% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Vinblastine_Zhou1990_estimated_parameters_vt_l_kg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
