model Vinblastine_Zhou1990_estimated_parameters_vt_l_kg
  parameter Real Cl_ref = 1.2833333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.8022000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Zhou_1990</td></tr><tr><td>measured_compound:</td><td>vinblastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('VCR 0.1', value '0.41') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vinblastine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'estimated parameters vt (l/kg)' subgroup of Zhou_1990 (paper reports 3 populations: estimated parameters cls (l/kg), estimated parameters vc (l/h/kg), estimated parameters vt (l/kg))</li><li>gap-filled Q22 (CL) from Levêque_1996's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Petric_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Zhou1990_estimated_parameters_vt_l_kg;
