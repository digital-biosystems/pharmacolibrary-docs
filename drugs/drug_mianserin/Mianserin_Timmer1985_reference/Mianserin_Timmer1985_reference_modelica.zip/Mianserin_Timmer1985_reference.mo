model Mianserin_Timmer1985_reference
  parameter Real Cl_ref = 5.277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.444 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2643648,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mianserin</h4><p>Mianserin is an atypical antidepressant that treats depression. It is given orally in tablets or liquid form. The drug is used in Europe and other territories.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q416701\">Wikidata Q416701</a>, <a href=\"https://en.wikipedia.org/wiki/Mianserin?oldid=1381943240\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mianserin</td></tr><tr><td>population:</td><td>healthy male adults</td></tr><tr><td>source_paper:</td><td>Timmer_1985</td></tr><tr><td>measured_compound:</td><td>mianserin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mianserin 264.365 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2ka  from footnote/prose kept as documentation only (['Timmer_1985:abstract'])</li><li>covariate category for t1/2ka  from footnote/prose kept as documentation only (['Timmer_1985:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mianserin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Mianserin_Timmer1985_reference;
