function p = Mianserin_Timmer1985_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mianserin   source: Timmer_1985 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Mianserin_Timmer1985_reference_params';
  p.drug  = 'mianserin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 444.0;                % central volume [L]
  p.CL = 19.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.22;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
