model IndocyanineGreen_Han2025_reference
  parameter Real Cl_ref = 1.6666666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00273 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.77497,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About indocyanine_green</h4><p>Indocyanine green is a diagnostic dye used to assess liver function and cardiac output and in angiography. It has been withdrawn from use, though it remains approved for some purposes.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q905662\">Wikidata Q905662</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>indocyanine_green</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Han_2025</td></tr><tr><td>measured_compound:</td><td>indocyanine_green</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>indocyanine_green 774.97 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Han_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end IndocyanineGreen_Han2025_reference;
