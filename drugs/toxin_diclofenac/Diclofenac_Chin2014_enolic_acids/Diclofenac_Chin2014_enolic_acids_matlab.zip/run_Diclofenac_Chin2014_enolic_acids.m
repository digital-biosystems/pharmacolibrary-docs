% Run: build params, simulate 0..120.0 h, plot every molecule + save Diclofenac_Chin2014_enolic_acids.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Diclofenac_Chin2014_enolic_acids.m
here = fileparts(mfilename('fullpath'));
p = Diclofenac_Chin2014_enolic_acids_params();
out = simulate_network(p, 0:0.05:120.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('diclofenac — Chin_2014 (retention function)');
print(fig, fullfile(here, 'Diclofenac_Chin2014_enolic_acids.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Diclofenac_Chin2014_enolic_acids.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Diclofenac_Chin2014_enolic_acids.json'), 'w');
try
  s.model = 'Diclofenac_Chin2014_enolic_acids'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Diclofenac_Chin2014_enolic_acids"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Diclofenac_Chin2014_enolic_acids.png, Diclofenac_Chin2014_enolic_acids.csv, Diclofenac_Chin2014_enolic_acids.json\n');
