model Diclofenac_Kim2021_reference
  parameter Real Cl_ref = 1.1466000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.296147,
    adminMass = 0.00014
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diclofenac</td></tr><tr><td>population:</td><td>Yucatan minipigs</td></tr><tr><td>source_paper:</td><td>Kim_2021</td></tr><tr><td>measured_compound:</td><td>Diclofenac</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0020</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diclofenac 296.147 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'sex / animal no.' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'sex / animal no.' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'sex / animal no.' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'sex / animal no.' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): '0' — extend the ontology if this is a real PK parameter (source ['tbl0020:row3:col1'])</li><li>dropped unlinked row (NIL): '10' — extend the ontology if this is a real PK parameter (source ['tbl0020:row11:col1'])</li><li>dropped unlinked row (NIL): '20' — extend the ontology if this is a real PK parameter (source ['tbl0020:row14:col1'])</li><li>table mostly unlinked (3/4 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q47 ('Kel(1/hr)'=0.227) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('T1/2(hr)'=3.058) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('CL(mL/hr/kg)'=58.968) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Diclofenac</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Kim_2021:other_prose, tbl0020); populations female, male kept as separate records</li><li>gap-filled Q61 (V) from Oliveira_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diclofenac_Kim2021_reference;
