function p = Diclofenac_Kim2021_female_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diclofenac   source: Kim_2021 / female   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Diclofenac_Kim2021_female_params';
  p.drug  = 'diclofenac';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.0;                % central volume [L]
  p.CL = 4.14078;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
