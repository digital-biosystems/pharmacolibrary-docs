// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model TetrabromobisphenolA_Knudsen2014_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {120.0},
    MM = 0.543875,
    adminMass = 0.00175,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetrabromobisphenol_a</td></tr><tr><td>population:</td><td>Female Wistar Han rats</td></tr><tr><td>source_paper:</td><td>Knudsen_2014</td></tr><tr><td>measured_compound:</td><td>Tetrabromobisphenol A</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tbl0015</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Tetrabromobisphenol A 543.875 g/mol (pubchem); tetrabromobisphenol_a 543.875 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q59 ('distribution half-life'=2) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('terminal half-life'=22) from results prose — parameter table was unreadable</li><li>implicit units: 'AUC' → μg·h/mL (from the popPK convention: 'No unit is stated in the provided text for the AUC parameter. Based on population PK conventions, AUC is typically repor')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tetrabromobisphenol A</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Adachi_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end TetrabromobisphenolA_Knudsen2014_reference;
