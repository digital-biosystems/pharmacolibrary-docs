// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model MercuryiiSulfate_Dargan2003_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {180000.0},
    MM = 0.20059,
    adminMass = 0.0002,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mercuryii_sulfate</td></tr><tr><td>population:</td><td>40-year-old man</td></tr><tr><td>source_paper:</td><td>Dargan_2003</td></tr><tr><td>measured_compound:</td><td>Mercury</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>mercuryii_sulfate 296.646 g/mol (pubchem); Mercury 200.59 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'Data set'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li><li>table representations disagree for 'All data'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1900.8));
end MercuryiiSulfate_Dargan2003_reference;
