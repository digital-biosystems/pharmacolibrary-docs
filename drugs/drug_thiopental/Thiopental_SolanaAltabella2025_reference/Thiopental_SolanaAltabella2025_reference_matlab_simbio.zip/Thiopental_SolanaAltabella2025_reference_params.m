function p = Thiopental_SolanaAltabella2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: thiopental   source: Solana-Altabella_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Thiopental_SolanaAltabella2025_reference_params';
  p.drug  = 'thiopental';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 234.132958;                % central volume [L]
  p.CL = 1.97;                % clearance [L/h]
  p.Vp = [219.28];             % peripheral volumes [L]
  p.Q  = [0.56];             % inter-compartmental clearances [L/h]
  p.ka = 1.68;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
