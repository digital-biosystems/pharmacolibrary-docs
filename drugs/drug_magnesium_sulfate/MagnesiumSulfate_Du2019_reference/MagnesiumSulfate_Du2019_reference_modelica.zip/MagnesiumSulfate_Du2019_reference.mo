model MagnesiumSulfate_Du2019_reference
  parameter Real Cl_ref = 1.0333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0154 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.024305,
    adminMass = 1e-05,
    k12 = 6.601731601731602e-05,
    k21 = 5.980392156862745e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About magnesium_sulfate</h4><p>Magnesium sulfate is used as a laxative for constipation, as a magnesium supplement, and in electrolyte solutions; it also acts as an anticonvulsant, antiarrhythmic, analgesic, anesthetic, and tocolytic agent. It is widely used in human medicine and is also an approved veterinary drug, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q288266\">Wikidata Q288266</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>pregnant women with preeclampsia</td></tr><tr><td>source_paper:</td><td>Du_2019</td></tr><tr><td>measured_compound:</td><td>magnesium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1328-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>magnesium 24.305 g/mol (pubchem); magnesium_sulfate 120.368 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q1 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=magnesium</li><li>review gap-fill skipped: this record measures 'magnesium', not magnesium_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_Du2019_reference;
