function p = MagnesiumSulfate_Du2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: magnesium_sulfate   source: Du_2019 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'MagnesiumSulfate_Du2019_reference_params';
  p.drug  = 'magnesium_sulfate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15.4;                % central volume [L]
  p.CL = 3.72;                % clearance [L/h]
  p.Vp = [17.0];             % peripheral volumes [L]
  p.Q  = [3.66];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
