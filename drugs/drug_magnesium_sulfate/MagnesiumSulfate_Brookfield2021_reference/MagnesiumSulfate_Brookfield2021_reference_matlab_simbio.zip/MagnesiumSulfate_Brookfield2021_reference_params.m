function p = MagnesiumSulfate_Brookfield2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: magnesium_sulfate   source: Brookfield_2021 / reference   route: oral
  p.name  = 'MagnesiumSulfate_Brookfield2021_reference_params';
  p.drug  = 'magnesium_sulfate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.9;                % central volume [L]
  p.CL = 3.52;                % clearance [L/h]
  p.Vp = [14.3];             % peripheral volumes [L]
  p.Q  = [3.62];             % inter-compartmental clearances [L/h]
  p.ka = 0.451;                % absorption rate [1/h]
  p.F  = 0.91;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4000.0;             % dose [mg]
end
