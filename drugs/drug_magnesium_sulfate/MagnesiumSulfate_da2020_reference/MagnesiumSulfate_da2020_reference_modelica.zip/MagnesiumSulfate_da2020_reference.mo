model MagnesiumSulfate_da2020_reference
  parameter Real Cl_ref = 3.833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About magnesium_sulfate</h4><p>Magnesium sulfate is used as a laxative for constipation, as a magnesium supplement, and in electrolyte solutions; it also acts as an anticonvulsant, antiarrhythmic, analgesic, anesthetic, and tocolytic agent. It is widely used in human medicine and is also an approved veterinary drug, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q288266\">Wikidata Q288266</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>pregnant women with preeclampsia</td></tr><tr><td>source_paper:</td><td>da_2020</td></tr><tr><td>measured_compound:</td><td>magnesium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>magnesium_sulfate 120.368 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Beta_CL_creatinine_mg_dL', value '0.0279') — already have one for this compound</li><li>dropped duplicate Q61 ('Beta_V_Weith_kg', value '0.0187') — already have one for this compound</li><li>implicit units: 'V_pop' → L (from the paper text: 'The text states: &quot;for V, it was 13.3 L&quot;')</li><li>implicit units: 'CL_pop' → L/h (from the paper text: 'The text states: &quot;The model estimate of the population CL was 1.38 L/h&quot;')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=magnesium</li><li>molar mass: PubChem entry choice failed (JSONDecodeError)</li><li>molar mass: none of 2 PubChem candidate(s) is 'magnesium' (LLM) — left in mass units</li><li>molar mass: none found for 'magnesium' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'magnesium', not magnesium_sulfate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_da2020_reference;
