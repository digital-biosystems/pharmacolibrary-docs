model MagnesiumSulfate_Lu2002_PD_dbp
  "emax exposure-response sweep — Lu_2002 :: DBP (diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -27.8,  // [mm Hg]
    EC50 = 0.88,  // [mol/m3; mmol/L × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mmol/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8.8, Interval = 0.0176),
    Documentation(info = "<html><body><!-- drug-about --><h4>About magnesium_sulfate</h4><p>Magnesium sulfate is used as a laxative for constipation, as a magnesium supplement, and in electrolyte solutions; it also acts as an anticonvulsant, antiarrhythmic, analgesic, anesthetic, and tocolytic agent. It is widely used in human medicine and is also an approved veterinary drug, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q288266\">Wikidata Q288266</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>MagnesiumSulfate_Lu2002_PD_dbp</h4><p>The steady-state exposure-response curve of Lu J et al., <i>Clinical pharmacokinetics 41(13):1105–1113</i> 2002 (<a href=\"https://doi.org/10.2165/00003088-200241130-00007\">doi:10.2165/00003088-200241130-00007</a>) — diastolic blood pressure [mm Hg] against magnesium mmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       27.8 mm Hg    maximal effect term (E(max), Q323)
  EC50  =       0.88 mmol/L   exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mmol/L of magnesium per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.88 mmol/L)  response -13.9
  exposure -> infinity  response -27.8</pre></body></html>"));
end MagnesiumSulfate_Lu2002_PD_dbp;
