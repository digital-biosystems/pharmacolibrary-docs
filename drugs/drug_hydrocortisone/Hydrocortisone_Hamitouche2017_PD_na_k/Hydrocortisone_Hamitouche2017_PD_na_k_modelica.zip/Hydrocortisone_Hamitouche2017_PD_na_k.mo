model Hydrocortisone_Hamitouche2017_PD_na_k
  "indirect_response_i exposure-response sweep — Hamitouche_2017 :: Na/K (urinary sodium/potassium ratio)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.67e-05,  // [kg/m3; μg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 μg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 170, Interval = 0.34),
    Documentation(info = "<html><body><h4>Hydrocortisone_Hamitouche2017_PD_na_k</h4><p>The steady-state exposure-response curve of Hamitouche N et al., <i>The AAPS journal 19(3):727–735</i> 2017 (<a href=\"https://doi.org/10.1208/s12248-016-0041-9\">doi:10.1208/s12248-016-0041-9</a>) — urinary sodium/potassium ratio against hydrocortisone μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       16.7 μg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/L of hydrocortisone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (16.7 μg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Hydrocortisone_Hamitouche2017_PD_na_k;
