% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Piperaquine_Ding2024_nonmem_population_estimates_rse_a_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
