model Piperaquine_Wicha2022_PD_pviable
  "sigmoid_emax exposure-response sweep — Wicha_2022 :: Pviable (viable parasites (parasite burden time course))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.316,  // [1]
    EC50 = -0.355,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = -3.55, Interval = -0.0071),
    Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Piperaquine_Wicha2022_PD_pviable</h4><p>The steady-state exposure-response curve of Wicha SG et al., <i>Antimicrobial agents and chemotherapy 66(11):e0055622</i> 2022 (<a href=\"https://doi.org/10.1128/aac.00556-22\">doi:10.1128/aac.00556-22</a>) — viable parasites (parasite burden time course) against piperaquine (PPQ) nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.316          maximal effect term (INT on Emax of PPQ mediated by AF, Q323)
  EC50  =     -0.355 nM       exposure at half of the maximal effect term (INT on EC50 of PPQ mediated by AF, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of piperaquine (PPQ) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (-0.355 nM)  response -0.158
  exposure -> infinity  response -0.316</pre></body></html>"));
end Piperaquine_Wicha2022_PD_pviable;
