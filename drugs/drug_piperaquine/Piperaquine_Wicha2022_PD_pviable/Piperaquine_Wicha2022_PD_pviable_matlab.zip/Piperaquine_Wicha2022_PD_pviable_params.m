function p = Piperaquine_Wicha2022_PD_pviable_params()
% Piperaquine_Wicha2022_PD_pviable_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% piperaquine Wicha_2022::Pviable: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Pviable in its own unit. Driver: piperaquine (PPQ) (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.316;
p.EC50 = -0.355;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = -3.55;
p.form = 'E0 + Emax*frac';
end
