function p = Piperaquine_Zaloumis2012_po_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: piperaquine   source: Zaloumis_2012 / po   route: oral
  p.name  = 'Piperaquine_Zaloumis2012_po_params';
  p.drug  = 'piperaquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8660.0;                % central volume [L]
  p.CL = 66.0;                % clearance [L/h]
  p.Vp = [24000.0];             % peripheral volumes [L]
  p.Q  = [131.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.717;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 581.0;             % dose [mg]
end
