model Piperaquine_Hughes2022_PD_qtc
  "linear exposure-response sweep — Hughes_2022 :: QTc (Fridericia corrected QTc interval)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 4420000,  // [(1)/(kg/m3); ms per 100 ng/mL × 1e+06]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // slope_unit_assumed: slope unit 'ms per 100 ng/mL' read as response per ng/mL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial medication taken in combination with other drugs to treat malaria. It is given orally in tablet form. The drug is used as a partner component in combination therapies due to resistance to single-drug treatment.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a>, <a href=\"https://en.wikipedia.org/wiki/Piperaquine?oldid=1300830812\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Piperaquine_Hughes2022_PD_qtc</h4><p>The steady-state exposure-response curve of Hughes E et al., <i>Clinical infectious diseases : an official publication of the Infectious Diseases Society of America 75(3):406–415</i> 2022 (<a href=\"https://doi.org/10.1093/cid/ciab965\">doi:10.1093/cid/ciab965</a>) — Fridericia corrected QTc interval [millisecond] against piperaquine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       4.42 ms per 100 ng/mL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of piperaquine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Piperaquine_Hughes2022_PD_qtc;
