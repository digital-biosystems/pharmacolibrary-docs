function p = Piperaquine_Zaloumis2012_art_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: piperaquine   source: Zaloumis_2012 / art   route: oral
  p.name  = 'Piperaquine_Zaloumis2012_art_params';
  p.drug  = 'piperaquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 217.0;                % central volume [L]
  p.CL = 180.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.37;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 581.0;             % dose [mg]
end
