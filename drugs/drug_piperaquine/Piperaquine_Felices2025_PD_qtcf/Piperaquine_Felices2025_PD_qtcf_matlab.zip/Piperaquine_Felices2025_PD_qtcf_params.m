function p = Piperaquine_Felices2025_PD_qtcf_params()
% Piperaquine_Felices2025_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% piperaquine Felices_2025::QTcF: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ΔΔQTcF in msec. Driver: piperaquine (cited_pk).
p.E0 = -0.0032400000000000003;
p.Emax = 0.0257;
p.EC50 = 0.0003;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3000.0;
p.form = 'E0 + Emax*frac';
end
