model Piperaquine_Felices2025_PD_qtcf
  "emax exposure-response sweep — Felices_2025 :: ΔΔQTcF (change from baseline in Fridericia-corrected QT interval (placebo-corrected ΔΔQTcF))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -0.00324,      // [s; msec × 0.001]
    Emax = 0.0257,  // [s; msec × 0.001]
    EC50 = 0.0003,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3000, Interval = 6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Piperaquine_Felices2025_PD_qtcf</h4><p>The steady-state exposure-response curve of Felices M et al., <i>Clinical and translational science 18(7):e70305</i> 2025 (<a href=\"https://doi.org/10.1111/cts.70305\">doi:10.1111/cts.70305</a>) — change from baseline in Fridericia-corrected QT interval (placebo-corrected ΔΔQTcF) [msec] against piperaquine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      -3.24 msec     drug-free response (baseline) (θ0 Intercept: placebo, Day 3, Time 456 h, Q324)
  Emax  =       25.7 msec     maximal effect term (PQP E max, Q320)
  EC50  =        300 ng/mL    exposure at half of the maximal effect term (PQP EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of piperaquine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -0.00324   (drug-free)
  exposure = EC50 (300 ng/mL)  response 0.00961
  exposure -> infinity  response 0.02246</pre></body></html>"));
end Piperaquine_Felices2025_PD_qtcf;
