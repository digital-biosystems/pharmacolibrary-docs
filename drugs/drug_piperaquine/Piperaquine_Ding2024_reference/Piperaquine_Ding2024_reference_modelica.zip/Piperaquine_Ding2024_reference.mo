model Piperaquine_Ding2024_reference
  parameter Real Cl_ref = 1.9416666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 4.24 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.53552,
    adminMass = 4e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>piperaquine</td></tr><tr><td>population:</td><td>African pregnant women with uncomplicated Plasmodium falciparum infections</td></tr><tr><td>source_paper:</td><td>Ding_2024</td></tr><tr><td>measured_compound:</td><td>piperaquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413211-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>piperaquine 535.52 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F (%)' routed out of structural estimates ('CV for IIV (%RSE a )')</li><li>table section iiv: 'VC/F (L)' routed out of structural estimates ('CV for IIV (%RSE a )')</li><li>dropped duplicate Q290 ('Vp1/F (L)', value '3880') — already have one for this compound</li><li>dropped duplicate Q69 ('Q2/F (L/h)', value '103') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Baseline parasites count on F (%)' — extend the ontology if this is a real PK parameter (source ['psp413211-tbl-0003:row12:col1'])</li><li>dropped unlinked row (NIL): 'Dose occasion on F (%)' — extend the ontology if this is a real PK parameter (source ['psp413211-tbl-0003:row13:col1'])</li><li>dropped unlinked row (NIL): 'Day 7 (ng/mL)' — extend the ontology if this is a real PK parameter (source ['psp413211-tbl-0003:row16:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=piperaquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'VC/F (L)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Piperaquine_Ding2024_reference;
