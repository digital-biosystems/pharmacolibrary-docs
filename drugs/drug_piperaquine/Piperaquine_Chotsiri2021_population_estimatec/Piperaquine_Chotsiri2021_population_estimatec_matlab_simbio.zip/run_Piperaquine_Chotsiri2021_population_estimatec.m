% Run (SimBiology): build model + dose, simulate 0..168.0 h, plot.
p = Piperaquine_Chotsiri2021_population_estimatec_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 168.0);
