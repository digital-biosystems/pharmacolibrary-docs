model Piperaquine_Chotsiri2021_reference
  parameter Real Cl_ref = 1.3611111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00891 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.53552,
    adminMass = 4e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>piperaquine</td></tr><tr><td>population:</td><td>pregnant women receiving intermittent preventive treatment for malaria in pregnancy</td></tr><tr><td>source_paper:</td><td>Chotsiri_2021</td></tr><tr><td>measured_compound:</td><td>piperaquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>piperaquine 535.52 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'VC/F (liters)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'VC/F (liters)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'VC/F (liters)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Q2/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Q2/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Q2/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iov: 'MTT (h)' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table section iov: 'MTT (h)' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table section iov: 'MTT (h)' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table section iov: 'F' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table section iov: 'F' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table section iov: 'F' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table representations disagree for 'MTT (h)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Piperaquine_Chotsiri2021_reference;
