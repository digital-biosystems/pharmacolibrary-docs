model Ciprofloxacin_Guo2022_reference
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061200000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0004,
    k12 = 0.00020379448075526509,
    k21 = 0.00017419304779639976
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>intensive care (ICU) patients</td></tr><tr><td>source_paper:</td><td>Guo_2022</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Posterior mean / Study 1' — extend the ontology if this is a real PK parameter (source ['Guo_2022_table_3:row1:col1'])</li><li>dropped unlinked row (NIL): 'Posterior mean / Study 2' — extend the ontology if this is a real PK parameter (source ['Guo_2022_table_3:row1:col2'])</li><li>dropped unlinked row (NIL): 'Posterior mean / CV (%)' — extend the ontology if this is a real PK parameter (source ['Guo_2022_table_3:row1:col4', 'Guo_2022_table_3:row2:col4', 'Guo_2022_table_3:row3:col4'])</li><li>table mostly unlinked (3/4 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q22 ('CL'=14.7) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V1'=61.2) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q (inter-compartmental clearance)'=44.9) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2'=71.6) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Guo_2022:other_prose, Guo_2022:results_prose, Guo_2022_table_3); populations base model, final model kept as separate records</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Guo2022_reference;
