function p = Ciprofloxacin_Van2023_febrile_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Van_2023 / febrile   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Van2023_febrile_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 161.0;                % central volume [L]
  p.CL = 12.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
