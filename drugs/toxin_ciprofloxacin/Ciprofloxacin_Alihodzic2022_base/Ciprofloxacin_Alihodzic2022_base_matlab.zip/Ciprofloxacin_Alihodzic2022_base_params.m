function p = Ciprofloxacin_Alihodzic2022_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Alihodzic_2022 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Alihodzic2022_base_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 73.2;                % central volume [L]
  p.CL = 13.6;                % clearance [L/h]
  p.Vp = [88.3];             % peripheral volumes [L]
  p.Q  = [39.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
