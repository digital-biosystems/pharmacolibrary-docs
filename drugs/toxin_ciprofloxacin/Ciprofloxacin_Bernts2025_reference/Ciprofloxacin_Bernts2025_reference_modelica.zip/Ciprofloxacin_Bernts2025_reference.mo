model Ciprofloxacin_Bernts2025_reference
  parameter Real Cl_ref = 3.5833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.112 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0008
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>patients with non-infected liver cysts undergoing percutaneous drainage</td></tr><tr><td>source_paper:</td><td>Bernts_2025</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkae394-T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'clinical breakpoint' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Ciprofloxacin (200 mg, half-dose)'; source reconciliation required</li><li>column 'clinical breakpoint' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Ciprofloxacin (200 mg, half-dose)'; source reconciliation required</li><li>column 'ecoff' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Ciprofloxacin (200 mg, half-dose)'; source reconciliation required</li><li>column 'ecoff' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Ciprofloxacin (200 mg, half-dose)'; source reconciliation required</li><li>table representations disagree for 'Ciprofloxacin (200 mg, half-dose)'; source reconciliation required</li><li>table representations disagree for 'Ciprofloxacin (200 mg, half-dose)'; source reconciliation required</li><li>column 'clinical breakpoint' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Escherichia coli'; source reconciliation required</li><li>column 'ecoff' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Escherichia coli'; source reconciliation required</li><li>column 'clinical breakpoint' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Enterobacter cloacae'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Bernts2025_reference;
