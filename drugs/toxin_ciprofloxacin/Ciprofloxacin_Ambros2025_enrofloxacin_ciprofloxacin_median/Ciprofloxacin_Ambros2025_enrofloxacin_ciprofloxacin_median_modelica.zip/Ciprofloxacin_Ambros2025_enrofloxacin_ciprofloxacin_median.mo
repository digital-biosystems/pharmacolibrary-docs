model Ciprofloxacin_Ambros2025_enrofloxacin_ciprofloxacin_median
  parameter Real Cl_ref = 3.5833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0008
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>pregnant goats</td></tr><tr><td>source_paper:</td><td>Ambros_2025</td></tr><tr><td>measured_compound:</td><td>enrofloxacin and ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>vetsci-12-00588-t001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '7.5 mg/kg/day IV' — extend the ontology if this is a real PK parameter (source ['Ambros_2025_table_2:row1:col5'])</li><li>covariate level '7.5 mg/kg/day IM' → Q900:7.5_mg_kg_day_im = 19.74 (linear_fractional on the model)</li><li>covariate level '10 mg/kg/day IM' → Q900:10_mg_kg_day_im = 25.72 (linear_fractional on the model)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=enrofloxacin and ciprofloxacin</li><li>topology: prose indicates saturable/MM/TMDD/time-varying kinetics — manual_model_class</li><li>template fit: none — nonlinear / manual model class</li><li>pharmacogenetic covariate '7.5_mg_kg_day_im' (im) — PGx domain</li><li>pharmacogenetic covariate '10_mg_kg_day_im' (im) — PGx domain</li><li>status held at route_to_review — not promoted</li><li>population split: 'enrofloxacin + ciprofloxacin / median' subgroup of Ambros_2025 (paper reports 3 populations: enrofloxacin + ciprofloxacin / median, enrofloxacin / median, estimate)</li><li>row roles (LLM): model_class=compartmental; 0/20 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'enrofloxacin' — its concentrations stay mass-only</li><li>molar mass: none found for 'enrofloxacin and ciprofloxacin' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Alihodzic_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Alihodzic_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Ambros2025_enrofloxacin_ciprofloxacin_median;
