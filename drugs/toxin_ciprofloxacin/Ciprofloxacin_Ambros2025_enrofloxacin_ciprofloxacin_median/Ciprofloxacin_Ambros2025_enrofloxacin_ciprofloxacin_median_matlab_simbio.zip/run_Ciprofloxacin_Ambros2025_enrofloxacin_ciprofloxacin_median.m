% Run (SimBiology): build model + dose, simulate 0..44.0 h, plot.
p = Ciprofloxacin_Ambros2025_enrofloxacin_ciprofloxacin_median_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 44.0);
