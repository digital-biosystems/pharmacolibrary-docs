function p = Ciprofloxacin_ma2021_early_phase_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Šíma_2021 / early_phase   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_ma2021_early_phase_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 136.9;                % central volume [L]
  p.CL = 18.59;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
