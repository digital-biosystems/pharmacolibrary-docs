model Ciprofloxacin_Abdulla2020_reference
  parameter Real Cl_ref = 7.055555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0911 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0004,
    k12 = 0.00028021709964629835,
    k21 = 0.00015565718157181573
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>critically ill adult ICU patients</td></tr><tr><td>source_paper:</td><td>Abdulla_2020</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vc' routed out of structural estimates ('IIV (%)')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual variability (%)')</li><li>table section residual_error: 'Additional' routed out of structural estimates ('Residual variability (%)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Abdulla2020_reference;
