model Ciprofloxacin_Gieling2020_reference
  parameter Real Cl_ref = 5.63888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06720000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0008,
    k12 = 0.00023644179894179894,
    k21 = 0.000170481640438722
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>adult intensive care unit (critically ill) patients receiving intravenous ciprofloxacin</td></tr><tr><td>source_paper:</td><td>Gieling_2020</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table S1 (pharmacokinetic parameter estimates of the base and final model)</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIVCL (%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIVV1 (%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIVV2 (%)' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iov: 'IOVCL (%)' routed out of structural estimates ('Inter-occasion variability (IOV)')</li><li>table section iov: 'Residual variability (%)' routed out of structural estimates ('Inter-occasion variability (IOV)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Gieling2020_reference;
