function p = Ciprofloxacin_Gieling2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Gieling_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Gieling2020_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 67.2;                % central volume [L]
  p.CL = 20.3;                % clearance [L/h]
  p.Vp = [93.2];             % peripheral volumes [L]
  p.Q  = [57.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
