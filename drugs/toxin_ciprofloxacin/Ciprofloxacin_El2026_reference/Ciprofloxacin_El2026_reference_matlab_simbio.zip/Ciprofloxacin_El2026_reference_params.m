function p = Ciprofloxacin_El2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: El_2026 / reference   route: oral
  p.name  = 'Ciprofloxacin_El2026_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 247.0;                % central volume [L]
  p.CL = 14.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
