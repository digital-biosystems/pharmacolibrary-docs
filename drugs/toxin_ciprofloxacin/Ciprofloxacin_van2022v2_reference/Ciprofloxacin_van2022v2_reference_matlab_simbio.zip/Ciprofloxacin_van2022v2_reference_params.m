function p = Ciprofloxacin_van2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: van_2022_2 / reference   route: oral
  p.name  = 'Ciprofloxacin_van2022v2_reference_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 69.0;                % central volume [L]
  p.CL = 33.2;                % clearance [L/h]
  p.Vp = [140.0];             % peripheral volumes [L]
  p.Q  = [71.4];             % inter-compartmental clearances [L/h]
  p.ka = 1.35;                % absorption rate [1/h]
  p.F  = 0.603;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
