model Ciprofloxacin_van2022v2_reference
  parameter Real Cl_ref = 9.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.069 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.603,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.001,
    ka = 0.000375,
    Tlag = 0.0,
    k12 = 0.00028743961352657005,
    k21 = 0.00014166666666666668
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>adult patients with haematological malignancies and healthy volunteers</td></tr><tr><td>source_paper:</td><td>van_2022_2</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkac283-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLc' routed out of structural estimates ('Interindividual variability (%)b')</li><li>table section iiv: 'Vcc' routed out of structural estimates ('Interindividual variability (%)b')</li><li>table section iiv: 'MTTc' routed out of structural estimates ('Interindividual variability (%)b')</li><li>table section residual_error: 'σpropd' routed out of structural estimates ('Residual error (%)b')</li><li>dropped duplicate Q81 ('Relative MTT', value '2.07') — already have one for this compound</li><li>unit_dimension_unknown: 'n' (n_transit)</li><li>covariate category for MTT from footnote/prose kept as documentation only (['dkac283-T2:footnote'])</li><li>NIL: refused to back-fill base 'shrinkage' from footnote/prose loose number 11 (source ['dkac283-T2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_van2022v2_reference;
