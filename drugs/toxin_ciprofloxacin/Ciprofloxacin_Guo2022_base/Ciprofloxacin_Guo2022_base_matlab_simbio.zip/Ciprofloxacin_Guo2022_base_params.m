function p = Ciprofloxacin_Guo2022_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ciprofloxacin   source: Guo_2022 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ciprofloxacin_Guo2022_base_params';
  p.drug  = 'ciprofloxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 61.7;                % central volume [L]
  p.CL = 15.2;                % clearance [L/h]
  p.Vp = [72.1];             % peripheral volumes [L]
  p.Q  = [44.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
