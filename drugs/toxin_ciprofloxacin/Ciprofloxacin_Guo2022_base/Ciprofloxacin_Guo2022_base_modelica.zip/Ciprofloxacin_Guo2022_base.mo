model Ciprofloxacin_Guo2022_base
  parameter Real Cl_ref = 4.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061700000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0004,
    k12 = 0.00019944174320187284,
    k21 = 0.0001706734473724765
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>intensive care (ICU) patients</td></tr><tr><td>source_paper:</td><td>Guo_2022</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'AddStudy1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'PropStudy1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'PropStudy2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'PropStudy3' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li><li>model-stage split: 'base model' is the base model of Guo_2022 (paper reports 2 stages: base model, final model); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Guo2022_base;
