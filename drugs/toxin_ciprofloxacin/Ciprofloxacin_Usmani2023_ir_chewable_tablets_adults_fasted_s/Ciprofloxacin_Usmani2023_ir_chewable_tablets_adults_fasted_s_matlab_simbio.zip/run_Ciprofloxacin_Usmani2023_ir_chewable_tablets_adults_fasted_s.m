% Run (SimBiology): build model + dose, simulate 0..44.0 h, plot.
p = Ciprofloxacin_Usmani2023_ir_chewable_tablets_adults_fasted_s_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 44.0);
