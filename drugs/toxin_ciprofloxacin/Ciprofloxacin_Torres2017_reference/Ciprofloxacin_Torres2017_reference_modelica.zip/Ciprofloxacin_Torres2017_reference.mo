model Ciprofloxacin_Torres2017_reference
  parameter Real Cl_ref = 1.2502777777777779e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0008
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>healthy and P. aeruginosa biofilm lung-infected Wistar rats</td></tr><tr><td>source_paper:</td><td>Torres_2017</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q17 ('area under the concentration-time curve from time zero to infinity (healthy)', value 13.3) — already have one for this compound</li><li>unit_dimension_unknown: 'infected' (Kp)</li><li>unit_dimension_unknown: 'healthy' (Kp)</li><li>dropped duplicate Q410 ('lung penetration factor (healthy)', value 1.69) — already have one for this compound</li><li>unit_dimension_unknown: 'lower in infected animals' (CL)</li><li>dropped duplicate Q22 ('Plasma clearance (lower in infected animals)', value 32) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Alihodzic_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Alihodzic_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Torres2017_reference;
