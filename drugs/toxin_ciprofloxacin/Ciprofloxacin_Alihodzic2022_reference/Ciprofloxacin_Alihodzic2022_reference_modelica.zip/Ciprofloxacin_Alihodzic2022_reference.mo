model Ciprofloxacin_Alihodzic2022_reference
  parameter Real Cl_ref = 3.5833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0734 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.331347,
    adminMass = 0.0008,
    k12 = 0.00014683620950650922,
    k21 = 0.0001230339928970066
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>critically ill adults undergoing extracorporeal membrane oxygenation (ECMO)</td></tr><tr><td>source_paper:</td><td>Alihodzic_2022</td></tr><tr><td>measured_compound:</td><td>Ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00965-t002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.347 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'COV_CL_BICARB'</li><li>dropped value-less row: 'COV_CL_eGFR'</li><li>salvaged Q63 ('V1'=73.4) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2'=87.6) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q'=38.8) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ciprofloxacin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Alihodzic_2022:results_prose, pharmaceutics-14-00965-t002:footnote); populations base model / estimate, final model / estimate kept as separate records</li><li>gap-filled Q22 (CL) from Alihodzic_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Alihodzic2022_reference;
