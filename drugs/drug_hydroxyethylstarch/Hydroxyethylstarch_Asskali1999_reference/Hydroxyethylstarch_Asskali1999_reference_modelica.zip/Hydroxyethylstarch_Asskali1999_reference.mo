model Hydroxyethylstarch_Asskali1999_reference
  parameter Real Cl_ref = 6.055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0217 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxyethylstarch</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Asskali_1999</td></tr><tr><td>measured_compound:</td><td>hydroxyethyl starch</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroxyethyl starch</li><li>gap-filled Q22 (CL) from Goutelle_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Haefliger_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxyethylstarch_Asskali1999_reference;
