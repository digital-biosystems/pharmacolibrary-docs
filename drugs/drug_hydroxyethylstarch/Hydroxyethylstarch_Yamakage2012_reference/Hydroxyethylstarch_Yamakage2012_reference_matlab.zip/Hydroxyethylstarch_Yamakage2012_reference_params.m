function p = Hydroxyethylstarch_Yamakage2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxyethylstarch   source: Yamakage_2012 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Hydroxyethylstarch_Yamakage2012_reference_params';
  p.drug  = 'hydroxyethylstarch';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.7;                % central volume [L]
  p.CL = 2.18;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
