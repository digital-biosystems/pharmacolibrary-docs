model Celecoxib_Hannam2023_reference
  parameter Real Cl_ref = 1.3611111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.34600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>celecoxib</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Hannam_2023</td></tr><tr><td>measured_compound:</td><td>celecoxib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 4</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'TF'</li><li>dropped unlinked row (NIL): 'Plasma RUV_PROP (%)' — extend the ontology if this is a real PK parameter (source ['Hannam_2023_table_p5_2:row3:col1'])</li><li>dropped duplicate Q75 ('CSF RUV_ADO (µg˙L−1)', value '10.4') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CSF RUV_PROP (%)' — extend the ontology if this is a real PK parameter (source ['Hannam_2023_table_p5_2:row5:col1'])</li><li>dropped value-less row: 'Agut'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'T LAG'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'Keq'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'Cp'</li><li>dropped value-less row: 'CCSF'</li><li>salvaged Q22 ('Estimated celecoxib clearance'=49) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=346) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=celecoxib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Celecoxib_Hannam2023_reference;
