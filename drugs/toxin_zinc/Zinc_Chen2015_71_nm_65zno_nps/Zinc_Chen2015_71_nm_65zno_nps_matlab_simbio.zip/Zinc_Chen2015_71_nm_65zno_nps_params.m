function p = Zinc_Chen2015_71_nm_65zno_nps_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zinc   source: Chen_2015 / 71_nm_65zno_nps   route: oral
  % estimated (absent from source): ka, F, dose
  p.name  = 'Zinc_Chen2015_71_nm_65zno_nps_params';
  p.drug  = 'zinc';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.69;                % central volume [L]
  p.CL = 4.4394;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
