model Zinc_Choi2014_70_nm
  parameter Real Cl_ref = 1.2331666666666663e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00469 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zinc</td></tr><tr><td>population:</td><td>male rats</td></tr><tr><td>source_paper:</td><td>Choi_2014</td></tr><tr><td>measured_compound:</td><td>zinc oxide nanoparticles</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zinc 65.38 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Zeta potential (mV)' — extend the ontology if this is a real PK parameter (source ['Choi_2014_table_1:row2:col4'])</li><li>'Oral absorption (2,000 mg/kg, female, %)' → Q40: printed without a unit and above 1 — read as a percentage</li><li>dropped unlinked row (NIL): 'Excretion via urine/feces (2,000 mg/kg)' — extend the ontology if this is a real PK parameter (source ['Choi_2014_table_1:row2:col8'])</li><li>dropped unlinked row (NIL): 'Reference' — extend the ontology if this is a real PK parameter (source ['Choi_2014_table_1:row2:col9'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=zinc oxide nanoparticles</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: '70 nm' subgroup of Choi_2014 (paper reports 4 populations: (japan), 20 nm, 70 nm, elements (usa))</li><li>molar mass: none found for 'zinc oxide nanoparticles' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Gheidari_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Gheidari_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Gheidari_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zinc_Choi2014_70_nm;
