model Zinc_Tran2004_reference
  parameter Real Cl_ref = 1.2331666666666663e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00469 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zinc</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Tran_2004</td></tr><tr><td>measured_compound:</td><td>zinc (Zn isotopes, incl. iv 67Zn tracer)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zinc 65.38 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'AZ at doses of 5.2 mg ingested Zn' — extend the ontology if this is a real PK parameter (source ['Tran_2004:abstract'])</li><li>dropped duplicate Q91 ('AZ at doses of 30.1 mg ingested Zn', value 11.2) — already have one for this compound</li><li>dropped duplicate Q40 ('maximum zinc absorption', value 13) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=zinc (Zn isotopes, incl. iv 67Zn tracer)</li><li>molar mass: none found for 'zinc (Zn isotopes, incl. iv 67Zn tracer)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Gheidari_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Gheidari_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Gheidari_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zinc_Tran2004_reference;
