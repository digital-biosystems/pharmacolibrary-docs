// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Zinc_Gestin2022_cd_52_1_27_3_ng_l_1_median
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {499065.97000316065},
    MM = 0.06538,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zinc</td></tr><tr><td>population:</td><td>adult Gammarus fossarum (freshwater amphipod), organ-level (intestines, caeca, cephalon, remaining tissues, gills)</td></tr><tr><td>source_paper:</td><td>Gestin_2022</td></tr><tr><td>measured_compound:</td><td>Zinc</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>zinc 65.38 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Caeca' — extend the ontology if this is a real PK parameter (source ['Gestin_2022_table_1:row1:col3', 'Gestin_2022_table_1:row6:col3', 'Gestin_2022_table_1:row11:col3'])</li><li>dropped duplicate Q47 ('Cephalons', value '0.009') — already have one for this compound</li><li>dropped duplicate Q47 ('Gills', value '0.42') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zinc</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>amount-only peripheral compartment: a peripheral output rate (kout_peripheral) is present with no reported volume — model its AMOUNT; concentration is not identifiable without an assumed volume</li><li>population split: '[cd] = 52.1 ± 27.3 ng.l-1 median' subgroup of Gestin_2022 (paper reports 2 populations: [cd] = 52.1 ± 27.3 ng.l-1 median, [zn] = 416 ± 264 ng.l-1 median)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Gheidari_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 6048.0));
end Zinc_Gestin2022_cd_52_1_27_3_ng_l_1_median;
