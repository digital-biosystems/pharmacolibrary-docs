model Zinc_Chen2015_10_nm_65zno_nps
  parameter Real Cl_ref = 1.2331666666666663e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00469 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zinc</td></tr><tr><td>population:</td><td>mice (ICR, NHRI Taiwan)</td></tr><tr><td>source_paper:</td><td>Chen_2015</td></tr><tr><td>measured_compound:</td><td>65Zn (radiolabeled zinc) in ZnO NPs and Zn2+ fraction</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ts4-ijn-10-6277</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zinc 65.38 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'pKi' — extend the ontology if this is a real PK parameter (source ['Chen_2015_table_8:row2:col1'])</li><li>dropped duplicate Q410 ('pSp', value '1.54') — already have one for this compound</li><li>dropped duplicate Q410 ('pLu', value '1.25') — already have one for this compound</li><li>dropped duplicate Q410 ('pHe', value '1.25') — already have one for this compound</li><li>dropped duplicate Q410 ('pGI', value '0.63') — already have one for this compound</li><li>dropped duplicate Q410 ('pBr', value '1.42') — already have one for this compound</li><li>dropped duplicate Q410 ('pCa', value '0.96') — already have one for this compound</li><li>dropped duplicate Q410 ('kLi', value '0.0192') — already have one for this compound</li><li>dropped duplicate Q410 ('kKi', value '0.0319') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=65Zn (radiolabeled zinc) in ZnO NPs and Zn2+ fraction</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: '10 nm 65zno nps' subgroup of Chen_2015 (paper reports 3 populations: 10 nm 65zno nps, 71 nm 65zno nps, value)</li><li>molar mass: none found for '65Zn (radiolabeled zinc) in ZnO NPs and Zn2+ fraction' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Gheidari_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Gheidari_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zinc_Chen2015_10_nm_65zno_nps;
