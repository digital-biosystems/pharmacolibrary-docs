% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Zinc_Chen2015_10_nm_65zno_nps_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
