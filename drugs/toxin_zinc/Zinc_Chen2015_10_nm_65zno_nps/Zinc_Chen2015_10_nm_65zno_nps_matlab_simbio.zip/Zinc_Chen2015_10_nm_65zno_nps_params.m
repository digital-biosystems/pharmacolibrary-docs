function p = Zinc_Chen2015_10_nm_65zno_nps_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zinc   source: Chen_2015 / 10_nm_65zno_nps   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Zinc_Chen2015_10_nm_65zno_nps_params';
  p.drug  = 'zinc';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.69;                % central volume [L]
  p.CL = 4.4394;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
