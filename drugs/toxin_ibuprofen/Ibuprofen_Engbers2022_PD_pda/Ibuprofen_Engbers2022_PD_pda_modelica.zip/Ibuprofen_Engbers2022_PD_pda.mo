model Ibuprofen_Engbers2022_PD_pda
  "log_linear exposure-response sweep — Engbers_2022 :: PDA (Patent Ductus Arteriosus (PDA) closure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = -300   "[1]";
equation
  response = E0 + slope*log(exposure);
  // slope_unit_assumed: slope unit '(none)' read as response per mg/L
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Ibuprofen_Engbers2022_PD_pda</h4><p>The steady-state exposure-response curve of Engbers AGJ et al., <i>Clinical pharmacology and therapeutics 112(2):307–315</i> 2022 (<a href=\"https://doi.org/10.1002/cpt.2616\">doi:10.1002/cpt.2616</a>) — Patent Ductus Arteriosus (PDA) closure against ibuprofen mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -0.3          change in response per unit of exposure (Coefficient for PNAstart (Complete population), Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one mg/L of ibuprofen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Ibuprofen_Engbers2022_PD_pda;
