function p = Ibuprofen_Engbers2022_PD_pda_params()
% Ibuprofen_Engbers2022_PD_pda_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibuprofen Engbers_2022::PDA: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PDA in its own unit. Driver: ibuprofen (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -300.00000000000006;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
