% run_Monobutylphthalate_Chu2021_PD_emps  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Monobutylphthalate_Chu2021_PD_emps_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [urinary concentrations]'); ylabel('response []'); title('Monobutylphthalate_Chu2021_PD_emps', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Monobutylphthalate_Chu2021_PD_emps.csv');
