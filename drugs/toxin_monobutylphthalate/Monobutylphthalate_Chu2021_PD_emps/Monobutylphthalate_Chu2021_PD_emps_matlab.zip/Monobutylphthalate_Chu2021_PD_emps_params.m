function p = Monobutylphthalate_Chu2021_PD_emps_params()
% Monobutylphthalate_Chu2021_PD_emps_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% monobutylphthalate Chu_2021::EMPs: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one urinary concentrations per second, in SI inside (kg/m3, s). Response EMPs in its own unit. Driver: monobutylphthalate (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.007;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
