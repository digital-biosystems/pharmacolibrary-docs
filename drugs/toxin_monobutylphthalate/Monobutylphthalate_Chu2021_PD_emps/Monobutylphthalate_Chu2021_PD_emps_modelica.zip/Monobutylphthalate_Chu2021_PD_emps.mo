model Monobutylphthalate_Chu2021_PD_emps
  "linear exposure-response sweep — Chu_2021 :: EMPs (serum endothelial microparticles level (EMPs))"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.007,  // [1]
    exposure_per_s = 1);   // 1 urinary concentrations per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Monobutylphthalate_Chu2021_PD_emps</h4><p>The steady-state exposure-response curve of Chu PC et al., <i>Toxics 9(2)</i> 2021 (<a href=\"https://doi.org/10.3390/toxics9020033\">doi:10.3390/toxics9020033</a>) — serum endothelial microparticles level (EMPs) against monobutylphthalate urinary concentrations — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.007          change in response per unit of exposure (beta, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one urinary concentrations of monobutylphthalate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Monobutylphthalate_Chu2021_PD_emps;
