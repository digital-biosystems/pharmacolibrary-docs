model Aprepitant_Nijstad2023_reference
  parameter Real Cl_ref = 1.6194444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0868 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.534432,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aprepitant</h4><p>Aprepitant is an antiemetic (an NK1 receptor antagonist) used to prevent nausea and vomiting, including chemotherapy-induced and postoperative nausea and vomiting. It is authorised in the European Union and is widely used, mainly in cancer care to help control vomiting caused by treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q621834\">Wikidata Q621834</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aprepitant</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Nijstad_2023</td></tr><tr><td>measured_compound:</td><td>aprepitant</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aprepitant 534.432 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q73 ('Effect of suspension on MAT', value '0.606') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=aprepitant</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Aprepitant_Nijstad2023_reference;
