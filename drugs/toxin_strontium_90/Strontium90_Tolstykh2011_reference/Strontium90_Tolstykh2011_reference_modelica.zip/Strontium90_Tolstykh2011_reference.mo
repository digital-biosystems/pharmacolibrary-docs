// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Strontium90_Tolstykh2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {781216480.9013761},
    MM = 0.08762,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>strontium_90</td></tr><tr><td>population:</td><td>adult persons from Techa Riverside residents</td></tr><tr><td>source_paper:</td><td>Tolstykh_2011</td></tr><tr><td>measured_compound:</td><td>Strontium-90</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Strontium-90 87.62 g/mol (pubchem); strontium_90 87.62 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'Cortical bone resorption rate (year⁻¹)' Q100 → Q47: a rate constant in 'year⁻¹' (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'RBM dose, 1950–1985 (Gy)' — extend the ontology if this is a real PK parameter (source ['Tolstykh_2011_table_4:row3:col2', 'Tolstykh_2011_table_4:row4:col2', 'Tolstykh_2011_table_4:row5:col2'])</li><li>dropped unlinked row (NIL): 'RBM dose, 1950–WBCᵃ (Gy)' — extend the ontology if this is a real PK parameter (source ['Tolstykh_2011_table_4:row6:col2', 'Tolstykh_2011_table_4:row7:col2', 'Tolstykh_2011_table_4:row8:col2'])</li><li>dropped unlinked row (NIL): 'BS dose, 1950–1985 (Gy)' — extend the ontology if this is a real PK parameter (source ['Tolstykh_2011_table_4:row9:col2', 'Tolstykh_2011_table_4:row10:col2', 'Tolstykh_2011_table_4:row11:col2'])</li><li>unit_dimension_unknown: 'kBq' (body_burden)</li><li>implicit units: '⁹⁰Sr-body burden, 1985 (kBq)' — the LLM proposed 'kBq', whose dimension does not fit Q414; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Strontium-90</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Strontium90_Tolstykh2011_reference;
