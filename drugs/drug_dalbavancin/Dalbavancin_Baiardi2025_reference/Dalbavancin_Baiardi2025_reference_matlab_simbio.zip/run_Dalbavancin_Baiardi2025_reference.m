% Run (SimBiology): build model + dose, simulate 0..480.0 h, plot.
p = Dalbavancin_Baiardi2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 480.0);
