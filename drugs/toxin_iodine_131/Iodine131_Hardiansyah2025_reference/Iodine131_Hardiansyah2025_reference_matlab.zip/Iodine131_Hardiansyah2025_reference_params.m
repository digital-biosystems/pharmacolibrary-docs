function p = Iodine131_Hardiansyah2025_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: iodine_131   source: Hardiansyah_2025 / reference   TK_Retention retention function, 3 pools (V = 1 L each: A/V = burden in mg)
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
  p.name  = 'Iodine131_Hardiansyah2025_reference_params';
  p.drug  = 'iodine_131';
  p.kind  = 'network';
  p.template = 'TK_Retention';
  p.states = {'pool_1', 'pool_2', 'pool_3'};
  p.V = [1.0, 1.0, 1.0];          % compartment volumes [L]
  p.K = [-10.0, 0.0, 0.0;
         0.0, -11.999999999999998, 0.0;
         0.0, 0.0, -15.0];
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;
  p.dose_into = [1.0, 2.0, 3.0];   % pools
  p.dose_frac = [0.3333333333333333, 0.3333333333333333, 0.3333333333333333];   % fraction A_i of the intake
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 10.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0, 3.0];
  p.out_names = {'burden_pool_1', 'burden_pool_2', 'burden_pool_3'};
  p.out_labels = {'burden of pool_1 (mg; A = 0.333333, Tb = 0.00288811 d)', 'burden of pool_2 (mg; A = 0.333333, Tb = 0.00240676 d)', 'burden of pool_3 (mg; A = 0.333333, Tb = 0.00192541 d)'};
end
