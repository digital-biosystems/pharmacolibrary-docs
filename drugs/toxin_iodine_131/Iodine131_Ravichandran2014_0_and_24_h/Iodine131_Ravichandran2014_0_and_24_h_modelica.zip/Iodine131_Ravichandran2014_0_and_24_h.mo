// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Iodine131_Ravichandran2014_0_and_24_h
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {72000.0},
    MM = 0.1269,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>iodine_131</td></tr><tr><td>population:</td><td>patients treated with RA131I for differentiated thyroid cancer</td></tr><tr><td>source_paper:</td><td>Ravichandran_2014</td></tr><tr><td>measured_compound:</td><td>Iodine-131</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T7</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Iodine-131 126.9 g/mol (pubchem); iodine_131 261.812 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Calculated T1/2eff (h) values from combination of exposure rates at different intervals of time: Stop hormone group (h)', value '78') — already have one for this compound</li><li>dropped duplicate Q57 ('T1/2eff (h) estimates from semi-log plot [Figure.1]: rhTSH group (h)', value '12.0') — already have one for this compound</li><li>dropped duplicate Q57 ('T1/2eff (h) estimates from semi-log plot [Figure.1]: Stop hormone group (h)', value '16.5') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Iodine-131</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: '0 and 24 h' subgroup of Ravichandran_2014 (paper reports 6 populations: 0 and 24 h, 0 and 48 h, 0 and 72 h, 24 and 48 h, 24 and 72 h, 48 and 72 h)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ly_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Iodine131_Ravichandran2014_0_and_24_h;
