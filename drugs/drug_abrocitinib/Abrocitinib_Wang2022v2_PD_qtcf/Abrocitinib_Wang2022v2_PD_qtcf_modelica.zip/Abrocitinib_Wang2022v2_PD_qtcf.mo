model Abrocitinib_Wang2022v2_PD_qtcf
  "linear exposure-response sweep — Wang_2022_2 :: ∆QTcF (change from baseline in Fridericia-corrected QT (∆QTcF))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = -6.2e-06,      // [s; ms × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0026   "[ms/[ng/mL]]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About abrocitinib</h4><p>Abrocitinib is a protein kinase inhibitor used to treat atopic dermatitis. It is authorised in the European Union as a dermatological medicine for dermatitis and is in approved use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76656815\">Wikidata Q76656815</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Abrocitinib_Wang2022v2_PD_qtcf</h4><p>The steady-state exposure-response curve of Wang X et al., <i>Clinical pharmacology in drug development 11(9):1036–1045</i> 2022 (<a href=\"https://doi.org/10.1002/cpdd.1111\">doi:10.1002/cpdd.1111</a>) — change from baseline in Fridericia-corrected QT (∆QTcF) [milliseconds] against abrocitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =    -0.0062 ms       drug-free response (baseline) (intercept, Q324)
  slope =     0.0026 ms/[ng/mL] change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of abrocitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -6.2e-06   (drug-free)</pre></body></html>"));
end Abrocitinib_Wang2022v2_PD_qtcf;
