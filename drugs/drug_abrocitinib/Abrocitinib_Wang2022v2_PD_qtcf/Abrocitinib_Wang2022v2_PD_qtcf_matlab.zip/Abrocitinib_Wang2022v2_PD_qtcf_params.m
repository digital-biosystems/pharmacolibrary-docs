function p = Abrocitinib_Wang2022v2_PD_qtcf_params()
% Abrocitinib_Wang2022v2_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% abrocitinib Wang_2022_2::QTcF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ∆QTcF in milliseconds. Driver: abrocitinib (cited_pk).
p.E0 = -6.2e-06;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0026;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
