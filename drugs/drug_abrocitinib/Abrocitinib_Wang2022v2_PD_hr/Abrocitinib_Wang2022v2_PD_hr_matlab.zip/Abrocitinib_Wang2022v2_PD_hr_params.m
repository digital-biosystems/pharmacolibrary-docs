function p = Abrocitinib_Wang2022v2_PD_hr_params()
% Abrocitinib_Wang2022v2_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% abrocitinib Wang_2022_2::HR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ∆HR in bpm. Driver: abrocitinib (cited_pk).
p.E0 = -0.669;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0031;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
