function p = GammaAminobutyricAcid_Valk2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gamma_aminobutyric_acid   source: Valk_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'GammaAminobutyricAcid_Valk2021_reference_params';
  p.drug  = 'gamma_aminobutyric_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 257.6;                % central volume [L]
  p.CL = 117.0;                % clearance [L/h]
  p.Vp = [30.1];             % peripheral volumes [L]
  p.Q  = [105.42];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
