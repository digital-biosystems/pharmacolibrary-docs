function p = GammaAminobutyricAcid_Thorpy2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gamma_aminobutyric_acid   source: Thorpy_2020 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'GammaAminobutyricAcid_Thorpy2020_reference_params';
  p.drug  = 'gamma_aminobutyric_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 562.651066;                % central volume [L]
  p.CL = 19.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
