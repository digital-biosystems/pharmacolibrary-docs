model Acenocoumarol_Daemen1986_reference
  parameter Real Cl_ref = 1.3333333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 3.5945 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acenocoumarol</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Daemen_1986</td></tr><tr><td>measured_compound:</td><td>S(-)-acenocoumarol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>acenocoumarol 353.33 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('AC clearance, conscious state', value 4.9) — already have one for this compound</li><li>dropped duplicate Q22 ('AC clearance, pentobarbitone anaesthesia', value 3.4) — already have one for this compound</li><li>dropped duplicate Q22 ('ICG clearance, hypothermia', value 0.9) — already have one for this compound</li><li>dropped duplicate Q22 ('AC clearance, hypothermia', value 2.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=S(-)-acenocoumarol</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>molar mass: none found for 'S(-)-acenocoumarol' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Martin-Suarez_2003's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Martin-Suarez_2003 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Acenocoumarol_Daemen1986_reference;
