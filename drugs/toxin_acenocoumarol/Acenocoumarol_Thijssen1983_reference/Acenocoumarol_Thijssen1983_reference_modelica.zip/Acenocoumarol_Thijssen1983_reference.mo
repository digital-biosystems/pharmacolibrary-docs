// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Acenocoumarol_Thijssen1983_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {12960.0},
    MM = 0.35333,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acenocoumarol</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Thijssen_1983</td></tr><tr><td>measured_compound:</td><td>acenocoumarol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>acenocoumarol 353.33 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'half-life of elimination of the compound (drug)' Q47 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('half-life of elimination of the compound (drug)', value 3.3) — already have one for this compound</li><li>relinked 'half-life of elimination of the compound (AA derivative)' Q47 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('half-life of elimination of the compound (AA derivative)', value 4) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life of elimination of the compound (AM)', value 8) — already have one for this compound</li><li>unit_dimension_unknown: 'drug' (fu)</li><li>dropped duplicate Q46 ('% free (AM)', value 2.84) — already have one for this compound</li><li>unit_dimension_unknown: 'AA derivative' (fu)</li><li>dropped duplicate Q46 ('% free (AA derivative)', value 3.89) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acenocoumarol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/7 row label(s) assigned, 0 linked by role</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Acenocoumarol_Thijssen1983_reference;
