function p = Cemiplimab_Nguyen2022_tumor_type_study_a_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cemiplimab   source: Nguyen_2022 / tumor_type_study_a   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cemiplimab_Nguyen2022_tumor_type_study_a_params';
  p.drug  = 'cemiplimab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.89;                % central volume [L]
  p.CL = 0.01025;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
