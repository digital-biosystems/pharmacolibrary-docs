// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ExotoxinAPseudomonasAeruginosa_Benhar1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1380.0000000000002},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>exotoxin_a_pseudomonas_aeruginosa</td></tr><tr><td>population:</td><td>athymic nude mice bearing human epidermoid carcinoma xenografts</td></tr><tr><td>source_paper:</td><td>Benhar_1995</td></tr><tr><td>measured_compound:</td><td>B1(Fv)PE38 and B1(dsFv)PE38 immunotoxins in blood</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life in the blood of mice of B1(dsFv)PE38 (disulfide-stabilized)', value 27) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=B1(Fv)PE38 and B1(dsFv)PE38 immunotoxins in blood</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'exotoxin_a_pseudomonas_aeruginosa' — its concentrations stay mass-only</li><li>molar mass: none found for 'B1(Fv)PE38 and B1(dsFv)PE38 immunotoxins in blood' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'B1(Fv)PE38 and B1(dsFv)PE38 immunotoxins in blood', not exotoxin_a_pseudomonas_aeruginosa — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end ExotoxinAPseudomonasAeruginosa_Benhar1995_reference;
