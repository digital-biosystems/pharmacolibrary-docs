function p = ExotoxinAPseudomonasAeruginosa_LiuChittenden2015_c2d1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: exotoxin_a_pseudomonas_aeruginosa   source: Liu-Chittenden_2015 / c2d1   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'ExotoxinAPseudomonasAeruginosa_LiuChittenden2015_c2d1_params';
  p.drug  = 'exotoxin_a_pseudomonas_aeruginosa';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.078;                % central volume [L]
  p.CL = 5.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.07;             % dose [mg]
end
