// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ExotoxinAPseudomonasAeruginosa_Kuan1994_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4320.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>exotoxin_a_pseudomonas_aeruginosa</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Kuan_1994</td></tr><tr><td>measured_compound:</td><td>Pseudomonas exotoxin A (PE-Cys(R313C), PEGylated and unmodified)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'mean residence time (t 1/2)' Q53 → Q57: a half-life by its label (the unit decides, not the label)</li><li>relinked 'mean residence time (t 1/2) for unpolyethylene glycolated PE-Cys(R313C)' Q53 → Q57: a half-life by its label (the unit decides, not the label)</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Kuan_1994:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pseudomonas exotoxin A (PE-Cys(R313C), PEGylated and unmodified)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/2 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'Pseudomonas exotoxin A (PE)' — its concentrations stay mass-only</li><li>molar mass: none found for 'mPEG (5-kDa and 20-kDa) conjugated PE-Cys' — its concentrations stay mass-only</li><li>molar mass: none found for 'Pseudomonas exotoxin A (PE-Cys(R313C), PEGylated and unmodified)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end ExotoxinAPseudomonasAeruginosa_Kuan1994_reference;
