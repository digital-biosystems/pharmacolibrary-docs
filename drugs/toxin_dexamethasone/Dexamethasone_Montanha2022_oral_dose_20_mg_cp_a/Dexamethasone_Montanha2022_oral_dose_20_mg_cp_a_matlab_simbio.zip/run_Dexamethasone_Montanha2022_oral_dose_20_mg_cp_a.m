% Run (SimBiology): build model + dose, simulate 0..2520.0 h, plot.
p = Dexamethasone_Montanha2022_oral_dose_20_mg_cp_a_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2520.0);
