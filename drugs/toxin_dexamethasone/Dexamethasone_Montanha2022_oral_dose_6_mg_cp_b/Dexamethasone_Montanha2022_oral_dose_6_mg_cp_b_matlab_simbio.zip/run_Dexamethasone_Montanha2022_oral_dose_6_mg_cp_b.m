% Run (SimBiology): build model + dose, simulate 0..3024.0 h, plot.
p = Dexamethasone_Montanha2022_oral_dose_6_mg_cp_b_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3024.0);
