model Dexamethasone_wierczek2023_PD_tnf
  "indirect_response_i exposure-response sweep — Świerczek_2023 :: TNFα (TNFα)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.09e-08,      // [kg/m3; pg/mL × 1e-09]
    Emax = 0.805,  // type I effect term
    EC50 = 2.25e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 23, Interval = 0.046),
    Documentation(info = "<html><body><h4>Dexamethasone_wierczek2023_PD_tnf</h4><p>The steady-state exposure-response curve of Świerczek A et al., <i>Clinical and translational science 16(9):1667-1679</i> 2023 (<a href=\"https://doi.org/10.1111/cts.13577\">doi:10.1111/cts.13577</a>) — TNFα [pg/mL] against dexamethasone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       10.9 pg/mL    drug-free response (baseline) (Baseline plasma TNFα concentration, Q324)
  Emax  =      0.805          maximal effect term (Maximum inhibition of TNFα production by DEX, Q323)
  EC50  =       2.25 ng/mL    exposure at half of the maximal effect term (DEX plasma concentration resulting in 50% of I maxDEX(TNF), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of dexamethasone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.09e-08   (drug-free)
  exposure = EC50 (2.25 ng/mL)  response 6.513e-09
  exposure -> infinity  response 2.125e-09</pre></body></html>"));
end Dexamethasone_wierczek2023_PD_tnf;
