model Dexamethasone_Otani2024_PD_m
  "linear exposure-response sweep — Otani_2024 :: M (Serum M-protein)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 23.4,      // [kg/m3; g/dL × 10]
    slope = 2592000000,  // [second / kilogram; day/mg × 8.64e+10]
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Dexamethasone_Otani2024_PD_m</h4><p>The steady-state exposure-response curve of Otani Y et al., <i>CPT: pharmacometrics &amp; systems pharmacology 13(12):2124-2136</i> 2024 (<a href=\"https://doi.org/10.1002/psp4.13225\">doi:10.1002/psp4.13225</a>) — Serum M-protein [g/dL] against dexamethasone mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       2.34 g/dL     drug-free response (baseline) (Baseline M-protein (M0), Q324)
  slope =       0.03 day/mg   change in response per unit of exposure (k dex, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/day of dexamethasone per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 23.4   (drug-free)</pre></body></html>"));
end Dexamethasone_Otani2024_PD_m;
