function p = Dexamethasone_Otani2024_PD_m_params()
% Dexamethasone_Otani2024_PD_m_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Otani_2024::M: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response M in g/dL. Driver: dexamethasone (dose_only).
p.E0 = 23.399999999999995;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2592000000.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
