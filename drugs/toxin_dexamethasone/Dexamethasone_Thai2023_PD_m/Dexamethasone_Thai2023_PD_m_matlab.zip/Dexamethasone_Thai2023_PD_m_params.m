function p = Dexamethasone_Thai2023_PD_m_params()
% Dexamethasone_Thai2023_PD_m_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Thai_2023::M: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mol/L per second, in SI inside (kg/m3, s). Response M in g/L. Driver: dexamethasone (cited_pk).
p.E0 = 26.999999999999996;
p.Emax = 1.0;
p.EC50 = 1129.9999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1000.0;
p.stop_time = 12.0;
p.form = 'E0*(1 - Emax*frac)';
end
