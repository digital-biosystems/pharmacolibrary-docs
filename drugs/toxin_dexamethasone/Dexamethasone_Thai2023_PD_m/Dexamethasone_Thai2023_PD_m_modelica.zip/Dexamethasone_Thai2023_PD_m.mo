model Dexamethasone_Thai2023_PD_m
  "indirect_response_i exposure-response sweep — Thai_2023 :: M (Serum M-protein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 27,      // [kg/m3; g/L × 1]
    Emax = 1,  // type I effect term
    EC50 = 1130,  // [mol/m3; mol/L × 1000]
    gamma = 1,
    exposure_per_s = 1000);   // 1 mol/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><h4>Dexamethasone_Thai2023_PD_m</h4><p>The steady-state exposure-response curve of Thai HT et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(12):1846-1858</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12947\">doi:10.1002/psp4.12947</a>) — Serum M-protein [g/L] against dexamethasone mol/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         27 g/L      drug-free response (baseline) (M0 (g/L), Q324)
  Emax  = (library default) maximal effect term
  EC50  =       1.13 mol/L    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mol/L of dexamethasone per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 27   (drug-free)
  exposure = EC50 (1.13 mol/L)  response 13.5
  exposure -> infinity  response 0</pre></body></html>"));
end Dexamethasone_Thai2023_PD_m;
