model Dexamethasone_Li2023_PD_crp
  "indirect_response_ii exposure-response sweep — Li_2023 :: CRP (C-reactive protein)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 59.4303797468,      // [mg/L]
    Emax = 3.63,  // type IV effect term
    EC50 = 0.000398,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.939/0.0158 = 59.43) — the paper's stated baseline may differ
  // emax_not_a_fraction: type II needs Imax ≤ 1 but the record has 3.63; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 860, Interval = 1.72),
    Documentation(info = "<html><body><h4>Dexamethasone_Li2023_PD_crp</h4><p>The steady-state exposure-response curve of Li L et al., 2023 (<a href=\"https://doi.org/10.2139/ssrn.4463680\">doi:10.2139/ssrn.4463680</a>) — C-reactive protein [mg/L] against dexamethasone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 59.4303797468 mg/L     drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       3.63          maximal effect term (Imax, Q323)
  EC50  =        398 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of dexamethasone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 59.43   (drug-free)
  exposure = EC50 (398 ng/mL)  response 21.11
  exposure -> infinity  response 12.84</pre></body></html>"));
end Dexamethasone_Li2023_PD_crp;
