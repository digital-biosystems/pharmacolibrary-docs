function p = Dexamethasone_Li2023_PD_crp_params()
% Dexamethasone_Li2023_PD_crp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Li_2023::CRP: indirect_response_ii exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response CRP in mg/L. Driver: dexamethasone (pk_record).
p.E0 = 59.430379746835435;
p.Emax = 3.63;
p.EC50 = 0.00039799999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 860.0;
p.form = 'E0/(1 + Emax*frac)';
end
