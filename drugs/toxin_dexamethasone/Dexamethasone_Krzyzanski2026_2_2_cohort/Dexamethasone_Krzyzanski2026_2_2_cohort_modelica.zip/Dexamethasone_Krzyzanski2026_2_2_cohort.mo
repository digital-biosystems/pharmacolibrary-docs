model Dexamethasone_Krzyzanski2026_2_2_cohort
  parameter Real Cl_ref = 8.694444444444444e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0029 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392467,
    adminMass = 8e-06,
    ka = 8.946759259259258e-06,
    Tlag = 1044.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>Parturient women and their fetuses</td></tr><tr><td>source_paper:</td><td>Krzyzanski_2026</td></tr><tr><td>measured_compound:</td><td>Dexamethasone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Dexamethasone 392.467 g/mol (pubchem); Dexamethasone phosphate 472.446 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is dexamethasone; the compartment is Dexamethasone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Dexamethasone, not dexamethasone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>dexamethasone's own concentration-time course is not produced by this model</li><li>dropped diagnostic row 'S.R.%' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>routed '\\:{\\omega\\:}_{CL} log(L/h)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed '\\:{\\omega\\:}_{V}, log(L)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): '\\:{\\omega\\:}_{CL} log(L)' — extend the ontology if this is a real PK parameter (source ['Krzyzanski_2026_table_1:row2:col4'])</li><li>routed '\\:{\\omega\\:}_{V}, log(L/h)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped value-less row: 'S.R.'</li><li>dropped value-less row: 'NA'</li><li>implicit units: '\\:{\\theta\\:}_{V} L' → L (from the paper text: &quot;The table header explicitly lists the column as '\\:{\\theta\\:}_{V} L'.&quot;)</li><li>metabolite dexamethasone: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite volume: '\\:{\\theta\\:}_{V} L' Q63→Q61 for Dexamethasone — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Dexamethasone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Krzyzanski2026_2_2_cohort;
