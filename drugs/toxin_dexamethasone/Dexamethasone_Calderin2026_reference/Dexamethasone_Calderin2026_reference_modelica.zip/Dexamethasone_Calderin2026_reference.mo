model Dexamethasone_Calderin2026_reference
  parameter Real Cl_ref = 3.638888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392467,
    adminMass = 1.5e-06,
    ka = 0.00011027777777777779,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>adults with HIV-associated tuberculous meningitis</td></tr><tr><td>source_paper:</td><td>Calderin_2026</td></tr><tr><td>measured_compound:</td><td>Dexamethasone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ciaf642-T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dexamethasone 392.467 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Clearance with lopinavir/ritonavir-based ART (L/h)', value '11.5') — already have one for this compound</li><li>routed 'Between-subject variability in clearance (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Between-occasion variability in first-order absorption rate constant (%)' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 45 (source ['ciaf642-T2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dexamethasone</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Calderin2026_reference;
