model Dexamethasone_Song2024_PD_cort
  "indirect_response_i exposure-response sweep — Song_2024 :: Cort (Cortisol (Cort))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.829e-05,      // [mol/m3; nmol/L × 1e-06]
    Emax = 1,  // type I effect term
    EC50 = 0.0573,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.58, Interval = 0.00116),
    Documentation(info = "<html><body><h4>Dexamethasone_Song2024_PD_cort</h4><p>The steady-state exposure-response curve of Song L et al., <i>ACS pharmacology &amp; translational science 7(6):1770–1782</i> 2024 (<a href=\"https://doi.org/10.1021/acsptsci.3c00391\">doi:10.1021/acsptsci.3c00391</a>) — Cortisol (Cort) [nmol/L] against dexamethasone nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      18.29 nmol/L   drug-free response (baseline) (Cortbl, Q324)
  Emax  = (library default) maximal effect term
  EC50  =     0.0573 nM       exposure at half of the maximal effect term (IC50Cort, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of dexamethasone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.829e-05   (drug-free)
  exposure = EC50 (0.0573 nM)  response 9.145e-06
  exposure -> infinity  response 0</pre></body></html>"));
end Dexamethasone_Song2024_PD_cort;
