function p = Dexamethasone_Song2024_PD_cort_params()
% Dexamethasone_Song2024_PD_cort_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Song_2024::Cort: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Cort in nmol/L. Driver: dexamethasone (pk_record).
p.E0 = 1.829e-05;
p.Emax = 1.0;
p.EC50 = 0.0573;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.58;
p.form = 'E0*(1 - Emax*frac)';
end
