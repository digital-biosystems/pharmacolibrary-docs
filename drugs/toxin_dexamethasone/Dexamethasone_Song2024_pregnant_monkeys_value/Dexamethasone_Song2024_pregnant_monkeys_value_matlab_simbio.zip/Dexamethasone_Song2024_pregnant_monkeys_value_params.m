function p = Dexamethasone_Song2024_pregnant_monkeys_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexamethasone   source: Song_2024 / pregnant_monkeys_value   route: oral
  p.name  = 'Dexamethasone_Song2024_pregnant_monkeys_value_params';
  p.drug  = 'dexamethasone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.97;                % central volume [L]
  p.CL = 25.1;                % clearance [L/h]
  p.Vp = [35.9];             % peripheral volumes [L]
  p.Q  = [19.72];             % inter-compartmental clearances [L/h]
  p.ka = 0.33;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
