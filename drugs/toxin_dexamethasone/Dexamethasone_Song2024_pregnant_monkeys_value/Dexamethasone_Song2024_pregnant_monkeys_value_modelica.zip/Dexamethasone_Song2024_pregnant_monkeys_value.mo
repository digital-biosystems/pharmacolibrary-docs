model Dexamethasone_Song2024_pregnant_monkeys_value
  parameter Real Cl_ref = 6.972222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0039700000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392467,
    adminMass = 5e-06,
    ka = 9.166666666666667e-05,
    Tlag = 0.0,
    k21 = 0.00015258433921386567
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>pregnant sheep and monkeys</td></tr><tr><td>source_paper:</td><td>Song_2024</td></tr><tr><td>measured_compound:</td><td>Dexamethasone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl1</td></tr><tr><td>input:</td><td>PK_3C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dexamethasone 392.467 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL p /F (L/h)', value '23.5') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Dexamethasone</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 3C vs LLM 2C — review compartment count</li><li>population split: 'pregnant monkeys value' subgroup of Song_2024 (paper reports 2 populations: pregnant monkeys value, pregnant sheep value)</li><li>gap-filled Q69 (Q/F) from Świerczek_2023's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Song2024_pregnant_monkeys_value;
