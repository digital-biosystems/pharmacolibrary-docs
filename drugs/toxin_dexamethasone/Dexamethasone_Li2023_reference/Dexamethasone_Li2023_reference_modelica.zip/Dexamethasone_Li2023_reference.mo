model Dexamethasone_Li2023_reference
  parameter Real Cl_ref = 7.916666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0154 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392467,
    adminMass = 1.5e-06,
    ka = 8.946759259259258e-06,
    Tlag = 1044.0,
    k12 = 3.787878787878788e-05,
    k21 = 4.7425474254742554e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>critically ill patients receiving fixed-dose intravenous dexamethasone for the treatment of COVID-19</td></tr><tr><td>source_paper:</td><td>Li_2023</td></tr><tr><td>measured_compound:</td><td>Dexamethasone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dexamethasone 392.467 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dexamethasone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Luo_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Świerczek_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Li2023_reference;
