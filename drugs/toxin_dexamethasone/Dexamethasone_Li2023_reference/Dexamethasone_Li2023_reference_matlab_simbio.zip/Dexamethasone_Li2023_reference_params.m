function p = Dexamethasone_Li2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexamethasone   source: Li_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Dexamethasone_Li2023_reference_params';
  p.drug  = 'dexamethasone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.4;                % central volume [L]
  p.CL = 2.85;                % clearance [L/h]
  p.Vp = [12.3];             % peripheral volumes [L]
  p.Q  = [2.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.29;             % absorption lag [h]
  p.dose = 1.5;             % dose [mg]
end
