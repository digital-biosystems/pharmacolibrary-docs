model Dexamethasone_Krzyzanski2026_reference
  parameter Real Cl_ref = 8.333333333333333e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392467,
    adminMass = 8e-06,
    ka = 0.0008111111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>Parturient women and their fetuses</td></tr><tr><td>source_paper:</td><td>Krzyzanski_2026</td></tr><tr><td>measured_compound:</td><td>Dexamethasone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Dexamethasone 392.467 g/mol (pubchem); Dexamethasone phosphate 472.446 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is dexamethasone; the compartment is Dexamethasone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Dexamethasone, not dexamethasone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>dexamethasone's own concentration-time course is not produced by this model</li><li>dropped value-less row: 'S.R.'</li><li>dropped value-less row: 'NA'</li><li>salvaged Q22 ('CL'=0.3) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V'=3) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F, L'=103) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('ka, 1/h'=2.92) from results prose — parameter table was unreadable</li><li>metabolite dexamethasone: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite dexamethasone: Q61→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite dexamethasone: Q76→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Dexamethasone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Krzyzanski2026_reference;
