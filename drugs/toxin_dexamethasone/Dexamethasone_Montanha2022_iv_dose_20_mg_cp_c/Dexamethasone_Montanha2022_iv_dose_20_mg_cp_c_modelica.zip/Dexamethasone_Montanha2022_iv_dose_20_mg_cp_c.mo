model Dexamethasone_Montanha2022_iv_dose_20_mg_cp_c
  parameter Real Cl_ref = 1.8916666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 7.7853 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.392467,
    adminMass = 6e-06,
    ka = 8.946759259259258e-06,
    Tlag = 1044.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamethasone</td></tr><tr><td>population:</td><td>Adult individuals aged 18-60 years with varying degrees of liver disease (Child-Pugh A, B, C) and healthy controls</td></tr><tr><td>source_paper:</td><td>Montanha_2022</td></tr><tr><td>measured_compound:</td><td>Dexamethasone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dexamethasone 392.467 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '20 mg' (AUC)</li><li>unit_dimension_unknown: '20 mg' (CL)</li><li>implicit units: 'AUC0-24' → ng·h/mL (from the popPK convention: &quot;The paper text states 'plasma concentrations are expressed as unbound in comparison to total plasma concentration' but d&quot;)</li><li>implicit units: 'CL' → L/h (from the popPK convention: &quot;Clearance values in population PK are standardly reported in L/h (or L/h/kg, but the parameter description 'Total cleara&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Dexamethasone</li><li>population split: 'iv dose (20 mg) / cp-c' subgroup of Montanha_2022 (paper reports 12 populations: iv dose (20 mg) / cp-a, iv dose (20 mg) / cp-b, iv dose (20 mg) / cp-c, iv dose (6 mg) / cp-a, iv dose (6 mg) / cp-b, iv dose (6 mg) / cp-c, oral dose (20 mg) / cp-a, oral dose (20 mg) / cp-b, oral dose (20 mg) / cp-c, oral dose (6 mg) / cp-a, oral dose (6 mg) / cp-b, oral dose (6 mg) / cp-c)</li><li>gap-filled Q61 (V) from Baalbaki_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Luo_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Świerczek_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Baalbaki_2023, Luo_2022, Świerczek_2023 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15120000, Tolerance = 1e-9, Interval = 1));
end Dexamethasone_Montanha2022_iv_dose_20_mg_cp_c;
