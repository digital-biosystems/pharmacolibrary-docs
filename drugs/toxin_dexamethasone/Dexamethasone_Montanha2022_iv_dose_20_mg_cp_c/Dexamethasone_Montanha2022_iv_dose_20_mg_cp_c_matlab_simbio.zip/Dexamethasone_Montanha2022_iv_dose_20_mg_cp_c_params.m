function p = Dexamethasone_Montanha2022_iv_dose_20_mg_cp_c_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexamethasone   source: Montanha_2022 / iv_dose_20_mg_cp_c   route: oral
  % estimated (absent from source): F
  p.name  = 'Dexamethasone_Montanha2022_iv_dose_20_mg_cp_c_params';
  p.drug  = 'dexamethasone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7785.3;                % central volume [L]
  p.CL = 6.81;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.29;             % absorption lag [h]
  p.dose = 6.0;             % dose [mg]
end
