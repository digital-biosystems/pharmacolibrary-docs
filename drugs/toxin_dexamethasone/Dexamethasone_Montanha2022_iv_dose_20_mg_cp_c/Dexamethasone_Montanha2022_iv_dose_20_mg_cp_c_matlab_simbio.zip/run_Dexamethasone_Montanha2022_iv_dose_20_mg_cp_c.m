% Run (SimBiology): build model + dose, simulate 0..4200.0 h, plot.
p = Dexamethasone_Montanha2022_iv_dose_20_mg_cp_c_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4200.0);
