function p = BotulinumToxin_Ryu2024_PD_cmap_params()
% BotulinumToxin_Ryu2024_PD_cmap_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% botulinum_toxin Ryu_2024::CMAP: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one U day⁻¹ per second, in SI inside (kg/m3, s). Response CMAP in its own unit. Driver: botulinum_toxin (dose_only).
p.E0 = 98.4;
p.Emax = 1.04;
p.EC50 = 2.056454633963426e-32;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.92192021866e-32;
p.stop_time = 5.3;
p.form = 'E0/(1 + Emax*frac)';
end
