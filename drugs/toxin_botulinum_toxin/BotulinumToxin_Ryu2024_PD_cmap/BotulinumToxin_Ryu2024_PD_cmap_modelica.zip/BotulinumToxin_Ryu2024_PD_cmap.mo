model BotulinumToxin_Ryu2024_PD_cmap
  "indirect_response_i exposure-response sweep — Ryu_2024 :: CMAP (compound muscle action potential)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 98.4,      // [1]
    Emax = 1.04,  // type IV effect term
    EC50 = 2.05645463396e-32,  // [kg/s; U day⁻¹ × 1.92192e-32]
    gamma = 1,
    exposure_per_s = 1.92192021866e-32);   // 1 U day⁻¹ per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 1.04; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.3, Interval = 0.0106),
    Documentation(info = "<html><body><h4>BotulinumToxin_Ryu2024_PD_cmap</h4><p>The steady-state exposure-response curve of Ryu HJ et al., <i>Biopharmaceutics &amp; drug disposition 45(4-6):190-200</i> 2024 (<a href=\"https://doi.org/10.1002/bdd.2398\">doi:10.1002/bdd.2398</a>) — compound muscle action potential against botulinum_toxin U day⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       98.4          drug-free response (baseline) (Base_CMAP, Q324)
  Emax  =       1.04          maximal effect term (Emax_CMAP, Q323)
  EC50  =       1.07 U day⁻¹  exposure at half of the maximal effect term (EDK50_CMAP, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one U day⁻¹ of botulinum_toxin per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 98.4   (drug-free)
  exposure = EC50 (1.07 U day⁻¹)  response 64.74
  exposure -> infinity  response 48.24</pre></body></html>"));
end BotulinumToxin_Ryu2024_PD_cmap;
