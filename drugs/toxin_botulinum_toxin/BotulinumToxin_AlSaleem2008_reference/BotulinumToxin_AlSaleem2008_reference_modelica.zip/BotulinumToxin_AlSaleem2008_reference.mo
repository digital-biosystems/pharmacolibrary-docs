// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model BotulinumToxin_AlSaleem2008_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {36000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>botulinum_toxin</td></tr><tr><td>population:</td><td>naive animals</td></tr><tr><td>source_paper:</td><td>Al-Saleem_2008</td></tr><tr><td>measured_compound:</td><td>Botulinum toxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Botulinum toxin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: no plausible PubChem entry for 'Botulinum toxin' ('Botulinum toxin') — left in mass units</li><li>molar mass: none found for 'botulinum_toxin' — its concentrations stay mass-only</li><li>molar mass: none found for 'Botulinum toxin' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL from Espinoza_2019: its label names a different analyte ('xe-a') — 'Clearance ... overall mean values of 4.21 ... mL/day/kg for XE-a'</li><li>gap-filled Q61 (V) from Tajti_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end BotulinumToxin_AlSaleem2008_reference;
