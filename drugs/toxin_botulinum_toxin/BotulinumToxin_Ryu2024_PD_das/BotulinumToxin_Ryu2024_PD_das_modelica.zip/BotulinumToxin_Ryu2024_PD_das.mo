model BotulinumToxin_Ryu2024_PD_das
  "indirect_response_i exposure-response sweep — Ryu_2024 :: DAS (digit abduction score)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0.00195652173913,      // [1]
    Emax = 3000,  // type IV effect term
    EC50 = 3.42101798921e-31,  // [kg/s; U day⁻¹ × 1.92192e-32]
    gamma = 1,
    exposure_per_s = 1.92192021866e-32);   // 1 U day⁻¹ per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.0054/2.76 = 0.001957) — the paper's stated baseline may differ
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 3000; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 27, Interval = 0.054),
    Documentation(info = "<html><body><h4>BotulinumToxin_Ryu2024_PD_das</h4><p>The steady-state exposure-response curve of Ryu HJ et al., <i>Biopharmaceutics &amp; drug disposition 45(4-6):190-200</i> 2024 (<a href=\"https://doi.org/10.1002/bdd.2398\">doi:10.1002/bdd.2398</a>) — digit abduction score against botulinum_toxin U day⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 0.00195652173913          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       3000          maximal effect term (Emax_DAS, Q323)
  EC50  =       17.8 U day⁻¹  exposure at half of the maximal effect term (EDK50_DAS, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one U day⁻¹ of botulinum_toxin per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.001957   (drug-free)
  exposure = EC50 (17.8 U day⁻¹)  response 1.303e-06
  exposure -> infinity  response 6.52e-07</pre></body></html>"));
end BotulinumToxin_Ryu2024_PD_das;
