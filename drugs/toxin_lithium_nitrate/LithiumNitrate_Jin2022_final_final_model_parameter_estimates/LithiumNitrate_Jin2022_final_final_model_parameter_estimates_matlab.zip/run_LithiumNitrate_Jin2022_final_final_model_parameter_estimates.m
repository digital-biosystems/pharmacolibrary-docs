% Run: build params, simulate 0..42.0 h, plot + save LithiumNitrate_Jin2022_final_final_model_parameter_estimates.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_LithiumNitrate_Jin2022_final_final_model_parameter_estimates.m
here = fileparts(mfilename('fullpath'));
p = LithiumNitrate_Jin2022_final_final_model_parameter_estimates_params();
out = simulate_pk(p, 0:0.05:42.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('lithium_nitrate — Jin_2022 (iv_bolus)');
print(fig, fullfile(here, 'LithiumNitrate_Jin2022_final_final_model_parameter_estimates.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'LithiumNitrate_Jin2022_final_final_model_parameter_estimates.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'LithiumNitrate_Jin2022_final_final_model_parameter_estimates.json'), 'w');
try
  s.model = 'LithiumNitrate_Jin2022_final_final_model_parameter_estimates'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"LithiumNitrate_Jin2022_final_final_model_parameter_estimates","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote LithiumNitrate_Jin2022_final_final_model_parameter_estimates.png, LithiumNitrate_Jin2022_final_final_model_parameter_estimates.csv, LithiumNitrate_Jin2022_final_final_model_parameter_estimates.json\n');
