% Run (SimBiology): build model + dose, simulate 0..42.0 h, plot.
p = LithiumNitrate_Jin2022_final_final_model_parameter_estimates_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 42.0);
