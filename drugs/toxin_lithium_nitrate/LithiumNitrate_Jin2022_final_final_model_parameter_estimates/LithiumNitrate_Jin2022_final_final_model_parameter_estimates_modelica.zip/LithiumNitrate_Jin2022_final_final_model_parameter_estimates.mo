model LithiumNitrate_Jin2022_final_final_model_parameter_estimates
  parameter Real Cl_ref = 2.525e-07 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real cov_crcl_1 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.0109 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.33)*cov_wt_0)*(1 + (0.186)*cov_crcl_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00025
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lithium_nitrate</td></tr><tr><td>population:</td><td>Chinese patients with bipolar disorder</td></tr><tr><td>source_paper:</td><td>Jin_2022</td></tr><tr><td>measured_compound:</td><td>Lithium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lithium_nitrate 69 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (%)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'V(%)' routed out of structural estimates ('Between subject variability')</li><li>table section residual_error: 'additive error (mmol/L)' routed out of structural estimates ('Residual variability')</li><li>unit_dimension_mismatch: 'DD on CL' → Q22 (unit '1 / [time]' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('DD on CL', value '0.354') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lithium</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>model-stage split: 'final model / parameter estimates(rse%)' is the final model of Jin_2022 (paper reports 4 stages: base model / parameter estimates (rse%), base model / parameter estimates(rse%), final model / parameter estimates (rse%), final model / parameter estimates(rse%)); same population, different model-building step</li><li>molar mass: no plausible PubChem entry for 'Lithium' ('lithium') — left in mass units</li><li>molar mass: none found for 'Lithium' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Lithium', not lithium_nitrate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end LithiumNitrate_Jin2022_final_final_model_parameter_estimates;
