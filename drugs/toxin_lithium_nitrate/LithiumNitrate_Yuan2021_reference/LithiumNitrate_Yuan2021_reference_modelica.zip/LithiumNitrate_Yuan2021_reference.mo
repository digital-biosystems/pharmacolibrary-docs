model LithiumNitrate_Yuan2021_reference
  parameter Real Cl_ref = 2.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0131 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.00694,
    adminMass = 0.00084,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lithium_nitrate</td></tr><tr><td>population:</td><td>children with intellectual disability aged 4-10 years old</td></tr><tr><td>source_paper:</td><td>Yuan_2021</td></tr><tr><td>measured_compound:</td><td>lithium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>lithium 6.94 g/mol (pubchem); lithium carbonate 73.888 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is lithium_nitrate; the compartment is lithium. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is lithium, not lithium_nitrate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>lithium_nitrate's own concentration-time course is not produced by this model</li><li>table section iiv: 'F (%)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'MTT (h)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'VC/F (L)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>table section iiv: 'Vp/F (L)' routed out of structural estimates ('CV for IIV (%RSE)')</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'Vc'</li><li>dropped value-less row: 'MTT'</li><li>dropped value-less row: 'Vp'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'a1-a6'</li><li>metabolite lithium: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lithium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end LithiumNitrate_Yuan2021_reference;
