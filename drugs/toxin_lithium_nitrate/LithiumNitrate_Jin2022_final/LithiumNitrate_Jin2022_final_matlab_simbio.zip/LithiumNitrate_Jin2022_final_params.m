function p = LithiumNitrate_Jin2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lithium_nitrate   source: Jin_2022 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'LithiumNitrate_Jin2022_final_params';
  p.drug  = 'lithium_nitrate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.9;                % central volume [L]
  p.CL = 0.909;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
