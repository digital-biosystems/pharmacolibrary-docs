model LithiumNitrate_Jermain1991_reference
  parameter Real Cl_ref = 3.777777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032799999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lithium_nitrate</td></tr><tr><td>population:</td><td>Psychiatric inpatients aged 18 or older with normal renal function</td></tr><tr><td>source_paper:</td><td>Jermain_1991</td></tr><tr><td>measured_compound:</td><td>Lithium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lithium_nitrate 69 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'coefficient of variation for lithium clearance' — extend the ontology if this is a real PK parameter (source ['Jermain_1991:abstract'])</li><li>routed 'coefficient of variation' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lithium</li><li>molar mass: no plausible PubChem entry for 'Lithium' ('Lithium') — left in mass units</li><li>molar mass: none found for 'Lithium' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Lithium', not lithium_nitrate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end LithiumNitrate_Jermain1991_reference;
