model Danaparoid_de1991v2_reference
  parameter Real Cl_ref = 1.2166666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.009800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About danaparoid</h4><p>Danaparoid is an anticoagulant of the heparin group used to prevent and treat blood clots. It was approved at one time but has since been withdrawn and is no longer in general use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q906271\">Wikidata Q906271</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>danaparoid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>de_1991_2</td></tr><tr><td>measured_compound:</td><td>danaparoid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (de_1991_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Danaparoid_de1991v2_reference;
