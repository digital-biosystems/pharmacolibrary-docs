model Ergotamine_Kudupoje2018_PD_norepinephrine_normalized_percent
  "sigmoid_emax exposure-response sweep — Kudupoje_2018 :: Norepinephrine normalized percent contractile response (Norepinephrine normalized percent contractile response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.8847,  // [1; % × 0.01]
    EC50 = 6.66,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 67, Interval = 0.134),
    Documentation(info = "<html><body><h4>Ergotamine_Kudupoje2018_PD_norepinephrine_normalized_percent</h4><p>The steady-state exposure-response curve of Kudupoje MB et al., <i>Toxins 10(2)</i> 2018 (<a href=\"https://doi.org/10.3390/toxins10020058\">doi:10.3390/toxins10020058</a>) — Norepinephrine normalized percent contractile response [%] against ergotamine tartrate M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      88.47 %        maximal effect term (max, Q320)
  EC50  =       6.66 M        exposure at half of the maximal effect term (log of the effective molar concentration (EC50) (-log [ETA]), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of ergotamine tartrate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.66 M)  response 0.4424
  exposure -> infinity  response 0.8847</pre></body></html>"));
end Ergotamine_Kudupoje2018_PD_norepinephrine_normalized_percent;
