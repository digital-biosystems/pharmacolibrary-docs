function p = Ergotamine_Kudupoje2018_PD_norepinephrine_normalized_percent_params()
% Ergotamine_Kudupoje2018_PD_norepinephrine_normalized_percent_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ergotamine Kudupoje_2018::Norepinephrine_normalized_percent_contractile_response: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response Norepinephrine normalized percent contractile response in %. Driver: ergotamine tartrate (not_resolved).
p.E0 = 0.0;
p.Emax = 0.8847;
p.EC50 = 6.66;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 67.0;
p.form = 'E0 + Emax*frac';
end
