model Ergotamine_Ibraheem1982_reference
  parameter Real Cl_ref = 1.2833333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.12933199999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.581673,
    adminMass = 4e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ergotamine</td></tr><tr><td>population:</td><td>migrainous patients</td></tr><tr><td>source_paper:</td><td>Ibraheem_1982</td></tr><tr><td>measured_compound:</td><td>Ergotamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ergotamine 581.673 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'min following administration' (tmax)</li><li>implicit units: 'maximum plasma levels were usually obtained' → h (from the popPK convention: 'Parameter is Tmax (time to maximum concentration). In population pharmacokinetics, time parameters are conventionally re')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ergotamine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ergotamine_Ibraheem1982_reference;
