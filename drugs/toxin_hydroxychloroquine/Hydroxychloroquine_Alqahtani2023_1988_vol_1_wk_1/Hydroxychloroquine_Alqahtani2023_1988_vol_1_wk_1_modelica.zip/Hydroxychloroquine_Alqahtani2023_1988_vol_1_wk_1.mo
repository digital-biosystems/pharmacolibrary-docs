model Hydroxychloroquine_Alqahtani2023_1988_vol_1_wk_1
  parameter Real Cl_ref = 1.0816666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.047299999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33587599999999995,
    adminMass = 0.000155,
    ka = 0.0003194444444444444,
    Tlag = 1400.4
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>healthy adults, liver cirrhosis (CP-A/B/C) and chronic kidney disease patients</td></tr><tr><td>source_paper:</td><td>Alqahtani_2023</td></tr><tr><td>measured_compound:</td><td>Hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-01250-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.876 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'AUC0-t (ng/mL·hr)'; source reconciliation required</li><li>table representations disagree for 'CL(L/h)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hydroxychloroquine</li><li>status held at route_to_review — not promoted</li><li>population split: '1988 vol * 1 wk * 1' subgroup of Alqahtani_2023 (paper reports 5 populations: 1988 vol * 1 wk * 1, 1988 vol 1 wk 4, 1988 vol 2 wk 1, 1988 vol 2 wk 4, input value)</li><li>gap-filled Q61 (V) from Ferreira_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alvarez_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Alvarez_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Alvarez_2022, Ferreira_2021 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Alqahtani2023_1988_vol_1_wk_1;
