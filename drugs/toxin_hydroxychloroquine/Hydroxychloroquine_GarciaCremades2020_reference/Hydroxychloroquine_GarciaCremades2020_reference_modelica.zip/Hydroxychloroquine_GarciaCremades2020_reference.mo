// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Hydroxychloroquine_GarciaCremades2020_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {103791.88284294502},
    MM = 0.33587599999999995,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>patients with SARS-CoV-2 infection receiving hydroxychloroquine</td></tr><tr><td>source_paper:</td><td>Garcia-Cremades_2020</td></tr><tr><td>measured_compound:</td><td>Hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table S1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.876 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'k (d-1) d' Q331 → Q47: a rate constant in 'd-1' (the unit decides, not the label)</li><li>dropped duplicate Q47 ('k (d-1) d', value '0.0631') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hydroxychloroquine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Ferreira_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Alvarez_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Alvarez_2022's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q32 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end Hydroxychloroquine_GarciaCremades2020_reference;
