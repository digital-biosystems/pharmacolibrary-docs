function p = Hydroxychloroquine_Alqahtani2023_1988_vol_1_wk_4_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Alqahtani_2023 / 1988_vol_1_wk_4   route: oral
  % estimated (absent from source): F
  p.name  = 'Hydroxychloroquine_Alqahtani2023_1988_vol_1_wk_4_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.3;                % central volume [L]
  p.CL = 10.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.15;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.389;             % absorption lag [h]
  p.dose = 155.0;             % dose [mg]
end
