% Run: build params, simulate 0..36.0 h, plot + save Hydroxychloroquine_Li2021_hydroxychloroquine.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Hydroxychloroquine_Li2021_hydroxychloroquine.m
here = fileparts(mfilename('fullpath'));
p = Hydroxychloroquine_Li2021_hydroxychloroquine_params();
out = simulate_pk(p, 0:0.05:36.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('hydroxychloroquine — Li_2021 (oral)');
print(fig, fullfile(here, 'Hydroxychloroquine_Li2021_hydroxychloroquine.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Hydroxychloroquine_Li2021_hydroxychloroquine.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Hydroxychloroquine_Li2021_hydroxychloroquine.json'), 'w');
try
  s.model = 'Hydroxychloroquine_Li2021_hydroxychloroquine'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Hydroxychloroquine_Li2021_hydroxychloroquine","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Hydroxychloroquine_Li2021_hydroxychloroquine.png, Hydroxychloroquine_Li2021_hydroxychloroquine.csv, Hydroxychloroquine_Li2021_hydroxychloroquine.json\n');
