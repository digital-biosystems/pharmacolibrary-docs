function p = Hydroxychloroquine_Balevic2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Balevic_2022_2 / reference   route: oral
  p.name  = 'Hydroxychloroquine_Balevic2022v2_reference_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6788.0;                % central volume [L]
  p.CL = 60.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.15;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 516.0;             % dose [mg]
end
