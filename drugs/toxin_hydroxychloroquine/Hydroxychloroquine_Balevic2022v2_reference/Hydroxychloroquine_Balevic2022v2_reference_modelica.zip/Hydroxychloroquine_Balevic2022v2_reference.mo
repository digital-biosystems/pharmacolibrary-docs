// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Hydroxychloroquine_Balevic2022v2_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.001},
    CLelim = {1.6833333333333334e-05},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>children with paediatric systemic lupus erythematosus (pSLE) on standard-of-care hydroxychloroquine</td></tr><tr><td>source_paper:</td><td>Balevic_2022_2</td></tr><tr><td>measured_compound:</td><td>Hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>molar_masses:</td><td>Hydroxychloroquine 335.876 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>compound tags: 21 row(s) → Desethylhydroxychloroquine (DHCQ) (name 21)</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F DHCQ' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section residual_error: 'Proportional error, HCQ (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error, DHCQ (%)' routed out of structural estimates ('Residual error')</li><li>dropped value-less row: 'CL/F, apparent oral clearance; CV, coefficient of variation; DHCQ, desethylhydroxychloroquine; HCQ, hydroxychloroquine; Ka, absorption rate constant; PK, pharmacokinetics; RSE, relative SE; Tlag, lag time after oral administration; V/F, apparent volume of distribution.'</li><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Hydroxychloroquine</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>row roles (LLM): model_class=compartmental; 0/13 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Desethylhydroxychloroquine (DHCQ)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Balevic2022v2_reference;
