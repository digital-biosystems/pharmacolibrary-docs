// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Hydroxychloroquine_Kolli2022_periciliary_layer
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {21060.000000000004},
    MM = 0.33587599999999995,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>healthy humans (PBPK) with supporting isolated rat hepatocytes and mouse peritoneal macrophages</td></tr><tr><td>source_paper:</td><td>Kolli_2022</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.876 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Generic model parameters / Diffusion coefficient, DC (cm2/s)' — extend the ontology if this is a real PK parameter (source ['Kolli_2022_table_1:row9:col9'])</li><li>dropped unlinked row (NIL): 'Generic model parameters / Diffusivity factor, Δs' — extend the ontology if this is a real PK parameter (source ['Kolli_2022_table_1:row9:col11'])</li><li>salvaged Q57 ('terminal half-life (CQ, lysosomal)'=351) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroxychloroquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'periciliary layer' subgroup of Kolli_2022 (paper reports 16 populations: brain, cell, extracellular or basal, gi, hcq, heart, kidney, liver, lysosome, mucus, muscle, periciliary layer, remaining, skin, slow, spleen)</li><li>gap-filled Q22 (CL) from Alvarez_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Ferreira_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alvarez_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Alvarez_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 230.4));
end Hydroxychloroquine_Kolli2022_periciliary_layer;
