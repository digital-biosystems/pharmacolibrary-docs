model Hydroxychloroquine_Zahr2021v2_healthy
  parameter Real Cl_ref = 3.3333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.851 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33587599999999995,
    adminMass = 0.000516,
    ka = 0.0003194444444444444,
    Tlag = 1400.4
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>COVID-19 hospitalized patients</td></tr><tr><td>source_paper:</td><td>Zahr_2021_2</td></tr><tr><td>measured_compound:</td><td>Hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0015</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.876 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Hydroxychloroquine</li><li>population split: 'healthy+' subgroup of Zahr_2021_2 (paper reports 5 populations: covid-19f, estimate, healthy+, lupusa, malariad)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alvarez_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Alvarez_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Zahr2021v2_healthy;
