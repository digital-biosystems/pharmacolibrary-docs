// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Hydroxychloroquine_Kolli2022v2_human_70_kg
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {271440.0},
    MM = 0.33587599999999995,
    adminMass = 0.0002,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>mice, rats and humans (PBPK models); HCQ kinetics in mice and humans</td></tr><tr><td>source_paper:</td><td>Kolli_2022_2</td></tr><tr><td>measured_compound:</td><td>Hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.876 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'human (70 kg)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'human (70 kg)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'human (70 kg)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'human (70 kg)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: '70 kg' (CLR)</li><li>dropped unlinked row (NIL): 'P-gp variant 1' — extend the ontology if this is a real PK parameter (source ['Tab5:row11:col6'])</li><li>unit_dimension_unknown: '70 kg' (kmp)</li><li>dropped value-less row: 'a'</li><li>dropped value-less row: 'b'</li><li>dropped value-less row: 'c'</li><li>dropped value-less row: 'd'</li><li>salvaged Q57 ('terminal elimination half-life (CQ, plasma)'=75.4) from results prose — parameter table was unreadable</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 6 column 4 (char 369)) — units left missing</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hydroxychloroquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 2764.8));
end Hydroxychloroquine_Kolli2022v2_human_70_kg;
