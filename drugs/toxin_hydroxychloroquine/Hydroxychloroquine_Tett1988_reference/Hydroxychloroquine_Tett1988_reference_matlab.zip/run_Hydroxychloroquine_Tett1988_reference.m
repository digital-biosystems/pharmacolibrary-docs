% Run: build params, simulate 0..504.0 h, plot + save Hydroxychloroquine_Tett1988_reference.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Hydroxychloroquine_Tett1988_reference.m
here = fileparts(mfilename('fullpath'));
p = Hydroxychloroquine_Tett1988_reference_params();
out = simulate_pk(p, 0:0.05:504.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('hydroxychloroquine — Tett_1988 (oral)');
print(fig, fullfile(here, 'Hydroxychloroquine_Tett1988_reference.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Hydroxychloroquine_Tett1988_reference.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Hydroxychloroquine_Tett1988_reference.json'), 'w');
try
  s.model = 'Hydroxychloroquine_Tett1988_reference'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Hydroxychloroquine_Tett1988_reference","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Hydroxychloroquine_Tett1988_reference.png, Hydroxychloroquine_Tett1988_reference.csv, Hydroxychloroquine_Tett1988_reference.json\n');
