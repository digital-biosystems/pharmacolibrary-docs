function p = Hydroxychloroquine_Xia2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Xia_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Hydroxychloroquine_Xia2024_reference_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.3;                % central volume [L]
  p.CL = 4.99;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.15;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.389;             % absorption lag [h]
  p.dose = 516.0;             % dose [mg]
end
