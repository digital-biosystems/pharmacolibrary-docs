model DarbepoetinAlfa_Kawakami2009_reference
  parameter Real Cl_ref = 4.388888888888889e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0137 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.0444444444444445e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>darbepoetin_alfa</td></tr><tr><td>population:</td><td>peritoneal dialysis and non-dialysis patients with chronic kidney disease</td></tr><tr><td>source_paper:</td><td>Kawakami_2009</td></tr><tr><td>measured_compound:</td><td>darbepoetin_alfa</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=darbepoetin_alfa</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'apparent volume of central compartment (V(1)/f)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end DarbepoetinAlfa_Kawakami2009_reference;
