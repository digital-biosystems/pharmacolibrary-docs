model DarbepoetinAlfa_Doshi2010_reference
  parameter Real Cl_ref = 3.935185185185185e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005900000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>darbepoetin_alfa</td></tr><tr><td>population:</td><td>anemic patients with chronic kidney disease not receiving dialysis</td></tr><tr><td>source_paper:</td><td>Doshi_2010</td></tr><tr><td>measured_compound:</td><td>darbepoetin_alfa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'drug potency' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Doshi_2010:abstract'])</li><li>dropped unlinked row (NIL): 'efficacy' — extend the ontology if this is a real PK parameter (source ['Doshi_2010:abstract'])</li><li>dropped unlinked row (NIL): 'RBC life span' — extend the ontology if this is a real PK parameter (source ['Doshi_2010:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=darbepoetin_alfa</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end DarbepoetinAlfa_Doshi2010_reference;
