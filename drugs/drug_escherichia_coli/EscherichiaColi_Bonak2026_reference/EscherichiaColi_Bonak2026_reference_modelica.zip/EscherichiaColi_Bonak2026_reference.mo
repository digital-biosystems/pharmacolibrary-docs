model EscherichiaColi_Bonak2026_reference
  parameter Real Cl_ref = 1.325e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09756999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00075,
    ka = 0.0003111111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About escherichia_coli</h4><p>Escherichia coli is classified as an antidiarrheal microorganism, suggesting use for diarrhoea. It is listed as investigational and has no authorised marketing in the European Union.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>escherichia_coli</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Boşnak_2026</td></tr><tr><td>measured_compound:</td><td>escherichia_coli</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Boşnak_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end EscherichiaColi_Bonak2026_reference;
