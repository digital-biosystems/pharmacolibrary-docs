function p = EscherichiaColi_van2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escherichia_coli   source: van_2024 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'EscherichiaColi_van2024_reference_params';
  p.drug  = 'escherichia_coli';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 14.0;                % central volume [L]
  p.CL = 3.69;                % clearance [L/h]
  p.Vp = [21.7];             % peripheral volumes [L]
  p.Q  = [8.45];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
