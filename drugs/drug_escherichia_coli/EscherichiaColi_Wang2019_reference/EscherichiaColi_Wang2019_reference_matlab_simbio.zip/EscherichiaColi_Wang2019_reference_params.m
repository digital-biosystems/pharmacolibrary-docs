function p = EscherichiaColi_Wang2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escherichia_coli   source: Wang_2019 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'EscherichiaColi_Wang2019_reference_params';
  p.drug  = 'escherichia_coli';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 118.3;                % central volume [L]
  p.CL = 17.5;                % clearance [L/h]
  p.Vp = [89.6];             % peripheral volumes [L]
  p.Q  = [11.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 154.0;             % dose [mg]
end
