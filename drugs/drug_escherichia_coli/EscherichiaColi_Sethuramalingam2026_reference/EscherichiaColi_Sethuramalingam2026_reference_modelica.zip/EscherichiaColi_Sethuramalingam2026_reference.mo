model EscherichiaColi_Sethuramalingam2026_reference
  parameter Real Cl_ref = 8.88888888888889e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00561 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escherichia_coli</td></tr><tr><td>population:</td><td>children with newly diagnosed acute lymphoblastic leukemia</td></tr><tr><td>source_paper:</td><td>Sethuramalingam_2026</td></tr><tr><td>measured_compound:</td><td>asparaginase</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '/h' (t1/2ka )</li><li>dropped unlinked row (NIL): 'beta_V_logtBSA' — extend the ontology if this is a real PK parameter (source ['Tab3:row7:col2', 'Tab3:row7:col4'])</li><li>dropped duplicate Q22 ('beta_Cl_logtBSA', value '0.14') — already have one for this compound</li><li>dropped unlinked row (NIL): 'a' — extend the ontology if this is a real PK parameter (source ['Tab3:row14:col1', 'Tab3:row14:col2', 'Tab3:row14:col3', 'Tab3:row14:col4'])</li><li>dropped unlinked row (NIL): 'b' — extend the ontology if this is a real PK parameter (source ['Tab3:row15:col1', 'Tab3:row15:col2', 'Tab3:row15:col3', 'Tab3:row15:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=asparaginase</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end EscherichiaColi_Sethuramalingam2026_reference;
