model Doxylamine_Friedman1989_reference
  parameter Real Cl_ref = 3.183333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.179 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27037599999999995,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxylamine</td></tr><tr><td>population:</td><td>young and elderly healthy volunteers</td></tr><tr><td>source_paper:</td><td>Friedman_1989</td></tr><tr><td>measured_compound:</td><td>doxylamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxylamine 270.376 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'young' — extend the ontology if this is a real PK parameter (source ['Friedman_1989:abstract'])</li><li>dropped unlinked row (NIL): 'elderly' — extend the ontology if this is a real PK parameter (source ['Friedman_1989:abstract'])</li><li>dropped duplicate Q32 ('Cmax [young women]', value 103) — already have one for this compound</li><li>dropped duplicate Q56 ('tmax [young women]', value 2.4) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life [young women]', value 10.1) — already have one for this compound</li><li>dropped duplicate Q61 ('volume of distribution [young women]', value 176) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance [young women]', value 218) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance [elderly men]', value 174) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance [young men]', value 240) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life [elderly men]', value 15.5) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life [young men]', value 10.2) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxylamine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Doxylamine_Friedman1989_reference;
