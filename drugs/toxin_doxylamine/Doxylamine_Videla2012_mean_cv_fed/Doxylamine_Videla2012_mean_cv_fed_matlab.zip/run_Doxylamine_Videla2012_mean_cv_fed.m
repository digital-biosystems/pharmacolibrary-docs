% Run: build params, simulate 0..72.0 h, plot every molecule + save Doxylamine_Videla2012_mean_cv_fed.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Doxylamine_Videla2012_mean_cv_fed.m
here = fileparts(mfilename('fullpath'));
p = Doxylamine_Videla2012_mean_cv_fed_params();
out = simulate_network(p, 0:0.05:72.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('doxylamine — Videla_2012 (retention function)');
print(fig, fullfile(here, 'Doxylamine_Videla2012_mean_cv_fed.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Doxylamine_Videla2012_mean_cv_fed.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Doxylamine_Videla2012_mean_cv_fed.json'), 'w');
try
  s.model = 'Doxylamine_Videla2012_mean_cv_fed'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Doxylamine_Videla2012_mean_cv_fed"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Doxylamine_Videla2012_mean_cv_fed.png, Doxylamine_Videla2012_mean_cv_fed.csv, Doxylamine_Videla2012_mean_cv_fed.json\n');
