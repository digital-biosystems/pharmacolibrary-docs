// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Doxylamine_Balan2013_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {57600.0},
    MM = 0.27037599999999995,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxylamine</td></tr><tr><td>population:</td><td>children ages 2-17 years</td></tr><tr><td>source_paper:</td><td>Balan_2013</td></tr><tr><td>measured_compound:</td><td>doxylamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>doxylamine 270.376 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CLo'</li><li>dropped value-less row: 'Vz /F'</li><li>dropped value-less row: 'Cmax'</li><li>dropped unlinked row (NIL): 'P-value' — extend the ontology if this is a real PK parameter (source ['Balan_2013:abstract'])</li><li>dropped value-less row: 't1/2,z'</li><li>dropped value-less row: 'CLo (allometric scaling)' (captured trailing unit 'allometric scaling' for child rows)</li><li>dropped unlinked row (NIL): 'predicted range' — extend the ontology if this is a real PK parameter (source ['Balan_2013:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxylamine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q88 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Doxylamine_Balan2013_reference;
