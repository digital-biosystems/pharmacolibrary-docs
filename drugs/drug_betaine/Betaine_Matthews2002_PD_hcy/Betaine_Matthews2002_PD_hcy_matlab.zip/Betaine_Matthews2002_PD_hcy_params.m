function p = Betaine_Matthews2002_PD_hcy_params()
% Betaine_Matthews2002_PD_hcy_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% betaine Matthews_2002::HCY: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µmol l⁻¹ per second, in SI inside (kg/m3, s). Response HCY in µmol l⁻¹. Driver: betaine (not_resolved).
p.E0 = 404.25531914893617;
p.Emax = 98.0;
p.EC50 = 0.05199999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 520.0;
p.form = 'E0*(1 + Emax*frac)';
end
