model Betaine_Matthews2002_PD_hcy
  "indirect_response_iii exposure-response sweep — Matthews_2002 :: HCY (plasma total HCY concentration)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 404.255319149,      // [µmol l⁻¹]
    Emax = 98,  // type III effect term
    EC50 = 0.052,  // [mol/m3; µmol l⁻¹ × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µmol l⁻¹ per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (19/0.047 = 404.3) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 520, Interval = 1.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About betaine</h4><p>Betaine is used to treat homocystinuria and also acts as a digestive aid. It is authorised in the European Union for homocystinuria and is also available as a nutraceutical.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q10860583\">Wikidata Q10860583</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Betaine_Matthews2002_PD_hcy</h4><p>The steady-state exposure-response curve of Matthews A et al., <i>British journal of clinical pharmacology 54(2):140–146</i> 2002 (<a href=\"https://doi.org/10.1046/j.1365-2125.2002.01620.x\">doi:10.1046/j.1365-2125.2002.01620.x</a>) — plasma total HCY concentration [µmol l⁻¹] against betaine µmol l⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 404.255319149 µmol l⁻¹ drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =         98          maximal effect term (Emax, Q320)
  EC50  =         52 µmol l⁻¹ exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one µmol l⁻¹ of betaine per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 404.3   (drug-free)
  exposure = EC50 (52 µmol l⁻¹)  response 2.021e+04
  exposure -> infinity  response 4.002e+04</pre></body></html>"));
end Betaine_Matthews2002_PD_hcy;
