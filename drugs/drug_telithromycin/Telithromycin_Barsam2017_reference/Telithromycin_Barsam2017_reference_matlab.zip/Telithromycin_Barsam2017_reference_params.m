function p = Telithromycin_Barsam2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telithromycin   source: Barsam_2017 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Telithromycin_Barsam2017_reference_params';
  p.drug  = 'telithromycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 104.0;                % central volume [L]
  p.CL = 8.59;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.32;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
