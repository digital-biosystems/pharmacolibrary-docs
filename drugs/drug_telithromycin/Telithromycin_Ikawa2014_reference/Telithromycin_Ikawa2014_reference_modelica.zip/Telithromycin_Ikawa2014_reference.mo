model Telithromycin_Ikawa2014_reference
  parameter Real Cl_ref = 9.555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2047 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.812018,
    adminMass = 0.0008,
    ka = 0.0001888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About telithromycin</h4><p>Telithromycin is a ketolide antibiotic used to treat bacterial respiratory infections such as pneumonia, sinusitis, pharyngitis, tonsillitis and chronic bronchitis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2736135\">Wikidata Q2736135</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>telithromycin</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Ikawa_2014</td></tr><tr><td>measured_compound:</td><td>telithromycin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>telithromycin 812.018 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'transfer rate constants connecting compartments (K12 , K21 , K13 and K31' — extend the ontology if this is a real PK parameter (source ['Ikawa_2014:abstract', 'Ikawa_2014:abstract', 'Ikawa_2014:abstract', 'Ikawa_2014:abstract'])</li><li>dropped duplicate Q49 ('Ka', value 0.74) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=telithromycin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Telithromycin_Ikawa2014_reference;
