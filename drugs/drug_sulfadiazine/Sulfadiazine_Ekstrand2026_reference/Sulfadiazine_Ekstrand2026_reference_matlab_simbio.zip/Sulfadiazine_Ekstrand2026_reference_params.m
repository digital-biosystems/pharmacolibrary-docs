function p = Sulfadiazine_Ekstrand2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulfadiazine   source: Ekstrand_2026 / reference   route: oral
  p.name  = 'Sulfadiazine_Ekstrand2026_reference_params';
  p.drug  = 'sulfadiazine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.9;                % central volume [L]
  p.CL = 30.1;                % clearance [L/h]
  p.Vp = [6.3];             % peripheral volumes [L]
  p.Q  = [9.8];             % inter-compartmental clearances [L/h]
  p.ka = 3.69;                % absorption rate [1/h]
  p.F  = 0.94;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
