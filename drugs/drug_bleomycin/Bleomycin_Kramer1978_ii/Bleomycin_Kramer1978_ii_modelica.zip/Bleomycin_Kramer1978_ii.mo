model Bleomycin_Kramer1978_ii
  parameter Real Cl_ref = 2.553716666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02478 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.415552,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bleomycin</h4><p>Bleomycin is a cytotoxic antibiotic used as an anticancer medicine to treat various types of cancer. It is an approved cancer drug, used in oncology treatment, and has also been investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105203558\">Wikidata Q105203558</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bleomycin</td></tr><tr><td>population:</td><td>patients with neoplastic disorders</td></tr><tr><td>source_paper:</td><td>Kramer_1978</td></tr><tr><td>measured_compound:</td><td>bleomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bleomycin 1415.55 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml/min/1.73 m2' (Q)</li><li>unit_dimension_unknown: 'ml/min/1.73 m2' (Q)</li><li>dropped duplicate Q30 ('Qβ (ml/min/1.73 m2)', value '128.0') — already have one for this compound</li><li>implicit units: 'Q (ml/min/1.73 m2)' → ml/min (from the popPK convention: &quot;The paper does not explicitly state a unit for the intercompartmental clearance Q (the caption only mentions 'Averaged P&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bleomycin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'ii' subgroup of Kramer_1978 (paper reports 3 populations: group i†, ii, iii†)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=9.19338 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bleomycin_Kramer1978_ii;
