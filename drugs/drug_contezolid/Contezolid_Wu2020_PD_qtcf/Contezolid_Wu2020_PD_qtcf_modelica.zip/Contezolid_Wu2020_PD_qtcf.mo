model Contezolid_Wu2020_PD_qtcf
  "linear exposure-response sweep — Wu_2020 :: ΔQTcF (ΔQTcF interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.227   "[ms per mg/liter]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Contezolid_Wu2020_PD_qtcf</h4><p>The steady-state exposure-response curve of Wu J et al., <i>Antimicrobial agents and chemotherapy 64(6)</i> 2020 (<a href=\"https://doi.org/10.1128/AAC.02158-19\">doi:10.1128/AAC.02158-19</a>) — ΔQTcF interval [ms] against contezolid mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.227 ms per mg/liter change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/liter of contezolid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Contezolid_Wu2020_PD_qtcf;
