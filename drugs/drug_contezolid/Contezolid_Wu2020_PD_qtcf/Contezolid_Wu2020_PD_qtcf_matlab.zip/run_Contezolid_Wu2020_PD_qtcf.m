% run_Contezolid_Wu2020_PD_qtcf  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Contezolid_Wu2020_PD_qtcf_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/liter]'); ylabel('response [ms]'); title('Contezolid_Wu2020_PD_qtcf', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Contezolid_Wu2020_PD_qtcf.csv');
