function p = Contezolid_Wu2020_PD_qtcf_params()
% Contezolid_Wu2020_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% contezolid Wu_2020::QTcF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response ΔQTcF in ms. Driver: contezolid (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.227;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
