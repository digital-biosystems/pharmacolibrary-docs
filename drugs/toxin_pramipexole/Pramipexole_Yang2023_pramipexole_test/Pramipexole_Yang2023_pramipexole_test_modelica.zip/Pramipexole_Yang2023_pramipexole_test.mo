// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Pramipexole_Yang2023_pramipexole_test
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {43128.0},
    MM = 0.211327,
    adminMass = 3.75e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pramipexole</td></tr><tr><td>population:</td><td>Healthy Chinese subjects</td></tr><tr><td>source_paper:</td><td>Yang_2023</td></tr><tr><td>measured_compound:</td><td>Pramipexole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>pramipexole 211.327 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Under fasted state'; source reconciliation required</li><li>table representations disagree for '#Tmax (h)'; source reconciliation required</li><li>table representations disagree for 'Under fed state'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Under fasted state' — extend the ontology if this is a real PK parameter (source ['t0002:row2:col1'])</li><li>dropped unlinked row (NIL): 'Under fed state' — extend the ontology if this is a real PK parameter (source ['t0002:row9:col1'])</li><li>salvaged Q57 ('t1/2 test'=11.98) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pramipexole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'pramipexole / test' subgroup of Yang_2023 (paper reports 3 populations: geometric mean, geometric mean ratio (%), pramipexole / test)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Pramipexole_Yang2023_pramipexole_test;
