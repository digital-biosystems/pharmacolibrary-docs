function p = Imipenem_Zhang2026_center_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Zhang_2026 / center_d   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Zhang2026_center_d_params';
  p.drug  = 'imipenem';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.4;                % central volume [L]
  p.CL = 7.182;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
