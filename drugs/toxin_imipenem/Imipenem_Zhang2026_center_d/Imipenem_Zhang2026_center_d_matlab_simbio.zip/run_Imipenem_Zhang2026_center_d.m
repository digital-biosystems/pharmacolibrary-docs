% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Imipenem_Zhang2026_center_d_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
