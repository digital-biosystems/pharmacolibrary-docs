% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Imipenem_Bhagunde2019_imipenem_bootstrapa_estimate_rse_b_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
