model Imipenem_Feng2026_mild_ri
  parameter Real Cl_ref = 3.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.020399999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.00049
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>healthy adults, adults with renal impairment, pediatric patients</td></tr><tr><td>source_paper:</td><td>Feng_2026</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Infusion time (h)'; source reconciliation required</li><li>table representations disagree for 'AUC0-t (μg·h/mL) / Observed'; source reconciliation required</li><li>table representations disagree for 'AUC0-t (μg·h/mL) / Predicted'; source reconciliation required</li><li>table representations disagree for 'AUC0-t (μg·h/mL) / Fold-Error'; source reconciliation required</li><li>table representations disagree for 'Cmax (μg/mL) / Predicted'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Infusion time (h)' — extend the ontology if this is a real PK parameter (source ['T2:row10:col2'])</li><li>dropped duplicate Q19 ('AUC0-t (μg·h/mL) / Predicted', value '23.13') — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0-t (μg·h/mL) / Fold-Error', value '1.16') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li><li>status held at route_to_review — not promoted</li><li>population split: 'mild ri' subgroup of Feng_2026 (paper reports 5 populations: initial value, mild ri, moderate ri, normal, severe ri)</li><li>gap-filled Q22 (CL) from Couffignal_2014's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Couffignal_2014's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Couffignal_2014 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Feng2026_mild_ri;
