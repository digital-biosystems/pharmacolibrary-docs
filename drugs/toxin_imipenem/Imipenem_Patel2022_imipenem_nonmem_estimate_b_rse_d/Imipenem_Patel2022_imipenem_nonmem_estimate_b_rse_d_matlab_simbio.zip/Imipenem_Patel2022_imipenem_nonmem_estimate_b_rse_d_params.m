function p = Imipenem_Patel2022_imipenem_nonmem_estimate_b_rse_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Patel_2022 / imipenem_nonmem_estimate_b_rse_d   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Patel2022_imipenem_nonmem_estimate_b_rse_d_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.4;                % central volume [L]
  p.CL = 12.7;                % clearance [L/h]
  p.Vp = [7.79];             % peripheral volumes [L]
  p.Q  = [23.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
