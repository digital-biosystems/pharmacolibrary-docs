model Imipenem_Patel2022_imipenem_nonmem_estimate_b_rse_d
  parameter Real Cl_ref = 3.5277777777777775e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0114 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005,
    k12 = 0.0005628654970760234,
    k21 = 0.0008237056054771075
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>adult participants with hospital-acquired/ventilator-associated bacterial pneumonia</td></tr><tr><td>source_paper:</td><td>Patel_2022</td></tr><tr><td>measured_compound:</td><td>imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13158-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>table representations disagree for 'V2 (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>table representations disagree for 'CrCl (power)'; source reconciliation required</li><li>table representations disagree for 'WT (power)'; source reconciliation required</li><li>table representations disagree for 'Pneumonia f'; source reconciliation required</li><li>table representations disagree for 'Ventilation g'; source reconciliation required</li><li>dropped unlinked row (NIL): 'CrCl (power)' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row8:col1'])</li><li>dropped unlinked row (NIL): 'WT (power)' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row9:col1', 'cts13158-tbl-0003:row12:col1'])</li><li>dropped unlinked row (NIL): 'Pneumonia f' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row10:col1', 'cts13158-tbl-0003:row13:col1'])</li><li>dropped unlinked row (NIL): 'Ventilation g' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row14:col1'])</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V1' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote', 'cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V2' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote', 'cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Q' from footnote/prose loose number 23.07 (source ['cts13158-tbl-0003:footnote', 'cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Patel2022_imipenem_nonmem_estimate_b_rse_d;
