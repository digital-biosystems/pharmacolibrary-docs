function p = Imipenem_Couffignal2014_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Couffignal_2014 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Couffignal2014_final_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.4;                % central volume [L]
  p.CL = 13.2;                % clearance [L/h]
  p.Vp = [9.8];             % peripheral volumes [L]
  p.Q  = [12.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
