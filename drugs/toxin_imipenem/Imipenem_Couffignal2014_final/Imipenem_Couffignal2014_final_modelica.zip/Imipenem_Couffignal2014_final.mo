model Imipenem_Couffignal2014_final
  parameter Real Cl_ref = 3.6666666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.020399999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005,
    k12 = 0.00016612200435729848,
    k21 = 0.00034580498866213145
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>critically ill ICU patients with suspected ventilator-associated pneumonia</td></tr><tr><td>source_paper:</td><td>Couffignal_2014</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωV1 (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section covariance: 'ηCL_i ηV1_i' routed out of structural estimates ('Correlation')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'βCrCl24h (log L/h)' — extend the ontology if this is a real PK parameter (source ['Couffignal_2014_table_2:row1:col3'])</li><li>dropped unlinked row (NIL): 'βWeight (log L)' — extend the ontology if this is a real PK parameter (source ['Couffignal_2014_table_2:row3:col3'])</li><li>dropped unlinked row (NIL): 'βSerum albumin (log L)' — extend the ontology if this is a real PK parameter (source ['Couffignal_2014_table_2:row4:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li><li>model-stage split: 'final model value' is the final model of Couffignal_2014 (paper reports 2 stages: basic model value, final model value); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Couffignal2014_final;
