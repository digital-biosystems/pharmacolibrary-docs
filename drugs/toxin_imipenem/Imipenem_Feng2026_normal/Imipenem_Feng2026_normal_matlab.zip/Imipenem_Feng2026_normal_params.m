function p = Imipenem_Feng2026_normal_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Feng_2026 / normal   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Feng2026_normal_params';
  p.drug  = 'imipenem';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.4;                % central volume [L]
  p.CL = 12.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 490.0;             % dose [mg]
end
