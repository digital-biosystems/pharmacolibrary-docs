function p = Imipenem_Wang2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Wang_2024 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Wang2024_reference_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.7;                % central volume [L]
  p.CL = 13.1;                % clearance [L/h]
  p.Vp = [29.3];             % peripheral volumes [L]
  p.Q  = [11.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
