function p = Imipenem_Qiao2026_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Qiao_2026 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Qiao2026_final_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 24.4;                % central volume [L]
  p.CL = 6.08;                % clearance [L/h]
  p.Vp = [12.0];             % peripheral volumes [L]
  p.Q  = [3.19];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
