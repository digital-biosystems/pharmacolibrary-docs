model Imipenem_Dao2022_reference
  parameter Real Cl_ref = 5.833333333333333e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00073 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>neonates</td></tr><tr><td>source_paper:</td><td>Dao_2022</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'GA' — extend the ontology if this is a real PK parameter (source ['Dao_2022:abstract'])</li><li>dropped unlinked row (NIL): 'PNA' — extend the ontology if this is a real PK parameter (source ['Dao_2022:abstract'])</li><li>dropped unlinked row (NIL): 'BW' — extend the ontology if this is a real PK parameter (source ['Dao_2022:abstract'])</li><li>dropped unlinked row (NIL): 'serum creatinine, SCr' — extend the ontology if this is a real PK parameter (source ['Dao_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Dao2022_reference;
