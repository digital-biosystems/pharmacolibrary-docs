function p = Imipenem_Qiao2026_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Qiao_2026 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Qiao2026_base_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 24.6;                % central volume [L]
  p.CL = 6.07;                % clearance [L/h]
  p.Vp = [10.8];             % peripheral volumes [L]
  p.Q  = [3.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
