model Imipenem_Qiao2026_base
  parameter Real Cl_ref = 1.6861111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0246 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005,
    k12 = 3.511743450767841e-05,
    k21 = 7.998971193415637e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>critically ill patients receiving continuous renal replacement therapy</td></tr><tr><td>source_paper:</td><td>Qiao_2026</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PROB-erro' — extend the ontology if this is a real PK parameter (source ['t0002:row8:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li><li>model equation 'eGFR = 175 * (Scr/0.9)^-1.154' not bound — neither LHS nor base term 'Scr' linked to an ontology parameter</li><li>model-stage split: 'base model estimate(rse %) [shrinkage %]' is the base model of Qiao_2026 (paper reports 2 stages: base model estimate(rse %) [shrinkage %], final model estimate(rse %) [shrinkage %]); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Qiao2026_base;
