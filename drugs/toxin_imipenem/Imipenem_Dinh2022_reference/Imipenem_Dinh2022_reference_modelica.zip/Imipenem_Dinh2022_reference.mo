model Imipenem_Dinh2022_reference
  parameter Real Cl_ref = 1.3305555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0111 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005,
    k12 = 0.0002777777777777778,
    k21 = 0.00034958427815570675
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>Vietnamese critically-ill patients</td></tr><tr><td>source_paper:</td><td>Dinh_2022</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV_CL' routed out of structural estimates ('Between-subject variability (CV,%)')</li><li>table section iiv: 'IIV_Vc' routed out of structural estimates ('Between-subject variability (CV,%)')</li><li>table section iiv: 'IIV_Q' routed out of structural estimates ('Between-subject variability (CV,%)')</li><li>table section iiv: 'IIV_Vp' routed out of structural estimates ('Between-subject variability (CV,%)')</li><li>table section residual_error: 'Additive error (mg/L)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Beta_Clcr' — extend the ontology if this is a real PK parameter (source ['t0002:row5:col1', 't0002:footnote'])</li><li>dropped value-less row: 'Cl'</li><li>dropped value-less row: 'Clpop'</li><li>dropped value-less row: 'Clcr'</li><li>dropped value-less row: 'Vc'</li><li>dropped value-less row: 'Vp'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'RSE'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Dinh2022_reference;
