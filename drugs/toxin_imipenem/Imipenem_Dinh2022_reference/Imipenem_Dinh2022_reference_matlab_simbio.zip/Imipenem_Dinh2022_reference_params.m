function p = Imipenem_Dinh2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Dinh_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Dinh2022_reference_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.1;                % central volume [L]
  p.CL = 4.79;                % clearance [L/h]
  p.Vp = [8.82];             % peripheral volumes [L]
  p.Q  = [11.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
