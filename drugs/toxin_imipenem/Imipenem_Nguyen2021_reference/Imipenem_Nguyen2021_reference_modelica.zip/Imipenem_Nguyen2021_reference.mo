model Imipenem_Nguyen2021_reference
  parameter Real Cl_ref = 2.188888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0151 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>patients with Acute Exacerbations of Chronic Obstructive Pulmonary Disease (AECOPD)</td></tr><tr><td>source_paper:</td><td>Nguyen_2021</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00456-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('βCLCRCG on CL', value '0.532') — already have one for this compound</li><li>dropped unlinked row (NIL): 'b (%)' — extend the ontology if this is a real PK parameter (source ['Nguyen_2021_table_p7_1:row6:col1', 'Nguyen_2021_table_p7_1:row13:col1'])</li><li>dropped value-less row: 'CLCRCG'</li><li>dropped value-less row: 'βCLCR on CL'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Nguyen2021_reference;
