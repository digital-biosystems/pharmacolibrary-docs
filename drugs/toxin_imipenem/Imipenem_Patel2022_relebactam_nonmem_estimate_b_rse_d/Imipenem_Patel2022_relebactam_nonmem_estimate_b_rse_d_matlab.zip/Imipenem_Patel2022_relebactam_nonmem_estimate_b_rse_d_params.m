function p = Imipenem_Patel2022_relebactam_nonmem_estimate_b_rse_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Patel_2022 / relebactam_nonmem_estimate_b_rse_d   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Patel2022_relebactam_nonmem_estimate_b_rse_d_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.2;                % central volume [L]
  p.CL = 7.23;                % clearance [L/h]
  p.Vp = [6.15];             % peripheral volumes [L]
  p.Q  = [10.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
