model Imipenem_Couffignal2014_basic_model_value
  parameter Real Cl_ref = 3.6111111111111115e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0224 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005,
    k12 = 0.00012524801587301588,
    k21 = 0.0002833894500561167
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>critically ill ICU patients with suspected ventilator-associated pneumonia</td></tr><tr><td>source_paper:</td><td>Couffignal_2014</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ωV1 (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section covariance: 'ηCL_i ηV1_i' routed out of structural estimates ('Correlation')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Imipenem</li><li>population split: 'basic model value' subgroup of Couffignal_2014 (paper reports 2 populations: basic model value, final model value)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Couffignal2014_basic_model_value;
