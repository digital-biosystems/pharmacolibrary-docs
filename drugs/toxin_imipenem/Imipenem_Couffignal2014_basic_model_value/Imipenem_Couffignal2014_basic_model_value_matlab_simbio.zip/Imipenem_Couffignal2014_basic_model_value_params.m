function p = Imipenem_Couffignal2014_basic_model_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Couffignal_2014 / basic_model_value   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Couffignal2014_basic_model_value_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 22.4;                % central volume [L]
  p.CL = 13.0;                % clearance [L/h]
  p.Vp = [9.9];             % peripheral volumes [L]
  p.Q  = [10.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
