function p = Imipenem_Mavridou2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Mavridou_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Imipenem_Mavridou2015_reference_params';
  p.drug  = 'imipenem';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 30.38;                % central volume [L]
  p.CL = 12.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
