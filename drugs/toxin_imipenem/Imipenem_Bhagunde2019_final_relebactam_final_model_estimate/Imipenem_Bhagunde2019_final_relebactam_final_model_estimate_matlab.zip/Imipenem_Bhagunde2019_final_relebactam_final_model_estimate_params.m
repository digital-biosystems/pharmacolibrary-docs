function p = Imipenem_Bhagunde2019_final_relebactam_final_model_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imipenem   source: Bhagunde_2019 / final_relebactam_final_model_estimate_rse_b   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Imipenem_Bhagunde2019_final_relebactam_final_model_estimate_params';
  p.drug  = 'imipenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.08;                % central volume [L]
  p.CL = 7.02;                % clearance [L/h]
  p.Vp = [6.41];             % peripheral volumes [L]
  p.Q  = [10.45];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
