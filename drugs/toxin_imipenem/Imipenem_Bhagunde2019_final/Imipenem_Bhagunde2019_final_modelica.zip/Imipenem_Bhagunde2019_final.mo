model Imipenem_Bhagunde2019_final
  parameter Real Cl_ref = 3.4805555555555554e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01583 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299345,
    adminMass = 0.0005,
    k12 = 0.00019460237242928337,
    k21 = 0.0005274923896499239
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>adult healthy volunteers and patients with bacterial infections</td></tr><tr><td>source_paper:</td><td>Bhagunde_2019</td></tr><tr><td>measured_compound:</td><td>Imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412462-tbl-0004</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.345 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL (L/hour)'; source reconciliation required</li><li>table representations disagree for 'V 1 (L)'; source reconciliation required</li><li>table representations disagree for 'V 2 (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/hour)'; source reconciliation required</li><li>table representations disagree for 'CrCL (power)'; source reconciliation required</li><li>table representations disagree for 'WT (power)'; source reconciliation required</li><li>table representations disagree for 'WT (power)'; source reconciliation required</li><li>table representations disagree for 'Healthy'; source reconciliation required</li><li>dropped unlinked row (NIL): 'CrCL (power)' — extend the ontology if this is a real PK parameter (source ['psp412462-tbl-0004:row8:col1'])</li><li>dropped unlinked row (NIL): 'Healthy' — extend the ontology if this is a real PK parameter (source ['psp412462-tbl-0004:row12:col1'])</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'NONMEM'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'RSE'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Bhagunde2019_final;
