function p = Methylprednisolone_Booker2002_PD_t_helper_cells_params()
% Methylprednisolone_Booker2002_PD_t_helper_cells_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylprednisolone Booker_2002::T_helper_cells: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response T-helper cells in its own unit. Driver: methylprednisolone (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 9.199999999999998e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 92.0;
p.form = 'E0*(1 - Emax*frac)';
end
