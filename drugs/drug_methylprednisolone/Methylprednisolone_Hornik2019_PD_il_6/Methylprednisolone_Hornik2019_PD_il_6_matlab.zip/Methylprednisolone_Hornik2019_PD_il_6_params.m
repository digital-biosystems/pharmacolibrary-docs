function p = Methylprednisolone_Hornik2019_PD_il_6_params()
% Methylprednisolone_Hornik2019_PD_il_6_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylprednisolone Hornik_2019::IL_6: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response IL-6 in pg/mL. Driver: methylprednisolone (cited_pk).
p.E0 = 7.900000000000001e-09;
p.Emax = 1.0;
p.EC50 = 1.4e-05;
p.gamma = 2.53;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 140.0;
p.form = 'E0*(1 - Emax*frac)';
end
