model Methylprednisolone_Hornik2019_PD_il_6
  "indirect_response_i exposure-response sweep — Hornik_2019 :: IL-6 (interleukin (IL)-6)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 7.9e-09,      // [kg/m3; pg/mL × 1e-09]
    Emax = 1,  // type I effect term
    EC50 = 1.4e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.53,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methylprednisolone</h4><p>Methylprednisolone is a glucocorticoid used to treat inflammatory and autoimmune conditions such as arthritis, multiple sclerosis, lupus nephritis, and graft-versus-host disease. It is widely used in human medicine and is also approved for veterinary use, appearing on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417222\">Wikidata Q417222</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Methylprednisolone_Hornik2019_PD_il_6</h4><p>The steady-state exposure-response curve of Hornik CP et al., <i>CPT: pharmacometrics &amp; systems pharmacology 8(12):913–922</i> 2019 (<a href=\"https://doi.org/10.1002/psp4.12470\">doi:10.1002/psp4.12470</a>) — interleukin (IL)-6 [pg/mL] against methylprednisolone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        7.9 pg/mL    drug-free response (baseline) (IL-6base, Q324)
  Emax  =          1          maximal effect term (Imax, Q323)
  EC50  =         14 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma =       2.53          Hill coefficient (HILL, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of methylprednisolone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.9e-09   (drug-free)
  exposure = EC50 (14 ng/mL)  response 3.95e-09
  exposure -> infinity  response 0</pre></body></html>"));
end Methylprednisolone_Hornik2019_PD_il_6;
