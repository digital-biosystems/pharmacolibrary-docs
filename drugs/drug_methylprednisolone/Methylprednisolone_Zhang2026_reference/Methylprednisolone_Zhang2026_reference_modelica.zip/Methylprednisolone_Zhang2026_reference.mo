model Methylprednisolone_Zhang2026_reference
  parameter Real Cl_ref = 5.63888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.92 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3744706,
    adminMass = 7.5e-06,
    ka = 0.0012444444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methylprednisolone</h4><p>Methylprednisolone is a glucocorticoid used to treat inflammatory and autoimmune conditions such as arthritis, multiple sclerosis, lupus nephritis, and graft-versus-host disease. It is widely used in human medicine and is also approved for veterinary use, appearing on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417222\">Wikidata Q417222</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methylprednisolone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhang_2026</td></tr><tr><td>measured_compound:</td><td>methylprednisolone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methylprednisolone 374.471 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhang_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Methylprednisolone_Zhang2026_reference;
