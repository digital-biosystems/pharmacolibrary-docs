function p = Methylprednisolone_Yu2025_PD_hc_params()
% Methylprednisolone_Yu2025_PD_hc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylprednisolone Yu_2025::HC: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HC in its own unit. Driver: methylprednisolone (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 8.299999999999999e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 8.3;
p.form = 'E0*(1 - Emax*frac)';
end
