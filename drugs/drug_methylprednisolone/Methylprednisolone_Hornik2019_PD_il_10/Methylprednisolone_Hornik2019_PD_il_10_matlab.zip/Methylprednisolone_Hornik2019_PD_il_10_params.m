function p = Methylprednisolone_Hornik2019_PD_il_10_params()
% Methylprednisolone_Hornik2019_PD_il_10_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylprednisolone Hornik_2019::IL_10: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response IL-10 in pg/mL. Driver: methylprednisolone (cited_pk).
p.E0 = 1.5200000000000001e-09;
p.Emax = 2.28;
p.EC50 = 5.82e-05;
p.gamma = 3.58;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 590.0;
p.form = 'E0*(1 + Emax*frac)';
end
