function p = Methylprednisolone_Slayter1996_PD_cortisol_params()
% Methylprednisolone_Slayter1996_PD_cortisol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylprednisolone Slayter_1996::cortisol: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response cortisol in its own unit. Driver: methylprednisolone (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 3.7e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3.7;
p.form = 'E0*(1 - Emax*frac)';
end
