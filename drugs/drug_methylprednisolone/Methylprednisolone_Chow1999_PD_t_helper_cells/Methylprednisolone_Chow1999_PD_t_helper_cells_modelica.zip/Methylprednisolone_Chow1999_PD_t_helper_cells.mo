model Methylprednisolone_Chow1999_PD_t_helper_cells
  "indirect_response_i exposure-response sweep — Chow_1999 :: T-helper cells (T-helper cells in blood)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 4.6e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methylprednisolone</h4><p>Methylprednisolone is a glucocorticoid used to treat inflammatory and autoimmune conditions such as arthritis, multiple sclerosis, lupus nephritis, and graft-versus-host disease. It is widely used in human medicine and is also approved for veterinary use, appearing on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417222\">Wikidata Q417222</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Methylprednisolone_Chow1999_PD_t_helper_cells</h4><p>The steady-state exposure-response curve of Chow FS et al., <i>Journal of pharmacokinetics and biopharmaceutics 27(6):559–575</i> 1999 (<a href=\"https://doi.org/10.1023/a:1020974408657\">doi:10.1023/a:1020974408657</a>) — T-helper cells in blood against methylprednisolone ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =        4.6 ng/ml    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of methylprednisolone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.6 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Methylprednisolone_Chow1999_PD_t_helper_cells;
