function p = Methylprednisolone_Chow1999_PD_t_helper_cells_params()
% Methylprednisolone_Chow1999_PD_t_helper_cells_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methylprednisolone Chow_1999::T_helper_cells: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response T-helper cells in its own unit. Driver: methylprednisolone (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 4.599999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 46.0;
p.form = 'E0*(1 - Emax*frac)';
end
