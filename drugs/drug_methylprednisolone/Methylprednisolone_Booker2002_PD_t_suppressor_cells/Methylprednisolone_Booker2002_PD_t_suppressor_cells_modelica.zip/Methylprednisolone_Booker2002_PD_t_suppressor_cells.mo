model Methylprednisolone_Booker2002_PD_t_suppressor_cells
  "indirect_response_i exposure-response sweep — Booker_2002 :: T-suppressor cells (T-suppressor lymphocytes)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.85e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 190, Interval = 0.38),
    Documentation(info = "<html><body><!-- drug-about --><h4>About methylprednisolone</h4><p>Methylprednisolone is a glucocorticoid used to treat inflammatory and autoimmune conditions such as arthritis, multiple sclerosis, lupus nephritis, and graft-versus-host disease. It is widely used in human medicine and is also approved for veterinary use, appearing on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417222\">Wikidata Q417222</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Methylprednisolone_Booker2002_PD_t_suppressor_cells</h4><p>The steady-state exposure-response curve of Booker BM et al., <i>Clinical pharmacology and therapeutics 72(4):370–382</i> 2002 (<a href=\"https://doi.org/10.1067/mcp.2002.127944\">doi:10.1067/mcp.2002.127944</a>) — T-suppressor lymphocytes against methylprednisolone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       18.5 ng/mL    exposure at half of the maximal effect term (50% inhibitory concentration, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of methylprednisolone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (18.5 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Methylprednisolone_Booker2002_PD_t_suppressor_cells;
