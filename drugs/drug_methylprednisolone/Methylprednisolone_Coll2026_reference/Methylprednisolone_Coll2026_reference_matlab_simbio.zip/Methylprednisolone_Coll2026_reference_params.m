function p = Methylprednisolone_Coll2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methylprednisolone   source: Coll_2026 / reference   route: oral
  p.name  = 'Methylprednisolone_Coll2026_reference_params';
  p.drug  = 'methylprednisolone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.6;                % central volume [L]
  p.CL = 8.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.75;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
