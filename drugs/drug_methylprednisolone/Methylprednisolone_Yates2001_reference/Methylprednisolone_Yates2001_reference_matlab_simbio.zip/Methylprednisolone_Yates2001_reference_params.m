function p = Methylprednisolone_Yates2001_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methylprednisolone   source: Yates_2001 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methylprednisolone_Yates2001_reference_params';
  p.drug  = 'methylprednisolone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 137.0;                % central volume [L]
  p.CL = 13.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.35;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
