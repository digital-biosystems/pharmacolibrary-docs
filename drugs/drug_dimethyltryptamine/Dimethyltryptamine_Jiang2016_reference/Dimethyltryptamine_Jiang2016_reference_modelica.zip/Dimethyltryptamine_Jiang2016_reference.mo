model Dimethyltryptamine_Jiang2016_reference
  parameter Real Cl_ref = 1.6033333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17010000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1882688,
    adminMass = 0.0001,
    ka = 0.0012466666666666668,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dimethyltryptamine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jiang_2016</td></tr><tr><td>measured_compound:</td><td>dimethyltryptamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dimethyltryptamine 188.269 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jiang_2016) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Dimethyltryptamine_Jiang2016_reference;
