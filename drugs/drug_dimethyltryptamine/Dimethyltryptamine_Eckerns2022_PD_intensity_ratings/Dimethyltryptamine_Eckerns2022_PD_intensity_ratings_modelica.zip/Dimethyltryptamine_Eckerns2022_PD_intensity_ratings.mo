model Dimethyltryptamine_Eckerns2022_PD_intensity_ratings
  "sigmoid_emax exposure-response sweep — Eckernäs_2022 :: intensity ratings (psychedelic intensity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 10,  // [1]
    EC50 = 94.7,  // [nM]
    gamma = 2.87,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 950, Interval = 1.9),
    Documentation(info = "<html><body><h4>Dimethyltryptamine_Eckerns2022_PD_intensity_ratings</h4><p>The steady-state exposure-response curve of Eckernäs E et al., <i>Clinical and translational science 15(12):2928–2937</i> 2022 (<a href=\"https://doi.org/10.1111/cts.13410\">doi:10.1111/cts.13410</a>) — psychedelic intensity against N,N-dimethyltryptamine nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         10          maximal effect term (E max, Q320)
  EC50  =       94.7 nM       exposure at half of the maximal effect term (EC50,e, Q321)
  gamma =       2.87          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of N,N-dimethyltryptamine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (94.7 nM)  response 5
  exposure -> infinity  response 10</pre></body></html>"));
end Dimethyltryptamine_Eckerns2022_PD_intensity_ratings;
