function p = Dimethyltryptamine_Eckerns2022_PD_intensity_ratings_params()
% Dimethyltryptamine_Eckerns2022_PD_intensity_ratings_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dimethyltryptamine Eckernäs_2022::intensity_ratings: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response intensity ratings in its own unit. Driver: N,N-dimethyltryptamine (conc_no_pk).
p.E0 = 0.0;
p.Emax = 10.0;
p.EC50 = 94.7;
p.gamma = 2.87;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 950.0;
p.form = 'E0 + Emax*frac';
end
