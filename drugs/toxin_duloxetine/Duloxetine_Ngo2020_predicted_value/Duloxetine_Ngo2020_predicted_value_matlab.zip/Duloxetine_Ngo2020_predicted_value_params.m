function p = Duloxetine_Ngo2020_predicted_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: duloxetine   source: Ngo_2020 / predicted_value   route: oral
  p.name  = 'Duloxetine_Ngo2020_predicted_value_params';
  p.drug  = 'duloxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2460.0;                % central volume [L]
  p.CL = 212.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.687;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2800.0;             % dose [mg]
end
