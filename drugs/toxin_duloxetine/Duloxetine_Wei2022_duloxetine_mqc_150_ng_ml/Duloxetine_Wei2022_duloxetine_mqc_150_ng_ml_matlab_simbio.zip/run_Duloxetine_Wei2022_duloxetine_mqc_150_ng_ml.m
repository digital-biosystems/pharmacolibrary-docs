% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Duloxetine_Wei2022_duloxetine_mqc_150_ng_ml_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
