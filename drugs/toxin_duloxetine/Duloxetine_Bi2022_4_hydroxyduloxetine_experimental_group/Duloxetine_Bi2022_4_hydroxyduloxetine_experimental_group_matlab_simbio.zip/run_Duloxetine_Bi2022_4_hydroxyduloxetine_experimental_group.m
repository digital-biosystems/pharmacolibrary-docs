% Run (SimBiology): build model + dose, simulate 0..42.0 h, plot.
p = Duloxetine_Bi2022_4_hydroxyduloxetine_experimental_group_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 42.0);
