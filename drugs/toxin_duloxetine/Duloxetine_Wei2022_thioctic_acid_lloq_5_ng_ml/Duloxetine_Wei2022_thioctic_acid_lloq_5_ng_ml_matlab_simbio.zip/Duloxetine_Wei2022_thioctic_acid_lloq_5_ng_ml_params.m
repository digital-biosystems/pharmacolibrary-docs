function p = Duloxetine_Wei2022_thioctic_acid_lloq_5_ng_ml_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: duloxetine   source: Wei_2022 / thioctic_acid_lloq_5_ng_ml   route: oral
  % estimated (absent from source): F
  p.name  = 'Duloxetine_Wei2022_thioctic_acid_lloq_5_ng_ml_params';
  p.drug  = 'duloxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1640.0;                % central volume [L]
  p.CL = 387.03;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.46;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
