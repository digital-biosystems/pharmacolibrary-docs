function p = Duloxetine_Lobo2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: duloxetine   source: Lobo_2014 / reference   route: oral
  p.name  = 'Duloxetine_Lobo2014_reference_params';
  p.drug  = 'duloxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1200.0;                % central volume [L]
  p.CL = 79.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.46;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
