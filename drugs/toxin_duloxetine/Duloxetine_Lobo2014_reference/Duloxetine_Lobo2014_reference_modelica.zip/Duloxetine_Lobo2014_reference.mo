model Duloxetine_Lobo2014_reference
  parameter Real Cl_ref = 2.213888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.2 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.297416,
    adminMass = 6e-05,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>children and adolescents aged 7-17 years with major depressive disorder</td></tr><tr><td>source_paper:</td><td>Lobo_2014</td></tr><tr><td>measured_compound:</td><td>Duloxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>duloxetine 297.416 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('The between-patient variability in CL/F', value 68) — already have one for this compound</li><li>dropped duplicate Q76 ('The between-patient variability in V d/F', value 87) — already have one for this compound</li><li>routed 'within-patient variability' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped value-less row: 'In American Indian patients, V d/F was 131% higher than the other races combined'</li><li>dropped value-less row: 'Estimates of CL/F and V d/F were higher in the pediatric population than in adults'</li><li>dropped value-less row: 'the average steady-state duloxetine concentration was approximately 30% lower in the pediatric population than in adults'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Duloxetine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Lobo2014_reference;
