% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Duloxetine_Wei2022_thioctic_acid_hqc_800_ng_ml_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
