function p = Duloxetine_Bi2022_4_hydroxyduloxetine_control_group_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: duloxetine   source: Bi_2022 / 4_hydroxyduloxetine_control_group   route: oral
  p.name  = 'Duloxetine_Bi2022_4_hydroxyduloxetine_control_group_params';
  p.drug  = 'duloxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2460.0;                % central volume [L]
  p.CL = 938.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.46;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
