model Duloxetine_Bi2022_4_hydroxyduloxetine_control_group
  parameter Real Cl_ref = 0.00026074999999999997 "Cl [m3/s]";
  parameter Real Vd_ref = 2.46 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.297416,
    adminMass = 0.00014,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>Six adult healthy beagle dogs (weighing 7–9 kg, male and female)</td></tr><tr><td>source_paper:</td><td>Bi_2022</td></tr><tr><td>measured_compound:</td><td>Duloxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab6</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>4-Hydroxyduloxetine 313.415 g/mol (pubchem); Duloxetine 297.416 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q53 ('MRT(0-∞) (h)', value '9.02') — already have one for this compound</li><li>dropped duplicate Q88 ('AUC(0-∞) (ng·h/mL)', value '183.29') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Duloxetine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: '4-hydroxyduloxetine / control group' subgroup of Bi_2022 (paper reports 4 populations: 4-hydroxyduloxetine / control group, 4-hydroxyduloxetine / experimental group, duloxetine / control group, duloxetine / experimental group)</li><li>row roles: 8 per-group rows of Duloxetine hydrochloride summary_statistic but 8 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=noncompartmental; 8/8 row label(s) assigned, 0 linked by role; re-tagged Duloxetine→parent ×32</li><li>gap-filled Q76 (V/F) from Chen_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chen_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Bi2022_4_hydroxyduloxetine_control_group;
