model Duloxetine_Wei2022_duloxetine_hqc_640_ng_ml
  parameter Real Cl_ref = 0.00010750833333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.297416,
    adminMass = 6e-05,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wei_2022</td></tr><tr><td>measured_compound:</td><td>Duloxetine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>duloxetine 297.416 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Batch 1' — extend the ontology if this is a real PK parameter (source ['Wei_2022_table_p8_1:row2:col4', 'Wei_2022_table_p8_1:row7:col4'])</li><li>dropped unlinked row (NIL): 'Batch 2' — extend the ontology if this is a real PK parameter (source ['Wei_2022_table_p8_1:row3:col4', 'Wei_2022_table_p8_1:row8:col4'])</li><li>dropped unlinked row (NIL): 'Batch 3' — extend the ontology if this is a real PK parameter (source ['Wei_2022_table_p8_1:row4:col4', 'Wei_2022_table_p8_1:row9:col4'])</li><li>dropped unlinked row (NIL): 'Inter-batch' — extend the ontology if this is a real PK parameter (source ['Wei_2022_table_p8_1:row5:col4', 'Wei_2022_table_p8_1:row10:col4'])</li><li>table mostly unlinked (4/4 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q22 ('CL of duloxetine'=387.03) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Duloxetine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'duloxetine / hqc (640 ng/ml)' subgroup of Wei_2022 (paper reports 8 populations: duloxetine / hqc (640 ng/ml), duloxetine / lloq (5 ng/ml), duloxetine / lqc (15 ng/ml), duloxetine / mqc (150 ng/ml), thioctic acid / hqc (800 ng/ml), thioctic acid / lloq (5 ng/ml), thioctic acid / lqc (15 ng/ml), thioctic acid / mqc (100 ng/ml))</li><li>gap-filled Q61 (V) from Ngo_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Chen_2024, Ngo_2020 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Wei2022_duloxetine_hqc_640_ng_ml;
