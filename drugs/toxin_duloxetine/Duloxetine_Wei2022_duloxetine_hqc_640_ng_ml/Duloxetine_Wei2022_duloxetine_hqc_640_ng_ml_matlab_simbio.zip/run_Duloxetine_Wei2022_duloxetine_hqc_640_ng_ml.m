% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Duloxetine_Wei2022_duloxetine_hqc_640_ng_ml_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
