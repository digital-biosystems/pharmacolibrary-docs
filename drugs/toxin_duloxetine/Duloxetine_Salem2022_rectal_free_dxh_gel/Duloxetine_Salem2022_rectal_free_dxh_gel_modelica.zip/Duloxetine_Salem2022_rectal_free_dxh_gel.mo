// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Duloxetine_Salem2022_rectal_free_dxh_gel
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {74700.0},
    MM = 0.333874,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Salem_2022</td></tr><tr><td>measured_compound:</td><td>Duloxetine HCl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Duloxetine HCl 333.874 g/mol (pubchem); duloxetine 297.416 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q88 ('AUC (0-∞) (ng.h/ml)', value '7962.48') — already have one for this compound</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'AUC(0–72)' (captured trailing unit '0–72' for child rows)</li><li>dropped value-less row: 'MRT'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Duloxetine HCl</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'rectal free dxh gel' subgroup of Salem_2022 (paper reports 3 populations: oral dxh solution, rectal dxh nanoglycerosomal in situ gel, rectal free dxh gel)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Ngo_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Duloxetine_Salem2022_rectal_free_dxh_gel;
