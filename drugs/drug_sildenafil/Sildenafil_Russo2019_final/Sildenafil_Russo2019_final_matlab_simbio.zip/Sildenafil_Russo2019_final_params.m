function p = Sildenafil_Russo2019_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sildenafil   source: Russo_2019 / final   route: oral
  p.name  = 'Sildenafil_Russo2019_final_params';
  p.drug  = 'sildenafil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.1;                % central volume [L]
  p.CL = 13.3;                % clearance [L/h]
  p.Vp = [110.0];             % peripheral volumes [L]
  p.Q  = [25.5];             % inter-compartmental clearances [L/h]
  p.ka = 25.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
