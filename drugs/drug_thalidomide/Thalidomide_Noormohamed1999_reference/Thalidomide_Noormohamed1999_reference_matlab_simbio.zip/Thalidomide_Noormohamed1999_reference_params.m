function p = Thalidomide_Noormohamed1999_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: thalidomide   source: Noormohamed_1999 / reference   route: oral
  p.name  = 'Thalidomide_Noormohamed1999_reference_params';
  p.drug  = 'thalidomide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 69.9;                % central volume [L]
  p.CL = 10.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.73;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
