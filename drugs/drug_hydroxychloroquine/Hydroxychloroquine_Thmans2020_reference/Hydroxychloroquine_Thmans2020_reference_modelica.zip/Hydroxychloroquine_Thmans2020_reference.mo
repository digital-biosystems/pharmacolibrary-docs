model Hydroxychloroquine_Thmans2020_reference
  parameter Real Cl_ref = 2.7472222222222226e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.605 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.746,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00021250000000000002,
    Tlag = 1602.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>COVID-19 patients</td></tr><tr><td>source_paper:</td><td>Thémans_2020</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '/h' (kabs)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroxychloroquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>unit re-normalised: kabs '/h' now converts (value unchanged)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Thmans2020_reference;
