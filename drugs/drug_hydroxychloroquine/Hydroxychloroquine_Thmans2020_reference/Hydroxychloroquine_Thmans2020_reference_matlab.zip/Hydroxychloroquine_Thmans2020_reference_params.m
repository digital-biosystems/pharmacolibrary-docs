function p = Hydroxychloroquine_Thmans2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Thémans_2020 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Hydroxychloroquine_Thmans2020_reference_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 605.0;                % central volume [L]
  p.CL = 9.89;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.746;                 % bioavailability [0-1]
  p.Tlag = 0.445;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
