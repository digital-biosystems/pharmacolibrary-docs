model Hydroxychloroquine_Thmans2020_estimate
  parameter Real Cl_ref = 4.361111111111111e-06 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real Vd_ref = 0.8608 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.746,
    Cl = Cl_ref*(1 + (1.38)*cov_wt_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.335872,
    adminMass = 0.0002,
    ka = 0.0025833333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxychloroquine</h4><p>Hydroxychloroquine is an antimalarial aminoquinoline used to treat malaria, rheumatoid arthritis, lupus, and other conditions. It is given orally, typically in tablet form. It is widely used and listed on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421094\">Wikidata Q421094</a>, <a href=\"https://en.wikipedia.org/wiki/Hydroxychloroquine?oldid=1383960162\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>adults with COVID-19</td></tr><tr><td>source_paper:</td><td>Thémans_2020</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.872 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Εprop (σ2)' routed out of structural estimates ('IIV on Tlag (ω2) ne')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroxychloroquine</li><li>population split: 'estimate' subgroup of Thémans_2020 (paper reports 2 populations: corresponding estimated value in model by carmichael et al. [2], estimate)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Thmans2020_estimate;
