function p = Hydroxychloroquine_Thmans2020_corresponding_estimated_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Thémans_2020 / corresponding_estimated_value_in_model_by_carmichael_et_al_2   route: oral
  p.name  = 'Hydroxychloroquine_Thmans2020_corresponding_estimated_value_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 605.0;                % central volume [L]
  p.CL = 9.89;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.765;                % absorption rate [1/h]
  p.F  = 0.746;                 % bioavailability [0-1]
  p.Tlag = 0.445;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
