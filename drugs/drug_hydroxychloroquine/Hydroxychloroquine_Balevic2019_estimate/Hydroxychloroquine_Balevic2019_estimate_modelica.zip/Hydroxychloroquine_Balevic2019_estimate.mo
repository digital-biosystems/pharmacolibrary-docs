model Hydroxychloroquine_Balevic2019_estimate
  parameter Real Cl_ref = 1.4166666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.85 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.335872,
    adminMass = 0.0004,
    ka = 0.0003194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxychloroquine</h4><p>Hydroxychloroquine is used to treat and prevent malaria and to manage autoimmune conditions such as systemic lupus erythematosus, rheumatoid arthritis, Sjögren's syndrome, and certain skin diseases. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421094\">Wikidata Q421094</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>pregnant women with rheumatic disease</td></tr><tr><td>source_paper:</td><td>Balevic_2019</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.872 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hydroxychloroquine</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>bound model equation to Q61 (V): V = tvV*(WT/70)^</li><li>Q61 (V) is equation-defined: value moved to equation-variable 'dVdWT*'; equation kept verbatim</li><li>population split: 'estimate' subgroup of Balevic_2019 (paper reports 3 populations: estimate, postnatal, prenatal)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Balevic2019_estimate;
