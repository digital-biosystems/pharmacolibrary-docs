model Fluoxetine_Eugene2021_reference
  parameter Real Cl_ref = 8.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.48 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.309331,
    adminMass = 2e-05,
    ka = 0.00018611111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluoxetine</td></tr><tr><td>population:</td><td>simulated adult COVID-19 patients (virtual population of 1,000 individuals)</td></tr><tr><td>source_paper:</td><td>Eugene_2021</td></tr><tr><td>measured_compound:</td><td>fluoxetine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1 and Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluoxetine 309.331 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('volume of distribution (Vd)'=1480) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance rate (CL)'=29.1) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('fixed absorption rate (Ka)'=0.67) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('t ½'=46.6) from results prose — parameter table was unreadable</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volume of distribution (Vd)); Q22 (clearance rate (CL))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fluoxetine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Fluoxetine_Eugene2021_reference;
