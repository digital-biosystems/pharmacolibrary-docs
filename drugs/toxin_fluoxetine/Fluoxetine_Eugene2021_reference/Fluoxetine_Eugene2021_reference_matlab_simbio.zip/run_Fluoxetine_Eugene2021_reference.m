% Run (SimBiology): build model + dose, simulate 0..240.0 h, plot.
p = Fluoxetine_Eugene2021_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 240.0);
