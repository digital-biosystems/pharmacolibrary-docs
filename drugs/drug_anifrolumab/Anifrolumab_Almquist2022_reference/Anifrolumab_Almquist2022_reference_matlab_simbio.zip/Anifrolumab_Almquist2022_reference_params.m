function p = Anifrolumab_Almquist2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: anifrolumab   source: Almquist_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Anifrolumab_Almquist2022_reference_params';
  p.drug  = 'anifrolumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.93;                % central volume [L]
  p.CL = 0.008042;                % clearance [L/h]
  p.Vp = [3.3];             % peripheral volumes [L]
  p.Q  = [0.039042];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
