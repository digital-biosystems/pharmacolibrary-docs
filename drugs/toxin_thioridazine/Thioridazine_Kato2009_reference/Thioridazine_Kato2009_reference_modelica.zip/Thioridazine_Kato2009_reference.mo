model Thioridazine_Kato2009_reference
  parameter Real Cl_ref = 7.135338623411202e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.252 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.370573,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>thioridazine</td></tr><tr><td>population:</td><td>three-year-old boy with acute thioridazine poisoning</td></tr><tr><td>source_paper:</td><td>Kato_2009</td></tr><tr><td>measured_compound:</td><td>Thioridazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thioridazine 370.573 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('Ka'=2.01) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd'=3.6) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('T1/2'=6.8) from results prose — parameter table was unreadable</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (Vd)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Thioridazine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q49 — no SI value to build from)</li><li>derived CL=25.6872 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end Thioridazine_Kato2009_reference;
