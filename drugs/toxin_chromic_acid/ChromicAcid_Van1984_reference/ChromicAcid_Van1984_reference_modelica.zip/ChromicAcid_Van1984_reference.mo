// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ChromicAcid_Van1984_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {76032.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chromic_acid</td></tr><tr><td>population:</td><td>lactating dairy cows</td></tr><tr><td>source_paper:</td><td>Van_1984</td></tr><tr><td>measured_compound:</td><td>Chromium (51Cr)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>chromic_acid 118.008 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Intestinal absorption' — extend the ontology if this is a real PK parameter (source ['Van_1984:abstract', 'Van_1984:abstract', 'Van_1984:abstract', 'Van_1984:abstract'])</li><li>dropped unlinked row (NIL): 'transfer coefficient of manganese into milk' — extend the ontology if this is a real PK parameter (source ['Van_1984:abstract'])</li><li>dropped duplicate Q57 ('half-life', value 72) — already have one for this compound</li><li>dropped unlinked row (NIL): 'excreted in the feces' — extend the ontology if this is a real PK parameter (source ['Van_1984:abstract'])</li><li>dropped unlinked row (NIL): 'of an oral' — extend the ontology if this is a real PK parameter (source ['Van_1984:abstract', 'Van_1984:abstract'])</li><li>dropped unlinked row (NIL): 'of an i.v.' — extend the ontology if this is a real PK parameter (source ['Van_1984:abstract', 'Van_1984:abstract'])</li><li>dropped unlinked row (NIL): 'transfer coefficient of cobalt into milk' — extend the ontology if this is a real PK parameter (source ['Van_1984:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chromium (51Cr)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none of 1 PubChem candidate(s) is 'Chromium (51Cr)' (LLM) — left in mass units</li><li>molar mass: none found for 'Chromium (51Cr)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Chromium (51Cr)', not chromic_acid — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end ChromicAcid_Van1984_reference;
