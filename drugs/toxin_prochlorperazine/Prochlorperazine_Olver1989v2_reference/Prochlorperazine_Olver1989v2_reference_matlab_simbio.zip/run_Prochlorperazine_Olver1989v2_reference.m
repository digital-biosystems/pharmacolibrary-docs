% Run (SimBiology): build model + dose, simulate 0..38.0 h, plot.
p = Prochlorperazine_Olver1989v2_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 38.0);
