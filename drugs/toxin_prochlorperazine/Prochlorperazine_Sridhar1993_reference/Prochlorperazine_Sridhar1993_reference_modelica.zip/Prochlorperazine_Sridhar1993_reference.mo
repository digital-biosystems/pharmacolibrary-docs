model Prochlorperazine_Sridhar1993_reference
  parameter Real Cl_ref = 1.6722222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.8994200000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37394299999999997,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>prochlorperazine</td></tr><tr><td>population:</td><td>patients with advanced, incurable, nonhematologic tumors</td></tr><tr><td>source_paper:</td><td>Sridhar_1993</td></tr><tr><td>measured_compound:</td><td>Prochlorperazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>prochlorperazine 373.943 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PCZ' — extend the ontology if this is a real PK parameter (source ['Sridhar_1993:abstract'])</li><li>dropped unlinked row (NIL): 'DOX' — extend the ontology if this is a real PK parameter (source ['Sridhar_1993:abstract'])</li><li>unit_dimension_unknown: 'l m-2 h-1' (CL)</li><li>implicit units: 'ClT' → L/h (from the popPK convention: 'The paper provides no text or table footnotes specifying units. Based on population PK conventions, total clearance (ClT')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Prochlorperazine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prochlorperazine_Sridhar1993_reference;
