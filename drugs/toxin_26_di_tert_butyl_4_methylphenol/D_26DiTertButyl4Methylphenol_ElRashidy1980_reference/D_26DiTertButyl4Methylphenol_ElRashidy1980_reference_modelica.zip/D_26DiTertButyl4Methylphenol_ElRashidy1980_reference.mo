// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_26DiTertButyl4Methylphenol_ElRashidy1980_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3600.0},
    MM = 0.220356,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>26_di_tert_butyl_4_methylphenol</td></tr><tr><td>population:</td><td>rabbits</td></tr><tr><td>source_paper:</td><td>El-Rashidy_1980</td></tr><tr><td>measured_compound:</td><td>2,6-Di-tert-butyl-4-methylphenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2,6-Di-tert-butyl-4-methylphenol 220.356 g/mol (pubchem); 26_di_tert_butyl_4_methylphenol 220.356 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2,6-Di-tert-butyl-4-methylphenol</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG from Sim_2025: its label names a different analyte ('permeation') — 'Skin permeation parameters fitted using an infinite dose model for permeation profiles of 5%w/v of MTG in various solvents (n = 3, mean ± SD; one-way ANOVA with post-hoc Tukey’s test): Solvent P1(× 10–4 cm) P2(× 10–3 h−1) Kp(× 10–6 cm/h) Jss (µg/cm2/h) tlag(h) DMSO tlag'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_26DiTertButyl4Methylphenol_ElRashidy1980_reference;
