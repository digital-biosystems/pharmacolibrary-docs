model Rifaximin_Wang2023_PD_bacterial_colony_count_reduction
  "sigmoid_emax exposure-response sweep — Wang_2023 :: bacterial colony count reduction (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -2.36,  // [log10 CFU/gland]
    EC50 = 2.36,  // [log10 CFU/gland]
    gamma = 1.0,
    exposure_per_s = 1.0);   // 1 log10 CFU/gland per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'log10 CFU/gland' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 23.6, Interval = 0.0472));
end Rifaximin_Wang2023_PD_bacterial_colony_count_reduction;
