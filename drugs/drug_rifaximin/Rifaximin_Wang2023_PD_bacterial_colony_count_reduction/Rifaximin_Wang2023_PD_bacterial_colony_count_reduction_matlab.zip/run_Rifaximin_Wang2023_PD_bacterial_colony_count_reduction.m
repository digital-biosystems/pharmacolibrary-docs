% run_Rifaximin_Wang2023_PD_bacterial_colony_count_reduction  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Rifaximin_Wang2023_PD_bacterial_colony_count_reduction_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [log10 CFU/gland]'); ylabel('response [log10CFU/gland]'); title('Rifaximin_Wang2023_PD_bacterial_colony_count_reduction', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Rifaximin_Wang2023_PD_bacterial_colony_count_reduction.csv');
