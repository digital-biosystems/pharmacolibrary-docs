function p = Rifaximin_Wang2023_PD_bacterial_colony_count_reduction_params()
% Rifaximin_Wang2023_PD_bacterial_colony_count_reduction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifaximin Wang_2023::bacterial_colony_count_reduction: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one log10 CFU/gland per second, in SI inside (kg/m3, s). Response bacterial colony count reduction in log10CFU/gland. Driver: rifaximin (cited_pk).
p.E0 = 0.0;
p.Emax = -2.36;
p.EC50 = 2.36;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 23.6;
p.form = 'E0 + Emax*frac';
end
