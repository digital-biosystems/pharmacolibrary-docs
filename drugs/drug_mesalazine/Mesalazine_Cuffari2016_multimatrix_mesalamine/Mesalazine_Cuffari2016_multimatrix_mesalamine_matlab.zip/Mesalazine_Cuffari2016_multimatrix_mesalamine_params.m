function p = Mesalazine_Cuffari2016_multimatrix_mesalamine_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mesalazine   source: Cuffari_2016 / multimatrix_mesalamine   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Mesalazine_Cuffari2016_multimatrix_mesalamine_params';
  p.drug  = 'mesalazine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 109.0;                % central volume [L]
  p.CL = 85.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
