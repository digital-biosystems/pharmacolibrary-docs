% Run: build params, simulate 0..24.0 h, plot + save Mesalazine_Cuffari2016_multimatrix_mesalamine.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Mesalazine_Cuffari2016_multimatrix_mesalamine.m
here = fileparts(mfilename('fullpath'));
p = Mesalazine_Cuffari2016_multimatrix_mesalamine_params();
out = simulate_pk(p, 0:0.05:24.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('mesalazine — Cuffari_2016 (iv_bolus)');
print(fig, fullfile(here, 'Mesalazine_Cuffari2016_multimatrix_mesalamine.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Mesalazine_Cuffari2016_multimatrix_mesalamine.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Mesalazine_Cuffari2016_multimatrix_mesalamine.json'), 'w');
try
  s.model = 'Mesalazine_Cuffari2016_multimatrix_mesalamine'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Mesalazine_Cuffari2016_multimatrix_mesalamine","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Mesalazine_Cuffari2016_multimatrix_mesalamine.png, Mesalazine_Cuffari2016_multimatrix_mesalamine.csv, Mesalazine_Cuffari2016_multimatrix_mesalamine.json\n');
