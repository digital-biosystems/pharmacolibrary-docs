model Dapagliflozin_van2023_PD_erpf
  "linear exposure-response sweep — van_2023 :: ERPF (Effective renal plasma flow)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -4.48333333333e-08   "[meter ** 3 / second; mL/min × 1.66667e-08]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Dapagliflozin_van2023_PD_erpf</h4><p>The steady-state exposure-response curve of van der Hoek S et al., <i>Journal of personalized medicine 13(5)</i> 2023 (<a href=\"https://doi.org/10.3390/jpm13050747\">doi:10.3390/jpm13050747</a>) — Effective renal plasma flow [mL/min] against dapagliflozin µg/L*h — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -2.69 mL/min   change in response per unit of exposure (β per Doubling AUC, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/L*h of dapagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Dapagliflozin_van2023_PD_erpf;
