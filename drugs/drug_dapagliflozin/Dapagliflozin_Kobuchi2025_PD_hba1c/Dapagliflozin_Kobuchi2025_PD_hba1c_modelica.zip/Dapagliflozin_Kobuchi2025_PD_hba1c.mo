model Dapagliflozin_Kobuchi2025_PD_hba1c
  "indirect_response_i exposure-response sweep — Kobuchi_2025 :: HbA1c (HbA1c)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.034,  // type I effect term
    EC50 = 2.37e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 240, Interval = 0.48),
    Documentation(info = "<html><body><h4>Dapagliflozin_Kobuchi2025_PD_hba1c</h4><p>The steady-state exposure-response curve of Kobuchi S et al., <i>International journal of medical sciences 22(10):2333–2341</i> 2025 (<a href=\"https://doi.org/10.7150/ijms.111519\">doi:10.7150/ijms.111519</a>) — HbA1c [%] against dapagliflozin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.034          maximal effect term (Emax, Q323)
  EC50  =       23.7 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of dapagliflozin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (23.7 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Dapagliflozin_Kobuchi2025_PD_hba1c;
