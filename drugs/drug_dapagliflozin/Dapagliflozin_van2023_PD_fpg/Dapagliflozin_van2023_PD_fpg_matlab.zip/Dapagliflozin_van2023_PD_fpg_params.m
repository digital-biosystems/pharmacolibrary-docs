function p = Dapagliflozin_van2023_PD_fpg_params()
% Dapagliflozin_van2023_PD_fpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dapagliflozin van_2023::FPG: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/L*h per second, in SI inside (kg/m3, s). Response FPG in mmol/L. Driver: dapagliflozin (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.08999999999999998;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
