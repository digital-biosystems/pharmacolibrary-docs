% run_Dapagliflozin_van2023_PD_hba1c  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Dapagliflozin_van2023_PD_hba1c_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [µg/L*h]'); ylabel('response [mmol/mol]'); title('Dapagliflozin_van2023_PD_hba1c', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Dapagliflozin_van2023_PD_hba1c.csv');
