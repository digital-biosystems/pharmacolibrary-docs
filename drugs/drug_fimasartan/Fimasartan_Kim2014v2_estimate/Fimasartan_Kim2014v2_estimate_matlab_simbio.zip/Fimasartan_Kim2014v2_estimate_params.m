function p = Fimasartan_Kim2014v2_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fimasartan   source: Kim_2014_2 / estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Fimasartan_Kim2014v2_estimate_params';
  p.drug  = 'fimasartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 286.0;                % central volume [L]
  p.CL = 77.0;                % clearance [L/h]
  p.Vp = [203.0];             % peripheral volumes [L]
  p.Q  = [19.4];             % inter-compartmental clearances [L/h]
  p.ka = 3.8;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
