function p = Rituximab_Pasquiers2025_PD_gg_params()
% Rituximab_Pasquiers2025_PD_gg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rituximab Pasquiers_2025::GG: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response GG in g/L. Driver: rituximab (pk_record).
p.E0 = 9.349999999999998;
p.Emax = 1.0;
p.EC50 = 0.04179999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 420.0;
p.form = 'E0*(1 - Emax*frac)';
end
