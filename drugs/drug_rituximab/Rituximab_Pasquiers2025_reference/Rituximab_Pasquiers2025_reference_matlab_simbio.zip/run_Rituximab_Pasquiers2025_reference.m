% Run (SimBiology): build model + dose, simulate 0..1512.0 h, plot.
p = Rituximab_Pasquiers2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1512.0);
