model Rituximab_Pasquiers2025_reference
  parameter Real Cl_ref = 1.7361111111111109e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00261 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 2.3059457925358312e-06,
    k21 = 1.9995078134613026e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rituximab</h4><p>Rituximab is a monoclonal antibody used to treat B-cell blood cancers such as non-Hodgkin and chronic lymphocytic leukemia and many autoimmune conditions including rheumatoid arthritis, vasculitis, and pemphigus. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412323\">Wikidata Q412323</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Pasquiers_2025</td></tr><tr><td>measured_compound:</td><td>rituximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Pasquiers_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Rituximab_Pasquiers2025_reference;
