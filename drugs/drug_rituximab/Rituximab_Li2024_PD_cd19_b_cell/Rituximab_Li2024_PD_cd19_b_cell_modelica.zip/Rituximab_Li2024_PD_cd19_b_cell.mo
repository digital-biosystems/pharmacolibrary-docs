model Rituximab_Li2024_PD_cd19_b_cell
  "indirect_response_ii exposure-response sweep — Li_2024 :: CD19+ B-cell (CD19+ B-cell)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 591.428571429,      // [/μL]
    Emax = 389.7,  // type IV effect term
    EC50 = 1.31e-06,  // [kg; mg × 1e-06]
    gamma = 6.65,
    exposure_per_s = 1e-06);   // 1 mg per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (4.14/0.007 = 591.4) — the paper's stated baseline may differ
  // emax_not_a_fraction: type II needs Imax ≤ 1 but the record has 389.7; bound as the reciprocal stimulation form (IV) the paper fitted
  annotation(experiment(StartTime = 0, StopTime = 5.4, Interval = 0.0108),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rituximab</h4><p>Rituximab is a monoclonal antibody used to treat B-cell blood cancers such as non-Hodgkin and chronic lymphocytic leukemia and many autoimmune conditions including rheumatoid arthritis, vasculitis, and pemphigus. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412323\">Wikidata Q412323</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Rituximab_Li2024_PD_cd19_b_cell</h4><p>The steady-state exposure-response curve of Li Z et al., <i>Frontiers in pharmacology 15:1526936</i> 2024 (<a href=\"https://doi.org/10.3389/fphar.2024.1526936\">doi:10.3389/fphar.2024.1526936</a>) — CD19+ B-cell [/μL] against rituximab mg — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 591.428571429 /μL      drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      389.7          maximal effect term (Emax, Q323)
  EC50  =       1.31 mg       exposure at half of the maximal effect term (ED50, Q322)
  gamma =       6.65          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg of rituximab per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 591.4   (drug-free)
  exposure = EC50 (1.31 mg)  response 3.02
  exposure -> infinity  response 1.514</pre></body></html>"));
end Rituximab_Li2024_PD_cd19_b_cell;
