function p = Rituximab_Li2024_PD_cd19_b_cell_params()
% Rituximab_Li2024_PD_cd19_b_cell_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rituximab Li_2024::CD19_B_cell: indirect_response_ii exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response CD19+ B-cell in /μL. Driver: rituximab (dose_only).
p.E0 = 591.4285714285713;
p.Emax = 389.7;
p.EC50 = 1.31e-06;
p.gamma = 6.65;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5.4;
p.form = 'E0/(1 + Emax*frac)';
end
