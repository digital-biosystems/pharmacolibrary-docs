function p = Rituximab_Pasquiers2025_PD_anca_params()
% Rituximab_Pasquiers2025_PD_anca_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rituximab Pasquiers_2025::ANCA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response ANCA in U/mL. Driver: rituximab (pk_record).
p.E0 = 1.2553675361035198e-19;
p.Emax = 1.0;
p.EC50 = 0.26399999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2700.0;
p.form = 'E0*(1 - Emax*frac)';
end
