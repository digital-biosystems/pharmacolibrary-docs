model Rituximab_Pasquiers2025_PD_anca
  "indirect_response_i exposure-response sweep — Pasquiers_2025 :: ANCA (MPO-ANCA and PR3-ANCA)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.2553675361e-19,      // [kg/m3; U/mL × 1.66054e-21]
    Emax = 1,  // type I effect term
    EC50 = 0.264,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2700, Interval = 5.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rituximab</h4><p>Rituximab is a monoclonal antibody used to treat B-cell blood cancers such as non-Hodgkin and chronic lymphocytic leukemia and many autoimmune conditions including rheumatoid arthritis, vasculitis, and pemphigus. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412323\">Wikidata Q412323</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Rituximab_Pasquiers2025_PD_anca</h4><p>The steady-state exposure-response curve of Pasquiers B et al., <i>EBioMedicine 121:105989</i> 2025 (<a href=\"https://doi.org/10.1016/j.ebiom.2025.105989\">doi:10.1016/j.ebiom.2025.105989</a>) — MPO-ANCA and PR3-ANCA [U/mL] against rituximab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       75.6 U/mL     drug-free response (baseline) (BASEANCA, Q324)
  Emax  = (library default) maximal effect term
  EC50  =        264 mg/L     exposure at half of the maximal effect term (IC50,ANCA, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of rituximab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.255e-19   (drug-free)
  exposure = EC50 (264 mg/L)  response 6.277e-20
  exposure -> infinity  response 0</pre></body></html>"));
end Rituximab_Pasquiers2025_PD_anca;
