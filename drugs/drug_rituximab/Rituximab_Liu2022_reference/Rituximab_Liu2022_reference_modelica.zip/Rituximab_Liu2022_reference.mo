model Rituximab_Liu2022_reference
  parameter Real Cl_ref = 3.703703703703704e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0034300000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 1.7546701220170609e-06,
    k21 = 8.166239509523092e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rituximab</h4><p>Rituximab is a monoclonal antibody used to treat B-cell blood cancers such as non-Hodgkin and chronic lymphocytic leukemia and many autoimmune conditions including rheumatoid arthritis, vasculitis, and pemphigus. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412323\">Wikidata Q412323</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rituximab</td></tr><tr><td>population:</td><td>patients with diffuse large B-cell lymphoma</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>rituximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13186-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σadd+Mult' routed out of structural estimates ('Residual variability (CV%)')</li><li>table section residual_error: 'σadd+Mult' routed out of structural estimates ('Residual variability (CV%)')</li><li>table section residual_error: 'σadd+Mult' routed out of structural estimates ('Residual variability (CV%)')</li><li>table section residual_error: 'σadd+Mult' routed out of structural estimates ('Residual variability (CV%)')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2V2' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Interindividual variability')</li><li>table representations disagree for 'tV (L)'; source reconciliation required</li><li>table representations disagree for 'tV2 (L)'; source reconciliation required</li><li>table representations disagree for 'tVCL (L/d)'; source reconciliation required</li><li>table representations disagree for 'tVCL2 (L/d)'; source reconciliation required</li><li>table representations disagree for 'tVCMultStdev'; source reconciliation required</li><li>table representations disagree for 'dCL-BSA'; source reconciliation required</li><li>table representations disagree for 'dCL2-stage III'; source reconciliation required</li><li>table representations disagree for 'dCL2-stage IV'; source reconciliation required</li><li>dropped unlinked row (NIL): 'tVCL2 (L/d)' — extend the ontology if this is a real PK parameter (source ['Liu_2022_table_p9_1:row4:col1', 'Liu_2022_table_p9_1:row4:col2', 'Liu_2022_table_p9_1:row4:col3', 'Liu_2022_table_p9_1:row4:col4'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Rituximab_Liu2022_reference;
