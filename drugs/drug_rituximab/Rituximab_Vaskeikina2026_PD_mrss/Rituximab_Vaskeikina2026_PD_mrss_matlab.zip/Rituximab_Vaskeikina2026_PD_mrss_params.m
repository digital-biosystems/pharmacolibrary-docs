function p = Rituximab_Vaskeikina2026_PD_mrss_params()
% Rituximab_Vaskeikina2026_PD_mrss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rituximab Vaskeikina_2026::mRSS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one weeks per second, in SI inside (kg/m3, s). Response mRSS in its own unit. Driver: rituximab (dose_only).
p.E0 = 0.0;
p.Emax = -8.03;
p.EC50 = 16625951.999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 604800.0;
p.stop_time = 280.0;
p.form = 'E0 + Emax*frac';
end
