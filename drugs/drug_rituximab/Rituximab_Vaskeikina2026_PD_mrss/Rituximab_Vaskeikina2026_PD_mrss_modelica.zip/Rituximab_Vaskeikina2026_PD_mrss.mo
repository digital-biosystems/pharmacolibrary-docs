model Rituximab_Vaskeikina2026_PD_mrss
  "emax exposure-response sweep — Vaskeikina_2026 :: mRSS (modified Rodnan skin score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -8.03,  // [1]
    EC50 = 16625952,  // [s; weeks × 604800]
    gamma = 1,
    exposure_per_s = 604800);   // 1 weeks per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 280, Interval = 0.56),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rituximab</h4><p>Rituximab is a monoclonal antibody used to treat B-cell blood cancers such as non-Hodgkin and chronic lymphocytic leukemia and many autoimmune conditions including rheumatoid arthritis, vasculitis, and pemphigus. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412323\">Wikidata Q412323</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Rituximab_Vaskeikina2026_PD_mrss</h4><p>The steady-state exposure-response curve of Vaskeikina M et al., <i>Pharmaceutics 18(2)</i> 2026 (<a href=\"https://doi.org/10.3390/pharmaceutics18020250\">doi:10.3390/pharmaceutics18020250</a>) — modified Rodnan skin score against rituximab weeks — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      -8.03          maximal effect term (Effect of rituximab on mRSS reduction, Q323)
  EC50  =      27.49 weeks    exposure at half of the maximal effect term (Time to 50% maximum change in mRSS and FVC in weeks, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one weeks of rituximab per second of simulated time (exposure is in s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (27.49 weeks)  response -4.015
  exposure -> infinity  response -8.03</pre></body></html>"));
end Rituximab_Vaskeikina2026_PD_mrss;
