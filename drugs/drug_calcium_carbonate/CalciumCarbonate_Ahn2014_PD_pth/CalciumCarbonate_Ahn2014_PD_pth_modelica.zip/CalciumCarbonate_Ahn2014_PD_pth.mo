model CalciumCarbonate_Ahn2014_PD_pth
  "indirect_response_i exposure-response sweep — Ahn_2014 :: PTH (Parathyroid hormone)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 25.4416961131,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.158,  // [mol/m3; mmol/L × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mmol/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (21.6/0.849 = 25.44) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.6, Interval = 0.0032),
    Documentation(info = "<html><body><!-- drug-about --><h4>About calcium_carbonate</h4><p>Calcium carbonate is used as an antacid for heartburn, indigestion and acid-related stomach problems, and as a calcium supplement, for example in osteoporosis. It is an approved, widely available over-the-counter medicine used broadly for these common conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23767\">Wikidata Q23767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>CalciumCarbonate_Ahn2014_PD_pth</h4><p>The steady-state exposure-response curve of Ahn JE et al., <i>The Korean journal of physiology &amp; pharmacology : official journal of the Korean Physiological Society and the Korean Society of Pharmacology 18(3):217–223</i> 2014 (<a href=\"https://doi.org/10.4196/kjpp.2014.18.3.217\">doi:10.4196/kjpp.2014.18.3.217</a>) — Parathyroid hormone against calcium_carbonate mmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 25.4416961131          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =      0.158 mmol/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mmol/L of calcium_carbonate per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 25.44   (drug-free)
  exposure = EC50 (0.158 mmol/L)  response 12.72
  exposure -> infinity  response 0</pre></body></html>"));
end CalciumCarbonate_Ahn2014_PD_pth;
