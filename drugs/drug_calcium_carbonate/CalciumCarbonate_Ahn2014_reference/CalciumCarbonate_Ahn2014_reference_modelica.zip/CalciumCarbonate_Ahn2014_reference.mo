model CalciumCarbonate_Ahn2014_reference
  parameter Real Cl_ref = 1.277777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0116 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>calcium_carbonate</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Ahn_2014</td></tr><tr><td>measured_compound:</td><td>parathyroid hormone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'kin_ca' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ahn_2014_table_p3_1:row0:col1', 'Ahn_2014_table_p3_1:row0:col3'])</li><li>dropped PD-category row 'kout_ca' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ahn_2014_table_p3_1:row1:col1'])</li><li>dropped PD-category row 'kin_pth' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ahn_2014_table_p3_1:row2:col1', 'Ahn_2014_table_p3_1:row2:col3'])</li><li>dropped PD-category row 'kout_pth' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ahn_2014_table_p3_1:row3:col1', 'Ahn_2014_table_p3_1:row3:col3'])</li><li>dropped PD-category row 'EC50 (mmol/L)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ahn_2014_table_p3_1:row5:col1', 'Ahn_2014_table_p3_1:row5:col3'])</li><li>routed 'SD_ca (mmol/L)' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'CV_pth (% CV)' — extend the ontology if this is a real PK parameter (source ['Ahn_2014_table_p3_1:row12:col1', 'Ahn_2014_table_p3_1:row12:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=parathyroid hormone</li><li>gap-filled Q22 (CL) from Ekobena_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Ekobena_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CalciumCarbonate_Ahn2014_reference;
