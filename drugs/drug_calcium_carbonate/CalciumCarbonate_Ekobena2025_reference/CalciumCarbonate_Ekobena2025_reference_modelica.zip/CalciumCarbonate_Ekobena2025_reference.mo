model CalciumCarbonate_Ekobena2025_reference
  parameter Real Cl_ref = 1.4e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0116 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.10008700000000001,
    adminMass = 5e-05,
    ka = 0.0007222222222222223,
    Tlag = 846.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About calcium_carbonate</h4><p>Calcium carbonate is used as an antacid for heartburn, indigestion and acid-related stomach problems, and as a calcium supplement, for example in osteoporosis. It is an approved, widely available over-the-counter medicine used broadly for these common conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23767\">Wikidata Q23767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>calcium_carbonate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ekobena_2025</td></tr><tr><td>measured_compound:</td><td>calcium_carbonate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>calcium_carbonate 100.087 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ekobena_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end CalciumCarbonate_Ekobena2025_reference;
