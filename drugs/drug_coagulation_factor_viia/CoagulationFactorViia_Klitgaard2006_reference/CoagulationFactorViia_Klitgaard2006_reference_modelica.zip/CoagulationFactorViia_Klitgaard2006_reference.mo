model CoagulationFactorViia_Klitgaard2006_reference
  parameter Real Cl_ref = 7.777777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006229999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 7.49063670411985e-05,
    k21 = 0.00021505376344086021
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About coagulation_factor_viia</h4><p>Coagulation factor VIIa is a blood coagulation factor used to treat bleeding by promoting clot formation. It is an approved medicine, though it carries a boxed warning, and has also been studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20801762\">Wikidata Q20801762</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>coagulation_factor_viia</td></tr><tr><td>population:</td><td>trauma patients with severe bleeding</td></tr><tr><td>source_paper:</td><td>Klitgaard_2006</td></tr><tr><td>measured_compound:</td><td>recombinant activated factor VII (rFVIIa)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('ΔClearance/RBC', value '1.014') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Hemophiliaa' — extend the ontology if this is a real PK parameter (source ['Klitgaard_2006_table_3:row0:col2', 'Klitgaard_2006_table_3:row0:col3'])</li><li>dropped unlinked row (NIL): 'Trauma' — extend the ontology if this is a real PK parameter (source ['Klitgaard_2006_table_3:row1:col1', 'Klitgaard_2006_table_3:row1:col2', 'Klitgaard_2006_table_3:row1:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=recombinant activated factor VII (rFVIIa)</li><li>molar mass: none found for 'coagulation_factor_viia' — its concentrations stay mass-only</li><li>molar mass: none found for 'recombinant activated factor VII (rFVIIa)' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CoagulationFactorViia_Klitgaard2006_reference;
