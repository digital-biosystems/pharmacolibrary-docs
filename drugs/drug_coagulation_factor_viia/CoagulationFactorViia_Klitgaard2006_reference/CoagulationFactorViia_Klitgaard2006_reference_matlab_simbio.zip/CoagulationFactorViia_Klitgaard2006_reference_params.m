function p = CoagulationFactorViia_Klitgaard2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: coagulation_factor_viia   source: Klitgaard_2006 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'CoagulationFactorViia_Klitgaard2006_reference_params';
  p.drug  = 'coagulation_factor_viia';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.23;                % central volume [L]
  p.CL = 2.87;                % clearance [L/h]
  p.Vp = [2.17];             % peripheral volumes [L]
  p.Q  = [1.68];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
