function p = CoagulationFactorViia_Klitgaard2008_healthy_japanese_and_cau_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: coagulation_factor_viia   source: Klitgaard_2008 / healthy_japanese_and_caucasian_volunteers_16   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'CoagulationFactorViia_Klitgaard2008_healthy_japanese_and_cau_params';
  p.drug  = 'coagulation_factor_viia';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.81;                % central volume [L]
  p.CL = 2.38;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
