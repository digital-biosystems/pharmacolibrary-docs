% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = CoagulationFactorViia_Klitgaard2008_healthy_japanese_and_cau_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
