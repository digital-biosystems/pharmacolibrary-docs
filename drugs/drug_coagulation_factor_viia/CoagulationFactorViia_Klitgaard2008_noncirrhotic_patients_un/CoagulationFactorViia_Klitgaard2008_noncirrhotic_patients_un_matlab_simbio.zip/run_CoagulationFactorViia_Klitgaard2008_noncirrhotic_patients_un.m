% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = CoagulationFactorViia_Klitgaard2008_noncirrhotic_patients_un_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
