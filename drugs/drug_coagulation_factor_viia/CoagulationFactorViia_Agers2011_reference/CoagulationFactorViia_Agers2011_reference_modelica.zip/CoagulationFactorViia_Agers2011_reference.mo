// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model CoagulationFactorViia_Agers2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.00581},
    CLelim = {7.972222222222223e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = {}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>coagulation_factor_viia</td></tr><tr><td>population:</td><td>severe hemophilia patients</td></tr><tr><td>source_paper:</td><td>Agersø_2011</td></tr><tr><td>measured_compound:</td><td>rFVIIa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=rFVIIa</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>gap-filled Q22 (CL) from Klitgaard_2006's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Klitgaard_2006's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CoagulationFactorViia_Agers2011_reference;
