function p = PeginterferonBeta1a_Hang2016_PD_gd_lesion_count_params()
% PeginterferonBeta1a_Hang2016_PD_gd_lesion_count_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% peginterferon_beta_1a Hang_2016::Gd_lesion_count: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL h per second, in SI inside (kg/m3, s). Response Gd+ lesion count in its own unit. Driver: peginterferon_beta_1a (dose_only).
p.E0 = 0.48;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.0256;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
