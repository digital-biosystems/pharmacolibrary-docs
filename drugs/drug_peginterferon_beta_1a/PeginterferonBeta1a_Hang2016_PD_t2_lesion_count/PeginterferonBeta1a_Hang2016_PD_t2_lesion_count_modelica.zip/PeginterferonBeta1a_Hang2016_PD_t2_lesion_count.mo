model PeginterferonBeta1a_Hang2016_PD_t2_lesion_count
  "linear exposure-response sweep — Hang_2016 :: T2 lesion count (new or newly enlarged T2 hyperintense lesions)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0066,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -0.0147   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About peginterferon_beta_1a</h4><p>Peginterferon beta-1a is an interferon immunostimulant used to treat multiple sclerosis. It is authorised in the European Union, where one product is on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17126885\">Wikidata Q17126885</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>PeginterferonBeta1a_Hang2016_PD_t2_lesion_count</h4><p>The steady-state exposure-response curve of Hang Y et al., <i>Journal of pharmacokinetics and pharmacodynamics 43(4):371–383</i> 2016 (<a href=\"https://doi.org/10.1007/s10928-016-9477-x\">doi:10.1007/s10928-016-9477-x</a>) — new or newly enlarged T2 hyperintense lesions against peginterferon_beta_1a ng/mL h — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     0.0066          drug-free response (baseline) (Baseline mean T2 lesion count for a typical subject in the lower baseline lesion activity sub-population, Q324)
  slope =    -0.0147          change in response per unit of exposure (Slope of AUC effect on log(λ), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL h of peginterferon_beta_1a per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0066   (drug-free)</pre></body></html>"));
end PeginterferonBeta1a_Hang2016_PD_t2_lesion_count;
