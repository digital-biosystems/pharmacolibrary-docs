function p = Carbenicillin_Strydom2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carbenicillin   source: Strydom_2024 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Carbenicillin_Strydom2024_reference_params';
  p.drug  = 'carbenicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.0;                % central volume [L]
  p.CL = 32.8;                % clearance [L/h]
  p.Vp = [14.0];             % peripheral volumes [L]
  p.Q  = [0.8];             % inter-compartmental clearances [L/h]
  p.ka = 1.1;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
