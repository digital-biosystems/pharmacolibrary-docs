model Riluzole_Nguyen2021_reference
  parameter Real Cl_ref = 1.0777777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0214 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.234195,
    adminMass = 5e-05,
    ka = 0.001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>riluzole</td></tr><tr><td>population:</td><td>SCI patients</td></tr><tr><td>source_paper:</td><td>Nguyen_2021</td></tr><tr><td>measured_compound:</td><td>Riluzole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1876-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>riluzole 234.195 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Riluzole</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Nguyen_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 14515200, Tolerance = 1e-9, Interval = 1));
end Riluzole_Nguyen2021_reference;
