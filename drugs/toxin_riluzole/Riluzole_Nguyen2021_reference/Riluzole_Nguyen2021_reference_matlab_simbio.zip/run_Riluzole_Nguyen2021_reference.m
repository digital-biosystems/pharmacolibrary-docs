% Run (SimBiology): build model + dose, simulate 0..4032.0 h, plot.
p = Riluzole_Nguyen2021_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 4032.0);
