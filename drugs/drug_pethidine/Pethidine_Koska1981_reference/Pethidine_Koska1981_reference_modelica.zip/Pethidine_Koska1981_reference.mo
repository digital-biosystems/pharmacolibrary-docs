model Pethidine_Koska1981_reference
  parameter Real Cl_ref = 1.2133333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.26180000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pethidine</td></tr><tr><td>population:</td><td>surgical patients</td></tr><tr><td>source_paper:</td><td>Koska_1981</td></tr><tr><td>measured_compound:</td><td>meperidine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'total dose' — extend the ontology if this is a real PK parameter (source ['Koska_1981:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=meperidine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'meperidine', not pethidine — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pethidine_Koska1981_reference;
