function p = Pethidine_Morse2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pethidine   source: Morse_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pethidine_Morse2022_reference_params';
  p.drug  = 'pethidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 43.7;                % central volume [L]
  p.CL = 24.0;                % clearance [L/h]
  p.Vp = [29.7];             % peripheral volumes [L]
  p.Q  = [43.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.088333;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
