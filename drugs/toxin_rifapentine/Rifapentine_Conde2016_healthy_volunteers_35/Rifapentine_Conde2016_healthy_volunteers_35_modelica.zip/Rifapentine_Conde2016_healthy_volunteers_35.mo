model Rifapentine_Conde2016_healthy_volunteers_35
  parameter Real Cl_ref = 5.083333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.877,
    adminMass = 0.000525,
    ka = 3.3333333333333335e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifapentine</td></tr><tr><td>population:</td><td>adults with sputum smear-positive pulmonary tuberculosis</td></tr><tr><td>source_paper:</td><td>Conde_2016</td></tr><tr><td>measured_compound:</td><td>Rifapentine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone.0154778.t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifapentine 877 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'healthy volunteers [35]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Moxifloxacin / AUC0-24 (mcg*h/mL)'; source reconciliation required</li><li>column 'healthy volunteers [35]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Moxifloxacin / Cmax (mcg/mL)'; source reconciliation required</li><li>column 'healthy volunteers [35]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Rifapentine / AUC0-24 (mcg*h/mL)'; source reconciliation required</li><li>column 'healthy volunteers [35]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Rifapentine / Cmax (mcg/mL)'; source reconciliation required</li><li>column 'healthy volunteers [35]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'healthy volunteers [35]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q88 ('Rifapentine / AUC0-24 (mcg*h/mL)', value '410') — already have one for this compound</li><li>dropped duplicate Q32 ('Rifapentine / Cmax (mcg/mL)', value '21.2') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Rifapentine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'healthy volunteers [35]' subgroup of Conde_2016 (paper reports 9 populations: control arm rehz (n = 59), control armarm rehz (n = 59), current study, healthy volunteers [35], investigational arm pmhz (n = 62), investigational arm pmhz (n = 62)n = 62, overall n = 121, rifaquin [34], tbtc [30,36])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Rifapentine_Conde2016_healthy_volunteers_35;
