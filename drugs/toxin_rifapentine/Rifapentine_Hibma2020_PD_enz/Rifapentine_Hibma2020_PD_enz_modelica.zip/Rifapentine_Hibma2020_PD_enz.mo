model Rifapentine_Hibma2020_PD_enz
  "indirect_response_iii exposure-response sweep — Hibma_2020 :: ENZ (Enzyme production rate (kENZ) / Autoinduction)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 73,  // type III effect term
    EC50 = 0.00427,  // [kg/m3; mg/L × 0.001]
    gamma = 10,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 43, Interval = 0.086),
    Documentation(info = "<html><body><h4>Rifapentine_Hibma2020_PD_enz</h4><p>The steady-state exposure-response curve of Hibma JE et al., <i>American journal of respiratory and critical care medicine 202(6):866-877</i> 2020 (<a href=\"https://doi.org/10.1164/rccm.201912-2489oc\">doi:10.1164/rccm.201912-2489oc</a>) — Enzyme production rate (kENZ) / Autoinduction against rifapentine mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         73          maximal effect term (Emax, Q320)
  EC50  =       4.27 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =         10          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of rifapentine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.27 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Rifapentine_Hibma2020_PD_enz;
