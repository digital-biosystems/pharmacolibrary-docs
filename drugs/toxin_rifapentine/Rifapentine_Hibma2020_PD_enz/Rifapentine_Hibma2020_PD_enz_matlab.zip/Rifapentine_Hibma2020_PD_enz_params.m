function p = Rifapentine_Hibma2020_PD_enz_params()
% Rifapentine_Hibma2020_PD_enz_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifapentine Hibma_2020::ENZ: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response ENZ in its own unit. Driver: rifapentine (pk_record).
p.E0 = 0.0;
p.Emax = 73.0;
p.EC50 = 0.004269999999999999;
p.gamma = 10.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 43.0;
p.form = 'E0*(1 + Emax*frac)';
end
