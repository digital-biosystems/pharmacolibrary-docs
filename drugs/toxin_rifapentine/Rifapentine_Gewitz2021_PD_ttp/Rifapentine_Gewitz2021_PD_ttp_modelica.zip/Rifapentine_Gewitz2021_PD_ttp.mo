model Rifapentine_Gewitz2021_PD_ttp
  "linear exposure-response sweep — Gewitz_2021 :: TTP (time to positivity)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 1080000,      // [s; days × 86400]
    slope = 26006.4,  // [1]
    exposure_per_s = 1);   // 1 μg · h/ml per second
  // slope_unit_assumed: slope unit '(none)' read as days per μg · h/ml
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Rifapentine_Gewitz2021_PD_ttp</h4><p>The steady-state exposure-response curve of Gewitz AD et al., <i>Antimicrobial agents and chemotherapy 65(10):e0179420</i> 2021 (<a href=\"https://doi.org/10.1128/AAC.01794-20\">doi:10.1128/AAC.01794-20</a>) — time to positivity [days] against rifapentine μg · h/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       12.5 days     drug-free response (baseline) (Baseline, Q324)
  slope =      0.301          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg · h/ml of rifapentine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.08e+06   (drug-free)</pre></body></html>"));
end Rifapentine_Gewitz2021_PD_ttp;
