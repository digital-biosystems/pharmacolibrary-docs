model Rifapentine_Svensson2015_reference
  parameter Real Cl_ref = 8.88888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0162 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.877,
    adminMass = 0.00011,
    ka = 3.3333333333333335e-05,
    Tlag = 0.0,
    k12 = 8.076131687242798e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifapentine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Svensson_2015</td></tr><tr><td>measured_compound:</td><td>rifapentine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifapentine 877 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Svensson_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Rifapentine_Svensson2015_reference;
