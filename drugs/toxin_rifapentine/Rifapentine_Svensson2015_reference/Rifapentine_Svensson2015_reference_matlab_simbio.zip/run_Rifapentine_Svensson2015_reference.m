% Run (SimBiology): build model + dose, simulate 0..43.0 h, plot.
p = Rifapentine_Svensson2015_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 43.0);
