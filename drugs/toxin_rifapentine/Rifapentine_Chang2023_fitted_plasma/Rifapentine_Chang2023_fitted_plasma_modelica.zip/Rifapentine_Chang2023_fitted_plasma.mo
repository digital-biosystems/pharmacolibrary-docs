model Rifapentine_Chang2023_fitted_plasma
  parameter Real Cl_ref = 3.3055555555555553e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.877,
    adminMass = 0.00011,
    ka = 3.3333333333333335e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifapentine</td></tr><tr><td>population:</td><td>BALB/c mice</td></tr><tr><td>source_paper:</td><td>Chang_2023</td></tr><tr><td>measured_compound:</td><td>Rifapentine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifapentine 877 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'RPT 0.075 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RPT 0.25 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RPT 0.75 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RPT 1.25 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RFB 0.75 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RFB 1.5 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RFB 2.5 mg/kg BID'; source reconciliation required</li><li>table representations disagree for 'RFB 5.5 mg/kg BID'; source reconciliation required</li><li>dropped unlinked row (NIL): 'RPT 0.075 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row8:col3', 'tab_2:row8:col4'])</li><li>dropped unlinked row (NIL): 'RPT 0.25 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row9:col3', 'tab_2:row9:col4'])</li><li>dropped unlinked row (NIL): 'RPT 0.75 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row10:col3', 'tab_2:row10:col4'])</li><li>dropped unlinked row (NIL): 'RPT 1.25 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row11:col3', 'tab_2:row11:col4'])</li><li>dropped unlinked row (NIL): 'RFB 0.75 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row13:col3', 'tab_2:row13:col4'])</li><li>dropped unlinked row (NIL): 'RFB 1.5 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row14:col3', 'tab_2:row14:col4'])</li><li>dropped unlinked row (NIL): 'RFB 2.5 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row15:col3', 'tab_2:row15:col4'])</li><li>dropped unlinked row (NIL): 'RFB 5.5 mg/kg BID' — extend the ontology if this is a real PK parameter (source ['tab_2:row16:col3', 'tab_2:row16:col4'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Rifapentine_Chang2023_fitted_plasma;
