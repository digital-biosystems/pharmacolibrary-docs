model Rifapentine_Francis2019_reference
  parameter Real Cl_ref = 3.6944444444444447e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.877,
    adminMass = 0.00045,
    ka = 0.0002261111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifapentine</td></tr><tr><td>population:</td><td>patients diagnosed with pulmonary tuberculosis</td></tr><tr><td>source_paper:</td><td>Francis_2019</td></tr><tr><td>measured_compound:</td><td>Rifapentine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifapentine 877 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q40 ('Effect of HIV+ on F (%)', value '-21.9') — already have one for this compound</li><li>dropped 'Effect of group on 1,200-mg dose in RIFAQUIN study on CL (%)' → Q22 = -13.2: a clearance of -13.2 is not a parameter value (source ['T2:row11:col1'])</li><li>dropped duplicate Q40 ('Effect of Daily RPE study on F (%)', value '-23.3') — already have one for this compound</li><li>dropped 'AADAC rs1803155 (AA) effect on CL (%)' → Q22 = -10.4: a clearance of -10.4 is not a parameter value (source ['T2:row13:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Rifapentine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Rifapentine_Francis2019_reference;
