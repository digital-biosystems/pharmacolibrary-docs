function p = Rifapentine_Conde2016_current_study_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifapentine   source: Conde_2016 / current_study   route: oral
  % estimated (absent from source): F
  p.name  = 'Rifapentine_Conde2016_current_study_params';
  p.drug  = 'rifapentine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.0;                % central volume [L]
  p.CL = 1.83;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.12;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 525.0;             % dose [mg]
end
