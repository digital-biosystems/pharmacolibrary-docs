function p = Remimazolam_Colin2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remimazolam   source: Colin_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Remimazolam_Colin2025_reference_params';
  p.drug  = 'remimazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 854.0;                % central volume [L]
  p.CL = 2940.0;                % clearance [L/h]
  p.Vp = [756.0];             % peripheral volumes [L]
  p.Q  = [7056.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
