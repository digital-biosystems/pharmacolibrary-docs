function p = Remimazolam_Ueshima2025_PD_bis_params()
% Remimazolam_Ueshima2025_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% remimazolam Ueshima_2025::BIS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: remimazolam (pk_record).
p.E0 = 0.0;
p.Emax = -54.0;
p.EC50 = 7.96e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 800.0;
p.form = 'E0 + Emax*frac';
end
