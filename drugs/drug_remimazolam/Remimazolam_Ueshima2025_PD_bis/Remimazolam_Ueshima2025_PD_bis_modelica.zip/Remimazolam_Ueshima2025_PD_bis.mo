model Remimazolam_Ueshima2025_PD_bis
  "emax exposure-response sweep — Ueshima_2025 :: BIS (Bispectral index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -54,  // [1]
    EC50 = 7.96e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 800, Interval = 1.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About remimazolam</h4><p>Remimazolam is a benzodiazepine used for procedural sedation in adults during invasive diagnostic or surgical procedures. It is given as an intravenous injection. It is authorized in the European Union for conscious sedation and has also been approved in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q7311799\">Wikidata Q7311799</a>, <a href=\"https://en.wikipedia.org/wiki/Remimazolam?oldid=1384270870\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Remimazolam_Ueshima2025_PD_bis</h4><p>The steady-state exposure-response curve of Ueshima S et al., <i>Scientific reports 15(1):24979</i> 2025 (<a href=\"https://doi.org/10.1038/s41598-025-10015-z\">doi:10.1038/s41598-025-10015-z</a>) — Bispectral index against remimazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         54          maximal effect term (Emax, Q323)
  EC50  =       79.6 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of remimazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (79.6 ng/mL)  response -27
  exposure -> infinity  response -54</pre></body></html>"));
end Remimazolam_Ueshima2025_PD_bis;
