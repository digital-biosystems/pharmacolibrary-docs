function p = Remimazolam_Chen2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remimazolam   source: Chen_2025_2 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Remimazolam_Chen2025v2_reference_params';
  p.drug  = 'remimazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.35;                % central volume [L]
  p.CL = 79.8;                % clearance [L/h]
  p.Vp = [28.2];             % peripheral volumes [L]
  p.Q  = [17.58];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
