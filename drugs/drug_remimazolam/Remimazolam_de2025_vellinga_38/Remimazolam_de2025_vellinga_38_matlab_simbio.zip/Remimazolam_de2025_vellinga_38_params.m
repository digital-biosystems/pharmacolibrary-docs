function p = Remimazolam_de2025_vellinga_38_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remimazolam   source: de_2025 / vellinga_38   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Remimazolam_de2025_vellinga_38_params';
  p.drug  = 'remimazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.36;                % central volume [L]
  p.CL = 75.0;                % clearance [L/h]
  p.Vp = [11.7];             % peripheral volumes [L]
  p.Q  = [44.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
