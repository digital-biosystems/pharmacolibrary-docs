function p = Capivasertib_Fernandez2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: capivasertib   source: Fernandez_2025 / reference   route: oral
  p.name  = 'Capivasertib_Fernandez2025_reference_params';
  p.drug  = 'capivasertib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.0;                % central volume [L]
  p.CL = 59.6;                % clearance [L/h]
  p.Vp = [113.0];             % peripheral volumes [L]
  p.Q  = [23.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.441;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
