function p = Glutathione_Coradduzza2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glutathione   source: Coradduzza_2026 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Glutathione_Coradduzza2026_reference_params';
  p.drug  = 'glutathione';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.143783;                % central volume [L]
  p.CL = 35.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
