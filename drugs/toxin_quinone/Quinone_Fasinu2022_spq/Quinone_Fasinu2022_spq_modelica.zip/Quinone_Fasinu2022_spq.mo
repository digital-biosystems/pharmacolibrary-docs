// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Quinone_Fasinu2022_spq
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6840.0},
    MM = 0.259353,
    adminMass = 0.00315,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinone</td></tr><tr><td>population:</td><td>male Albino ND4 Swiss mice</td></tr><tr><td>source_paper:</td><td>Fasinu_2022</td></tr><tr><td>measured_compound:</td><td>Primaquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Carboxyprimaquine 274.32 g/mol (pubchem); Primaquine 259.353 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Tlast (h)' — extend the ontology if this is a real PK parameter (source ['Tab1:row4:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Primaquine</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'spq' subgroup of Fasinu_2022 (paper reports 2 populations: rpq, spq)</li><li>row roles (LLM): model_class=noncompartmental; 6/6 row label(s) assigned, 0 linked by role</li><li>review gap-fill skipped: this record measures 'Primaquine', not quinone — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Quinone_Fasinu2022_spq;
