function p = Diazepam_Ku2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diazepam   source: Ku_2018 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Diazepam_Ku2018_reference_params';
  p.drug  = 'diazepam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 3.8;                % clearance [L/h]
  p.Vp = [46.2];             % peripheral volumes [L]
  p.Q  = [18.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
