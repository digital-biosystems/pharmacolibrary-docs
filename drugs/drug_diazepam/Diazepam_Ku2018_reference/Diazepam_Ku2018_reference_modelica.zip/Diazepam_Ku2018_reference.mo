model Diazepam_Ku2018_reference
  parameter Real Cl_ref = 1.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 1.5281999324552516e-05,
    k21 = 0.00010882635882635882
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazepam</td></tr><tr><td>population:</td><td>children with status epilepticus</td></tr><tr><td>source_paper:</td><td>Ku_2018</td></tr><tr><td>measured_compound:</td><td>diazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>PSP4-7-718-s003.pdf</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>control_stream ADVAN3 TRANS4: topology=2C, parameterization=mechanistic (clearance)</li><li>theta_crosscheck: table present but its labels did not align to bound THETAs (skipped)</li><li>gap-filled Q22 (CL) from Carrascosa-Arteaga_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>gap-filled Q64 (V2) from Huang_2025_2's review values (primary lacked it)</li><li>gap-filled Q30 (Q) from Helfer_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diazepam_Ku2018_reference;
