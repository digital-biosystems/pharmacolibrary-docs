model Diazepam_Klotz1975_t1_2_b
  parameter Real Cl_ref = 2.1666666666666665e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07909999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazepam</td></tr><tr><td>population:</td><td>adults with liver disease and healthy controls</td></tr><tr><td>source_paper:</td><td>Klotz_1975</td></tr><tr><td>measured_compound:</td><td>diazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table i</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'B. S.*' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'B. S.†' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row2:col1'])</li><li>dropped unlinked row (NIL): 'M. C.*' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row3:col1'])</li><li>dropped unlinked row (NIL): 'M. C.†' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row4:col1'])</li><li>dropped unlinked row (NIL): 'J. H.*' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row5:col1'])</li><li>dropped unlinked row (NIL): 'J. H.†' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row6:col1'])</li><li>dropped unlinked row (NIL): 'J. H.§' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row7:col1'])</li><li>dropped unlinked row (NIL): 'J. M.*' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row8:col1'])</li><li>dropped unlinked row (NIL): 'J. M.†' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row9:col1'])</li><li>dropped unlinked row (NIL): 'J. J.*' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row10:col1'])</li><li>dropped unlinked row (NIL): 'J. J.†' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row11:col1'])</li><li>dropped unlinked row (NIL): 'Upper normal limit' — extend the ontology if this is a real PK parameter (source ['Klotz_1975_table_p9_1:row12:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diazepam_Klotz1975_t1_2_b;
