function p = Diazepam_Visser2003_PD_eeg_effects_params()
% Diazepam_Visser2003_PD_eeg_effects_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% diazepam Visser_2003::EEG_effects: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng.ml(-1) per second, in SI inside (kg/m3, s). Response EEG effects in its own unit. Driver: diazepam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.54;
p.EC50 = 0.00043599999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4400.0;
p.form = 'E0 + Emax*frac';
end
