model Diazepam_Visser2003_PD_eeg_effects
  "emax exposure-response sweep — Visser_2003 :: EEG effects (EEG effects)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.54,  // [1]
    EC50 = 0.000436,  // [kg/m3; ng.ml(-1) × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng.ml(-1) per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4400, Interval = 8.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diazepam</h4><p>Diazepam is a benzodiazepine sedative used for conditions such as anxiety, insomnia, epilepsy including status epilepticus, muscle spasticity, and alcohol withdrawal. It is widely used, appears on the WHO essential medicines list, and is also approved for veterinary use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q210402\">Wikidata Q210402</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diazepam_Visser2003_PD_eeg_effects</h4><p>The steady-state exposure-response curve of Visser SA et al., <i>The Journal of pharmacology and experimental therapeutics 304(1):88–101</i> 2003 (<a href=\"https://doi.org/10.1124/jpet.102.042341\">doi:10.1124/jpet.102.042341</a>) — EEG effects against diazepam ng.ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.54          maximal effect term (ePD, Q320)
  EC50  =        436 ng.ml(-1) exposure at half of the maximal effect term (KPD, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng.ml(-1) of diazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (436 ng.ml(-1))  response 0.27
  exposure -> infinity  response 0.54</pre></body></html>"));
end Diazepam_Visser2003_PD_eeg_effects;
