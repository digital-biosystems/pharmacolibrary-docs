model Diazepam_Visser2003_PD_eeg
  "emax exposure-response sweep — Visser_2003 :: EEG (amplitude in the β-frequency band of the EEG)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 9.9,      // [V]
    Emax = 10.6,  // [V]
    EC50 = 0.000373,  // [kg/m3; ng·ml⁻¹ × 1e-06]
    gamma = 1.17,
    exposure_per_s = 1e-06);   // 1 ng·ml⁻¹ per second
  annotation(experiment(StartTime = 0, StopTime = 3800, Interval = 7.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diazepam</h4><p>Diazepam is a benzodiazepine sedative used for conditions such as anxiety, insomnia, epilepsy including status epilepticus, muscle spasticity, and alcohol withdrawal. It is widely used, appears on the WHO essential medicines list, and is also approved for veterinary use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q210402\">Wikidata Q210402</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diazepam_Visser2003_PD_eeg</h4><p>The steady-state exposure-response curve of Visser SA et al., <i>The Journal of pharmacology and experimental therapeutics 304(1):88–101</i> 2003 (<a href=\"https://doi.org/10.1124/jpet.102.042341\">doi:10.1124/jpet.102.042341</a>) — amplitude in the β-frequency band of the EEG [V] against diazepam ng·ml⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        9.9 V        drug-free response (baseline) (no-drug response, Q324)
  Emax  =       10.6 V        maximal effect term (intrinsic activity, Q320)
  EC50  =        373 ng·ml⁻¹  exposure at half of the maximal effect term (potency, Q321)
  gamma =       1.17          Hill coefficient (slope factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng·ml⁻¹ of diazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 9.9   (drug-free)
  exposure = EC50 (373 ng·ml⁻¹)  response 15.2
  exposure -> infinity  response 20.5</pre></body></html>"));
end Diazepam_Visser2003_PD_eeg;
