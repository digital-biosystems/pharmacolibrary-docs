function p = Diazepam_Visser2003_PD_eeg_params()
% Diazepam_Visser2003_PD_eeg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% diazepam Visser_2003::EEG: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·ml⁻¹ per second, in SI inside (kg/m3, s). Response EEG in V. Driver: diazepam (cited_pk).
p.E0 = 9.9;
p.Emax = 10.6;
p.EC50 = 0.00037299999999999996;
p.gamma = 1.17;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3800.0;
p.form = 'E0 + Emax*frac';
end
