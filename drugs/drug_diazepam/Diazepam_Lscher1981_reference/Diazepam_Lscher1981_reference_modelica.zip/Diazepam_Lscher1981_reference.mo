// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Diazepam_Lscher1981_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.329},
    CLelim = {1.0555555555555555e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazepam</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Löscher_1981</td></tr><tr><td>measured_compound:</td><td>diazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('maximal diazepam concentrations', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=diazepam</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Carrascosa-Arteaga_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diazepam_Lscher1981_reference;
