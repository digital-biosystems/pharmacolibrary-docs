model Penciclovir_Ogungbenro2009_reference
  parameter Real Cl_ref = 0.0006066666666666666 "Cl [m3/s]";
  parameter Real Vd_ref = 5.816999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2532578,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About penciclovir</h4><p>Penciclovir is an antiviral nucleoside analogue used to treat herpes simplex infections and has been used against Epstein–Barr virus infection. It is an approved drug, applied topically to the skin as a dermatological antiviral and also available for systemic use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420364\">Wikidata Q420364</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>penciclovir</td></tr><tr><td>population:</td><td>adults and children</td></tr><tr><td>source_paper:</td><td>Ogungbenro_2009</td></tr><tr><td>measured_compound:</td><td>penciclovir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>penciclovir 253.258 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=penciclovir</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Penciclovir_Ogungbenro2009_reference;
