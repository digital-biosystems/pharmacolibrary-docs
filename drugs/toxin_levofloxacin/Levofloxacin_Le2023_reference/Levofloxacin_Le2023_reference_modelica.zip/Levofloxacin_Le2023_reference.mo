// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Levofloxacin_Le2023_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1630.9345424939888},
    MM = 0.361373,
    adminMass = 0.0005,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levofloxacin</td></tr><tr><td>population:</td><td>rabbits and humans</td></tr><tr><td>source_paper:</td><td>Le_2023</td></tr><tr><td>measured_compound:</td><td>Levofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>levofloxacin 361.373 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'logP(neutral)' — extend the ontology if this is a real PK parameter (source ['Tab1:row3:col3'])</li><li>'Fu' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped unlinked row (NIL): 'Fu melanin' — extend the ontology if this is a real PK parameter (source ['Tab1:row5:col3'])</li><li>unit_dimension_unknown: '× 10–4 cm/s' (Kp_derm)</li><li>dropped unlinked row (NIL): 'PermCornea_epi' — extend the ontology if this is a real PK parameter (source ['Tab1:row15:col3'])</li><li>dropped unlinked row (NIL): 'PermCornea_str' — extend the ontology if this is a real PK parameter (source ['Tab1:row16:col3'])</li><li>dropped unlinked row (NIL): 'PermConjunctiva' — extend the ontology if this is a real PK parameter (source ['Tab1:row17:col3'])</li><li>dropped unlinked row (NIL): 'PermAH' — extend the ontology if this is a real PK parameter (source ['Tab1:row18:col3'])</li><li>dropped unlinked row (NIL): 'PermICB' — extend the ontology if this is a real PK parameter (source ['Tab1:row19:col3'])</li><li>dropped unlinked row (NIL): 'PermSclera' — extend the ontology if this is a real PK parameter (source ['Tab1:row20:col3'])</li><li>dropped unlinked row (NIL): 'PermChoroid' — extend the ontology if this is a real PK parameter (source ['Tab1:row21:col3'])</li><li>dropped unlinked row (NIL): 'PermRetina' — extend the ontology if this is a real PK parameter (source ['Tab1:row22:col3'])</li><li>unit_dimension_unknown: '× 10–6 cm/s' (Kp_derm)</li><li>dropped duplicate Q412 ('PermV.H', value '7.2') — already have one for this compound</li><li>unit_dimension_unknown: '× 10–4 s−1' (kel)</li><li>dropped unlinked row (NIL): 'SARRetina' — extend the ontology if this is a real PK parameter (source ['Tab1:row25:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Levofloxacin_Le2023_reference;
