// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Levofloxacin_Cen2023_control_group
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2952.0},
    MM = 0.361373,
    adminMass = 0.0035,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levofloxacin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Cen_2023</td></tr><tr><td>measured_compound:</td><td>Levofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>cns13989-tbl-0004</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>levofloxacin 361.373 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'C max'; source reconciliation required</li><li>table representations disagree for 'T max'; source reconciliation required</li><li>table representations disagree for 'AUC0–180'; source reconciliation required</li><li>table representations disagree for 'AUC0–∞'; source reconciliation required</li><li>table representations disagree for 't 1/2'; source reconciliation required</li><li>table representations disagree for 'MRT'; source reconciliation required</li><li>table representations disagree for 'K p,uu,CSF'; source reconciliation required</li><li>table representations disagree for 'K p,uu,ECF'; source reconciliation required</li><li>dropped duplicate Q410 ('K p,uu,ECF', value '34.0') — already have one for this compound</li><li>dropped value-less row: 'TABLE 4. Key pharmacokinetic parameters of LVFX (50 mg/kg) with or without treatment with transporter inhibitors'</li><li>dropped value-less row: 'The specific grouping is shown in Section 2.7. Significant data relative to the Control group were highlighted in bold, with the symbol * representing significance level:'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levofloxacin</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'control group' subgroup of Cen_2023 (paper reports 2 populations: control group, pro group)</li><li>gap-filled Q22 (CL) from Deshpande_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Levofloxacin_Cen2023_control_group;
