model Tocainide_Oltmanns1983_reference
  parameter Real Cl_ref = 2.1466666666666663e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3054866353621235 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1922575,
    adminMass = 0.0012
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tocainide</h4><p>Tocainide is a class Ib antiarrhythmic that was used to treat heart arrhythmia and was also studied for trigeminal neuralgia. It has been withdrawn and is no longer in use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q757058\">Wikidata Q757058</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tocainide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Oltmanns_1983</td></tr><tr><td>measured_compound:</td><td>tocainide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tocainide 192.257 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Oltmanns_1983) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Tocainide_Oltmanns1983_reference;
