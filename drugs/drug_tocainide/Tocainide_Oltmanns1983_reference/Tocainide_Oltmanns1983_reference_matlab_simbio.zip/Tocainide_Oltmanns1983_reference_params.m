function p = Tocainide_Oltmanns1983_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tocainide   source: Oltmanns_1983 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tocainide_Oltmanns1983_reference_params';
  p.drug  = 'tocainide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 305.486635;                % central volume [L]
  p.CL = 7.728;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
