model Glycopyrronium_Bartels2021_mf
  parameter Real Cl_ref = 5.833333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.8 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0006666666666666666,
    Tlag = 0.0,
    k12 = 3.8580246913580246e-05,
    k21 = 1.8768768768768768e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>glycopyrronium</td></tr><tr><td>population:</td><td>patients with asthma</td></tr><tr><td>source_paper:</td><td>Bartels_2021</td></tr><tr><td>measured_compound:</td><td>indacaterol, glycopyrronium, mometasone furoate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'mf' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'mf' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'mf' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Duration of zero-order absorption (h)' — extend the ontology if this is a real PK parameter (source ['Tab5:row8:col5'])</li><li>dropped unlinked row (NIL): 'Body weight on Q/F' — extend the ontology if this is a real PK parameter (source ['Tab5:row25:col5'])</li><li>dropped unlinked row (NIL): 'Body weight on Vp/F' — extend the ontology if this is a real PK parameter (source ['Tab5:row26:col5'])</li><li>salvaged Q27 ('CL/F (L/h)'=210) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F (L)'=1800) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F (L/h)'=250) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('Vp/F (L)'=3700) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (1/h)'=2.4) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=indacaterol, glycopyrronium, mometasone furoate</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Glycopyrronium_Bartels2021_mf;
