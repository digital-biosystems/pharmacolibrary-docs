function p = Glycopyrronium_Bartels2021_mf_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glycopyrronium   source: Bartels_2021 / mf   route: oral
  % estimated (absent from source): dose
  p.name  = 'Glycopyrronium_Bartels2021_mf_params';
  p.drug  = 'glycopyrronium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1800.0;                % central volume [L]
  p.CL = 210.0;                % clearance [L/h]
  p.Vp = [3700.0];             % peripheral volumes [L]
  p.Q  = [250.0];             % inter-compartmental clearances [L/h]
  p.ka = 2.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
