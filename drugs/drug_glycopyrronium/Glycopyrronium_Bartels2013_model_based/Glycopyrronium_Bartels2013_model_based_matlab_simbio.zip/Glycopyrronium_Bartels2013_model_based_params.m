function p = Glycopyrronium_Bartels2013_model_based_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glycopyrronium   source: Bartels_2013 / model_based   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Glycopyrronium_Bartels2013_model_based_params';
  p.drug  = 'glycopyrronium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1566.6;                % central volume [L]
  p.CL = 44.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
