model Glycopyrronium_Bartels2013_model_based
  parameter Real Cl_ref = 1.2472222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.5666 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3184305,
    adminMass = 0.00012,
    ka = 2.406761043610921e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About glycopyrronium</h4><p>Glycopyrronium is an anticholinergic (muscarinic antagonist) used for conditions such as peptic ulcer disease and chronic obstructive pulmonary disease, and also as an anesthetic adjuvant and antihidrotic. It remains in use, with approved and veterinary-approved products, and is used in inhaled combinations for obstructive airway diseases as well as gastrointestinal and dermatological preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411917\">Wikidata Q411917</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>glycopyrronium</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Bartels_2013</td></tr><tr><td>measured_compound:</td><td>glycopyrronium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>glycopyrronium 318.43 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('GI tract absorption half-life', value '2') — already have one for this compound</li><li>dropped unlinked row (NIL): '0' — extend the ontology if this is a real PK parameter (source ['Bartels_2013_table_2:row21:col1'])</li><li>implicit units: 'Systemic clearance' → L/h (from the popPK convention: 'Systemic clearance in population PK is standardly expressed in L/h; the magnitude 44.9 is consistent with this unit for ')</li><li>implicit units: 'Volume of distribution at steady state ‡' → L (from the popPK convention: 'Volume of distribution at steady state is standardly expressed in L; the magnitude 102 is consistent with this unit for ')</li><li>implicit units: 'Intermediate lung absorption half-life' → h (from the paper text: &quot;Table 5 footnote states: 'rate constants, K, expressed as half-lives, t1/2 = ln(2)/K'. In the Results section, a similar&quot;)</li><li>implicit units: 'Slow lung absorption half-life' → h (from the paper text: &quot;Table 5 footnote states: 'rate constants, K, expressed as half-lives, t1/2 = ln(2)/K'. The Discussion section explicitly&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=glycopyrronium</li><li>population split: 'model-based' subgroup of Bartels_2013 (paper reports 3 populations: model-based, noncompartmental, population mean (%cv))</li><li>gap-filled Q61 (V) from Marchiori_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Glycopyrronium_Bartels2013_model_based;
