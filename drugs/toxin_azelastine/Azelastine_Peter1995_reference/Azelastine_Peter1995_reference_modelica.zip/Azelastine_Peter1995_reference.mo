// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Azelastine_Peter1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {138600.0},
    MM = 0.367877,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>azelastine</td></tr><tr><td>population:</td><td>elderly volunteers</td></tr><tr><td>source_paper:</td><td>Peter_1995</td></tr><tr><td>measured_compound:</td><td>Azelastine and N-demethyl-azelastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Azelastine and N-demethyl-azelastine 367.877 g/mol (pubchem); Azelastine hydrochloride 418.362 g/mol (pubchem); N-demethyl-azelastine 367.877 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'young volunteers age' — extend the ontology if this is a real PK parameter (source ['Peter_1995:abstract'])</li><li>dropped duplicate Q57 ('t1/2 young single dose', value 25.0) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 elderly multiple dose', value 35.5) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 young multiple dose', value 55.4) — already have one for this compound</li><li>dropped PD-category row 'ratios of accumulation Rmin' → Q336 (R0, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Peter_1995:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Azelastine and N-demethyl-azelastine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles: 4 per-group rows of Azelastine hydrochloride summary_statistic but 2 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=noncompartmental; 7/7 row label(s) assigned, 0 linked by role; re-tagged Azelastine and N-demethyl-azelastine→parent ×6</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1555.2));
end Azelastine_Peter1995_reference;
