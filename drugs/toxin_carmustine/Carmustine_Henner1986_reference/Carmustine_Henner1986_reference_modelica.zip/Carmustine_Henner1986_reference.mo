model Carmustine_Henner1986_reference
  parameter Real Cl_ref = 9.053333333333332e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.357 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carmustine</td></tr><tr><td>population:</td><td>patients with advanced neoplasms receiving high-dose combination chemotherapy</td></tr><tr><td>source_paper:</td><td>Henner_1986</td></tr><tr><td>measured_compound:</td><td>Carmustine (BCNU)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carmustine 214.046 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'protein bound' — extend the ontology if this is a real PK parameter (source ['Henner_1986:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Carmustine (BCNU)</li><li>molar mass: none found for 'Carmustine (BCNU)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carmustine_Henner1986_reference;
