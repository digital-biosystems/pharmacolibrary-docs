model Ibuprofen_Trocniz2000_estimate
  parameter Real Cl_ref = 1.125e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0044 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00022777777777777775,
    Tlag = 4788.0,
    k12 = 0.00013194444444444443,
    k21 = 8.769721383014433e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibuprofen</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Trocóniz_2000</td></tr><tr><td>measured_compound:</td><td>ibuprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('kₐ,grn1 (h⁻¹)', value '0.61') — already have one for this compound</li><li>dropped duplicate Q49 ('kₐ,grn2 (h⁻¹)', value '2.26') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ibuprofen</li><li>population split: 'estimate' subgroup of Trocóniz_2000 (paper reports 2 populations: estimate, interindividual variabilityᵃ)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ibuprofen_Trocniz2000_estimate;
