function p = Ibuprofen_Knihinicki1990_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Knihinicki_1990 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Ibuprofen_Knihinicki1990_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 202.320667;                % central volume [L]
  p.CL = 52.92;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
