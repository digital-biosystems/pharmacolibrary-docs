function p = Ibuprofen_Brown1992_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Brown_1992 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Ibuprofen_Brown1992_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 72.1;                % central volume [L]
  p.CL = 5.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
