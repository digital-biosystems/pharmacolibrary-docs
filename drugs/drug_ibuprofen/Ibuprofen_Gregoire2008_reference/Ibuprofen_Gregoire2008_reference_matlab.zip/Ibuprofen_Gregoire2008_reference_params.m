function p = Ibuprofen_Gregoire2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Gregoire_2008 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ibuprofen_Gregoire2008_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.11;                % central volume [L]
  p.CL = 0.245;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.1;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
