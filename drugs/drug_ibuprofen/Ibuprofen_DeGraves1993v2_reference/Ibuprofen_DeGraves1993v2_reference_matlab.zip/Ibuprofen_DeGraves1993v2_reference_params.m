function p = Ibuprofen_DeGraves1993v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: DeGraves_1993_2 / reference   route: oral
  p.name  = 'Ibuprofen_DeGraves1993v2_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.347;                % central volume [L]
  p.CL = 6.034;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.1;                % absorption rate [1/h]
  p.F  = 0.99;                 % bioavailability [0-1]
  p.Tlag = 0.1;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
