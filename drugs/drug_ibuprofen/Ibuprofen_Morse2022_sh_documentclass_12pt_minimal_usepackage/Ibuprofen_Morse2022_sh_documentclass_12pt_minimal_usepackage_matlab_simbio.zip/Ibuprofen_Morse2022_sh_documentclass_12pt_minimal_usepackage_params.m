function p = Ibuprofen_Morse2022_sh_documentclass_12pt_minimal_usepackage_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Morse_2022 / sh_documentclass_12pt_minimal_usepackage_amsmath_usepackage_wasysym_usepackage_amsfonts_usepackage_amssymb_usepackage_amsbsy_usepackage_mathrsfs_usepackage_upgreek_setlength_oddsidemargin_69pt_begin_document_eta_end_document   route: oral
  % estimated (absent from source): F
  p.name  = 'Ibuprofen_Morse2022_sh_documentclass_12pt_minimal_usepackage_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.7;                % central volume [L]
  p.CL = 28.8;                % clearance [L/h]
  p.Vp = [15.8];             % peripheral volumes [L]
  p.Q  = [25.4];             % inter-compartmental clearances [L/h]
  p.ka = 1.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 325.0;             % dose [mg]
end
