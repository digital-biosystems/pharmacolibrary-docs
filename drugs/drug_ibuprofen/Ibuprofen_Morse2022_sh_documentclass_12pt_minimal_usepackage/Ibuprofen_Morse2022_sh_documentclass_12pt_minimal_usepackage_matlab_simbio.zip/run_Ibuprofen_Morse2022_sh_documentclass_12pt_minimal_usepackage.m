% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Ibuprofen_Morse2022_sh_documentclass_12pt_minimal_usepackage_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
