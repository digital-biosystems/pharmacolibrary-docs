function p = Ibuprofen_SoriaChacartegui2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Soria-Chacartegui_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ibuprofen_SoriaChacartegui2026_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 126.0;                % central volume [L]
  p.CL = 51.1;                % clearance [L/h]
  p.Vp = [171.0];             % peripheral volumes [L]
  p.Q  = [175.0];             % inter-compartmental clearances [L/h]
  p.ka = 3.09;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
