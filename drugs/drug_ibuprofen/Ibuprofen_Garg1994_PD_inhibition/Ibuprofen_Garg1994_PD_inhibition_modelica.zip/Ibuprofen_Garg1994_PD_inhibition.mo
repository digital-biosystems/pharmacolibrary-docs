model Ibuprofen_Garg1994_PD_inhibition
  "indirect_response_i exposure-response sweep — Garg_1994 :: %Inhibition (Inhibition of fever)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 110.267857143,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.0101,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (98.8/0.896 = 110.3) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ibuprofen</h4><p>Ibuprofen is a non-steroidal anti-inflammatory medicine used to relieve pain, inflammation and fever, and for conditions such as osteoarthritis, rheumatoid arthritis, migraine and gout. It is widely used and available over the counter in the UK, and is also authorised in the European Union for pain and for treating a heart vessel problem in premature babies.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q186969\">Wikidata Q186969</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ibuprofen_Garg1994_PD_inhibition</h4><p>The steady-state exposure-response curve of Garg V et al., <i>Clinical pharmacology and therapeutics 55(1):87–88</i> 1994 (<a href=\"https://doi.org/10.1038/clpt.1994.16\">doi:10.1038/clpt.1994.16</a>) — Inhibition of fever against ibuprofen mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 110.267857143          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       10.1 mg/L     exposure at half of the maximal effect term (ICso, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of ibuprofen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 110.3   (drug-free)
  exposure = EC50 (10.1 mg/L)  response 55.13
  exposure -> infinity  response 0</pre></body></html>"));
end Ibuprofen_Garg1994_PD_inhibition;
