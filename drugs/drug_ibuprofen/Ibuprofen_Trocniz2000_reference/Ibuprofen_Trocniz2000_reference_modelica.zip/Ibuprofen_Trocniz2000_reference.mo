model Ibuprofen_Trocniz2000_reference
  parameter Real Cl_ref = 6.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0044 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.008611111111111111,
    Tlag = 57600.0,
    k12 = 0.0029040404040404037,
    k21 = 0.00019658119658119656
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibuprofen</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Trocóniz_2000</td></tr><tr><td>measured_compound:</td><td>ibuprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('kₐ,grn1 (h⁻¹)', value '33') — already have one for this compound</li><li>dropped duplicate Q49 ('kₐ,grn2 (h⁻¹)', value '2.26') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ibuprofen</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ibuprofen_Trocniz2000_reference;
