function p = Ibuprofen_Trocniz2000_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Trocóniz_2000 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ibuprofen_Trocniz2000_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.4;                % central volume [L]
  p.CL = 24.0;                % clearance [L/h]
  p.Vp = [65.0];             % peripheral volumes [L]
  p.Q  = [46.0];             % inter-compartmental clearances [L/h]
  p.ka = 31.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 16.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
