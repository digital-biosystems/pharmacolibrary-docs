function p = Ibuprofen_Hong2008_PD_platelet_aggregation_params()
% Ibuprofen_Hong2008_PD_platelet_aggregation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibuprofen Hong_2008::platelet_aggregation: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response platelet aggregation in ohms. Driver: ibuprofen (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0156;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
