function p = Ibuprofen_Brown1998_ibu05_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Brown_1998 / ibu05   route: oral
  % estimated (absent from source): dose
  p.name  = 'Ibuprofen_Brown1998_ibu05_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.2;                % central volume [L]
  p.CL = 5.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 7.75;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
