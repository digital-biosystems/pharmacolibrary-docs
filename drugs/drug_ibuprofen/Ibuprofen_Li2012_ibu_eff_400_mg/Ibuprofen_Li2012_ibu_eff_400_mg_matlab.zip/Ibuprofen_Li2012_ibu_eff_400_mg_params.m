function p = Ibuprofen_Li2012_ibu_eff_400_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Li_2012 / ibu_eff_400_mg   route: oral
  p.name  = 'Ibuprofen_Li2012_ibu_eff_400_mg_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.45;                % central volume [L]
  p.CL = 3.77;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 23.7;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.14;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
