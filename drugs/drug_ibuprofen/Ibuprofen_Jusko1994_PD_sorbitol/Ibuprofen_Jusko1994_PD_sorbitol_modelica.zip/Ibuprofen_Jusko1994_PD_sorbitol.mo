model Ibuprofen_Jusko1994_PD_sorbitol
  "indirect_response_i exposure-response sweep — Jusko_1994 :: Sorbitol (sorbitol concentration)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0.0,      // [1]
    Emax = 12.99,  // type IV effect term
    EC50 = 2.6399999999999998e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // off_target_driver: driver compound 'aldose reductase inhibitor' is not 'ibuprofen' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 12.99; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 264, Interval = 0.528));
end Ibuprofen_Jusko1994_PD_sorbitol;
