function p = Ibuprofen_Jusko1994_PD_sorbitol_params()
% Ibuprofen_Jusko1994_PD_sorbitol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibuprofen Jusko_1994::Sorbitol: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response Sorbitol in its own unit. Driver: aldose reductase inhibitor (conc_no_pk).
p.E0 = 0.0;
p.Emax = 12.99;
p.EC50 = 2.6399999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 264.0;
p.form = 'E0/(1 + Emax*frac)';
end
