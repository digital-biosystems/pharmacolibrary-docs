model Ibuprofen_Brown1998_ibu10
  parameter Real Cl_ref = 2.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0154 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0022833333333333334,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibuprofen</td></tr><tr><td>population:</td><td>febrile children</td></tr><tr><td>source_paper:</td><td>Brown_1998</td></tr><tr><td>measured_compound:</td><td>ibuprofen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table iv</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 't_lag (hr) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_3:row1:col3'])</li><li>dropped unlinked row (NIL): 'k_a (hr⁻¹) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_3:row3:col3'])</li><li>dropped unlinked row (NIL): 'β (hr⁻¹) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_3:row5:col3'])</li><li>dropped unlinked row (NIL): 'T₁/₂ (hr) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_3:row7:col3'])</li><li>dropped unlinked row (NIL): 'Total n' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_3:row8:col3', 'Brown_1998_table_4:row6:col3'])</li><li>dropped unlinked row (NIL): 'AUC₀→∞ (µg/ml*hr) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_4:row1:col3'])</li><li>dropped unlinked row (NIL): 'V_d/F (L/kg) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_4:row3:col3'])</li><li>dropped unlinked row (NIL): 'Cl_p/F (L/kg/hr) SE' — extend the ontology if this is a real PK parameter (source ['Brown_1998_table_4:row5:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ibuprofen</li><li>population split: 'ibu10' subgroup of Brown_1998 (paper reports 2 populations: ibu05, ibu10)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ibuprofen_Brown1998_ibu10;
