function p = Ibuprofen_Morse2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibuprofen   source: Morse_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ibuprofen_Morse2022_reference_params';
  p.drug  = 'ibuprofen';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 43.7;                % central volume [L]
  p.CL = 24.0;                % clearance [L/h]
  p.Vp = [29.7];             % peripheral volumes [L]
  p.Q  = [43.5];             % inter-compartmental clearances [L/h]
  p.ka = 3.61642;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
