function p = ArginineHydrochloride_Yeo2013_severemalaria_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arginine_hydrochloride   source: Yeo_2013 / severemalaria   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'ArginineHydrochloride_Yeo2013_severemalaria_params';
  p.drug  = 'arginine_hydrochloride';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 115.0;                % central volume [L]
  p.CL = 61.8;                % clearance [L/h]
  p.Vp = [70.9];             % peripheral volumes [L]
  p.Q  = [21.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12000.0;             % dose [mg]
end
