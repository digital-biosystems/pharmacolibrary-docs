function p = ArginineHydrochloride_Yeo2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: arginine_hydrochloride   source: Yeo_2013 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'ArginineHydrochloride_Yeo2013_reference_params';
  p.drug  = 'arginine_hydrochloride';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.0;                % central volume [L]
  p.CL = 31.0;                % clearance [L/h]
  p.Vp = [21.0];             % peripheral volumes [L]
  p.Q  = [74.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
