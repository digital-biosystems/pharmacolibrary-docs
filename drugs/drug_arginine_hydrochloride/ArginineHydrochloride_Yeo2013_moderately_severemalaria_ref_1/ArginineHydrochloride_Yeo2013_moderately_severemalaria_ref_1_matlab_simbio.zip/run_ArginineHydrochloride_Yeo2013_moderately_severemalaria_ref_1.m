% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = ArginineHydrochloride_Yeo2013_moderately_severemalaria_ref_1_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
