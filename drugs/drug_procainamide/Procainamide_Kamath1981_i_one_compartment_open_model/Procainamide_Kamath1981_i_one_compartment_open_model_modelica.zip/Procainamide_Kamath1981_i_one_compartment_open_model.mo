model Procainamide_Kamath1981_i_one_compartment_open_model
  parameter Real Cl_ref = 4.007111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.322 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2353253,
    adminMass = 0.00525
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About procainamide</h4><p>Procainamide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medicine, though it is not authorised in the European Union and is used mainly in other regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417597\">Wikidata Q417597</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>procainamide</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kamath_1981</td></tr><tr><td>measured_compound:</td><td>procainamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 111</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>procainamide 235.325 g/mol (drugbank); N-acetylprocainamide 277.368 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=procainamide</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>population split: 'i, one-compartment open model (n = 8)' subgroup of Kamath_1981 (paper reports 4 populations: i, one-compartment open model (n = 8), ii, pseudo-three-compartment modela (n = 7), ii, two-compartment open modelb (n = 8), mean)</li><li>row roles (LLM): model_class=compartmental; 19/19 row label(s) assigned, 54 linked by role; re-tagged parent→N-acetylprocainamide ×31</li><li>engineer: parent_metabolite composite downgraded to a 1C model of the measured compound — the paper reports the metabolite's own CL and V but neither the parent's disposition nor a formation rate, so the parent sub-component could not be populated; the parent's concentration-time course is NOT produced by this model</li><li>derived CL=144.256 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Procainamide_Kamath1981_i_one_compartment_open_model;
