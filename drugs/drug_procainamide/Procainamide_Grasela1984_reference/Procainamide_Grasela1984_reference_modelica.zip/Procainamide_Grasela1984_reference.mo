model Procainamide_Grasela1984_reference
  parameter Real Cl_ref = 3.333333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.136 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2353253,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About procainamide</h4><p>Procainamide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medicine, though it is not authorised in the European Union and is used mainly in other regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417597\">Wikidata Q417597</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>procainamide</td></tr><tr><td>population:</td><td>patients receiving procainamide</td></tr><tr><td>source_paper:</td><td>Grasela_1984</td></tr><tr><td>measured_compound:</td><td>procainamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table iii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>procainamide 235.325 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CLA (L/h)', value '10.1') — already have one for this compound</li><li>covariate level 'Decrease in CLR and CLA associated with CHF' → Q900:decrease_in_clr_and_cla_associated_with_chf = 0.11 (additive_shift on Q26)</li><li>unit_dimension_unknown: '£' (Fab)</li><li>dropped duplicate Q40 ('OCHF2', value 0) — already have one for this compound</li><li>unit_dimension_unknown: '£' (Fab)</li><li>dropped duplicate Q40 ('OCHF1', value 0.11) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=procainamide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end Procainamide_Grasela1984_reference;
