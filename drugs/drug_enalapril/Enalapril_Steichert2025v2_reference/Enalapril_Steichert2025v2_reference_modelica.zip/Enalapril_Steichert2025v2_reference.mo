model Enalapril_Steichert2025v2_reference
  parameter Real Cl_ref = 1.0108333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.22371000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.348399,
    adminMass = 1.6100000000000002e-05,
    ka = 0.00033055555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>enalapril</td></tr><tr><td>population:</td><td>healthy adults and children with heart failure</td></tr><tr><td>source_paper:</td><td>Steichert_2025_2</td></tr><tr><td>measured_compound:</td><td>enalaprilat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-01345-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enalapril 376.447 g/mol (drugbank); enalaprilat 348.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV ktr' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV ktr' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV Mtt' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV Mtt' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV V1/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV V1/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV E0' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV E0' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV IC50' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV IC50' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Enalapril_Steichert2025v2_reference;
