function p = Enalapril_Steichert2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: enalapril   source: Steichert_2025_2 / reference   route: oral
  p.name  = 'Enalapril_Steichert2025v2_reference_params';
  p.drug  = 'enalapril';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 223.71;                % central volume [L]
  p.CL = 36.39;                % clearance [L/h]
  p.Vp = [108.26];             % peripheral volumes [L]
  p.Q  = [6.38];             % inter-compartmental clearances [L/h]
  p.ka = 1.19;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.2;             % dose [mg]
end
