model Enalapril_Hockings1986_PD_ace_inhibition
  "sigmoid_emax exposure-response sweep — Hockings_1986 :: ACE inhibition (ACE inhibition)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.898,  // [1; % × 0.01]
    EC50 = 1.83,  // [ng mt']
    gamma = 1,
    exposure_per_s = 1);   // 1 ng mt' per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: "ng mt'" — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 19, Interval = 0.038),
    Documentation(info = "<html><body><h4>Enalapril_Hockings1986_PD_ace_inhibition</h4><p>The steady-state exposure-response curve of Hockings N et al., <i>British journal of clinical pharmacology 21(4):341–348</i> 1986 (<a href=\"https://doi.org/10.1111/j.1365-2125.1986.tb05205.x\">doi:10.1111/j.1365-2125.1986.tb05205.x</a>) — ACE inhibition [%] against enalaprilat ng mt' — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       89.8 %        maximal effect term (Emax (%0) — YI, Q320)
  EC50  =       1.83 ng mt'   exposure at half of the maximal effect term (C50 (ng mt') — YI, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng mt' of enalaprilat per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.83 ng mt')  response -0.449
  exposure -> infinity  response -0.898</pre></body></html>"));
end Enalapril_Hockings1986_PD_ace_inhibition;
