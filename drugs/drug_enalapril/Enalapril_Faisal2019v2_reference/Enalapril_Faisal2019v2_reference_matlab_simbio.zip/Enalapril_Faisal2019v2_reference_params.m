function p = Enalapril_Faisal2019v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: enalapril   source: Faisal_2019_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Enalapril_Faisal2019v2_reference_params';
  p.drug  = 'enalapril';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.0;                % central volume [L]
  p.CL = 0.75;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
