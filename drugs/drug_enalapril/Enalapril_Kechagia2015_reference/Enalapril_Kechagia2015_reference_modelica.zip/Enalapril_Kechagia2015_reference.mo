model Enalapril_Kechagia2015_reference
  parameter Real Cl_ref = 2.308333333333334e-06 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Real Vd_ref = 0.09 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref + (1.7888888888888891e-06)*(if cov_category_0 then 1 else 0) + (8.250000000000001e-07)*(if cov_category_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.348399,
    adminMass = 2.5e-06,
    ka = 0.00025833333333333334,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>enalapril</td></tr><tr><td>population:</td><td>paediatric patients (literature data, infants to 16 years)</td></tr><tr><td>source_paper:</td><td>Kechagia_2015</td></tr><tr><td>measured_compound:</td><td>enalaprilat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enalapril 376.447 g/mol (drugbank); enalaprilat 348.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Inter group variability for CL, %CV' → Q900:inter_group_variability_for_cl_cv = 6.44 (additive_shift on Q22)</li><li>covariate level 'Inter group variability for V1, %CV' → Q900:inter_group_variability_for_v1_cv = 2.97 (additive_shift on Q22)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL a , L/h); Q63 (V1 a , L); Q30 (Q a , L/h); Q64 (V2 a , L)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=enalaprilat</li><li>template fit: PK_3M_9C — formed from central; parent 0, metabolites [2]</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles (LLM): model_class=compartmental; 11/11 row label(s) assigned, 12 linked by role; re-tagged enalaprilat→parent ×4</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Enalapril_Kechagia2015_reference;
