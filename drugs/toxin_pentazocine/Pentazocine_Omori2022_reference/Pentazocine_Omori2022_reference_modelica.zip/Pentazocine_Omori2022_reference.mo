model Pentazocine_Omori2022_reference
  parameter Real Cl_ref = 2.3916666666666664e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07210000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.285431,
    adminMass = 1.5e-05,
    k12 = 0.0009385113268608413,
    k21 = 0.0003333333333333334
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentazocine</td></tr><tr><td>population:</td><td>in-hospital orthopedic surgery patients</td></tr><tr><td>source_paper:</td><td>Omori_2022</td></tr><tr><td>measured_compound:</td><td>Pentazocine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentazocine 285.431 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Pentazocine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pentazocine_Omori2022_reference;
