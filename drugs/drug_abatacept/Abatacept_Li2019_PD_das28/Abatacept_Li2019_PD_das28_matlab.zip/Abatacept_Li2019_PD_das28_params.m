function p = Abatacept_Li2019_PD_das28_params()
% Abatacept_Li2019_PD_das28_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% abatacept Li_2019::DAS28: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response DAS28 in its own unit. Driver: abatacept (cited_pk).
p.E0 = 6.22;
p.Emax = -2.15;
p.EC50 = 0.006819999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 69.0;
p.form = 'E0 + Emax*frac';
end
