model Abatacept_Li2019_PD_das28
  "emax exposure-response sweep — Li_2019 :: DAS28 (Disease Activity Score in 28 joints)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.22,      // [1]
    Emax = -2.15,  // [1]
    EC50 = 0.00682,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 69, Interval = 0.138),
    Documentation(info = "<html><body><!-- drug-about --><h4>About abatacept</h4><p>Abatacept is an immunosuppressive, disease-modifying antirheumatic drug used to treat forms of arthritis, including rheumatoid, psoriatic, and juvenile arthritis. It is an approved medicine authorised in the European Union, with additional investigational uses being studied.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2697833\">Wikidata Q2697833</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Abatacept_Li2019_PD_das28</h4><p>The steady-state exposure-response curve of Li X et al., <i>Journal of clinical pharmacology 59(2):245–257</i> 2019 (<a href=\"https://doi.org/10.1002/jcph.1308\">doi:10.1002/jcph.1308</a>) — Disease Activity Score in 28 joints against abatacept μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.22          drug-free response (baseline) (E0, Q324)
  Emax  =       2.15          maximal effect term (Emax,aba, Q323)
  EC50  =       6.82 μg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of abatacept per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.22   (drug-free)
  exposure = EC50 (6.82 μg/mL)  response 5.145
  exposure -> infinity  response 4.07</pre></body></html>"));
end Abatacept_Li2019_PD_das28;
