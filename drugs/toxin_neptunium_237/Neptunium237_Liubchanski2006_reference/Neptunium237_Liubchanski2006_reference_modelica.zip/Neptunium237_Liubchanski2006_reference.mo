// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Neptunium237_Liubchanski2006_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {35424.0},
    MM = 0.23704817,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>neptunium_237</td></tr><tr><td>population:</td><td>Wistar rats and mongrel dogs</td></tr><tr><td>source_paper:</td><td>Liubchanskiĭ_2006</td></tr><tr><td>measured_compound:</td><td>237Np</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>neptunium_237 237.048 g/mol (pubchem); 237Np 237.048 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'prevalence of fast phase' — extend the ontology if this is a real PK parameter (source ['Liubchanskiĭ_2006:abstract'])</li><li>dropped unlinked row (NIL): 'prevalence of intermediate phase' — extend the ontology if this is a real PK parameter (source ['Liubchanskiĭ_2006:abstract', 'Liubchanskiĭ_2006:abstract'])</li><li>dropped unlinked row (NIL): 'T(eff) intermediate phase' — extend the ontology if this is a real PK parameter (source ['Liubchanskiĭ_2006:abstract', 'Liubchanskiĭ_2006:abstract'])</li><li>dropped unlinked row (NIL): 'prevalence of slow clearance phase' — extend the ontology if this is a real PK parameter (source ['Liubchanskiĭ_2006:abstract', 'Liubchanskiĭ_2006:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=237Np</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Neptunium237_Liubchanski2006_reference;
