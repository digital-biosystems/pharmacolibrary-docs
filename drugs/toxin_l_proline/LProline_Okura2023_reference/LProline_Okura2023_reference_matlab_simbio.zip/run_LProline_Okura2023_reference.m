% Run (SimBiology): build model + dose, simulate 0..504.0 h, plot.
p = LProline_Okura2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 504.0);
