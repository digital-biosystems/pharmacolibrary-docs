model LProline_Tee2022_reference
  parameter Real Cl_ref = 3.14e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.1089592824702013 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.115132,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>l_proline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tee_2022</td></tr><tr><td>measured_compound:</td><td>l_proline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>l_proline 115.132 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tee_2022) — secondary source</li><li>central volume derived from CL·t½/ln2</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end LProline_Tee2022_reference;
