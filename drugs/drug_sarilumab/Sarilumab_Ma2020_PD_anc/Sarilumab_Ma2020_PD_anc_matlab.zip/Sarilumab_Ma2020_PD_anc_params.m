function p = Sarilumab_Ma2020_PD_anc_params()
% Sarilumab_Ma2020_PD_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sarilumab Ma_2020::ANC: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response ANC in × 10^9/L. Driver: sarilumab (cited_pk).
p.E0 = 5.38;
p.Emax = 1.5;
p.EC50 = 0.010299999999999998;
p.gamma = 0.862;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 36.0;
p.form = 'E0/(1 + Emax*frac)';
end
