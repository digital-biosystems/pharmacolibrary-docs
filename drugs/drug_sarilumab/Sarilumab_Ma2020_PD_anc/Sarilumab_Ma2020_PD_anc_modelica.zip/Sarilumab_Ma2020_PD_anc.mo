model Sarilumab_Ma2020_PD_anc
  "indirect_response_iv exposure-response sweep — Ma_2020 :: ANC (Absolute Neutrophil Count)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 5.38,      // [× 10^9/L]
    Emax = 1.5,  // type IV effect term
    EC50 = 0.0103,  // [kg/m3; mg/L × 0.001]
    gamma = 0.862,
    exposure_per_s = 0.001);   // 1 mg/L per second
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sarilumab</h4><p>Sarilumab is a monoclonal antibody used to treat rheumatoid arthritis. It is an approved interleukin inhibitor, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7424081\">Wikidata Q7424081</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Sarilumab_Ma2020_PD_anc</h4><p>The steady-state exposure-response curve of Ma L et al., <i>Clinical pharmacokinetics 59(11):1451–1466</i> 2020 (<a href=\"https://doi.org/10.1007/s40262-020-00899-7\">doi:10.1007/s40262-020-00899-7</a>) — Absolute Neutrophil Count [× 10^9/L] against sarilumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       5.38 × 10^9/L drug-free response (baseline) (BASE, Q324)
  Emax  =        1.5          maximal effect term (Emax, Q320)
  EC50  =       10.3 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =      0.862          Hill coefficient (Γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one mg/L of sarilumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5.38   (drug-free)
  exposure = EC50 (10.3 mg/L)  response 3.074
  exposure -> infinity  response 2.152</pre></body></html>"));
end Sarilumab_Ma2020_PD_anc;
