function p = Sarilumab_Ma2020_PD_das28_crp_params()
% Sarilumab_Ma2020_PD_das28_crp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sarilumab Ma_2020::DAS28_CRP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response DAS28-CRP in its own unit. Driver: sarilumab (cited_pk).
p.E0 = 6.06;
p.Emax = 0.237;
p.EC50 = 0.0023199999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 24.0;
p.form = 'E0*(1 - Emax*frac)';
end
