model Sarilumab_Ma2020_PD_das28_crp
  "indirect_response_i exposure-response sweep — Ma_2020 :: DAS28-CRP (28-joint disease activity score by C-reactive protein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 6.06,      // [1]
    Emax = 0.237,  // type I effect term
    EC50 = 0.00232,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 24, Interval = 0.048),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sarilumab</h4><p>Sarilumab is a monoclonal antibody used to treat rheumatoid arthritis. It is an approved interleukin inhibitor, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7424081\">Wikidata Q7424081</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Sarilumab_Ma2020_PD_das28_crp</h4><p>The steady-state exposure-response curve of Ma L et al., <i>Clinical pharmacokinetics 59(11):1451–1466</i> 2020 (<a href=\"https://doi.org/10.1007/s40262-020-00899-7\">doi:10.1007/s40262-020-00899-7</a>) — 28-joint disease activity score by C-reactive protein against sarilumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.06          drug-free response (baseline) (BASE, Q324)
  Emax  =      0.237          maximal effect term (Log (Emax), Q323)
  EC50  =       2.32 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of sarilumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.06   (drug-free)
  exposure = EC50 (2.32 mg/L)  response 5.342
  exposure -> infinity  response 4.624</pre></body></html>"));
end Sarilumab_Ma2020_PD_das28_crp;
