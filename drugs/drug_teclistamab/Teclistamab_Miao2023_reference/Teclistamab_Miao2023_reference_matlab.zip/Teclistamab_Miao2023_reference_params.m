function p = Teclistamab_Miao2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: teclistamab   source: Miao_2023 / reference   route: oral
  p.name  = 'Teclistamab_Miao2023_reference_params';
  p.drug  = 'teclistamab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.13;                % central volume [L]
  p.CL = 0.018708;                % clearance [L/h]
  p.Vp = [1.34];             % peripheral volumes [L]
  p.Q  = [0.001625];             % inter-compartmental clearances [L/h]
  p.ka = 0.005542;                % absorption rate [1/h]
  p.F  = 0.718;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.021;             % dose [mg]
end
