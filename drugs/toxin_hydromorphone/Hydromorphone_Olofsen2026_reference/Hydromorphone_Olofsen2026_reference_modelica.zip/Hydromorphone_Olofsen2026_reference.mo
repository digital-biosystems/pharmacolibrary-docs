// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Hydromorphone_Olofsen2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2556.0},
    MM = 0.285343,
    adminMass = 4e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydromorphone</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Olofsen_2026</td></tr><tr><td>measured_compound:</td><td>hydromorphone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>hydromorphone 285.343 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'morphine potency' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Olofsen_2026:abstract'])</li><li>dropped PD-category row 'hydromorphone potency' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Olofsen_2026:abstract'])</li><li>relinked 't½ke0 morphine' Q326 → Q57: a half-life by its label (the unit decides, not the label)</li><li>relinked 't½ke0 hydromorphone' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('t½ke0 hydromorphone', value 0.75) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydromorphone</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Gao_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Coluzzi_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Hydromorphone_Olofsen2026_reference;
