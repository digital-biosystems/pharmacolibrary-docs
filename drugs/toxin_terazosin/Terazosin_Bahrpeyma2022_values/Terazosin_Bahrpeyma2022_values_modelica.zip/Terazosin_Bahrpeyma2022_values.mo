// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Terazosin_Bahrpeyma2022_values
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5400.0},
    MM = 0.38744,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>terazosin</td></tr><tr><td>population:</td><td>isolated porcine retinal pigment epithelium/choroid melanin particles, porcive eye melanosomes and re-pigmented ARPE-19 cells (in vitro)</td></tr><tr><td>source_paper:</td><td>Bahrpeyma_2022</td></tr><tr><td>measured_compound:</td><td>Terazosin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>terazosin 387.44 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Amount melanin (isolated melanosomes)' — extend the ontology if this is a real PK parameter (source ['Bahrpeyma_2022_table_1:row5:col1'])</li><li>unit_dimension_unknown: 'melanin study' (equation variable)</li><li>unit_dimension_unknown: '50%' (equation variable)</li><li>dropped duplicate Q900 ('Cell number', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'Melanosomal volume fraction' — extend the ontology if this is a real PK parameter (source ['Bahrpeyma_2022_table_1:row14:col1'])</li><li>salvaged Q57 ('half-lives of the high binders (papaverin, terazosin, and levofloxacin)'=1.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Terazosin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'values' subgroup of Bahrpeyma_2022 (paper reports 2 populations: terazosin, values)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Terazosin_Bahrpeyma2022_values;
