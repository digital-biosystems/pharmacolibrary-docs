// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Terazosin_Jungers1986_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {36000.0},
    MM = 0.38744,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>terazosin</td></tr><tr><td>population:</td><td>patients with varying degrees of renal insufficiency</td></tr><tr><td>source_paper:</td><td>Jungers_1986</td></tr><tr><td>measured_compound:</td><td>Terazosin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>terazosin 387.44 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('plasma half-life of terazosin in patients with moderate renal insufficiency', value 8.4) — already have one for this compound</li><li>dropped duplicate Q57 ('plasma half-life of terazosin in the group with severe renal insufficiency', value 9.8) — already have one for this compound</li><li>unit_dimension_unknown: 'ml per minute' (CLR)</li><li>unit_dimension_unknown: 'ml per minute' (CLR)</li><li>dropped duplicate Q26 ('creatinine clearance (moderate renal insufficiency)', value 30) — already have one for this compound</li><li>unit_dimension_unknown: 'ml per minute' (CLR)</li><li>dropped duplicate Q26 ('creatinine clearance (severe renal insufficiency)', value 10) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Terazosin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q26 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Terazosin_Jungers1986_reference;
