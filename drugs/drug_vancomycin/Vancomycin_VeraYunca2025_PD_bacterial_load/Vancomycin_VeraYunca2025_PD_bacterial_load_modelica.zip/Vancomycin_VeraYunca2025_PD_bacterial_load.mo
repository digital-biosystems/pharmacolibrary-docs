model Vancomycin_VeraYunca2025_PD_bacterial_load
  "sigmoid_emax exposure-response sweep — Vera-Yunca_2025 :: bacterial load (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -0.00048333333333333334,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00056,  // [kg/m3; mg/L × 0.001]
    gamma = 1.0,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.6, Interval = 0.0112));
end Vancomycin_VeraYunca2025_PD_bacterial_load;
