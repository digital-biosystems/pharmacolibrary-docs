function p = Vancomycin_VeraYunca2025_PD_bacterial_load_params()
% Vancomycin_VeraYunca2025_PD_bacterial_load_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vancomycin Vera-Yunca_2025::bacterial_load: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response bacterial load in cfu/total lung. Driver: linezolid, vancomycin (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.00048333333333333334;
p.EC50 = 0.00056;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 5.6;
p.form = 'E0 + Emax*frac';
end
