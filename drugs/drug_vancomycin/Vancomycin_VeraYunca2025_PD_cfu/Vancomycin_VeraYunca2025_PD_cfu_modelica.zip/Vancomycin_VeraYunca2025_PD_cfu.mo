model Vancomycin_VeraYunca2025_PD_cfu
  "sigmoid_emax exposure-response sweep — Vera-Yunca_2025 :: cfu (Bacterial load)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000483333333333,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.000245,  // [kg/m3; mg/L × 0.001]
    gamma = 20,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2.5, Interval = 0.005),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vancomycin</h4><p>Vancomycin is a glycopeptide antibiotic used to treat serious bacterial infections, including staphylococcal infections, pneumonia, infective endocarditis, and pseudomembranous colitis. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used, typically in hospital settings for severe infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424027\">Wikidata Q424027</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Vancomycin_VeraYunca2025_PD_cfu</h4><p>The steady-state exposure-response curve of Vera-Yunca D et al., <i>The Journal of antimicrobial chemotherapy 80(7):1860–1868</i> 2025 (<a href=\"https://doi.org/10.1093/jac/dkaf140\">doi:10.1093/jac/dkaf140</a>) — Bacterial load [log10 (cfu/mL)] against vancomycin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.74 h−1      maximal effect term (E max,VAN, Q323)
  EC50  =      0.245 mg/L     exposure at half of the maximal effect term (EC50,VAN,0, Q321)
  gamma =         20          Hill coefficient (γ VAN, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of vancomycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.245 mg/L)  response -0.0002417
  exposure -> infinity  response -0.0004833</pre></body></html>"));
end Vancomycin_VeraYunca2025_PD_cfu;
