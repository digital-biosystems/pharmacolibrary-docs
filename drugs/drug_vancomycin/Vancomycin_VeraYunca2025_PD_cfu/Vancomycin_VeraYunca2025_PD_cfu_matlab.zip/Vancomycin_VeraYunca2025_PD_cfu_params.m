function p = Vancomycin_VeraYunca2025_PD_cfu_params()
% Vancomycin_VeraYunca2025_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vancomycin Vera-Yunca_2025::cfu: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response cfu in log10 (cfu/mL). Driver: vancomycin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.00048333333333333334;
p.EC50 = 0.00024499999999999994;
p.gamma = 20.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.5;
p.form = 'E0 + Emax*frac';
end
