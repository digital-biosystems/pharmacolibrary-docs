% Run (SimBiology): build model + dose, simulate 0..31.0 h, plot.
p = Vancomycin_Goyal2022_final_pk_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 31.0);
