function p = Vancomycin_Goyal2022_final_pk_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Goyal_2022 / final_pk_model   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vancomycin_Goyal2022_final_pk_model_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 67.35;                % central volume [L]
  p.CL = 7.64;                % clearance [L/h]
  p.Vp = [37.5];             % peripheral volumes [L]
  p.Q  = [9.06];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
