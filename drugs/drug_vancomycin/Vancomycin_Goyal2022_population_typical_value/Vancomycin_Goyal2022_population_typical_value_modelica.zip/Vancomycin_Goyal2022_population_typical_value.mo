model Vancomycin_Goyal2022_population_typical_value
  parameter Real Cl_ref = 2.7777777777777776e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.0001111111111111111,
    k21 = 0.0001111111111111111
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>pregnant women</td></tr><tr><td>source_paper:</td><td>Goyal_2022</td></tr><tr><td>measured_compound:</td><td>vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('qCRCL', value '1.0') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vancomycin</li><li>population split: 'population typical value' subgroup of Goyal_2022 (paper reports 3 populations: final pk model, formula, population typical value)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Goyal2022_population_typical_value;
