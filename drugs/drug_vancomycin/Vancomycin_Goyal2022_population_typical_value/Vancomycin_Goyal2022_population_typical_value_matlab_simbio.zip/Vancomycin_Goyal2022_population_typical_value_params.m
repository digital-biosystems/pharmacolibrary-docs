function p = Vancomycin_Goyal2022_population_typical_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Goyal_2022 / population_typical_value   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vancomycin_Goyal2022_population_typical_value_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.0;                % central volume [L]
  p.CL = 1.0;                % clearance [L/h]
  p.Vp = [5.0];             % peripheral volumes [L]
  p.Q  = [2.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
