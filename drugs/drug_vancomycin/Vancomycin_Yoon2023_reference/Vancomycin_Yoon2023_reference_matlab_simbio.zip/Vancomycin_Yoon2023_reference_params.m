function p = Vancomycin_Yoon2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Yoon_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vancomycin_Yoon2023_reference_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 38.6;                % central volume [L]
  p.CL = 4.32;                % clearance [L/h]
  p.Vp = [66.8];             % peripheral volumes [L]
  p.Q  = [3.93];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
