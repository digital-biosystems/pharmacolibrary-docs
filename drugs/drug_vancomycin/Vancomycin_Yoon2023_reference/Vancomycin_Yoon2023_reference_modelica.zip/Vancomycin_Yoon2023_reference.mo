model Vancomycin_Yoon2023_reference
  parameter Real Cl_ref = 1.2e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0386 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k21 = 1.6342315369261478e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>patients with infections</td></tr><tr><td>source_paper:</td><td>Yoon_2023</td></tr><tr><td>measured_compound:</td><td>vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'kCr (if age ≥30) (yr-1)' — extend the ontology if this is a real PK parameter (source ['T3:row7:col1'])</li><li>dropped unlinked row (NIL): 'kCr (if age <30) (yr-1)' — extend the ontology if this is a real PK parameter (source ['T3:row8:col1'])</li><li>unit_dimension_unknown: 'Creatinine clearance related parameter' (kel)</li><li>dropped unlinked row (NIL): 'PMA50' — extend the ontology if this is a real PK parameter (source ['T3:row11:col1'])</li><li>dropped unlinked row (NIL): 'γ' — extend the ontology if this is a real PK parameter (source ['T3:row12:col1'])</li><li>dropped unlinked row (NIL): 'ktox (day-1)' — extend the ontology if this is a real PK parameter (source ['T3:row14:col1'])</li><li>dropped unlinked row (NIL): 'kV' — extend the ontology if this is a real PK parameter (source ['T3:row16:col1'])</li><li>dropped unlinked row (NIL): 'kBUN' — extend the ontology if this is a real PK parameter (source ['T3:row17:col1'])</li><li>kept covariate coefficient θREN=-0.237 (covariate REN) — not an ontology parameter</li><li>kept covariate coefficient θFEM=-0.199 (covariate FEM) — not an ontology parameter</li><li>kept covariate coefficient θDM=-0.151 (covariate DM) — not an ontology parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vancomycin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Yoon2023_reference;
