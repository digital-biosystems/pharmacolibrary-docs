model Vancomycin_Yoon2023_reference
  parameter Real Cl_ref = 1.2e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0386 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.4492539999999998,
    adminMass = 0.002,
    k12 = 2.828151986183074e-05,
    k21 = 1.6342315369261478e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vancomycin</h4><p>Vancomycin is a glycopeptide antibiotic used to treat serious bacterial infections, including staphylococcal infections, pneumonia, infective endocarditis, and pseudomembranous colitis. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used, typically in hospital settings for severe infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424027\">Wikidata Q424027</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>patients with infections (including children)</td></tr><tr><td>source_paper:</td><td>Yoon_2023</td></tr><tr><td>measured_compound:</td><td>vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.25 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 CL (CV(%))' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'ω2 V2 (CV(%))' routed out of structural estimates ('Between subject variability')</li><li>table section residual_error: 'σ2 proportional trough (CV %))' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ2 additive trough (mg/L)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ2 proportional peak (CV %))' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ2 additive peak (mg/L)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'kCr (if age ≥30) (yr-1)' — extend the ontology if this is a real PK parameter (source ['T3:row7:col1'])</li><li>dropped unlinked row (NIL): 'kCr (if age <30) (yr-1)' — extend the ontology if this is a real PK parameter (source ['T3:row8:col1'])</li><li>unit_dimension_unknown: 'Creatinine clearance related parameter' (kel)</li><li>dropped unlinked row (NIL): 'PMA50' — extend the ontology if this is a real PK parameter (source ['T3:row11:col1'])</li><li>dropped unlinked row (NIL): 'γ' — extend the ontology if this is a real PK parameter (source ['T3:row12:col1'])</li><li>dropped unlinked row (NIL): 'ktox (day-1)' — extend the ontology if this is a real PK parameter (source ['T3:row14:col1'])</li><li>dropped unlinked row (NIL): 'kV' — extend the ontology if this is a real PK parameter (source ['T3:row16:col1'])</li><li>dropped unlinked row (NIL): 'kBUN' — extend the ontology if this is a real PK parameter (source ['T3:row17:col1'])</li><li>kept covariate coefficient θREN=-0.237 (covariate REN) — not an ontology parameter</li><li>kept covariate coefficient θFEM=-0.199 (covariate FEM) — not an ontology parameter</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Yoon2023_reference;
