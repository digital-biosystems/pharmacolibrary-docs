model Carbamazepine_Djordjevic2025_reference
  parameter Real Cl_ref = 4.861111111111111e-08 "Cl [m3/s]";
  parameter Real cov_cyp1a2_0 = 0 "cyp1a2 covariate";
  parameter Real cov_abcb1_1 = 0 "abcb1 covariate";
  parameter Real Vd_ref = 1.26 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.0176)*cov_cyp1a2_0)*(1 + (0.0332)*cov_abcb1_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002425,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbamazepine</td></tr><tr><td>population:</td><td>pediatric epileptic patients</td></tr><tr><td>source_paper:</td><td>Djordjevic_2025</td></tr><tr><td>measured_compound:</td><td>carbamazepine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pediatrrep-17-00010-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['pediatrrep-17-00010-t003:row1:col2'])</li><li>dropped unlinked row (NIL): 'SEX' — extend the ontology if this is a real PK parameter (source ['pediatrrep-17-00010-t003:row3:col1', 'pediatrrep-17-00010-t003:row3:col2', 'pediatrrep-17-00010-t003:row3:col3', 'pediatrrep-17-00010-t003:row3:col4'])</li><li>dropped unlinked row (NIL): 'DD (mg/L)' — extend the ontology if this is a real PK parameter (source ['pediatrrep-17-00010-t003:row4:col1', 'pediatrrep-17-00010-t003:row4:col2', 'pediatrrep-17-00010-t003:row4:col3', 'pediatrrep-17-00010-t003:row4:col4'])</li><li>covariate level 'CYP1A2' → Q900:cyp1a2 = 0.0176 (linear_fractional on Q27)</li><li>covariate level 'ABCB1' → Q900:abcb1 = 0.0332 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=carbamazepine</li><li>gap-filled Q76 (V/F) from Kudo_1999's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chan_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carbamazepine_Djordjevic2025_reference;
