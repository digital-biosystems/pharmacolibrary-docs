// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Carbamazepine_Yip2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.17450000000000002},
    CLelim = {2.5250000000000004e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbamazepine</td></tr><tr><td>population:</td><td>healthy volunteers and epilepsy patients</td></tr><tr><td>source_paper:</td><td>Yip_2021</td></tr><tr><td>measured_compound:</td><td>carbamazepine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 6</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=carbamazepine</li><li>topology: 3 first-order transfer(s) across 4 compounds → general_linear</li><li>gap-filled Q22 (CL) from Chan_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Naik_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chan_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carbamazepine_Yip2021_reference;
