function p = Carbamazepine_Milovanovic2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carbamazepine   source: Milovanovic_2016 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Carbamazepine_Milovanovic2016_reference_params';
  p.drug  = 'carbamazepine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 174.5;                % central volume [L]
  p.CL = 0.215;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.873;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
