model Carbamazepine_Lukic2024_reference
  parameter Real Cl_ref = 2.5250000000000004e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17450000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0002425,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbamazepine</td></tr><tr><td>population:</td><td>adults with acute carbamazepine self-poisoning</td></tr><tr><td>source_paper:</td><td>Lukic_2024</td></tr><tr><td>measured_compound:</td><td>carbamazepine and carbamazepine-10,11-epoxide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=carbamazepine and carbamazepine-10,11-epoxide</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Chan_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Naik_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chan_2023's review values (primary lacked it)</li><li>engineer: parent_metabolite composite downgraded to a 1C model of the measured compound — the paper reports the metabolite's own CL and V but neither the parent's disposition nor a formation rate, so the parent sub-component could not be populated; the parent's concentration-time course is NOT produced by this model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carbamazepine_Lukic2024_reference;
