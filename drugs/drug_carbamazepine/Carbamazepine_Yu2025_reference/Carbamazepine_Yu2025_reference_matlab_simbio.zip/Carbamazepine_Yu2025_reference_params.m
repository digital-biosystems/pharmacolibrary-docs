function p = Carbamazepine_Yu2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carbamazepine   source: Yu_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Carbamazepine_Yu2025_reference_params';
  p.drug  = 'carbamazepine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 227.0;                % central volume [L]
  p.CL = 0.177;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
