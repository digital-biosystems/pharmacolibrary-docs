model Carbamazepine_Punyawudho2012_reference
  parameter Real Cl_ref = 9.972222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.472222222222223e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbamazepine</td></tr><tr><td>population:</td><td>elderly patients with epilepsy</td></tr><tr><td>source_paper:</td><td>Punyawudho_2012</td></tr><tr><td>measured_compound:</td><td>carbamazepine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'If taking PHT' — extend the ontology if this is a real PK parameter (source ['T2:row5:col1', 'T2:row5:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=carbamazepine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carbamazepine_Punyawudho2012_reference;
