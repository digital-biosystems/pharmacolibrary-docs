model Heparin_Salem2022_reference
  parameter Real Cl_ref = 9.11111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.012362000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 2.1944444444444445e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About heparin</h4><p>Heparin is an anticoagulant (blood thinner) used to treat and prevent blood clots, including pulmonary embolism, and is also used in antiphospholipid syndrome. It is a widely used medicine and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q190016\">Wikidata Q190016</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>heparin</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Salem_2022</td></tr><tr><td>measured_compound:</td><td>unfractionated heparin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h·50 kg' (CL)</li><li>implicit units: 'CL' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. For total clearance (CL) in population pharmacokinetics, the s')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=unfractionated heparin</li><li>molar mass: none found for 'heparin' — its concentrations stay mass-only</li><li>molar mass: none found for 'unfractionated heparin' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gouin-Thibault_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Heparin_Salem2022_reference;
