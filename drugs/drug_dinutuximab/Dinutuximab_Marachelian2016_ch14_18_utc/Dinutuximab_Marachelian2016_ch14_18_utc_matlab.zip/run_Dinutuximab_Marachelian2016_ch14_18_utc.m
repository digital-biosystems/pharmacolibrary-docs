% Run: build params, simulate 0..192.0 h, plot + save Dinutuximab_Marachelian2016_ch14_18_utc.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Dinutuximab_Marachelian2016_ch14_18_utc.m
here = fileparts(mfilename('fullpath'));
p = Dinutuximab_Marachelian2016_ch14_18_utc_params();
out = simulate_pk(p, 0:0.05:192.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('dinutuximab — Marachelian_2016 (iv_bolus)');
print(fig, fullfile(here, 'Dinutuximab_Marachelian2016_ch14_18_utc.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Dinutuximab_Marachelian2016_ch14_18_utc.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Dinutuximab_Marachelian2016_ch14_18_utc.json'), 'w');
try
  s.model = 'Dinutuximab_Marachelian2016_ch14_18_utc'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Dinutuximab_Marachelian2016_ch14_18_utc","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Dinutuximab_Marachelian2016_ch14_18_utc.png, Dinutuximab_Marachelian2016_ch14_18_utc.csv, Dinutuximab_Marachelian2016_ch14_18_utc.json\n');
