model Dinutuximab_Marachelian2016_ch14_18_nci
  parameter Real Cl_ref = 8.680555555555555e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00136 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 8.135893246187362e-06,
    k21 = 2.9427698975571312e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dinutuximab</h4><p>Dinutuximab is a monoclonal antibody anticancer drug used to treat neuroblastoma. It is authorised in the European Union, though one EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21011236\">Wikidata Q21011236</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dinutuximab</td></tr><tr><td>population:</td><td>pediatric patients with high-risk neuroblastoma</td></tr><tr><td>source_paper:</td><td>Marachelian_2016</td></tr><tr><td>measured_compound:</td><td>dinutuximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/d/m2' (CL)</li><li>dropped duplicate Q22 ('CL (L/d/m2)', value '1.17') — already have one for this compound</li><li>unit_dimension_unknown: 'L/d/m2' (Q)</li><li>dropped duplicate Q30 ('Q (L/d/m2)', value '1.46') — already have one for this compound</li><li>unit_dimension_unknown: 'L/m2' (V1)</li><li>dropped duplicate Q63 ('V1 (L/m2)', value '2.05') — already have one for this compound</li><li>unit_dimension_unknown: 'L/m2' (V2)</li><li>dropped duplicate Q64 ('V2 (L/m2)', value '5.65') — already have one for this compound</li><li>unit_dimension_unknown: 'L/m2' (Vss)</li><li>dropped duplicate Q65 ('V ss (L/m2)', value '7.70') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dinutuximab</li><li>population split: 'ch14.18-nci(n = 25)' subgroup of Marachelian_2016 (paper reports 3 populations: ch14.18-nci(n = 25), ch14.18-utc and ch14.18-nci combined(n = 27), ch14.18-utc(n = 26))</li><li>molar mass: none found for 'dinutuximab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Dinutuximab_Marachelian2016_ch14_18_nci;
