function p = Dinutuximab_Marachelian2016_ch14_18_nci_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dinutuximab   source: Marachelian_2016 / ch14_18_nci   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Dinutuximab_Marachelian2016_ch14_18_nci_params';
  p.drug  = 'dinutuximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.36;                % central volume [L]
  p.CL = 0.03125;                % clearance [L/h]
  p.Vp = [3.76];             % peripheral volumes [L]
  p.Q  = [0.039833];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
