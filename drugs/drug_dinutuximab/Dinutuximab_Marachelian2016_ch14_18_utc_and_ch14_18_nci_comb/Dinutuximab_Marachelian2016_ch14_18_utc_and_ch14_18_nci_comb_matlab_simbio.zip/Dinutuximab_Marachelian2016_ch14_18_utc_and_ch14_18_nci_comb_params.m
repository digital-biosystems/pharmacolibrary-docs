function p = Dinutuximab_Marachelian2016_ch14_18_utc_and_ch14_18_nci_comb_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dinutuximab   source: Marachelian_2016 / ch14_18_utc_and_ch14_18_nci_combined   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Dinutuximab_Marachelian2016_ch14_18_utc_and_ch14_18_nci_comb_params';
  p.drug  = 'dinutuximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.4;                % central volume [L]
  p.CL = 0.029542;                % clearance [L/h]
  p.Vp = [3.85];             % peripheral volumes [L]
  p.Q  = [0.035708];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
