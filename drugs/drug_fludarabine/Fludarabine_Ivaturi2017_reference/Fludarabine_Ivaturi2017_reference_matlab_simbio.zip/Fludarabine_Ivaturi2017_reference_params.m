function p = Fludarabine_Ivaturi2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fludarabine   source: Ivaturi_2017 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Fludarabine_Ivaturi2017_reference_params';
  p.drug  = 'fludarabine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 938.0;                % central volume [L]
  p.CL = 3.1;                % clearance [L/h]
  p.Vp = [13.4];             % peripheral volumes [L]
  p.Q  = [154.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
