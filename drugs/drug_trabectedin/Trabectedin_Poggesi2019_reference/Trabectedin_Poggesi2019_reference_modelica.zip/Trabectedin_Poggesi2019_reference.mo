model Trabectedin_Poggesi2019_reference
  parameter Real Cl_ref = 1.0111111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0132 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.761837,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trabectedin</h4><p>Trabectedin is an alkylating antineoplastic agent used to treat advanced soft-tissue sarcoma and ovarian cancer. It is given by intravenous injection.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q2637746\">Wikidata Q2637746</a>, <a href=\"https://en.wikipedia.org/wiki/Trabectedin?oldid=1373361314\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trabectedin</td></tr><tr><td>population:</td><td>children and adolescent patients with cancer</td></tr><tr><td>source_paper:</td><td>Poggesi_2019</td></tr><tr><td>measured_compound:</td><td>trabectedin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>trabectedin 761.837 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q88 ('median AUC in the adult population', value 61.3) — already have one for this compound</li><li>dropped unlinked row (NIL): 'mean (range) BSA for adults' — extend the ontology if this is a real PK parameter (source ['Poggesi_2019:abstract'])</li><li>dropped unlinked row (NIL): 'mean (range) BSA for children/adolescent patients' — extend the ontology if this is a real PK parameter (source ['Poggesi_2019:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trabectedin</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'mean ± standard deviation (SD) of the individual estimated central volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Trabectedin_Poggesi2019_reference;
