model Ozanimod_Briggs2021_PD_qtcp
  "emax exposure-response sweep — Briggs_2021 :: QTcP (QTcP)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.394,      // [s; msec × 0.001]
    Emax = 0.000972,  // [s; msec × 0.001]
    EC50 = 1.95e-07,  // [mol/m3; pmol/L × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pmol/L per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2000, Interval = 4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ozanimod</h4><p>Ozanimod is an immunosuppressant used to treat relapsing-remitting multiple sclerosis and ulcerative colitis. It is an approved medicine authorised in the European Union, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21098986\">Wikidata Q21098986</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ozanimod_Briggs2021_PD_qtcp</h4><p>The steady-state exposure-response curve of Briggs E et al., <i>CPT: pharmacometrics &amp; systems pharmacology 10(2):119–126</i> 2021 (<a href=\"https://doi.org/10.1002/psp4.12580\">doi:10.1002/psp4.12580</a>) — QTcP [msec] against Ozanimod pmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        394 msec     drug-free response (baseline) (Baseline, Q324)
  Emax  =      0.972 msec     maximal effect term (E max, Q320)
  EC50  =        195 pmol/L   exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pmol/L of Ozanimod per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.394   (drug-free)
  exposure = EC50 (195 pmol/L)  response 0.3945
  exposure -> infinity  response 0.395</pre></body></html>"));
end Ozanimod_Briggs2021_PD_qtcp;
