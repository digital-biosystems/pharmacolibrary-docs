function p = Ozanimod_Briggs2021_PD_qtcp_params()
% Ozanimod_Briggs2021_PD_qtcp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ozanimod Briggs_2021::QTcP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pmol/L per second, in SI inside (kg/m3, s). Response QTcP in msec. Driver: Ozanimod (conc_no_pk).
p.E0 = 0.394;
p.Emax = 0.000972;
p.EC50 = 1.9499999999999996e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 2000.0;
p.form = 'E0 + Emax*frac';
end
