function p = Ertapenem_Chauzy2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ertapenem   source: Chauzy_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ertapenem_Chauzy2022_reference_params';
  p.drug  = 'ertapenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 51.8;                % central volume [L]
  p.CL = 30.59;                % clearance [L/h]
  p.Vp = [52.01];             % peripheral volumes [L]
  p.Q  = [22.05];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
