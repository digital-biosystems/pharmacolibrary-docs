function p = Etoposide_Toffoli2001_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: etoposide   source: Toffoli_2001 / mean   route: iv_bolus
  p.name  = 'Etoposide_Toffoli2001_mean_params';
  p.drug  = 'etoposide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.0;                % central volume [L]
  p.CL = 1.14;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.44;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
