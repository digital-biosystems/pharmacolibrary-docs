model Etoposide_Toffoli2001_mean
  parameter Real Cl_ref = 3.1666666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5885566,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etoposide</h4><p>Etoposide is a chemotherapy drug used to treat many cancers, including testicular cancer, lung small cell carcinoma, lymphomas, leukemias, and several other tumors. It is an approved medicine and appears on the WHO essential medicines list, so it is widely used in cancer care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418817\">Wikidata Q418817</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etoposide</td></tr><tr><td>population:</td><td>adult patients with solid tumours</td></tr><tr><td>source_paper:</td><td>Toffoli_2001</td></tr><tr><td>measured_compound:</td><td>etoposide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>etoposide 588.557 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l h x1' (CL)</li><li>unit_dimension_unknown: 'h x1' (k12)</li><li>unit_dimension_unknown: 'h x1' (k21)</li><li>implicit units: 'CL (l h x1 )' → L/h (from the paper text: &quot;Abstract states: 'Mean clearance was 1.14 l h x1' and section 'In¯uence of renal function and ageing on clearance' prese&quot;)</li><li>implicit units: 'k 12 (h x1 )' → 1/h (from the popPK convention: 'k12 is a first-order rate constant; by PK convention these are expressed in reciprocal time (1/h). The value 0.14 is con')</li><li>implicit units: 'k 21 (h x1 )' → 1/h (from the popPK convention: 'k21 is a first-order rate constant; by PK convention these are expressed in reciprocal time (1/h). The value 0.06 is con')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=etoposide</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'mean' subgroup of Toffoli_2001 (paper reports 2 populations: mean, mean with covariables)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Etoposide_Toffoli2001_mean;
