function [model, dose, variant, obs] = build_sb_pk(p)
% Build a SimBiology PK model from a parameter struct p (see *_params.m).
% Requires the SimBiology toolbox. Uses PKModelDesign for a 1..N-compartment,
% linear-clearance model with IV-bolus or first-order-oral dosing.
  isOral = strcmp(p.route, 'oral');
  pkm = PKModelDesign;
  addCompartment(pkm, 'Central', ...
      'DosingType',          ternary(isOral, 'FirstOrder', 'Bolus'), ...
      'EliminationType',     'linear-clearance', ...
      'HasResponseVariable', true, ...
      'HasLag',              p.Tlag > 0);
  for j = 1:(p.ncmt - 1)
      addCompartment(pkm, sprintf('Peripheral%d', j), ...
          'DosingType', '', 'EliminationType', '', 'HasResponseVariable', false);
  end
  [model, pkmap] = construct(pkm);

  % Names come from the PKModelMap construct() returns, not from guesses: its properties
  % are Dosed (dose targets), Observed (response species), Estimated (parameter names)
  % and LagParameter. PKModelDesign names the clearance Cl_Central, the absorption rate
  % ka_Central and the inter-compartmental clearances Q12, Q13, ... (one per peripheral,
  % in order) — read from Estimated so a renaming SimBiology release cannot break it.
  est = pkmap.Estimated;
  qnames = est(strncmp(est, 'Q', 1));

  % Parameter values via a Variant.
  variant = addvariant(model, [p.name '_params']);
  addcontent(variant, {'compartment', 'Central', 'Capacity', p.Vc});
  addcontent(variant, {'parameter',   'Cl_Central', 'Value', p.CL});
  if isOral
      addcontent(variant, {'parameter', 'ka_Central', 'Value', p.ka});
  end
  for j = 1:(p.ncmt - 1)
      addcontent(variant, {'compartment', sprintf('Peripheral%d', j), 'Capacity', p.Vp(j)});
      addcontent(variant, {'parameter',   qnames{j},                  'Value',    p.Q(j)});
  end

  % Dose (IV bolus or first-order oral; bioavailability folded into the amount).
  dose = sbiodose('dose');
  dose.TargetName = firstname(pkmap.Dosed);
  if isOral
      dose.Amount = p.F * p.dose;
  else
      dose.Amount = p.dose;
  end
  dose.StartTime = 0;
  if p.Tlag > 0
      % the lag parameter exists (HasLag above); give it its value and attach it to the dose
      lag = firstname(pkmap.LagParameter);
      addcontent(variant, {'parameter', lag, 'Value', p.Tlag});
      dose.LagParameterName = lag;
  end
  % Repeated dosing: set dose.Interval = tau; dose.RepeatCount = n-1;

  obs = firstname(pkmap.Observed);
end

function n = firstname(x)
  % a PKModelMap name property is a cell array of names (or one char name)
  if iscell(x), n = x{1}; else, n = x; end
end

function y = ternary(c, a, b)
  if c, y = a; else, y = b; end
end
