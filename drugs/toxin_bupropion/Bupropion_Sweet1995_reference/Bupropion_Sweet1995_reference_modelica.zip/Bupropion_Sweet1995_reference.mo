model Bupropion_Sweet1995_reference
  parameter Real Cl_ref = 3.1251299539378296e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 5.550999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23974299999999998,
    adminMass = 0.0003,
    ka = 0.0007833333333333333,
    Tlag = 864.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bupropion</td></tr><tr><td>population:</td><td>elderly patients with depression</td></tr><tr><td>source_paper:</td><td>Sweet_1995</td></tr><tr><td>measured_compound:</td><td>bupropion</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bupropion 239.743 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('t1/2 app hydroxybupropion', value 34.2) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 app erythrobupropion', value 61.4) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 app threohydrobupropion', value 38.8) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bupropion</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/5 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'hydroxybupropion' — its concentrations stay mass-only</li><li>molar mass: none found for 'erythrobupropion' — its concentrations stay mass-only</li><li>molar mass: none found for 'threohydrobupropion' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ichida_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Ichida_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Bupropion_Sweet1995_reference;
