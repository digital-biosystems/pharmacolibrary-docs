model Bupropion_Xue2017_hydroxybupropion_value
  parameter Real Cl_ref = 1.6e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23974299999999998,
    adminMass = 0.0003,
    ka = 0.0007833333333333333,
    Tlag = 864.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bupropion</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Xue_2017</td></tr><tr><td>measured_compound:</td><td>bupropion</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-10-00001-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bupropion 239.743 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Log Po:w' — extend the ontology if this is a real PK parameter (source ['Xue_2017_table_2:row2:col1'])</li><li>dropped unlinked row (NIL): 'pKa' — extend the ontology if this is a real PK parameter (source ['Xue_2017_table_2:row3:col1'])</li><li>dropped value-less row: 'Table 4. In vitro P450 inhibition parameters for bupropion and its metabolism. All data from [28]. Ki here are apparent values, and are corrected for free fraction in microsome (fu,mic = 0.01) estimated in the Simcyp model.'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bupropion</li><li>toxin: 4 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>population split: 'hydroxybupropion / value' subgroup of Xue_2017 (paper reports 6 populations: bupropion / value, erythrohydrobupropion / value, hydroxybupropion / value, threohydrobupropion / value, value, venlafaxine / value)</li><li>row roles (LLM): model_class=pbpk; 0/23 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'hydroxybupropion' — its concentrations stay mass-only</li><li>molar mass: none found for 'threohydrobupropion' — its concentrations stay mass-only</li><li>molar mass: none found for 'erythrohydrobupropion' — its concentrations stay mass-only</li><li>molar mass: none found for &quot;4'-hydroxybupropion&quot; — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ichida_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bupropion_Xue2017_hydroxybupropion_value;
