function p = Bupropion_Xue2017_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bupropion   source: Xue_2017 / value   route: oral
  p.name  = 'Bupropion_Xue2017_value_params';
  p.drug  = 'bupropion';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2738.0;                % central volume [L]
  p.CL = 52.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.82;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.24;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
