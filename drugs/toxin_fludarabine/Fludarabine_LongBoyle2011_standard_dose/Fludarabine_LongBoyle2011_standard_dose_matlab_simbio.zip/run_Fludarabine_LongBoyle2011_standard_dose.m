% Run (SimBiology): build model + dose, simulate 0..43.0 h, plot.
p = Fludarabine_LongBoyle2011_standard_dose_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 43.0);
