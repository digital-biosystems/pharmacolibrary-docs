function p = Atomoxetine_Li2012_PD_da_params()
% Atomoxetine_Li2012_PD_da_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atomoxetine Li_2012::DA: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response DA in nM. Driver: Atomoxetine (pk_record).
p.E0 = 0.303;
p.Emax = 0.552;
p.EC50 = 4.669999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 110.0;
p.form = 'E0/(1 - Emax*frac)';
end
