model Atomoxetine_Li2012_PD_da
  "indirect_response_ii exposure-response sweep — Li_2012 :: DA (dopamine)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.303,      // [nM]
    Emax = 0.552,  // type II effect term
    EC50 = 4.67e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a selective norepinephrine reuptake inhibitor indicated for attention deficit hyperactivity disorder and anxiety. The medication is taken orally in capsule, tablet, or liquid forms. It is an approved medication used in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a>, <a href=\"https://en.wikipedia.org/wiki/Atomoxetine?oldid=1384125679\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atomoxetine_Li2012_PD_da</h4><p>The steady-state exposure-response curve of Li CS et al., <i>The AAPS journal 14(2):365–376</i> 2012 (<a href=\"https://doi.org/10.1208/s12248-012-9343-8\">doi:10.1208/s12248-012-9343-8</a>) — dopamine [nM] against Atomoxetine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.303 nM       drug-free response (baseline) (E 0, Q324)
  Emax  =      0.552          maximal effect term (I max, Q323)
  EC50  =       4.67 ng/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma =          1          Hill coefficient (g2, Q325)</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of Atomoxetine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.303   (drug-free)
  exposure = EC50 (4.67 ng/mL)  response 0.4185
  exposure -> infinity  response 0.6763</pre></body></html>"));
end Atomoxetine_Li2012_PD_da;
