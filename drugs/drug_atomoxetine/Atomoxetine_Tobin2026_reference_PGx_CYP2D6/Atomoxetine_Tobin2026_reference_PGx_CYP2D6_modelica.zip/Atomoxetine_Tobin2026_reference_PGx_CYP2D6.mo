model Atomoxetine_Tobin2026_reference_PGx_CYP2D6
  "Atomoxetine_Tobin2026_reference with the CYP2D6 phenotype as a parameter (Tobin_2026)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2D6 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {1.08416666667e-05, 4.82300286797e-06, 1.08416666667e-05, 1.08416666667e-05, 1.08416666667e-05, 1.08416666667e-05};
  extends Atomoxetine_Tobin2026_reference(Cl = Cl_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a selective norepinephrine reuptake inhibitor indicated for attention deficit hyperactivity disorder and anxiety. The medication is taken orally in capsule, tablet, or liquid forms. It is an approved medication used in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a>, <a href=\"https://en.wikipedia.org/wiki/Atomoxetine?oldid=1384125679\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Atomoxetine_Tobin2026_reference_PGx_CYP2D6;
