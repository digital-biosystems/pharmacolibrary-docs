% Run: build params, simulate 0..24.0 h, plot + save Atomoxetine_Tobin2026_reference_PGx_CYP2D6.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Atomoxetine_Tobin2026_reference_PGx_CYP2D6.m
% metabolizer: the CYP2D6 phenotype (1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra).
% Set it before running, e.g.  metabolizer = 2; run_Atomoxetine_Tobin2026_reference_PGx_CYP2D6  (default 4, the reference).
if ~exist('metabolizer', 'var'), metabolizer = 4; end
phenotypes = {'Unknown', 'Poor', 'Intermediate', 'Normal', 'Rapid', 'Ultra'};
here = fileparts(mfilename('fullpath'));
p = Atomoxetine_Tobin2026_reference_PGx_CYP2D6_params(metabolizer);
out = simulate_pk(p, 0:0.05:24.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('atomoxetine — Tobin_2026 (oral)');
print(fig, fullfile(here, ['Atomoxetine_Tobin2026_reference_PGx_CYP2D6_' phenotypes{metabolizer} '.png']), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, ['Atomoxetine_Tobin2026_reference_PGx_CYP2D6_' phenotypes{metabolizer} '.csv']), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, ['Atomoxetine_Tobin2026_reference_PGx_CYP2D6_' phenotypes{metabolizer} '.json']), 'w');
try
  s.model = 'Atomoxetine_Tobin2026_reference_PGx_CYP2D6'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Atomoxetine_Tobin2026_reference_PGx_CYP2D6","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Atomoxetine_Tobin2026_reference_PGx_CYP2D6.png, Atomoxetine_Tobin2026_reference_PGx_CYP2D6.csv, Atomoxetine_Tobin2026_reference_PGx_CYP2D6.json\n');
