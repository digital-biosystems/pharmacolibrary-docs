% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
% metabolizer: the CYP2D6 phenotype (1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra).
% Set it before running, e.g.  metabolizer = 2; run_Atomoxetine_Tobin2026_reference_PGx_CYP2D6  (default 4, the reference).
if ~exist('metabolizer', 'var'), metabolizer = 4; end
phenotypes = {'Unknown', 'Poor', 'Intermediate', 'Normal', 'Rapid', 'Ultra'};
p = Atomoxetine_Tobin2026_reference_PGx_CYP2D6_params(metabolizer);
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
