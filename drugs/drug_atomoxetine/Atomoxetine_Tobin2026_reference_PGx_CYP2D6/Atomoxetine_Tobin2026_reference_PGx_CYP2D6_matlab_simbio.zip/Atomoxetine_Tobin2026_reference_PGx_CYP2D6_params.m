function p = Atomoxetine_Tobin2026_reference_PGx_CYP2D6_params(metabolizer)
% Auto-generated population-PK parameters (clinical units).
%   drug: atomoxetine   source: Tobin_2026 / reference   route: oral
%   PGx: metabolizer is the CYP2D6 phenotype (1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra);
%   it selects CL. A phenotype the paper gives no effect for
%   runs the reference values.
  if nargin < 1, metabolizer = 4; end
  p.name  = 'Atomoxetine_Tobin2026_reference_PGx_CYP2D6_params';
  p.drug  = 'atomoxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 175.94;                % central volume [L]
  p.CL = 39.03;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 27.35;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 35.0;             % dose [mg]
  switch metabolizer
    case 2   % Poor metabolizer
      p.CL = 17.36281;                % clearance [L/h]
  end
  p.metabolizer = metabolizer;
end
