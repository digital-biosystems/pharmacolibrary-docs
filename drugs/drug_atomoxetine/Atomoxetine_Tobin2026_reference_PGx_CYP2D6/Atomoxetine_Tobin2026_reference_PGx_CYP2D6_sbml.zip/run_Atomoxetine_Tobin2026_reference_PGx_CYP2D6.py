#!/usr/bin/env python3
"""Simulate Atomoxetine_Tobin2026_reference_PGx_CYP2D6.sbml (0..24.0 h) with Tellurium/libRoadRunner and write results.

Headless-friendly: writes Atomoxetine_Tobin2026_reference_PGx_CYP2D6.csv, Atomoxetine_Tobin2026_reference_PGx_CYP2D6.json and Atomoxetine_Tobin2026_reference_PGx_CYP2D6.png next to this script
(no interactive window). Requires `tellurium` (bundles libRoadRunner + matplotlib).
"""
import re
import sys

# The CYP2D6 phenotype (Pharmacolibrary.Pharmacogenomics.PGx.MetabolizerStatus order):
# 1 Unknown, 2 Poor, 3 Intermediate, 4 Normal (reference), 5 Rapid, 6 Ultra.
# python run_Atomoxetine_Tobin2026_reference_PGx_CYP2D6.py 2   -> poor metaboliser; outputs Atomoxetine_Tobin2026_reference_PGx_CYP2D6_Poor.csv/.json/.png
PHENOTYPES = ['Unknown', 'Poor', 'Intermediate', 'Normal', 'Rapid', 'Ultra']
METABOLIZER = int(sys.argv[1]) if len(sys.argv) > 1 else 4
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Atomoxetine_Tobin2026_reference_PGx_CYP2D6")

xml = re.sub(r'(<parameter\b[^>]*\bid="metabolizer"[^>]*\bvalue=")[^"]*',
             r"\g<1>%d" % METABOLIZER, open(BASE + ".sbml").read())
r = te.loadSBMLModel(xml)
BASE += "_" + PHENOTYPES[METABOLIZER - 1]
res = r.simulate(0, 24.0, 500, ["time", "Cc"])   # Cc = central concentration [mg/L]
t = [float(x) for x in res[:, 0]]
Cc = [float(x) for x in res[:, 1]]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Atomoxetine_Tobin2026_reference_PGx_CYP2D6", "stop_time_h": 24.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Atomoxetine_Tobin2026_reference_PGx_CYP2D6"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
