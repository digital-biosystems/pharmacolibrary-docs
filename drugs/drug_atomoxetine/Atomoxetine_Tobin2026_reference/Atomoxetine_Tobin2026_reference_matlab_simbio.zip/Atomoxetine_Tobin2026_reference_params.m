function p = Atomoxetine_Tobin2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atomoxetine   source: Tobin_2026 / reference   route: oral
  p.name  = 'Atomoxetine_Tobin2026_reference_params';
  p.drug  = 'atomoxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 175.94;                % central volume [L]
  p.CL = 39.03;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 27.35;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 35.0;             % dose [mg]
end
