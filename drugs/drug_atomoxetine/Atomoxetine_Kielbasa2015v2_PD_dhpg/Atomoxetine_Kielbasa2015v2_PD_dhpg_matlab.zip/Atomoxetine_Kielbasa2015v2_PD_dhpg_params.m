function p = Atomoxetine_Kielbasa2015v2_PD_dhpg_params()
% Atomoxetine_Kielbasa2015v2_PD_dhpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atomoxetine Kielbasa_2015_2::DHPG: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response DHPG in pg/mL. Driver: Atomoxetine (cited_pk).
p.E0 = 1.24e-06;
p.Emax = 0.367;
p.EC50 = 2.67e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 27.0;
p.form = 'E0*(1 - Emax*frac)';
end
