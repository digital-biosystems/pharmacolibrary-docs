model Atomoxetine_Kielbasa2015v2_PD_dhpg
  "indirect_response_i exposure-response sweep — Kielbasa_2015_2 :: DHPG (3,4-Dihydroxyphenylglycol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.24e-06,      // [kg/m3; pg/mL × 1e-09]
    Emax = 0.367,  // type I effect term
    EC50 = 2.67e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 27, Interval = 0.054),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a selective norepinephrine reuptake inhibitor indicated for attention deficit hyperactivity disorder and anxiety. The medication is taken orally in capsule, tablet, or liquid forms. It is an approved medication used in the United States.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a>, <a href=\"https://en.wikipedia.org/wiki/Atomoxetine?oldid=1384125679\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atomoxetine_Kielbasa2015v2_PD_dhpg</h4><p>The steady-state exposure-response curve of Kielbasa W et al., <i>Journal of clinical pharmacology 55(12):1422–1431</i> 2015 (<a href=\"https://doi.org/10.1002/jcph.551\">doi:10.1002/jcph.551</a>) — 3,4-Dihydroxyphenylglycol [pg/mL] against Atomoxetine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1240 pg/mL    drug-free response (baseline) (Baseline, Q324)
  Emax  =      0.367          maximal effect term (I max, Q323)
  EC50  =       2.67 ng/mL    exposure at half of the maximal effect term (Plasma IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of Atomoxetine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.24e-06   (drug-free)
  exposure = EC50 (2.67 ng/mL)  response 1.012e-06
  exposure -> infinity  response 7.849e-07</pre></body></html>"));
end Atomoxetine_Kielbasa2015v2_PD_dhpg;
