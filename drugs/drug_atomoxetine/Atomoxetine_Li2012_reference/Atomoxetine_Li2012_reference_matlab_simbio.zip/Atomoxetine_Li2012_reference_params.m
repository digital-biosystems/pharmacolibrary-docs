function p = Atomoxetine_Li2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atomoxetine   source: Li_2012 / reference   route: oral
  p.name  = 'Atomoxetine_Li2012_reference_params';
  p.drug  = 'atomoxetine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 903.0;                % central volume [L]
  p.CL = 454.3;                % clearance [L/h]
  p.Vp = [401.8];             % peripheral volumes [L]
  p.Q  = [557.2];             % inter-compartmental clearances [L/h]
  p.ka = 24.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
