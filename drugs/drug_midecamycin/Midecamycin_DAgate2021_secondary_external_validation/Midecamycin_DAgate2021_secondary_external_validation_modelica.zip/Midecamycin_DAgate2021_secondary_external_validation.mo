model Midecamycin_DAgate2021_secondary_external_validation
  parameter Real Cl_ref = 2.472222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0009080000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About midecamycin</h4><p>Midecamycin is a macrolide antibiotic used against bacterial infections. It is considered investigational and does not appear to have an authorised marketing status in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2636110\">Wikidata Q2636110</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>midecamycin</td></tr><tr><td>population:</td><td>secondary external validation</td></tr><tr><td>source_paper:</td><td>DAgate_2021</td></tr><tr><td>measured_compound:</td><td>unknown</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>midecamycin 813.979 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Number of patients' — extend the ontology if this is a real PK parameter (source ['DAgate_2021_table_2:row0:col2'])</li><li>dropped unlinked row (NIL): 'Male, %' — extend the ontology if this is a real PK parameter (source ['DAgate_2021_table_2:row5:col2'])</li><li>salvaged Q22 ('clearance (CL)'=0.089) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central volume of distribution (Vc)'=0.908) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=unknown</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution (Vc)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>population split: 'secondary external validation' subgroup of DAgate_2021 (paper reports 2 populations: model building *, secondary external validation)</li><li>molar mass: no plausible PubChem entry for 'unknown' ('unknown') — left in mass units</li><li>molar mass: none found for 'unknown' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Midecamycin_DAgate2021_secondary_external_validation;
