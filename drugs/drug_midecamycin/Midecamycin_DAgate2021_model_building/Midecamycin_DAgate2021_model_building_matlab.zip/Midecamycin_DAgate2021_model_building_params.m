function p = Midecamycin_DAgate2021_model_building_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midecamycin   source: DAgate_2021 / model_building   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Midecamycin_DAgate2021_model_building_params';
  p.drug  = 'midecamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.908;                % central volume [L]
  p.CL = 0.089;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
