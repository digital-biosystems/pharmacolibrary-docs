model CoagulationFactorX_Zou2025_PD_aptt
  "linear exposure-response sweep — Zou_2025 :: aPTT (activated partial thromboplastin time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 35.5,      // [s; s × 1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0467   "[s mL/ng]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About coagulation_factor_x</h4><p>Coagulation factor X is a human blood-clotting protein used to treat bleeding caused by a lack of factor X. It is an approved medicine, classified among blood coagulation factors, though it appears to be used only in limited settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423701\">Wikidata Q423701</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>CoagulationFactorX_Zou2025_PD_aptt</h4><p>The steady-state exposure-response curve of Zou P et al., <i>CPT: pharmacometrics &amp; systems pharmacology</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.13248\">doi:10.1002/psp4.13248</a>) — activated partial thromboplastin time [s] against edoxaban ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       35.5 s        drug-free response (baseline) (Baseline-activated partial thromboplastin time, Q324)
  slope =     0.0467 s mL/ng  change in response per unit of exposure (The slope of the effect of edoxaban, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of edoxaban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 35.5   (drug-free)</pre></body></html>"));
end CoagulationFactorX_Zou2025_PD_aptt;
