model CoagulationFactorX_Zou2025_PD_anti_fxa
  "emax exposure-response sweep — Zou_2025 :: anti-FXa (anti-Factor Xa activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.1,      // [IU/mL]
    Emax = 8.65,  // [IU/mL]
    EC50 = 0.000631,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 6400, Interval = 12.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About coagulation_factor_x</h4><p>Coagulation factor X is a human blood-clotting protein used to treat bleeding caused by a lack of factor X. It is an approved medicine, classified among blood coagulation factors, though it appears to be used only in limited settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423701\">Wikidata Q423701</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>CoagulationFactorX_Zou2025_PD_anti_fxa</h4><p>The steady-state exposure-response curve of Zou P et al., <i>CPT: pharmacometrics &amp; systems pharmacology</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.13248\">doi:10.1002/psp4.13248</a>) — anti-Factor Xa activity [IU/mL] against edoxaban ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        0.1 IU/mL    drug-free response (baseline) (Baseline anti-Factor Xa activity, Q324)
  Emax  =       8.65 IU/mL    maximal effect term (Maximum effect of edoxaban, Q320)
  EC50  =        631 ng/mL    exposure at half of the maximal effect term (Edoxaban concentration at half max, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of edoxaban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.1   (drug-free)
  exposure = EC50 (631 ng/mL)  response 4.425
  exposure -> infinity  response 8.75</pre></body></html>"));
end CoagulationFactorX_Zou2025_PD_anti_fxa;
