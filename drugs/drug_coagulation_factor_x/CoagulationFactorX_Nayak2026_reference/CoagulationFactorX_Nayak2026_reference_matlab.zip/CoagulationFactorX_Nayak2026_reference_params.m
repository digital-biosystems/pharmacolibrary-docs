function p = CoagulationFactorX_Nayak2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: coagulation_factor_x   source: Nayak_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'CoagulationFactorX_Nayak2026_reference_params';
  p.drug  = 'coagulation_factor_x';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.61;                % central volume [L]
  p.CL = 0.0188;                % clearance [L/h]
  p.Vp = [4.99];             % peripheral volumes [L]
  p.Q  = [0.00489];             % inter-compartmental clearances [L/h]
  p.ka = 0.00742;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
