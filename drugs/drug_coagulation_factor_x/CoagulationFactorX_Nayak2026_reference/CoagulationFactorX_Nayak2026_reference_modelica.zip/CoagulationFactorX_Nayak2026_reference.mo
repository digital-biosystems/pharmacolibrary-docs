model CoagulationFactorX_Nayak2026_reference
  parameter Real Cl_ref = 5.222222222222222e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00361 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 2.061111111111111e-06,
    Tlag = 7200.0,
    k12 = 3.7626962142197606e-07,
    k21 = 2.7221108884435537e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About coagulation_factor_x</h4><p>Coagulation factor X is a human blood-clotting protein used to treat bleeding caused by a lack of factor X. It is an approved medicine, classified among blood coagulation factors, though it appears to be used only in limited settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423701\">Wikidata Q423701</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>coagulation_factor_x</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Nayak_2026</td></tr><tr><td>measured_compound:</td><td>coagulation_factor_x</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Nayak_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end CoagulationFactorX_Nayak2026_reference;
