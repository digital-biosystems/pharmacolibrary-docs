model CoagulationFactorX_Zou2025_reference
  parameter Real Cl_ref = 1.1908333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.261 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.548059,
    adminMass = 3e-05,
    ka = 0.0010305555555555556,
    Tlag = 0.0,
    k12 = 9.142188165176672e-06,
    k21 = 6.946466116771793e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About coagulation_factor_x</h4><p>Coagulation factor X is a human blood-clotting protein used to treat bleeding caused by a lack of factor X. It is an approved medicine, classified among blood coagulation factors, though it appears to be used only in limited settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423701\">Wikidata Q423701</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>coagulation_factor_x</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Zou_2025</td></tr><tr><td>measured_compound:</td><td>edoxaban</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413248-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>edoxaban 548.059 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Hill coefficient of maturation function, HILL' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413248-tbl-0001:row8:col1'])</li><li>dropped unlinked row (NIL): 'Post‐menstrual age (PMA) at half max of the maturation function, TM50' — extend the ontology if this is a real PK parameter (source ['psp413248-tbl-0001:row9:col1'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q22 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=edoxaban</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>molar mass: none found for 'coagulation_factor_x' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'edoxaban', not coagulation_factor_x — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CoagulationFactorX_Zou2025_reference;
