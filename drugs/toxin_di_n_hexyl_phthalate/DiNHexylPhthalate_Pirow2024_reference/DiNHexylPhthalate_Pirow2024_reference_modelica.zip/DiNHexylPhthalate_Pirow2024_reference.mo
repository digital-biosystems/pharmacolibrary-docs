// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model DiNHexylPhthalate_Pirow2024_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {19800.0},
    MM = 0.250294,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>di_n_hexyl_phthalate</td></tr><tr><td>population:</td><td>humans (adults and children)</td></tr><tr><td>source_paper:</td><td>Pirow_2024</td></tr><tr><td>measured_compound:</td><td>Mono-n-hexyl phthalate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Di-n-hexyl phthalate 334.456 g/mol (pubchem); Mono-n-hexyl phthalate 250.294 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Sunscreen'; source reconciliation required</li><li>table representations disagree for 'Sunscreen'; source reconciliation required</li><li>table representations disagree for 'Lip balm'; source reconciliation required</li><li>table representations disagree for 'Lip balm'; source reconciliation required</li><li>table representations disagree for 'Pump spray for face'; source reconciliation required</li><li>table representations disagree for 'Pump spray for face'; source reconciliation required</li><li>table representations disagree for 'Sunscreen'; source reconciliation required</li><li>table representations disagree for 'Sunscreen'; source reconciliation required</li><li>table representations disagree for 'Lip balm'; source reconciliation required</li><li>table representations disagree for 'Lip balm'; source reconciliation required</li><li>table representations disagree for 'Pump spray for face'; source reconciliation required</li><li>table representations disagree for 'Pump spray for face'; source reconciliation required</li><li>table representations disagree for 'Plastic sandals'; source reconciliation required</li><li>table representations disagree for 'Plastic sandals'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Sunscreen' — extend the ontology if this is a real PK parameter (source ['Tab4:row2:col2', 'Tab4:row2:col3', 'Tab4:row6:col2', 'Tab4:row6:col3'])</li><li>dropped unlinked row (NIL): 'Lip balm' — extend the ontology if this is a real PK parameter (source ['Tab4:row3:col2', 'Tab4:row3:col3', 'Tab4:row7:col2', 'Tab4:row7:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 201.6));
end DiNHexylPhthalate_Pirow2024_reference;
