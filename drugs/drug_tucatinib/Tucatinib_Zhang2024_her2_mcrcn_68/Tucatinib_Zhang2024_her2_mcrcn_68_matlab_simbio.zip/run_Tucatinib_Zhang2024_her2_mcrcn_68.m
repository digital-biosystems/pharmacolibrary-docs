% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Tucatinib_Zhang2024_her2_mcrcn_68_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
