function p = Tucatinib_Zhang2024_her2_mcrcn_68_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tucatinib   source: Zhang_2024 / her2_mcrcn_68   route: oral
  % estimated (absent from source): ka
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Tucatinib_Zhang2024_her2_mcrcn_68_params';
  p.drug  = 'tucatinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 829.0;                % central volume [L]
  p.CL = 89.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
