model Brexanolone_Wald2022_reference
  parameter Real Cl_ref = 2.4305555555555558e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.4312 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexanolone</td></tr><tr><td>population:</td><td>patients with postpartum depression and healthy lactating women</td></tr><tr><td>source_paper:</td><td>Wald_2022</td></tr><tr><td>measured_compound:</td><td>allopregnanolone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q19 ('AUC24–56, ng·h/mL', value '2257.9') — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0–t, ng·h/mL', value '3557.8') — already have one for this compound</li><li>dropped unlinked row (NIL): 'tlast, h' — extend the ontology if this is a real PK parameter (source ['Tab3:row9:col1', 'Tab3:row9:col2'])</li><li>dropped unlinked row (NIL): 'R2 adjusted' — extend the ontology if this is a real PK parameter (source ['Tab3:row10:col1', 'Tab3:row10:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=allopregnanolone</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Brexanolone_Wald2022_reference;
