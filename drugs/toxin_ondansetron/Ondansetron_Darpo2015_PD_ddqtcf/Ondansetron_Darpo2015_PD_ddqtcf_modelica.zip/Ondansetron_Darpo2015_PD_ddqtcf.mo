model Ondansetron_Darpo2015_PD_ddqtcf
  "linear exposure-response sweep — Darpo_2015 :: DDQTcF (DDQTcF)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 33,  // [meter ** 3 * second / kilogram; ms per ng/ml × 1000]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Ondansetron_Darpo2015_PD_ddqtcf</h4><p>The steady-state exposure-response curve of Darpo B et al., <i>Drug safety 38(9):773–780</i> 2015 (<a href=\"https://doi.org/10.1007/s40264-015-0325-5\">doi:10.1007/s40264-015-0325-5</a>) — DDQTcF [ms] against ondansetron ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.033 ms per ng/ml change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of ondansetron per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ondansetron_Darpo2015_PD_ddqtcf;
