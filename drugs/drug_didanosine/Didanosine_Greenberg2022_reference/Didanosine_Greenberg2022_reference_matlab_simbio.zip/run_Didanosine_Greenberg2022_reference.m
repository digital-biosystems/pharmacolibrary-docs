% Run (SimBiology): build model + dose, simulate 0..46.0 h, plot.
p = Didanosine_Greenberg2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 46.0);
