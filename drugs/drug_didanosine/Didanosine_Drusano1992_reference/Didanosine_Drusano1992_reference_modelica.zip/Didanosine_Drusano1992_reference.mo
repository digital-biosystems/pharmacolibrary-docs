model Didanosine_Drusano1992_reference
  parameter Real Cl_ref = 1.3250000000000002e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 27.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2362273,
    adminMass = 0.0004,
    ka = 0.00037027092978629555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About didanosine</h4><p>Didanosine is a nucleoside reverse transcriptase inhibitor used to treat HIV infection as part of combination therapy. It is taken by mouth in various solid dosage forms and is well absorbed from the gut. The drug is used worldwide and is listed on the World Health Organization's Model List of Essential Medicines.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422606\">Wikidata Q422606</a>, <a href=\"https://en.wikipedia.org/wiki/Didanosine?oldid=1352071189\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>didanosine</td></tr><tr><td>population:</td><td>HIV-infected patients</td></tr><tr><td>source_paper:</td><td>Drusano_1992</td></tr><tr><td>measured_compound:</td><td>didanosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>didanosine 236.227 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'liters/h/70 kg of body weight' (CL)</li><li>implicit units: 'Clearance of the drug from plasma' → L/h (from the popPK convention: &quot;The parameter is identified as 'Clearance' (CL) with a value of 47.7. The provided text and table captions contain no ex&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=didanosine</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'The volume of distribution in the central compartment' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Didanosine_Drusano1992_reference;
