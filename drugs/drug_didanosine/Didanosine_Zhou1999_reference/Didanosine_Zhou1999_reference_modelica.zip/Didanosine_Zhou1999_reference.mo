model Didanosine_Zhou1999_reference
  parameter Real Cl_ref = 1.4805555555555555e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0819 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2362273,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About didanosine</h4><p>Didanosine is a nucleoside reverse transcriptase inhibitor used to treat HIV infection as part of combination therapy. It is taken by mouth in various solid dosage forms and is well absorbed from the gut. The drug is used worldwide and is listed on the World Health Organization's Model List of Essential Medicines.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422606\">Wikidata Q422606</a>, <a href=\"https://en.wikipedia.org/wiki/Didanosine?oldid=1352071189\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>didanosine</td></tr><tr><td>population:</td><td>adults with HIV</td></tr><tr><td>source_paper:</td><td>Zhou_1999</td></tr><tr><td>measured_compound:</td><td>didanosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>didanosine 236.227 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'liters/h/kg of body weight' (CL)</li><li>dropped duplicate Q22 ('Individual mean oral CL', value '1.84') — already have one for this compound</li><li>dropped duplicate Q61 ('V', value '2.67') — already have one for this compound</li><li>dropped duplicate Q65 ('VSS', value '3.56') — already have one for this compound</li><li>unit_dimension_unknown: 'relative bioavailability (F) of ddI' (Frel)</li><li>unit_dimension_unknown: 'relative bioavailability (F) of ddI' (Frel)</li><li>dropped duplicate Q87 ('FDOUBLE', value '1') — already have one for this compound</li><li>dropped value-less row: 'F of ZDV'</li><li>implicit units: 'Individual oral clearance (CL)' → L/h (from the popPK convention: 'No unit is provided in the text or table. Oral clearance (CL) is standardly reported in L/h in population PK. The value ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=didanosine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Didanosine_Zhou1999_reference;
