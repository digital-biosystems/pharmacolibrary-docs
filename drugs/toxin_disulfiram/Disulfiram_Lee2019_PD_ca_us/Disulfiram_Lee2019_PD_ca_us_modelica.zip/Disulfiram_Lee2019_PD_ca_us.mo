model Disulfiram_Lee2019_PD_ca_us
  "emax exposure-response sweep — Lee_2019 :: CA-US (cell-associated unspliced (CA-US))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.78,  // [1; % × 0.01]
    EC50 = 1600,  // [μg*hour/L]
    gamma = 1,
    exposure_per_s = 1);   // 1 μg*hour/L per second
  // exposure_unit_unresolved: 'μg*hour/L' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16000, Interval = 32),
    Documentation(info = "<html><body><h4>Disulfiram_Lee2019_PD_ca_us</h4><p>The steady-state exposure-response curve of Lee SA et al., <i>Clinical pharmacology and therapeutics 105(3):692-702</i> 2019 (<a href=\"https://doi.org/10.1002/cpt.1220\">doi:10.1002/cpt.1220</a>) — cell-associated unspliced (CA-US) against Disulfiram μg*hour/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         78 %        maximal effect term (Maximum effect (Emax), Q320)
  EC50  =       1600 μg*hour/L exposure at half of the maximal effect term (AUC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg*hour/L of Disulfiram per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1600 μg*hour/L)  response 0.39
  exposure -> infinity  response 0.78</pre></body></html>"));
end Disulfiram_Lee2019_PD_ca_us;
