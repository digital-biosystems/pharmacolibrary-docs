function p = Disulfiram_Lee2019_PD_ca_us_params()
% Disulfiram_Lee2019_PD_ca_us_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% disulfiram Lee_2019::CA_US: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg*hour/L per second, in SI inside (kg/m3, s). Response CA-US in its own unit. Driver: Disulfiram (pk_record).
p.E0 = 0.0;
p.Emax = 0.78;
p.EC50 = 1600.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 16000.0;
p.form = 'E0 + Emax*frac';
end
