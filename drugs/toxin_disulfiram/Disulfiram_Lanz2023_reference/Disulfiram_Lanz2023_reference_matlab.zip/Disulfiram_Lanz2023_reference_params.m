function p = Disulfiram_Lanz2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: disulfiram   source: Lanz_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Disulfiram_Lanz2023_reference_params';
  p.drug  = 'disulfiram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.3;                % central volume [L]
  p.CL = 0.53;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.08;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
