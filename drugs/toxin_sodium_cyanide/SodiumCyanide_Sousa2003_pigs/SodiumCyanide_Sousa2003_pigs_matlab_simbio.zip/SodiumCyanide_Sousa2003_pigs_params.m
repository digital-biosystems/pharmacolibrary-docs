function p = SodiumCyanide_Sousa2003_pigs_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_cyanide   source: Sousa_2003 / pigs   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'SodiumCyanide_Sousa2003_pigs_params';
  p.drug  = 'sodium_cyanide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 20.3;                % central volume [L]
  p.CL = 1.5414;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 210.0;             % dose [mg]
end
