model SodiumCyanide_Sousa2003_pigs
  parameter Real Cl_ref = 4.281666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0203 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.026,
    adminMass = 0.00021
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_cyanide</td></tr><tr><td>population:</td><td>rats, pigs and goats</td></tr><tr><td>source_paper:</td><td>Sousa_2003</td></tr><tr><td>measured_compound:</td><td>Cyanide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Cyanide 26 g/mol (paper); Thiocyanate 58 g/mol (paper)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'lmol/l' (Cmax)</li><li>unit_dimension_unknown: 'lmol.l/h' (AUC)</li><li>implicit units: 'K el' → 1/h (from the printed half-life: 'K el = 1.28 and t 1/2 b (h) = 0.54 h: λ·t½ = ln2 only in 1/h')</li><li>implicit units: 'C max (lmol/l)' — the LLM proposed 'umol/L', whose dimension does not fit Q32; left unset</li><li>implicit units: 'AUC (lmol.l/h)' — the LLM proposed 'umol·L/h', whose dimension does not fit Q88; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyanide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'pigs' subgroup of Sousa_2003 (paper reports 3 populations: goats, pigs, rats)</li><li>row roles (LLM): model_class=noncompartmental; 8/8 row label(s) assigned, 18 linked by role; re-tagged parent→Cyanide ×39, parent→Thiocyanate ×3</li><li>review gap-fill skipped: this record measures 'Cyanide', not sodium_cyanide — the review values are the parent's</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q32, Q88 — no SI value to build from)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SodiumCyanide_Sousa2003_pigs;
