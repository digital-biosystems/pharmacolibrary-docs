function p = Salbutamol_Venkatasubramanian2020_PD_hr_params()
% Salbutamol_Venkatasubramanian2020_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salbutamol Venkatasubramanian_2020::HR: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response HR in bpm. Driver: salbutamol (cited_pk).
p.E0 = 79.7;
p.Emax = 0.19;
p.EC50 = 21.3;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 220.0;
p.form = 'E0*(1 + Emax*frac)';
end
