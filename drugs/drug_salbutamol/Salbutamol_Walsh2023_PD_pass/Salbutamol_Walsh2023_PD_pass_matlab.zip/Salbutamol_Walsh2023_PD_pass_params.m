function p = Salbutamol_Walsh2023_PD_pass_params()
% Salbutamol_Walsh2023_PD_pass_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salbutamol Walsh_2023::PASS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response PASS in fraction of PASS-score [0-9]. Driver: salbutamol (pk_record).
p.E0 = 0.381;
p.Emax = -0.25;
p.EC50 = 1.1499999999999998e-06;
p.gamma = 3.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 12.0;
p.form = 'E0 + Emax*frac';
end
