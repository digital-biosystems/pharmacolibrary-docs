model Salbutamol_Walsh2023_PD_pass
  "sigmoid_emax exposure-response sweep — Walsh_2023 :: PASS (Paediatric Asthma Severity Score (PASS))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.381,      // [fraction of PASS-score [0-9]]
    Emax = -0.25,  // [fraction of PASS-score [0-9]]
    EC50 = 1.15e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 3.2,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salbutamol_Walsh2023_PD_pass</h4><p>The steady-state exposure-response curve of Walsh S et al., <i>Archives of disease in childhood 108(4):316–322</i> 2023 (<a href=\"https://doi.org/10.1136/archdischild-2022-324008\">doi:10.1136/archdischild-2022-324008</a>) — Paediatric Asthma Severity Score (PASS) [fraction of PASS-score [0-9]] against salbutamol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.381 fraction of PASS-score [0-9] drug-free response (baseline) (E0, Q324)
  Emax  =       0.25 fraction of PASS-score [0-9] maximal effect term (EMAX, Q323)
  EC50  =       1.15 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        3.2          Hill coefficient (HILL, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of salbutamol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.381   (drug-free)
  exposure = EC50 (1.15 ng/ml)  response 0.256
  exposure -> infinity  response 0.131</pre></body></html>"));
end Salbutamol_Walsh2023_PD_pass;
