function p = Salbutamol_Boger2019_PD_fev1_params()
% Salbutamol_Boger2019_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salbutamol Boger_2019::FEV1: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response FEV1 in its own unit. Driver: (R)-salbutamol (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0005000000000000001;
p.EC50 = 0.99;
p.gamma = 1.36;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 9.9;
p.form = 'E0 + Emax*frac';
end
