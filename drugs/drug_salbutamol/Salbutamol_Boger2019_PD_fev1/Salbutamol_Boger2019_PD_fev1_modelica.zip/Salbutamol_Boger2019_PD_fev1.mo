model Salbutamol_Boger2019_PD_fev1
  "sigmoid_emax exposure-response sweep — Boger_2019 :: FEV1 (forced expiratory volume in 1 second)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0005,  // [m3; mL × 1e-06]
    EC50 = 0.99,  // [nM]
    gamma = 1.36,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 9.9, Interval = 0.0198),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salbutamol_Boger2019_PD_fev1</h4><p>The steady-state exposure-response curve of Boger E et al., <i>Journal of aerosol medicine and pulmonary drug delivery 32(1):1–12</i> 2019 (<a href=\"https://doi.org/10.1089/jamp.2017.1436\">doi:10.1089/jamp.2017.1436</a>) — forced expiratory volume in 1 second against (R)-salbutamol nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        500 mL       maximal effect term (Emax, Q320)
  EC50  =       0.99 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.36          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of (R)-salbutamol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.99 nM)  response 0.00025
  exposure -> infinity  response 0.0005</pre></body></html>"));
end Salbutamol_Boger2019_PD_fev1;
