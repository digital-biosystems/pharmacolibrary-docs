function p = Salbutamol_Walsh2023_residual_variability_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salbutamol   source: Walsh_2023 / residual_variability   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Salbutamol_Walsh2023_residual_variability_params';
  p.drug  = 'salbutamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 109.0;                % central volume [L]
  p.CL = 8.58;                % clearance [L/h]
  p.Vp = [69.4];             % peripheral volumes [L]
  p.Q  = [8.58];             % inter-compartmental clearances [L/h]
  p.ka = 16.7;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
