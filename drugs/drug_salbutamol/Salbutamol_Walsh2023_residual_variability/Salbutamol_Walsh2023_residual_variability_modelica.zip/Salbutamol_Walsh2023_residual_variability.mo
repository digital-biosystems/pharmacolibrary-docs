model Salbutamol_Walsh2023_residual_variability
  parameter Real Cl_ref = 2.3833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.109 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.004638888888888889,
    Tlag = 0.0,
    k12 = 2.1865443425076454e-05,
    k21 = 3.4341978866474546e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>children with acute asthma</td></tr><tr><td>source_paper:</td><td>Walsh_2023</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Additive on logit-scale' — extend the ontology if this is a real PK parameter (source ['Walsh_2023_table_p23_1:row15:col3'])</li><li>salvaged Q22 ('intercompartment clearance'=8.58) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central volume'=109) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('peripheral volume'=69.4) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('ka (h -1 )'=16.7) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q (l/h)'=8.58) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'residual variability' subgroup of Walsh_2023 (paper reports 3 populations: fixed effects, random effects, residual variability)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Walsh2023_residual_variability;
