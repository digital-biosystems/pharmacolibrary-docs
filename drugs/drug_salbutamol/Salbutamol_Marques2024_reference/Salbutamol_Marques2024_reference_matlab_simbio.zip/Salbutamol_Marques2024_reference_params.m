function p = Salbutamol_Marques2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salbutamol   source: Marques_2024 / reference   route: oral
  p.name  = 'Salbutamol_Marques2024_reference_params';
  p.drug  = 'salbutamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 195.75;                % central volume [L]
  p.CL = 43.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.474;                 % bioavailability [0-1]
  p.Tlag = 1.5;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
