model Salbutamol_Marques2024_reference
  parameter Real Cl_ref = 1.2166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.19575 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 47.4,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2393107,
    adminMass = 4e-06,
    ka = 0.0001388888888888889,
    Tlag = 5400.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>virtual patients</td></tr><tr><td>source_paper:</td><td>Marques_2024</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-00039-t006</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salbutamol 239.311 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'fold-error' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fold-error' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fold-error' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fold-error' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fold-error' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>salvaged Q22 ('Cl'=43.8) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd'=195.75) from results prose — parameter table was unreadable</li><li>implicit units: 'Cl' → L/h (from the paper text: &quot;The text explicitly states the units in the stratified analysis section: 'for the 26–75 kg with a BSA < 1.6 m2 group, Cl&quot;)</li><li>implicit units: 'Vd' → L (from the paper text: &quot;The text explicitly states the units in the stratified analysis section: 'Cl was observed to be 78 L/h, and V1 was 226 L&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>base model from table(s) without population columns (Marques_2024:results_prose, Marques_2024_table_4); populations estimate, geometric mean, value kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Heuberger_2018's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Heuberger_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Marques2024_reference;
