model Salbutamol_Marques2024v2_reference
  parameter Real Cl_ref = 9.702777777777779e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16293000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.003763888888888889,
    Tlag = 0.0,
    k12 = 1.8054788354917243e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>virtual patients and asthma patients</td></tr><tr><td>source_paper:</td><td>Marques_2024_2</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-00881-t003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('ka and Q', value '-0.83') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V1 and Cl' — extend the ontology if this is a real PK parameter (source ['Marques_2024_2_table_4:row14:col1', 'Marques_2024_2_table_4:row14:col2'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (Cl (L/h)); Q30 (Q (L/h)); Q64 (V2 (L)); Q63 (V1 (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Marques2024v2_reference;
