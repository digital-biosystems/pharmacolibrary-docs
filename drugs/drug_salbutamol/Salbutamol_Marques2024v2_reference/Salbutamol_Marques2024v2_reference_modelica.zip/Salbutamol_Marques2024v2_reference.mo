model Salbutamol_Marques2024v2_reference
  parameter Real Cl_ref = 9.702777777777779e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16293000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2393107,
    adminMass = 1.2e-05,
    ka = 0.003763888888888889,
    Tlag = 0.0,
    k12 = 1.8054788354917243e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>adults with asthma</td></tr><tr><td>source_paper:</td><td>Marques_2024_2</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-00881-t003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salbutamol 239.311 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>table section covariance: 'ka and Q' routed out of structural estimates ('Correlation')</li><li>table section covariance: 'ka and Q' routed out of structural estimates ('Correlation')</li><li>table section covariance: 'V1 and Cl' routed out of structural estimates ('Correlation')</li><li>dropped duplicate Q49 ('Parameters / ka (h−1)', value '0.0130') — already have one for this compound</li><li>dropped duplicate Q22 ('Parameters / Cl (mL/h)', value '8.77') — already have one for this compound</li><li>dropped duplicate Q64 ('Parameters / V2 (mL)', value '0.0460') — already have one for this compound</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (Cl (L/h)); Q30 (Q (L/h)); Q63 (V1 (L)); Q64 (V2 (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Marques2024v2_reference;
