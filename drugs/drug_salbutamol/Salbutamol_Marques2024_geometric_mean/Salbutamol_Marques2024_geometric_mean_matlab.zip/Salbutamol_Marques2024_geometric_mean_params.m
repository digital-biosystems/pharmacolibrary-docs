function p = Salbutamol_Marques2024_geometric_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salbutamol   source: Marques_2024 / geometric_mean   route: oral
  % estimated (absent from source): F
  p.name  = 'Salbutamol_Marques2024_geometric_mean_params';
  p.drug  = 'salbutamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 226.0;                % central volume [L]
  p.CL = 77.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.71;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
