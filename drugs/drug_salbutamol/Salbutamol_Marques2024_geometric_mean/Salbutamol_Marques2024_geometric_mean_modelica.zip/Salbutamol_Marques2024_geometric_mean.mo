model Salbutamol_Marques2024_geometric_mean
  parameter Real Cl_ref = 2.163888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.226 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2393107,
    adminMass = 4e-06,
    ka = 0.0010305555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>virtual patients with varying characteristics (age, weight, race, gender, health status)</td></tr><tr><td>source_paper:</td><td>Marques_2024</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-00039-t006</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salbutamol 239.311 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '0.94–1.60' — extend the ontology if this is a real PK parameter (source ['Marques_2024_table_7:row4:col3', 'Marques_2024_table_7:row7:col3'])</li><li>dropped unlinked row (NIL): '1.60–2.37' — extend the ontology if this is a real PK parameter (source ['Marques_2024_table_7:row5:col3', 'Marques_2024_table_7:row8:col3'])</li><li>implicit units: 'V1' → L (from the paper text: 'The text states: &quot;Cl was observed to be 78 L/h, and V1 was 226 L.&quot;')</li><li>implicit units: 'Cl' → L/h (from the paper text: 'The text states: &quot;Cl was observed to be 78 L/h, and V1 was 226 L.&quot; (77.9 is consistent with this magnitude)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1' is the general volume)</li><li>population split: 'geometric mean' subgroup of Marques_2024 (paper reports 2 populations: estimate, geometric mean)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Marques_2024_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Marques2024_geometric_mean;
