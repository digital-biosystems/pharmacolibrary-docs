model Salbutamol_Walsh2023_random_effects
  parameter Real Cl_ref = 1.45e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0017900000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0010305555555555556,
    Tlag = 0.0,
    k12 = 0.001643389199255121,
    k21 = 0.00045607235142118866
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>children with acute asthma</td></tr><tr><td>source_paper:</td><td>Walsh_2023</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'E0 (fraction of PASS-score [0-9])' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row11:col2'])</li><li>dropped PD-category row 'EMAX' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row18:col2'])</li><li>dropped PD-category row 'EC50 (ng/ml)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row19:col2', 'Walsh_2023_table_p23_1:row24:col2'])</li><li>dropped PD-category row 'E0 (z-score)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row22:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>population split: 'random effects' subgroup of Walsh_2023 (paper reports 3 populations: fixed effects, random effects, residual variability)</li><li>gap-filled Q30 (Q) from Marques_2024_2's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Marques_2024_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Walsh2023_random_effects;
