model Salbutamol_Courlet2022_reference
  parameter Real Cl_ref = 7.777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16702 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.008777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Courlet_2022</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412773-tbl-0001</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'logitF 2' — extend the ontology if this is a real PK parameter (source ['psp412773-tbl-0001:row3:col1'])</li><li>dropped duplicate Q49 ('k a2 (h−1)', value '1.47') — already have one for this compound</li><li>dropped duplicate Q22 ('ω CL (CV%) b', value '37') — already have one for this compound</li><li>dropped unlinked row (NIL): 'θ physical,UR_PROD' — extend the ontology if this is a real PK parameter (source ['psp412773-tbl-0001:row11:col1', 'psp412773-tbl-0001:row11:col2', 'psp412773-tbl-0001:row11:col3'])</li><li>routed 'ω UR_PRODuncorrected (CV%) b' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'ω UR_PRODcorrected (CV%) b' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped value-less row: 'F 2'</li><li>dropped value-less row: 'k a1'</li><li>dropped value-less row: 'k a2'</li><li>dropped value-less row: 'k 34'</li><li>dropped value-less row: 'k 30'</li><li>dropped value-less row: 'V 3'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Courlet2022_reference;
