function p = Salbutamol_Courlet2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salbutamol   source: Courlet_2022 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Salbutamol_Courlet2022_reference_params';
  p.drug  = 'salbutamol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 167.02;                % central volume [L]
  p.CL = 28.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 31.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
