% Run (SimBiology): build model + dose, simulate 0..27.0 h, plot.
p = Salbutamol_Courlet2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 27.0);
