function p = Salbutamol_Heuberger2018_original_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salbutamol   source: Heuberger_2018 / original_value   route: oral
  % estimated (absent from source): F
  p.name  = 'Salbutamol_Heuberger2018_original_value_params';
  p.drug  = 'salbutamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 78.4;                % central volume [L]
  p.CL = 5.91;                % clearance [L/h]
  p.Vp = [134.4];             % peripheral volumes [L]
  p.Q  = [0.56];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
