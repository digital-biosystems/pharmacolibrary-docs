function p = Salbutamol_Walsh2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salbutamol   source: Walsh_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Salbutamol_Walsh2023_reference_params';
  p.drug  = 'salbutamol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.79;                % central volume [L]
  p.CL = 0.522;                % clearance [L/h]
  p.Vp = [6.45];             % peripheral volumes [L]
  p.Q  = [8.58];             % inter-compartmental clearances [L/h]
  p.ka = 16.7;                % absorption rate [1/h]
  p.F  = 0.0925;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
