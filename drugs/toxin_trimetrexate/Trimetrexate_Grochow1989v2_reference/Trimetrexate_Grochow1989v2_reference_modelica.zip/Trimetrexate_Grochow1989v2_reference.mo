model Trimetrexate_Grochow1989v2_reference
  parameter Real Cl_ref = 8.611111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022490000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369425,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>trimetrexate</td></tr><tr><td>population:</td><td>patients with advanced solid tumors</td></tr><tr><td>source_paper:</td><td>Grochow_1989_2</td></tr><tr><td>measured_compound:</td><td>Trimetrexate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Trimetrexate 369.425 g/mol (pubchem); Trimetrexate glucuronate 563.564 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is trimetrexate; the compartment is Trimetrexate. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Trimetrexate, not trimetrexate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>trimetrexate's own concentration-time course is not produced by this model</li><li>unit_dimension_unknown: 'mL/min per m2' (CL)</li><li>implicit units: 'mean total body clearance' → L/h (from the popPK convention: 'The parameter is mean total body clearance. In the absence of specific units in the text or table, the most common unit ')</li><li>metabolite trimetrexate: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite trimetrexate: Q61→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Trimetrexate</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 2/2 row label(s) assigned, 0 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Trimetrexate_Grochow1989v2_reference;
