model Trimetrexate_Reece1987_reference
  parameter Real Cl_ref = 8.765333333333335e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.056744 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369425,
    adminMass = 8.5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>trimetrexate</td></tr><tr><td>population:</td><td>16 patients with refractory or relapsing cancer</td></tr><tr><td>source_paper:</td><td>Reece_1987</td></tr><tr><td>measured_compound:</td><td>Trimetrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>trimetrexate 369.425 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'mean percentage of the trimetrexate dose excreted unchanged in urine' → Q44: printed without a unit and above 1 — read as a percentage</li><li>covariate creatinine for fe from footnote/prose kept as documentation only (['Reece_1987:abstract'])</li><li>dropped unlinked row (NIL): 'P for percentage excreted vs creatinine clearance' — extend the ontology if this is a real PK parameter (source ['Reece_1987:abstract'])</li><li>covariate renal for slope from footnote/prose kept as documentation only (['Reece_1987:abstract'])</li><li>covariate renal for CLR from footnote/prose kept as documentation only (['Reece_1987:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Trimetrexate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Trimetrexate_Reece1987_reference;
