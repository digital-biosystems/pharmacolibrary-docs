% Run (SimBiology): build model + dose, simulate 0..36.0 h, plot.
p = Metronidazole_FischerHolzhausen2026_m_nnist_1984_single_poin_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 36.0);
