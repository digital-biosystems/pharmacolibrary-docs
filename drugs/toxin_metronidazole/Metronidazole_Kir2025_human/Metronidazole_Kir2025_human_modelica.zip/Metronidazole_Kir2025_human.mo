model Metronidazole_Kir2025_human
  parameter Real Cl_ref = 5.95e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.793,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.171156,
    adminMass = 0.00035,
    ka = 0.00023694444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metronidazole</td></tr><tr><td>population:</td><td>Multiple species (human and veterinary)</td></tr><tr><td>source_paper:</td><td>Kir_2025</td></tr><tr><td>measured_compound:</td><td>Metronidazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metronidazole 171.156 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Metronidazole</li><li>population split: 'human' subgroup of Kir_2025 (paper reports 14 populations: cat, cattle, chicken, dog, estimate (cv%), goat (29.8), goose, horse, human, mouse, pigeon, rat, sheep (29.8), turkey)</li><li>gap-filled Q61 (V) from Hartman_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metronidazole_Kir2025_human;
