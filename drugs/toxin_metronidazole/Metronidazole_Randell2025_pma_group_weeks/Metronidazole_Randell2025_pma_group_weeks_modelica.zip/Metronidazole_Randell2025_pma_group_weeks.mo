model Metronidazole_Randell2025_pma_group_weeks
  parameter Real Cl_ref = 1.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.171156,
    adminMass = 0.000525,
    ka = 0.00021666666666666668,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metronidazole</td></tr><tr><td>population:</td><td>critically ill infants</td></tr><tr><td>source_paper:</td><td>Randell_2025</td></tr><tr><td>measured_compound:</td><td>Metronidazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metronidazole 171.156 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Cmax,ss (mg/L)', value '31.41') — already have one for this compound</li><li>dropped duplicate Q36 ('Cmin,ss (mg/L)', value '22.39') — already have one for this compound</li><li>dropped unlinked row (NIL): 'AUC0–24, ss/MIC ≥ 70 for MIC = 2 µg/mL (%)' — extend the ontology if this is a real PK parameter (source ['Randell_2025_table_1:row8:col3', 'Randell_2025_table_1:row8:col4', 'Randell_2025_table_1:row8:col5'])</li><li>dropped unlinked row (NIL): 'AUC0–24, ss/MIC ≥ 70 for MIC = 4 µg/mL (%)' — extend the ontology if this is a real PK parameter (source ['Randell_2025_table_1:row9:col3', 'Randell_2025_table_1:row9:col4', 'Randell_2025_table_1:row9:col5'])</li><li>unit_dimension_mismatch: 'Cmin,1 > 8 (%)' → Q36 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q36 ('Cmin,1 > 8 (%)', value '59') — already have one for this compound</li><li>unit_dimension_mismatch: 'Cmin,1 > 2 (%)' → Q36 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q36 ('Cmin,1 > 2 (%)', value '100') — already have one for this compound</li><li>unit_dimension_mismatch: 'Cmin,ss > 8 (%)' → Q36 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q36 ('Cmin,ss > 8 (%)', value '98') — already have one for this compound</li><li>unit_dimension_mismatch: 'Cmin,ss > 2 (%)' → Q36 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q36 ('Cmin,ss > 2 (%)', value '100') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Metronidazole</li><li>population split: 'pma group (weeks)' subgroup of Randell_2025 (paper reports 3 populations: pma group (weeks), pna group (days), total)</li><li>gap-filled Q22 (CL) from Arévalo-Pérez_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hartman_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Metronidazole_Randell2025_pma_group_weeks;
