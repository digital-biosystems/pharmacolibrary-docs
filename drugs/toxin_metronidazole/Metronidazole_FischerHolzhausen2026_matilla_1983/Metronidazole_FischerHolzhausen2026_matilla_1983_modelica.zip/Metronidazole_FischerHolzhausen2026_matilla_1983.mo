model Metronidazole_FischerHolzhausen2026_matilla_1983
  parameter Real Cl_ref = 1.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.171156,
    adminMass = 0.002,
    ka = 0.00021666666666666668,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metronidazole</td></tr><tr><td>population:</td><td>Female European population (n=100) / Healthy women</td></tr><tr><td>source_paper:</td><td>Fischer-Holzhausen_2026</td></tr><tr><td>measured_compound:</td><td>Metronidazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T6</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metronidazole 171.156 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'matilla 1983' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Cmax (mg/L)(predicted)'; source reconciliation required</li><li>column 'matilla 1983' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'AUC (mg*h/L)(predicted)'; source reconciliation required</li><li>column 'matilla 1983' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Cmax (mg/L)(observed)'; source reconciliation required</li><li>column 'matilla 1983' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'AUC (mg*h/L)(observed)'; source reconciliation required</li><li>column 'matilla 1983' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Cmax ratio'; source reconciliation required</li><li>column 'matilla 1983' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'AUC ratio'; source reconciliation required</li><li>dropped duplicate Q32 ('Cmax (mg/L)(observed)', value '9.00') — already have one for this compound</li><li>dropped duplicate Q88 ('AUC (mg*h/L)(observed)', value '90.68') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Metronidazole</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Metronidazole_FischerHolzhausen2026_matilla_1983;
