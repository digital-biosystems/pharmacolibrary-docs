function p = Metronidazole_Randell2025_total_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metronidazole   source: Randell_2025 / total   route: oral
  % estimated (absent from source): F
  p.name  = 'Metronidazole_Randell2025_total_params';
  p.drug  = 'metronidazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 35.0;                % central volume [L]
  p.CL = 3.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.78;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 525.0;             % dose [mg]
end
