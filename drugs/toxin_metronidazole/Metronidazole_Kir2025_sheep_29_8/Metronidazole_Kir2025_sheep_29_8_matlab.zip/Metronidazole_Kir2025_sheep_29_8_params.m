function p = Metronidazole_Kir2025_sheep_29_8_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metronidazole   source: Kir_2025 / sheep_29_8   route: oral
  % estimated (absent from source): F
  p.name  = 'Metronidazole_Kir2025_sheep_29_8_params';
  p.drug  = 'metronidazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 35.0;                % central volume [L]
  p.CL = 10.122;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.78;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
