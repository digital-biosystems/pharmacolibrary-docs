model Metronidazole_FischerHolzhausen2026_salas_herrera_1991b
  parameter Real Cl_ref = 1.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.171156,
    adminMass = 0.002,
    ka = 0.00021666666666666668,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metronidazole</td></tr><tr><td>population:</td><td>Female European population (n=100) / Healthy women</td></tr><tr><td>source_paper:</td><td>Fischer-Holzhausen_2026</td></tr><tr><td>measured_compound:</td><td>Metronidazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T6</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metronidazole 171.156 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax (mg/L)(predicted)'; source reconciliation required</li><li>table representations disagree for 'AUC (mg*h/L)(predicted)'; source reconciliation required</li><li>table representations disagree for 'Cmax (mg/L)(observed)'; source reconciliation required</li><li>table representations disagree for 'AUC (mg*h/L)(observed)'; source reconciliation required</li><li>table representations disagree for 'Cmax ratio'; source reconciliation required</li><li>table representations disagree for 'AUC ratio'; source reconciliation required</li><li>dropped duplicate Q32 ('Cmax (mg/L)(observed)', value '0.80') — already have one for this compound</li><li>dropped duplicate Q88 ('AUC (mg*h/L)(observed)', value '6.58') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Metronidazole</li><li>status held at route_to_review — not promoted</li><li>population split: 'salas-herrera 1991b' subgroup of Fischer-Holzhausen_2026 (paper reports 10 populations: 37.5 mg, 400 mg, 400 mg tid, 500 mg, cunningham 1994, fredericsson 1987, matilla 1983, männistö 1984 (+ single points endometrium and myometrium), salas-herera 1991a, salas-herrera 1991b)</li><li>gap-filled Q22 (CL) from Arévalo-Pérez_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hartman_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Arévalo-Pérez_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Metronidazole_FischerHolzhausen2026_salas_herrera_1991b;
