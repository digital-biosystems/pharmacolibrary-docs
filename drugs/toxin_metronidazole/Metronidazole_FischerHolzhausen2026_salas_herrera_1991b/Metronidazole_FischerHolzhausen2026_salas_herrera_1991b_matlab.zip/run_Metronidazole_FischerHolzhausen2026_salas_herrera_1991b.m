% Run: build params, simulate 0..36.0 h, plot + save Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.m
here = fileparts(mfilename('fullpath'));
p = Metronidazole_FischerHolzhausen2026_salas_herrera_1991b_params();
out = simulate_pk(p, 0:0.05:36.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('metronidazole — Fischer-Holzhausen_2026 (oral)');
print(fig, fullfile(here, 'Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.json'), 'w');
try
  s.model = 'Metronidazole_FischerHolzhausen2026_salas_herrera_1991b'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Metronidazole_FischerHolzhausen2026_salas_herrera_1991b","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.png, Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.csv, Metronidazole_FischerHolzhausen2026_salas_herrera_1991b.json\n');
