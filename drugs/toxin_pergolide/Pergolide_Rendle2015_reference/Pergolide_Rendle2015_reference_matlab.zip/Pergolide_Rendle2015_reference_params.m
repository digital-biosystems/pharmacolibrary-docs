function p = Pergolide_Rendle2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pergolide   source: Rendle_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pergolide_Rendle2015_reference_params';
  p.drug  = 'pergolide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 55.3;                % central volume [L]
  p.CL = 67.13;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
