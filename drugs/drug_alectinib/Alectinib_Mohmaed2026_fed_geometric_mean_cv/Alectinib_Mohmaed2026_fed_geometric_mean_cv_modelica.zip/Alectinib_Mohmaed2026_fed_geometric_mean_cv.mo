model Alectinib_Mohmaed2026_fed_geometric_mean_cv
  parameter Real Cl_ref = 2.3388888888888893e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.776 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0012,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alectinib</h4><p>Alectinib is a protein kinase inhibitor that blocks anaplastic lymphoma kinase to treat non-small-cell lung carcinoma. The medication is administered orally in capsule form. It is authorised for use in the European Union and other regions worldwide.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q21099132\">Wikidata Q21099132</a>, <a href=\"https://en.wikipedia.org/wiki/Alectinib?oldid=1383705635\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alectinib</td></tr><tr><td>population:</td><td>patients with ALK-positive, non-small cell lung cancer</td></tr><tr><td>source_paper:</td><td>Mohmaed_2026</td></tr><tr><td>measured_compound:</td><td>2H6-alectinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt70141-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>alectinib 482.617 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'fed geometric mean (%cv)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'fed geometric mean (%cv)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>salvaged Q27 ('CL/F'=84.2) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('VD/F'=776) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=2H6-alectinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'fed geometric mean (%cv)' subgroup of Mohmaed_2026 (paper reports 3 populations: estimate, fasted geometric mean (%cv), fed geometric mean (%cv))</li><li>molar mass: no plausible PubChem entry for '2H6-alectinib' ('2H6-alectinib') — left in mass units</li><li>molar mass: none found for '2H6-alectinib' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end Alectinib_Mohmaed2026_fed_geometric_mean_cv;
