function p = Linagliptin_Retlich2010v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: linagliptin   source: Retlich_2010_2 / reference   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Linagliptin_Retlich2010v2_reference_params';
  p.drug  = 'linagliptin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 380.0;                % central volume [L]
  p.CL = 2.51;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.63;                % absorption rate [1/h]
  p.F  = 0.3;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
