model Linagliptin_Retlich2015_PD_dpp_4
  "sigmoid_emax exposure-response sweep — Retlich_2015 :: DPP-4 (DPP-4 activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 10700,      // [RFU]
    Emax = -0.924,  // [1; % × 0.01]
    EC50 = 3.06e-06,  // [mol/m3; nmol/L × 1e-06]
    gamma = 3.22,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 31, Interval = 0.062),
    Documentation(info = "<html><body><!-- drug-about --><h4>About linagliptin</h4><p>Linagliptin is a DPP-4 inhibitor used to lower blood sugar in adults with type 2 diabetes, available alone or in fixed oral combinations with other glucose-lowering drugs. It is approved and authorised in the European Union and is widely used as an oral anti-diabetic medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q909745\">Wikidata Q909745</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Linagliptin_Retlich2015_PD_dpp_4</h4><p>The steady-state exposure-response curve of Retlich S et al., <i>Clinical pharmacokinetics 54(7):737–750</i> 2015 (<a href=\"https://doi.org/10.1007/s40262-014-0232-4\">doi:10.1007/s40262-014-0232-4</a>) — DPP-4 activity [RFU] against linagliptin nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      10700 RFU      drug-free response (baseline) (BSLmale, Q324)
  Emax  =       92.4 %        maximal effect term (E max, Q323)
  EC50  =       3.06 nmol/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma =       3.22          Hill coefficient (HILL, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of linagliptin per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.07e+04   (drug-free)
  exposure = EC50 (3.06 nmol/L)  response 1.07e+04
  exposure -> infinity  response 1.07e+04</pre></body></html>"));
end Linagliptin_Retlich2015_PD_dpp_4;
