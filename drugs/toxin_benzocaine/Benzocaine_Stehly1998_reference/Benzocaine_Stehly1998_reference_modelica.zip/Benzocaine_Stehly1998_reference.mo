model Benzocaine_Stehly1998_reference
  parameter Real Cl_ref = 0.0006778333333333335 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16583 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.165192,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>benzocaine</td></tr><tr><td>population:</td><td>rainbow trout (Oncorhynchus mykiss) acclimated at 6, 12, or 18 degrees C</td></tr><tr><td>source_paper:</td><td>Stehly_1998</td></tr><tr><td>measured_compound:</td><td>Benzocaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>benzocaine 165.192 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('uptake clearance at 18 degrees C', value '1154') — already have one for this compound</li><li>dropped duplicate Q22 ('metabolic clearance at 6 degrees C', value '15.2') — already have one for this compound</li><li>dropped duplicate Q22 ('metabolic clearance at 18 degrees C', value '22.3') — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life of benzocaine in plasma at 12 degrees C', value '35.9') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Benzocaine</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Benzocaine_Stehly1998_reference;
