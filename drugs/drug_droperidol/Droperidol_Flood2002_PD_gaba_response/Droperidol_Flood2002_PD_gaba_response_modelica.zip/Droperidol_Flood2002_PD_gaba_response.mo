model Droperidol_Flood2002_PD_gaba_response
  "sigmoid_emax exposure-response sweep — Flood_2002 :: GABA response (GABA response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.247,  // [1; % × 0.01]
    EC50 = 12.6,  // [nm]
    gamma = 1,
    exposure_per_s = 1);   // 1 nm per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nm' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About droperidol</h4><p>Droperidol is a butyrophenone antipsychotic used to treat pain and schizophreniform disorder, as well as nausea and agitation. It is usually given by intramuscular or intravenous injection. The drug is approved for human and veterinary use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q174259\">Wikidata Q174259</a>, <a href=\"https://en.wikipedia.org/wiki/Droperidol?oldid=1384038718\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Droperidol_Flood2002_PD_gaba_response</h4><p>The steady-state exposure-response curve of Flood P et al., <i>Anesthesiology 96(4):987–993</i> 2002 (<a href=\"https://doi.org/10.1097/00000542-200204000-00029\">doi:10.1097/00000542-200204000-00029</a>) — GABA response against droperidol nm — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       24.7 %        maximal effect term (maximum, Q323)
  EC50  =       12.6 nm       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nm of droperidol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (12.6 nm)  response -0.1235
  exposure -> infinity  response -0.247</pre></body></html>"));
end Droperidol_Flood2002_PD_gaba_response;
