function p = Droperidol_Flood2002_PD_gaba_response_params()
% Droperidol_Flood2002_PD_gaba_response_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% droperidol Flood_2002::GABA_response: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nm per second, in SI inside (kg/m3, s). Response GABA response in its own unit. Driver: droperidol (cited_pk).
p.E0 = 0.0;
p.Emax = -0.247;
p.EC50 = 12.6;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
