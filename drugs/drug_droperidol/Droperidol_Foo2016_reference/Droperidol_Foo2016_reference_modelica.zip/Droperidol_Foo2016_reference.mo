model Droperidol_Foo2016_reference
  parameter Real Cl_ref = 1.1638888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0736 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37942739999999997,
    adminMass = 2.5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About droperidol</h4><p>Droperidol is a butyrophenone antipsychotic used to treat pain and schizophreniform disorder, as well as nausea and agitation. It is usually given by intramuscular or intravenous injection. The drug is approved for human and veterinary use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q174259\">Wikidata Q174259</a>, <a href=\"https://en.wikipedia.org/wiki/Droperidol?oldid=1384038718\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>droperidol</td></tr><tr><td>population:</td><td>acutely agitated patients</td></tr><tr><td>source_paper:</td><td>Foo_2016</td></tr><tr><td>measured_compound:</td><td>droperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>droperidol 379.427 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'absorption rate constant'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=droperidol</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of distribution of the central compartment' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Droperidol_Foo2016_reference;
