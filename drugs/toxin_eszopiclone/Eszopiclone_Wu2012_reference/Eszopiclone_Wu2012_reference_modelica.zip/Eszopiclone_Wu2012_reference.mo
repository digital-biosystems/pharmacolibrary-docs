// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Eszopiclone_Wu2012_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {21024.0},
    MM = 0.388812,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>eszopiclone</td></tr><tr><td>population:</td><td>healthy adult Chinese volunteers</td></tr><tr><td>source_paper:</td><td>Wu_2012</td></tr><tr><td>measured_compound:</td><td>Eszopiclone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>eszopiclone 388.812 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Cmax (3 mg)', value 38.29) — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (6 mg)', value 76.38) — already have one for this compound</li><li>dropped duplicate Q56 ('Tmax (3 mg)', value 1.04) — already have one for this compound</li><li>dropped duplicate Q56 ('Tmax (6 mg)', value 1.08) — already have one for this compound</li><li>dropped duplicate Q19 ('AUC0-24 (6 mg)', value 504.1) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life (3 mg)', value 5.53) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life (6 mg)', value 6.17) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Eszopiclone</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 216.0));
end Eszopiclone_Wu2012_reference;
