model Trazodone_Oggianu2023_PD_w
  "linear exposure-response sweep — Oggianu_2023 :: W (number of writhings)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 654000   "[meter ** 3 * second / mole; L/μmoles/min × 60000]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About trazodone</h4><p>Trazodone is an antidepressant used for depression, and also for conditions such as anxiety, insomnia, sleep-wake disorders, delirium and neurotic disorders. It is an approved medicine in widespread clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411457\">Wikidata Q411457</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Trazodone_Oggianu2023_PD_w</h4><p>The steady-state exposure-response curve of Oggianu L et al., <i>Clinical and translational science 16(4):606–617</i> 2023 (<a href=\"https://doi.org/10.1111/cts.13472\">doi:10.1111/cts.13472</a>) — number of writhings against trazodone μmoles/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       10.9 L/μmoles/min change in response per unit of exposure (k 2, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μmoles/L of trazodone per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Trazodone_Oggianu2023_PD_w;
