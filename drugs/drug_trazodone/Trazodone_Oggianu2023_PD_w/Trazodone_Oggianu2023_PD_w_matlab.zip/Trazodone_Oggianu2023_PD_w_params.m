function p = Trazodone_Oggianu2023_PD_w_params()
% Trazodone_Oggianu2023_PD_w_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% trazodone Oggianu_2023::W: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmoles/L per second, in SI inside (kg/m3, s). Response W in its own unit. Driver: trazodone (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 654000.0000000002;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
