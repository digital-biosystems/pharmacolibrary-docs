model Trazodone_Knych2017_reference
  parameter Real Cl_ref = 7.991666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.058800000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>trazodone</td></tr><tr><td>population:</td><td>healthy horses</td></tr><tr><td>source_paper:</td><td>Knych_2017</td></tr><tr><td>measured_compound:</td><td>trazodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Terminal phase half-life', value 7.11) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trazodone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Cuomo_2026_2's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end Trazodone_Knych2017_reference;
