% Run (SimBiology): build model + dose, simulate 0..39.0 h, plot.
p = Trazodone_Cuomo2026v2_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 39.0);
