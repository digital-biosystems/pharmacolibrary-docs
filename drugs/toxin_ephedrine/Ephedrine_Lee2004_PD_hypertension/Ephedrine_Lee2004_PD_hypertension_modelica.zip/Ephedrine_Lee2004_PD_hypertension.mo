model Ephedrine_Lee2004_PD_hypertension
  "linear exposure-response sweep — Lee_2004 :: hypertension (hypertension)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 56300,  // [1]
    exposure_per_s = 1e-06);   // 1 mg per second
  // slope_unit_assumed: slope unit '(none)' read as response per mg
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Ephedrine_Lee2004_PD_hypertension</h4><p>The steady-state exposure-response curve of Lee A et al., <i>Anesthesia and analgesia 98(2):483–490</i> 2004 (<a href=\"https://doi.org/10.1213/01.ANE.0000096183.49619.FC\">doi:10.1213/01.ANE.0000096183.49619.FC</a>) — hypertension against ephedrine mg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0563          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg of ephedrine per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ephedrine_Lee2004_PD_hypertension;
