model Ephedrine_Jeong2021_reference
  parameter Real Cl_ref = 0.00012619444444444443 "Cl [m3/s]";
  parameter Real Vd_ref = 1.3062 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.165236,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ephedrine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Jeong_2021</td></tr><tr><td>measured_compound:</td><td>Ephedrine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00478-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ephedrine 165.236 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Oral (n = 5)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-13-00478-t002:row1:col2', 'Jeong_2021_table_3:row0:col2'])</li><li>unit_dimension_unknown: '8 h' (AUC)</li><li>unit_dimension_unknown: '8 h' (AUC∞)</li><li>unit_dimension_unknown: '8 h' (equation variable)</li><li>dropped duplicate Q88 ('AUC120–132', value '63.84') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC120-∞', value '77.32') — already have one for this compound</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['pharmaceutics-13-00478-t002:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['pharmaceutics-13-00478-t002:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['pharmaceutics-13-00478-t002:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['pharmaceutics-13-00478-t002:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'AUC0-12' → ng·h/mL (from the popPK convention: &quot;No explicit unit stated for AUC in Table 2. Text mentions plasma concentrations around '10 ng/mL'. AUC is the integral o&quot;)</li><li>implicit units: 'AUC0-∞' → ng·h/mL (from the popPK convention: 'Same reasoning as AUC0-12. Consistent with ng/mL concentrations and hours time.')</li><li>implicit units: 't1/2' → h (from the popPK convention: 'Half-life (t1/2) is a time parameter. In population PK and noncompartmental analysis, it is expressed in hours (h). The ')</li><li>implicit units: 'Cmax' → ng/mL (from the popPK convention: &quot;Cmax is concentration. Text mentions 'concentration of cinnamic acid ... around 10 ng/mL'. Given the values for Cmax (21&quot;)</li><li>implicit units: 'Tmax' → h (from the popPK convention: &quot;Tmax is a time parameter. Text states 'Tmax values ... less than 1.5 h' and '0.35–1.40 h', confirming hours.&quot;)</li><li>implicit units: 'CL/F' → L/h/kg (from the paper text: &quot;The text explicitly states: 'CL/F of 0.05–42.52 L/h/kg' when comparing human and rat data, referring to the rat values f&quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ephedrine_Jeong2021_reference;
