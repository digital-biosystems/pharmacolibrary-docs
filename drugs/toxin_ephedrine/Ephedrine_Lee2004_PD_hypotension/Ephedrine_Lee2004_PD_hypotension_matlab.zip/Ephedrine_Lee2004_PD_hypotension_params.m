function p = Ephedrine_Lee2004_PD_hypotension_params()
% Ephedrine_Lee2004_PD_hypotension_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ephedrine Lee_2004::hypotension: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response hypotension in its own unit. Driver: ephedrine (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -12800.000000000002;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
