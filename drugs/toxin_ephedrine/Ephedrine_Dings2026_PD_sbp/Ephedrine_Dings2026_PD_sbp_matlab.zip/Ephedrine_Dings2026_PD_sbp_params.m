function p = Ephedrine_Dings2026_PD_sbp_params()
% Ephedrine_Dings2026_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ephedrine Dings_2026::SBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: ephedrine (pk_record).
p.E0 = 0.0;
p.Emax = 169.0;
p.EC50 = 0.0644;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 650.0;
p.form = 'E0 + Emax*frac';
end
