model Ephedrine_Dings2026_PD_sbp
  "emax exposure-response sweep — Dings_2026 :: SBP (Systolic Blood Pressure (SBP))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 169,  // [mmHg]
    EC50 = 0.0644,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is transduction; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 650, Interval = 1.3),
    Documentation(info = "<html><body><h4>Ephedrine_Dings2026_PD_sbp</h4><p>The steady-state exposure-response curve of Dings C et al., <i>Pharmaceutics 18(3):296</i> 2026 (<a href=\"https://doi.org/10.3390/pharmaceutics18030296\">doi:10.3390/pharmaceutics18030296</a>) — Systolic Blood Pressure (SBP) [mmHg] against ephedrine mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        169 mmHg     maximal effect term (Maximum SBP, Q320)
  EC50  =       64.4 mg/L     exposure at half of the maximal effect term (Half-effective concentration SBP, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of ephedrine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (64.4 mg/L)  response 84.5
  exposure -> infinity  response 169</pre></body></html>"));
end Ephedrine_Dings2026_PD_sbp;
