model Nalmefene_Rosen2000_reference
  parameter Real Cl_ref = 1.4175e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.5047 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.339435,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nalmefene</h4><p>Nalmefene is an opioid antagonist used to treat opioid overdose and alcohol dependence. It is given by mouth, injection, or nasal administration, and is well absorbed orally. The drug is authorised in the European Union and available as a generic medication.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q4353252\">Wikidata Q4353252</a>, <a href=\"https://en.wikipedia.org/wiki/Nalmefene?oldid=1368650312\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalmefene</td></tr><tr><td>population:</td><td>children aged 2-12 years undergoing cardiothoracic surgery</td></tr><tr><td>source_paper:</td><td>Rosen_2000</td></tr><tr><td>measured_compound:</td><td>nalmefene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>nalmefene 339.435 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nalmefene</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Nalmefene_Rosen2000_reference;
