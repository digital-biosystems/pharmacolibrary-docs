function p = Pentobarbital_Frederiksen1983_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Frederiksen_1983 / reference   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Pentobarbital_Frederiksen1983_reference_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 75.6;                % central volume [L]
  p.CL = 0.0013;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
