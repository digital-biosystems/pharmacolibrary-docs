% run_Pentobarbital_Todorovic1998_PD_t_type_ca2_current  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Pentobarbital_Todorovic1998_PD_t_type_ca2_current_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [microM]'); ylabel('response []'); title('Pentobarbital_Todorovic1998_PD_t_type_ca2_current', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Pentobarbital_Todorovic1998_PD_t_type_ca2_current.csv');
