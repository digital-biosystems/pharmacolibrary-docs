model Pentobarbital_Todorovic1998_PD_t_type_ca2_current
  "sigmoid_emax exposure-response sweep — Todorovic_1998 :: T-type Ca2+ current (T-type Ca2+ current)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 334,  // [microM]
    gamma = 1.2,
    exposure_per_s = 1);   // 1 microM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'microM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 3400, Interval = 6.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pentobarbital</h4><p>Pentobarbital is a short-acting barbiturate sedative used to treat status epilepticus and assist with anesthesia. It is administered via intravenous, intramuscular, oral, or rectal routes, with specific formulations available for injection, tablets, capsules, or suppositories. The drug is approved for veterinary use, frequently used for euthanasia, and utilized in human executions and physician-assisted suicide in some regions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q409632\">Wikidata Q409632</a>, <a href=\"https://en.wikipedia.org/wiki/Pentobarbital?oldid=1379958545\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pentobarbital_Todorovic1998_PD_t_type_ca2_current</h4><p>The steady-state exposure-response curve of Todorovic SM et al., <i>Journal of neurophysiology 79(1):240–252</i> 1998 (<a href=\"https://doi.org/10.1152/jn.1998.79.1.240\">doi:10.1152/jn.1998.79.1.240</a>) — T-type Ca2+ current against pentobarbital microM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (maximum block, Q323)
  EC50  =        334 microM   exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.2          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microM of pentobarbital per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (334 microM)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Pentobarbital_Todorovic1998_PD_t_type_ca2_current;
