function p = Pentobarbital_Helfer2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Helfer_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pentobarbital_Helfer2026_reference_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 35.43;                % central volume [L]
  p.CL = 5.13;                % clearance [L/h]
  p.Vp = [62.71];             % peripheral volumes [L]
  p.Q  = [17.81];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 27.3;             % dose [mg]
end
