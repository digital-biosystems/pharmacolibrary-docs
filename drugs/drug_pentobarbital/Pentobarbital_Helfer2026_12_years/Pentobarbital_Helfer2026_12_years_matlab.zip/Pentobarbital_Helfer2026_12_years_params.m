function p = Pentobarbital_Helfer2026_12_years_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentobarbital   source: Helfer_2026 / 12_years   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pentobarbital_Helfer2026_12_years_params';
  p.drug  = 'pentobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 35.7;                % central volume [L]
  p.CL = 5.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 27.3;             % dose [mg]
end
