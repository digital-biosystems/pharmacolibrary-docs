model Pentobarbital_Helfer2026_12_years
  parameter Real Cl_ref = 1.4777777777777779e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0357 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2262722,
    adminMass = 2.73e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pentobarbital</h4><p>Pentobarbital is a short-acting barbiturate sedative used to treat status epilepticus and assist with anesthesia. It is administered via intravenous, intramuscular, oral, or rectal routes, with specific formulations available for injection, tablets, capsules, or suppositories. The drug is approved for veterinary use, frequently used for euthanasia, and utilized in human executions and physician-assisted suicide in some regions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q409632\">Wikidata Q409632</a>, <a href=\"https://en.wikipedia.org/wiki/Pentobarbital?oldid=1379958545\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>pediatric patients (birth to 21 years)</td></tr><tr><td>source_paper:</td><td>Helfer_2026</td></tr><tr><td>measured_compound:</td><td>pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70204-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.272 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Number of Participants' — extend the ontology if this is a real PK parameter (source ['Helfer_2026_table_3:row3:col1'])</li><li>dropped unlinked row (NIL): 'Total Body Weight (kg)' — extend the ontology if this is a real PK parameter (source ['Helfer_2026_table_3:row3:col2'])</li><li>dropped duplicate Q22 ('CL (L/h)', value '4.2') — already have one for this compound</li><li>dropped duplicate Q63 ('V1 (L)', value '28') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pentobarbital</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1 (L/kg)' is the general volume)</li><li>population split: '≥12 years' subgroup of Helfer_2026 (paper reports 5 populations: 2 to <6 years, 6 to <12 years, <2 years, estimate, ≥12 years)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Helfer2026_12_years;
