model PipecuroniumBromide_Caldwell1988_reference
  parameter Real Cl_ref = 2.8e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02163 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6028912000000001,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pipecuronium_bromide</h4><p>Pipecuronium bromide is a non-depolarising neuromuscular blocking agent, a muscle relaxant used to relax muscles during surgery. It is no longer in use, having been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20817188\">Wikidata Q20817188</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pipecuronium_bromide</td></tr><tr><td>population:</td><td>ASA class I or II patients</td></tr><tr><td>source_paper:</td><td>Caldwell_1988</td></tr><tr><td>measured_compound:</td><td>pipecuronium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pipecuronium_bromide 602.891 g/mol (drugbank); pipecuronium 602.891 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q65 ('pancuronium Vss', value 199) — already have one for this compound</li><li>dropped duplicate Q22 ('pancuronium Cl', value 1.5) — already have one for this compound</li><li>dropped unlinked row (NIL): 'pipecuronium duration of action' — extend the ontology if this is a real PK parameter (source ['Caldwell_1988:abstract'])</li><li>dropped unlinked row (NIL): 'pancuronium duration of action' — extend the ontology if this is a real PK parameter (source ['Caldwell_1988:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pipecuronium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end PipecuroniumBromide_Caldwell1988_reference;
