// parent + metabolites (N-desmethyl enzalutamide): PK_3M_9C — formed from central; parent 1, metabolites [2]
model Talazoparib_Hadigol2026_reference
  parameter Real Q27_enzalutamide_ref = 1.1805555555555555e-07 "θ CLe/Fe (L/h) [SI]";
  parameter Real cov_age_0 = 0 "age covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.025293,
    q12 = 5.7344444444444445e-06,
    q21 = 5.7344444444444445e-06,
    q13 = 4.3244444444444445e-06,
    q31 = 4.3244444444444445e-06,
    q1_m11 = 0.634*(Q27_enzalutamide_ref*(1 + (-0.003)*cov_age_0)),
    CL1 = max((Q27_enzalutamide_ref*(1 + (-0.003)*cov_age_0)) - (0.634*(Q27_enzalutamide_ref*(1 + (-0.003)*cov_age_0))), 0),
    Vd1m1 = 0.044944000000000005,
    CLm1 = 7.944444444444444e-08,
    Vd2m1 = 0.052372999999999996,
    qm11_m12 = 2.6230555555555555e-06,
    qm12_m11 = 2.6230555555555555e-06,
    MW = 0.380359,
    MW_m1 = 0.45041000000000003,
    F = 1,
    ka = 0.0009530555555555556,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.5e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About talazoparib</h4><p>Talazoparib is a PARP inhibitor anticancer drug used to treat breast cancer. It is approved and authorised in the European Union for breast cancer, though it remains a specialised oncology medicine rather than a widely used drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25100990\">Wikidata Q25100990</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>talazoparib</td></tr><tr><td>population:</td><td>patients with metastatic castration-resistant prostate cancer</td></tr><tr><td>source_paper:</td><td>Hadigol_2026</td></tr><tr><td>measured_compound:</td><td>talazoparib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70125-tbl-0001</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of N-desmethyl enzalutamide: fm=0.634 × CL; dose 0.35 mg (paper); covariate effects applied (1): theta_cl_f_age — typical subject by default</td></tr><tr><td>molar_masses:</td><td>N-desmethyl enzalutamide 450.41 g/mol (pubchem); enzalutamide 464.437 g/mol (pubchem); talazoparib 380.359 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q76 ('θ Vpe/Fe (L)', value '45.928') — already have one for this compound</li><li>unit_dimension_unknown: 'R' (fe)</li><li>routed 'Thetarized sigma' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Body weight effect on θ CLe/Fe' — extend the ontology if this is a real PK parameter (source ['jcph70125-tbl-0001:row9:col1'])</li><li>dropped unlinked row (NIL): 'Body weight effect on θ Vce/Fe' — extend the ontology if this is a real PK parameter (source ['jcph70125-tbl-0001:row11:col1'])</li><li>unit_dimension_unknown: 'R' (fm)</li><li>routed 'Thetarized σ' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>linked '(L/h)' as 'CL' → Q22 (CL) for talazoparib — compound marker removed</li><li>unit_dimension_unknown: 'Fixed' (equation variable)</li><li>dropped unlinked row (NIL): 'BCCL effect on' — extend the ontology if this is a real PK parameter (source ['Hadigol_2026_table_3:row8:col1'])</li><li>dropped value-less row: 'CLe/Fe, enzalutamide apparent clearance'</li><li>dropped value-less row: 'CLn, N‐desmethyl enzalutamide clearance'</li><li>dropped value-less row: 'Fmet, fraction of enzalutamide converted to N‐desmethyl metabolite'</li><li>dropped value-less row: 'kae, enzalutamide first‐order absorption rate constant'</li><li>dropped value-less row: 'Qe/Fe, enzalutamide apparent inter‐compartmental clearance'</li><li>dropped value-less row: 'Qn, N‐desmethyl enzalutamide inter‐compartmental clearance'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Talazoparib_Hadigol2026_reference;
