function p = Oxitriptan_Guan2020_PD_cortisol_params()
% Oxitriptan_Guan2020_PD_cortisol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxitriptan Guan_2020::cortisol: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response cortisol in ng/mL. Driver: 5-HTP (not_resolved).
p.E0 = 8.859999999999999e-05;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.072;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
