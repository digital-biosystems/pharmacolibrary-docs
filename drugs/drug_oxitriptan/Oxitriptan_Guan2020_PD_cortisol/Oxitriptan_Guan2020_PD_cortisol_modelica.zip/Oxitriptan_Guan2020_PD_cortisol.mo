model Oxitriptan_Guan2020_PD_cortisol
  "linear exposure-response sweep — Guan_2020 :: cortisol (serum cortisol)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 8.86e-05,      // [kg/m3; ng/mL × 1e-06]
    slope = 7.2e-08,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // slope_unit_assumed: slope unit '(none)' read as ng/mL per exposure unit
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxitriptan</h4><p>Oxitriptan (5-HTP) is an antidepressant used for major depressive disorder. It is approved and also sold as a nutraceutical, with some investigational uses, though it has been withdrawn in some settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238544\">Wikidata Q238544</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxitriptan_Guan2020_PD_cortisol</h4><p>The steady-state exposure-response curve of Guan Z et al., <i>Pharmacology research &amp; perspectives 8(2):e00574</i> 2020 (<a href=\"https://doi.org/10.1002/prp2.574\">doi:10.1002/prp2.574</a>) — serum cortisol [ng/mL] against 5-HTP — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       88.6 ng/mL    drug-free response (baseline) (Baseline, Q324)
  slope =      0.072          change in response per unit of exposure (S 0, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of 5-HTP per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8.86e-05   (drug-free)</pre></body></html>"));
end Oxitriptan_Guan2020_PD_cortisol;
