// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model MicrocystinLr_Yokoyama2003_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {421745.89014351607},
    MM = 0.995189,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>microcystin_lr</td></tr><tr><td>population:</td><td>freshwater bivalves (Unio douglasiae)</td></tr><tr><td>source_paper:</td><td>Yokoyama_2003</td></tr><tr><td>measured_compound:</td><td>Microcystin-LR</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Microcystin-LR 995.189 g/mol (pubchem); microcystin_lr 995.189 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'microg g(-1) dry weight' (Ct)</li><li>unit_dimension_mismatch: 'concentrations of MCYST-LR on day 5 at 25 degrees C' → Q75 (unit 'dimensionless' vs ontology '[mass] / [length] ** 3') — route to review</li><li>dropped duplicate Q75 ('concentrations of MCYST-LR on day 5 at 25 degrees C', value 250) — already have one for this compound</li><li>dropped duplicate Q47 ('depuration rate constant (k(d)) at 25 degrees C', value 0.226) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Microcystin-LR</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q75 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 4838.4));
end MicrocystinLr_Yokoyama2003_reference;
