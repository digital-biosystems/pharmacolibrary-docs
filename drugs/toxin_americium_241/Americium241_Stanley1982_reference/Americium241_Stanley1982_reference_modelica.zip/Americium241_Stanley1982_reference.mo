// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Americium241_Stanley1982_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {132019200.00000001},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>americium_241</td></tr><tr><td>population:</td><td>Fischer-344 rats, Beagle dogs, and Cynomolgus and Rhesus monkeys</td></tr><tr><td>source_paper:</td><td>Stanley_1982</td></tr><tr><td>measured_compound:</td><td>Americium-241</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>americium_241 241.057 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Lung' — extend the ontology if this is a real PK parameter (source ['Stanley_1982_table_1:row2:col5'])</li><li>salvaged Q57 ('halftimes'=1528) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Americium-241</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: halftimes printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 1/1 row label(s) assigned, 0 linked by role</li><li>molar mass: no plausible PubChem entry for 'Plutonium-241' ('Plutonium-241') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'Americium-241' ('Americium-241') — left in mass units</li><li>molar mass: none found for 'Plutonium-241' — its concentrations stay mass-only</li><li>molar mass: none found for 'Americium-241' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Americium241_Stanley1982_reference;
