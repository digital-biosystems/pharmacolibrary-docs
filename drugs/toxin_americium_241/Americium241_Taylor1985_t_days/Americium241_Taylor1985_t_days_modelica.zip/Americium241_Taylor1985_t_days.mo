// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Americium241_Taylor1985_t_days
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1080000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>americium_241</td></tr><tr><td>population:</td><td>Male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Taylor_1985</td></tr><tr><td>measured_compound:</td><td>Americium-241</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Fig. 1c</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>americium_241 241.057 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '⁶⁷Ga' — extend the ontology if this is a real PK parameter (source ['Taylor_1985_table_2:row0:col4'])</li><li>dropped unlinked row (NIL): '¹⁸¹+¹⁸¹Hf' — extend the ontology if this is a real PK parameter (source ['Taylor_1985_table_2:row1:col4'])</li><li>dropped unlinked row (NIL): '²³⁴Th' — extend the ontology if this is a real PK parameter (source ['Taylor_1985_table_2:row2:col4'])</li><li>dropped unlinked row (NIL): '²³⁹Pu' — extend the ontology if this is a real PK parameter (source ['Taylor_1985_table_2:row3:col4'])</li><li>dropped unlinked row (NIL): '²⁰³Hg' — extend the ontology if this is a real PK parameter (source ['Taylor_1985_table_2:row5:col4'])</li><li>table mostly unlinked (5/6 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q57 ('mean half-time of retention of these metals, in control muscle'=12.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Americium-241</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'tᵇ
(days)' subgroup of Taylor_1985 (paper reports 2 populations: a
% dose g⁻¹, tᵇ
(days))</li><li>molar mass: no plausible PubChem entry for 'Americium-241' ('Americium-241') — left in mass units</li><li>molar mass: none found for 'Americium-241' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 10886.4));
end Americium241_Taylor1985_t_days;
