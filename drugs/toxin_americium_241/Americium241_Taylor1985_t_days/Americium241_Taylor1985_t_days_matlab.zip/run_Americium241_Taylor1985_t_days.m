% Run: build params, simulate 0..1512.0 h, plot every molecule + save Americium241_Taylor1985_t_days.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Americium241_Taylor1985_t_days.m
here = fileparts(mfilename('fullpath'));
p = Americium241_Taylor1985_t_days_params();
out = simulate_network(p, 0:0.05:1512.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('americium_241 — Taylor_1985 (retention function)');
print(fig, fullfile(here, 'Americium241_Taylor1985_t_days.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Americium241_Taylor1985_t_days.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Americium241_Taylor1985_t_days.json'), 'w');
try
  s.model = 'Americium241_Taylor1985_t_days'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Americium241_Taylor1985_t_days"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Americium241_Taylor1985_t_days.png, Americium241_Taylor1985_t_days.csv, Americium241_Taylor1985_t_days.json\n');
