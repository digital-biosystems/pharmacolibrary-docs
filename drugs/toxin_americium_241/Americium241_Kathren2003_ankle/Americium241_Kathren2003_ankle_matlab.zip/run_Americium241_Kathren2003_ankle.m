% Run: build params, simulate 0..4320.0 h, plot every molecule + save Americium241_Kathren2003_ankle.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Americium241_Kathren2003_ankle.m
here = fileparts(mfilename('fullpath'));
p = Americium241_Kathren2003_ankle_params();
out = simulate_network(p, 0:0.05:4320.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('americium_241 — Kathren_2003 (retention function)');
print(fig, fullfile(here, 'Americium241_Kathren2003_ankle.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Americium241_Kathren2003_ankle.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Americium241_Kathren2003_ankle.json'), 'w');
try
  s.model = 'Americium241_Kathren2003_ankle'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Americium241_Kathren2003_ankle"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Americium241_Kathren2003_ankle.png, Americium241_Kathren2003_ankle.csv, Americium241_Kathren2003_ankle.json\n');
