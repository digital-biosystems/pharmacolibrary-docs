#!/usr/bin/env python3
"""Simulate Americium241_Kathren2003_ankle.sbml (0..4320.0 h) — a toxin retention function — with Tellurium/
libRoadRunner; writes Americium241_Kathren2003_ankle.csv, Americium241_Kathren2003_ankle.json and Americium241_Kathren2003_ankle.png next to this script."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Americium241_Kathren2003_ankle")
OUT = {'burden': 'whole-body burden (mg)'}                        # output -> molecule
r = te.loadSBMLModel(BASE + ".sbml")
r.integrator.relative_tolerance = 1e-8
r.integrator.absolute_tolerance = 1e-12
res = r.simulate(0, 4320.0, 2001, ["time"] + list(OUT))
t = [float(x) for x in res[:, 0]]
cols = {o: [float(x) for x in res[:, i + 1]] for i, o in enumerate(OUT)}

with open(BASE + ".csv", "w") as f:
    f.write("time_h," + ",".join(o + "_mg" for o in OUT) + "\n")
    for k, ti in enumerate(t):
        f.write("%r," % ti + ",".join("%r" % cols[o][k] for o in OUT) + "\n")
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Americium241_Kathren2003_ankle", "stop_time_h": 4320.0, "labels": OUT, "time_h": t,
               **{o + "_mg": cols[o] for o in OUT}}, f, indent=2)

plt.figure()
for o in OUT:
    plt.semilogy(t, [max(c, 1e-12) for c in cols[o]], linewidth=1.5, label=f"{OUT[o]} ({o})")
plt.xlabel("time [h]"); plt.ylabel("body burden [mg]"); plt.legend()
plt.title("Americium241_Kathren2003_ankle"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
