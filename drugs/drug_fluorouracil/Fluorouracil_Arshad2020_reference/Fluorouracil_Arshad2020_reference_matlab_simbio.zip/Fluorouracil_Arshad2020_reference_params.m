function p = Fluorouracil_Arshad2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Arshad_2020 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Fluorouracil_Arshad2020_reference_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 902.0;                % central volume [L]
  p.CL = 37.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.757;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.000552;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
