function p = Fluorouracil_Kobuchi2013_PD_tv_params()
% Fluorouracil_Kobuchi2013_PD_tv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Kobuchi_2013::TV: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response TV in mm3. Driver: 5-fluorouracil (pk_record).
p.E0 = 3.7;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1728000.0000000002;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
