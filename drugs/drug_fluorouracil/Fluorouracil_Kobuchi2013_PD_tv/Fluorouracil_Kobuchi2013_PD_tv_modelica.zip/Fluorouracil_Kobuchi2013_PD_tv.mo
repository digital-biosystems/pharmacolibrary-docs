model Fluorouracil_Kobuchi2013_PD_tv
  "linear exposure-response sweep — Kobuchi_2013 :: TV (Tumor volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 3.7,      // [mm3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 1728000   "[meter ** 3 * second / kilogram; mL µg-1 day-1 × 8.64e+07]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluorouracil_Kobuchi2013_PD_tv</h4><p>The steady-state exposure-response curve of Kobuchi S et al., <i>Journal of pharmaceutical sciences 102(6):2056–2067</i> 2013 (<a href=\"https://doi.org/10.1002/jps.23547\">doi:10.1002/jps.23547</a>) — Tumor volume [mm3] against 5-fluorouracil µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        3.7 mm3      drug-free response (baseline) (v0, Q324)
  slope =       0.02 mL µg-1 day-1 change in response per unit of exposure (k2, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/mL of 5-fluorouracil per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.7   (drug-free)</pre></body></html>"));
end Fluorouracil_Kobuchi2013_PD_tv;
