function p = Fluorouracil_Kobuchi2014_PD_hb_params()
% Fluorouracil_Kobuchi2014_PD_hb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Kobuchi_2014::Hb: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg•mL⁻¹ per second, in SI inside (kg/m3, s). Response Hb in g•dL⁻¹. Driver: 5-FU (not_resolved).
p.E0 = 15.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.8;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
