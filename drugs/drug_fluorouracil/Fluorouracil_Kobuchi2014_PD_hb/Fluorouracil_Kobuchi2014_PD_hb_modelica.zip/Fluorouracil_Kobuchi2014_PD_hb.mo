model Fluorouracil_Kobuchi2014_PD_hb
  "linear exposure-response sweep — Kobuchi_2014 :: Hb (hemoglobin (Hb) concentrations)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 15,      // [g•dL -1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 2.8   "[mL•μg -1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  // off_target_driver: driver compound '5-FU' is not 'fluorouracil' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluorouracil_Kobuchi2014_PD_hb</h4><p>The steady-state exposure-response curve of Kobuchi S et al., <i>Journal of pharmacological and toxicological methods 70(2):134–144</i> 2014 (<a href=\"https://doi.org/10.1016/j.vascn.2014.07.007\">doi:10.1016/j.vascn.2014.07.007</a>) — hemoglobin (Hb) concentrations [g•dL⁻¹] against 5-FU μg•mL⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         15 g•dL -1  drug-free response (baseline) (Circ 0, Q324)
  slope =        2.8 mL•μg -1 change in response per unit of exposure (k slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg•mL⁻¹ of 5-FU per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 15   (drug-free)</pre></body></html>"));
end Fluorouracil_Kobuchi2014_PD_hb;
