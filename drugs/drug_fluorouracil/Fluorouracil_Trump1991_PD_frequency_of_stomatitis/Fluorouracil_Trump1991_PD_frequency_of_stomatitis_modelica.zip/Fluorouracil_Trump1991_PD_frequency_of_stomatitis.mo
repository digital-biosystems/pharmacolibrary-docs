model Fluorouracil_Trump1991_PD_frequency_of_stomatitis
  "sigmoid_emax exposure-response sweep — Trump_1991 :: frequency of stomatitis (percentage frequency of stomatitis)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 100,  // [1]
    EC50 = 0.00559,  // [mol/m3; umol/L × 0.001]
    gamma = 2.58,
    exposure_per_s = 0.001);   // 1 umol/L per second
  // off_target_driver: driver compound '5FUra' is not 'fluorouracil' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 56, Interval = 0.112),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluorouracil_Trump1991_PD_frequency_of_stomatitis</h4><p>The steady-state exposure-response curve of Trump DL et al., <i>Journal of clinical oncology : official journal of the American Society of Clinical Oncology 9(11):2027–2035</i> 1991 (<a href=\"https://doi.org/10.1200/JCO.1991.9.11.2027\">doi:10.1200/JCO.1991.9.11.2027</a>) — percentage frequency of stomatitis against 5FUra umol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100          maximal effect term (maximum effect, Q320)
  EC50  =       5.59 umol/L   exposure at half of the maximal effect term (Css 50, Q321)
  gamma =       2.58          Hill coefficient (Hill's constant, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one umol/L of 5FUra per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.59 umol/L)  response 50
  exposure -> infinity  response 100</pre></body></html>"));
end Fluorouracil_Trump1991_PD_frequency_of_stomatitis;
