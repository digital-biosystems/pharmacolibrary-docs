function p = Fluorouracil_Daryani2016_PD_bioluminescence_params()
% Fluorouracil_Daryani2016_PD_bioluminescence_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Daryani_2016::bioluminescence: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response bioluminescence in its own unit. Driver: 5-FU (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.00018277777777777777;
p.EC50 = 2.12;
p.gamma = 1.22;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 22.0;
p.form = 'E0 + Emax*frac';
end
