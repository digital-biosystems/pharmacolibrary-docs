model Fluorouracil_Daryani2016_PD_bioluminescence
  "sigmoid_emax exposure-response sweep — Daryani_2016 :: bioluminescence (tumor growth)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000182777777778,  // [1/s; 1/hr × 0.000277778]
    EC50 = 2.12,  // [μM]
    gamma = 1.22,
    exposure_per_s = 1);   // 1 μM per second
  // off_target_driver: driver compound '5-FU' is not 'fluorouracil' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 22, Interval = 0.044),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluorouracil_Daryani2016_PD_bioluminescence</h4><p>The steady-state exposure-response curve of Daryani VM et al., <i>CPT: pharmacometrics &amp; systems pharmacology 5(4):211–221</i> 2016 (<a href=\"https://doi.org/10.1002/psp4.12075\">doi:10.1002/psp4.12075</a>) — tumor growth against 5-FU μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.658 1/hr     maximal effect term (Maximum 5‐FU tumor inhibitory effect (Kmax,m), Q323)
  EC50  =       2.12 μM       exposure at half of the maximal effect term (5‐FU tECF concentration producing half the maximum tumor inhibitory effect (IC50,m), Q322)
  gamma =       1.22          Hill coefficient (Hill coefficient (Hm), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of 5-FU per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.12 μM)  response -9.139e-05
  exposure -> infinity  response -0.0001828</pre></body></html>"));
end Fluorouracil_Daryani2016_PD_bioluminescence;
