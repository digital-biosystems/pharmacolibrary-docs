model Fluorouracil_Pierik2024_PD_v
  "sigmoid_emax exposure-response sweep — Pierik_2024 :: V (tumor volume)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1,      // [1]
    Emax = -1,  // [1]
    EC50 = 20,  // [1]
    gamma = 10,
    exposure_per_s = 1);   // 1 unit per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 200, Interval = 0.4),
    Documentation(info = "<html><body><h4>Fluorouracil_Pierik2024_PD_v</h4><p>The steady-state exposure-response curve of Pierik L et al., <i>Bulletin of mathematical biology 86(5):47</i> 2024 (<a href=\"https://doi.org/10.1007/s11538-024-01278-0\">doi:10.1007/s11538-024-01278-0</a>) — tumor volume against 5-fluorouracil — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          1          drug-free response (baseline) (E0, Q324)
  Emax  =         -1          maximal effect term (E1, Q323)
  EC50  =         20          exposure at half of the maximal effect term (C, Q321)
  gamma =         10          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of 5-fluorouracil per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)
  exposure = EC50 (20 )  response 0.5
  exposure -> infinity  response 0</pre></body></html>"));
end Fluorouracil_Pierik2024_PD_v;
