function p = Fluorouracil_Kang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Kang_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Fluorouracil_Kang2025_reference_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 902.0;                % central volume [L]
  p.CL = 37.9;                % clearance [L/h]
  p.Vp = [519.0];             % peripheral volumes [L]
  p.Q  = [132.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.59;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
