function p = Fluorouracil_Kobuchi2013_day_3_07_00_h_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Kobuchi_2013 / day_3_07_00_h   route: oral
  % estimated (absent from source): F
  p.name  = 'Fluorouracil_Kobuchi2013_day_3_07_00_h_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.5;                % central volume [L]
  p.CL = 24.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.757;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1400.0;             % dose [mg]
end
