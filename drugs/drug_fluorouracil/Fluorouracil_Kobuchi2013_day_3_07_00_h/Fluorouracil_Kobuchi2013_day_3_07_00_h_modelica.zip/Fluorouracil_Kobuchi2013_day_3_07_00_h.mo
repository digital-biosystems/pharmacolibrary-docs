model Fluorouracil_Kobuchi2013_day_3_07_00_h
  parameter Real Cl_ref = 6.805555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0245 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1300772,
    adminMass = 0.0014,
    ka = 0.0002102777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorouracil</td></tr><tr><td>population:</td><td>rats with colorectal cancer</td></tr><tr><td>source_paper:</td><td>Kobuchi_2013</td></tr><tr><td>measured_compound:</td><td>5-fluorouracil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5-fluorouracil 130.077 g/mol (drugbank); fluorouracil 130.077 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'UH2/Ura' — extend the ontology if this is a real PK parameter (source ['Kobuchi_2013_table_1:row0:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=5-fluorouracil</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1 (L·kg−1)' is the general volume)</li><li>population split: 'day 3 07:00 h' subgroup of Kobuchi_2013 (paper reports 13 populations: 07:00 h, 13:00 h, 19:00 h, control, day 1 07:00 h, day 1 13:00 h, day 1 19:00 h, day 3 07:00 h, day 3 13:00 h, day 3 19:00 h, day 7 07:00 h, day 7 13:00 h, day 7 19:00 h)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Bae_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fluorouracil_Kobuchi2013_day_3_07_00_h;
