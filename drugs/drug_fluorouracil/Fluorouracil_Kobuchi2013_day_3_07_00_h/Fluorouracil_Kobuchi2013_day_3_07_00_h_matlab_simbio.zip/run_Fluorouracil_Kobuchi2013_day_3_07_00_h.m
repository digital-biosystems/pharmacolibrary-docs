% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Fluorouracil_Kobuchi2013_day_3_07_00_h_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
