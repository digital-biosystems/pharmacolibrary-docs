model Fluorouracil_Arshad2020_PD_wbc
  "linear exposure-response sweep — Arshad_2020 :: WBC (total WBC count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 6.86,      // [× 109/L]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 1170   "[meter ** 3 / kilogram; L/mg × 1000]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  // off_target_driver: driver compound '5FU' is not 'fluorouracil' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluorouracil_Arshad2020_PD_wbc</h4><p>The steady-state exposure-response curve of Arshad U et al., <i>Cancer chemotherapy and pharmacology 85(4):711–722</i> 2020 (<a href=\"https://doi.org/10.1007/s00280-019-04028-5\">doi:10.1007/s00280-019-04028-5</a>) — total WBC count [× 109/L] against 5FU mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.86 × 109/L  drug-free response (baseline) (CIRC0, Q324)
  slope =       1.17 L/mg     change in response per unit of exposure (Slopemono, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/L of 5FU per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.86   (drug-free)</pre></body></html>"));
end Fluorouracil_Arshad2020_PD_wbc;
