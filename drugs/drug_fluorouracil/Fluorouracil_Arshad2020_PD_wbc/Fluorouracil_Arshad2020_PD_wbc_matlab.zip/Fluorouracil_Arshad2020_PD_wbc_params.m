function p = Fluorouracil_Arshad2020_PD_wbc_params()
% Fluorouracil_Arshad2020_PD_wbc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Arshad_2020::WBC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response WBC in × 109/L. Driver: 5FU (conc_no_pk).
p.E0 = 6.86;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1170.0000000000002;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
