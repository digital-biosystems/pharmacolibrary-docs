model Fluorouracil_Kobuchi2017_PD_bw
  "indirect_response_i exposure-response sweep — Kobuchi_2017 :: BW (body weight)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1,      // [1; % × 0.01]
    Emax = 1,  // type I effect term
    EC50 = 8.6,  // [kg/m3; mg/mL × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 86, Interval = 0.172),
    Documentation(info = "<html><body><h4>Fluorouracil_Kobuchi2017_PD_bw</h4><p>The steady-state exposure-response curve of Kobuchi S et al., <i>European journal of drug metabolism and pharmacokinetics 42(4):707–718</i> 2017 (<a href=\"https://doi.org/10.1007/s13318-016-0389-3\">doi:10.1007/s13318-016-0389-3</a>) — body weight [%] against 5-fluorouracil mg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        100 %        drug-free response (baseline) (BW 0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =        8.6 mg/mL    exposure at half of the maximal effect term (EC 50,placebo, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/mL of 5-fluorouracil per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)
  exposure = EC50 (8.6 mg/mL)  response 0.5
  exposure -> infinity  response 0</pre></body></html>"));
end Fluorouracil_Kobuchi2017_PD_bw;
