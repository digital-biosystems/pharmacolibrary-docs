function p = Fluorouracil_Trump1991_PD_frequency_of_stomatitis_2_params()
% Fluorouracil_Trump1991_PD_frequency_of_stomatitis_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Trump_1991::frequency_of_stomatitis::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one umol/L per second, in SI inside (kg/m3, s). Response frequency of stomatitis in its own unit. Driver: 5FUra (conc_no_pk).
p.E0 = 0.0;
p.Emax = 100.0;
p.EC50 = 0.0026099999999999995;
p.gamma = 0.95;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 27.0;
p.form = 'E0 + Emax*frac';
end
