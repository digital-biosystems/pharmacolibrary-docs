function p = Fluorouracil_Kobuchi2014_PD_hct_params()
% Fluorouracil_Kobuchi2014_PD_hct_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Kobuchi_2014::Hct: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg•mL⁻¹ per second, in SI inside (kg/m3, s). Response Hct in %. Driver: 5-FU (not_resolved).
p.E0 = 0.45299999999999996;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.79;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
