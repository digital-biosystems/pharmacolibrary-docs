function p = Fluorouracil_Bae2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Bae_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fluorouracil_Bae2026_reference_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.89;                % central volume [L]
  p.CL = 2.17;                % clearance [L/h]
  p.Vp = [1652.0];             % peripheral volumes [L]
  p.Q  = [108.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.757;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
