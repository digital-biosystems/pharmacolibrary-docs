model HexavalentChromium_Park2004_PD_lung_cancer_death
  "linear exposure-response sweep — Park_2004 :: lung cancer death (lung cancer death)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 2.44   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>HexavalentChromium_Park2004_PD_lung_cancer_death</h4><p>The steady-state exposure-response curve of Park RM et al., <i>Risk analysis : an official publication of the Society for Risk Analysis 24(5):1099–1108</i> 2004 (<a href=\"https://doi.org/10.1111/j.0272-4332.2004.00512.x\">doi:10.1111/j.0272-4332.2004.00512.x</a>) — lung cancer death against hexavalent chromium mg/m3-yr — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       2.44          change in response per unit of exposure (rate ratio, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/m3-yr of hexavalent chromium per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end HexavalentChromium_Park2004_PD_lung_cancer_death;
