function p = HexavalentChromium_Park2004_PD_lung_cancer_death_params()
% HexavalentChromium_Park2004_PD_lung_cancer_death_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hexavalent_chromium Park_2004::lung_cancer_death: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/m3-yr per second, in SI inside (kg/m3, s). Response lung cancer death in its own unit. Driver: hexavalent chromium (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.44;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
