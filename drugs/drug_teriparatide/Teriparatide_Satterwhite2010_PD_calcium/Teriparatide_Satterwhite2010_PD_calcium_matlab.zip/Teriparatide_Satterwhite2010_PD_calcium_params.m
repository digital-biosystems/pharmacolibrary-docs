function p = Teriparatide_Satterwhite2010_PD_calcium_params()
% Teriparatide_Satterwhite2010_PD_calcium_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% teriparatide Satterwhite_2010::Calcium: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/ml per second, in SI inside (kg/m3, s). Response Calcium in mg/dl. Driver: teriparatide (conc_no_pk).
p.E0 = 0.09199999999999998;
p.Emax = 19.5;
p.EC50 = 5.4e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 540.0;
p.form = 'E0*(1 + Emax*frac)';
end
