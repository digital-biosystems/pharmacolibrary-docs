model Teriparatide_Satterwhite2010_PD_calcium
  "indirect_response_iii exposure-response sweep — Satterwhite_2010 :: Calcium (serum calcium)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.092,      // [kg/m3; mg/dl × 0.01]
    Emax = 19.5,  // type III effect term
    EC50 = 5.4e-08,  // [kg/m3; pg/ml × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg/ml per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 540, Interval = 1.08),
    Documentation(info = "<html><body><!-- drug-about --><h4>About teriparatide</h4><p>Teriparatide, a parathyroid hormone analogue, is used to treat osteoporosis, including postmenopausal osteoporosis, and other bone diseases. It is an approved medicine with several authorised products in the European Union, mainly for osteoporosis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411781\">Wikidata Q411781</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Teriparatide_Satterwhite2010_PD_calcium</h4><p>The steady-state exposure-response curve of Satterwhite J et al., <i>Calcified tissue international 87(6):485–492</i> 2010 (<a href=\"https://doi.org/10.1007/s00223-010-9424-6\">doi:10.1007/s00223-010-9424-6</a>) — serum calcium [mg/dl] against teriparatide pg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        9.2 mg/dl    drug-free response (baseline) (baseline serum calcium, Q324)
  Emax  =       19.5          maximal effect term (E max, Q320)
  EC50  =         54 pg/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one pg/ml of teriparatide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.092   (drug-free)
  exposure = EC50 (54 pg/ml)  response 0.989
  exposure -> infinity  response 1.886</pre></body></html>"));
end Teriparatide_Satterwhite2010_PD_calcium;
