model Vancomycin_Gao2026_basic_model_estimate_rse_estimate_rse_med
  parameter Real Cl_ref = 9.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.002,
    k12 = 0.00017294685990338168,
    k21 = 3.689960832817976e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>Adult cancer patients</td></tr><tr><td>source_paper:</td><td>Gao_2026</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>table representations disagree for 'V2 (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vancomycin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'basic model / estimate rse% estimate rse% median' subgroup of Gao_2026 (paper reports 2 populations: basic model / estimate rse% estimate rse% median, final model / estimate rse% estimate rse% median)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Gao2026_basic_model_estimate_rse_estimate_rse_med;
