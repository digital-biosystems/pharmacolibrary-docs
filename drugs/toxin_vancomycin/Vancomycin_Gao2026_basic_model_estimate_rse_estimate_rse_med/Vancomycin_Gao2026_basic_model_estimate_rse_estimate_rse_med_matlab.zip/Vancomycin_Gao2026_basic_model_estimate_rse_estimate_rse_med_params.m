function p = Vancomycin_Gao2026_basic_model_estimate_rse_estimate_rse_med_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Gao_2026 / basic_model_estimate_rse_estimate_rse_median   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Vancomycin_Gao2026_basic_model_estimate_rse_estimate_rse_med_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.5;                % central volume [L]
  p.CL = 3.37;                % clearance [L/h]
  p.Vp = [53.9];             % peripheral volumes [L]
  p.Q  = [7.16];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
