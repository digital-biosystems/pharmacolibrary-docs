model Vancomycin_Olivo2025_PD_cfu
  "sigmoid_emax exposure-response sweep — Olivo_2025 :: CFU (MRSA bacterial cell death)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.69444444444e-05,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00105,  // [kg/m3; mg/L × 0.001]
    gamma = 5.74,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is transduction; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><h4>Vancomycin_Olivo2025_PD_cfu</h4><p>The steady-state exposure-response curve of Olivo LB et al., <i>Pharmaceutics 17(9)</i> 2025 (<a href=\"https://doi.org/10.3390/pharmaceutics17091111\">doi:10.3390/pharmaceutics17091111</a>) — MRSA bacterial cell death [Log CFU/mL] against Vancomycin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.061 h−1      maximal effect term (Maximum effect, Q320)
  EC50  =       1.05 mg/L     exposure at half of the maximal effect term (EC50 in absence of AR, Q321)
  gamma =       5.74          Hill coefficient (Hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of Vancomycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.05 mg/L)  response 8.472e-06
  exposure -> infinity  response 1.694e-05</pre></body></html>"));
end Vancomycin_Olivo2025_PD_cfu;
