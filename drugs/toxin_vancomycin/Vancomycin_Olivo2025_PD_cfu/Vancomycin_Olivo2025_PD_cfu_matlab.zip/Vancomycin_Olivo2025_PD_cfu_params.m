function p = Vancomycin_Olivo2025_PD_cfu_params()
% Vancomycin_Olivo2025_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vancomycin Olivo_2025::CFU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response CFU in Log CFU/mL. Driver: Vancomycin (pk_record).
p.E0 = 0.0;
p.Emax = 1.6944444444444446e-05;
p.EC50 = 0.00105;
p.gamma = 5.74;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
