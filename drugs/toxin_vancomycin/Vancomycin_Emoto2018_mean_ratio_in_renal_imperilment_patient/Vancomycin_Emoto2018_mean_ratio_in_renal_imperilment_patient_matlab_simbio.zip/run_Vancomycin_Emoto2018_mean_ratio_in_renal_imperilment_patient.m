% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Vancomycin_Emoto2018_mean_ratio_in_renal_imperilment_patient_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
