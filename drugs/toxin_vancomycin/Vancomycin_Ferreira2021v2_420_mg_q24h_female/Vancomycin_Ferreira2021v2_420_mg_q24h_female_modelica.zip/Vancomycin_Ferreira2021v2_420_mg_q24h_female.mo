model Vancomycin_Ferreira2021v2_420_mg_q24h_female
  parameter Real Cl_ref = 8.944444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0011899999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>inpatients with severe systemic infections</td></tr><tr><td>source_paper:</td><td>Ferreira_2021_2</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>life-11-01130-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'Fa (%) 1' → Q40: printed without a unit and above 1 — read as a percentage</li><li>'FDp (%) 2' → Q45: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q32 ('Cmax liver (mg/L) 8', value '104.770') — already have one for this compound</li><li>implicit units: 'AUC0-inf (µg∙h/mL) 6' → µg∙h/mL (from the paper text: &quot;The parameter label itself includes the unit in parentheses: 'AUC0-inf (µg∙h/mL)'. This is the explicit unit provided by&quot;)</li><li>implicit units: 'AUC0-t (µg∙h/mL) 7' → µg∙h/mL (from the paper text: &quot;The parameter label itself includes the unit in parentheses: 'AUC0-t (µg∙h/mL)'. This is the explicit unit provided by t&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vancomycin</li><li>population split: '420 mg q24h female' subgroup of Ferreira_2021_2 (paper reports 15 populations: 1000 mg q12h, 1000 mg q12h female, 1000 mg q24h, 120 mg q8h, 200 mg q24h, 200 mg q24h female, 250 mg q24h, 400 mg q24h, 420 mg q24h, 420 mg q24h female, 500 mg q12h, 500 mg q24h, 70 mg q12h, 800 mg q24h, 800 mg q24h female)</li><li>gap-filled Q22 (CL) from Ding_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Albanell-Fernández_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Albanell-Fernández_2025, Ding_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Ferreira2021v2_420_mg_q24h_female;
