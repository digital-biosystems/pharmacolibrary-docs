model Vancomycin_Shi2026_reference
  parameter Real Cl_ref = 1.8694444444444447e-06 "Cl [m3/s]";
  parameter Real cov_crcl_0 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.049100000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.708)*cov_crcl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>adult burn patients</td></tr><tr><td>source_paper:</td><td>Shi_2026</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV_CL [%CV]' routed out of structural estimates ('Between-subject variability (BSV)')</li><li>table section iiv: 'BSV_V [%CV]' routed out of structural estimates ('Between-subject variability (BSV)')</li><li>table section residual_error: 'Proportional error [%CV]' routed out of structural estimates ('Residual variability (RV)')</li><li>covariate level 'CrCL on CL' → Q900:crcl_on_cl = 0.708 (linear_fractional on Q22)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vancomycin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Shi2026_reference;
