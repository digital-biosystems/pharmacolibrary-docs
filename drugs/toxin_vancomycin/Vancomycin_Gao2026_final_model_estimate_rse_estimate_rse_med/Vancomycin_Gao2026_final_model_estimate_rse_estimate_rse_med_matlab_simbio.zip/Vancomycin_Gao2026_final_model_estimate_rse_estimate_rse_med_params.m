function p = Vancomycin_Gao2026_final_model_estimate_rse_estimate_rse_med_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Gao_2026 / final_model_estimate_rse_estimate_rse_median   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Vancomycin_Gao2026_final_model_estimate_rse_estimate_rse_med_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.6;                % central volume [L]
  p.CL = 9.12;                % clearance [L/h]
  p.Vp = [49.5];             % peripheral volumes [L]
  p.Q  = [7.46];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
