model Vancomycin_Ferreira2021v2_reference
  parameter Real Cl_ref = 3.597777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0011899999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>inpatients with severe systemic infections</td></tr><tr><td>source_paper:</td><td>Ferreira_2021_2</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>life-11-01130-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'Fa (%) 1' → Q40: printed without a unit and above 1 — read as a percentage</li><li>'FDp (%) 2' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q32 ('Cmax liver (mg/L) 8', value '129.520') — already have one for this compound</li><li>dropped duplicate Q22 ('800 mg q24h CL min (1.401 L/h)', value '147.360') — already have one for this compound</li><li>dropped duplicate Q22 ('800 mg q24h CL max (11.298 L/h)', value '117.190') — already have one for this compound</li><li>dropped duplicate Q22 ('200 mg q24h CL avg (5.941 L/h)', value '31.876') — already have one for this compound</li><li>dropped duplicate Q22 ('200 mg q24h CL min (1.667 L/h)', value '36.212') — already have one for this compound</li><li>dropped duplicate Q22 ('200 mg q24h CL max (15.887 L/h)', value '26.809') — already have one for this compound</li><li>dropped duplicate Q22 ('420 mg q24h CL avg (6.007 L/h)', value '104.740') — already have one for this compound</li><li>dropped duplicate Q22 ('420 mg q24h CL min (3.868 L/h)', value '111.740') — already have one for this compound</li><li>dropped duplicate Q22 ('420 mg q24h CL max (8.771 L/h)', value '98.209') — already have one for this compound</li><li>dropped duplicate Q22 ('1000 mg q12h CL avg (5.787 L/h)', value '61.742') — already have one for this compound</li><li>dropped duplicate Q22 ('1000 mg q12h CL min (0.590 L/h)', value '146.400') — already have one for this compound</li><li>dropped duplicate Q22 ('1000 mg q12h CL max (18.796 L/h)', value '38.136') — already have one for this compound</li><li>implicit units: 'AUC0-inf (µg∙h/mL) 6' → µg∙h/mL (from the paper text: 'AUC0-inf (µg∙h/mL)')</li><li>implicit units: 'AUC0-t (µg∙h/mL) 7' → µg∙h/mL (from the paper text: 'AUC0-t (µg∙h/mL)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Ferreira2021v2_reference;
