function p = Vancomycin_Ferreira2021v2_400_mg_q24h_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Ferreira_2021_2 / 400_mg_q24h   route: iv_bolus
  p.name  = 'Vancomycin_Ferreira2021v2_400_mg_q24h_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.19;                % central volume [L]
  p.CL = 3.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.9996;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
