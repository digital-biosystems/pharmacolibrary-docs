model Vancomycin_Xu2026v2_reference
  parameter Real Cl_ref = 2.1e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0856 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.00105,
    k12 = 2.4208203530633437e-05,
    k21 = 7.2455322455322445e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>children aged 3 months to 18 years receiving intravenous vancomycin</td></tr><tr><td>source_paper:</td><td>Xu_2026_2</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability (CV%) (RSE) [Shrinkage]')</li><li>table section iiv: 'V1' routed out of structural estimates ('Inter-individual variability (CV%) (RSE) [Shrinkage]')</li><li>table section iov: 'CL' routed out of structural estimates ('Inter-occasion variability (CV%) (RSE) [Shrinkage]')</li><li>table representations disagree for 'CLb (L/h/70 kg)'; source reconciliation required</li><li>table representations disagree for 'Effect of creatinine on CL'; source reconciliation required</li><li>table representations disagree for 'Hill'; source reconciliation required</li><li>table representations disagree for 'TM50 (weeks)'; source reconciliation required</li><li>table representations disagree for 'V1c (L/70 kg)'; source reconciliation required</li><li>table representations disagree for 'Qd (L/h/70 kg)'; source reconciliation required</li><li>table representations disagree for 'V2e (L/70 kg)'; source reconciliation required</li><li>table representations disagree for 'Proportional error (%)'; source reconciliation required</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row3:col1'])</li><li>dropped unlinked row (NIL): 'TM50 (weeks)' — extend the ontology if this is a real PK parameter (source ['T2:row4:col1'])</li><li>NIL: refused to back-fill base 'equation variable' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'equation variable' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Xu2026v2_reference;
