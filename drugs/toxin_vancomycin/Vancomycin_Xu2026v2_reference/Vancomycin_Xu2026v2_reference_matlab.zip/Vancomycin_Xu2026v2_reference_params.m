function p = Vancomycin_Xu2026v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Xu_2026_2 / reference   route: iv_bolus
  p.name  = 'Vancomycin_Xu2026v2_reference_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 85.6;                % central volume [L]
  p.CL = 7.56;                % clearance [L/h]
  p.Vp = [286.0];             % peripheral volumes [L]
  p.Q  = [7.46];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.2394;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
