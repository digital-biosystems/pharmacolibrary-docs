% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Vancomycin_Ferreira2021v2_120_mg_q8h_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
