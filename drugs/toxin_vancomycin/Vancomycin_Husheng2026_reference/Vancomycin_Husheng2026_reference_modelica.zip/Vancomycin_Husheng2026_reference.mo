model Vancomycin_Husheng2026_reference
  parameter Real Cl_ref = 8.055555555555555e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0008 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>Critically ill adults</td></tr><tr><td>source_paper:</td><td>Husheng_2026</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL (L/h) / Value'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / CLPOP (L/h)'; source reconciliation required</li><li>table representations disagree for 'V (L) / Value'; source reconciliation required</li><li>table representations disagree for 'VPOP'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / Formula'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / Value'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / CLPOP (L/h)'; source reconciliation required</li><li>table representations disagree for 'V (L) / Value'; source reconciliation required</li><li>table representations disagree for 'VPOP'; source reconciliation required</li><li>table representations disagree for 'V (L) / Formula'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / Value'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / CLPOP (L/h)'; source reconciliation required</li><li>table representations disagree for 'V (L) / Value'; source reconciliation required</li><li>table representations disagree for 'VPOP'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / Value'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / CLPOP (L/h)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Husheng2026_reference;
