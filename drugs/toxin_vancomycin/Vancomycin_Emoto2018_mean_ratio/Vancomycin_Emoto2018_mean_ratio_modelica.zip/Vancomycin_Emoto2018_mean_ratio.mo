model Vancomycin_Emoto2018_mean_ratio
  parameter Real Cl_ref = 8.944444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0011899999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.449265,
    adminMass = 0.00105
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vancomycin</td></tr><tr><td>population:</td><td>healthy adults, renally impaired patients, hepatic impaired patients, and pediatric patients</td></tr><tr><td>source_paper:</td><td>Emoto_2018</td></tr><tr><td>measured_compound:</td><td>Vancomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412279-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vancomycin 1449.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Population' — extend the ontology if this is a real PK parameter (source ['Emoto_2018_table_S5:row15:col1'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['psp412279-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['psp412279-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['psp412279-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'D1' from footnote/prose loose number None (source ['psp412279-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'E' from footnote/prose loose number None (source ['psp412279-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['psp412279-tbl-0001:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vancomycin</li><li>population split: 'mean ratio' subgroup of Emoto_2018 (paper reports 7 populations: healthy, mean ratio, mean ratio in renal imperilment patient, renal imperilment, single dose (0.5 g), single dose (1.0 g), value)</li><li>gap-filled Q22 (CL) from Ding_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Albanell-Fernández_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Albanell-Fernández_2025, Ding_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vancomycin_Emoto2018_mean_ratio;
