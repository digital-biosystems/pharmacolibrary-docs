% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Vancomycin_Emoto2018_single_dose_0_5_g_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
