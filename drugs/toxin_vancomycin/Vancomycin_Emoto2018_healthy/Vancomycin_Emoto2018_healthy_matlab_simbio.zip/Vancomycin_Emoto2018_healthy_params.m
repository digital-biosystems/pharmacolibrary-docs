function p = Vancomycin_Emoto2018_healthy_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vancomycin   source: Emoto_2018 / healthy   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Vancomycin_Emoto2018_healthy_params';
  p.drug  = 'vancomycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.19;                % central volume [L]
  p.CL = 3.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
