model Warfarin_Aoyama2022_PD_inr
  "sigmoid_emax exposure-response sweep — Aoyama_2022 :: INR (PT-INR)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1]
    EC50 = 0.0041,  // [kg/m3; mg/L × 0.001]
    gamma = 1.15,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 41, Interval = 0.082),
    Documentation(info = "<html><body><h4>Warfarin_Aoyama2022_PD_inr</h4><p>The steady-state exposure-response curve of Aoyama T et al., <i>Biological &amp; pharmaceutical bulletin 45(1):136–142</i> 2022 (<a href=\"https://doi.org/10.1248/bpb.b21-00778\">doi:10.1248/bpb.b21-00778</a>) — PT-INR against S-warfarin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (E max, Q323)
  EC50  =        4.1 mg/L     exposure at half of the maximal effect term (EC 50, Q322)
  gamma =       1.15          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of S-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.1 mg/L)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Warfarin_Aoyama2022_PD_inr;
