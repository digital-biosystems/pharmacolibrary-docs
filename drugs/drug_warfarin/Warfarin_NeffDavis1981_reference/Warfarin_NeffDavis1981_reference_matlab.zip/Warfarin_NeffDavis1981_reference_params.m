function p = Warfarin_NeffDavis1981_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: warfarin   source: Neff-Davis_1981 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Warfarin_NeffDavis1981_reference_params';
  p.drug  = 'warfarin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.4;                % central volume [L]
  p.CL = 0.348;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.214;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.29;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
