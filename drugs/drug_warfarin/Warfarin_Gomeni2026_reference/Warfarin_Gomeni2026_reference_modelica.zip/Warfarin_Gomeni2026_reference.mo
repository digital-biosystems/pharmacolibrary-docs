model Warfarin_Gomeni2026_reference
  parameter Real Cl_ref = 3.777777777777779e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00809 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.9444444444444445e-05,
    Tlag = 4644.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gomeni_2026</td></tr><tr><td>measured_compound:</td><td>warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gomeni_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Warfarin_Gomeni2026_reference;
