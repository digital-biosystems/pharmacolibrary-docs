model Warfarin_RodrguezFernndez2024_PD_inr
  "indirect_response_i exposure-response sweep — Rodríguez-Fernández_2024 :: INR (INR)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.78,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00588,  // [kg/m3; mg/L × 0.001]
    gamma = 1.47,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 59, Interval = 0.118),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant medication used to treat conditions such as deep vein thrombosis, pulmonary embolism, and atrial fibrillation. It is usually taken orally, as it is well-absorbed by mouth, but it may also be given intravenously. It is widely used and listed on the World Health Organization essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a>, <a href=\"https://en.wikipedia.org/wiki/Warfarin?oldid=1383243665\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_RodrguezFernndez2024_PD_inr</h4><p>The steady-state exposure-response curve of Rodríguez-Fernández K et al., <i>Biomedicine &amp; pharmacotherapy = Biomedecine &amp; pharmacotherapie 170:115977</i> 2024 (<a href=\"https://doi.org/10.1016/j.biopha.2023.115977\">doi:10.1016/j.biopha.2023.115977</a>) — INR against warfarin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.78          drug-free response (baseline) (Baseline, Q324)
  Emax  = (library default) maximal effect term
  EC50  =       5.88 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma =       1.47          Hill coefficient (gamma, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.78   (drug-free)
  exposure = EC50 (5.88 mg/L)  response 0.89
  exposure -> infinity  response 0</pre></body></html>"));
end Warfarin_RodrguezFernndez2024_PD_inr;
