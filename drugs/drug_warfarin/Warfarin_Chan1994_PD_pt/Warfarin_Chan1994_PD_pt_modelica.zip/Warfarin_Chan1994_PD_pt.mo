model Warfarin_Chan1994_PD_pt
  "indirect_response_i exposure-response sweep — Chan_1994 :: PT (Prothrombin time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 2.6e-06,  // [kg/m3; mg L-1 × 0.001]
    gamma = 0.9,
    exposure_per_s = 0.001);   // 1 mg L-1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 0.026, Interval = 5.2e-05),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant used to prevent and treat blood clots in conditions such as atrial fibrillation, heart valve disease, pulmonary embolism, thrombosis, and heart disease. It is widely used in human medicine and is included on the WHO list of essential medicines, though it also serves as a rodenticide and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Chan1994_PD_pt</h4><p>The steady-state exposure-response curve of Chan E et al., <i>Clinical pharmacology and therapeutics 56(3):286–294</i> 1994 (<a href=\"https://doi.org/10.1038/clpt.1994.139\">doi:10.1038/clpt.1994.139</a>) — Prothrombin time [seconds] against (S)-warfarin; (R)-warfarin mg L-1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =     0.0026 mg L-1   exposure at half of the maximal effect term (Cu50,S, Q322)
  gamma =        0.9          Hill coefficient (gamma, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg L-1 of (S)-warfarin; (R)-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0026 mg L-1)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Warfarin_Chan1994_PD_pt;
