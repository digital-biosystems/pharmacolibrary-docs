% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Warfarin_Lane2012_s_warfarin_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
