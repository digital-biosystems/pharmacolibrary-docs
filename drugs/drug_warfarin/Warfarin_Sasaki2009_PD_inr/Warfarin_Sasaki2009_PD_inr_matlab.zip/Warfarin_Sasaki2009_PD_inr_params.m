function p = Warfarin_Sasaki2009_PD_inr_params()
% Warfarin_Sasaki2009_PD_inr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Sasaki_2009::INR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response INR in its own unit. Driver: S-warfarin (pk_record).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.0046099999999999995;
p.gamma = 0.424;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 47.0;
p.form = 'E0 + Emax*frac';
end
