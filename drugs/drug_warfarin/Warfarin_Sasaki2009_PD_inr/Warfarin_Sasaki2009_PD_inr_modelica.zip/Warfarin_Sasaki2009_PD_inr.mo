model Warfarin_Sasaki2009_PD_inr
  "sigmoid_emax exposure-response sweep — Sasaki_2009 :: INR (international normalized ratio of prothrombin time)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1]
    EC50 = 0.00461,  // [kg/m3; mg/l × 0.001]
    gamma = 0.424,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 47, Interval = 0.094),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant medication used to treat conditions such as deep vein thrombosis, pulmonary embolism, and atrial fibrillation. It is usually taken orally, as it is well-absorbed by mouth, but it may also be given intravenously. It is widely used and listed on the World Health Organization essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a>, <a href=\"https://en.wikipedia.org/wiki/Warfarin?oldid=1383243665\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Sasaki2009_PD_inr</h4><p>The steady-state exposure-response curve of Sasaki T et al., <i>Pharmacogenomics 10(8):1257–1266</i> 2009 (<a href=\"https://doi.org/10.2217/pgs.09.65\">doi:10.2217/pgs.09.65</a>) — international normalized ratio of prothrombin time against S-warfarin mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (E max, Q323)
  EC50  =       4.61 mg/l     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =      0.424          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of S-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.61 mg/l)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Warfarin_Sasaki2009_PD_inr;
