model Warfarin_Sasaki2009_PD_inr
  "sigmoid_emax exposure-response sweep — Sasaki_2009 :: INR (international normalized ratio of prothrombin time)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1]
    EC50 = 0.00461,  // [kg/m3; mg/l × 0.001]
    gamma = 0.424,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 47, Interval = 0.094),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant used to prevent and treat blood clots in conditions such as atrial fibrillation, heart valve disease, pulmonary embolism, thrombosis, and heart disease. It is widely used in human medicine and is included on the WHO list of essential medicines, though it also serves as a rodenticide and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Sasaki2009_PD_inr</h4><p>The steady-state exposure-response curve of Sasaki T et al., <i>Pharmacogenomics 10(8):1257–1266</i> 2009 (<a href=\"https://doi.org/10.2217/pgs.09.65\">doi:10.2217/pgs.09.65</a>) — international normalized ratio of prothrombin time against S-warfarin mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (E max, Q323)
  EC50  =       4.61 mg/l     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =      0.424          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of S-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.61 mg/l)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Warfarin_Sasaki2009_PD_inr;
