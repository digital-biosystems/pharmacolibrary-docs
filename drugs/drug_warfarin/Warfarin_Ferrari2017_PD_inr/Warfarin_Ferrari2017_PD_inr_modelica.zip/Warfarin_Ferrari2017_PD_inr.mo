model Warfarin_Ferrari2017_PD_inr
  "linear exposure-response sweep — Ferrari_2017 :: INR (INR)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 710,  // [1]
    exposure_per_s = 0.001);   // 1 mg/L per second
  // slope_unit_assumed: slope unit '(none)' read as response per mg/L
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant medication used to treat conditions such as deep vein thrombosis, pulmonary embolism, and atrial fibrillation. It is usually taken orally, as it is well-absorbed by mouth, but it may also be given intravenously. It is widely used and listed on the World Health Organization essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a>, <a href=\"https://en.wikipedia.org/wiki/Warfarin?oldid=1383243665\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Ferrari2017_PD_inr</h4><p>The steady-state exposure-response curve of Ferrari M et al., <i>European journal of clinical pharmacology 73(6):699–707</i> 2017 (<a href=\"https://doi.org/10.1007/s00228-017-2248-9\">doi:10.1007/s00228-017-2248-9</a>) — INR against (S)-warfarin and (R)-warfarin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.71          change in response per unit of exposure (m, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/L of (S)-warfarin and (R)-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Warfarin_Ferrari2017_PD_inr;
