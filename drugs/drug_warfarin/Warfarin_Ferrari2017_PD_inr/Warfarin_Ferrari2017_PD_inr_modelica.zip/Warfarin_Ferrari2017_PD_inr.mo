model Warfarin_Ferrari2017_PD_inr
  "linear exposure-response sweep — Ferrari_2017 :: INR (INR)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.71   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Warfarin_Ferrari2017_PD_inr</h4><p>The steady-state exposure-response curve of Ferrari M et al., <i>European journal of clinical pharmacology 73(6):699–707</i> 2017 (<a href=\"https://doi.org/10.1007/s00228-017-2248-9\">doi:10.1007/s00228-017-2248-9</a>) — INR against (S)-warfarin and (R)-warfarin — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.71          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of (S)-warfarin and (R)-warfarin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Warfarin_Ferrari2017_PD_inr;
