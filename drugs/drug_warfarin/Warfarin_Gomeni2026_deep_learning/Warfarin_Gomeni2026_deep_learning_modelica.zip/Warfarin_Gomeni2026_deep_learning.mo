model Warfarin_Gomeni2026_deep_learning
  parameter Real Cl_ref = 3.777777777777779e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00809 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.9444444444444445e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Gomeni_2026</td></tr><tr><td>measured_compound:</td><td>warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70174-tbl-0001</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mg h/L' (AUC)</li><li>salvaged Q22 ('CL (L/h/70 kg)'=0.136) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V (L/70 kg)'=8.09) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('ka (1/h)'=0.214) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=warfarin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'deep learning' subgroup of Gomeni_2026 (paper reports 2 populations: deep learning, one compartment)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Warfarin_Gomeni2026_deep_learning;
