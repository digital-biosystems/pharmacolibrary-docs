function p = Warfarin_Davies2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: warfarin   source: Davies_2010 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Warfarin_Davies2010_reference_params';
  p.drug  = 'warfarin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.497261;                % central volume [L]
  p.CL = 0.145;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
