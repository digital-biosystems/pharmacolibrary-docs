function p = Warfarin_Mungall1985_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: warfarin   source: Mungall_1985 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Warfarin_Mungall1985_reference_params';
  p.drug  = 'warfarin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.3;                % central volume [L]
  p.CL = 0.348;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.958333;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
