model Warfarin_Geng2024_PD_inr
  "indirect_response_i exposure-response sweep — Geng_2024 :: INR (international normalized ratio)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.027,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.27, Interval = 0.00054),
    Documentation(info = "<html><body><h4>Warfarin_Geng2024_PD_inr</h4><p>The steady-state exposure-response curve of Geng K et al., <i>CPT: pharmacometrics &amp; systems pharmacology 13(5):853–869</i> 2024 (<a href=\"https://doi.org/10.1002/psp4.13123\">doi:10.1002/psp4.13123</a>) — international normalized ratio against S-warfarin μM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =      0.027 μM       exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μM of S-warfarin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.027 μM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Warfarin_Geng2024_PD_inr;
