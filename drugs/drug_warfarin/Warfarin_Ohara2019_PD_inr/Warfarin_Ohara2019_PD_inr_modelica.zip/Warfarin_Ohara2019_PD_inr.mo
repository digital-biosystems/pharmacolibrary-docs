model Warfarin_Ohara2019_PD_inr
  "indirect_response_iii exposure-response sweep — Ohara_2019 :: INR (international normalized ratio)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 7,  // type III effect term
    EC50 = 0.00163,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 17, Interval = 0.034),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant used to prevent and treat blood clots in conditions such as atrial fibrillation, heart valve disease, pulmonary embolism, thrombosis, and heart disease. It is widely used in human medicine and is included on the WHO list of essential medicines, though it also serves as a rodenticide and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Ohara2019_PD_inr</h4><p>The steady-state exposure-response curve of Ohara M et al., <i>Clinical pharmacokinetics 58(8):1077–1089</i> 2019 (<a href=\"https://doi.org/10.1007/s40262-019-00745-5\">doi:10.1007/s40262-019-00745-5</a>) — international normalized ratio against S-warfarin μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          7          maximal effect term (E max, Q320)
  EC50  =       1.63 μg/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/mL of S-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.63 μg/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Warfarin_Ohara2019_PD_inr;
