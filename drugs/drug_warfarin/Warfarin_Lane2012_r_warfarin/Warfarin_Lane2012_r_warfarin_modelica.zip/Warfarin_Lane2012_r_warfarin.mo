model Warfarin_Lane2012_r_warfarin
  parameter Real Cl_ref = 1.7972222222222223e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00157 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>patients on long-term warfarin therapy</td></tr><tr><td>source_paper:</td><td>Lane_2012</td></tr><tr><td>measured_compound:</td><td>R-warfarin, S-warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Objective function' — extend the ontology if this is a real PK parameter (source ['tab_2:row1:col4', 'Lane_2012_table_2:row0:col4'])</li><li>dropped unlinked row (NIL): 'qwgt' — extend the ontology if this is a real PK parameter (source ['tab_2:row6:col2', 'tab_2:row6:col5'])</li><li>dropped unlinked row (NIL): 'qwgt' — extend the ontology if this is a real PK parameter (source ['tab_2:row6:col4'])</li><li>dropped unlinked row (NIL): 'qage' — extend the ontology if this is a real PK parameter (source ['tab_2:row7:col2', 'tab_2:row7:col5'])</li><li>dropped unlinked row (NIL): 'qage' — extend the ontology if this is a real PK parameter (source ['tab_2:row7:col4'])</li><li>dropped unlinked row (NIL): 'Male' — extend the ontology if this is a real PK parameter (source ['tab_2:row10:col2'])</li><li>dropped unlinked row (NIL): '*1/*2' — extend the ontology if this is a real PK parameter (source ['tab_2:row13:col2'])</li><li>dropped unlinked row (NIL): '*2/*2' — extend the ontology if this is a real PK parameter (source ['tab_2:row14:col2'])</li><li>dropped unlinked row (NIL): '*1/*3' — extend the ontology if this is a real PK parameter (source ['tab_2:row15:col2'])</li><li>dropped unlinked row (NIL): '*2/*3' — extend the ontology if this is a real PK parameter (source ['tab_2:row16:col2'])</li><li>dropped unlinked row (NIL): '*3/*3' — extend the ontology if this is a real PK parameter (source ['tab_2:row17:col2'])</li><li>dropped unlinked row (NIL): 'Missing' — extend the ontology if this is a real PK parameter (source ['tab_2:row18:col2', 'tab_2:row23:col5'])</li><li>dropped unlinked row (NIL): 'Homozygote' — extend the ontology if this is a real PK parameter (source ['tab_2:row20:col4', 'tab_2:row25:col4'])</li><li>dropped unlinked row (NIL): 'Heterozygote' — extend the ontology if this is a real PK parameter (source ['tab_2:row21:col4', 'tab_2:row26:col4'])</li><li>dropped unlinked row (NIL): 'Heterozygote' — extend the ontology if this is a real PK parameter (source ['tab_2:row21:col5', 'tab_2:row26:col5'])</li><li>dropped unlinked row (NIL): 'Mutant -homozygote' — extend the ontology if this is a real PK parameter (source ['tab_2:row22:col4', 'tab_2:row27:col4'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Warfarin_Lane2012_r_warfarin;
