model Warfarin_Lane2012_estimate
  parameter Real Cl_ref = 1.0583333333333333e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.000934 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7.5e-06,
    ka = 5.9444444444444445e-05,
    Tlag = 4644.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant used to prevent and treat blood clots in conditions such as atrial fibrillation, heart valve disease, pulmonary embolism, thrombosis, and heart disease. It is widely used in human medicine and is included on the WHO list of essential medicines, though it also serves as a rodenticide and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>patients on long-term warfarin therapy</td></tr><tr><td>source_paper:</td><td>Lane_2012</td></tr><tr><td>measured_compound:</td><td>R-warfarin; S-warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>warfarin 308.328 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL (l h-1)'; source reconciliation required</li><li>table representations disagree for 'CL (l h-1)'; source reconciliation required</li><li>table representations disagree for 'V (l)'; source reconciliation required</li><li>table representations disagree for 'V (l)'; source reconciliation required</li><li>table representations disagree for 'θwgt'; source reconciliation required</li><li>table representations disagree for 'θwgt'; source reconciliation required</li><li>table representations disagree for 'θage'; source reconciliation required</li><li>table representations disagree for 'θage'; source reconciliation required</li><li>table representations disagree for 'Male'; source reconciliation required</li><li>table representations disagree for '*1/*2'; source reconciliation required</li><li>table representations disagree for '*2/*2'; source reconciliation required</li><li>table representations disagree for '*1/*3'; source reconciliation required</li><li>table representations disagree for '*2/*3'; source reconciliation required</li><li>table representations disagree for '*3/*3'; source reconciliation required</li><li>table representations disagree for 'Missing'; source reconciliation required</li><li>table representations disagree for 'Heterozygote'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Warfarin_Lane2012_estimate;
