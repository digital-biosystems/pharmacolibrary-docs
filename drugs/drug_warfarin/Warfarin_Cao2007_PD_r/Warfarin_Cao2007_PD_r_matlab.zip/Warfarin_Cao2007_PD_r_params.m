function p = Warfarin_Cao2007_PD_r_params()
% Warfarin_Cao2007_PD_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Cao_2007::R: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg ml−1 per second, in SI inside (kg/m3, s). Response R in its own unit. Driver: warfarin (pk_record).
p.E0 = 1.06;
p.Emax = 0.9;
p.EC50 = 0.0036999999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 37.0;
p.form = 'E0*(1 - Emax*frac)';
end
