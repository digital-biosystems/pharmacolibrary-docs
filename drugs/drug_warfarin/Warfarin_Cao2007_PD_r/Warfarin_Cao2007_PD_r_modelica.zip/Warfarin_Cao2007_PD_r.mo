model Warfarin_Cao2007_PD_r
  "indirect_response_i exposure-response sweep — Cao_2007 :: R (prothrombin activity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.06,      // [1]
    Emax = 0.9,  // type I effect term
    EC50 = 0.0037,  // [kg/m3; µg ml−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg ml−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 37, Interval = 0.074),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant medication used to treat conditions such as deep vein thrombosis, pulmonary embolism, and atrial fibrillation. It is usually taken orally, as it is well-absorbed by mouth, but it may also be given intravenously. It is widely used and listed on the World Health Organization essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a>, <a href=\"https://en.wikipedia.org/wiki/Warfarin?oldid=1383243665\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Cao2007_PD_r</h4><p>The steady-state exposure-response curve of Cao YG et al., <i>European journal of pharmaceutical sciences : official journal of the European Federation for Pharmaceutical Sciences 30(2):175–180</i> 2007 (<a href=\"https://doi.org/10.1016/j.ejps.2006.10.009\">doi:10.1016/j.ejps.2006.10.009</a>) — prothrombin activity against warfarin µg ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.06          drug-free response (baseline) (R0, Q324)
  Emax  =        0.9          maximal effect term (E max, Q320)
  EC50  =        3.7 µg ml−1  exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one µg ml−1 of warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.06   (drug-free)
  exposure = EC50 (3.7 µg ml−1)  response 0.583
  exposure -> infinity  response 0.106</pre></body></html>"));
end Warfarin_Cao2007_PD_r;
