model Warfarin_Hirai2024_prior_values
  parameter Real Cl_ref = 9.666666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 5.9444444444444445e-05,
    Tlag = 4644.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>Japanese adults</td></tr><tr><td>source_paper:</td><td>Hirai_2024</td></tr><tr><td>measured_compound:</td><td>warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'MTT2 − MTT1, h' — extend the ontology if this is a real PK parameter (source ['Hirai_2024_table_2:row10:col5', 'Hirai_2024_table_2:row10:col6'])</li><li>dropped unlinked row (NIL): 'MTT2, h' — extend the ontology if this is a real PK parameter (source ['Hirai_2024_table_2:row11:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=warfarin</li><li>population split: 'prior values' subgroup of Hirai_2024 (paper reports 3 populations: estimates, median, prior values)</li><li>gap-filled Q22 (CL) from Aoyama_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Aoyama_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gomeni_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gomeni_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Warfarin_Hirai2024_prior_values;
