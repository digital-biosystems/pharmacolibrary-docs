function p = Warfarin_Lane2012_r_warfarin_9425_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: warfarin   source: Lane_2012 / r_warfarin_9425_estimate   route: oral
  % estimated (absent from source): F
  p.name  = 'Warfarin_Lane2012_r_warfarin_9425_estimate_params';
  p.drug  = 'warfarin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.11;                % central volume [L]
  p.CL = 0.132;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.214;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.29;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
