model Warfarin_Shi2024_PD_npt
  "indirect_response_i exposure-response sweep — Shi_2024 :: NPT (normal prothrombin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 7.25e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.73, Interval = 0.00146),
    Documentation(info = "<html><body><h4>Warfarin_Shi2024_PD_npt</h4><p>The steady-state exposure-response curve of Shi K et al., <i>Pharmacogenetics and genomics 34(9):275–284</i> 2024 (<a href=\"https://doi.org/10.1097/FPC.0000000000000545\">doi:10.1097/FPC.0000000000000545</a>) — normal prothrombin against S-warfarin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =     0.0725 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of S-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0725 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Warfarin_Shi2024_PD_npt;
