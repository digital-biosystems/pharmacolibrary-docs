model Warfarin_Shi2024_PD_npt
  "indirect_response_i exposure-response sweep — Shi_2024 :: NPT (normal prothrombin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.119,      // [kg/m3; mg/l × 0.001]
    Emax = 1,  // type I effect term
    EC50 = 7.25e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.73, Interval = 0.00146),
    Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant used to prevent and treat blood clots in conditions such as atrial fibrillation, heart valve disease, pulmonary embolism, thrombosis, and heart disease. It is widely used in human medicine and is included on the WHO list of essential medicines, though it also serves as a rodenticide and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Warfarin_Shi2024_PD_npt</h4><p>The steady-state exposure-response curve of Shi K et al., <i>Pharmacogenetics and genomics 34(9):275–284</i> 2024 (<a href=\"https://doi.org/10.1097/FPC.0000000000000545\">doi:10.1097/FPC.0000000000000545</a>) — normal prothrombin [mg/l] against S-warfarin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        119 mg/l     drug-free response (baseline) (NPT0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =     0.0725 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of S-warfarin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.119   (drug-free)
  exposure = EC50 (0.0725 mg/L)  response 0.0595
  exposure -> infinity  response 0</pre></body></html>"));
end Warfarin_Shi2024_PD_npt;
