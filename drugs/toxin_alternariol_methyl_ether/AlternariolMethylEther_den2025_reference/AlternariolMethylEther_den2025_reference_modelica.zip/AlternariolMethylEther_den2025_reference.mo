// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model AlternariolMethylEther_den2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {492.17551282362973},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alternariol_methyl_ether</td></tr><tr><td>population:</td><td>piglets (weaned, ~4–8 weeks of age, ~6–20 kg b.w.)</td></tr><tr><td>source_paper:</td><td>den_2025</td></tr><tr><td>measured_compound:</td><td>Alternariol methyl ether (AME)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>alternariol_methyl_ether 272.256 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC0-∞'</li><li>dropped value-less row: 'C0'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 't1/2el'</li><li>dropped value-less row: 'ke'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'Vd'</li><li>dropped value-less row: 'fe'</li><li>salvaged Q47 ('mean ke (AOH)'=5.07) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('mean t1/2el (AOH)'=0.16) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Alternariol methyl ether (AME)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 9 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end AlternariolMethylEther_den2025_reference;
