model Vinblastine_Owellen1975_reference
  parameter Real Cl_ref = 7.599288026072491e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0297 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8109890000000001,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>two patients with malignant disease</td></tr><tr><td>source_paper:</td><td>Owellen_1975</td></tr><tr><td>measured_compound:</td><td>Vinblastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vinblastine 810.989 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2α from footnote/prose kept as documentation only (['Owellen_1975:abstract', 'Owellen_1975:abstract'])</li><li>covariate category for t1/2γ from footnote/prose kept as documentation only (['Owellen_1975:abstract', 'Owellen_1975:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vinblastine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of the central compartment' is the general volume)</li><li>toxin: t1/2 printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL from Kawai_2025: its label names a different analyte ('creatinine') — 'Clearance of creatinine (ml/min) median (IQR):'</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li><li>derived CL=273.574 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Owellen1975_reference;
