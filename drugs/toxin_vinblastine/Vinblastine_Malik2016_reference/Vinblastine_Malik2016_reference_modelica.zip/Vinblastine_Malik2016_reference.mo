model Vinblastine_Malik2016_reference
  parameter Real Cl_ref = 6.682797784223643e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7917000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8109890000000001,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>18 Hodgkin's lymphoma male patients</td></tr><tr><td>source_paper:</td><td>Malik_2016</td></tr><tr><td>measured_compound:</td><td>Vinblastine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>vinblastine 810.989 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Drug'</li><li>dropped value-less row: 'C max'</li><li>dropped value-less row: 'T max'</li><li>dropped value-less row: 'AUC 0-∞'</li><li>dropped value-less row: 'K e'</li><li>dropped value-less row: 'T 1/2'</li><li>dropped value-less row: 'MRT'</li><li>dropped value-less row: 'Clearance'</li><li>dropped value-less row: 'Vd'</li><li>salvaged Q57 ('Half-life'=22.81) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Clearances'=346.69) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Apparent volume of distribution'=11.31) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Vinblastine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 4 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Malik2016_reference;
