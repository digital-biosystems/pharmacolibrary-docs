model Vinblastine_Malik2016_vinblastine
  parameter Real Cl_ref = 1.275e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14209999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8109890000000001,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>18 Hodgkin's lymphoma male patients</td></tr><tr><td>source_paper:</td><td>Malik_2016</td></tr><tr><td>measured_compound:</td><td>Vinblastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vinblastine 810.989 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Drug'</li><li>dropped value-less row: 'C max'</li><li>dropped value-less row: 'T max'</li><li>dropped value-less row: 'AUC 0-∞'</li><li>dropped value-less row: 'K e'</li><li>dropped value-less row: 'T 1/2'</li><li>dropped value-less row: 'MRT'</li><li>dropped value-less row: 'Clearance'</li><li>dropped value-less row: 'Vd'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Vinblastine</li><li>toxin: 4 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'vinblastine' subgroup of Malik_2016 (paper reports 1 populations: vinblastine)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Malik2016_vinblastine;
