function p = Meloxicam_Lehr2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: meloxicam   source: Lehr_2010 / reference   route: oral
  p.name  = 'Meloxicam_Lehr2010_reference_params';
  p.drug  = 'meloxicam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.15;                % central volume [L]
  p.CL = 0.4592;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.26;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
