model Meloxicam_Jeunesse2011_PD_creeping_time
  "indirect_response_i exposure-response sweep — Jeunesse_2011 :: creeping time (creeping time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 400,  // [Nanograms per milliliter]
    gamma = 2.56,
    exposure_per_s = 1);   // 1 Nanograms per milliliter per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (13.8/3.45 = 4) — the paper's stated baseline may differ
  // exposure_unit_unresolved: 'Nanograms per milliliter' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 4000, Interval = 8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About meloxicam</h4><p>Meloxicam is a nonsteroidal anti-inflammatory drug used to treat osteoarthritis and other forms of arthritis. It is an approved medicine, also approved for veterinary use, and is widely used for inflammatory joint disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414028\">Wikidata Q414028</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Meloxicam_Jeunesse2011_PD_creeping_time</h4><p>The steady-state exposure-response curve of Jeunesse EC et al., <i>The Journal of pharmacology and experimental therapeutics 338(2):548–558</i> 2011 (<a href=\"https://doi.org/10.1124/jpet.110.178350\">doi:10.1124/jpet.110.178350</a>) — creeping time against meloxicam Nanograms per milliliter — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          4          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =          1          maximal effect term (I maxA, Q323)
  EC50  =        400 Nanograms per milliliter exposure at half of the maximal effect term (IC 50A, Q322)
  gamma =       2.56          Hill coefficient (n1, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one Nanograms per milliliter of meloxicam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4   (drug-free)
  exposure = EC50 (400 Nanograms per milliliter)  response 2
  exposure -> infinity  response 0</pre></body></html>"));
end Meloxicam_Jeunesse2011_PD_creeping_time;
