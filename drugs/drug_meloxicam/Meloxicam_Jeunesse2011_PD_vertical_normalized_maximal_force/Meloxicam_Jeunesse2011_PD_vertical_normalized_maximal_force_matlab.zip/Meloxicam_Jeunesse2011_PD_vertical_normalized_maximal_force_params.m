function p = Meloxicam_Jeunesse2011_PD_vertical_normalized_maximal_force_params()
% Meloxicam_Jeunesse2011_PD_vertical_normalized_maximal_force_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Jeunesse_2011::vertical_normalized_maximal_force_of_the_paw_as_obtained_with_a_force_plate: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Nanograms per milliliter per second, in SI inside (kg/m3, s). Response vertical normalized maximal force of the paw as obtained with a force plate in its own unit. Driver: meloxicam (cited_pk).
p.E0 = 2.5214521452145213;
p.Emax = 1.0;
p.EC50 = 546.0;
p.gamma = 3.03;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 5500.0;
p.form = 'E0*(1 - Emax*frac)';
end
