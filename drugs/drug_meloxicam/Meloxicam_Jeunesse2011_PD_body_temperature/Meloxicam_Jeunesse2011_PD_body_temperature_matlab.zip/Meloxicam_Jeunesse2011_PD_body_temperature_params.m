function p = Meloxicam_Jeunesse2011_PD_body_temperature_params()
% Meloxicam_Jeunesse2011_PD_body_temperature_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Jeunesse_2011::body_temperature: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Nanograms per milliliter per second, in SI inside (kg/m3, s). Response body temperature in its own unit. Driver: meloxicam (cited_pk).
p.E0 = 37.689243027888445;
p.Emax = 0.84;
p.EC50 = 210.0;
p.gamma = 4.37;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2100.0;
p.form = 'E0*(1 - Emax*frac)';
end
