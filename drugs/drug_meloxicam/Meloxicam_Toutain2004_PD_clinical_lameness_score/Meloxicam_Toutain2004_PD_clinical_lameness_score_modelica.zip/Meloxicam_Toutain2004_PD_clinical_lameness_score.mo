model Meloxicam_Toutain2004_PD_clinical_lameness_score
  "sigmoid_emax exposure-response sweep — Toutain_2004 :: clinical lameness score (clinical lameness score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 9.16,  // [units]
    EC50 = 2.65e-07,  // [1; mg/kg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg/kg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.7, Interval = 0.0054),
    Documentation(info = "<html><body><!-- drug-about --><h4>About meloxicam</h4><p>Meloxicam is a nonsteroidal anti-inflammatory drug used to treat osteoarthritis and other forms of arthritis. It is an approved medicine, also approved for veterinary use, and is widely used for inflammatory joint disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414028\">Wikidata Q414028</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Meloxicam_Toutain2004_PD_clinical_lameness_score</h4><p>The steady-state exposure-response curve of Toutain PL et al., <i>American journal of veterinary research 65(11):1533–1541</i> 2004 (<a href=\"https://doi.org/10.2460/ajvr.2004.65.1533\">doi:10.2460/ajvr.2004.65.1533</a>) — clinical lameness score [units] against meloxicam mg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       9.16 units    maximal effect term (Emax, Q320)
  EC50  =      0.265 mg/kg    exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/kg of meloxicam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.265 mg/kg)  response 4.58
  exposure -> infinity  response 9.16</pre></body></html>"));
end Meloxicam_Toutain2004_PD_clinical_lameness_score;
