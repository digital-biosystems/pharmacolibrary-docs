function p = Meloxicam_Jeunesse2011_PD_lameness_score_params()
% Meloxicam_Jeunesse2011_PD_lameness_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Jeunesse_2011::lameness_score: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Nanograms per milliliter per second, in SI inside (kg/m3, s). Response lameness score in its own unit. Driver: meloxicam (cited_pk).
p.E0 = 0.0011422845691382766;
p.Emax = 0.82;
p.EC50 = 466.0;
p.gamma = 3.93;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 4700.0;
p.form = 'E0*(1 - Emax*frac)';
end
