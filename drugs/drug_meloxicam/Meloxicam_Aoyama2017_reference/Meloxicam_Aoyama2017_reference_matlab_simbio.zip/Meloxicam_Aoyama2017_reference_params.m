function p = Meloxicam_Aoyama2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: meloxicam   source: Aoyama_2017 / reference   route: oral
  p.name  = 'Meloxicam_Aoyama2017_reference_params';
  p.drug  = 'meloxicam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.79;                % central volume [L]
  p.CL = 0.391;                % clearance [L/h]
  p.Vp = [2.73];             % peripheral volumes [L]
  p.Q  = [1.24];             % inter-compartmental clearances [L/h]
  p.ka = 2.0;                % absorption rate [1/h]
  p.F  = 0.425;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
