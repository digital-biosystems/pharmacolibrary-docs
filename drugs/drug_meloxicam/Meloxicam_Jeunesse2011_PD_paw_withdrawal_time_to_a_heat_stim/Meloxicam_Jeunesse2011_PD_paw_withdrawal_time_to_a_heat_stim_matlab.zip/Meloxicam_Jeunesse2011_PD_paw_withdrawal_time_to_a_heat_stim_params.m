function p = Meloxicam_Jeunesse2011_PD_paw_withdrawal_time_to_a_heat_stim_params()
% Meloxicam_Jeunesse2011_PD_paw_withdrawal_time_to_a_heat_stim_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Jeunesse_2011::paw_withdrawal_time_to_a_heat_stimulus: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Nanograms per milliliter per second, in SI inside (kg/m3, s). Response paw withdrawal time to a heat stimulus in its own unit. Driver: meloxicam (cited_pk).
p.E0 = 8.007448789571695;
p.Emax = 1.0;
p.EC50 = 390.0;
p.gamma = 3.88;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3900.0;
p.form = 'E0*(1 - Emax*frac)';
end
