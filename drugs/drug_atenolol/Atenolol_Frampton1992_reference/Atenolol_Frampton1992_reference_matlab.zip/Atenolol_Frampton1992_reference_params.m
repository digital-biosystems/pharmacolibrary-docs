function p = Atenolol_Frampton1992_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atenolol   source: Frampton_1992 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Atenolol_Frampton1992_reference_params';
  p.drug  = 'atenolol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 62.516785;                % central volume [L]
  p.CL = 52.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 75.0;             % dose [mg]
end
