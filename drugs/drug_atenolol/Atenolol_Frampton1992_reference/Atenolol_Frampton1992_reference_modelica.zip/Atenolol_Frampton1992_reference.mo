model Atenolol_Frampton1992_reference
  parameter Real Cl_ref = 1.4444444444444446e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06251678510518842 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26633609999999996,
    adminMass = 7.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atenolol</h4><p>Atenolol is a selective beta blocker used to treat high blood pressure and other heart conditions such as angina, arrhythmias, and after a heart attack. It is an approved medicine, widely used in cardiovascular care, and is also available in fixed combinations with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411325\">Wikidata Q411325</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atenolol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Frampton_1992</td></tr><tr><td>measured_compound:</td><td>atenolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>atenolol 266.336 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Frampton_1992) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atenolol_Frampton1992_reference;
