function p = Atenolol_van2007_PD_hr_2_params()
% Atenolol_van2007_PD_hr_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atenolol van_2007::HR::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml−1 per second, in SI inside (kg/m3, s). Response HR in b.p.m.. Driver: S(−)-atenolol (pk_record).
p.E0 = 362.0;
p.Emax = -43.0;
p.EC50 = 2.7899999999999997e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 280.0;
p.form = 'E0 + Emax*frac';
end
