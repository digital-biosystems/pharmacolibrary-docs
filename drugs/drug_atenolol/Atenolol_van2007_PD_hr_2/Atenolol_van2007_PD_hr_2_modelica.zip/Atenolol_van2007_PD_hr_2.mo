model Atenolol_van2007_PD_hr_2
  "sigmoid_emax exposure-response sweep — van_2007 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 362,      // [b.p.m.]
    Emax = -43,  // [b.p.m.]
    EC50 = 2.79e-05,  // [kg/m3; ng ml−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 280, Interval = 0.56),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atenolol</h4><p>Atenolol is a selective beta blocker used to treat high blood pressure and other heart conditions such as angina, arrhythmias, and after a heart attack. It is an approved medicine, widely used in cardiovascular care, and is also available in fixed combinations with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411325\">Wikidata Q411325</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atenolol_van2007_PD_hr_2</h4><p>The steady-state exposure-response curve of van Steeg TJ et al., <i>British journal of pharmacology 151(3):356–366</i> 2007 (<a href=\"https://doi.org/10.1038/sj.bjp.0707234\">doi:10.1038/sj.bjp.0707234</a>) — heart rate [b.p.m.] against S(−)-atenolol ng ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        362 b.p.m.   drug-free response (baseline) (E0, Q324)
  Emax  =        -43 b.p.m.   maximal effect term (Emax, Q323)
  EC50  =       27.9 ng ml−1  exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml−1 of S(−)-atenolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 362   (drug-free)
  exposure = EC50 (27.9 ng ml−1)  response 340.5
  exposure -> infinity  response 319</pre></body></html>"));
end Atenolol_van2007_PD_hr_2;
