function p = Atenolol_McCoy1994_PD_hr_2_params()
% Atenolol_McCoy1994_PD_hr_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atenolol McCoy_1994::HR::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response HR in beats/mm. Driver: S(-)-atenolol (cited_pk).
p.E0 = 0.0;
p.Emax = -34.5;
p.EC50 = 2.5899999999999996e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 260.0;
p.form = 'E0 + Emax*frac';
end
