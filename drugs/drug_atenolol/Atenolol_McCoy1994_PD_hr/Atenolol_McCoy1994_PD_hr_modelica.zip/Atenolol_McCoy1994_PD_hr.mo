model Atenolol_McCoy1994_PD_hr
  "sigmoid_emax exposure-response sweep — McCoy_1994 :: HR (Heart Rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -39.6,  // [beats/mm]
    EC50 = 3.84e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 390, Interval = 0.78),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atenolol</h4><p>Atenolol is a selective beta blocker used to treat high blood pressure and other heart conditions such as angina, arrhythmias, and after a heart attack. It is an approved medicine, widely used in cardiovascular care, and is also available in fixed combinations with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411325\">Wikidata Q411325</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atenolol_McCoy1994_PD_hr</h4><p>The steady-state exposure-response curve of McCoy RA et al., <i>Journal of clinical pharmacology 34(8):816–822</i> 1994 (<a href=\"https://doi.org/10.1002/j.1552-4604.1994.tb02045.x\">doi:10.1002/j.1552-4604.1994.tb02045.x</a>) — Heart Rate [beats/mm] against S(-)-atenolol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       39.6 beats/mm maximal effect term (Emax, Q323)
  EC50  =       38.4 ng/ml    exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of S(-)-atenolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (38.4 ng/ml)  response -19.8
  exposure -> infinity  response -39.6</pre></body></html>"));
end Atenolol_McCoy1994_PD_hr;
