model Atenolol_Baek2008_PD_dbp
  "sigmoid_emax exposure-response sweep — Baek_2008 :: DBP (Diastolic Blood Pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.4886,  // [1; % × 0.01]
    EC50 = 0.00035946,  // [kg/m3; ng/mL × 1e-06]
    gamma = 6.6,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 3600, Interval = 7.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atenolol</h4><p>Atenolol is a selective beta blocker used to treat high blood pressure and other heart conditions such as angina, arrhythmias, and after a heart attack. It is an approved medicine, widely used in cardiovascular care, and is also available in fixed combinations with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411325\">Wikidata Q411325</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atenolol_Baek2008_PD_dbp</h4><p>The steady-state exposure-response curve of Baek IH et al., <i>Archives of pharmacal research 31(6):814–821</i> 2008 (<a href=\"https://doi.org/10.1007/s12272-001-1231-4\">doi:10.1007/s12272-001-1231-4</a>) — Diastolic Blood Pressure [%] against atenolol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      48.86 %        maximal effect term (E max, Q323)
  EC50  =     359.46 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        6.6          Hill coefficient (Γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of atenolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (359.46 ng/mL)  response -0.2443
  exposure -> infinity  response -0.4886</pre></body></html>"));
end Atenolol_Baek2008_PD_dbp;
