model Etelcalcetide_Chen2018_reference
  parameter Real Cl_ref = 1.311111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0499 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.04826,
    adminMass = 2.1000000000000002e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etelcalcetide</h4><p>Etelcalcetide is a calcimimetic medicine used to treat secondary hyperparathyroidism. It is authorised in the European Union and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21098973\">Wikidata Q21098973</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etelcalcetide</td></tr><tr><td>population:</td><td>patients with chronic kidney disease and secondary hyperparathyroidism receiving hemodialysis</td></tr><tr><td>source_paper:</td><td>Chen_2018</td></tr><tr><td>measured_compound:</td><td>etelcalcetide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>etelcalcetide 1048.26 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('turnover half-lives of Ca', value 23) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=etelcalcetide</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution (Vc)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Etelcalcetide_Chen2018_reference;
