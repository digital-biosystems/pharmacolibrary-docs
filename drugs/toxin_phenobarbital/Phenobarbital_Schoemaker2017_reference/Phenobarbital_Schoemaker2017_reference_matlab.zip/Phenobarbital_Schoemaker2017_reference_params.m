function p = Phenobarbital_Schoemaker2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenobarbital   source: Schoemaker_2017 / reference   route: oral
  p.name  = 'Phenobarbital_Schoemaker2017_reference_params';
  p.drug  = 'phenobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.8;                % central volume [L]
  p.CL = 3.63;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.84;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
