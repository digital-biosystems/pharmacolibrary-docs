model Phenobarbital_Schoemaker2017_reference
  parameter Real Cl_ref = 1.0083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.047799999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.232239,
    adminMass = 0.0001,
    ka = 0.0005111111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenobarbital</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Schoemaker_2017</td></tr><tr><td>measured_compound:</td><td>phenobarbital</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>phenobarbital 232.239 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Schoemaker_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Phenobarbital_Schoemaker2017_reference;
