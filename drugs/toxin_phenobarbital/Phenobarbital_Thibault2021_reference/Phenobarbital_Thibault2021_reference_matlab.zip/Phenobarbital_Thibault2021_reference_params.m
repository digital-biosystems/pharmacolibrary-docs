function p = Phenobarbital_Thibault2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenobarbital   source: Thibault_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Phenobarbital_Thibault2021_reference_params';
  p.drug  = 'phenobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.83;                % central volume [L]
  p.CL = 0.038;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.61;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.96;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
