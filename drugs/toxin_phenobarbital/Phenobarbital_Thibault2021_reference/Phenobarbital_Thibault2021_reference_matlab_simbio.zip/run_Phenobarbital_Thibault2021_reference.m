% Run (SimBiology): build model + dose, simulate 0..360.0 h, plot.
p = Phenobarbital_Thibault2021_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 360.0);
