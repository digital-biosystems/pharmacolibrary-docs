model Phenobarbital_Stoschus2025_reference
  parameter Real Cl_ref = 9.722222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.049769999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.232239,
    adminMass = 0.0007,
    ka = 0.0005277777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenobarbital</td></tr><tr><td>population:</td><td>critically ill patients with refractory and superrefractory status epilepticus</td></tr><tr><td>source_paper:</td><td>Stoschus_2025</td></tr><tr><td>measured_compound:</td><td>Phenobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>epi18517-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>phenobarbital 232.239 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'V, L' routed out of structural estimates ('IIV parameters SD CV %')</li><li>table section iiv: 'CL, L/h' routed out of structural estimates ('IIV parameters SD CV %')</li><li>table section iov: 'CL, L/h' routed out of structural estimates ('IOV parameters SD')</li><li>table representations disagree for 'k a, h−1 a'; source reconciliation required</li><li>table representations disagree for 'k a, h−1 a'; source reconciliation required</li><li>unit_dimension_unknown: 'h−1 a' (kabs)</li><li>implicit units: 'k a, h−1 a' → 1/h (from the popPK convention: &quot;The paper text does not explicitly state the unit for ka, but the parameter is defined as the 'Absorption rate constant'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Phenobarbital</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Favié_2019's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Birbeck_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Birbeck_2019, Favié_2019 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1814400, Tolerance = 1e-9, Interval = 1));
end Phenobarbital_Stoschus2025_reference;
