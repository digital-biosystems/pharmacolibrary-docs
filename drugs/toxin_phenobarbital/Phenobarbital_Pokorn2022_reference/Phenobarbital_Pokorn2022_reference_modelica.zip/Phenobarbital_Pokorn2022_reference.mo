model Phenobarbital_Pokorn2022_reference
  parameter Real Cl_ref = 1.5638888888888887e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00091 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.232239,
    adminMass = 0.0001,
    ka = 0.00016944444444444445,
    Tlag = 7056.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenobarbital</td></tr><tr><td>population:</td><td>asphyxiated newborns treated with therapeutic hypothermia</td></tr><tr><td>source_paper:</td><td>Pokorná_2022</td></tr><tr><td>measured_compound:</td><td>Phenobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>phenobarbital 232.239 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'additional kg' — extend the ontology if this is a real PK parameter (source ['Pokorná_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Phenobarbital</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alvariza_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Birbeck_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Phenobarbital_Pokorn2022_reference;
