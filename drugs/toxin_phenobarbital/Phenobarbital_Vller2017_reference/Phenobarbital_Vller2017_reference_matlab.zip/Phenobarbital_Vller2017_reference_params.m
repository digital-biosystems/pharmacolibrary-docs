function p = Phenobarbital_Vller2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenobarbital   source: Völler_2017 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Phenobarbital_Vller2017_reference_params';
  p.drug  = 'phenobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.38;                % central volume [L]
  p.CL = 0.0091;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 50.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 91.0;             % dose [mg]
end
