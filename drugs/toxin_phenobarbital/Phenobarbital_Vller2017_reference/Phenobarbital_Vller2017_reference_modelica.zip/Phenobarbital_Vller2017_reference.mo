model Phenobarbital_Vller2017_reference
  parameter Real Cl_ref = 2.5277777777777782e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0023799999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.232239,
    adminMass = 9.1e-05,
    ka = 0.013888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenobarbital</td></tr><tr><td>population:</td><td>term and preterm newborns</td></tr><tr><td>source_paper:</td><td>Völler_2017</td></tr><tr><td>measured_compound:</td><td>Phenobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>phenobarbital 232.239 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'On CL [%]' routed out of structural estimates ('Inter-individual variability (eta)')</li><li>table section iiv: 'On V [%]' routed out of structural estimates ('Inter-individual variability (eta)')</li><li>table section residual_error: 'Proportional [%]' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'ΘPNA [increase in CL per postnatal day (PNA) (fraction)]' — extend the ontology if this is a real PK parameter (source ['Völler_2017_table_p4_1:row3:col1'])</li><li>dropped duplicate Q22 ('ΘbBW [increase in CL per kg birthweight (bBW) (fraction)]', value '0.369') — already have one for this compound</li><li>dropped unlinked row (NIL): 'F [%]' — extend the ontology if this is a real PK parameter (source ['Völler_2017_table_p4_1:row9:col1'])</li><li>dropped value-less row: 'Ɵ PNA'</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL [L/h] = CLp); Q61 (V [L] = Vp)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Phenobarbital</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q352 — no SI value to build from; C1_half_life_beta failed (ratio 1.5285))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Phenobarbital_Vller2017_reference;
