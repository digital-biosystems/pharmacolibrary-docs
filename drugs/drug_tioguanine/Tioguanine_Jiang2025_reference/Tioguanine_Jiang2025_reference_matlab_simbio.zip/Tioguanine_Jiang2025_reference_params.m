function p = Tioguanine_Jiang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tioguanine   source: Jiang_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Tioguanine_Jiang2025_reference_params';
  p.drug  = 'tioguanine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 140.0;                % central volume [L]
  p.CL = 21.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
