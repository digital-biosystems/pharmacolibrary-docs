model Phenobarbital_Stoschus2025_reference
  parameter Real Cl_ref = 1.6333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00182 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0007333333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenobarbital</td></tr><tr><td>population:</td><td>critically ill patients with refractory and superrefractory status epilepticus</td></tr><tr><td>source_paper:</td><td>Stoschus_2025</td></tr><tr><td>measured_compound:</td><td>phenobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>epi18517-tbl-0002</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'k a, h−1 a'</li><li>dropped value-less row: 'V, L'</li><li>dropped value-less row: 'CL, L/h'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=phenobarbital</li><li>gap-filled Q22 (CL) from Yalcin_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Yalcin_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Teixeira-da-Silva_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Phenobarbital_Stoschus2025_reference;
