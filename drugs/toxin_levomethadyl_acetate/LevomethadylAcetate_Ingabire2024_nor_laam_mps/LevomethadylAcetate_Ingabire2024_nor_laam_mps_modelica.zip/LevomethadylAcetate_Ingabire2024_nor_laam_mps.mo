// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model LevomethadylAcetate_Ingabire2024_nor_laam_mps
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {199080.0},
    adminMass = 7e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levomethadyl_acetate</td></tr><tr><td>population:</td><td>rabbits</td></tr><tr><td>source_paper:</td><td>Ingabire_2024</td></tr><tr><td>measured_compound:</td><td>Nor-Levo-α-acetylmethadol (nor-LAAM)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>levomethadyl_acetate 353.506 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Route of administration' — extend the ontology if this is a real PK parameter (source ['T2:row1:col3'])</li><li>unit_dimension_unknown: 'h×ng/mL' (AUC∞)</li><li>unit_dimension_unknown: 'h×ng/mL' (AUCt)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nor-Levo-α-acetylmethadol (nor-LAAM)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'nor-laam-mps' subgroup of Ingabire_2024 (paper reports 3 populations: no-laam solution, nor-laam solution, nor-laam-mps)</li><li>molar mass: no plausible PubChem entry for 'Nor-Levo-α-acetylmethadol (nor-LAAM)' ('nor-levomethadyl acetate (nor-LAAM)') — left in mass units</li><li>molar mass: none found for 'Nor-Levo-α-acetylmethadol (nor-LAAM)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end LevomethadylAcetate_Ingabire2024_nor_laam_mps;
