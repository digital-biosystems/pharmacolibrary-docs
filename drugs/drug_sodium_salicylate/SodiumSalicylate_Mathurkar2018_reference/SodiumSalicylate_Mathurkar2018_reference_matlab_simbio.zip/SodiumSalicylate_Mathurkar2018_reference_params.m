function p = SodiumSalicylate_Mathurkar2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_salicylate   source: Mathurkar_2018 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'SodiumSalicylate_Mathurkar2018_reference_params';
  p.drug  = 'sodium_salicylate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 84.0;                % central volume [L]
  p.CL = 2.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
