model SodiumSalicylate_Lowenthal1974_four_normal_subjects
  parameter Real Cl_ref = 7.777777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00543 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00017777777777777779,
    Tlag = 1512.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_salicylate</td></tr><tr><td>population:</td><td>anephric patients</td></tr><tr><td>source_paper:</td><td>Lowenthal_1974</td></tr><tr><td>measured_compound:</td><td>salicylic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('Vd (area), liter', value '9.18') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salicylic acid</li><li>population split: 'four normal subjects*' subgroup of Lowenthal_1974 (paper reports 2 populations: four normal subjects*, six anephric patients)</li><li>gap-filled Q22 (CL) from Mathurkar_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Mathurkar_2018's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Somani_2016's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SodiumSalicylate_Lowenthal1974_four_normal_subjects;
