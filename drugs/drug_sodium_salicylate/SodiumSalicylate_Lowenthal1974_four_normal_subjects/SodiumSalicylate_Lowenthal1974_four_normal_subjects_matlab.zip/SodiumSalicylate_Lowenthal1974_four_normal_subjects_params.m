function p = SodiumSalicylate_Lowenthal1974_four_normal_subjects_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_salicylate   source: Lowenthal_1974 / four_normal_subjects   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'SodiumSalicylate_Lowenthal1974_four_normal_subjects_params';
  p.drug  = 'sodium_salicylate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.43;                % central volume [L]
  p.CL = 2.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.42;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
