function p = Cefiderocol_SanzCodina2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefiderocol   source: Sanz-Codina_2024 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefiderocol_SanzCodina2024_reference_params';
  p.drug  = 'cefiderocol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.3;                % central volume [L]
  p.CL = 11.0;                % clearance [L/h]
  p.Vp = [15.1];             % peripheral volumes [L]
  p.Q  = [25.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
