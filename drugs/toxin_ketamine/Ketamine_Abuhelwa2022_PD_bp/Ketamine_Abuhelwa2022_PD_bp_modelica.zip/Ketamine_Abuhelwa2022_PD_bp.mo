model Ketamine_Abuhelwa2022_PD_bp
  "sigmoid_emax exposure-response sweep — Abuhelwa_2022 :: BP (Blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 97.1,      // [mm Hg]
    Emax = 51.6,  // [mm Hg]
    EC50 = 0.000468,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.04,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  annotation(experiment(StartTime = 0, StopTime = 4700, Interval = 9.4),
    Documentation(info = "<html><body><h4>Ketamine_Abuhelwa2022_PD_bp</h4><p>The steady-state exposure-response curve of Abuhelwa AY et al., <i>Clinical pharmacology and therapeutics 112(3):720-729</i> 2022 (<a href=\"https://doi.org/10.1002/cpt.2640\">doi:10.1002/cpt.2640</a>) — Blood pressure [mm Hg] against ketamine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       97.1 mm Hg    drug-free response (baseline) (Baseline MADRS, BP, or HR, Q324)
  Emax  =       51.6 mm Hg    maximal effect term (Maximum drug effect, Q320)
  EC50  =        468 ng/mL    exposure at half of the maximal effect term (Ketamine concentration at half maximum effect, Q321)
  gamma =       2.04          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of ketamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 97.1   (drug-free)
  exposure = EC50 (468 ng/mL)  response 122.9
  exposure -> infinity  response 148.7</pre></body></html>"));
end Ketamine_Abuhelwa2022_PD_bp;
