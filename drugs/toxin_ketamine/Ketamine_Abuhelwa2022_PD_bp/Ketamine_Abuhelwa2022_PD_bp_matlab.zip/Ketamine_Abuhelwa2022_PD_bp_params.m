function p = Ketamine_Abuhelwa2022_PD_bp_params()
% Ketamine_Abuhelwa2022_PD_bp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketamine Abuhelwa_2022::BP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BP in mm Hg. Driver: ketamine (cited_pk).
p.E0 = 97.1;
p.Emax = 51.6;
p.EC50 = 0.000468;
p.gamma = 2.04;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4700.0;
p.form = 'E0 + Emax*frac';
end
