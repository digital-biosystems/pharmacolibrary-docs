function p = Ketamine_Abuhelwa2022_PD_madrs_params()
% Ketamine_Abuhelwa2022_PD_madrs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketamine Abuhelwa_2022::MADRS: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response MADRS in its own unit. Driver: ketamine (cited_pk).
p.E0 = 22.3;
p.Emax = 1.0;
p.EC50 = 4.39e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4.4;
p.form = 'E0*(1 - Emax*frac)';
end
