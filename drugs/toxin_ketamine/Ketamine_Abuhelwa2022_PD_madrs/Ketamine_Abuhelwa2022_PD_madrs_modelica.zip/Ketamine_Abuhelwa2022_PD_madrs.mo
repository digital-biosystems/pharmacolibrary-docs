model Ketamine_Abuhelwa2022_PD_madrs
  "indirect_response_i exposure-response sweep — Abuhelwa_2022 :: MADRS (MADRS scores)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 22.3,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 4.39e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 4.4, Interval = 0.0088),
    Documentation(info = "<html><body><h4>Ketamine_Abuhelwa2022_PD_madrs</h4><p>The steady-state exposure-response curve of Abuhelwa AY et al., <i>Clinical pharmacology and therapeutics 112(3):720-729</i> 2022 (<a href=\"https://doi.org/10.1002/cpt.2640\">doi:10.1002/cpt.2640</a>) — MADRS scores against ketamine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       22.3          drug-free response (baseline) (Baseline MADRS, BP, or HR, Q324)
  Emax  =          1          maximal effect term (Maximum drug effect, Q323)
  EC50  =      0.439 ng/mL    exposure at half of the maximal effect term (Ketamine concentration at half maximum effect, Q321)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of ketamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 22.3   (drug-free)
  exposure = EC50 (0.439 ng/mL)  response 11.15
  exposure -> infinity  response 0</pre></body></html>"));
end Ketamine_Abuhelwa2022_PD_madrs;
