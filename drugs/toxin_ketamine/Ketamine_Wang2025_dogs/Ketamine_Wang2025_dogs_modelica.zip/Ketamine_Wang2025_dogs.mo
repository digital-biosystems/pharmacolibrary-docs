model Ketamine_Wang2025_dogs
  parameter Real Cl_ref = 1.1550000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.237727,
    adminMass = 7e-05,
    ka = 0.0009166666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>SD rats and Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>Ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>(R)-norketamine 223.7 g/mol (pubchem); Ketamine 237.727 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'T1/2'; source reconciliation required</li><li>table representations disagree for 'CLint in vitro'; source reconciliation required</li><li>table representations disagree for 'CLint in vivo'; source reconciliation required</li><li>table representations disagree for 'CLsys'; source reconciliation required</li><li>unit_dimension_unknown: 'R' (t1/2z)</li><li>dropped duplicate Q3 ('CLint in vivo', value '30.5') — already have one for this compound</li><li>implicit units: 'T1/2' → min (from the paper text: &quot;The text explicitly states units for half-lives in the metabolic stability section: 'the half-lives of phenacetin ... we&quot;)</li><li>implicit units: 'CLint in vitro' → μL/min/mg (from the paper text: &quot;The text explicitly defines the units for intrinsic clearance in the results section: 'The calculated intrinsic clearanc&quot;)</li><li>implicit units: 'CLsys' → mL/min/kg (from the popPK convention: &quot;The text defines CLsys as systemic clearance estimated via allometric scaling. It explicitly reports 'in vivo clearance &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ketamine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'dogs' subgroup of Wang_2025 (paper reports 12 populations: (r)-ketamine, 1 mg/kg, 10 mg/kg, 2.5 mg/kg / day 1, 25 mg/kg / day 1, 3 mg/kg, 7.5 mg/kg / day 1, 7.5 mg/kg / day 7, dogs, humans, monkeys, rats)</li><li>row roles (LLM): model_class=noncompartmental; 13/13 row label(s) assigned, 0 linked by role; re-tagged Ketamine→parent ×5</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Ketamine_Wang2025_dogs;
