function p = Ketamine_Henthorn1999_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketamine   source: Henthorn_1999 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ketamine_Henthorn1999_reference_params';
  p.drug  = 'ketamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 147.0;                % central volume [L]
  p.CL = 125.58;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
