model Ketamine_Wang2025_humans
  parameter Real Cl_ref = 2e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.237727,
    adminMass = 7e-05,
    ka = 0.0009166666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>SD rats and Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>Ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>(R)-norketamine 223.7 g/mol (pubchem); Ketamine 237.727 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'T1/2'; source reconciliation required</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'CLint in vitro'; source reconciliation required</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'CLint in vivo'; source reconciliation required</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'CLsys'; source reconciliation required</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'humans' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: 'R' (t1/2z)</li><li>dropped duplicate Q3 ('CLint in vivo', value '14.9') — already have one for this compound</li><li>implicit units: 'T1/2' → min (from the paper text: 'The text discusses half-lives in the context of in vitro microsomal stability, explicitly stating units in minutes (e.g.')</li><li>implicit units: 'CLint in vitro' → μL/min/mg (from the paper text: &quot;The paper explicitly calculates and reports intrinsic clearance (CLint in vitro) values with this unit: 'The calculated &quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketamine_Wang2025_humans;
