model Ketamine_Abuhelwa2022_PD_hr
  "emax exposure-response sweep — Abuhelwa_2022 :: HR (Heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 72.7,      // [beats/min]
    Emax = 220,  // [beats/min]
    EC50 = 0.00758,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  annotation(experiment(StartTime = 0, StopTime = 76000, Interval = 152),
    Documentation(info = "<html><body><h4>Ketamine_Abuhelwa2022_PD_hr</h4><p>The steady-state exposure-response curve of Abuhelwa AY et al., <i>Clinical pharmacology and therapeutics 112(3):720-729</i> 2022 (<a href=\"https://doi.org/10.1002/cpt.2640\">doi:10.1002/cpt.2640</a>) — Heart rate [beats/min] against ketamine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       72.7 beats/min drug-free response (baseline) (Baseline MADRS, BP, or HR, Q324)
  Emax  =        220 beats/min maximal effect term (Maximum drug effect, Q320)
  EC50  =       7580 ng/mL    exposure at half of the maximal effect term (Ketamine concentration at half maximum effect, Q321)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of ketamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 72.7   (drug-free)
  exposure = EC50 (7580 ng/mL)  response 182.7
  exposure -> infinity  response 292.7</pre></body></html>"));
end Ketamine_Abuhelwa2022_PD_hr;
