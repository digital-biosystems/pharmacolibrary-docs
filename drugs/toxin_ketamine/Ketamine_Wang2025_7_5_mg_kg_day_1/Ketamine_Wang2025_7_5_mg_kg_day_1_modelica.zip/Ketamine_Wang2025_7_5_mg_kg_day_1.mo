model Ketamine_Wang2025_7_5_mg_kg_day_1
  parameter Real Cl_ref = 2.5952777777777775e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.237727,
    adminMass = 7e-05,
    ka = 0.0009166666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>SD rats and Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>Ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>(R)-norketamine 223.7 g/mol (pubchem); Ketamine 237.727 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'R' (tmax)</li><li>unit_dimension_unknown: 'R' (AUClast)</li><li>unit_dimension_unknown: 'R' (AUC∞)</li><li>unit_dimension_unknown: 'R' (t1/2z)</li><li>unit_dimension_unknown: 'R' (MRT)</li><li>unit_dimension_unknown: 'R' (MRT)</li><li>dropped duplicate Q53 ('MRTINF_obs', value '0.381') — already have one for this compound</li><li>unit_dimension_unknown: 'R' (V3)</li><li>unit_dimension_unknown: 'R' (CL)</li><li>implicit units: 'Cmax' → ng/mL (from the popPK convention: 'The paper does not explicitly state the concentration unit in the provided text, but describes an LC-MS/MS quantitation ')</li><li>implicit units: 'Tmax' → h (from the popPK convention: 'Population PK and NCA time parameters like Tmax are standardly reported in hours (h). A value of 0.116 hours (approx 7 m')</li><li>implicit units: 'AUClast' → ng·h/mL (from the popPK convention: 'AUC is the integral of concentration (ng/mL) over time (h). Given the Cmax magnitude (~2300) and half-life (~0.7 h), an ')</li><li>implicit units: 'AUCINF_obs' → ng·h/mL (from the popPK convention: 'Same logic as AUClast. AUCINF_obs is slightly larger than AUClast (818 vs 817), which is consistent with minimal extrapo')</li><li>implicit units: 'T1/2' → h (from the popPK convention: 'Half-life (T1/2) is a time parameter, standardly reported in hours (h). 0.683 h (approx 41 minutes) is a plausible termi')</li><li>implicit units: 'MRTlast' → h (from the popPK convention: 'Mean Residence Time (MRT) is a time parameter, standardly reported in hours (h). It should be less than or equal to the ')</li><li>implicit units: 'Vz_obs' → L (from the popPK convention: 'Volume of distribution (Vz) is standardly reported in Liters (L) for absolute values or L/kg for normalized values. Give')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketamine_Wang2025_7_5_mg_kg_day_1;
