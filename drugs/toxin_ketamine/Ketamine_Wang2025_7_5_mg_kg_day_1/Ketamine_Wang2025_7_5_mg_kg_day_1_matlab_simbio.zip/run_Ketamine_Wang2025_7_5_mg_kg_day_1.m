% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Ketamine_Wang2025_7_5_mg_kg_day_1_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
