function p = Ketamine_Wang2025_7_5_mg_kg_day_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketamine   source: Wang_2025 / 7_5_mg_kg_day_1   route: oral
  % estimated (absent from source): F
  p.name  = 'Ketamine_Wang2025_7_5_mg_kg_day_1_params';
  p.drug  = 'ketamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 9.343;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
