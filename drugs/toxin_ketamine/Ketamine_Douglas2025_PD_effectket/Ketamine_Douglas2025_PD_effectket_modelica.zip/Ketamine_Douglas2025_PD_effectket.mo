model Ketamine_Douglas2025_PD_effectket
  "sigmoid_emax exposure-response sweep — Douglas_2025 :: EFFECTKET (Pain Score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.4,      // [pain units (0–10)]
    Emax = -0.11,  // [fractional pain units]
    EC50 = 4.16666666667e-10,  // [1/s; mg/kg/h × 2.77778e-10]
    gamma = 0.26,
    exposure_per_s = 2.77777777778e-10);   // 1 mg/kg/h per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><h4>Ketamine_Douglas2025_PD_effectket</h4><p>The steady-state exposure-response curve of Douglas C et al., <i>Paediatric anaesthesia 35(4):302-309</i> 2025 (<a href=\"https://doi.org/10.1111/pan.15063\">doi:10.1111/pan.15063</a>) — Pain Score against Ketamine mg/kg/h — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        6.4 pain units (0–10) drug-free response (baseline) (E0, Q324)
  Emax  =       0.11 fractional pain units maximal effect term (EMAX KETAMINE, Q323)
  EC50  =        1.5 mg/kg/h  exposure at half of the maximal effect term (ED50 KETAMINE, Q321)
  gamma =       0.26          Hill coefficient (HILLk, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/kg/h of Ketamine per second of simulated time (exposure is in 1/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.4   (drug-free)
  exposure = EC50 (1.5 mg/kg/h)  response 6.345
  exposure -> infinity  response 6.29</pre></body></html>"));
end Ketamine_Douglas2025_PD_effectket;
