// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ketamine_Simons2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {324.0},
    MM = 0.237727,
    adminMass = 5e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>healthy male and female volunteers</td></tr><tr><td>source_paper:</td><td>Simons_2022</td></tr><tr><td>measured_compound:</td><td>S-ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>S-ketamine 237.727 g/mol (pubchem); ketamine 237.727 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Baseline NRS'; source reconciliation required</li><li>column 'ν2 ±see' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 't½ke0 (min)'; source reconciliation required</li><li>column 'ω2 ±see' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'C50 (nmol/mL)'; source reconciliation required</li><li>column 'ω2 ±see' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'γ'; source reconciliation required</li><li>table representations disagree for 'σ'; source reconciliation required</li><li>table representations disagree for 'Baseline NRS'; source reconciliation required</li><li>column 'ν2 ±see' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'C50 (nmol/mL)'; source reconciliation required</li><li>column 'ω2 ±see' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'γ'; source reconciliation required</li><li>column 'ω2 ±see' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'σ'; source reconciliation required</li><li>table representations disagree for 'Baseline (N)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Ketamine_Simons2022_reference;
