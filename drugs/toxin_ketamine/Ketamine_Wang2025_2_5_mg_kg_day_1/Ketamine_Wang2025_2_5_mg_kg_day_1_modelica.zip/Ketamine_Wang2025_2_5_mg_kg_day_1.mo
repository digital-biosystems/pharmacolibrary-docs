// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Ketamine_Wang2025_2_5_mg_kg_day_1
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1879.2},
    MM = 0.237727,
    adminMass = 7e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>SD rats and Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>Ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>(R)-norketamine 223.7 g/mol (pubchem); Ketamine 237.727 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'R' (tmax)</li><li>unit_dimension_unknown: 'R' (AUClast)</li><li>unit_dimension_unknown: 'R' (AUC∞)</li><li>unit_dimension_unknown: 'R' (t1/2z)</li><li>unit_dimension_unknown: 'R' (MRT)</li><li>unit_dimension_unknown: 'R' (MRT)</li><li>dropped duplicate Q53 ('MRTINF_obs', value '0.383') — already have one for this compound</li><li>unit_dimension_unknown: 'R' (V3)</li><li>implicit units: 'Cmax' → ng/mL (from the popPK convention: 'The paper describes an LC-MS/MS method with an internal standard of 200 ng/mL and quantitation in plasma. While the spec')</li><li>implicit units: 'Tmax' → h (from the popPK convention: 'Tmax is a time parameter. A value of 0.116 suggests hours (approx 7 minutes) rather than minutes (0.116 min is very shor')</li><li>implicit units: 'AUClast' → ng*h/mL (from the popPK convention: 'AUC is the product of concentration (ng/mL) and time (h). Given Cmax is likely ng/mL and time is h, the unit is ng*h/mL ')</li><li>implicit units: 'AUCINF_obs' → ng*h/mL (from the popPK convention: 'Same as AUClast. Area under the curve to infinity shares the same units as AUClast.')</li><li>implicit units: 'T1/2' → h (from the popPK convention: 'Half-life is a time duration. A value of 0.522 fits hours (approx 31 minutes), which is plausible for ketamine in rats/d')</li><li>implicit units: 'MRTlast' → h (from the popPK convention: 'MRT (Mean Residence Time) is a time duration. A value of 0.366 fits hours (approx 22 minutes), consistent with the short')</li><li>implicit units: 'Vz_obs' → L/kg (from the popPK convention: 'Vz is Volume of Distribution. In preclinical PK (rats/dogs), volumes are typically reported per kilogram of body weight.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ketamine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Ketamine_Wang2025_2_5_mg_kg_day_1;
