model Ketamine_Wang2025_10_mg_kg
  parameter Real Cl_ref = 0.0001103861111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.237727,
    adminMass = 7e-05,
    ka = 0.0009166666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>SD rats and Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>Ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>(R)-norketamine 223.7 g/mol (pubchem); Ketamine 237.727 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q53 ('MRTINF_obs', value '0.684') — already have one for this compound</li><li>implicit units: 'Cmax' → ng/mL (from the popPK convention: 'For a 2.5 mg/kg IV dose in rats, a Cmax of 4710 corresponds to 4.71 µg/mL or 4710 ng/mL. In LC-MS/MS preclinical PK stud')</li><li>implicit units: 'Tmax' → h (from the popPK convention: 'The paper reports pharmacokinetic parameters including half-life (T1/2) and mean residence time (MRT) in hours (e.g., T1')</li><li>implicit units: 'AUClast' → ng*h/mL (from the popPK convention: 'AUC units are the product of concentration and time. Given the Cmax convention of ng/mL and time in h, AUC is ng*h/mL. V')</li><li>implicit units: 'AUCINF_obs' → ng*h/mL (from the popPK convention: 'Same reasoning as AUClast. AUCINF_obs is the extrapolated AUC, reported in the same units as AUClast. Standard units for')</li><li>implicit units: 'T1/2' → h (from the popPK convention: &quot;The paper text mentions 'half-life (T1/2)' and standard PK units for time parameters in rats are hours. 2.50 h is a reas&quot;)</li><li>implicit units: 'MRTlast' → h (from the popPK convention: 'MRT (Mean Residence Time) is a time parameter. In consistency with T1/2 and Tmax, the unit is hours (h).')</li><li>implicit units: 'Cl_obs' → mL/h/kg (from the popPK convention: 'Clearance in preclinical rodent studies is typically normalized by weight. The value 5677 is too large for L/h/kg (which')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ketamine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: '10 mg/kg' subgroup of Wang_2025 (paper reports 12 populations: (r)-ketamine, 1 mg/kg, 10 mg/kg, 2.5 mg/kg / day 1, 25 mg/kg / day 1, 3 mg/kg, 7.5 mg/kg / day 1, 7.5 mg/kg / day 7, dogs, humans, monkeys, rats)</li><li>row roles (LLM): model_class=noncompartmental; 13/13 row label(s) assigned, 0 linked by role; re-tagged Ketamine→parent ×5</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketamine_Wang2025_10_mg_kg;
