model Ketamine_Wang2025_3_mg_kg
  parameter Real Cl_ref = 2.2833333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.237727,
    adminMass = 7e-05,
    ka = 0.0009166666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>SD rats and Beagle dogs</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>Ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>(R)-norketamine 223.7 g/mol (pubchem); Ketamine 237.727 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q53 ('MRTINF_obs', value '0.410') — already have one for this compound</li><li>implicit units: 'Cmax' → ng/mL (from the popPK convention: 'The paper does not explicitly state the concentration unit for Cmax in the provided text. However, the internal standard')</li><li>implicit units: 'Tmax' → h (from the popPK convention: 'Tmax is a time parameter. The value 0.167 corresponds to 10 minutes (1/6 hour), which is a common sampling time point (e')</li><li>implicit units: 'AUClast' → ng·h/mL (from the popPK convention: 'AUC is the integral of concentration over time. Assuming Cmax is in ng/mL and time is in hours (standard for PK reportin')</li><li>implicit units: 'AUCINF_obs' → ng·h/mL (from the popPK convention: 'Same unit as AUClast. AUCINF is the extrapolated area, unit depends on concentration and time units. Based on the consis')</li><li>implicit units: 'T1/2' → h (from the popPK convention: 'T1/2 is a time duration. 0.885 h is a plausible half-life for ketamine in rats (terminal phase). The text lists it along')</li><li>implicit units: 'MRTlast' → h (from the popPK convention: 'MRT is mean residence time, measured in units of time. Consistent with Tmax and T1/2 being in hours.')</li><li>implicit units: 'Cl_obs' → mL/h (from the popPK convention: 'Clearance values in rats are often reported in mL/h or mL/min. A value of 8220 is too large for L/h (8220 L/h is impossi')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ketamine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: '3 mg/kg' subgroup of Wang_2025 (paper reports 12 populations: (r)-ketamine, 1 mg/kg, 10 mg/kg, 2.5 mg/kg / day 1, 25 mg/kg / day 1, 3 mg/kg, 7.5 mg/kg / day 1, 7.5 mg/kg / day 7, dogs, humans, monkeys, rats)</li><li>row roles (LLM): model_class=noncompartmental; 13/13 row label(s) assigned, 0 linked by role; re-tagged Ketamine→parent ×5</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketamine_Wang2025_3_mg_kg;
