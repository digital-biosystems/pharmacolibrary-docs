// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Stavudine_Zazo2022_liver
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2664.0},
    MM = 0.224216,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Zazo_2022</td></tr><tr><td>measured_compound:</td><td>stavudine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00406-t002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>stavudine 224.216 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for '1 AUC∞0'; source reconciliation required</li><li>table representations disagree for 'MRT(h)'; source reconciliation required</li><li>table representations disagree for 't1/2(h)'; source reconciliation required</li><li>dropped value-less row: 'AUC∞0 units: Plasma:'</li><li>dropped value-less row: 'tissues:'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=stavudine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'liver' subgroup of Zazo_2022 (paper reports 7 populations: brain, liver, p, plasma, spleen, stavudine-aunp, thymus)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Innes_2018's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Sinxadi_2010's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q189 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Stavudine_Zazo2022_liver;
