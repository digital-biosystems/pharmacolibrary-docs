function p = Stavudine_Zazo2022_p_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: stavudine   source: Zazo_2022 / p   route: oral
  % estimated (absent from source): F
  p.name  = 'Stavudine_Zazo2022_p_params';
  p.drug  = 'stavudine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 128.8;                % central volume [L]
  p.CL = 0.46;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.38;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.41;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
