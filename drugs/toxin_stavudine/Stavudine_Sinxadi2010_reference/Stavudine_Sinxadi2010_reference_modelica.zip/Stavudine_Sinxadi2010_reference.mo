model Stavudine_Sinxadi2010_reference
  parameter Real Cl_ref = 4.9444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.345 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.224216,
    adminMass = 3e-05,
    ka = 0.0030833333333333333,
    Tlag = 1476.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>HIV-1 infected African adults on stavudine treatment</td></tr><tr><td>source_paper:</td><td>Sinxadi_2010</td></tr><tr><td>measured_compound:</td><td>Stavudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>stavudine 224.216 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '2 hour glucose' — extend the ontology if this is a real PK parameter (source ['T1:row2:col1'])</li><li>dropped unlinked row (NIL): 'Lactate' — extend the ontology if this is a real PK parameter (source ['T1:row3:col1'])</li><li>dropped unlinked row (NIL): 'Triglycerides' — extend the ontology if this is a real PK parameter (source ['T1:row4:col1'])</li><li>dropped unlinked row (NIL): 'Lipoatrophy score' — extend the ontology if this is a real PK parameter (source ['T1:row5:col1'])</li><li>dropped unlinked row (NIL): 'Impaired fasting glucose' — extend the ontology if this is a real PK parameter (source ['Sinxadi_2010_table_1:row0:col1'])</li><li>dropped unlinked row (NIL): 'Impaired glucose tolerance' — extend the ontology if this is a real PK parameter (source ['Sinxadi_2010_table_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Hyperlactataemia' — extend the ontology if this is a real PK parameter (source ['Sinxadi_2010_table_1:row2:col1'])</li><li>dropped unlinked row (NIL): 'Hypertriglyceridaemia' — extend the ontology if this is a real PK parameter (source ['Sinxadi_2010_table_1:row3:col1'])</li><li>dropped unlinked row (NIL): 'Lipoatrophy score >0' — extend the ontology if this is a real PK parameter (source ['Sinxadi_2010_table_1:row4:col1'])</li><li>dropped value-less row: 'Table 1. Univariate linear regression analysis of stavudine log-transformed AUC and metabolic parameters'</li><li>table mostly unlinked (9/10 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q27 ('apparent clearance'=17.8) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('apparent volume of distribution'=33.5) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('first-order absorption rate constant'=11.1) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('absorption lag time'=0.41) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Stavudine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Stavudine_Sinxadi2010_reference;
