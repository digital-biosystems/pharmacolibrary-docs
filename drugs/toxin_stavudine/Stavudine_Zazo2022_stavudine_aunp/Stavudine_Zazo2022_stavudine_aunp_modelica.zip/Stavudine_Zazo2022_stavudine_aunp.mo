model Stavudine_Zazo2022_stavudine_aunp
  parameter Real Cl_ref = 1.277777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1288 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.224216,
    adminMass = 8e-05,
    ka = 0.0006611111111111111,
    Tlag = 1476.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Zazo_2022</td></tr><tr><td>measured_compound:</td><td>stavudine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00406-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>stavudine 224.216 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Group'; source reconciliation required</li><li>table representations disagree for '1 AUC∞0'; source reconciliation required</li><li>table representations disagree for 'MRT(h)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Group' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00406-t002:row2:col1', 'pharmaceutics-14-00406-t002:row4:col1', 'pharmaceutics-14-00406-t002:row6:col1', 'pharmaceutics-14-00406-t002:row8:col1', 'pharmaceutics-14-00406-t002:row10:col1'])</li><li>dropped value-less row: 'AUC∞0 units: Plasma:'</li><li>dropped value-less row: 'tissues:'</li><li>salvaged Q22 ('Cl (solution)'=0.46) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Vd (solution)'=1.84) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=stavudine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'stavudine-aunp' subgroup of Zazo_2022 (paper reports 7 populations: brain, liver, p, plasma, spleen, stavudine-aunp, thymus)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Innes_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Stavudine_Zazo2022_stavudine_aunp;
