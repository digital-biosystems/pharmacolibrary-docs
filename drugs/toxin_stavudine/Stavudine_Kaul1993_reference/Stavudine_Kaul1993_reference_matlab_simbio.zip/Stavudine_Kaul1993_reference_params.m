function p = Stavudine_Kaul1993_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: stavudine   source: Kaul_1993 / reference   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Stavudine_Kaul1993_reference_params';
  p.drug  = 'stavudine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.6;                % central volume [L]
  p.CL = 44.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.38;                % absorption rate [1/h]
  p.F  = 0.8;                 % bioavailability [0-1]
  p.Tlag = 0.41;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
