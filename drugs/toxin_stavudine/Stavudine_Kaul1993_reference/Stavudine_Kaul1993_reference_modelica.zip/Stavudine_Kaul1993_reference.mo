model Stavudine_Kaul1993_reference
  parameter Real Cl_ref = 1.2444444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0476 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 80.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.224216,
    adminMass = 8e-05,
    ka = 0.0006611111111111111,
    Tlag = 1476.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>cynomolgus monkeys</td></tr><tr><td>source_paper:</td><td>Kaul_1993</td></tr><tr><td>measured_compound:</td><td>Stavudine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>stavudine 224.216 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'urinary recovery' → Q44: printed without a unit and above 1 — read as a percentage</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Stavudine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Innes_2018's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Sinxadi_2010's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Stavudine_Kaul1993_reference;
