% Run: build params, simulate 0..24.0 h, plot every molecule + save Stavudine_Zazo2022_thymus.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Stavudine_Zazo2022_thymus.m
here = fileparts(mfilename('fullpath'));
p = Stavudine_Zazo2022_thymus_params();
out = simulate_network(p, 0:0.05:24.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('stavudine — Zazo_2022 (retention function)');
print(fig, fullfile(here, 'Stavudine_Zazo2022_thymus.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Stavudine_Zazo2022_thymus.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Stavudine_Zazo2022_thymus.json'), 'w');
try
  s.model = 'Stavudine_Zazo2022_thymus'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Stavudine_Zazo2022_thymus"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Stavudine_Zazo2022_thymus.png, Stavudine_Zazo2022_thymus.csv, Stavudine_Zazo2022_thymus.json\n');
