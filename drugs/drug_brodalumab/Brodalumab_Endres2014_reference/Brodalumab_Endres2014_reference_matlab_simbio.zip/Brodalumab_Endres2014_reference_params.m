function p = Brodalumab_Endres2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brodalumab   source: Endres_2014 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Brodalumab_Endres2014_reference_params';
  p.drug  = 'brodalumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.62;                % central volume [L]
  p.CL = 0.009292;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.037833;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
