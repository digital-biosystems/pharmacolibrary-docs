model Brodalumab_Endres2014_reference
  parameter Real Cl_ref = 2.5810185185185186e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00462 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.0509259259259259e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brodalumab</h4><p>Brodalumab is a monoclonal antibody used to treat psoriasis. It is authorised in the European Union for psoriasis and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4972934\">Wikidata Q4972934</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brodalumab</td></tr><tr><td>population:</td><td>healthy adults and adults with psoriasis</td></tr><tr><td>source_paper:</td><td>Endres_2014</td></tr><tr><td>measured_compound:</td><td>brodalumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'V(max)' → Q61 (unit '[mass] / [time]' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q61 ('V(max)', value 5.4) — already have one for this compound</li><li>covariate weight for allometric_exponent from footnote/prose kept as documentation only (['Endres_2014:abstract'])</li><li>covariate weight for allometric_exponent from footnote/prose kept as documentation only (['Endres_2014:abstract'])</li><li>dropped unlinked row (NIL): 'BW effect exponent on V(max)' — extend the ontology if this is a real PK parameter (source ['Endres_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=brodalumab</li><li>molar mass: none found for 'brodalumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Rodríguez-Fernández_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Brodalumab_Endres2014_reference;
