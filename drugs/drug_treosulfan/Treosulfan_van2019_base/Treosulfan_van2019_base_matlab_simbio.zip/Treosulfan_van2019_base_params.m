function p = Treosulfan_van2019_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: treosulfan   source: van_2019 / base   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Treosulfan_van2019_base_params';
  p.drug  = 'treosulfan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.77;                % central volume [L]
  p.CL = 5.94;                % clearance [L/h]
  p.Vp = [8.73];             % peripheral volumes [L]
  p.Q  = [24.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
