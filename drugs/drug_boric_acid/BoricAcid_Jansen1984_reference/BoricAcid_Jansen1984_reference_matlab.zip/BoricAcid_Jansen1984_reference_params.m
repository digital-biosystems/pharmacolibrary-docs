function p = BoricAcid_Jansen1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: boric_acid   source: Jansen_1984 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'BoricAcid_Jansen1984_reference_params';
  p.drug  = 'boric_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 17.57;                % central volume [L]
  p.CL = 54.6;                % clearance [L/h]
  p.Vp = [31.92];             % peripheral volumes [L]
  p.Q  = [3.996];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
