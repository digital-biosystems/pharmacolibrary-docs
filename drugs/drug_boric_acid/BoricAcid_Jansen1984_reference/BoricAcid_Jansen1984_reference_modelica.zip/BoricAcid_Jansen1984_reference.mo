model BoricAcid_Jansen1984_reference
  parameter Real Cl_ref = 1.5166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.017570000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.061833,
    adminMass = 1e-05,
    k12 = 6.317586795674444e-05,
    k21 = 3.477443609022556e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About boric_acid</h4><p>Boric acid is an antiseptic used against infections, including ear infections. It remains in use as an approved medicine, mainly in ear-drop preparations for the ear.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72451064\">Wikidata Q72451064</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>boric_acid</td></tr><tr><td>population:</td><td>healthy adult male volunteers</td></tr><tr><td>source_paper:</td><td>Jansen_1984</td></tr><tr><td>measured_compound:</td><td>boric acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>boric acid 61.833 g/mol (drugbank); boric_acid 61.833 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '% of dose' (fe)</li><li>unit_dimension_unknown: 'ml/min/1.73 m2' (CL)</li><li>implicit units: 'Cltot' → L/h (from the popPK convention: 'No unit stated in text or table footnotes; total clearance in population PK is conventionally expressed in L/h, and 54.6')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=boric acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q30 (Q) from Syvänen_2012's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end BoricAcid_Jansen1984_reference;
