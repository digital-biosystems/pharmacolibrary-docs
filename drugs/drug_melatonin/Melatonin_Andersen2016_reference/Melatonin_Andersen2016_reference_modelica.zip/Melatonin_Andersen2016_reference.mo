model Melatonin_Andersen2016_reference
  parameter Real Cl_ref = 2.4629595248322926e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08399999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2322783,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About melatonin</h4><p>Melatonin is a melatonin receptor agonist used to treat sleep initiation and maintenance disorders and jet lag. It is administered orally. It is authorised in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q180912\">Wikidata Q180912</a>, DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>melatonin</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Andersen_2016</td></tr><tr><td>measured_compound:</td><td>melatonin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>melatonin 232.278 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: '6.0 (3.1)' (captured trailing unit '3.1' for child rows)</li><li>implicit units: 't 1/2 elimination min' → min (from the paper text: '&quot;Mean t1/2 elimination was 39.4 (3.6) min&quot; for iv melatonin.')</li><li>implicit units: 'V d l kg-1' → L/kg (from the paper text: '&quot;mean Vd 1.2 (0.6) l kg-1&quot;.')</li><li>implicit units: 'CL l min-1 kg-1' → L/min/kg (from the paper text: '&quot;mean CL 0.0218 (0.0102) l min-1 kg-1&quot;.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=melatonin</li><li>gap-filled Q22 (CL) from Wang_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=88.6665 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Melatonin_Andersen2016_reference;
