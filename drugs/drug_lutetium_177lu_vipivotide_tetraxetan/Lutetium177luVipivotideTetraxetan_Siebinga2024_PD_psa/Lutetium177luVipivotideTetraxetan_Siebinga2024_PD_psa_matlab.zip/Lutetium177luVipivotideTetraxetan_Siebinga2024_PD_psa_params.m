function p = Lutetium177luVipivotideTetraxetan_Siebinga2024_PD_psa_params()
% Lutetium177luVipivotideTetraxetan_Siebinga2024_PD_psa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lutetium_177lu_vipivotide_tetraxetan Siebinga_2024::PSA: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one MBq/L per second, in SI inside (kg/m3, s). Response PSA in µg/L. Driver: [177Lu]Lu-PSMA-I&T (not_resolved).
p.E0 = 0.00013999999999999996;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.00335;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
