model Lutetium177luVipivotideTetraxetan_Siebinga2024_PD_psa
  "linear exposure-response sweep — Siebinga_2024 :: PSA (PSA)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.00014,      // [kg/m3; µg/L × 1e-06]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.00335   "[L·day−1·GBq−1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // off_target_driver: driver compound '[177Lu]Lu-PSMA-I&T' is not 'lutetium_177lu_vipivotide_tetraxetan' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lutetium_177lu_vipivotide_tetraxetan</h4><p>Lutetium vipivotide tetraxetan is a therapeutic radiopharmaceutical used to treat prostate cancer, including castration-resistant disease. It is authorised in the European Union and is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q111353661\">Wikidata Q111353661</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lutetium177luVipivotideTetraxetan_Siebinga2024_PD_psa</h4><p>The steady-state exposure-response curve of Siebinga H et al., <i>EJNMMI physics 11(1):39</i> 2024 (<a href=\"https://doi.org/10.1186/s40658-024-00642-2\">doi:10.1186/s40658-024-00642-2</a>) — PSA [µg/L] against [177Lu]Lu-PSMA-I&amp;T MBq/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        140 µg/L     drug-free response (baseline) (Baseline PSA, Q324)
  slope =    0.00335 L·day−1·GBq−1 change in response per unit of exposure (Direct drug-induced effect, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one MBq/L of [177Lu]Lu-PSMA-I&amp;T per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.00014   (drug-free)</pre></body></html>"));
end Lutetium177luVipivotideTetraxetan_Siebinga2024_PD_psa;
