// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model CadmiumTelluride_Wang2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {28800.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cadmium_telluride</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Wang_2026</td></tr><tr><td>measured_compound:</td><td>Cadmium telluride quantum dots</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cadmium_telluride 240.01 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cadmium telluride quantum dots</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: no plausible PubChem entry for 'Cadmium telluride quantum dots' ('Cadmium telluride quantum dots') — left in mass units</li><li>molar mass: none found for 'Cadmium telluride quantum dots' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 288.0));
end CadmiumTelluride_Wang2026_reference;
