function p = Danicopan_Chen2026_PD_ap_params()
% Danicopan_Chen2026_PD_ap_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% danicopan Chen_2026::AP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response AP in %. Driver: danicopan (conc_no_pk).
p.E0 = 0.29100000000000004;
p.Emax = -0.0305;
p.EC50 = 1.2e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 120.0;
p.form = 'E0 + Emax*frac';
end
