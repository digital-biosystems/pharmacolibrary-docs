model Danicopan_Chen2026_PD_ap
  "emax exposure-response sweep — Chen_2026 :: AP (alternative pathway (AP) activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.291,      // [1; % × 0.01]
    Emax = -0.0305,  // [1; % × 0.01]
    EC50 = 1.2e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 120, Interval = 0.24),
    Documentation(info = "<html><body><!-- drug-about --><h4>About danicopan</h4><p>Danicopan is a complement inhibitor used to treat haemolysis in paroxysmal nocturnal haemoglobinuria. It is an approved medicine, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q124407181\">Wikidata Q124407181</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Danicopan_Chen2026_PD_ap</h4><p>The steady-state exposure-response curve of Chen J et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(3):e70209</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70209\">doi:10.1002/psp4.70209</a>) — alternative pathway (AP) activity [%] against danicopan ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       29.1 %        drug-free response (baseline) (AP 0, Q324)
  Emax  =       3.05 %        maximal effect term (I max, Q323)
  EC50  =         12 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of danicopan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.291   (drug-free)
  exposure = EC50 (12 ng/mL)  response 0.2758
  exposure -> infinity  response 0.2605</pre></body></html>"));
end Danicopan_Chen2026_PD_ap;
