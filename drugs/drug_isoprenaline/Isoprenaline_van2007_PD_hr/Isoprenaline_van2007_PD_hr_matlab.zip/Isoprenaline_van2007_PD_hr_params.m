function p = Isoprenaline_van2007_PD_hr_params()
% Isoprenaline_van2007_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoprenaline van_2007::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml À1 per second, in SI inside (kg/m3, s). Response HR in b.p.m.. Driver: isoprenaline (not_resolved).
p.E0 = 374.0;
p.Emax = 130.0;
p.EC50 = 1.38e-08;
p.gamma = 1.18;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.14;
p.form = 'E0 + Emax*frac';
end
