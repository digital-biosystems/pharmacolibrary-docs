model Isoprenaline_van2007_PD_hr
  "sigmoid_emax exposure-response sweep — van_2007 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 374,      // [b.p.m.]
    Emax = 130,  // [b.p.m.]
    EC50 = 1.38e-08,  // [kg/m3; ng ml À1 × 1e-06]
    gamma = 1.18,
    exposure_per_s = 1e-06);   // 1 ng ml À1 per second
  annotation(experiment(StartTime = 0, StopTime = 0.14, Interval = 0.00028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About isoprenaline</h4><p>Isoprenaline is a sympathomimetic beta-agonist used as a bronchodilator for bronchospasm and as a cardiotonic agent, for example in congenital heart block. It is an approved medicine, but it is not authorised centrally in the European Union and today is used only rarely, mainly in specialised hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415550\">Wikidata Q415550</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Isoprenaline_van2007_PD_hr</h4><p>The steady-state exposure-response curve of van Steeg TJ et al., <i>British journal of pharmacology 151(3):356–366</i> 2007 (<a href=\"https://doi.org/10.1038/sj.bjp.0707234\">doi:10.1038/sj.bjp.0707234</a>) — heart rate [b.p.m.] against isoprenaline ng ml À1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        374 b.p.m.   drug-free response (baseline) (E 0, Q324)
  Emax  =        130 b.p.m.   maximal effect term (E max, Q320)
  EC50  =     0.0138 ng ml À1 exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       1.18          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml À1 of isoprenaline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 374   (drug-free)
  exposure = EC50 (0.0138 ng ml À1)  response 439
  exposure -> infinity  response 504</pre></body></html>"));
end Isoprenaline_van2007_PD_hr;
