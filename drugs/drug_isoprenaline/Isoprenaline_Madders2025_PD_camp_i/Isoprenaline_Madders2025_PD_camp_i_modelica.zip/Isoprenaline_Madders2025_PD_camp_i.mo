model Isoprenaline_Madders2025_PD_camp_i
  "emax exposure-response sweep — Madders_2025 :: [cAMP]i (cytosolic cAMP)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.689,  // [1; % × 0.01]
    EC50 = 4.6,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><!-- drug-about --><h4>About isoprenaline</h4><p>Isoprenaline is a sympathomimetic beta-agonist used as a bronchodilator for bronchospasm and as a cardiotonic agent, for example in congenital heart block. It is an approved medicine, but it is not authorised centrally in the European Union and today is used only rarely, mainly in specialised hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415550\">Wikidata Q415550</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Isoprenaline_Madders2025_PD_camp_i</h4><p>The steady-state exposure-response curve of Madders GWP et al., <i>eLife 14:e84243</i> 2025 (<a href=\"https://doi.org/10.7554/elife.84243\">doi:10.7554/elife.84243</a>) — cytosolic cAMP [%] against isoprenaline nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      168.9 %        maximal effect term (Emax, Q320)
  EC50  =        4.6 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of isoprenaline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.6 nM)  response 0.8445
  exposure -> infinity  response 1.689</pre></body></html>"));
end Isoprenaline_Madders2025_PD_camp_i;
