function p = Isoprenaline_Madders2025_PD_camp_i_params()
% Isoprenaline_Madders2025_PD_camp_i_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoprenaline Madders_2025::cAMP_i: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response [cAMP]i in %. Driver: isoprenaline (conc_no_pk).
p.E0 = 0.0;
p.Emax = 1.689;
p.EC50 = 4.6;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 46.0;
p.form = 'E0 + Emax*frac';
end
