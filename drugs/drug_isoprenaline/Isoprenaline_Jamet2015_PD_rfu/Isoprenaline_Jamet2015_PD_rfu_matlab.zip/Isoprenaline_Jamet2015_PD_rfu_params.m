function p = Isoprenaline_Jamet2015_PD_rfu_params()
% Isoprenaline_Jamet2015_PD_rfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoprenaline Jamet_2015::RFU: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response RFU in RFU. Driver: isoprenaline (conc_no_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.42;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 4.2;
p.form = 'E0 + Emax*frac';
end
