model Isoprenaline_Jamet2015_PD_rfu
  "emax exposure-response sweep — Jamet_2015 :: RFU (isoprenaline-induced calcium response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 0.42,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.2, Interval = 0.0084),
    Documentation(info = "<html><body><!-- drug-about --><h4>About isoprenaline</h4><p>Isoprenaline is a sympathomimetic beta-agonist used as a bronchodilator for bronchospasm and as a cardiotonic agent, for example in congenital heart block. It is an approved medicine, but it is not authorised centrally in the European Union and today is used only rarely, mainly in specialised hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415550\">Wikidata Q415550</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Isoprenaline_Jamet2015_PD_rfu</h4><p>The steady-state exposure-response curve of Jamet S et al., <i>PloS one 10(10):e0141696</i> 2015 (<a href=\"https://doi.org/10.1371/journal.pone.0141696\">doi:10.1371/journal.pone.0141696</a>) — isoprenaline-induced calcium response [RFU] against isoprenaline nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Maximum response, Q320)
  EC50  =       0.42 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of isoprenaline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.42 nM)  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Isoprenaline_Jamet2015_PD_rfu;
