model Isoprenaline_LacerdaJnior2025_PD_uterine_relaxation
  "emax exposure-response sweep — Lacerda-Júnior_2025 :: uterine relaxation (uterine relaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 15.1,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 160, Interval = 0.32),
    Documentation(info = "<html><body><!-- drug-about --><h4>About isoprenaline</h4><p>Isoprenaline is a sympathomimetic beta-agonist used as a bronchodilator for bronchospasm and as a cardiotonic agent, for example in congenital heart block. It is an approved medicine, but it is not authorised centrally in the European Union and today is used only rarely, mainly in specialised hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415550\">Wikidata Q415550</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Isoprenaline_LacerdaJnior2025_PD_uterine_relaxation</h4><p>The steady-state exposure-response curve of Lacerda-Júnior FF et al., <i>Pharmaceuticals (Basel, Switzerland) 18(8)</i> 2025 (<a href=\"https://doi.org/10.3390/ph18081191\">doi:10.3390/ph18081191</a>) — uterine relaxation [%] against isoprenaline — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q320)
  EC50  =       15.1          exposure at half of the maximal effect term (pEC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of isoprenaline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (15.1 )  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Isoprenaline_LacerdaJnior2025_PD_uterine_relaxation;
