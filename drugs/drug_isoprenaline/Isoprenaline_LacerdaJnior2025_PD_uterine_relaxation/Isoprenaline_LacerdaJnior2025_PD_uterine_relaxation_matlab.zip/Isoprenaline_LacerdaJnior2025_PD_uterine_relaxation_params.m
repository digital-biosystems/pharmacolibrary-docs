function p = Isoprenaline_LacerdaJnior2025_PD_uterine_relaxation_params()
% Isoprenaline_LacerdaJnior2025_PD_uterine_relaxation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoprenaline Lacerda-Júnior_2025::uterine_relaxation: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response uterine relaxation in %. Driver: isoprenaline (not_resolved).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 15.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 160.0;
p.form = 'E0 + Emax*frac';
end
