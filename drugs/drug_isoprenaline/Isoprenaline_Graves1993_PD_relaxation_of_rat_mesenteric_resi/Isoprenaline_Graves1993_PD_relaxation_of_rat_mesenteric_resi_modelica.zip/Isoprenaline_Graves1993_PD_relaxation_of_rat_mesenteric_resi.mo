model Isoprenaline_Graves1993_PD_relaxation_of_rat_mesenteric_resi
  "emax exposure-response sweep — Graves_1993 :: relaxation of rat mesenteric resistance arteries pre-contracted with K+ (relaxation of rat mesenteric resistance arteries pre-contracted with K+)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.6679,  // [1; % × 0.01]
    EC50 = 8.03,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 81, Interval = 0.162),
    Documentation(info = "<html><body><!-- drug-about --><h4>About isoprenaline</h4><p>Isoprenaline is a sympathomimetic beta-agonist used as a bronchodilator for bronchospasm and as a cardiotonic agent, for example in congenital heart block. It is an approved medicine, but it is not authorised centrally in the European Union and today is used only rarely, mainly in specialised hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415550\">Wikidata Q415550</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Isoprenaline_Graves1993_PD_relaxation_of_rat_mesenteric_resi</h4><p>The steady-state exposure-response curve of Graves J et al., <i>British journal of pharmacology 108(3):631–637</i> 1993 (<a href=\"https://doi.org/10.1111/j.1476-5381.1993.tb12853.x\">doi:10.1111/j.1476-5381.1993.tb12853.x</a>) — relaxation of rat mesenteric resistance arteries pre-contracted with K+ [%] against isoprenaline M — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      66.79 %        maximal effect term (maximum relaxation, Q320)
  EC50  =       8.03 M        exposure at half of the maximal effect term (pEC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of isoprenaline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (8.03 M)  response 0.334
  exposure -> infinity  response 0.6679</pre></body></html>"));
end Isoprenaline_Graves1993_PD_relaxation_of_rat_mesenteric_resi;
