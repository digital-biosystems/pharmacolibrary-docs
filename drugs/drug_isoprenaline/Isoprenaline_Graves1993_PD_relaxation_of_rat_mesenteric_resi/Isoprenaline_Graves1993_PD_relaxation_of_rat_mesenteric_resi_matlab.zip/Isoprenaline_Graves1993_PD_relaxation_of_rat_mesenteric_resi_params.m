function p = Isoprenaline_Graves1993_PD_relaxation_of_rat_mesenteric_resi_params()
% Isoprenaline_Graves1993_PD_relaxation_of_rat_mesenteric_resi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoprenaline Graves_1993::relaxation_of_rat_mesenteric_resistance_arteries_pre_contracted_with_K: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response relaxation of rat mesenteric resistance arteries pre-contracted with K+ in %. Driver: isoprenaline (not_resolved).
p.E0 = 0.0;
p.Emax = 0.6679;
p.EC50 = 8.03;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 81.0;
p.form = 'E0 + Emax*frac';
end
