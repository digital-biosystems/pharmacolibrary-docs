function p = Mecamylamine_AlvarezJimenez2017_PD_0_back_params()
% Mecamylamine_AlvarezJimenez2017_PD_0_back_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mecamylamine Alvarez-Jimenez_2017::0_back: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg•L -1 per second, in SI inside (kg/m3, s). Response 0-back in % correct answers. Driver: mecamylamine (pk_record).
p.E0 = 3.66;
p.Emax = -0.00377;
p.EC50 = 8.74;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 88.0;
p.form = 'E0 + Emax*frac';
end
