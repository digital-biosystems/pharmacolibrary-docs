model Mecamylamine_AlvarezJimenez2017_PD_0_back
  "emax exposure-response sweep — Alvarez-Jimenez_2017 :: 0-back (Correct Answers of the 0-back (percentage of correct answers))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.66,      // [% correct answers]
    Emax = -0.00377,  // [1; % × 0.01]
    EC50 = 8.74,  // [μg•L -1]
    gamma = 1,
    exposure_per_s = 1);   // 1 μg•L -1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μg•L -1' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 88, Interval = 0.176),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mecamylamine</h4><p>Mecamylamine is a ganglion-blocking antihypertensive drug that has been used to treat arterial and malignant hypertension, and has also been studied for Tourette syndrome. It is an approved drug, though it is no longer widely used as an antihypertensive; it is also listed as investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3332124\">Wikidata Q3332124</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mecamylamine_AlvarezJimenez2017_PD_0_back</h4><p>The steady-state exposure-response curve of Alvarez-Jimenez R et al., <i>Journal of psychopharmacology (Oxford, England) 31(2):192–203</i> 2017 (<a href=\"https://doi.org/10.1177/0269881116681417\">doi:10.1177/0269881116681417</a>) — Correct Answers of the 0-back (percentage of correct answers) [% correct answers] against mecamylamine μg•L -1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       3.66 % correct answers drug-free response (baseline) (BL, Q324)
  Emax  =      0.377 %        maximal effect term (E max, Q323)
  EC50  =       8.74 μg•L -1  exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg•L -1 of mecamylamine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.66   (drug-free)
  exposure = EC50 (8.74 μg•L -1)  response 3.658
  exposure -> infinity  response 3.656</pre></body></html>"));
end Mecamylamine_AlvarezJimenez2017_PD_0_back;
