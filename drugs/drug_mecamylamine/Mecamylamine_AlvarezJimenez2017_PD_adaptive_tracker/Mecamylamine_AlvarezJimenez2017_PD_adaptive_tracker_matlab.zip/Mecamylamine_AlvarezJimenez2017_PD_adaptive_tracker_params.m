function p = Mecamylamine_AlvarezJimenez2017_PD_adaptive_tracker_params()
% Mecamylamine_AlvarezJimenez2017_PD_adaptive_tracker_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mecamylamine Alvarez-Jimenez_2017::Adaptive_tracker: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg L -1 per second, in SI inside (kg/m3, s). Response Adaptive tracker in %. Driver: mecamylamine (pk_record).
p.E0 = 29.0;
p.Emax = -0.0027;
p.EC50 = 9.719999999999998e-05;
p.gamma = 1.58;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 980.0;
p.form = 'E0 + Emax*frac';
end
