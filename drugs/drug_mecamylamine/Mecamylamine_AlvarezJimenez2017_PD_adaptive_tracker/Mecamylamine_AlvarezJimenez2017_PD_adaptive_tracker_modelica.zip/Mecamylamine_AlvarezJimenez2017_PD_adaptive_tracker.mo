model Mecamylamine_AlvarezJimenez2017_PD_adaptive_tracker
  "sigmoid_emax exposure-response sweep — Alvarez-Jimenez_2017 :: Adaptive tracker (Percentage of accuracy of the adaptive tracker test)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 29,      // [-]
    Emax = -0.0027,  // [1; % × 0.01]
    EC50 = 9.72e-05,  // [kg/m3; μg L -1 × 1e-06]
    gamma = 1.58,
    exposure_per_s = 1e-06);   // 1 μg L -1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 980, Interval = 1.96),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mecamylamine</h4><p>Mecamylamine is a ganglion-blocking antihypertensive drug that has been used to treat arterial and malignant hypertension, and has also been studied for Tourette syndrome. It is an approved drug, though it is no longer widely used as an antihypertensive; it is also listed as investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3332124\">Wikidata Q3332124</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mecamylamine_AlvarezJimenez2017_PD_adaptive_tracker</h4><p>The steady-state exposure-response curve of Alvarez-Jimenez R et al., <i>Journal of psychopharmacology (Oxford, England) 31(2):192–203</i> 2017 (<a href=\"https://doi.org/10.1177/0269881116681417\">doi:10.1177/0269881116681417</a>) — Percentage of accuracy of the adaptive tracker test [%] against mecamylamine μg L -1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         29 -        drug-free response (baseline) (BL, Q324)
  Emax  =       0.27 %        maximal effect term (E max, Q323)
  EC50  =       97.2 μg L -1  exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       1.58          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg L -1 of mecamylamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 29   (drug-free)
  exposure = EC50 (97.2 μg L -1)  response 29
  exposure -> infinity  response 29</pre></body></html>"));
end Mecamylamine_AlvarezJimenez2017_PD_adaptive_tracker;
