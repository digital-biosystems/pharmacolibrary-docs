function p = Glucose_Liu2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glucose   source: Liu_2017 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Glucose_Liu2017_reference_params';
  p.drug  = 'glucose';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 23.96;                % central volume [L]
  p.CL = 7.8;                % clearance [L/h]
  p.Vp = [104.69];             % peripheral volumes [L]
  p.Q  = [9.85];             % inter-compartmental clearances [L/h]
  p.ka = 9.57;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.09;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
