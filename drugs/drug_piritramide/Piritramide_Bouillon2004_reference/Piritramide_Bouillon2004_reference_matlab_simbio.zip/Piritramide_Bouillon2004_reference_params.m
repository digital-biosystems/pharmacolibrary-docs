function p = Piritramide_Bouillon2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: piritramide   source: Bouillon_2004 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Piritramide_Bouillon2004_reference_params';
  p.drug  = 'piritramide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 47.9;                % central volume [L]
  p.CL = 66.5;                % clearance [L/h]
  p.Vp = [402.0];             % peripheral volumes [L]
  p.Q  = [215.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 45.0;             % dose [mg]
end
