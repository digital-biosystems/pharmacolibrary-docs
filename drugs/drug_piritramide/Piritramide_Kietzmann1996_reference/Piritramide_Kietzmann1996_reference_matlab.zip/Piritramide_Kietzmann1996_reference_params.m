function p = Piritramide_Kietzmann1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: piritramide   source: Kietzmann_1996 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Piritramide_Kietzmann1996_reference_params';
  p.drug  = 'piritramide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 32.76;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
