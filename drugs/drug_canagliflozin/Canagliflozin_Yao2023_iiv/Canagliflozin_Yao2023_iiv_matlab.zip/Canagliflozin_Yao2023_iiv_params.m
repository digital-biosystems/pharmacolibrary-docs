function p = Canagliflozin_Yao2023_iiv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canagliflozin   source: Yao_2023 / iiv   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Canagliflozin_Yao2023_iiv_params';
  p.drug  = 'canagliflozin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.63;                % central volume [L]
  p.CL = 5.69;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
