model Canagliflozin_Yao2023_iiv
  parameter Real Cl_ref = 1.5805555555555558e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00563 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>canagliflozin</td></tr><tr><td>population:</td><td>healthy subjects and patients with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Yao_2023</td></tr><tr><td>measured_compound:</td><td>dapagliflozin, canagliflozin, empagliflozin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412934-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dapagliflozin, canagliflozin, empagliflozin</li><li>population split: 'iiv (%)' subgroup of Yao_2023 (paper reports 2 populations: estimates, iiv (%))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Canagliflozin_Yao2023_iiv;
