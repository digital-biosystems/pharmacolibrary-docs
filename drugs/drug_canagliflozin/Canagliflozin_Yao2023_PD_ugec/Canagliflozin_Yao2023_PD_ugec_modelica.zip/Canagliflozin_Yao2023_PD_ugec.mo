model Canagliflozin_Yao2023_PD_ugec
  "emax exposure-response sweep — Yao_2023 :: ΔUGEc (change of urine glucose excretion (UGE) from baseline normalized by FPG)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0606,  // [m3; g/(mg/dL) × 0.1]
    EC50 = 2310,  // [ng/mL·h]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng/mL·h per second
  // exposure_unit_unresolved: 'ng/mL·h' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 24000, Interval = 48),
    Documentation(info = "<html><body><!-- drug-about --><h4>About canagliflozin</h4><p>Canagliflozin is an anti-diabetic medicine used to treat type 2 diabetes mellitus. It is an approved SGLT2 inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5030940\">Wikidata Q5030940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Canagliflozin_Yao2023_PD_ugec</h4><p>The steady-state exposure-response curve of Yao X et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(4):487–499</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12934\">doi:10.1002/psp4.12934</a>) — change of urine glucose excretion (UGE) from baseline normalized by FPG [g/(mg/dL)] against canagliflozin ng/mL·h — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.606 g/(mg/dL) maximal effect term (Emax, Q320)
  EC50  =       2310 ng/mL·h  exposure at half of the maximal effect term (Cana‐EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL·h of canagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2310 ng/mL·h)  response 0.0303
  exposure -> infinity  response 0.0606</pre></body></html>"));
end Canagliflozin_Yao2023_PD_ugec;
