function p = Nebivolol_Marques2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nebivolol   source: Marques_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Nebivolol_Marques2022_reference_params';
  p.drug  = 'nebivolol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.21;                % central volume [L]
  p.CL = 0.22;                % clearance [L/h]
  p.Vp = [7.12];             % peripheral volumes [L]
  p.Q  = [0.59];             % inter-compartmental clearances [L/h]
  p.ka = 2.06;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.3;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
