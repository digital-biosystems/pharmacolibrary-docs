model Iohexol_Taubert2018_reference
  parameter Real Cl_ref = 9.566666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0054 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8211379,
    adminMass = 0.003235,
    k12 = 0.0006172839506172839,
    k21 = 0.00101010101010101
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iohexol</h4><p>Iohexol is an iodinated X-ray contrast agent used to visualise tissues and blood vessels during imaging procedures. It is widely used in medical imaging and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410683\">Wikidata Q410683</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iohexol</td></tr><tr><td>population:</td><td>elderly patients (Berlin Initiative Study)</td></tr><tr><td>source_paper:</td><td>Taubert_2018</td></tr><tr><td>measured_compound:</td><td>iohexol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>iohexol 821.138 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Method'</li><li>dropped value-less row: 'Schwartz'</li><li>dropped value-less row: 'Pop PK, 2 compartments'</li><li>dropped value-less row: 'Pop PK, 3 compartments'</li><li>salvaged Q22 ('median population value of iohexol clearance'=57.4) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('inter-compartmental clearance (Q)'=12.0) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('peripheral volume (V)'=3.3) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V'=5.4) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=iohexol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iohexol_Taubert2018_reference;
