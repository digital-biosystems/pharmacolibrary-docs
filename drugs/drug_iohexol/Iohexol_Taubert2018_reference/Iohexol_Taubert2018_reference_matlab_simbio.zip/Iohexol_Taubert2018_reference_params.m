function p = Iohexol_Taubert2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iohexol   source: Taubert_2018 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Iohexol_Taubert2018_reference_params';
  p.drug  = 'iohexol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.4;                % central volume [L]
  p.CL = 3.444;                % clearance [L/h]
  p.Vp = [3.3];             % peripheral volumes [L]
  p.Q  = [12.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3235.0;             % dose [mg]
end
