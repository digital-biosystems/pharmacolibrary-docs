model Iohexol_sberg2020_mean
  parameter Real Cl_ref = 7.222222222222224e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010960000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8211379,
    adminMass = 0.003235,
    k12 = 0.00023925385239253853,
    k21 = 0.0002777777777777778
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iohexol</h4><p>Iohexol is an iodinated X-ray contrast agent used to visualise tissues and blood vessels during imaging procedures. It is widely used in medical imaging and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410683\">Wikidata Q410683</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iohexol</td></tr><tr><td>population:</td><td>patients aged 1-82 years referred for measured GFR</td></tr><tr><td>source_paper:</td><td>Åsberg_2020</td></tr><tr><td>measured_compound:</td><td>iohexol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>iohexol 821.138 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'CLs'</li><li>dropped value-less row: 'Qs'</li><li>dropped value-less row: 'Vps'</li><li>dropped value-less row: 'Vs'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=iohexol</li><li>population split: 'mean' subgroup of Åsberg_2020 (paper reports 2 populations: mean, median)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iohexol_sberg2020_mean;
