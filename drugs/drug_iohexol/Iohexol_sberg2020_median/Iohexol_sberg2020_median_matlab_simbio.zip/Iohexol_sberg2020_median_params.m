function p = Iohexol_sberg2020_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iohexol   source: Åsberg_2020 / median   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Iohexol_sberg2020_median_params';
  p.drug  = 'iohexol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.47;                % central volume [L]
  p.CL = 1.55;                % clearance [L/h]
  p.Vp = [8.02];             % peripheral volumes [L]
  p.Q  = [5.99];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3235.0;             % dose [mg]
end
