function p = Iohexol_Hooper2025_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iohexol   source: Hooper_2025 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Iohexol_Hooper2025_final_params';
  p.drug  = 'iohexol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.92061;                % central volume [L]
  p.CL = 4.1814;                % clearance [L/h]
  p.Vp = [6.02142];             % peripheral volumes [L]
  p.Q  = [10.0746];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1618.0;             % dose [mg]
end
