model Iohexol_Hooper2025_final
  parameter Real Cl_ref = 1.1614999999999998e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00592061 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8211379,
    adminMass = 0.001618,
    k12 = 0.0004726708903305571,
    k21 = 0.00046475748245430475
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iohexol</h4><p>Iohexol is an iodinated contrast agent used to improve visualisation during X-ray imaging. It is typically injected into veins or body cavities, though it can also be taken orally. This substance appears on the World Health Organization list of essential medicines.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q410683\">Wikidata Q410683</a>, <a href=\"https://en.wikipedia.org/wiki/Iohexol?oldid=1368028914\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iohexol</td></tr><tr><td>population:</td><td>healthy adults with varying kidney function</td></tr><tr><td>source_paper:</td><td>Hooper_2025</td></tr><tr><td>measured_compound:</td><td>iohexol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70046-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>iohexol 821.138 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V1' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V1' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>dropped duplicate Q22 ('CL_β_eGFRcr‐cys', value '0.69') — already have one for this compound</li><li>dropped duplicate Q22 ('CL_ β_Sex', value '0.15') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V1_ β_Sex' — extend the ontology if this is a real PK parameter (source ['jcph70046-tbl-0002:row6:col3'])</li><li>dropped duplicate Q64 ('V2_β_weight', value '0.88') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V2_ β_Sex' — extend the ontology if this is a real PK parameter (source ['Hooper_2025_table_3:row8:col3'])</li><li>dropped duplicate Q22 ('Cl_pop', value '65.158') — already have one for this compound</li><li>routed 'beta_Cl_Sex_1' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q63 ('V1_pop', value '5091.933') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iohexol_Hooper2025_final;
