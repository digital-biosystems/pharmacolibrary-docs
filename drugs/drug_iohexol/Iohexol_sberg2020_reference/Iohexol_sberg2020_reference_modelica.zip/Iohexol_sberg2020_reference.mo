model Iohexol_sberg2020_reference
  parameter Real Cl_ref = 4.305555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01047 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8211379,
    adminMass = 0.003235,
    k12 = 0.0001589196646503237,
    k21 = 0.00020746744250484903
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iohexol</h4><p>Iohexol is an iodinated contrast agent used to improve visualisation during X-ray imaging. It is typically injected into veins or body cavities, though it can also be taken orally. This substance appears on the World Health Organization list of essential medicines.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q410683\">Wikidata Q410683</a>, <a href=\"https://en.wikipedia.org/wiki/Iohexol?oldid=1368028914\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iohexol</td></tr><tr><td>population:</td><td>patients with renal impairment</td></tr><tr><td>source_paper:</td><td>Åsberg_2020</td></tr><tr><td>measured_compound:</td><td>iohexol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>iohexol 821.138 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>competing summary columns for 'CLs (L/h)'; not population strata</li><li>competing summary columns for 'CLs (L/h)'; not population strata</li><li>competing summary columns for 'Qs (L/h)'; not population strata</li><li>competing summary columns for 'Qs (L/h)'; not population strata</li><li>competing summary columns for 'Vs (L)'; not population strata</li><li>competing summary columns for 'Vs (L)'; not population strata</li><li>competing summary columns for 'Vps (L)'; not population strata</li><li>competing summary columns for 'Vps (L)'; not population strata</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=iohexol</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iohexol_sberg2020_reference;
