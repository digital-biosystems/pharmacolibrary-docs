function p = Rifabutin_Bentley2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rifabutin   source: Bentley_2021 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rifabutin_Bentley2021_reference_params';
  p.drug  = 'rifabutin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 186.0;                % central volume [L]
  p.CL = 8.43;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
