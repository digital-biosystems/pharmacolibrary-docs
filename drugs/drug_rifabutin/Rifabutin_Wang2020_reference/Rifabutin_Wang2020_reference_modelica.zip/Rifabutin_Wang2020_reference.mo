model Rifabutin_Wang2020_reference
  parameter Real Cl_ref = 1.0305555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6057195805094162 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00011027777777777779,
    Tlag = 2970.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifabutin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wang_2020</td></tr><tr><td>measured_compound:</td><td>rifabutin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wang_2020) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rifabutin_Wang2020_reference;
