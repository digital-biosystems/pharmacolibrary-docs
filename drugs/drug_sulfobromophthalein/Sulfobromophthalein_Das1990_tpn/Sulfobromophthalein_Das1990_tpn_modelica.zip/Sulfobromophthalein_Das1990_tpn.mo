model Sulfobromophthalein_Das1990_tpn
  parameter Real Cl_ref = 5.763333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.003164 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.79403,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfobromophthalein</h4><p>Sulfobromophthalein is a diagnostic agent used to assess liver functional capacity. It is classified as an experimental drug and is not currently used in standard clinical practice.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q27132840\">Wikidata Q27132840</a>, <a href=\"https://en.wikipedia.org/wiki/Bromsulfthalein?oldid=1293294052\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfobromophthalein</td></tr><tr><td>population:</td><td>rabbits on lab chow and total parenteral nutrition</td></tr><tr><td>source_paper:</td><td>Das_1990</td></tr><tr><td>measured_compound:</td><td>sulfobromophthalein</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sulfobromophthalein 794.03 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Serum bile acids (uM)' — extend the ontology if this is a real PK parameter (source ['Das_1990_table_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Serum cholesterol (mM)' — extend the ontology if this is a real PK parameter (source ['Das_1990_table_1:row1:col2'])</li><li>unit_dimension_unknown: 'fraction/min' (kel)</li><li>implicit units: 'Extraction coefficient (Ke) (fraction/min)' → 1/min (from the paper text: &quot;The table header for the parameter column lists the unit as '(Ke) (fraction/min)'. Additionally, the Abstract states tha&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulfobromophthalein</li><li>population split: 'tpn (n = 6)' subgroup of Das_1990 (paper reports 2 populations: lcf (n = 6), tpn (n = 6))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulfobromophthalein_Das1990_tpn;
