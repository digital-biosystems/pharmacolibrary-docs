function p = Tetracaine_Cacek2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetracaine   source: Cacek_2017 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Tetracaine_Cacek2017_reference_params';
  p.drug  = 'tetracaine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.97;                % central volume [L]
  p.CL = 66.4;                % clearance [L/h]
  p.Vp = [418.0];             % peripheral volumes [L]
  p.Q  = [419.0];             % inter-compartmental clearances [L/h]
  p.ka = 4.41;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
