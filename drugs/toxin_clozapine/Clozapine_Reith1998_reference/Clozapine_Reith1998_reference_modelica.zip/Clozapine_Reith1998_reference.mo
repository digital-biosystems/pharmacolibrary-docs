model Clozapine_Reith1998_reference
  parameter Real Cl_ref = 8.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.508 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32680000000000003,
    adminMass = 0.0003,
    ka = 0.00019166666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clozapine</td></tr><tr><td>population:</td><td>patients with clozapine self-poisoning</td></tr><tr><td>source_paper:</td><td>Reith_1998</td></tr><tr><td>measured_compound:</td><td>Clozapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Clozapine 326.8 g/mol (pubchem); Norclozapine 312.801 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Approximate retention times were norclozapine' — extend the ontology if this is a real PK parameter (source ['Reith_1998:abstract'])</li><li>dropped unlinked row (NIL): 'Approximate retention times were clozapine' — extend the ontology if this is a real PK parameter (source ['Reith_1998:abstract'])</li><li>dropped unlinked row (NIL): 'Approximate retention times were propyl-norclozapine' — extend the ontology if this is a real PK parameter (source ['Reith_1998:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Clozapine</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=other; 5/5 row label(s) assigned, 0 linked by role; re-tagged Clozapine→Norclozapine ×1, Clozapine→parent ×2, Clozapine→Propyl-norclozapine ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Albitar_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Albitar_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Albitar_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Albitar_2020 — borrowed values do not complete its disposition core)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Clozapine_Reith1998_reference;
