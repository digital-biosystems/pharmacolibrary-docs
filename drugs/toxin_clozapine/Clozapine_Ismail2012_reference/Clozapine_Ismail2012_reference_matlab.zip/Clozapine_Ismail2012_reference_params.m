function p = Clozapine_Ismail2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clozapine   source: Ismail_2012 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Clozapine_Ismail2012_reference_params';
  p.drug  = 'clozapine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 508.0;                % central volume [L]
  p.CL = 63.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.69;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
