model Clozapine_M2023_i_n_drug_solution_clz_ds
  parameter Real Cl_ref = 8.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.508 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 6.4e-08,
    ka = 0.00019166666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clozapine</td></tr><tr><td>population:</td><td>Male Swiss Albino Mice</td></tr><tr><td>source_paper:</td><td>M_2023</td></tr><tr><td>measured_compound:</td><td>[131I] iodo-Clozapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clozapine 326.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'i.n. drug solution (clz-ds)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'i.n. drug solution (clz-ds)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'i.n. drug solution (clz-ds)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'i.n. drug solution (clz-ds)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: '%ID/g' (Cmax)</li><li>unit_dimension_unknown: 'Min. %ID/g' (AUC)</li><li>unit_dimension_unknown: 'Min. %ID/g' (AUC∞)</li><li>implicit units: 'Pharmacokinetic Parameters / Cmax (%ID/g)' — the LLM proposed '%ID/g', whose dimension does not fit Q32; left unset</li><li>implicit units: 'Pharmacokinetic Parameters / AUC 0–240 (Min. %ID/g)' — the LLM proposed 'min. %ID/g', whose dimension does not fit Q88; left unset</li><li>implicit units: 'Pharmacokinetic Parameters / AUC 0–∞ (Min. %ID/g)' — the LLM proposed 'min. %ID/g', whose dimension does not fit Q17; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=[131I] iodo-Clozapine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'i.n. drug solution (clz-ds)' subgroup of M_2023 (paper reports 3 populations: i.n. drug formula (clz- lbpm), i.n. drug solution (clz-ds), i.v. drug formula (clz- lbpm))</li><li>molar mass: no plausible PubChem entry for '[131I] iodo-Clozapine' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for '[131I] iodo-Clozapine' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Clozapine_M2023_i_n_drug_solution_clz_ds;
