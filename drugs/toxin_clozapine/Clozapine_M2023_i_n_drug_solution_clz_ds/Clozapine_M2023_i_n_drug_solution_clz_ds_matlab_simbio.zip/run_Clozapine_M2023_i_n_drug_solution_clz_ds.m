% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Clozapine_M2023_i_n_drug_solution_clz_ds_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
