model Clozapine_Pani2026_reference
  parameter Real Cl_ref = 8.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32680000000000003,
    adminMass = 0.0003,
    ka = 0.00019166666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clozapine</td></tr><tr><td>population:</td><td>adult psychiatric patients</td></tr><tr><td>source_paper:</td><td>Panić_2026</td></tr><tr><td>measured_compound:</td><td>Clozapine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Clozapine 326.8 g/mol (pubchem); Norclozapine 312.801 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is clozapine; the compartment is Clozapine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Clozapine, not clozapine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>clozapine's own concentration-time course is not produced by this model</li><li>dropped unlinked row (NIL): 'male sex' — extend the ontology if this is a real PK parameter (source ['Panić_2026:abstract'])</li><li>dropped unlinked row (NIL): 'valproic acid (VPA) use' — extend the ontology if this is a real PK parameter (source ['Panić_2026:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Clozapine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles: 2 per-group rows of none covariate_effect but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=other; 4/4 row label(s) assigned, 1 linked by role; re-tagged Clozapine→parent ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q76 (V/F) from Jiang_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Albitar_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Albitar_2020, Jiang_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clozapine_Pani2026_reference;
