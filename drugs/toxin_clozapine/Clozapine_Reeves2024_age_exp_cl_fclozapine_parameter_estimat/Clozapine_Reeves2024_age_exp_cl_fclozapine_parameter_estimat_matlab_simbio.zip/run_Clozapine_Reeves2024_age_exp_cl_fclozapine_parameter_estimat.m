% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
