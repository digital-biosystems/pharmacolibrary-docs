% Run: build params, simulate 0..96.0 h, plot + save Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.m
here = fileparts(mfilename('fullpath'));
p = Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat_params();
out = simulate_pk(p, 0:0.05:96.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('clozapine — Reeves_2024 (oral)');
print(fig, fullfile(here, 'Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.json'), 'w');
try
  s.model = 'Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.png, Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.csv, Clozapine_Reeves2024_age_exp_cl_fclozapine_parameter_estimat.json\n');
