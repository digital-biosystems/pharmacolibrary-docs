model Clozapine_Wills2021_600_mg_mean
  parameter Real Cl_ref = 8.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.508 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32680000000000003,
    adminMass = 0.0002,
    ka = 0.00019166666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clozapine</td></tr><tr><td>population:</td><td>patients with treatment-resistant schizophrenia in an active TDM population</td></tr><tr><td>source_paper:</td><td>Wills_2021</td></tr><tr><td>measured_compound:</td><td>Clozapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00047-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clozapine 326.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Clozapine to norclozapine ratio' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00047-t002:row3:col9'])</li><li>dropped unlinked row (NIL): '% Therapeutic' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00047-t002:row4:col9'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Clozapine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: '600 mg / mean' subgroup of Wills_2021 (paper reports 5 populations: 200 mg / mean, 300 mg / mean, 400 mg / mean, 500 mg / mean, 600 mg / mean)</li><li>gap-filled Q22 (CL) from Albitar_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Albitar_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Albitar_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Albitar_2020 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Clozapine_Wills2021_600_mg_mean;
