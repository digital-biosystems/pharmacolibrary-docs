function p = Clozapine_Wills2021_600_mg_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clozapine   source: Wills_2021 / 600_mg_mean   route: oral
  % estimated (absent from source): F
  p.name  = 'Clozapine_Wills2021_600_mg_mean_params';
  p.drug  = 'clozapine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 508.0;                % central volume [L]
  p.CL = 30.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.69;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
