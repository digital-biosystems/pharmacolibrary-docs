model Clozapine_Li2012_reference
  parameter Real Cl_ref = 6.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.508 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32680000000000003,
    adminMass = 0.0003,
    ka = 0.00019166666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clozapine</td></tr><tr><td>population:</td><td>Chinese patients with refractory schizophrenia</td></tr><tr><td>source_paper:</td><td>Li_2012</td></tr><tr><td>measured_compound:</td><td>Clozapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clozapine 326.8 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('The population-predicted clearance of norclozapine', value 32.7) — already have one for this compound</li><li>dropped duplicate Q22 ('Smoking was significantly associated with increases in the clearance (clozapine by 45%', value 45) — already have one for this compound</li><li>unit_dimension_unknown: 'norclozapine by 54.3%' (CL)</li><li>dropped duplicate Q22 ('Smoking was significantly associated with increases in the clearance (norclozapine by 54.3%)', value 54.3) — already have one for this compound</li><li>dropped duplicate Q22 ('The clearance was significantly greater in males than in females (clozapine by 20.8%', value 20.8) — already have one for this compound</li><li>unit_dimension_unknown: 'norclozapine by 24.2%' (CL)</li><li>dropped duplicate Q22 ('The clearance was significantly greater in males than in females (norclozapine by 24.2%)', value 24.2) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Clozapine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Albitar_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Albitar_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Albitar_2020 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Clozapine_Li2012_reference;
