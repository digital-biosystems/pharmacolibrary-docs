function p = Clozapine_M2023_i_n_drug_formula_clz_lbpm_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clozapine   source: M_2023 / i_n_drug_formula_clz_lbpm   route: oral
  % estimated (absent from source): F
  p.name  = 'Clozapine_M2023_i_n_drug_formula_clz_lbpm_params';
  p.drug  = 'clozapine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 508.0;                % central volume [L]
  p.CL = 30.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.69;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.064;             % dose [mg]
end
