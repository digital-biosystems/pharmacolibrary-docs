function p = Clozapine_Reeves2024_smoke_cl_fclozapine_parameter_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clozapine   source: Reeves_2024 / smoke_cl_fclozapine_parameter_estimates   route: oral
  p.name  = 'Clozapine_Reeves2024_smoke_cl_fclozapine_parameter_estimates_params';
  p.drug  = 'clozapine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 750.0;                % central volume [L]
  p.CL = 30.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.69;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
