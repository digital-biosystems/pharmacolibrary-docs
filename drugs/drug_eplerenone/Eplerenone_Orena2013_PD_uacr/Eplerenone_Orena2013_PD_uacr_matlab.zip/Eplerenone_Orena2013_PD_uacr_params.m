function p = Eplerenone_Orena2013_PD_uacr_params()
% Eplerenone_Orena2013_PD_uacr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eplerenone Orena_2013::UACR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response UACR in its own unit. Driver: eplerenone (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 671.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 6800.0;
p.form = 'E0*(1 - Emax*frac)';
end
