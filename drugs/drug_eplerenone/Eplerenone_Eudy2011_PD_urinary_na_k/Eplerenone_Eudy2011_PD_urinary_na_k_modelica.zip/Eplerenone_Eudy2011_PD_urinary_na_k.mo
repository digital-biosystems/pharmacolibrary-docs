model Eplerenone_Eudy2011_PD_urinary_na_k
  "indirect_response_iii exposure-response sweep — Eudy_2011 :: urinary Na+/K+ (urinary Na+/K+)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type III effect term
    EC50 = 557,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5600, Interval = 11.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eplerenone</h4><p>Eplerenone is a steroidal antimineralocorticoid used as an adjunct in managing chronic heart failure and to treat arterial hypertension. It is an approved medicine, available as an aldosterone antagonist diuretic, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423804\">Wikidata Q423804</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Eplerenone_Eudy2011_PD_urinary_na_k</h4><p>The steady-state exposure-response curve of Eudy RJ et al., <i>Journal of translational medicine 9:180</i> 2011 (<a href=\"https://doi.org/10.1186/1479-5876-9-180\">doi:10.1186/1479-5876-9-180</a>) — urinary Na+/K+ against eplerenone nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =        557 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of eplerenone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (557 nM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Eplerenone_Eudy2011_PD_urinary_na_k;
