function p = Eplerenone_Jaisser2021_PD_k_params()
% Eplerenone_Jaisser2021_PD_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eplerenone Jaisser_2021::K: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response K+ in mmol/L. Driver: eplerenone (pk_record).
p.E0 = 44.937428896473264;
p.Emax = 0.151;
p.EC50 = 0.000276;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2800.0;
p.form = 'E0*(1 + Emax*frac)';
end
