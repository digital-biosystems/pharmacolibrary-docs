model Eplerenone_Jaisser2021_PD_k
  "indirect_response_iii exposure-response sweep — Jaisser_2021 :: K+ (Serum K+)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 44.9374288965,      // [mmol/L]
    Emax = 0.151,  // type III effect term
    EC50 = 0.000276,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (3.95/0.0879 = 44.94) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2800, Interval = 5.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eplerenone</h4><p>Eplerenone is a steroidal antimineralocorticoid used as an adjunct in managing chronic heart failure and to treat arterial hypertension. It is an approved medicine, available as an aldosterone antagonist diuretic, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423804\">Wikidata Q423804</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Eplerenone_Jaisser2021_PD_k</h4><p>The steady-state exposure-response curve of Jaisser F et al., <i>Frontiers in pharmacology 12:604928</i> 2021 (<a href=\"https://doi.org/10.3389/fphar.2021.604928\">doi:10.3389/fphar.2021.604928</a>) — Serum K+ [mmol/L] against eplerenone ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 44.9374288965 mmol/L   drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      0.151          maximal effect term (Emax, Q320)
  EC50  =        276 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of eplerenone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 44.94   (drug-free)
  exposure = EC50 (276 ng/ml)  response 48.33
  exposure -> infinity  response 51.72</pre></body></html>"));
end Eplerenone_Jaisser2021_PD_k;
