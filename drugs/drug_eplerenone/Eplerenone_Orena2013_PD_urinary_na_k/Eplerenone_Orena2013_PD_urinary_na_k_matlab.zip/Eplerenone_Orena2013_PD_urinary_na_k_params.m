function p = Eplerenone_Orena2013_PD_urinary_na_k_params()
% Eplerenone_Orena2013_PD_urinary_na_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eplerenone Orena_2013::urinary_Na_K: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response urinary Na+/K+ in its own unit. Driver: eplerenone (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 5.92;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 60.0;
p.form = 'E0*(1 + Emax*frac)';
end
