function p = Eplerenone_Jaisser2021_PD_uacr_params()
% Eplerenone_Jaisser2021_PD_uacr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eplerenone Jaisser_2021::UACR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response UACR in its own unit. Driver: eplerenone (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1074.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 11000.0;
p.form = 'E0*(1 - Emax*frac)';
end
