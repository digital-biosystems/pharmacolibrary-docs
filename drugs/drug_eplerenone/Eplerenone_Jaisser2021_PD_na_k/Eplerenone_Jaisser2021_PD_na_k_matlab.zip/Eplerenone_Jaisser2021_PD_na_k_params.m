function p = Eplerenone_Jaisser2021_PD_na_k_params()
% Eplerenone_Jaisser2021_PD_na_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eplerenone Jaisser_2021::Na_K: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Na+/K+ in its own unit. Driver: eplerenone (pk_record).
p.E0 = 0.0;
p.Emax = 3.54;
p.EC50 = 3040.0;
p.gamma = 2.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 31000.0;
p.form = 'E0 + Emax*frac';
end
