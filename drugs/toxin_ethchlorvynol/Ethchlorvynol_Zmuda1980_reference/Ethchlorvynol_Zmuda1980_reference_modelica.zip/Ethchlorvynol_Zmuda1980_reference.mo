model Ethchlorvynol_Zmuda1980_reference
  parameter Real Cl_ref = 3.2942701638372655e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.144598,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethchlorvynol</td></tr><tr><td>population:</td><td>intoxicated dogs</td></tr><tr><td>source_paper:</td><td>Zmuda_1980</td></tr><tr><td>measured_compound:</td><td>Ethchlorvynol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ethchlorvynol 144.598 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Column clearances' — extend the ontology if this is a real PK parameter (source ['Zmuda_1980:abstract'])</li><li>dropped duplicate Q57 (&quot;During hemoperfusion, t 1/2's&quot;, value 3.8) — already have one for this compound</li><li>dropped duplicate Q57 (&quot;t 1/2's shorter than at the endogenous rate of detoxication&quot;, value 90.3) — already have one for this compound</li><li>dropped unlinked row (NIL): 'ethchlorvynol removed by hemoperfusion (based on plasma column clearance)' — extend the ontology if this is a real PK parameter (source ['Zmuda_1980:abstract'])</li><li>unit_dimension_unknown: 'based on plasma column clearance' (f_removed_HD)</li><li>dropped unlinked row (NIL): 'amount eluted from the resin' — extend the ontology if this is a real PK parameter (source ['Zmuda_1980:abstract'])</li><li>dropped unlinked row (NIL): 'amount eluted from the resin as % of dose' — extend the ontology if this is a real PK parameter (source ['Zmuda_1980:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ethchlorvynol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=1.18594 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Ethchlorvynol_Zmuda1980_reference;
