model Arsenic_Xu2016_PD_as_concentration_in_cord_serum
  "linear exposure-response sweep — Xu_2016 :: As concentration in cord serum (As concentration in cord serum)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 230000,  // [1]
    exposure_per_s = 1e-06);   // 1 μg L-1 per second
  // slope_unit_assumed: slope unit '(none)' read as response per μg L-1
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Arsenic_Xu2016_PD_as_concentration_in_cord_serum</h4><p>The steady-state exposure-response curve of Xu C et al., <i>Environmental science and pollution research international 23(22):22467–22476</i> 2016 (<a href=\"https://doi.org/10.1007/s11356-016-7265-1\">doi:10.1007/s11356-016-7265-1</a>) — As concentration in cord serum [μg L-1] against As μg L-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.23          change in response per unit of exposure (coefficient, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg L-1 of As per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Arsenic_Xu2016_PD_as_concentration_in_cord_serum;
