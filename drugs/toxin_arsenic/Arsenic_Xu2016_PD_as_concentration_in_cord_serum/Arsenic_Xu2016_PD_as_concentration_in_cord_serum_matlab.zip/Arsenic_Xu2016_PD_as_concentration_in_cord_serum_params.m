function p = Arsenic_Xu2016_PD_as_concentration_in_cord_serum_params()
% Arsenic_Xu2016_PD_as_concentration_in_cord_serum_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% arsenic Xu_2016::As_concentration_in_cord_serum: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg L-1 per second, in SI inside (kg/m3, s). Response As concentration in cord serum in μg L-1. Driver: As (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 230000.00000000006;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
