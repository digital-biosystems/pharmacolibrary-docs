model Arsenic_AlSaleh2026_PD_sbp
  "log_linear exposure-response sweep — Al-Saleh_2026 :: SBP (systolic pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 1.2   "[% per ln-unit]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Arsenic_AlSaleh2026_PD_sbp</h4><p>The steady-state exposure-response curve of Al-Saleh I et al., <i>International journal of hygiene and environmental health 272:114720</i> 2026 (<a href=\"https://doi.org/10.1016/j.ijheh.2025.114720\">doi:10.1016/j.ijheh.2025.114720</a>) — systolic pressure against arsenic — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        1.2 % per ln-unit change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one  of arsenic per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Arsenic_AlSaleh2026_PD_sbp;
