function p = Arsenic_AlSaleh2026_PD_sbp_params()
% Arsenic_AlSaleh2026_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% arsenic Al-Saleh_2026::SBP: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response SBP in its own unit. Driver: arsenic (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.2;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
