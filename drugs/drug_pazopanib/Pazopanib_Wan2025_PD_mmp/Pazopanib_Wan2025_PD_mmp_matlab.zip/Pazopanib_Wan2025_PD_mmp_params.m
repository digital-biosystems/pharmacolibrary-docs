function p = Pazopanib_Wan2025_PD_mmp_params()
% Pazopanib_Wan2025_PD_mmp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pazopanib Wan_2025::MMP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μm per second, in SI inside (kg/m3, s). Response MMP in relative. Driver: pazopanib (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 21.49;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 220.0;
p.form = 'E0*(1 - Emax*frac)';
end
