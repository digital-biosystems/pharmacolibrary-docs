% Run (SimBiology): build model + dose, simulate 0..38.0 h, plot.
p = Pazopanib_Bins2019_final_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 38.0);
