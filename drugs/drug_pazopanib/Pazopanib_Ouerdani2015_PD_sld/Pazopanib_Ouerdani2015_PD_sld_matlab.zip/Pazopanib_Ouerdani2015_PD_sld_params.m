function p = Pazopanib_Ouerdani2015_PD_sld_params()
% Pazopanib_Ouerdani2015_PD_sld_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pazopanib Ouerdani_2015::SLD: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg·h/mL per second, in SI inside (kg/m3, s). Response SLD in mm. Driver: pazopanib (cited_pk).
p.E0 = 329.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.4305555555555553e-08;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
