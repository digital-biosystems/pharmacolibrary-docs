function p = Chloramphenicol_Soback1986_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloramphenicol   source: Soback_1986 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Chloramphenicol_Soback1986_reference_params';
  p.drug  = 'chloramphenicol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 397.242906;                % central volume [L]
  p.CL = 309.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.54;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
