% Run (SimBiology): build model + dose, simulate 0..36.0 h, plot.
p = Chloramphenicol_Anadn1994_30_mg_kg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 36.0);
