model Chloramphenicol_Anadn1994_30_mg_kg
  parameter Real Cl_ref = 4.277777777777778e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1526 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 29.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.323129,
    adminMass = 0.0021,
    ka = 0.0008611111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About chloramphenicol</h4><p>Chloramphenicol is a broad-spectrum antibiotic that inhibits protein synthesis to treat serious bacterial infections, conjunctivitis, and rickettsiosis. It is administered orally, by injection into a vein, topically, or via ophthalmic and otic routes; it is well absorbed when taken by mouth. Blood levels are measured to guide the correct dose during treatment. It is widely used as an essential medicine, though systemic use is recommended only when safer antibiotics cannot be used.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q274515\">Wikidata Q274515</a>, <a href=\"https://en.wikipedia.org/wiki/Chloramphenicol?oldid=1386058603\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloramphenicol</td></tr><tr><td>population:</td><td>broiler chickens</td></tr><tr><td>source_paper:</td><td>Anadón_1994</td></tr><tr><td>measured_compound:</td><td>chloramphenicol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>chloramphenicol 323.129 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'MW' from footnote/prose loose number 8.63 (source ['tab_0:footnote', 'tab_0:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'tmax' from footnote/prose loose number 0.72 (source ['tab_0:footnote', 'tab_0:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=chloramphenicol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: '30 mg/kg' subgroup of Anadón_1994 (paper reports 2 populations: 30 mg/kg, 50 mg/kg)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Chloramphenicol_Anadn1994_30_mg_kg;
