% Run: build params, simulate 0..36.0 h, plot + save Chloramphenicol_Anadn1994_30_mg_kg.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Chloramphenicol_Anadn1994_30_mg_kg.m
here = fileparts(mfilename('fullpath'));
p = Chloramphenicol_Anadn1994_30_mg_kg_params();
out = simulate_pk(p, 0:0.05:36.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('chloramphenicol — Anadón_1994 (oral)');
print(fig, fullfile(here, 'Chloramphenicol_Anadn1994_30_mg_kg.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Chloramphenicol_Anadn1994_30_mg_kg.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Chloramphenicol_Anadn1994_30_mg_kg.json'), 'w');
try
  s.model = 'Chloramphenicol_Anadn1994_30_mg_kg'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Chloramphenicol_Anadn1994_30_mg_kg","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Chloramphenicol_Anadn1994_30_mg_kg.png, Chloramphenicol_Anadn1994_30_mg_kg.csv, Chloramphenicol_Anadn1994_30_mg_kg.json\n');
