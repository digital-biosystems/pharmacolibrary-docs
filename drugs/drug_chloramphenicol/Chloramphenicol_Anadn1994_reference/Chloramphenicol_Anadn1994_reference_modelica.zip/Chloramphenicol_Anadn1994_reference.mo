model Chloramphenicol_Anadn1994_reference
  parameter Real Cl_ref = 4.277777777777778e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16659999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.323129,
    adminMass = 0.003
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About chloramphenicol</h4><p>Chloramphenicol is an antibiotic used to treat bacterial infections such as rickettsial disease, Bacteroides infections, and outer ear infections. It remains in use, including as a topical treatment for skin, eye, and ear infections, and is listed among WHO essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q274515\">Wikidata Q274515</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloramphenicol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Anadón_1994</td></tr><tr><td>measured_compound:</td><td>chloramphenicol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>chloramphenicol 323.129 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Anadón_1994) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Chloramphenicol_Anadn1994_reference;
