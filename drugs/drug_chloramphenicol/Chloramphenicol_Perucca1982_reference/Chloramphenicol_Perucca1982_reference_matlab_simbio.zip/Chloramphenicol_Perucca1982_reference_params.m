function p = Chloramphenicol_Perucca1982_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloramphenicol   source: Perucca_1982 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Chloramphenicol_Perucca1982_reference_params';
  p.drug  = 'chloramphenicol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 43.800221;                % central volume [L]
  p.CL = 0.276;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
