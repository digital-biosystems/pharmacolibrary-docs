function p = Chloramphenicol_Anadn1994_50_mg_kg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloramphenicol   source: Anadón_1994 / 50_mg_kg   route: oral
  p.name  = 'Chloramphenicol_Anadn1994_50_mg_kg_params';
  p.drug  = 'chloramphenicol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 166.6;                % central volume [L]
  p.CL = 0.0154;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.23;                % absorption rate [1/h]
  p.F  = 0.38;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2100.0;             % dose [mg]
end
