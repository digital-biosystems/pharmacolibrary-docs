function p = Cyanocobalamin_Kashyap2024_PD_absolute_bioavailability_params()
% Cyanocobalamin_Kashyap2024_PD_absolute_bioavailability_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cyanocobalamin Kashyap_2024::absolute_bioavailability: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg per second, in SI inside (kg/m3, s). Response absolute bioavailability in µg. Driver: cyanocobalamin (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 429999999.99999994;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
