model Cyanocobalamin_Kashyap2024_PD_absolute_bioavailability
  "linear exposure-response sweep — Kashyap_2024 :: absolute bioavailability (absolute bioavailability)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 430000000,  // [1]
    exposure_per_s = 1e-09);   // 1 µg per second
  // slope_unit_assumed: slope unit '(none)' read as response per µg
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Cyanocobalamin_Kashyap2024_PD_absolute_bioavailability</h4><p>The steady-state exposure-response curve of Kashyap S et al., <i>Nutrients 16(23):4157</i> 2024 (<a href=\"https://doi.org/10.3390/nu16234157\">doi:10.3390/nu16234157</a>) — absolute bioavailability [µg] against cyanocobalamin µg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.43          change in response per unit of exposure (Slope (Line 1), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µg of cyanocobalamin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Cyanocobalamin_Kashyap2024_PD_absolute_bioavailability;
