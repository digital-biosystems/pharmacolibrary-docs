function p = DichloroaceticAcid_Jiang2017_PD_gstz1_1_params()
% DichloroaceticAcid_Jiang2017_PD_gstz1_1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dichloroacetic_acid Jiang_2017::GSTZ1_1: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response GSTZ1-1 in its own unit. Driver: Dichloroacetic acid (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.004319999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 44.0;
p.form = 'E0*(1 - Emax*frac)';
end
