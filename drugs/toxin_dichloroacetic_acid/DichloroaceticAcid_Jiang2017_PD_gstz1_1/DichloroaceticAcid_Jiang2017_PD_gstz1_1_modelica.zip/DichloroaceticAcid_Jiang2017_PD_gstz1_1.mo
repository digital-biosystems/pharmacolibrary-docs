model DichloroaceticAcid_Jiang2017_PD_gstz1_1
  "indirect_response_i exposure-response sweep — Jiang_2017 :: GSTZ1-1 (GSTZ1-1 activity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00432,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 44, Interval = 0.088),
    Documentation(info = "<html><body><h4>DichloroaceticAcid_Jiang2017_PD_gstz1_1</h4><p>The steady-state exposure-response curve of Jiang Y et al., <i>Journal of pharmaceutical sciences 106(5):1396-1404</i> 2017 (<a href=\"https://doi.org/10.1016/j.xphs.2017.01.032\">doi:10.1016/j.xphs.2017.01.032</a>) — GSTZ1-1 activity against Dichloroacetic acid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       4.32 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of Dichloroacetic acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.32 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end DichloroaceticAcid_Jiang2017_PD_gstz1_1;
