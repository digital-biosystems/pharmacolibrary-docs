// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model DichloroaceticAcid_Abbas1997_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7.732661450312373},
    MM = 0.13138,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dichloroacetic_acid</td></tr><tr><td>population:</td><td>B6C3F1 mice</td></tr><tr><td>source_paper:</td><td>Abbas_1997</td></tr><tr><td>measured_compound:</td><td>Trichloroethylene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Chloral hydrate 165.394 g/mol (pubchem); Dichloroacetic acid 128.936 g/mol (pubchem); Trichloroacetic acid 163.378 g/mol (pubchem); Trichloroethanol 149.395 g/mol (pubchem); Trichloroethanol glucuronide 325.519 g/mol (pubchem); Trichloroethylene 131.38 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'null' (Kp)</li><li>unit_dimension_unknown: 'null' (blood_air_partition)</li><li>dropped 'Urinary excretion rate constant' → Q50 = 0: a rate of 0 is not a parameter value (source ['Abbas_1997:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Trichloroethylene</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 6 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=pbpk; 4/4 row label(s) assigned, 1 linked by role; re-tagged Trichloroethylene→parent ×2, Trichloroethylene→Trichloroethanol glucuronide ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Trichloroethylene', not dichloroacetic_acid — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end DichloroaceticAcid_Abbas1997_reference;
