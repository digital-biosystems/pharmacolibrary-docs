function p = Potassium_Wang2023v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium   source: Wang_2023_2 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Potassium_Wang2023v2_reference_params';
  p.drug  = 'potassium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 80.6;                % central volume [L]
  p.CL = 10.4;                % clearance [L/h]
  p.Vp = [26.5];             % peripheral volumes [L]
  p.Q  = [3.02];             % inter-compartmental clearances [L/h]
  p.ka = 3.29;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
