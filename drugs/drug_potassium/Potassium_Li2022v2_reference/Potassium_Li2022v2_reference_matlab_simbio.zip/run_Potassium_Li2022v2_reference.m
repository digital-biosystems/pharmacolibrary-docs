% Run (SimBiology): build model + dose, simulate 0..3360.0 h, plot.
p = Potassium_Li2022v2_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3360.0);
