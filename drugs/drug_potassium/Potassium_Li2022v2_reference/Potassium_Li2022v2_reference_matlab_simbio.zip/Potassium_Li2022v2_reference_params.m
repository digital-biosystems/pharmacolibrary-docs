function p = Potassium_Li2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium   source: Li_2022_2 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Potassium_Li2022v2_reference_params';
  p.drug  = 'potassium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.65;                % central volume [L]
  p.CL = 0.007583;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.019292;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
