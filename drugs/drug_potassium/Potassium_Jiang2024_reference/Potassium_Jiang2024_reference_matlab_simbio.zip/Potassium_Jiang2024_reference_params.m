function p = Potassium_Jiang2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium   source: Jiang_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Potassium_Jiang2024_reference_params';
  p.drug  = 'potassium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.27;                % central volume [L]
  p.CL = 53.8;                % clearance [L/h]
  p.Vp = [45.6];             % peripheral volumes [L]
  p.Q  = [48.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
