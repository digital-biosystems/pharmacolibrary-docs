function p = Buprenorphine_Love2015_PD_mechanical_threshold_params()
% Buprenorphine_Love2015_PD_mechanical_threshold_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Love_2015::Mechanical_threshold: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL À1 per second, in SI inside (kg/m3, s). Response Mechanical threshold in Newton. Driver: buprenorphine (cited_pk).
p.E0 = 3.98;
p.Emax = 0.53;
p.EC50 = 6.84e-06;
p.gamma = 30.8;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 69.0;
p.form = 'E0*(1 - Emax*frac)';
end
