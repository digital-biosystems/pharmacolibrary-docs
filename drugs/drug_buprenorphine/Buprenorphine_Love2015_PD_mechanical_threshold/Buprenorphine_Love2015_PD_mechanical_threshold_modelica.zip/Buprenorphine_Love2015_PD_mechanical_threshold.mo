model Buprenorphine_Love2015_PD_mechanical_threshold
  "indirect_response_i exposure-response sweep — Love_2015 :: Mechanical threshold (Mechanical threshold)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 3.98,      // [Newton]
    Emax = 0.53,  // type I effect term
    EC50 = 6.84e-06,  // [kg/m3; ng mL À1 × 1e-06]
    gamma = 30.8,
    exposure_per_s = 1e-06);   // 1 ng mL À1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 69, Interval = 0.138),
    Documentation(info = "<html><body><!-- drug-about --><h4>About buprenorphine</h4><p>Buprenorphine is an opioid used to treat pain and opioid dependence, including heroin dependence. It is widely used and authorised in the European Union, mainly for opioid-related disorders, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407721\">Wikidata Q407721</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Buprenorphine_Love2015_PD_mechanical_threshold</h4><p>The steady-state exposure-response curve of Love EJ et al., <i>Veterinary anaesthesia and analgesia 42(1):17–29</i> 2015 (<a href=\"https://doi.org/10.1111/vaa.12165\">doi:10.1111/vaa.12165</a>) — Mechanical threshold [Newton] against buprenorphine ng mL À1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       3.98 Newton   drug-free response (baseline) (R 0, Q324)
  Emax  =       0.53          maximal effect term (I max, Q323)
  EC50  =       6.84 ng mL À1 exposure at half of the maximal effect term (IC 50, Q322)
  gamma =       30.8          Hill coefficient (n, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng mL À1 of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.98   (drug-free)
  exposure = EC50 (6.84 ng mL À1)  response 2.925
  exposure -> infinity  response 1.871</pre></body></html>"));
end Buprenorphine_Love2015_PD_mechanical_threshold;
