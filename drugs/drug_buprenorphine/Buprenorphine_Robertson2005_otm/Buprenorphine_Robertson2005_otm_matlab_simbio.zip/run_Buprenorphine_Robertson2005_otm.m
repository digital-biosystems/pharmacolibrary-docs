% Run (SimBiology): build model + dose, simulate 0..30.0 h, plot.
p = Buprenorphine_Robertson2005_otm_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 30.0);
