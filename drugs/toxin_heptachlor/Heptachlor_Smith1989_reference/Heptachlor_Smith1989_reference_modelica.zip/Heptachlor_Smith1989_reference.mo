// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Heptachlor_Smith1989_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1209600.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heptachlor</td></tr><tr><td>population:</td><td>fine-wool wether lambs</td></tr><tr><td>source_paper:</td><td>Smith_1989</td></tr><tr><td>measured_compound:</td><td>[14C]heptachlor</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>heptachlor 373.3 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'body weight' — extend the ontology if this is a real PK parameter (source ['Smith_1989:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Smith_1989:abstract'])</li><li>dropped 'Kel' → Q47 = -0.061: a rate of -0.061 is not a parameter value (source ['Smith_1989:abstract'])</li><li>relinked 'Clearance from blood had T1/2' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=[14C]heptachlor</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: no plausible PubChem entry for '[14C]heptachlor' ('carbon-14 labeled heptachlor') — left in mass units</li><li>molar mass: none found for '[14C]heptachlor' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 12096.0));
end Heptachlor_Smith1989_reference;
