model Clozapine_Parker2001_PD_theta
  "sigmoid_emax exposure-response sweep — Parker_2001 :: theta (theta frequency band amplitude)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 80,      // [µV s⁻¹]
    Emax = 18,  // [µV s⁻¹]
    EC50 = 0.00126,  // [kg/m3; ng ml⁻¹ × 1e-06]
    gamma = 5.9,
    exposure_per_s = 1e-06);   // 1 ng ml⁻¹ per second
  annotation(experiment(StartTime = 0, StopTime = 13000, Interval = 26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clozapine</h4><p>Clozapine is an atypical antipsychotic medication primarily used to treat schizophrenia and schizoaffective disorder. It is administered orally in the form of tablets or a suspension. Blood levels are routinely measured to guide the correct dose. It is widely used and listed on the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q221361\">Wikidata Q221361</a>, <a href=\"https://en.wikipedia.org/wiki/Clozapine?oldid=1385830875\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h4>Clozapine_Parker2001_PD_theta</h4><p>The steady-state exposure-response curve of Parker TJ et al., <i>British journal of pharmacology 132(1):151–158</i> 2001 (<a href=\"https://doi.org/10.1038/sj.bjp.0703791\">doi:10.1038/sj.bjp.0703791</a>) — theta frequency band amplitude [µV s⁻¹] against clozapine ng ml⁻¹ — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         80 µV s⁻¹   drug-free response (baseline) (E, Q324)
  Emax  =         18 µV s⁻¹   maximal effect term (Emax, Q320)
  EC50  =       1260 ng ml⁻¹  exposure at half of the maximal effect term (EC50, Q321)
  gamma =        5.9          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml⁻¹ of clozapine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 80   (drug-free)
  exposure = EC50 (1260 ng ml⁻¹)  response 89
  exposure -> infinity  response 98</pre></body></html>"));
end Clozapine_Parker2001_PD_theta;
