model Flurbiprofen_Zhang2018_reference
  parameter Real Cl_ref = 4.305555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00791 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2442609,
    adminMass = 7e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flurbiprofen</h4><p>Flurbiprofen is a non-steroidal anti-inflammatory drug used to treat pain and inflammation in conditions such as osteoarthritis and rheumatoid arthritis, and is also applied topically for joint, muscular, throat, and eye problems. It is an approved medicine used in several forms, including tablets, topical preparations, throat lozenges, and eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419890\">Wikidata Q419890</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flurbiprofen</td></tr><tr><td>population:</td><td>Chinese patients with postoperative pain</td></tr><tr><td>source_paper:</td><td>Zhang_2018</td></tr><tr><td>measured_compound:</td><td>flurbiprofen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t2-jpr-11-3061</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>flurbiprofen 244.261 g/mol (drugbank); flurbiprofen axetil 330.355 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is flurbiprofen; the compartment is flurbiprofen. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is flurbiprofen, not flurbiprofen</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>flurbiprofen's own concentration-time course is not produced by this model</li><li>kept covariate coefficient θheight=-0.0162 (covariate height) — not an ontology parameter</li><li>metabolite flurbiprofen: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite volume: 'θVd (L)' Q63→Q61 for flurbiprofen — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=flurbiprofen</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles (LLM): model_class=compartmental; 10/10 row label(s) assigned, 18 linked by role</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flurbiprofen_Zhang2018_reference;
