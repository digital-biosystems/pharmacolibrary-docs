function p = C1InhibitorPlasmaDerived_Pawaskar2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: c1_inhibitor_plasma_derived   source: Pawaskar_2018 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'C1InhibitorPlasmaDerived_Pawaskar2018_reference_params';
  p.drug  = 'c1_inhibitor_plasma_derived';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.5;                % central volume [L]
  p.CL = 0.0721;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0146;                % absorption rate [1/h]
  p.F  = 43.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
