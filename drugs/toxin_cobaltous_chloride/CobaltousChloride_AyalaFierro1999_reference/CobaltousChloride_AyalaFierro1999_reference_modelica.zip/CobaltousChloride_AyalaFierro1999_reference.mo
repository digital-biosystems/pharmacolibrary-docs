// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model CobaltousChloride_AyalaFierro1999_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4680.0},
    MM = 0.058933,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cobaltous_chloride</td></tr><tr><td>population:</td><td>male Fischer 344 rats</td></tr><tr><td>source_paper:</td><td>Ayala-Fierro_1999</td></tr><tr><td>measured_compound:</td><td>Cobalt</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cobalt 58.933 g/mol (pubchem); cobaltous_chloride 129.833 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'peaked at' — extend the ontology if this is a real PK parameter (source ['Ayala-Fierro_1999:abstract'])</li><li>dropped duplicate Q57 ('terminal elimination half-life of', value 22.9) — already have one for this compound</li><li>relinked 'slower clearance rate with a half-life of' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q57 ('slower clearance rate with a half-life of', value 4.3) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life of', value 19) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cobalt</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Cobalt', not cobaltous_chloride — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end CobaltousChloride_AyalaFierro1999_reference;
