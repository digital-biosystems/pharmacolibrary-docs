function p = Mirikizumab_Chua2025_PD_pro_30_decrease_sf_ap_params()
% Mirikizumab_Chua2025_PD_pro_30_decrease_sf_ap_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mirikizumab Chua_2025::PRO_30_decrease_SF_AP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response PRO ≥ 30% decrease SF/AP in its own unit. Driver: mirikizumab (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0111;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
