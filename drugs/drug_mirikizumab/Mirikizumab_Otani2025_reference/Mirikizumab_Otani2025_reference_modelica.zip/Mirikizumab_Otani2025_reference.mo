model Mirikizumab_Otani2025_reference
  parameter Real Cl_ref = 5.833333333333334e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004830000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7.1e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mirikizumab</h4><p>Mirikizumab, a monoclonal antibody that blocks interleukin signalling, is used to treat ulcerative colitis. It is approved and authorised in the European Union, and remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q55641096\">Wikidata Q55641096</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mirikizumab</td></tr><tr><td>population:</td><td>pediatric patients with moderate-to-severe ulcerative colitis</td></tr><tr><td>source_paper:</td><td>Otani_2025</td></tr><tr><td>measured_compound:</td><td>mirikizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Baseline weight effect on CL and Q' — extend the ontology if this is a real PK parameter (source ['Otani_2025_table_p6_1:row4:col1'])</li><li>salvaged Q22 ('Parameter for CL (L/h)'=0.021) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mirikizumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'mirikizumab' — its concentrations stay mass-only</li><li>gap-filled Q61 (V) from Otani_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Mirikizumab_Otani2025_reference;
