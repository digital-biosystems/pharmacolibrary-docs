function p = D_1Hydroxypyrene_Verheyen2021_PD_hcc_params()
% D_1Hydroxypyrene_Verheyen2021_PD_hcc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% 1_hydroxypyrene Verheyen_2021::HCC: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/L per second, in SI inside (kg/m3, s). Response HCC in pg/mg hair. Driver: 1-hydroxypyrene (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1130000.0000000002;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
