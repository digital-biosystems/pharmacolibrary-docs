function p = D_1Hydroxypyrene_Zhou2024_PD_fev1_fvc_params()
% D_1Hydroxypyrene_Zhou2024_PD_fev1_fvc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% 1_hydroxypyrene Zhou_2024::FEV1_FVC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response FEV1/FVC in %. Driver: 1-hydroxypyrene (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -4.594772733034197e-11;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
