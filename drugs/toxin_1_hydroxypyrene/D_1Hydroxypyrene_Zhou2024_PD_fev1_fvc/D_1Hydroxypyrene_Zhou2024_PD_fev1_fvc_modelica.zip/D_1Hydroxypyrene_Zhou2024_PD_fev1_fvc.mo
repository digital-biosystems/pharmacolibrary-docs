model D_1Hydroxypyrene_Zhou2024_PD_fev1_fvc
  "linear exposure-response sweep — Zhou_2024 :: FEV1/FVC (FEV1/FVC)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -4.59477273303e-11,  // [1 / second; %/year × 3.16881e-10]
    exposure_per_s = 1);   // 1 unit per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>D_1Hydroxypyrene_Zhou2024_PD_fev1_fvc</h4><p>The steady-state exposure-response curve of Zhou M et al., <i>Environmental pollution (Barking, Essex : 1987) 340(Pt 1):122801</i> 2024 (<a href=\"https://doi.org/10.1016/j.envpol.2023.122801\">doi:10.1016/j.envpol.2023.122801</a>) — FEV1/FVC [%] against 1-hydroxypyrene — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -0.145 %/year   change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of 1-hydroxypyrene per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end D_1Hydroxypyrene_Zhou2024_PD_fev1_fvc;
