model D_1Hydroxypyrene_Hu2024_PD_gestational_age
  "linear exposure-response sweep — Hu_2024 :: gestational age (gestational age)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -76723.2,  // [second; days × 86400]
    exposure_per_s = 1);   // 1 µg/g Cr per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>D_1Hydroxypyrene_Hu2024_PD_gestational_age</h4><p>The steady-state exposure-response curve of Hu Z et al., <i>Ecotoxicology and environmental safety 284:116868</i> 2024 (<a href=\"https://doi.org/10.1016/j.ecoenv.2024.116868\">doi:10.1016/j.ecoenv.2024.116868</a>) — gestational age [days] against 1-hydroxypyrene µg/g Cr — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -0.888 days     change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µg/g Cr of 1-hydroxypyrene per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end D_1Hydroxypyrene_Hu2024_PD_gestational_age;
