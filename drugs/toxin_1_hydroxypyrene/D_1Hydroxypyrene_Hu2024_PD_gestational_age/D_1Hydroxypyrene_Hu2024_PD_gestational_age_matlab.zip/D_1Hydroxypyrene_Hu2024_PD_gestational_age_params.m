function p = D_1Hydroxypyrene_Hu2024_PD_gestational_age_params()
% D_1Hydroxypyrene_Hu2024_PD_gestational_age_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% 1_hydroxypyrene Hu_2024::gestational_age: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/g Cr per second, in SI inside (kg/m3, s). Response gestational age in days. Driver: 1-hydroxypyrene (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -76723.2;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
