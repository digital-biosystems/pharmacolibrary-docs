model D_1Hydroxypyrene_Verheyen2021_PD_8_oxodg
  "log_linear exposure-response sweep — Verheyen_2021 :: 8-oxodG (8-oxo-7,8-dihydro-2’-deoxyguanosine)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 1070000   "[1]";
equation
  response = E0 + slope*log(exposure);
  // slope_unit_assumed: slope unit '(none)' read as response per µg/L
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>D_1Hydroxypyrene_Verheyen2021_PD_8_oxodg</h4><p>The steady-state exposure-response curve of Verheyen VJ et al., <i>Toxics 9(10)</i> 2021 (<a href=\"https://doi.org/10.3390/toxics9100245\">doi:10.3390/toxics9100245</a>) — 8-oxo-7,8-dihydro-2’-deoxyguanosine [µg/L] against 1-hydroxypyrene µg/L — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       1.07          change in response per unit of exposure (beta, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one µg/L of 1-hydroxypyrene per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end D_1Hydroxypyrene_Verheyen2021_PD_8_oxodg;
