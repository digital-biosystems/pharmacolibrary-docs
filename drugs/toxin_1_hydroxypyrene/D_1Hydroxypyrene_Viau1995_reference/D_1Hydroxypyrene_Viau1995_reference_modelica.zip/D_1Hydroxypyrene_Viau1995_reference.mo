// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_1Hydroxypyrene_Viau1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {43200.0},
    MM = 0.22025999999999998,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>1_hydroxypyrene</td></tr><tr><td>population:</td><td>well-informed human volunteers</td></tr><tr><td>source_paper:</td><td>Viau_1995</td></tr><tr><td>measured_compound:</td><td>1-hydroxypyrene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>1-hydroxypyrene 220.26 g/mol (pubchem); pyrene 202.256 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>linked '1-OHP is excreted with a first order apparent half-life' as 'kel/F' → Q47 (kel) for 1-hydroxypyrene — compound marker removed</li><li>relinked '1-OHP is excreted with a first order apparent half-life' Q47 → Q59: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1-hydroxypyrene</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>row roles (LLM): model_class=compartmental; 3/3 row label(s) assigned, 4 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end D_1Hydroxypyrene_Viau1995_reference;
