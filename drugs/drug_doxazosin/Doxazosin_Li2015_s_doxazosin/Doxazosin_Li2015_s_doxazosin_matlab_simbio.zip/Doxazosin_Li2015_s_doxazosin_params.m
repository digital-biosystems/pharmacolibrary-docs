function p = Doxazosin_Li2015_s_doxazosin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxazosin   source: Li_2015 / s_doxazosin   route: oral
  p.name  = 'Doxazosin_Li2015_s_doxazosin_params';
  p.drug  = 'doxazosin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 431.9;                % central volume [L]
  p.CL = 145.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.077;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 210.0;             % dose [mg]
end
