model Doxazosin_Reid1990_PD_sbp
  "linear exposure-response sweep — Reid_1990 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 2.3   "[mmHg/ng/ml]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Doxazosin_Reid1990_PD_sbp</h4><p>The steady-state exposure-response curve of Reid JL et al., <i>Hypertension (Dallas, Tex. : 1979) 16(1):12–18</i> 1990 (<a href=\"https://doi.org/10.1161/01.hyp.16.1.12\">doi:10.1161/01.hyp.16.1.12</a>) — systolic blood pressure [mm Hg] against doxazosin ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        2.3 mmHg/ng/ml change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/ml of doxazosin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Doxazosin_Reid1990_PD_sbp;
