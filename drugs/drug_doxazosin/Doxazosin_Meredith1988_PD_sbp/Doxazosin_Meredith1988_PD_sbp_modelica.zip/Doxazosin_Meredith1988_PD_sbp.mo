model Doxazosin_Meredith1988_PD_sbp
  "linear exposure-response sweep — Meredith_1988 :: SBP (placebo-corrected erect systolic blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -2.05   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Doxazosin_Meredith1988_PD_sbp</h4><p>The steady-state exposure-response curve of Meredith PA et al., <i>Xenobiotica; the fate of foreign compounds in biological systems 18(1):123–129</i> 1988 (<a href=\"https://doi.org/10.3109/00498258809055143\">doi:10.3109/00498258809055143</a>) — placebo-corrected erect systolic blood pressure [mmHg] against doxazosin ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -2.05          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/ml of doxazosin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Doxazosin_Meredith1988_PD_sbp;
