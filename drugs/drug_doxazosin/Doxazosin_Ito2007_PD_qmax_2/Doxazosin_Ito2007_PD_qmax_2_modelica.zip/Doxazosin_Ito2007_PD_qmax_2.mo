model Doxazosin_Ito2007_PD_qmax_2
  "linear exposure-response sweep — Ito_2007 :: Qmax (Qmax, the maximum urinary flow rate)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 9.53e-08,      // [m3/s; ml s -1 × 1e-06]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.01);
  parameter Real slope = 2.97e-10   "[meter ** 3 / second; ml s -1 % × 1e-08]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About doxazosin</h4><p>Doxazosin is an alpha-blocker used to treat high blood pressure and urinary problems caused by an enlarged prostate. It is an approved medicine, used widely in general practice for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419939\">Wikidata Q419939</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Doxazosin_Ito2007_PD_qmax_2</h4><p>The steady-state exposure-response curve of Ito K et al., <i>British journal of clinical pharmacology 63(4):394-403</i> 2007 (<a href=\"https://doi.org/10.1111/j.1365-2125.2006.02783.x\">doi:10.1111/j.1365-2125.2006.02783.x</a>) — Qmax, the maximum urinary flow rate [ml s -1] against doxazosin % — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     0.0953 ml s -1  drug-free response (baseline) (EBSL, Q324)
  slope =     0.0297 ml s -1 % change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one % of doxazosin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 9.53e-08   (drug-free)</pre></body></html>"));
end Doxazosin_Ito2007_PD_qmax_2;
