model Doxazosin_Donnelly1989v2_PD_sbp
  "linear exposure-response sweep — Donnelly_1989_2 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -2.1,  // [mm Hg ng- ml-',]
    exposure_per_s = 1);   // 1 ng ml-' per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About doxazosin</h4><p>Doxazosin is an alpha-blocker used to treat high blood pressure and urinary problems caused by an enlarged prostate. It is an approved medicine, used widely in general practice for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419939\">Wikidata Q419939</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Doxazosin_Donnelly1989v2_PD_sbp</h4><p>The steady-state exposure-response curve of Donnelly R et al., <i>British journal of clinical pharmacology 28(5):517–526</i> 1989 (<a href=\"https://doi.org/10.1111/j.1365-2125.1989.tb03537.x\">doi:10.1111/j.1365-2125.1989.tb03537.x</a>) — systolic blood pressure [mm Hg] against doxazosin ng ml-' — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -2.1 mm Hg ng- ml-', change in response per unit of exposure (m, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng ml-' of doxazosin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Doxazosin_Donnelly1989v2_PD_sbp;
