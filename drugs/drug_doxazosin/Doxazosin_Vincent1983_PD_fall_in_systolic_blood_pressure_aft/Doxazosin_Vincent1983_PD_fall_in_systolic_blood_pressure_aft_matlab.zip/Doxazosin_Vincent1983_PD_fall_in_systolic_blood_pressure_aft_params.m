function p = Doxazosin_Vincent1983_PD_fall_in_systolic_blood_pressure_aft_params()
% Doxazosin_Vincent1983_PD_fall_in_systolic_blood_pressure_aft_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxazosin Vincent_1983::fall_in_systolic_blood_pressure_after_5_min_standing: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response fall in systolic blood pressure (after 5 min standing) in mmHg. Driver: doxazosin (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -2.53;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
