% run_Doxazosin_Vincent1983_PD_fall_in_systolic_blood_pressure_aft  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Doxazosin_Vincent1983_PD_fall_in_systolic_blood_pressure_aft_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/ml]'); ylabel('response [mmHg]'); title('Doxazosin_Vincent1983_PD_fall_in_systolic_blood_pressure_aft', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Doxazosin_Vincent1983_PD_fall_in_systolic_blood_pressure_aft.csv');
