function p = Lumasiran_Sten2023_model_simultaneously_fitted_to_all_data_e_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lumasiran   source: Sten_2023 / model_simultaneously_fitted_to_all_data_estimate_se   route: oral
  p.name  = 'Lumasiran_Sten2023_model_simultaneously_fitted_to_all_data_e_params';
  p.drug  = 'lumasiran';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.1;                % central volume [L]
  p.CL = 23.8;                % clearance [L/h]
  p.Vp = [1340.0];             % peripheral volumes [L]
  p.Q  = [3.02];             % inter-compartmental clearances [L/h]
  p.ka = 0.157;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
