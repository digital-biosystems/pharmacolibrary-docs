model Pemetrexed_Boosman2023_reference
  parameter Real Cl_ref = 6.444444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004070000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemetrexed</td></tr><tr><td>population:</td><td>patients with lung cancer and mesothelioma</td></tr><tr><td>source_paper:</td><td>Boosman_2023</td></tr><tr><td>measured_compound:</td><td>pemetrexed</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('Cl (L/h)'=2.32) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Volume of distribution Central compartment (L)'=4.07) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q (L/h)'=4.53) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pemetrexed</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pemetrexed_Boosman2023_reference;
