model Pemetrexed_Hu2026_PD_folate
  "indirect_response_i exposure-response sweep — Hu_2026 :: Folate (Folate levels)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00047315,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.8, Interval = 0.0096),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pemetrexed</h4><p>Pemetrexed is an anticancer drug used to treat non-small-cell lung cancer and mesothelioma. It is an approved antifolate chemotherapy, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415220\">Wikidata Q415220</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pemetrexed_Hu2026_PD_folate</h4><p>The steady-state exposure-response curve of Hu K et al., <i>Pharmaceutics 18(4)</i> 2026 (<a href=\"https://doi.org/10.3390/pharmaceutics18040408\">doi:10.3390/pharmaceutics18040408</a>) — Folate levels against pemetrexed mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =    0.47315 mg/L     exposure at half of the maximal effect term (EC50,pem,plasma, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of pemetrexed per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.47315 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Pemetrexed_Hu2026_PD_folate;
