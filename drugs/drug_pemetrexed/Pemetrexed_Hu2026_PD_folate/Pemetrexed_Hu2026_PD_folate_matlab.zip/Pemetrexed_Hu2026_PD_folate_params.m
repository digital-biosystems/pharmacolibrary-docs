function p = Pemetrexed_Hu2026_PD_folate_params()
% Pemetrexed_Hu2026_PD_folate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pemetrexed Hu_2026::Folate: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response Folate in its own unit. Driver: pemetrexed (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.0004731499999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4.8;
p.form = 'E0*(1 - Emax*frac)';
end
