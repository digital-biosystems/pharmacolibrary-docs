model Pemetrexed_Cao2022_reference
  parameter Real Cl_ref = 2.3027777777777774e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.018940000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 1.466619734835152e-06,
    k21 = 5.4253472222222224e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemetrexed</td></tr><tr><td>population:</td><td>Chinese primary advanced non-small cell lung carcinoma patients</td></tr><tr><td>source_paper:</td><td>Cao_2022</td></tr><tr><td>measured_compound:</td><td>pemetrexed</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'θ1' — extend the ontology if this is a real PK parameter (source ['T2:row6:col1', 'T2:row6:col2', 'T2:row6:col4', 'T2:row6:col5', 'T2:row6:col6'])</li><li>dropped unlinked row (NIL): 'θ2' — extend the ontology if this is a real PK parameter (source ['T2:row7:col1', 'T2:row7:col2', 'T2:row7:col4', 'T2:row7:col5', 'T2:row7:col6'])</li><li>dropped unlinked row (NIL): 'θ3' — extend the ontology if this is a real PK parameter (source ['T2:row8:col1', 'T2:row8:col2', 'T2:row8:col4', 'T2:row8:col5', 'T2:row8:col6'])</li><li>dropped diagnostic row 'ηCL -shrinkage (%)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped diagnostic row 'ηQ -shrinkage (%)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped diagnostic row 'ε-shrinkage (%)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pemetrexed</li><li>model equation 'θi = θ×exp(θCov)' not bound — neither LHS nor base term 'θ' linked to an ontology parameter</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pemetrexed_Cao2022_reference;
