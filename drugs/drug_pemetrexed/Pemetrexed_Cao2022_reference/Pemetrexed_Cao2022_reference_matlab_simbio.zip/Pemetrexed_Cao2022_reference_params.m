function p = Pemetrexed_Cao2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemetrexed   source: Cao_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pemetrexed_Cao2022_reference_params';
  p.drug  = 'pemetrexed';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 18.94;                % central volume [L]
  p.CL = 8.29;                % clearance [L/h]
  p.Vp = [5.12];             % peripheral volumes [L]
  p.Q  = [0.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
