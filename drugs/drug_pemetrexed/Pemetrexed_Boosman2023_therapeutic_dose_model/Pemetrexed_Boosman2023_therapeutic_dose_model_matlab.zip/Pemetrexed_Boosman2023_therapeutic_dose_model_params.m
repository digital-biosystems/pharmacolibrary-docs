function p = Pemetrexed_Boosman2023_therapeutic_dose_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemetrexed   source: Boosman_2023 / therapeutic_dose_model   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pemetrexed_Boosman2023_therapeutic_dose_model_params';
  p.drug  = 'pemetrexed';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.28;                % central volume [L]
  p.CL = 5.73;                % clearance [L/h]
  p.Vp = [5.39];             % peripheral volumes [L]
  p.Q  = [4.53];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
