function p = GlycopyrroniumBromide_Bartels2013_population_mean_cv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glycopyrronium_bromide   source: Bartels_2013 / population_mean_cv   route: oral
  p.name  = 'GlycopyrroniumBromide_Bartels2013_population_mean_cv_params';
  p.drug  = 'glycopyrronium_bromide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.3;                % central volume [L]
  p.CL = 44.9;                % clearance [L/h]
  p.Vp = [71.5];             % peripheral volumes [L]
  p.Q  = [8.23];             % inter-compartmental clearances [L/h]
  p.ka = 0.009;                % absorption rate [1/h]
  p.F  = 0.0111;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
