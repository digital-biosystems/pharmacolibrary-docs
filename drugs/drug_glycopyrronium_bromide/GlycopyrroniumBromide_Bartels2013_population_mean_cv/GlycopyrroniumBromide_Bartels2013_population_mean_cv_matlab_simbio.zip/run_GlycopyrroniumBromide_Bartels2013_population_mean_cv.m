% Run (SimBiology): build model + dose, simulate 0..336.0 h, plot.
p = GlycopyrroniumBromide_Bartels2013_population_mean_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 336.0);
