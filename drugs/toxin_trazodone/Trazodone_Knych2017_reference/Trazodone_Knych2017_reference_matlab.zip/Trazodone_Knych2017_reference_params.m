function p = Trazodone_Knych2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trazodone   source: Knych_2017 / reference   route: oral
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Trazodone_Knych2017_reference_params';
  p.drug  = 'trazodone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 74.2;                % central volume [L]
  p.CL = 28.77;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.372;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
