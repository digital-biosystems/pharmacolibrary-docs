model Trazodone_Oggianu2022_value
  parameter Real Cl_ref = 1.388888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.371869,
    adminMass = 3e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>trazodone</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Oggianu_2022</td></tr><tr><td>measured_compound:</td><td>Trazodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13253-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>trazodone 371.869 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Log P' — extend the ontology if this is a real PK parameter (source ['cts13253-tbl-0001:row3:col1'])</li><li>dropped unlinked row (NIL): 'pK a' — extend the ontology if this is a real PK parameter (source ['cts13253-tbl-0001:row5:col1'])</li><li>dropped unlinked row (NIL): 'Model' — extend the ontology if this is a real PK parameter (source ['cts13253-tbl-0001:row9:col1'])</li><li>dropped unlinked row (NIL): 'fugut' — extend the ontology if this is a real PK parameter (source ['cts13253-tbl-0001:row12:col1'])</li><li>covariate effect for Q45 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CLiv (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Trazodone</li><li>pharmacogenetic covariate 'theta_q45_cyp3a4' (cyp3a4) — PGx domain</li><li>population split: 'value' subgroup of Oggianu_2022 (paper reports 4 populations: 30 mg ir, 300 mg oad, q.d., value)</li><li>skipped review gap-fill of V from Adachi_2021: its label names a different analyte ('systemic') — 'Volume of systemic circulation'</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Trazodone_Oggianu2022_value;
