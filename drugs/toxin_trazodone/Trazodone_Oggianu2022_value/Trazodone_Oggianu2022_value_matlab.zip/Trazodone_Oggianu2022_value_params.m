function p = Trazodone_Oggianu2022_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trazodone   source: Oggianu_2022 / value   route: oral
  % estimated (absent from source): ka, F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Trazodone_Oggianu2022_value_params';
  p.drug  = 'trazodone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.0;                % central volume [L]
  p.CL = 5.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
