model Trimethoprim_Boulanger2024_reference
  parameter Real Cl_ref = 0.00011666666666666667 "Cl [m3/s]";
  parameter Real cov_sdz_bw_0 = 0 "SDZ_BW covariate";
  parameter Real cov_mp_bw_1 = 0 "MP_BW covariate";
  parameter Real Vd_ref = 0.5467 "Vd [m3]";
  parameter Real cov_smx_bw_1 = 0 "SMX_BW covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (41.4)*cov_sdz_bw_0)*(1 + (23.1)*cov_mp_bw_1),
    Vd = Vd_ref*(1 + (40.7)*cov_sdz_bw_0)*(1 + (46.4)*cov_smx_bw_1),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2903177,
    adminMass = 0.00224,
    ka = 0.005583333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trimethoprim</h4><p>Trimethoprim is an antibiotic used to treat bacterial infections, especially urinary tract infections, and is also used against infections such as toxoplasmosis and pneumocystosis. It remains widely used, appears on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422665\">Wikidata Q422665</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trimethoprim</td></tr><tr><td>population:</td><td>broilers</td></tr><tr><td>source_paper:</td><td>Boulanger_2024</td></tr><tr><td>measured_compound:</td><td>trimethoprim</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>trimethoprim 290.318 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'F_SDZ' — extend the ontology if this is a real PK parameter (source ['tbl0001:row2:col2'])</li><li>dropped unlinked row (NIL): 'F_SMX' — extend the ontology if this is a real PK parameter (source ['tbl0001:row3:col2'])</li><li>dropped duplicate Q49 ('ka_SMX', value '16.40') — already have one for this compound</li><li>dropped duplicate Q49 ('ka_TMP', value '11.30') — already have one for this compound</li><li>dropped duplicate Q61 ('Vd_SMX', value '10.10') — already have one for this compound</li><li>dropped duplicate Q61 ('Vd_TMP', value '5.42') — already have one for this compound</li><li>dropped duplicate Q22 ('CL_SMX', value '8.72') — already have one for this compound</li><li>'β_Vd_SDZ_BW' is a β covariate effect on _Vd_, not Q61 (llm link set aside)</li><li>covariate level 'β_Vd_SDZ_BW' → Q900:theta_v_sdz_bw = 40.70 (linear_fractional on Q61)</li><li>'β_Vd_SMX_BW' is a β covariate effect on _Vd_, not Q352 (llm link set aside)</li><li>covariate level 'β_Vd_SMX_BW' → Q900:theta_v_smx_bw = 46.40 (linear_fractional on Q61)</li><li>'β_CL_SDZ_BW' is a β covariate effect on _CL_, not Q22 (llm link set aside)</li><li>covariate level 'β_CL_SDZ_BW' → Q900:theta_cl_sdz_bw = 41.40 (linear_fractional on Q22)</li><li>'β_CL_TMP_BW' is a β covariate effect on _CL_T, not Q31 (llm link set aside)</li><li>covariate level 'β_CL_TMP_BW' → Q900:theta_cl_mp_bw = 23.10 (linear_fractional on Q22)</li><li>dropped duplicate Q60 ('T1/2β SMX (h)', value '2.80') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Trimethoprim_Boulanger2024_reference;
