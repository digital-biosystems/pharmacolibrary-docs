function p = Trimethoprim_Boulanger2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trimethoprim   source: Boulanger_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Trimethoprim_Boulanger2024_reference_params';
  p.drug  = 'trimethoprim';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 546.7;                % central volume [L]
  p.CL = 420.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 20.1;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2240.0;             % dose [mg]
end
