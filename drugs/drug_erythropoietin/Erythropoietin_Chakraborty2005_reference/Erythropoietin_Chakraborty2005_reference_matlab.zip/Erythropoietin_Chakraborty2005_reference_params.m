function p = Erythropoietin_Chakraborty2005_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: erythropoietin   source: Chakraborty_2005 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Erythropoietin_Chakraborty2005_reference_params';
  p.drug  = 'erythropoietin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.8;                % central volume [L]
  p.CL = 1.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
