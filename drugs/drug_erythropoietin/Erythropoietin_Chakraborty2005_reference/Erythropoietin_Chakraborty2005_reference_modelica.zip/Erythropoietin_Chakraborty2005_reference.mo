model Erythropoietin_Chakraborty2005_reference
  parameter Real Cl_ref = 5.166666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027800000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>erythropoietin</td></tr><tr><td>population:</td><td>critically ill subjects</td></tr><tr><td>source_paper:</td><td>Chakraborty_2005</td></tr><tr><td>measured_compound:</td><td>erythropoietin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'interindividual variability in CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'interindividual variability in V/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q27 ('CL/F', value None) — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'drop in exposure of EPO from the first to the subsequent dosing events' — extend the ontology if this is a real PK parameter (source ['Chakraborty_2005:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=erythropoietin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Erythropoietin_Chakraborty2005_reference;
