function p = Plazomicin_Trang2019v2_geometric_mean_value_cv_d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: plazomicin   source: Trang_2019_2 / geometric_mean_value_cv_d   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Plazomicin_Trang2019v2_geometric_mean_value_cv_d_params';
  p.drug  = 'plazomicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 100.2;                % central volume [L]
  p.CL = 4.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
