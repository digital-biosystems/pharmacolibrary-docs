% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Plazomicin_Trang2019v2_geometric_mean_value_cv_d_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
