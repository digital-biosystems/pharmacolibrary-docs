model Upadacitinib_Klnder2019_reference
  parameter Real Cl_ref = 1.1361111111111111e-05 "Cl [m3/s]";
  parameter Real cov_creatinine = 1.0 "creatinine covariate (reference 1.0)";
  parameter Real Vd_ref = 0.156 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_creatinine/1.0)^(0.256),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.380375,
    adminMass = 1e-06,
    ka = 1.4527777777777777e-05,
    Tlag = 554.4,
    k12 = 5.733618233618234e-06,
    k21 = 1.3153594771241829e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About upadacitinib</h4><p>Upadacitinib, a Janus kinase inhibitor, is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, axial spondyloarthritis, giant cell arteritis, atopic dermatitis, ulcerative colitis, and Crohn disease. It is an approved, authorised medicine in the European Union and is widely used for these immune-mediated diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074125\">Wikidata Q27074125</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>upadacitinib</td></tr><tr><td>population:</td><td>healthy volunteers and subjects with rheumatoid arthritis</td></tr><tr><td>source_paper:</td><td>Klünder_2019</td></tr><tr><td>measured_compound:</td><td>upadacitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>upadacitinib 380.375 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('Immediate-release Ka (1/h)', value '2.77') — already have one for this compound</li><li>dropped duplicate Q83 ('Immediate-release absorption lag time (h)', value '0.200') — already have one for this compound</li><li>covariate level 'Covariate exponent of creatinine clearance on CL/F' → Q900:covariate_exponent_of_creatinine_clearance_on_cl_f = 0.256 (power on Q27)</li><li>unit_dimension_mismatch: 'ISV on CL/F in phase I (%)' → Q27 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('ISV on CL/F in phase I (%)', value '20.5') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ISV on CL/F in phase II/III (%)' — extend the ontology if this is a real PK parameter (source ['Tab3:row18:col1'])</li><li>unit_dimension_mismatch: 'ISV on Vc/F in phase I (%)' → Q290 (unit 'dimensionless' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q290 ('ISV on Vc/F in phase I (%)', value '24.4') — already have one for this compound</li><li>unit_dimension_mismatch: 'ISV on Vc/F in phase II/III (%)' → Q290 (unit 'dimensionless' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q290 ('ISV on Vc/F in phase II/III (%)', value '53.0') — already have one for this compound</li><li>unit_dimension_mismatch: 'ISV on extended-release Ka (%)' → Q49 (unit 'dimensionless' vs ontology '1 / [time]') — route to review</li><li>dropped duplicate Q49 ('ISV on extended-release Ka (%)', value '66.8') — already have one for this compound</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=upadacitinib</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Upadacitinib_Klnder2019_reference;
