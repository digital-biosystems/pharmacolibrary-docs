function p = Upadacitinib_Klnder2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: upadacitinib   source: Klünder_2019 / reference   route: oral
  p.name  = 'Upadacitinib_Klnder2019_reference_params';
  p.drug  = 'upadacitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 156.0;                % central volume [L]
  p.CL = 40.9;                % clearance [L/h]
  p.Vp = [68.0];             % peripheral volumes [L]
  p.Q  = [3.22];             % inter-compartmental clearances [L/h]
  p.ka = 0.0523;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.154;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
