model Upadacitinib_Klnder2018_reference
  parameter Real Cl_ref = 1.102777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.146 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.380375,
    adminMass = 1e-06,
    ka = 0.003416666666666667,
    Tlag = 0.0,
    k12 = 6.145357686453577e-06,
    k21 = 1.3953689303611545e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About upadacitinib</h4><p>Upadacitinib, a Janus kinase inhibitor, is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, axial spondyloarthritis, giant cell arteritis, atopic dermatitis, ulcerative colitis, and Crohn disease. It is an approved, authorised medicine in the European Union and is widely used for these immune-mediated diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074125\">Wikidata Q27074125</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>upadacitinib</td></tr><tr><td>population:</td><td>healthy subjects and subjects with rheumatoid arthritis</td></tr><tr><td>source_paper:</td><td>Klünder_2018</td></tr><tr><td>measured_compound:</td><td>upadacitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>upadacitinib 380.375 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'ISVKa (%)' — extend the ontology if this is a real PK parameter (source ['Tab3:row12:col1'])</li><li>dropped duplicate Q27 ('Ratio of CL/F in females compared with males (θ2)c', value '0.86') — already have one for this compound</li><li>dropped duplicate Q290 ('Ratio of Vc/F in females compared with males (θ4)d', value '0.75') — already have one for this compound</li><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=upadacitinib</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Upadacitinib_Klnder2018_reference;
