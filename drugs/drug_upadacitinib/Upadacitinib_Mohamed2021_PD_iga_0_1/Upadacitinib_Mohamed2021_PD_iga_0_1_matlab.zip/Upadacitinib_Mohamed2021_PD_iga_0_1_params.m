function p = Upadacitinib_Mohamed2021_PD_iga_0_1_params()
% Upadacitinib_Mohamed2021_PD_iga_0_1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% upadacitinib Mohamed_2021::IGA_0_1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response IGA 0/1 in its own unit. Driver: upadacitinib (cited_pk).
p.E0 = 0.0;
p.Emax = 5.78;
p.EC50 = 1.28e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
