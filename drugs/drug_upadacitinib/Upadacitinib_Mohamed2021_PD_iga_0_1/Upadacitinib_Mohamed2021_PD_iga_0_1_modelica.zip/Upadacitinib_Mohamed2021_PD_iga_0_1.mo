model Upadacitinib_Mohamed2021_PD_iga_0_1
  "emax exposure-response sweep — Mohamed_2021 :: IGA 0/1 (IGA 0/1)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 5.78,  // [1]
    EC50 = 1.28e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About upadacitinib</h4><p>Upadacitinib, a Janus kinase inhibitor, is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, axial spondyloarthritis, giant cell arteritis, atopic dermatitis, ulcerative colitis, and Crohn disease. It is an approved, authorised medicine in the European Union and is widely used for these immune-mediated diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074125\">Wikidata Q27074125</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Upadacitinib_Mohamed2021_PD_iga_0_1</h4><p>The steady-state exposure-response curve of Mohamed MF et al., <i>Journal of clinical pharmacology 61(5):628–635</i> 2021 (<a href=\"https://doi.org/10.1002/jcph.1782\">doi:10.1002/jcph.1782</a>) — IGA 0/1 against upadacitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       5.78          maximal effect term (Emax, Q320)
  EC50  =       12.8 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of upadacitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (12.8 ng/mL)  response 2.89
  exposure -> infinity  response 5.78</pre></body></html>"));
end Upadacitinib_Mohamed2021_PD_iga_0_1;
