function p = Upadacitinib_Mohamed2021_PD_easi_75_params()
% Upadacitinib_Mohamed2021_PD_easi_75_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% upadacitinib Mohamed_2021::EASI_75: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response EASI-75 in its own unit. Driver: upadacitinib (cited_pk).
p.E0 = 0.0;
p.Emax = 5.35;
p.EC50 = 1.86e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 190.0;
p.form = 'E0 + Emax*frac';
end
