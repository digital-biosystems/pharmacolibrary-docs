#!/usr/bin/env python3
"""Sweep InsulinAspart_Rppel2017_PD_gir.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes InsulinAspart_Rppel2017_PD_gir.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "InsulinAspart_Rppel2017_PD_gir")
E0, Emax, EC50, gamma, slope, exposure_per_s = 4.5000000000000006e-08, 1.9833333333333335e-07, 2.5240193847584e-25, 1.8, 0.0, 1.66053906892e-27
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma))
x = [exposure_per_s * 1600.0 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "InsulinAspart_Rppel2017_PD_gir", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [mU/L]"); plt.ylabel("response [mg/kg/min]")
plt.title("InsulinAspart_Rppel2017_PD_gir"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
