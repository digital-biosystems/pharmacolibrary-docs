model InsulinAspart_Rppel2017_PD_gir
  "sigmoid_emax exposure-response sweep — Rüppel_2017 :: GIR (glucose infusion rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 4.5e-08,      // [1/s; mg/kg/min × 1.66667e-08]
    Emax = 1.98333333333e-07,  // [1/s; mg/kg/min × 1.66667e-08]
    EC50 = 2.52401938476e-25,  // [kg/m3; mU/L × 1.66054e-27]
    gamma = 1.8,
    exposure_per_s = 1.66053906892e-27);   // 1 mU/L per second
  annotation(experiment(StartTime = 0, StopTime = 1600, Interval = 3.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About insulin_aspart</h4><p>Insulin aspart is a fast-acting insulin analogue used to treat diabetes, including type-1 diabetes and high blood sugar. It is widely used and authorised in the European Union, available both alone and in combination with longer-acting insulins.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2754775\">Wikidata Q2754775</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>InsulinAspart_Rppel2017_PD_gir</h4><p>The steady-state exposure-response curve of Rüppel D et al., <i>CPT: pharmacometrics &amp; systems pharmacology 6(6):365-372</i> 2017 (<a href=\"https://doi.org/10.1002/psp4.12189\">doi:10.1002/psp4.12189</a>) — glucose infusion rate [mg/kg/min] against insulin mU/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.7 mg/kg/min drug-free response (baseline) (GIR0, Q324)
  Emax  =       11.9 mg/kg/min maximal effect term (GIRmax, Q320)
  EC50  =        152 mU/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.8          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mU/L of insulin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.5e-08   (drug-free)
  exposure = EC50 (152 mU/L)  response 1.442e-07
  exposure -> infinity  response 2.433e-07</pre></body></html>"));
end InsulinAspart_Rppel2017_PD_gir;
