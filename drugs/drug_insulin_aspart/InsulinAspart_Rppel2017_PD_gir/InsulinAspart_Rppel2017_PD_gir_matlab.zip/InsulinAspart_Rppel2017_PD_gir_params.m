function p = InsulinAspart_Rppel2017_PD_gir_params()
% InsulinAspart_Rppel2017_PD_gir_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% insulin_aspart Rüppel_2017::GIR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mU/L per second, in SI inside (kg/m3, s). Response GIR in mg/kg/min. Driver: insulin (not_resolved).
p.E0 = 4.5000000000000006e-08;
p.Emax = 1.9833333333333335e-07;
p.EC50 = 2.5240193847584e-25;
p.gamma = 1.8;
p.slope = 0.0;
p.exposure_per_s = 1.66053906892e-27;
p.stop_time = 1600.0;
p.form = 'E0 + Emax*frac';
end
