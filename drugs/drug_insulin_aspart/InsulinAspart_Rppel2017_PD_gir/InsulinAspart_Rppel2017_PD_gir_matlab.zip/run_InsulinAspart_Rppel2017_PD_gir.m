% run_InsulinAspart_Rppel2017_PD_gir  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = InsulinAspart_Rppel2017_PD_gir_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mU/L]'); ylabel('response [mg/kg/min]'); title('InsulinAspart_Rppel2017_PD_gir', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'InsulinAspart_Rppel2017_PD_gir.csv');
