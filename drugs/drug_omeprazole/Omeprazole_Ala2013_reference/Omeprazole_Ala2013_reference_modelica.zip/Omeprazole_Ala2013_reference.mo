model Omeprazole_Ala2013_reference
  parameter Real Cl_ref = 5.777777777777779e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0216 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0008333333333333333,
    Tlag = 9000.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>healthy Iranian adults</td></tr><tr><td>source_paper:</td><td>Ala_2013</td></tr><tr><td>measured_compound:</td><td>omeprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=omeprazole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gao_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from McCann_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Omeprazole_Ala2013_reference;
