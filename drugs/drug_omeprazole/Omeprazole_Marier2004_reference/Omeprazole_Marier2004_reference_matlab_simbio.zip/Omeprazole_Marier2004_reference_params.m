function p = Omeprazole_Marier2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Marier_2004 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Omeprazole_Marier2004_reference_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 53.2;                % central volume [L]
  p.CL = 43.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
