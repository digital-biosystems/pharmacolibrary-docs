% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Omeprazole_Marier2004_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
