function p = Omeprazole_Katashima1995_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Katashima_1995 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Omeprazole_Katashima1995_reference_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.653;                % central volume [L]
  p.CL = 241.92;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
