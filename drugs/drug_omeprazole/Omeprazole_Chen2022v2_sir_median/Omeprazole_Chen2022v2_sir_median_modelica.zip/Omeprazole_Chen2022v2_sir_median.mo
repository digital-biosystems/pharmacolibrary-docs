model Omeprazole_Chen2022v2_sir_median
  parameter Real Cl_ref = 6.138888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0222 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0008333333333333333,
    Tlag = 9000.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>obese patients undergoing laparoscopic sleeve gastrectomy</td></tr><tr><td>source_paper:</td><td>Chen_2022_2</td></tr><tr><td>measured_compound:</td><td>omeprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-01986-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'MTT ratio for visit 2: visit 1 (θ1)' → Q900:mtt_ratio_for_visit_2_visit_1_1 = 0.27 (additive_shift on the model)</li><li>covariate level 'MTT ratio for visit 3: visit 1 (θ2)' → Q900:mtt_ratio_for_visit_3_visit_1_2 = 0.45 (additive_shift on the model)</li><li>covariate effect for Q81 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q31 has no base parameter row (kept as unattached equation-variable)</li><li>dropped duplicate covariate effect 'cyp2c19'/'' on Q31 — ambiguous identity (two shifts cannot share one category)</li><li>covariate effect for Q31 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=omeprazole</li><li>population split: 'sir (median)' subgroup of Chen_2022_2 (paper reports 2 populations: final estimates, sir (median))</li><li>gap-filled Q27 (CL/F) from Chung_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gao_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from McCann_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Omeprazole_Chen2022v2_sir_median;
