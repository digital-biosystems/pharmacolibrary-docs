function p = Omeprazole_Chen2022v2_sir_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Chen_2022_2 / sir_median   route: oral
  % estimated (absent from source): dose
  p.name  = 'Omeprazole_Chen2022v2_sir_median_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.2;                % central volume [L]
  p.CL = 221.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
