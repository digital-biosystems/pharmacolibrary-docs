function p = Omeprazole_Zhao2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Zhao_2018 / reference   route: oral
  p.name  = 'Omeprazole_Zhao2018_reference_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.508;                % central volume [L]
  p.CL = 0.863;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0509;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
