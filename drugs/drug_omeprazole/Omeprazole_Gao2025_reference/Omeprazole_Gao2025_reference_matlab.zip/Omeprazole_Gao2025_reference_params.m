function p = Omeprazole_Gao2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Gao_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Omeprazole_Gao2025_reference_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.653;                % central volume [L]
  p.CL = 16.0;                % clearance [L/h]
  p.Vp = [40.0];             % peripheral volumes [L]
  p.Q  = [22.0];             % inter-compartmental clearances [L/h]
  p.ka = 3.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
