model Omeprazole_Yusuff2026_reference
  parameter Real Cl_ref = 1.7277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1448 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 4.27793124616329e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yusuff_2026</td></tr><tr><td>measured_compound:</td><td>omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yusuff_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Omeprazole_Yusuff2026_reference;
