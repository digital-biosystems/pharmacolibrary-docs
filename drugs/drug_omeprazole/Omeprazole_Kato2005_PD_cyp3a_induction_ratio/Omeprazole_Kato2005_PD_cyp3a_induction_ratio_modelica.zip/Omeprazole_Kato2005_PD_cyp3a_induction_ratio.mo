model Omeprazole_Kato2005_PD_cyp3a_induction_ratio
  "emax exposure-response sweep — Kato_2005 :: CYP3A induction ratio (CYP3A enzyme induction ratio)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.36,  // [1]
    EC50 = 0.000225,  // [mol/m3; micromol/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 micromol/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.3, Interval = 0.0046),
    Documentation(info = "<html><body><h4>Omeprazole_Kato2005_PD_cyp3a_induction_ratio</h4><p>The steady-state exposure-response curve of Kato M et al., <i>Drug metabolism and pharmacokinetics 20(4):236–243</i> 2005 (<a href=\"https://doi.org/10.2133/dmpk.20.236\">doi:10.2133/dmpk.20.236</a>) — CYP3A enzyme induction ratio against omeprazole micromol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.36          maximal effect term (Emax, Q320)
  EC50  =      0.225 micromol/L exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micromol/L of omeprazole per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.225 micromol/L)  response 1.18
  exposure -> infinity  response 2.36</pre></body></html>"));
end Omeprazole_Kato2005_PD_cyp3a_induction_ratio;
