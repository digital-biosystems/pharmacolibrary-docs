model Omeprazole_Kirchheiner2009_PD_ph
  "emax exposure-response sweep — Kirchheiner_2009 :: pH (mean 24-h intragastric pH)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.06,      // [1]
    Emax = 3.46,  // [1]
    EC50 = 6.27314814815e-10,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 550, Interval = 1.1),
    Documentation(info = "<html><body><!-- drug-about --><h4>About omeprazole</h4><p>Omeprazole is a proton-pump inhibitor used for acid-related stomach problems such as reflux disease, ulcers, gastritis, and Zollinger–Ellison syndrome. It is widely used, appears on the WHO essential medicines list, and is approved for both human and veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422210\">Wikidata Q422210</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Omeprazole_Kirchheiner2009_PD_ph</h4><p>The steady-state exposure-response curve of ['Julia Kirchheiner', 'Silke Glatt', 'Uwe Fuhr', 'Ulrich Klotz', 'Ingolf Meineke', 'Thomas Seufferlein', 'Jürgen Brockmöller'], <i>European journal of clinical pharmacology</i> 2009 (<a href=\"https://doi.org/10.1007/s00228-008-0576-5\">doi:10.1007/s00228-008-0576-5</a>) — mean 24-h intragastric pH against omeprazole mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       3.06          drug-free response (baseline) (Basal pH, Q324)
  Emax  =       3.46          maximal effect term (E max (pH), Q320)
  EC50  =       54.2 mg/day   exposure at half of the maximal effect term (ED 50 (mg/day), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of omeprazole per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.06   (drug-free)
  exposure = EC50 (54.2 mg/day)  response 4.79
  exposure -> infinity  response 6.52</pre></body></html>"));
end Omeprazole_Kirchheiner2009_PD_ph;
