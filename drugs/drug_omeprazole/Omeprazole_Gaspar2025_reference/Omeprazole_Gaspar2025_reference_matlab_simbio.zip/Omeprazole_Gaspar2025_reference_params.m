function p = Omeprazole_Gaspar2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omeprazole   source: Gaspar_2025 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Omeprazole_Gaspar2025_reference_params';
  p.drug  = 'omeprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 14.9;                % central volume [L]
  p.CL = 114.64;                % clearance [L/h]
  p.Vp = [145.7];             % peripheral volumes [L]
  p.Q  = [52.02];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
