model Omeprazole_Kirchheiner2009v2_PD_ph
  "emax exposure-response sweep — Kirchheiner_2009_2 :: pH (mean 24-h intragastric pH)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.06,      // [1]
    Emax = 1.2456e-08,  // [s; pH × 3.6e-09]
    EC50 = 6.27314814815e-10,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 550, Interval = 1.1),
    Documentation(info = "<html><body><h4>Omeprazole_Kirchheiner2009v2_PD_ph</h4><p>The steady-state exposure-response curve of Kirchheiner J et al., <i>European journal of clinical pharmacology 65(1):19–31</i> 2009 (<a href=\"https://doi.org/10.1007/s00228-008-0576-5\">doi:10.1007/s00228-008-0576-5</a>) — mean 24-h intragastric pH against omeprazole mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       3.06          drug-free response (baseline) (Basal pH, Q324)
  Emax  =       3.46 pH       maximal effect term (E max, Q320)
  EC50  =       54.2 mg/day   exposure at half of the maximal effect term (ED 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of omeprazole per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.06   (drug-free)
  exposure = EC50 (54.2 mg/day)  response 3.06
  exposure -> infinity  response 3.06</pre></body></html>"));
end Omeprazole_Kirchheiner2009v2_PD_ph;
