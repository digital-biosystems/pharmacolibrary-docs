model Macrogol_Sharda2021_reference
  parameter Real Cl_ref = 9.216666666666665e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>macrogol</td></tr><tr><td>population:</td><td>mice, rats, cynomolgus monkeys</td></tr><tr><td>source_paper:</td><td>Sharda_2021</td></tr><tr><td>measured_compound:</td><td>PEG40</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'half-life of PEG40 conjugated PEGylated products'</li><li>dropped duplicate Q22 ('CL', value 0.037) — already have one for this compound</li><li>dropped duplicate Q65 ('Vss', value 0.2) — already have one for this compound</li><li>dropped duplicate Q22 ('intrinsic CL', value 0.02) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=PEG40</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'PEG40', not macrogol — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Macrogol_Sharda2021_reference;
