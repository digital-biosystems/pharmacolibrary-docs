function p = Macrogol_Zhu2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: macrogol   source: Zhu_2018 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Macrogol_Zhu2018_reference_params';
  p.drug  = 'macrogol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.6;                % central volume [L]
  p.CL = 50.8;                % clearance [L/h]
  p.Vp = [561.0];             % peripheral volumes [L]
  p.Q  = [21.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.484;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
