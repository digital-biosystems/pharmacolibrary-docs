model Macrogol_Zhu2018_reference
  parameter Real Cl_ref = 1.411111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0476 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00013444444444444444,
    Tlag = 0.0,
    k12 = 0.00012605042016806722,
    k21 = 1.06951871657754e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>macrogol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhu_2018</td></tr><tr><td>measured_compound:</td><td>macrogol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhu_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Macrogol_Zhu2018_reference;
