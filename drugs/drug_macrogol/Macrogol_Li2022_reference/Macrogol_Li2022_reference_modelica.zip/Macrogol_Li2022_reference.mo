model Macrogol_Li2022_reference
  parameter Real Cl_ref = 2.1583333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2354045498218522 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>macrogol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>macrogol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2022) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Macrogol_Li2022_reference;
