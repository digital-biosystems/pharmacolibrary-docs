model Macrogol_Brunet2022_PD_mic
  "emax exposure-response sweep — Brunet_2022 :: MIC (AmB MIC)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.00036,      // [kg/m3; mg/L × 0.001]
    Emax = -0.0052,  // [kg/m3; mg/L × 0.001]
    EC50 = 0.00044,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // off_target_driver: driver compound 'PEG15HS' is not 'macrogol' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.4, Interval = 0.0088),
    Documentation(info = "<html><body><!-- drug-about --><h4>About macrogol</h4><p>Macrogol (polyethylene glycol) is a polymer used as an osmotic laxative to treat constipation. It is an approved medicine, also has veterinary approval, and is widely used for constipation; it also serves as a solvent and surfactant in other products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410083\">Wikidata Q410083</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Macrogol_Brunet2022_PD_mic</h4><p>The steady-state exposure-response curve of Brunet K et al., <i>Journal of fungi (Basel, Switzerland) 8(2)</i> 2022 (<a href=\"https://doi.org/10.3390/jof8020121\">doi:10.3390/jof8020121</a>) — AmB MIC [mg/L] against PEG15HS mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.36 mg/L     drug-free response (baseline) (MIC0, Q324)
  Emax  =        5.2 mg/L     maximal effect term (Rmax, Q323)
  EC50  =       0.44 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of PEG15HS per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.00036   (drug-free)
  exposure = EC50 (0.44 mg/L)  response -0.00224
  exposure -> infinity  response -0.00484</pre></body></html>"));
end Macrogol_Brunet2022_PD_mic;
