function p = Macrogol_Brunet2022_PD_mic_params()
% Macrogol_Brunet2022_PD_mic_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% macrogol Brunet_2022::MIC: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response MIC in mg/L. Driver: PEG15HS (conc_no_pk).
p.E0 = 0.0003599999999999999;
p.Emax = -0.005199999999999999;
p.EC50 = 0.0004399999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4.4;
p.form = 'E0 + Emax*frac';
end
