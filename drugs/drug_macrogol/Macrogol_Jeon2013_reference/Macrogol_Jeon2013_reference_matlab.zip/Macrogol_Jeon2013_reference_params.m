function p = Macrogol_Jeon2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: macrogol   source: Jeon_2013 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Macrogol_Jeon2013_reference_params';
  p.drug  = 'macrogol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 691.0;                % central volume [L]
  p.CL = 12.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.00653;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 85.7;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
