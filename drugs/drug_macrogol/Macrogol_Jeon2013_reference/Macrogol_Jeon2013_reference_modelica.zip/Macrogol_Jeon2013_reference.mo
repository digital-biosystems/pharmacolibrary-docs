model Macrogol_Jeon2013_reference
  parameter Real Cl_ref = 3.3888888888888884e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6910000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.813888888888889e-06,
    Tlag = 308520.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>macrogol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jeon_2013</td></tr><tr><td>measured_compound:</td><td>macrogol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jeon_2013) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Macrogol_Jeon2013_reference;
