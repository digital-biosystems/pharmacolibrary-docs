model Macrogol_Jeon2013_reference
  parameter Real Cl_ref = 3.3888888888888884e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6910000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.01,
    ka = 1.813888888888889e-06,
    Tlag = 308520.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About macrogol</h4><p>Macrogol (polyethylene glycol) is a polymer used as an osmotic laxative to treat constipation. It is an approved medicine, also has veterinary approval, and is widely used for constipation; it also serves as a solvent and surfactant in other products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410083\">Wikidata Q410083</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>macrogol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jeon_2013</td></tr><tr><td>measured_compound:</td><td>macrogol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jeon_2013) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Macrogol_Jeon2013_reference;
