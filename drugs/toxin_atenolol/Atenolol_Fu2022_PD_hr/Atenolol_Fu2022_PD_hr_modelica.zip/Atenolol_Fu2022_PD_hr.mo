model Atenolol_Fu2022_PD_hr
  "indirect_response_i exposure-response sweep — Fu_2022 :: HR (Heart Rate)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 79.4,      // [beats*min−1]
    Emax = 0.415,  // type I effect term
    EC50 = 5.83e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 590, Interval = 1.18),
    Documentation(info = "<html><body><h4>Atenolol_Fu2022_PD_hr</h4><p>The steady-state exposure-response curve of Fu Y et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(5):640-652</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12774\">doi:10.1002/psp4.12774</a>) — Heart Rate [beats*min−1] against atenolol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       79.4 beats*min−1 drug-free response (baseline) (Baseline of HR for study 1, Q324)
  Emax  =      0.415          maximal effect term (Emax on HR, Q323)
  EC50  =       58.3 ng/ml    exposure at half of the maximal effect term (EC50 on HR, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of atenolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 79.4   (drug-free)
  exposure = EC50 (58.3 ng/ml)  response 62.92
  exposure -> infinity  response 46.45</pre></body></html>"));
end Atenolol_Fu2022_PD_hr;
