function p = Atenolol_Fu2022_PD_hr_params()
% Atenolol_Fu2022_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atenolol Fu_2022::HR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response HR in beats*min−1. Driver: atenolol (cited_pk).
p.E0 = 79.4;
p.Emax = 0.415;
p.EC50 = 5.8299999999999994e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 590.0;
p.form = 'E0*(1 - Emax*frac)';
end
