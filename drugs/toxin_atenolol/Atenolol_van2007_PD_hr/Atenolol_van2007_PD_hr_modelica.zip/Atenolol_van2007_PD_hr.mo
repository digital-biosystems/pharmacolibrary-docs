model Atenolol_van2007_PD_hr
  "sigmoid_emax exposure-response sweep — van_2007 :: HR (Heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.742,      // [b.p.m.]
    Emax = -0.606,  // [b.p.m.]
    EC50 = 6.7e-08,  // [kg/m3; ng ml(-1) × 1e-06]
    gamma = 0.716,
    exposure_per_s = 1e-06);   // 1 ng ml(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 0.67, Interval = 0.00134),
    Documentation(info = "<html><body><h4>Atenolol_van2007_PD_hr</h4><p>The steady-state exposure-response curve of van Steeg TJ et al., <i>British journal of pharmacology 151(3):356-366</i> 2007 (<a href=\"https://doi.org/10.1038/sj.bjp.0707234\">doi:10.1038/sj.bjp.0707234</a>) — Heart rate [b.p.m.] against S(-)-atenolol ng ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.742 b.p.m.   drug-free response (baseline) (E0, Q324)
  Emax  =      0.606 b.p.m.   maximal effect term (Emax, Q323)
  EC50  =      0.067 ng ml(-1) exposure at half of the maximal effect term (EC50, Q321)
  gamma =      0.716          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml(-1) of S(-)-atenolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.742   (drug-free)
  exposure = EC50 (0.067 ng ml(-1))  response 0.439
  exposure -> infinity  response 0.136</pre></body></html>"));
end Atenolol_van2007_PD_hr;
