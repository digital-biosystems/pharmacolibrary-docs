function p = Atenolol_van2007_PD_hr_params()
% Atenolol_van2007_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atenolol van_2007::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml(-1) per second, in SI inside (kg/m3, s). Response HR in b.p.m.. Driver: S(-)-atenolol (pk_record).
p.E0 = 0.742;
p.Emax = -0.606;
p.EC50 = 6.7e-08;
p.gamma = 0.716;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.67;
p.form = 'E0 + Emax*frac';
end
