model Cyclophosphamide_Campagne2019_reference
  parameter Real Cl_ref = 8.555555555555557e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045500000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.261083,
    adminMass = 0.0091,
    ka = 8.946759259259258e-06,
    Tlag = 0.0,
    k21 = 0.0008064516129032258
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclophosphamide</td></tr><tr><td>population:</td><td>CD1-nude mice (non-tumor-bearing and tumor-bearing)</td></tr><tr><td>source_paper:</td><td>Campagne_2019</td></tr><tr><td>measured_compound:</td><td>Cyclophosphamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>4-hydroxy-cyclophosphamide 277.082 g/mol (pubchem); Cyclophosphamide 261.083 g/mol (pubchem); carboxyethylphosphoramide mustard 293.081 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Central clearance η-CL' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Central clearance η-CL' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Central clearance η-CL' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Central volume η-V' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Influx clearance η-CLin' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Influx clearance η-CLin' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Influx clearance η-CLin' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Efflux clearance η-CLef' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table section iiv: 'Efflux clearance η-CLef' routed out of structural estimates ('Inter-individual variabilities (IIV)')</li><li>table representations disagree for 'Central clearance CL (L/h/kg)'; source reconciliation required</li><li>table representations disagree for 'Central volume V (L/kg)'; source reconciliation required</li><li>table representations disagree for 'Peripheral clearance Q (L/h/kg)'; source reconciliation required</li><li>table representations disagree for 'Peripheral volume Vp (L/kg)'; source reconciliation required</li><li>table representations disagree for 'Proportional residual variability εprop'; source reconciliation required</li><li>dropped value-less row: 'CTX'</li><li>dropped value-less row: '4OH-CTX'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Cyclophosphamide_Campagne2019_reference;
