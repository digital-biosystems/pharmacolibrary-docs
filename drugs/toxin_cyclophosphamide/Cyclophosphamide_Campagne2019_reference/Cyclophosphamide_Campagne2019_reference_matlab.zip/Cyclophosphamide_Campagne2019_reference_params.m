function p = Cyclophosphamide_Campagne2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cyclophosphamide   source: Campagne_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Cyclophosphamide_Campagne2019_reference_params';
  p.drug  = 'cyclophosphamide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.5;                % central volume [L]
  p.CL = 308.0;                % clearance [L/h]
  p.Vp = [4.34];             % peripheral volumes [L]
  p.Q  = [12.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 9100.0;             % dose [mg]
end
