model Cyclophosphamide_Baudry2019_reference
  parameter Real Cl_ref = 1.4194444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0294 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.261083,
    adminMass = 0.0001,
    ka = 8.946759259259258e-06,
    Tlag = 0.0,
    k12 = 0.00046863189720332585,
    k21 = 1.2192723697148476e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclophosphamide</td></tr><tr><td>population:</td><td>elderly and very elderly patients with DLBCL</td></tr><tr><td>source_paper:</td><td>Baudry_2019</td></tr><tr><td>measured_compound:</td><td>Cyclophosphamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclophosphamide 261.083 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyclophosphamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Luo_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Cyclophosphamide_Baudry2019_reference;
