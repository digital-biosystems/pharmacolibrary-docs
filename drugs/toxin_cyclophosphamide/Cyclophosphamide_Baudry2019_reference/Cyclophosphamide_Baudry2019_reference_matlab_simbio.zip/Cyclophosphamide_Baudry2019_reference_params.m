function p = Cyclophosphamide_Baudry2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cyclophosphamide   source: Baudry_2019 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Cyclophosphamide_Baudry2019_reference_params';
  p.drug  = 'cyclophosphamide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 29.4;                % central volume [L]
  p.CL = 51.1;                % clearance [L/h]
  p.Vp = [1130.0];             % peripheral volumes [L]
  p.Q  = [49.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
