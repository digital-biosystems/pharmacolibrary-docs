model Cyclophosphamide_Ahmed2020_PD_anc
  "linear exposure-response sweep — Ahmed_2020 :: ANC (absolute neutrophil count)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 3450,      // [cells/mm3]
    slope = -1.42,  // [cells/mm3 per µmol.h/L]
    exposure_per_s = 1);   // 1 µmol.h/L per second
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Cyclophosphamide_Ahmed2020_PD_anc</h4><p>The steady-state exposure-response curve of Ahmed JH et al., <i>Frontiers in pharmacology 11:406</i> 2020 (<a href=\"https://doi.org/10.3389/fphar.2020.00406\">doi:10.3389/fphar.2020.00406</a>) — absolute neutrophil count [cells/mm3] against cyclophosphamide µmol.h/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       3450 cells/mm3 drug-free response (baseline) (baseline ANC, Q324)
  slope =      -1.42 cells/mm3 per µmol.h/L change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µmol.h/L of cyclophosphamide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3450   (drug-free)</pre></body></html>"));
end Cyclophosphamide_Ahmed2020_PD_anc;
