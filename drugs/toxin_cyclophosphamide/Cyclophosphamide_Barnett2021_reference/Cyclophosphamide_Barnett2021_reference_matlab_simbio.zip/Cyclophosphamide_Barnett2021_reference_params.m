function p = Cyclophosphamide_Barnett2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cyclophosphamide   source: Barnett_2021 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Cyclophosphamide_Barnett2021_reference_params';
  p.drug  = 'cyclophosphamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.781;                % central volume [L]
  p.CL = 1.326;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
