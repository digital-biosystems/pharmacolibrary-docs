model Cyclophosphamide_Veal2016_reference
  parameter Real Cl_ref = 1.768444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0174 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.261083,
    adminMass = 0.0001,
    ka = 8.946759259259258e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclophosphamide</td></tr><tr><td>population:</td><td>children with B-cell non-Hodgkin's lymphoma</td></tr><tr><td>source_paper:</td><td>Veal_2016</td></tr><tr><td>measured_compound:</td><td>Cyclophosphamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclophosphamide 261.083 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Age (years)' — extend the ontology if this is a real PK parameter (source ['tbl2:row1:col1', 'tbl2:row2:col1'])</li><li>dropped unlinked row (NIL): 'BW (kg)' — extend the ontology if this is a real PK parameter (source ['tbl2:row1:col2', 'tbl2:row2:col2'])</li><li>dropped unlinked row (NIL): 'BSA (m2)' — extend the ontology if this is a real PK parameter (source ['tbl2:row1:col3', 'tbl2:row2:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cyclophosphamide</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1 (L)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Luo_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Cyclophosphamide_Veal2016_reference;
