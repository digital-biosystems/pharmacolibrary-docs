function p = TrastuzumabEmtansine_Gupta2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trastuzumab_emtansine   source: Gupta_2012 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'TrastuzumabEmtansine_Gupta2012_reference_params';
  p.drug  = 'trastuzumab_emtansine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.33;                % central volume [L]
  p.CL = 0.029167;                % clearance [L/h]
  p.Vp = [0.89];             % peripheral volumes [L]
  p.Q  = [0.0325];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
