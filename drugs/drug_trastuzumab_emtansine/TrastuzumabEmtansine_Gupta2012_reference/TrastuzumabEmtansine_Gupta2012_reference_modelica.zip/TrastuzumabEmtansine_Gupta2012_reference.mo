model TrastuzumabEmtansine_Gupta2012_reference
  parameter Real Cl_ref = 8.101851851851853e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00333 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.2e-05,
    k12 = 2.7110443777110442e-06,
    k21 = 1.0143570536828964e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trastuzumab_emtansine</h4><p>Ado-trastuzumab emtansine is an antibody-drug conjugate used to treat breast cancer. It is authorised in the European Union and is used in cancer care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3997863\">Wikidata Q3997863</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trastuzumab_emtansine</td></tr><tr><td>population:</td><td>patients with HER2-positive metastatic breast cancer</td></tr><tr><td>source_paper:</td><td>Gupta_2012</td></tr><tr><td>measured_compound:</td><td>trastuzumab emtansine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trastuzumab emtansine</li><li>molar mass: none found for 'trastuzumab_emtansine' — its concentrations stay mass-only</li><li>molar mass: none found for 'trastuzumab emtansine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end TrastuzumabEmtansine_Gupta2012_reference;
