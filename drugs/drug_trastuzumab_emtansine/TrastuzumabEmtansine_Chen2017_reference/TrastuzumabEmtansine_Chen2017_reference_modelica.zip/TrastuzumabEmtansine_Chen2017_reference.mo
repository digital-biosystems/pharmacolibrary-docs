model TrastuzumabEmtansine_Chen2017_reference
  parameter Real Cl_ref = 9.143518518518519e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0044800000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.2e-05,
    k12 = 1.6017691798941798e-06,
    k21 = 4.816057668406662e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trastuzumab_emtansine</h4><p>Ado-trastuzumab emtansine is an antibody-drug conjugate used to treat breast cancer. It is authorised in the European Union and is used in cancer care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3997863\">Wikidata Q3997863</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trastuzumab_emtansine</td></tr><tr><td>population:</td><td>previously treated patients with HER2-positive advanced gastric cancer</td></tr><tr><td>source_paper:</td><td>Chen_2017</td></tr><tr><td>measured_compound:</td><td>trastuzumab emtansine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('nonlinear CL', value 2.06) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trastuzumab emtansine</li><li>molar mass: none found for 'trastuzumab_emtansine' — its concentrations stay mass-only</li><li>molar mass: none found for 'trastuzumab emtansine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end TrastuzumabEmtansine_Chen2017_reference;
