model TrastuzumabEmtansine_Khera2024_PD_tgi
  "linear exposure-response sweep — Khera_2024 :: TGI (Tumor volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 160000   "[1 / meter; 1/nM × 1e+09]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  // off_target_driver: driver compound 'conjugated active payload' is not 'trastuzumab_emtansine' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About trastuzumab_emtansine</h4><p>Ado-trastuzumab emtansine is an antibody-drug conjugate used to treat breast cancer. It is authorised in the European Union and is used in cancer care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3997863\">Wikidata Q3997863</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>TrastuzumabEmtansine_Khera2024_PD_tgi</h4><p>The steady-state exposure-response curve of Khera E et al., <i>Journal of pharmacokinetics and pharmacodynamics 52(1):7</i> 2024 (<a href=\"https://doi.org/10.1007/s10928-024-09956-1\">doi:10.1007/s10928-024-09956-1</a>) — Tumor volume [mm3] against conjugated active payload nM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    0.00016 1/nM     change in response per unit of exposure (Tumor killing constant, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one nM of conjugated active payload per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end TrastuzumabEmtansine_Khera2024_PD_tgi;
