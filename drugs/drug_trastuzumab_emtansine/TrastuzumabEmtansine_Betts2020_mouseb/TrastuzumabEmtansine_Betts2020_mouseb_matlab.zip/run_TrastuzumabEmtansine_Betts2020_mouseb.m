% Run: build params, simulate 0..240.0 h, plot + save TrastuzumabEmtansine_Betts2020_mouseb.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_TrastuzumabEmtansine_Betts2020_mouseb.m
here = fileparts(mfilename('fullpath'));
p = TrastuzumabEmtansine_Betts2020_mouseb_params();
out = simulate_pk(p, 0:0.05:240.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('trastuzumab_emtansine — Betts_2020 (iv_bolus)');
print(fig, fullfile(here, 'TrastuzumabEmtansine_Betts2020_mouseb.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'TrastuzumabEmtansine_Betts2020_mouseb.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'TrastuzumabEmtansine_Betts2020_mouseb.json'), 'w');
try
  s.model = 'TrastuzumabEmtansine_Betts2020_mouseb'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"TrastuzumabEmtansine_Betts2020_mouseb","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote TrastuzumabEmtansine_Betts2020_mouseb.png, TrastuzumabEmtansine_Betts2020_mouseb.csv, TrastuzumabEmtansine_Betts2020_mouseb.json\n');
