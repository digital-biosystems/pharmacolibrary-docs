function p = TrastuzumabEmtansine_Betts2020_mouseb_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trastuzumab_emtansine   source: Betts_2020 / mouseb   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'TrastuzumabEmtansine_Betts2020_mouseb_params';
  p.drug  = 'trastuzumab_emtansine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.27;                % central volume [L]
  p.CL = 0.0665;                % clearance [L/h]
  p.Vp = [3.934];             % peripheral volumes [L]
  p.Q  = [0.102083];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
