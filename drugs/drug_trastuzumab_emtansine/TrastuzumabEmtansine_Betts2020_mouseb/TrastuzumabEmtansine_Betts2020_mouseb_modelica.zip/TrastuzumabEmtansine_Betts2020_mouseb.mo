model TrastuzumabEmtansine_Betts2020_mouseb
  parameter Real Cl_ref = 1.8472222222222223e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0042699999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.2e-05,
    k21 = 7.208053248978515e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trastuzumab_emtansine</h4><p>Ado-trastuzumab emtansine is an antibody-drug conjugate used to treat breast cancer. It is authorised in the European Union and is used in cancer care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3997863\">Wikidata Q3997863</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trastuzumab_emtansine</td></tr><tr><td>population:</td><td>adults with cancer</td></tr><tr><td>source_paper:</td><td>Betts_2020</td></tr><tr><td>measured_compound:</td><td>trastuzumab_emtansine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trastuzumab_emtansine</li><li>population split: 'mouseb' subgroup of Betts_2020 (paper reports 9 populations: 144580pdx (breast), 24312pdx (breast), 37622pdx (nsclc), bt474clx (breast), ga-3109pdx (gastric), jimt-1clx (breast), mouseb, n87clx (gastric), t-dm1)</li><li>molar mass: none found for 'trastuzumab_emtansine' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end TrastuzumabEmtansine_Betts2020_mouseb;
