model Alfaxalone_Goodchild2020_PD_bis
  "sigmoid_emax exposure-response sweep — Goodchild_2020 :: BIS (bispectral index (BIS))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 96,      // [1]
    Emax = -0.94,  // [1]
    EC50 = 0.00098,  // [kg/m3; mg/L × 0.001]
    gamma = 12.1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 9.8, Interval = 0.0196),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alfaxalone</h4><p>Alfaxalone is a steroid-based general anesthetic used to induce and maintain anesthesia. It is approved for veterinary use, where it is widely used as an anesthetic in animals, while in humans it is considered experimental.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3611058\">Wikidata Q3611058</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Alfaxalone_Goodchild2020_PD_bis</h4><p>The steady-state exposure-response curve of Goodchild CS et al., <i>Anesthesia and analgesia 130(3):704–714</i> 2020 (<a href=\"https://doi.org/10.1213/ANE.0000000000004204\">doi:10.1213/ANE.0000000000004204</a>) — bispectral index (BIS) against alfaxalone mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         96          drug-free response (baseline) (baseline BIS, Q324)
  Emax  =       0.94          maximal effect term (EMAX, Q323)
  EC50  =       0.98 mg/L     exposure at half of the maximal effect term (C50, Q322)
  gamma =       12.1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of alfaxalone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96   (drug-free)
  exposure = EC50 (0.98 mg/L)  response 95.53
  exposure -> infinity  response 95.06</pre></body></html>"));
end Alfaxalone_Goodchild2020_PD_bis;
