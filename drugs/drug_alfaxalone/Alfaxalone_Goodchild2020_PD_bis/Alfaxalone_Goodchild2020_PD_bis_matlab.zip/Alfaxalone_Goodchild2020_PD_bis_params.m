function p = Alfaxalone_Goodchild2020_PD_bis_params()
% Alfaxalone_Goodchild2020_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alfaxalone Goodchild_2020::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: alfaxalone (pk_record).
p.E0 = 96.0;
p.Emax = -0.94;
p.EC50 = 0.0009799999999999998;
p.gamma = 12.1;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 9.8;
p.form = 'E0 + Emax*frac';
end
