function p = Semaglutide_Overgaard2019_one_compartment_model_from_phase_3_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Overgaard_2019 / one_compartment_model_from_phase_3a_trialsa   route: oral
  % estimated (absent from source): dose
  p.name  = 'Semaglutide_Overgaard2019_one_compartment_model_from_phase_3_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.2;                % central volume [L]
  p.CL = 0.0478;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0286;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
