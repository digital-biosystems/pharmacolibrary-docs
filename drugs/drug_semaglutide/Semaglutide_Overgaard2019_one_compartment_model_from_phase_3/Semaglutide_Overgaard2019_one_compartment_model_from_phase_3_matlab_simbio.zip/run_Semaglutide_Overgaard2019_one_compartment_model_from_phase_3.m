% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Semaglutide_Overgaard2019_one_compartment_model_from_phase_3_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
