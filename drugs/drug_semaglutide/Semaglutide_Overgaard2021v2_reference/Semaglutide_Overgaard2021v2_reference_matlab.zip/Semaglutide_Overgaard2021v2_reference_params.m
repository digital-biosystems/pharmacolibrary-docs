function p = Semaglutide_Overgaard2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Overgaard_2021_2 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Semaglutide_Overgaard2021v2_reference_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 350.0;                % central volume [L]
  p.CL = 0.059;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0286;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
