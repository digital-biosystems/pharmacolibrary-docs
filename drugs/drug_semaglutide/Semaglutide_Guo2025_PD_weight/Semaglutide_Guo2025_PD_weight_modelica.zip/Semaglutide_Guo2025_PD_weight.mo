model Semaglutide_Guo2025_PD_weight
  "emax exposure-response sweep — Guo_2025 :: ΔΔWeight (weight reduction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -11.7,  // [kg; kg × 1]
    EC50 = 3.84e-07,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.9, Interval = 0.0078),
    Documentation(info = "<html><body><!-- drug-about --><h4>About semaglutide</h4><p>Semaglutide is a GLP-1 analogue medicine used to treat type 2 diabetes and obesity or overweight. It is widely used and authorised in the European Union, with products also studied for fatty liver disease and related liver conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27261089\">Wikidata Q27261089</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Semaglutide_Guo2025_PD_weight</h4><p>The steady-state exposure-response curve of Guo H et al., <i>Obesity pillars 13:100162</i> 2025 (<a href=\"https://doi.org/10.1016/j.obpill.2025.100162\">doi:10.1016/j.obpill.2025.100162</a>) — weight reduction [kg] against Semaglutide_injection mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      -11.7 kg       maximal effect term (Emax, Q323)
  EC50  =      0.384 mg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of Semaglutide_injection per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.384 mg)  response -5.85
  exposure -> infinity  response -11.7</pre></body></html>"));
end Semaglutide_Guo2025_PD_weight;
