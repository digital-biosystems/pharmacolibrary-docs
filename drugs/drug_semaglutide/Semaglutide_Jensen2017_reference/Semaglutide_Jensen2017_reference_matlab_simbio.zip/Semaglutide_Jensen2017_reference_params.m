function p = Semaglutide_Jensen2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Jensen_2017 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Semaglutide_Jensen2017_reference_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 9.4;                % central volume [L]
  p.CL = 0.039;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.5;             % dose [mg]
end
