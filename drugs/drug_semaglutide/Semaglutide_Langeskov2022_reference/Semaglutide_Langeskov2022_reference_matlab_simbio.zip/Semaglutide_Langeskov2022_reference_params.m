function p = Semaglutide_Langeskov2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Langeskov_2022 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Semaglutide_Langeskov2022_reference_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3250.0;                % central volume [L]
  p.CL = 11.1;                % clearance [L/h]
  p.Vp = [2170.0];             % peripheral volumes [L]
  p.Q  = [199.0];             % inter-compartmental clearances [L/h]
  p.ka = 9.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
