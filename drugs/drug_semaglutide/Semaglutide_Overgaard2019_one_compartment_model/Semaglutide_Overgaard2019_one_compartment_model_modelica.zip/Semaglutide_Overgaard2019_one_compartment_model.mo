model Semaglutide_Overgaard2019_one_compartment_model
  parameter Real Cl_ref = 1.3277777777777778e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00977 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 8.222222222222222e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>semaglutide</td></tr><tr><td>population:</td><td>healthy subjects and subjects with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Overgaard_2019</td></tr><tr><td>measured_compound:</td><td>semaglutide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate effect for Q27 has no base parameter row (kept as unattached equation-variable)</li><li>dropped duplicate covariate effect 'body weight'/'' on Q27 — ambiguous identity (two shifts cannot share one category)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=semaglutide</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'one-compartment model' subgroup of Overgaard_2019 (paper reports 4 populations: estimate, one-compartment model, one-compartment model from phase 3a trialsa, two-compartment final model)</li><li>gap-filled Q27 (CL/F) from Carlsson_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Semaglutide_Overgaard2019_one_compartment_model;
