model Semaglutide_Overgaard2019_estimate
  parameter Real Cl_ref = 9.666666666666666e-09 "Cl [m3/s]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  parameter Real cov_body_weight_1 = 0 "body weight covariate";
  parameter Real cov_injection_site_2 = 0 "injection site covariate";
  parameter Real Vd_ref = 0.00359 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.847,
    Cl = Cl_ref*(1 + (1.01)*cov_body_weight_0)*(1 + (0.923)*cov_body_weight_1)*(1 + (0.883)*cov_injection_site_2),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 4.113640999999999,
    adminMass = 2.5e-07,
    ka = 7.027777777777778e-06,
    Tlag = 0.0,
    k12 = 2.3522129371711548e-05,
    k21 = 2.0596205962059627e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About semaglutide</h4><p>Semaglutide is a GLP-1 analogue medicine used to treat type 2 diabetes and obesity or overweight. It is widely used and authorised in the European Union, with products also studied for fatty liver disease and related liver conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27261089\">Wikidata Q27261089</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>semaglutide</td></tr><tr><td>population:</td><td>healthy subjects and subjects with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Overgaard_2019</td></tr><tr><td>measured_compound:</td><td>semaglutide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>semaglutide 4113.64 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Body weight effect on CL and Q' → Q900:body_weight_effect_on_cl_and_q = 1.01 (linear_fractional on Q22)</li><li>covariate level 'Body weight effect on Vc and Vp' → Q900:body_weight_effect_on_vc_and_vp = 0.923 (linear_fractional on Q22)</li><li>dropped duplicate Q22 ('T2D effect on CL', value '1.12') — already have one for this compound</li><li>covariate level 'Injection site effect on F' → Q900:injection_site_effect_on_f = 0.883 (linear_fractional on Q22)</li><li>dropped duplicate Q49 ('Drug product strength effects on ka, 1 mg', value '0.0346') — already have one for this compound</li><li>dropped duplicate Q49 ('Drug product strength effects on ka, 3 mg', value '0.0526') — already have one for this compound</li><li>dropped duplicate Q49 ('Drug product strength effects on ka, 10 mg', value '0.139') — already have one for this compound</li><li>dropped duplicate Q49 ('T2D effect on ka', value '0.544') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=semaglutide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'estimate' subgroup of Overgaard_2019 (paper reports 4 populations: estimate, one-compartment model, one-compartment model from phase 3a trialsa, two-compartment final model)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Semaglutide_Overgaard2019_estimate;
