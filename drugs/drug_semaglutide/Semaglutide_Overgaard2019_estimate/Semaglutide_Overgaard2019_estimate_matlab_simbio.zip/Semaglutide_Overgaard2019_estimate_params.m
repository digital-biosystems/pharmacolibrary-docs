function p = Semaglutide_Overgaard2019_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Overgaard_2019 / estimate   route: oral
  % estimated (absent from source): dose
  p.name  = 'Semaglutide_Overgaard2019_estimate_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.59;                % central volume [L]
  p.CL = 0.0348;                % clearance [L/h]
  p.Vp = [4.1];             % peripheral volumes [L]
  p.Q  = [0.304];             % inter-compartmental clearances [L/h]
  p.ka = 0.0253;                % absorption rate [1/h]
  p.F  = 0.847;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
