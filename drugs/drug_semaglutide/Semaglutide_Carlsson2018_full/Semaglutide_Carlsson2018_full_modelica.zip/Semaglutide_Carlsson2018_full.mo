model Semaglutide_Carlsson2018_full
  parameter Real Cl_ref = 1.3277777777777778e-08 "Cl [m3/s]";
  parameter Real cov_body_weight = 1.0 "body weight covariate (reference 1.0)";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real cov_age_2 = 0 "age covariate";
  parameter Real cov_age_3 = 0 "age covariate";
  parameter Real cov_maintenance_dose_4 = 0 "maintenance dose covariate";
  parameter Real cov_race_5 = 0 "race covariate";
  parameter Real cov_race_6 = 0 "race covariate";
  parameter Real cov_ethnicity_7 = 0 "ethnicity covariate";
  parameter Real cov_injection_site_8 = 0 "injection site covariate";
  parameter Real cov_injection_site_9 = 0 "injection site covariate";
  parameter Real cov_renal_10 = 0 "renal covariate";
  parameter Real cov_renal_11 = 0 "renal covariate";
  parameter Real cov_renal_12 = 0 "renal covariate";
  parameter Real Vd_ref = 0.012199999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_body_weight/1.0)^(0.774)*(1 + (1.04)*cov_sex_1)*(1 + (0.988)*cov_age_2)*(1 + (0.961)*cov_age_3)*(1 + (1.0)*cov_maintenance_dose_4)*(1 + (0.974)*cov_race_5)*(1 + (0.989)*cov_race_6)*(1 + (1.06)*cov_ethnicity_7)*(1 + (1.04)*cov_injection_site_8)*(1 + (1.08)*cov_injection_site_9)*(1 + (0.948)*cov_renal_10)*(1 + (0.955)*cov_renal_11)*(1 + (0.92)*cov_renal_12),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 7.944444444444445e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>semaglutide</td></tr><tr><td>population:</td><td>adults with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Carlsson_2018</td></tr><tr><td>measured_compound:</td><td>semaglutide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'total' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'total' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'total' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'total' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Body weight, kg' — extend the ontology if this is a real PK parameter (source ['Tab2:row20:col2'])</li><li>dropped unlinked row (NIL): 'BMI, kg/m2' — extend the ontology if this is a real PK parameter (source ['Tab2:row22:col2'])</li><li>dropped unlinked row (NIL): 'Duration of diabetes, years' — extend the ontology if this is a real PK parameter (source ['Tab2:row24:col2'])</li><li>dropped unlinked row (NIL): 'HbA1c, %' — extend the ontology if this is a real PK parameter (source ['Tab2:row26:col2'])</li><li>covariate level 'Body weight' → Q900:body_weight = 0.774 (power on Q27)</li><li>covariate level 'Sex - male' → Q900:sex_male = 1.04 (linear_fractional on Q27)</li><li>covariate level 'Age 65–74 years' → Q900:age_65_74_years = 0.988 (linear_fractional on Q27)</li><li>covariate level 'Age >74 years' → Q900:age_gt_74_years = 0.961 (linear_fractional on Q27)</li><li>covariate level 'Maintenance dose 0.5 mg' → Q900:maintenance_dose_0.5_mg = 1.00 (linear_fractional on Q27)</li><li>covariate level 'Race - black' → Q900:race_black = 0.974 (linear_fractional on Q27)</li><li>covariate level 'Race - Asian' → Q900:race_asian = 0.989 (linear_fractional on Q27)</li><li>covariate level 'Ethnicity – Hispanic or Latino' → Q900:ethnicity_hispanic_or_latino = 1.06 (linear_fractional on Q27)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Semaglutide_Carlsson2018_full;
