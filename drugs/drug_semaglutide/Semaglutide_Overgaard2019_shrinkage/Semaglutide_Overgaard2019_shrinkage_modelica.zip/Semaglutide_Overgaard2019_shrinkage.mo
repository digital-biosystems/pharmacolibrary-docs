model Semaglutide_Overgaard2019_shrinkage
  parameter Real Cl_ref = 9.666666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00359 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 7.027777777777778e-06,
    Tlag = 0.0,
    k12 = 2.3522129371711548e-05,
    k21 = 2.0596205962059627e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>semaglutide</td></tr><tr><td>population:</td><td>healthy subjects and those with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Overgaard_2019</td></tr><tr><td>measured_compound:</td><td>semaglutide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Absorption rate constant (ka), h−1'</li><li>dropped value-less row: 'Clearance (CL), L/h'</li><li>dropped value-less row: 'Central volume (Vc), L'</li><li>dropped value-less row: 'Intercompartmental clearance (Q), L/h'</li><li>dropped value-less row: 'Peripheral volume (Vp), L'</li><li>salvaged Q49 ('Absorption rate constant (ka), h−1'=0.0253) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('Clearance (CL), L/h'=0.0348) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('Central volume (Vc), L'=3.59) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Intercompartmental clearance (Q), L/h'=0.304) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('Peripheral volume (Vp), L'=4.1) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=semaglutide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Semaglutide_Overgaard2019_shrinkage;
