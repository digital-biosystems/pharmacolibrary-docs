function p = Semaglutide_Overgaard2021_subjects_with_t2d_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Overgaard_2021 / subjects_with_t2d   route: oral
  p.name  = 'Semaglutide_Overgaard2021_subjects_with_t2d_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.7;                % central volume [L]
  p.CL = 0.039;                % clearance [L/h]
  p.Vp = [4.2];             % peripheral volumes [L]
  p.Q  = [0.31];             % inter-compartmental clearances [L/h]
  p.ka = 2.09;                % absorption rate [1/h]
  p.F  = 0.69;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
