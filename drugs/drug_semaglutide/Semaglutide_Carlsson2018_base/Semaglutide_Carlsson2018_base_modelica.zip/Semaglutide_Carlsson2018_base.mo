model Semaglutide_Carlsson2018_base
  parameter Real Cl_ref = 1.3333333333333334e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0125 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 4.113640999999999,
    adminMass = 2.5e-07,
    ka = 7.944444444444445e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About semaglutide</h4><p>Semaglutide is a GLP-1 analogue medicine used to treat type 2 diabetes and obesity or overweight. It is widely used and authorised in the European Union, with products also studied for fatty liver disease and related liver conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27261089\">Wikidata Q27261089</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>semaglutide</td></tr><tr><td>population:</td><td>adults with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Carlsson_2018</td></tr><tr><td>measured_compound:</td><td>semaglutide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>semaglutide 4113.64 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('IIV (% CV)')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('IIV (% CV)')</li><li>dropped unlinked row (NIL): 'Body weight, kg' — extend the ontology if this is a real PK parameter (source ['Carlsson_2018_table_2:row19:col2'])</li><li>dropped unlinked row (NIL): 'BMI, kg/m²' — extend the ontology if this is a real PK parameter (source ['Carlsson_2018_table_2:row21:col2'])</li><li>dropped unlinked row (NIL): 'Duration of diabetes, years' — extend the ontology if this is a real PK parameter (source ['Carlsson_2018_table_2:row23:col2'])</li><li>dropped unlinked row (NIL): 'HbA1c, %' — extend the ontology if this is a real PK parameter (source ['Carlsson_2018_table_2:row25:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=semaglutide</li><li>model-stage split: 'base' is the base model of Carlsson_2018 (paper reports 2 stages: base, full); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Semaglutide_Carlsson2018_base;
