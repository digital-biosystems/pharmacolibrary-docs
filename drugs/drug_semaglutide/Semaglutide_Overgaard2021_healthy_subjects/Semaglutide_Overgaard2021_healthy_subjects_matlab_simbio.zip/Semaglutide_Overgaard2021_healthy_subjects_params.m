function p = Semaglutide_Overgaard2021_healthy_subjects_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Overgaard_2021 / healthy_subjects   route: oral
  p.name  = 'Semaglutide_Overgaard2021_healthy_subjects_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.4;                % central volume [L]
  p.CL = 0.033;                % clearance [L/h]
  p.Vp = [3.9];             % peripheral volumes [L]
  p.Q  = [0.28];             % inter-compartmental clearances [L/h]
  p.ka = 2.09;                % absorption rate [1/h]
  p.F  = 0.76;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
