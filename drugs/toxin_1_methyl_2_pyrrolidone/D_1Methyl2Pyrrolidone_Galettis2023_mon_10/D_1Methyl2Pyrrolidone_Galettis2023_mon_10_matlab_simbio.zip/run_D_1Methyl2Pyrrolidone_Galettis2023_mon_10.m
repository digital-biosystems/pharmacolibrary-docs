% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = D_1Methyl2Pyrrolidone_Galettis2023_mon_10_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
