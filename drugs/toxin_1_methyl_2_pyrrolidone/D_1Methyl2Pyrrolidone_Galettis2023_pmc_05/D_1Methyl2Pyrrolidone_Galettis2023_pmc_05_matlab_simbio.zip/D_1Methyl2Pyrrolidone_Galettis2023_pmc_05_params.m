function p = D_1Methyl2Pyrrolidone_Galettis2023_pmc_05_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 1_methyl_2_pyrrolidone   source: Galettis_2023 / pmc_05   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'D_1Methyl2Pyrrolidone_Galettis2023_pmc_05_params';
  p.drug  = '1_methyl_2_pyrrolidone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 36.62;                % central volume [L]
  p.CL = 23.62;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
