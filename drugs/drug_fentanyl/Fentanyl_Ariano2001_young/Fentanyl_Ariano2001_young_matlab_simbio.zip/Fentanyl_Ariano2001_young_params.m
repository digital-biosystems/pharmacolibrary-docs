function p = Fentanyl_Ariano2001_young_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Ariano_2001 / young   route: oral
  % estimated (absent from source): F
  p.name  = 'Fentanyl_Ariano2001_young_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 84.7;                % central volume [L]
  p.CL = 128.1;                % clearance [L/h]
  p.Vp = [119.7];             % peripheral volumes [L]
  p.Q  = [222.6];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 0.35;             % dose [mg]
end
