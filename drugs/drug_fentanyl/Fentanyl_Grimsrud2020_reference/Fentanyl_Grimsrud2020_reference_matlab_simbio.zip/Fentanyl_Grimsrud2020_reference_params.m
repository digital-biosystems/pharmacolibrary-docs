function p = Fentanyl_Grimsrud2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Grimsrud_2020 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fentanyl_Grimsrud2020_reference_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.01;                % central volume [L]
  p.CL = 7.19;                % clearance [L/h]
  p.Vp = [25.1];             % peripheral volumes [L]
  p.Q  = [2.16];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
