function p = Fentanyl_Vller2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Völler_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Fentanyl_Vller2019_reference_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.68;                % central volume [L]
  p.CL = 0.415;                % clearance [L/h]
  p.Vp = [3.15];             % peripheral volumes [L]
  p.Q  = [0.533];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 0.07;             % dose [mg]
end
