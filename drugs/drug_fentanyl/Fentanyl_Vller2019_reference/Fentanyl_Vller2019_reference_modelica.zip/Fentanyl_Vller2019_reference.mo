model Fentanyl_Vller2019_reference
  parameter Real Cl_ref = 1.1527777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00868 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3364705,
    adminMass = 7e-08,
    ka = 0.0002777777777777778,
    Tlag = 900.0,
    k12 = 1.705709165386585e-05,
    k21 = 4.7001763668430345e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fentanyl</h4><p>Fentanyl is a synthetic opioid analgesic used to treat pain, including cancer-related and postoperative pain, and as an anesthetic adjuvant. It is widely used and authorised in the European Union, though it is a controlled substance carrying a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407541\">Wikidata Q407541</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>preterm neonates</td></tr><tr><td>source_paper:</td><td>Völler_2019</td></tr><tr><td>measured_compound:</td><td>fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fentanyl 336.471 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'On CL (%)' routed out of structural estimates ('Interindividual variability (eta)')</li><li>table section iiv: 'On V (%)' routed out of structural estimates ('Interindividual variability (eta)')</li><li>table section residual_error: 'Proportional (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive (μg/L)' routed out of structural estimates ('Residual variability')</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fentanyl</li><li>gap-filled Q49 (kabs) from Eleveld_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Andersen_1986's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Vller2019_reference;
