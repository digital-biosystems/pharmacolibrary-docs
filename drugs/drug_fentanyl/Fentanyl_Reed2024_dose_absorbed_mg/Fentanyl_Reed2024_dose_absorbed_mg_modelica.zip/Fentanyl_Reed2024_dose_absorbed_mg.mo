model Fentanyl_Reed2024_dose_absorbed_mg
  parameter Real Cl_ref = 1.2658333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>healthy adult horses</td></tr><tr><td>source_paper:</td><td>Reed_2024</td></tr><tr><td>measured_compound:</td><td>fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'LDF' — extend the ontology if this is a real PK parameter (source ['Reed_2024_table_3:row0:col2'])</li><li>dropped unlinked row (NIL): 'MDF' — extend the ontology if this is a real PK parameter (source ['Reed_2024_table_3:row1:col2'])</li><li>dropped unlinked row (NIL): 'HDF' — extend the ontology if this is a real PK parameter (source ['Reed_2024_table_3:row2:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fentanyl</li><li>population split: 'dose absorbed (mg)' subgroup of Reed_2024 (paper reports 4 populations: dose absorbed (mg), estimate, fractional bioavailability (%), target dose(mg))</li><li>gap-filled Q22 (CL) from Cavallaro_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Reed2024_dose_absorbed_mg;
