function p = Fentanyl_Reed2024_dose_absorbed_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Reed_2024 / dose_absorbed_mg   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Fentanyl_Reed2024_dose_absorbed_mg_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 45.57;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
