function p = Fentanyl_Ueshima2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Ueshima_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Fentanyl_Ueshima2025_reference_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.38;                % central volume [L]
  p.CL = 82.8;                % clearance [L/h]
  p.Vp = [6.906667];             % peripheral volumes [L]
  p.Q  = [0.018];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
