function p = Fentanyl_Choi2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Choi_2016 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fentanyl_Choi2016_reference_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 252.0;                % central volume [L]
  p.CL = 32.0;                % clearance [L/h]
  p.Vp = [474.0];             % peripheral volumes [L]
  p.Q  = [43.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
