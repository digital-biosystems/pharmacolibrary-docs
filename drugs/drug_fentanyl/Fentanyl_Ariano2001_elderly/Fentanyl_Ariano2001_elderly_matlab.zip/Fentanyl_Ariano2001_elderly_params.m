function p = Fentanyl_Ariano2001_elderly_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fentanyl   source: Ariano_2001 / elderly   route: oral
  % estimated (absent from source): F
  p.name  = 'Fentanyl_Ariano2001_elderly_params';
  p.drug  = 'fentanyl';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 85.4;                % central volume [L]
  p.CL = 206.5;                % clearance [L/h]
  p.Vp = [165.2];             % peripheral volumes [L]
  p.Q  = [1021.3];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 0.35;             % dose [mg]
end
