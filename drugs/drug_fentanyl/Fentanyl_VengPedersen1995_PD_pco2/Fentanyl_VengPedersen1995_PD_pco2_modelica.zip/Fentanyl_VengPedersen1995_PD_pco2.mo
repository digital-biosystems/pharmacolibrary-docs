model Fentanyl_VengPedersen1995_PD_pco2
  "sigmoid_emax exposure-response sweep — Veng-Pedersen_1995 :: pCO2 (transcutaneous pCO2)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 39.6,      // [1]
    Emax = 45.4,  // [1]
    EC50 = 4.73e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.33,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is transduction; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  annotation(experiment(StartTime = 0, StopTime = 4.8, Interval = 0.0096),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fentanyl</h4><p>Fentanyl is a synthetic opioid analgesic used to treat pain, including cancer-related and postoperative pain, and as an anesthetic adjuvant. It is widely used and authorised in the European Union, though it is a controlled substance carrying a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407541\">Wikidata Q407541</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Fentanyl_VengPedersen1995_PD_pco2</h4><p>The steady-state exposure-response curve of Veng-Pedersen P et al., <i>Journal of pharmaceutical sciences 84(9):1101–1106</i> 1995 (<a href=\"https://doi.org/10.1002/jps.2600840913\">doi:10.1002/jps.2600840913</a>) — transcutaneous pCO2 against fentanyl ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       39.6          drug-free response (baseline) (E0, Q324)
  Emax  =       45.4          maximal effect term (Emax, Q320)
  EC50  =      0.473 ng/mL    exposure at half of the maximal effect term (EC50a, Q321)
  gamma =       1.33          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of fentanyl per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 39.6   (drug-free)
  exposure = EC50 (0.473 ng/mL)  response 62.3
  exposure -> infinity  response 85</pre></body></html>"));
end Fentanyl_VengPedersen1995_PD_pco2;
