model Ribavirin_Jin2012_population_mean_in_final_pk_model
  parameter Real Cl_ref = 5.277777777777778e-06 "Cl [m3/s]";
  parameter Real cov_race_0 = 0 "race covariate";
  parameter Real Vd_ref = 1.1300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.5)*cov_race_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2442047,
    adminMass = 0.001,
    ka = 0.00023888888888888888,
    Tlag = 0.0,
    k12 = 9.488692232055063e-06,
    k21 = 2.667219458264234e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ribavirin</h4><p>Ribavirin is an antiviral nucleoside analogue used against viral infections such as hepatitis C, hepatitis E, and respiratory syncytial virus infection. It is included on the WHO essential medicines list and remains in use, though several European marketing authorisations have been withdrawn or lapsed; it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421862\">Wikidata Q421862</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ribavirin</td></tr><tr><td>population:</td><td>adults with chronic hepatitis C genotype 1 infection</td></tr><tr><td>source_paper:</td><td>Jin_2012</td></tr><tr><td>measured_compound:</td><td>ribavirin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ribavirin 244.205 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Race factor' → Q900:race_factor = 1.50 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ribavirin</li><li>population split: 'population mean in final pk model' subgroup of Jin_2012 (paper reports 2 populations: mean of 25 leverage runs (% cv), population mean in final pk model)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Ribavirin_Jin2012_population_mean_in_final_pk_model;
