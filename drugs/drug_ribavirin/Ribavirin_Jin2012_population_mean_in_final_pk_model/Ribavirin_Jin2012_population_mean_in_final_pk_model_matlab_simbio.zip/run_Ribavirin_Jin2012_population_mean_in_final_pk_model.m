% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Ribavirin_Jin2012_population_mean_in_final_pk_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
