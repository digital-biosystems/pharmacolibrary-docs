model Ribavirin_Wade2006_reference
  parameter Real Cl_ref = 5.500000000000001e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.47200000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2442047,
    adminMass = 0.0006,
    ka = 0.0004027777777777778,
    Tlag = 0.0,
    k12 = 2.0244821092278717e-05,
    k21 = 1.946141661009278e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ribavirin</h4><p>Ribavirin is an antiviral nucleoside analogue used against viral infections such as hepatitis C, hepatitis E, and respiratory syncytial virus infection. It is included on the WHO essential medicines list and remains in use, though several European marketing authorisations have been withdrawn or lapsed; it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421862\">Wikidata Q421862</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ribavirin</td></tr><tr><td>population:</td><td>adults with hepatitis C virus</td></tr><tr><td>source_paper:</td><td>Wade_2006</td></tr><tr><td>measured_compound:</td><td>ribavirin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ribavirin 244.205 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL* (l h -1 )' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'V 1 (l)' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'Q2 (l h -1 )' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'V 2 * (l)' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'Q3 (l h -1 )' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'V 3 (l)' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'F 1 (fasting and standard meal) F 1 (high-fat meal)' routed out of structural estimates ('Interindividual')</li><li>table section iov: 'F 1 (fasting and standard meal) F 1 (high-fat meal)' routed out of structural estimates ('Interoccasion')</li><li>table section iiv: 'D1 (fasting and standard meal) (h) D1 (high-fat meal) (h)' routed out of structural estimates ('Interindividual')</li><li>table section iov: 'D1 (fasting and standard meal) (h) D1 (high-fat meal) (h)' routed out of structural estimates ('Interoccasion')</li><li>table section iiv: 'K a (standard meal) (h -1 )' routed out of structural estimates ('Interindividual')</li><li>table section iov: 'K a (standard meal) (h -1 )' routed out of structural estimates ('Interoccasion')</li><li>dropped duplicate Q64 ('LBW on V 2', value '0.011') — already have one for this compound</li><li>unit_dimension_unknown: 'high-fat meal' (Fab)</li><li>dropped duplicate Q49 ('K a (standard meal) (h -1 )', value '0.767') — already have one for this compound</li><li>dropped duplicate Q49 ('K a (high-fat meal) (h -1 )', value '0.99') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Ribavirin_Wade2006_reference;
