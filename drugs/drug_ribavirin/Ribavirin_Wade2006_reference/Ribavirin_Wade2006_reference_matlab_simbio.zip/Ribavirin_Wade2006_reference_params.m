function p = Ribavirin_Wade2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ribavirin   source: Wade_2006 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ribavirin_Wade2006_reference_params';
  p.drug  = 'ribavirin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 472.0;                % central volume [L]
  p.CL = 19.8;                % clearance [L/h]
  p.Vp = [4910.0];             % peripheral volumes [L]
  p.Q  = [34.4];             % inter-compartmental clearances [L/h]
  p.ka = 1.45;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
