function p = Ribavirin_Jin2012_mean_of_25_leverage_runs_cv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ribavirin   source: Jin_2012 / mean_of_25_leverage_runs_cv   route: oral
  p.name  = 'Ribavirin_Jin2012_mean_of_25_leverage_runs_cv_params';
  p.drug  = 'ribavirin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1151.0;                % central volume [L]
  p.CL = 19.12;                % clearance [L/h]
  p.Vp = [3992.0];             % peripheral volumes [L]
  p.Q  = [37.07];             % inter-compartmental clearances [L/h]
  p.ka = 0.91;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
