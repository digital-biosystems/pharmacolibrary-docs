% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Ribavirin_Jin2012_mean_of_25_leverage_runs_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
