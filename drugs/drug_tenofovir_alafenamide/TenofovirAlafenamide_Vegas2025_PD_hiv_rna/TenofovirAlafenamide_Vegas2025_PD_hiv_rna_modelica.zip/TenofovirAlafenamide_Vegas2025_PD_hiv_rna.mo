model TenofovirAlafenamide_Vegas2025_PD_hiv_rna
  "sigmoid_emax exposure-response sweep — Vegas_2025 :: HIV-RNA (HIV-RNA (viral load))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 43460.16,      // [copies/mL]
    Emax = -0.99,  // [copies/mL]
    EC50 = 8.5e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 85, Interval = 0.17),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tenofovir_alafenamide</h4><p>Tenofovir alafenamide is an antiviral used to treat hepatitis B, including chronic hepatitis B, and HIV infection. It is an approved medicine and is authorised in the European Union, where it is used fairly widely.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q22075912\">Wikidata Q22075912</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>TenofovirAlafenamide_Vegas2025_PD_hiv_rna</h4><p>The steady-state exposure-response curve of Vegas Rodriguez A et al., <i>The AAPS journal 27(6):161</i> 2025 (<a href=\"https://doi.org/10.1208/s12248-025-01136-4\">doi:10.1208/s12248-025-01136-4</a>) — HIV-RNA (viral load) [copies/mL] against tenofovir alafenamide/tenofovir (TAF/TFV) ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =   43460.16 copies/mL drug-free response (baseline) (V0, Q324)
  Emax  =       0.99 copies/mL maximal effect term (EMAX, Q323)
  EC50  =        8.5 ng/mL    exposure at half of the maximal effect term (EC50 TAF/TFV, Q321)
  gamma =          1          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of tenofovir alafenamide/tenofovir (TAF/TFV) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.346e+04   (drug-free)
  exposure = EC50 (8.5 ng/mL)  response 4.346e+04
  exposure -> infinity  response 4.346e+04</pre></body></html>"));
end TenofovirAlafenamide_Vegas2025_PD_hiv_rna;
