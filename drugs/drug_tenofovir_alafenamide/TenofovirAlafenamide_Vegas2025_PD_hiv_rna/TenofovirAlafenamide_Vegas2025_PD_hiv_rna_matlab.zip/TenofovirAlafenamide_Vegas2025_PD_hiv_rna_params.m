function p = TenofovirAlafenamide_Vegas2025_PD_hiv_rna_params()
% TenofovirAlafenamide_Vegas2025_PD_hiv_rna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tenofovir_alafenamide Vegas_2025::HIV_RNA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HIV-RNA in copies/mL. Driver: tenofovir alafenamide/tenofovir (TAF/TFV) (conc_no_pk).
p.E0 = 43460.16;
p.Emax = -0.99;
p.EC50 = 8.5e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 85.0;
p.form = 'E0 + Emax*frac';
end
