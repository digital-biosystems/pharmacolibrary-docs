model Tetrodotoxin_Hong2018_intragastric_tetrodotoxin_of_100_g_kg
  parameter Real Cl_ref = 0.0003536676111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 5.3393396 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31927,
    adminMass = 7e-08
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetrodotoxin</td></tr><tr><td>population:</td><td>Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Hong_2018</td></tr><tr><td>measured_compound:</td><td>Tetrodotoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>marinedrugs-16-00195-t005</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tetrodotoxin 319.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tetrodotoxin</li><li>population split: 'intragastric tetrodotoxin of 100 μg/kg' subgroup of Hong_2018 (paper reports 2 populations: intragastric tetrodotoxin of 100 μg/kg, intravenous tetrodotoxin of 6 μg/kg)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tetrodotoxin_Hong2018_intragastric_tetrodotoxin_of_100_g_kg;
