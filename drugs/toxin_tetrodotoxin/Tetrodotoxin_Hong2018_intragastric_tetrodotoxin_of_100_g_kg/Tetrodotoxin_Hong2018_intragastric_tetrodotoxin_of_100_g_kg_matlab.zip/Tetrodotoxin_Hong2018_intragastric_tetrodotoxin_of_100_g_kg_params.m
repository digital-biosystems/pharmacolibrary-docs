function p = Tetrodotoxin_Hong2018_intragastric_tetrodotoxin_of_100_g_kg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetrodotoxin   source: Hong_2018 / intragastric_tetrodotoxin_of_100_g_kg   route: iv_bolus
  p.name  = 'Tetrodotoxin_Hong2018_intragastric_tetrodotoxin_of_100_g_kg_params';
  p.drug  = 'tetrodotoxin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5339.3396;                % central volume [L]
  p.CL = 1273.2034;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.067;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.07;             % dose [mg]
end
