// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tetrodotoxin_Hong2017_total_radioactivity_in_dried_plasma_ma
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {7307.999999999999},
    MM = 0.31927,
    adminMass = 6e-09,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetrodotoxin</td></tr><tr><td>population:</td><td>Adult Sprague-Dawley Rats</td></tr><tr><td>source_paper:</td><td>Hong_2017</td></tr><tr><td>measured_compound:</td><td>Tetrodotoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>marinedrugs-15-00159-t003</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>tetrodotoxin 319.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ng Eq./mL' (Cmax)</li><li>unit_dimension_unknown: 'h·ng Eq./mL' (AUCt)</li><li>unit_dimension_unknown: 'h·ng Eq./mL' (AUC∞)</li><li>implicit units: 'Cmax a (ng Eq./mL)' — the LLM proposed 'ng Eq./mL', whose dimension does not fit Q32; left unset</li><li>implicit units: 'AUC0–t a (h·ng Eq./mL)' — the LLM proposed 'h·ng Eq./mL', whose dimension does not fit Q19; left unset</li><li>implicit units: 'AUC0–∞ a (h·ng Eq./mL)' — the LLM proposed 'h·ng Eq./mL', whose dimension does not fit Q17; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tetrodotoxin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'total radioactivity in dried plasma / male' subgroup of Hong_2017 (paper reports 3 populations: total radioactivity in dried plasma / average, total radioactivity in dried plasma / female, total radioactivity in dried plasma / male)</li><li>gap-filled Q22 (CL) from Hong_2018's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hong_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Tetrodotoxin_Hong2017_total_radioactivity_in_dried_plasma_ma;
