function p = Tetrodotoxin_Hong2018_intravenous_tetrodotoxin_of_6_g_kg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetrodotoxin   source: Hong_2018 / intravenous_tetrodotoxin_of_6_g_kg   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tetrodotoxin_Hong2018_intravenous_tetrodotoxin_of_6_g_kg_params';
  p.drug  = 'tetrodotoxin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 127.7276;                % central volume [L]
  p.CL = 94.458;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.07;             % dose [mg]
end
