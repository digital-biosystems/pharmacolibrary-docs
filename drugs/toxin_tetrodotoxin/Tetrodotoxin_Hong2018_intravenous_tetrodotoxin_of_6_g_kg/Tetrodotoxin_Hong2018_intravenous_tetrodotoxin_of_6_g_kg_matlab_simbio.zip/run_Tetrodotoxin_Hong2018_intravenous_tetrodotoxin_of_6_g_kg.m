% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Tetrodotoxin_Hong2018_intravenous_tetrodotoxin_of_6_g_kg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
