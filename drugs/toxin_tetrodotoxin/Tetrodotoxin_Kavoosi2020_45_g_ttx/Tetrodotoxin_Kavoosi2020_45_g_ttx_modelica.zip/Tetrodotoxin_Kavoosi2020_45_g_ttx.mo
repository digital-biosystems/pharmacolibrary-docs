// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tetrodotoxin_Kavoosi2020_45_g_ttx
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {16200.0},
    MM = 0.31927,
    adminMass = 1.5e-08,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetrodotoxin</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Kavoosi_2020</td></tr><tr><td>measured_compound:</td><td>Tetrodotoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>toxins-12-00511-t003</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>tetrodotoxin 319.27 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Geometric Mean'; source reconciliation required</li><li>table representations disagree for 'Median'; source reconciliation required</li><li>table representations disagree for 'Arithmetic Mean'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Geometric Mean' — extend the ontology if this is a real PK parameter (source ['toxins-12-00511-t003:row2:col3', 'toxins-12-00511-t003:row5:col3'])</li><li>dropped unlinked row (NIL): 'Median' — extend the ontology if this is a real PK parameter (source ['toxins-12-00511-t003:row8:col3'])</li><li>dropped unlinked row (NIL): 'Arithmetic Mean' — extend the ontology if this is a real PK parameter (source ['toxins-12-00511-t003:row11:col3'])</li><li>salvaged Q57 ('half-life'=4.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tetrodotoxin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: '45 µg ttx(n = 9)' subgroup of Kavoosi_2020 (paper reports 3 populations: 15 µg ttx a(n = 9), 30 µg ttx(n = 9), 45 µg ttx(n = 9))</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Tetrodotoxin_Kavoosi2020_45_g_ttx;
