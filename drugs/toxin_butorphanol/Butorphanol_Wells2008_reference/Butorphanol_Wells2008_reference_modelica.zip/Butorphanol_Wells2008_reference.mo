model Butorphanol_Wells2008_reference
  parameter Real Cl_ref = 0.0003713111111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 0.24569999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32746800000000004,
    adminMass = 1.2e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>butorphanol</td></tr><tr><td>population:</td><td>healthy adult cats</td></tr><tr><td>source_paper:</td><td>Wells_2008</td></tr><tr><td>measured_compound:</td><td>Butorphanol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>butorphanol 327.468 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Wells_2008:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Wells_2008:abstract'])</li><li>'Extent of butorphanol absorption' → Q40: printed without a unit and above 1 — read as a percentage</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Butorphanol</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Saeed_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Saeed_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Saeed_2026 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Butorphanol_Wells2008_reference;
