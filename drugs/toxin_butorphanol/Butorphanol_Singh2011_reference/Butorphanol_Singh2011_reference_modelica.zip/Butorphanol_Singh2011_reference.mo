model Butorphanol_Singh2011_reference
  parameter Real Cl_ref = 4.561666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.48300000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32746800000000004,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>butorphanol</td></tr><tr><td>population:</td><td>healthy broiler chickens</td></tr><tr><td>source_paper:</td><td>Singh_2011</td></tr><tr><td>measured_compound:</td><td>Butorphanol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>butorphanol 327.468 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q47 ('k(12)', value 0.05) — already have one for this compound</li><li>dropped duplicate Q47 ('k(10)', value 0.029) — already have one for this compound</li><li>implicit units: 'k(21)' → 1/h (from the popPK convention: 'The paper does not specify units. In population pharmacokinetics, first-order rate constants (such as elimination rate c')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Butorphanol</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=16.422 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Butorphanol_Singh2011_reference;
