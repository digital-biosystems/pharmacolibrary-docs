function p = Butorphanol_Pfeffer1980_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: butorphanol   source: Pfeffer_1980 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Butorphanol_Pfeffer1980_reference_params';
  p.drug  = 'butorphanol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 557.2;                % central volume [L]
  p.CL = 241.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
