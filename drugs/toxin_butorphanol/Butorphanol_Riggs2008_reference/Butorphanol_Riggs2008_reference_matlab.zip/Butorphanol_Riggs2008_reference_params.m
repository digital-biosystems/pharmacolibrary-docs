function p = Butorphanol_Riggs2008_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: butorphanol   source: Riggs_2008 / reference   TK_Retention retention function, 1 pool (V = 1 L each: A/V = burden in mg)
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
  p.name  = 'Butorphanol_Riggs2008_reference_params';
  p.drug  = 'butorphanol';
  p.kind  = 'network';
  p.template = 'TK_Retention';
  p.states = {'pool_1'};
  p.V = [1.0];          % compartment volumes [L]
  p.K = [-0.7373906176169631];
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;
  p.dose_into = [1.0];   % pools
  p.dose_frac = [1.0];   % fraction A_i of the intake
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 12.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0];
  p.out_names = {'burden'};
  p.out_labels = {'whole-body burden (mg)'};
end
