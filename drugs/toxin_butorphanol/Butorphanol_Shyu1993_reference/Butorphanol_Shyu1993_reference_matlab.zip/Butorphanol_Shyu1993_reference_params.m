function p = Butorphanol_Shyu1993_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: butorphanol   source: Shyu_1993 / reference   route: iv_bolus
  p.name  = 'Butorphanol_Shyu1993_reference_params';
  p.drug  = 'butorphanol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 245.7;                % central volume [L]
  p.CL = 121.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.72;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
