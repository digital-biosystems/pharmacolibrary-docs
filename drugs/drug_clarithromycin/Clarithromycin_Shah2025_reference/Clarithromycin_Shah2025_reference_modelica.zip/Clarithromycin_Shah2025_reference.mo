model Clarithromycin_Shah2025_reference
  parameter Real Cl_ref = 2.2694444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0257 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clarithromycin</td></tr><tr><td>population:</td><td>critically ill adults</td></tr><tr><td>source_paper:</td><td>Shah_2025</td></tr><tr><td>measured_compound:</td><td>clarithromycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-14-00559-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'θV2 (L/h/70 kg)' — extend the ontology if this is a real PK parameter (source ['antibiotics-14-00559-t002:row5:col1', 'antibiotics-14-00559-t002:row5:col2', 'antibiotics-14-00559-t002:row5:col3'])</li><li>dropped duplicate Q22 ('η2 CL', value '0.53') — already have one for this compound</li><li>dropped duplicate Q63 ('η2 V1', value '1.55') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clarithromycin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'θV1 (L/70 kg)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clarithromycin_Shah2025_reference;
