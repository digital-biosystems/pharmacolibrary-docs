model SebacicAcid_Favuzzi1999_reference
  parameter Real Cl_ref = 5.45279e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026817 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sebacic_acid</td></tr><tr><td>population:</td><td>Wistar rats of both sexes</td></tr><tr><td>source_paper:</td><td>Favuzzi_1999</td></tr><tr><td>measured_compound:</td><td>Sebacic acid (as disodium sebacate)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sebacic_acid 202.25 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml/100 g bw' (V)</li><li>unit_dimension_unknown: 'ml/min/100 g of bw' (CLR)</li><li>unit_dimension_unknown: 'ml/min/100 g bw' (Q)</li><li>dropped unlinked row (NIL): 'form' — extend the ontology if this is a real PK parameter (source ['Favuzzi_1999:abstract'])</li><li>implicit units: 'overall volume of distribution' → L (from the popPK convention: 'Volume of distribution is conventionally expressed in liters (L) or L/kg; given the parameter is labeled as an absolute ')</li><li>implicit units: 'renal clearance' → L/h (from the popPK convention: 'Clearance parameters, including renal clearance, are conventionally expressed in liters per hour (L/h).')</li><li>implicit units: 'GFR' → L/h (from the popPK convention: &quot;Although labeled 'GFR' (Glomerular Filtration Rate), the parameter description defines it as 'Apparent intercompartmenta&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sebacic acid (as disodium sebacate)</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>molar mass: no plausible PubChem entry for 'Sebacic acid (as disodium sebacate)' ('sebacic acid (as disodium sebacate)') — left in mass units</li><li>molar mass: none found for 'Sebacic acid (as disodium sebacate)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=19.63 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SebacicAcid_Favuzzi1999_reference;
