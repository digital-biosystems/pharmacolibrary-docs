// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SebacicAcid_Tataranni1992_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2322.6},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sebacic_acid</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Tataranni_1992</td></tr><tr><td>measured_compound:</td><td>Sebacic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>sebacic_acid 202.25 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'eliminated as 14CO2 in expired air' → Q44: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q57 ('sebacate half-life in adipose tissue', value 135) — already have one for this compound</li><li>dropped duplicate Q57 ('sebacate half-life in liver', value 74) — already have one for this compound</li><li>implicit units: 'administered tracer excreted in the urine as unchanged sebacate' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Sebacic acid</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: PubChem entry choice failed (JSONDecodeError)</li><li>molar mass: none of 1 PubChem candidate(s) is 'Sebacic acid' (LLM) — left in mass units</li><li>molar mass: none found for 'Sebacic acid' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end SebacicAcid_Tataranni1992_reference;
