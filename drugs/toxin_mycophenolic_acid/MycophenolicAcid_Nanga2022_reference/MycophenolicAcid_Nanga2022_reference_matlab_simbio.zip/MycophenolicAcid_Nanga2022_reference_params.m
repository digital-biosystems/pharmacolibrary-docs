function p = MycophenolicAcid_Nanga2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Nanga_2022 / reference   route: oral
  p.name  = 'MycophenolicAcid_Nanga2022_reference_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 35.9;                % central volume [L]
  p.CL = 4.99;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 8.7;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
