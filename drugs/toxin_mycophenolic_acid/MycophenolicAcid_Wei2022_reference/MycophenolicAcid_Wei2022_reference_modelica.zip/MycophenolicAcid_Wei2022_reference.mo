model MycophenolicAcid_Wei2022_reference
  parameter Real Cl_ref = 1.3861111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    ka = 0.0005555555555555556,
    Tlag = 0.0,
    k21 = 1.590251961999174e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mycophenolic_acid</td></tr><tr><td>population:</td><td>pediatric patients early after liver transplantation</td></tr><tr><td>source_paper:</td><td>Wei_2022</td></tr><tr><td>measured_compound:</td><td>mycophenolic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mycophenolic_acid 320.341 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>routed 'RV (%)' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>metabolite mycophenolic acid: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=mycophenolic acid</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 0/9 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'mycophenolate mofetil' — its concentrations stay mass-only</li><li>molar mass: none found for 'mycophenolic acid' — its concentrations stay mass-only</li><li>gap-filled Q27 (CL/F) from Fromage_2025's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MycophenolicAcid_Wei2022_reference;
