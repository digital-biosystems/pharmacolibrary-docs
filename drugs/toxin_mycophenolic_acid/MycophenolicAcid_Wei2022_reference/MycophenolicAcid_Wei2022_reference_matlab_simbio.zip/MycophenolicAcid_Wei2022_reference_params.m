function p = MycophenolicAcid_Wei2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Wei_2022 / reference   route: oral
  p.name  = 'MycophenolicAcid_Wei2022_reference_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.0;                % central volume [L]
  p.CL = 4.99;                % clearance [L/h]
  p.Vp = [269.0];             % peripheral volumes [L]
  p.Q  = [15.4];             % inter-compartmental clearances [L/h]
  p.ka = 2.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
