model MycophenolicAcid_Wang2021_reference
  parameter Real Cl_ref = 2.0444444444444447e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0126 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00025,
    ka = 0.0003361111111111111,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mycophenolic_acid</td></tr><tr><td>population:</td><td>adult heart transplant recipients taking mycophenolate mofetil</td></tr><tr><td>source_paper:</td><td>Wang_2021</td></tr><tr><td>measured_compound:</td><td>mycophenolic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mycophenolic_acid 320.341 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'Frel' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'omega_cov' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q27 ('CL/F'=7.36) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=17.0) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=mycophenolic acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (T2:footnote, Wang_2021:discussion_prose, Wang_2021:other_prose); populations results by bootstraps (n = 1,000) / median, values kept as separate records</li><li>molar mass: none found for 'mycophenolic acid' — its concentrations stay mass-only</li><li>gap-filled Q76 (V/F) from Fromage_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kauv_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kauv_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Fromage_2025, Kauv_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MycophenolicAcid_Wang2021_reference;
