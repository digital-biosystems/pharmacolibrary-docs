function p = MycophenolicAcid_RomanoAguilar2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Romano-Aguilar_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'MycophenolicAcid_RomanoAguilar2020_reference_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.86;                % central volume [L]
  p.CL = 15.4;                % clearance [L/h]
  p.Vp = [768.0];             % peripheral volumes [L]
  p.Q  = [20.3];             % inter-compartmental clearances [L/h]
  p.ka = 1.28;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
