function p = MycophenolicAcid_Saqr2026_eubacterium_callanderi_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Saqr_2026 / eubacterium_callanderi   route: oral
  p.name  = 'MycophenolicAcid_Saqr2026_eubacterium_callanderi_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.6;                % central volume [L]
  p.CL = 4.99;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
