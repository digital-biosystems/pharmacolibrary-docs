function p = MycophenolicAcid_Maizaud2025_rong_et_al_27_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Maizaud_2025 / rong_et_al_27   route: oral
  % estimated (absent from source): F
  p.name  = 'MycophenolicAcid_Maizaud2025_rong_et_al_27_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.73;                % central volume [L]
  p.CL = 9.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
