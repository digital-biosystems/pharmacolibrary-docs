model MycophenolicAcid_Quintairos2021_mpa_value_rse
  parameter Real Cl_ref = 3.277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.106 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.002,
    ka = 0.0004972222222222222,
    Tlag = 0.0,
    k21 = 1.2881944444444445e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mycophenolic_acid</td></tr><tr><td>population:</td><td>de novo adult kidney transplant recipients</td></tr><tr><td>source_paper:</td><td>Quintairos_2021</td></tr><tr><td>measured_compound:</td><td>Mycophenolic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone.0245880.t004</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mycophenolic_acid 320.341 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error')</li><li>table section iiv: 'CL' routed out of structural estimates ('BSV was only be associated with the whole blood clearance (CL), intercompartmental clearance (Q) and central volume of distribution (VC).')</li><li>table section iiv: 'Q' routed out of structural estimates ('BSV was only be associated with the whole blood clearance (CL), intercompartmental clearance (Q) and central volume of distribution (VC).')</li><li>table section iiv: 'VC' routed out of structural estimates ('BSV was only be associated with the whole blood clearance (CL), intercompartmental clearance (Q) and central volume of distribution (VC).')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL); Q63 (VC); Q30 (Q); Q64 (VP)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mycophenolic acid</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'mpa / value (rse%)' subgroup of Quintairos_2021 (paper reports 2 populations: mpa / value (rse%), tacrolimus / value (rse%))</li><li>molar mass: none found for 'Mycophenolic acid' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end MycophenolicAcid_Quintairos2021_mpa_value_rse;
