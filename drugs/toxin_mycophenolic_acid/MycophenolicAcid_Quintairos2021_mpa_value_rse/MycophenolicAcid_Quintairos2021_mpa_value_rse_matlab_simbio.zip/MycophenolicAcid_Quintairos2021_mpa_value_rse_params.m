function p = MycophenolicAcid_Quintairos2021_mpa_value_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Quintairos_2021 / mpa_value_rse   route: oral
  % estimated (absent from source): F
  p.name  = 'MycophenolicAcid_Quintairos2021_mpa_value_rse_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 106.0;                % central volume [L]
  p.CL = 11.8;                % clearance [L/h]
  p.Vp = [800.0];             % peripheral volumes [L]
  p.Q  = [37.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.79;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
