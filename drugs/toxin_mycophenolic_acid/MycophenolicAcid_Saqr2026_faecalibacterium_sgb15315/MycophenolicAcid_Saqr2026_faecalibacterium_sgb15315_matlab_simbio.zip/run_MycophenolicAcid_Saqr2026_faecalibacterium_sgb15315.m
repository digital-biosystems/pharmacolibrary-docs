% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = MycophenolicAcid_Saqr2026_faecalibacterium_sgb15315_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
