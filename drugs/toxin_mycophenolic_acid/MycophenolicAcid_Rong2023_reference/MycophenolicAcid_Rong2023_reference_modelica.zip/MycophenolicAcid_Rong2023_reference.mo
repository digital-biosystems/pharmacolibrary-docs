model MycophenolicAcid_Rong2023_reference
  parameter Real Cl_ref = 2e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0228 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.002,
    ka = 0.0007,
    Tlag = 597.6,
    k12 = 0.00021442495126705653,
    k21 = 2.263374485596708e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mycophenolic_acid</td></tr><tr><td>population:</td><td>pediatric kidney transplant recipients</td></tr><tr><td>source_paper:</td><td>Rong_2023</td></tr><tr><td>measured_compound:</td><td>mycophenolic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mycophenolic_acid 320.341 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (volumes of distributions of the central); Q64 (peripheral); Q30 (intercompartment clearance); Q22 (total MPA clearance)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mycophenolic acid</li><li>molar mass: none found for 'mycophenolic acid' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end MycophenolicAcid_Rong2023_reference;
