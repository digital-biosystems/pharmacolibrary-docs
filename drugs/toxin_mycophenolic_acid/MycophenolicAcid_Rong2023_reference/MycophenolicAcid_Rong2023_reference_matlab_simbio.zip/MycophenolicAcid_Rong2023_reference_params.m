function p = MycophenolicAcid_Rong2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Rong_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'MycophenolicAcid_Rong2023_reference_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.8;                % central volume [L]
  p.CL = 0.72;                % clearance [L/h]
  p.Vp = [216.0];             % peripheral volumes [L]
  p.Q  = [17.6];             % inter-compartmental clearances [L/h]
  p.ka = 2.52;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.166;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
