model MycophenolicAcid_Elmowafy2026_reference
  parameter Real Cl_ref = 2.5833333333333337e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0037300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.002,
    ka = 0.0003361111111111111,
    Tlag = 900.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mycophenolic_acid</td></tr><tr><td>population:</td><td>Egyptian female patients with active lupus nephritis (ISN/RPS class III-IV)</td></tr><tr><td>source_paper:</td><td>Elmowafy_2026</td></tr><tr><td>measured_compound:</td><td>Mycophenolic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mycophenolic_acid 320.341 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'S. creatinine' — extend the ontology if this is a real PK parameter (source ['Elmowafy_2026_table_p13_1:row0:col3', 'Elmowafy_2026_table_p13_1:row0:col4'])</li><li>dropped unlinked row (NIL): 'Proteinuria' — extend the ontology if this is a real PK parameter (source ['Elmowafy_2026_table_p13_1:row1:col3', 'Elmowafy_2026_table_p13_1:row1:col4'])</li><li>dropped unlinked row (NIL): 'Activity index' — extend the ontology if this is a real PK parameter (source ['Elmowafy_2026_table_p13_1:row3:col3', 'Elmowafy_2026_table_p13_1:row3:col4'])</li><li>dropped unlinked row (NIL): 'Chronicity index' — extend the ontology if this is a real PK parameter (source ['Elmowafy_2026_table_p13_1:row4:col3', 'Elmowafy_2026_table_p13_1:row4:col4'])</li><li>dropped unlinked row (NIL): 'Type of induction (MMF vs cyclophosphamide)' — extend the ontology if this is a real PK parameter (source ['Elmowafy_2026_table_p13_1:row5:col3', 'Elmowafy_2026_table_p13_1:row5:col4'])</li><li>dropped unlinked row (NIL): 'SLCO1B1 (AT vs TT)' — extend the ontology if this is a real PK parameter (source ['Elmowafy_2026_table_p13_1:row7:col3', 'Elmowafy_2026_table_p13_1:row7:col4'])</li><li>table mostly unlinked (6/7 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mycophenolic acid</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=other; 0/8 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'Mycophenolate mofetil' — its concentrations stay mass-only</li><li>molar mass: none found for 'Mycophenolic acid' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Tsyplakova_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MycophenolicAcid_Elmowafy2026_reference;
