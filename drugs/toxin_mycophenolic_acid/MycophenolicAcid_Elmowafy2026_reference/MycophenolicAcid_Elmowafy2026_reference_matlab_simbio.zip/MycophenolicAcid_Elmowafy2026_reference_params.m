function p = MycophenolicAcid_Elmowafy2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mycophenolic_acid   source: Elmowafy_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'MycophenolicAcid_Elmowafy2026_reference_params';
  p.drug  = 'mycophenolic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.73;                % central volume [L]
  p.CL = 9.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.25;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
