function p = Tafenoquine_Watson2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tafenoquine   source: Watson_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Tafenoquine_Watson2022_reference_params';
  p.drug  = 'tafenoquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1330.0;                % central volume [L]
  p.CL = 3.14;                % clearance [L/h]
  p.Vp = [311.0];             % peripheral volumes [L]
  p.Q  = [5.82];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.147;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
