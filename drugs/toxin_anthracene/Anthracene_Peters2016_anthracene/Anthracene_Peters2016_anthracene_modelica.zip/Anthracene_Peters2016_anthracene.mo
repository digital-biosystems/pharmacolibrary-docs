// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Anthracene_Peters2016_anthracene
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {891.1892321485011},
    MM = 0.178234,
    adminMass = 1.0000000000000001e-11,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>anthracene</td></tr><tr><td>population:</td><td>juvenile swine</td></tr><tr><td>source_paper:</td><td>Peters_2016</td></tr><tr><td>measured_compound:</td><td>Anthracene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>anthracene 178.234 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table tab_2: rows are variants (Anthracene, Benzo[a]pyrene), the parameters are the column headers (Average Bioavailability (%)) — read one record per variant</li><li>salvaged Q47 ('Average k a values calculated for combined artificial and real-world soils anthracene'=2.8) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Absorption rate constants reported in both rats and mice, for benzo[a]anthracene, pyrene, and phenanthrene, range from'=0.69) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Anthracene</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'Anthracene' is one of 2 estimates of Peters_2016's substance matrix (Anthracene, Benzo[a]pyrene); same population, different estimation method</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Anthracene_Peters2016_anthracene;
