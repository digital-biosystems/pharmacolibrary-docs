model Anthracene_Jia2023_PD_mt_cox1
  "linear exposure-response sweep — Jia_2023 :: MT-COX1 (MT-COX1 methylation)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 8310,  // [meter ** 3 / kilogram; %/(ng/mL) × 10000]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Anthracene_Jia2023_PD_mt_cox1</h4><p>The steady-state exposure-response curve of Jia Y et al., <i>Toxics 11(5)</i> 2023 (<a href=\"https://doi.org/10.3390/toxics11050466\">doi:10.3390/toxics11050466</a>) — MT-COX1 methylation [%] against Anthracene ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.831 %/(ng/mL) change in response per unit of exposure (Slope (Anthracene), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of Anthracene per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Anthracene_Jia2023_PD_mt_cox1;
