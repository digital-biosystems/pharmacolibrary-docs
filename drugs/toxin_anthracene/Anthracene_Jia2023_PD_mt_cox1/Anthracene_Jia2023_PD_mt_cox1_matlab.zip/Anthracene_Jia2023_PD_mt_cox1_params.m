function p = Anthracene_Jia2023_PD_mt_cox1_params()
% Anthracene_Jia2023_PD_mt_cox1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% anthracene Jia_2023::MT_COX1: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response MT-COX1 in %. Driver: Anthracene (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 8310.000000000002;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
