function p = Ketamine_Herd2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketamine   source: Herd_2007 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ketamine_Herd2007_reference_params';
  p.drug  = 'ketamine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1540.0;                % central volume [L]
  p.CL = 945.0;                % clearance [L/h]
  p.Vp = [9030.0];             % peripheral volumes [L]
  p.Q  = [15120.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.66;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
