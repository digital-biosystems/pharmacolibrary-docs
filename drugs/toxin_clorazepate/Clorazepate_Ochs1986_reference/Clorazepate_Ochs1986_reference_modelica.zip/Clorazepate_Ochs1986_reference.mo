model Clorazepate_Ochs1986_reference
  parameter Real Cl_ref = 3.2783333333333336e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0889 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clorazepate</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Ochs_1986</td></tr><tr><td>measured_compound:</td><td>Desmethyldiazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Clorazepate 314.725 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is clorazepate; the compartment is Desmethyldiazepam. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Desmethyldiazepam, not clorazepate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>clorazepate's own concentration-time course is not produced by this model</li><li>unit_dimension_unknown: '% unbound' (fu)</li><li>unit_dimension_unknown: '% unbound' (fu)</li><li>dropped duplicate Q46 ('free fraction in serum (propranolol treatment)', value 1.8) — already have one for this compound</li><li>dropped duplicate Q57 ('desmethyldiazepam half-life (propranolol treatment)', value 61) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance (propranolol treatment)', value 0.247) — already have one for this compound</li><li>dropped duplicate Q61 ('desmethyldiazepam volume of distribution (controls)', value 1.29) — already have one for this compound</li><li>dropped duplicate Q61 ('desmethyldiazepam volume of distribution (cigarette smokers)', value 1.34) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life (controls)', value 55) — already have one for this compound</li><li>dropped duplicate Q57 ('elimination half-life (cigarette smokers)', value 59) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance (controls)', value 0.284) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance (cigarette smokers)', value 0.276) — already have one for this compound</li><li>unit_dimension_unknown: '% unbound' (fu)</li><li>dropped duplicate Q46 ('free fraction in serum (controls)', value 1.96) — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Clorazepate_Ochs1986_reference;
