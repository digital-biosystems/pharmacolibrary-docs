model Clorazepate_Forrester1990_reference
  parameter Real Cl_ref = 3.6049999999999994e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1232 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00016045073624072808,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clorazepate</td></tr><tr><td>population:</td><td>healthy dogs</td></tr><tr><td>source_paper:</td><td>Forrester_1990</td></tr><tr><td>measured_compound:</td><td>nordiazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>clorazepate 314.725 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is clorazepate; the compartment is nordiazepam. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is nordiazepam, not clorazepate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>clorazepate's own concentration-time course is not produced by this model</li><li>dropped duplicate Q76 ('Oral volume of distribution after a single dose', value 3.18) — already have one for this compound</li><li>dropped duplicate Q27 ('Oral clearance after a single dose', value 6.54) — already have one for this compound</li><li>dropped duplicate Q95 ('Absorption half-life after a single dose', value 33) — already have one for this compound</li><li>metabolite nordiazepam: Q76→Q376 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>metabolite nordiazepam: Q27→Q375 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nordiazepam</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/6 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'clorazepate dipotassium' — its concentrations stay mass-only</li><li>molar mass: none found for 'nordiazepam' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Clorazepate_Forrester1990_reference;
