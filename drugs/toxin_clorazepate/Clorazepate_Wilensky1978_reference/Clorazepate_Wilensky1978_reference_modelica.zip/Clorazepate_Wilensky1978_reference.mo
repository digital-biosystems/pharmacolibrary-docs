model Clorazepate_Wilensky1978_reference
  parameter Real Cl_ref = 5.733333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1141 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clorazepate</td></tr><tr><td>population:</td><td>treated epileptic patients</td></tr><tr><td>source_paper:</td><td>Wilensky_1978</td></tr><tr><td>measured_compound:</td><td>Desmethyldiazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Clorazepate 314.725 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is clorazepate; the compartment is Desmethyldiazepam. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Desmethyldiazepam, not clorazepate</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>clorazepate's own concentration-time course is not produced by this model</li><li>dropped value-less row: 'Peak serum concentrations of demethyldiazepam occurred in'</li><li>metabolite desmethyldiazepam: Q76→Q376 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided), normalised to a standard size</li><li>metabolite desmethyldiazepam: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Desmethyldiazepam</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles (LLM): model_class=noncompartmental; 0/5 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Desmethyldiazepam' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Desmethyldiazepam', not clorazepate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Clorazepate_Wilensky1978_reference;
