// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Clorazepate_Malgorn2004_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {604800.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clorazepate</td></tr><tr><td>population:</td><td>neonate following massive maternal clorazepate overdose (1 case report)</td></tr><tr><td>source_paper:</td><td>Malgorn_2004</td></tr><tr><td>measured_compound:</td><td>nordiazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>clorazepate 314.725 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'nordiazepam' — extend the ontology if this is a real PK parameter (source ['Malgorn_2004:abstract', 'Malgorn_2004:abstract'])</li><li>dropped unlinked row (NIL): 'oxazepam' — extend the ontology if this is a real PK parameter (source ['Malgorn_2004:abstract', 'Malgorn_2004:abstract'])</li><li>dropped duplicate Q57 ('half-life', value 42) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nordiazepam</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/4 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'clorazepate dipotassium' — its concentrations stay mass-only</li><li>molar mass: none found for 'nordiazepam' — its concentrations stay mass-only</li><li>molar mass: none found for 'oxazepam' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'nordiazepam', not clorazepate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 6048.0));
end Clorazepate_Malgorn2004_reference;
