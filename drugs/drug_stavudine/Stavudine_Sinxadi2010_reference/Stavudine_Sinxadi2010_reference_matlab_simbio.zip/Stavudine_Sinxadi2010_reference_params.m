function p = Stavudine_Sinxadi2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: stavudine   source: Sinxadi_2010 / reference   route: oral
  p.name  = 'Stavudine_Sinxadi2010_reference_params';
  p.drug  = 'stavudine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2345.0;                % central volume [L]
  p.CL = 17.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 11.1;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.41;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
