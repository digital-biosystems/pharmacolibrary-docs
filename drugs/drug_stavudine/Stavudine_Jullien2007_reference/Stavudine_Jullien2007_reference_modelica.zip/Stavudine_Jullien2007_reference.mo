model Stavudine_Jullien2007_reference
  parameter Real Cl_ref = 4.583333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0409 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2242133,
    adminMass = 8e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About stavudine</h4><p>Stavudine is a nucleoside reverse transcriptase inhibitor used to treat HIV infection and prevent transmission after potential exposure. The medication is administered orally as capsules or tablets and is well absorbed. It is no longer a first-line treatment and has a boxed warning due to serious side effects, leading to its withdrawal from the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q423984\">Wikidata Q423984</a>, <a href=\"https://en.wikipedia.org/wiki/Stavudine?oldid=1357914105\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>children from birth to 16 years</td></tr><tr><td>source_paper:</td><td>Jullien_2007</td></tr><tr><td>measured_compound:</td><td>stavudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>stavudine 224.213 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Mean calculated doses for children less than 2 weeks' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'Mean calculated doses for children more than 2 weeks with bodyweight less than 30 kg' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'Mean calculated doses for children with a bodyweight between 30 and 60 kg' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'current paediatric doses for children less than 2 weeks' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'current paediatric doses for children more than 2 weeks with bodyweight less than 30 kg' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'current paediatric doses for children with a bodyweight between 30 and 60 kg' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=stavudine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Stavudine_Jullien2007_reference;
