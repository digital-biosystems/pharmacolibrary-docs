function p = Stavudine_Panhard2007_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: stavudine   source: Panhard_2007 / reference   route: oral
  p.name  = 'Stavudine_Panhard2007_reference_params';
  p.drug  = 'stavudine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 145.0;                % central volume [L]
  p.CL = 32.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.46;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
