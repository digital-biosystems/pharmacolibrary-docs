model Alfentanil_Davis1986_reference
  parameter Real Cl_ref = 1.3183333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027300000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfentanil</td></tr><tr><td>population:</td><td>patients undergoing coronary revascularisation procedures</td></tr><tr><td>source_paper:</td><td>Davis_1986</td></tr><tr><td>measured_compound:</td><td>sufentanil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table i</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'apparent volume of distribution'</li><li>salvaged Q22 ('clearance'=11.3) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volumes of distribution'=0.39) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('apparent volume of distribution'=4.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sufentanil</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Alfentanil_Davis1986_reference;
