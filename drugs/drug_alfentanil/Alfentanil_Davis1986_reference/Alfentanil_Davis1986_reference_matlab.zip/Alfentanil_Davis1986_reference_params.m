function p = Alfentanil_Davis1986_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alfentanil   source: Davis_1986 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Alfentanil_Davis1986_reference_params';
  p.drug  = 'alfentanil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.3;                % central volume [L]
  p.CL = 47.46;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
