// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Clofibrate_Crouthamel1975_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {69480.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clofibrate</td></tr><tr><td>population:</td><td>rats (iv CPIB); human subjects (oral clofibrate)</td></tr><tr><td>source_paper:</td><td>Crouthamel_1975</td></tr><tr><td>measured_compound:</td><td>CPIB (p-chlorophenoxyisobutyrate, clofibric acid)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Clofibrate 242.699 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'plasma FFA elevated to' — extend the ontology if this is a real PK parameter (source ['Crouthamel_1975:abstract'])</li><li>dropped duplicate Q57 ('CPIB elimination half-life (elevated FFA)', value 7.3) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=CPIB (p-chlorophenoxyisobutyrate, clofibric acid)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/3 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'CPIB (p-chlorophenoxyisobutyrate / clofibric acid)' — its concentrations stay mass-only</li><li>molar mass: none found for 'CPIB (p-chlorophenoxyisobutyrate, clofibric acid)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Kanoh_2010's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kanoh_2010's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Clofibrate_Crouthamel1975_reference;
