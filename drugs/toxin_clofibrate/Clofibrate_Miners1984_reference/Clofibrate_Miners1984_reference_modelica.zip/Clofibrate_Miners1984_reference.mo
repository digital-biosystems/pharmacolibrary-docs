model Clofibrate_Miners1984_reference
  parameter Real Cl_ref = 0.0003344444444444444 "Cl [m3/s]";
  parameter Real Vd_ref = 0.009800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24269900000000003,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clofibrate</td></tr><tr><td>population:</td><td>healthy adult humans (males, females, females on oral contraceptive steroids)</td></tr><tr><td>source_paper:</td><td>Miners_1984</td></tr><tr><td>measured_compound:</td><td>clofibric acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clofibrate 242.699 g/mol (pubchem); clofibric acid 242.699 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Clofibric acid plasma clearance'</li><li>dropped value-less row: 'clofibric acid free fraction'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clofibric acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Kanoh_2010's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kanoh_2010's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Kanoh_2010 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clofibrate_Miners1984_reference;
