model Citrulline_Aschner2023_reference
  parameter Real Cl_ref = 1.6666666666666665e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0009000000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17518799999999998,
    adminMass = 0.0001,
    ka = 0.00026388888888888886,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>citrulline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Aschner_2023</td></tr><tr><td>measured_compound:</td><td>citrulline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>citrulline 175.188 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Aschner_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Citrulline_Aschner2023_reference;
