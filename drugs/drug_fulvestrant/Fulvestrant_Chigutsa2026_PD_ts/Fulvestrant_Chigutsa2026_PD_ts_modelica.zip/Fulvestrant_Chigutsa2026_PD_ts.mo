model Fulvestrant_Chigutsa2026_PD_ts
  "linear exposure-response sweep — Chigutsa_2026 :: TS (Tumor size)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 36.7,      // [mm]
    slope = 6.59722222222e-08,  // [1 / second; week −1 × 1.65344e-06]
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fulvestrant</h4><p>Fulvestrant is an estrogen receptor antagonist used to treat breast cancer. It is an approved medicine, authorised in the European Union for breast cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5508491\">Wikidata Q5508491</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Fulvestrant_Chigutsa2026_PD_ts</h4><p>The steady-state exposure-response curve of Chigutsa E et al., <i>Clinical pharmacology and therapeutics 119(4):1070–1079</i> 2026 (<a href=\"https://doi.org/10.1002/cpt.70212\">doi:10.1002/cpt.70212</a>) — Tumor size [mm] against abemaciclib + fulvestrant ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       36.7 mm       drug-free response (baseline) (Baseline tumor size (mm), Q324)
  slope =     0.0399 week −1  change in response per unit of exposure (Abemaciclib drug effect per unit plasma concentration (week −1), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of abemaciclib + fulvestrant per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 36.7   (drug-free)</pre></body></html>"));
end Fulvestrant_Chigutsa2026_PD_ts;
