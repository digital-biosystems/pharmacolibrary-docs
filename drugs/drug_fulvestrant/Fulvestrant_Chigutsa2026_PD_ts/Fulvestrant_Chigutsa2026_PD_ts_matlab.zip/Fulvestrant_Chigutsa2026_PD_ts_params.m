function p = Fulvestrant_Chigutsa2026_PD_ts_params()
% Fulvestrant_Chigutsa2026_PD_ts_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fulvestrant Chigutsa_2026::TS: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TS in mm. Driver: abemaciclib + fulvestrant (conc_no_pk).
p.E0 = 36.7;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 6.597222222222222e-08;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
