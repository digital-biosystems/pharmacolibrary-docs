// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Risperidone_Kneller2020v2_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3708.0},
    MM = 0.410493,
    adminMass = 5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>risperidone</td></tr><tr><td>population:</td><td>geriatric inpatients aged 65+ years</td></tr><tr><td>source_paper:</td><td>Kneller_2020_2</td></tr><tr><td>measured_compound:</td><td>Risperidone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>9-Hydroxyrisperidone 426.492 g/mol (pubchem); Risperidone 410.493 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'IM' → Q900:im = 1.00 (linear_fractional on the model)</li><li>covariate level 'PM' → Q900:pm = 0.74 (linear_fractional on the model)</li><li>covariate level 'UM' → Q900:um = 1.04 (linear_fractional on the model)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Risperidone</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>pharmacogenetic covariate 'im' (im) — PGx domain</li><li>pharmacogenetic covariate 'pm' (pm) — PGx domain</li><li>pharmacogenetic covariate 'um' (um) — PGx domain</li><li>row roles: 7 per-group rows of none summary_statistic but 4 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=pbpk; 7/7 row label(s) assigned, 0 linked by role</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Risperidone_Kneller2020v2_reference;
