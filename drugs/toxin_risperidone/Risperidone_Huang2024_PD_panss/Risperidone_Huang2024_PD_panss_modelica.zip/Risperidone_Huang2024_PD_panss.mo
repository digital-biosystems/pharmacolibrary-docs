model Risperidone_Huang2024_PD_panss
  "sigmoid_emax exposure-response sweep — Huang_2024 :: PANSS (PANSS total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 90.1,      // [1]
    Emax = -0.661,  // [1]
    EC50 = 6.21527777778e-11,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1.31,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 54, Interval = 0.108),
    Documentation(info = "<html><body><h4>Risperidone_Huang2024_PD_panss</h4><p>The steady-state exposure-response curve of Huang Z et al., <i>Pharmaceuticals (Basel, Switzerland) 17(2):148</i> 2024 (<a href=\"https://doi.org/10.3390/ph17020148\">doi:10.3390/ph17020148</a>) — PANSS total score against risperidone mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       90.1          drug-free response (baseline) (E0, Q324)
  Emax  =      0.661          maximal effect term (Emax, Q323)
  EC50  =       5.37 mg/day   exposure at half of the maximal effect term (ET50, Q321)
  gamma =       1.31          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of risperidone per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 90.1   (drug-free)
  exposure = EC50 (5.37 mg/day)  response 89.77
  exposure -> infinity  response 89.44</pre></body></html>"));
end Risperidone_Huang2024_PD_panss;
