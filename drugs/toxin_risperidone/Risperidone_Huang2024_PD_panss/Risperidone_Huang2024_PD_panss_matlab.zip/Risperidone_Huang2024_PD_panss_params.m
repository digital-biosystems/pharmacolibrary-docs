function p = Risperidone_Huang2024_PD_panss_params()
% Risperidone_Huang2024_PD_panss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risperidone Huang_2024::PANSS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response PANSS in its own unit. Driver: risperidone (dose_only).
p.E0 = 90.1;
p.Emax = -0.661;
p.EC50 = 6.215277777777777e-11;
p.gamma = 1.31;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 54.0;
p.form = 'E0 + Emax*frac';
end
