function p = Risperidone_Kozielska2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: risperidone   source: Kozielska_2012 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Risperidone_Kozielska2012_reference_params';
  p.drug  = 'risperidone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 90.3;                % central volume [L]
  p.CL = 74.2;                % clearance [L/h]
  p.Vp = [11.83];             % peripheral volumes [L]
  p.Q  = [6.174];             % inter-compartmental clearances [L/h]
  p.ka = 2.84;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.7;             % dose [mg]
end
