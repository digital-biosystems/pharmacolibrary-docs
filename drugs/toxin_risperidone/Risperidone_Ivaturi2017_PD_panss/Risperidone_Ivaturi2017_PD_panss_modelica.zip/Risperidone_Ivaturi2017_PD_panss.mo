model Risperidone_Ivaturi2017_PD_panss
  "emax exposure-response sweep — Ivaturi_2017 :: PANSS (PANSS score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.054,  // [1; % × 0.01]
    EC50 = 4.6e-06,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><h4>Risperidone_Ivaturi2017_PD_panss</h4><p>The steady-state exposure-response curve of Ivaturi V et al., <i>British journal of clinical pharmacology 83(7):1476–1498</i> 2017 (<a href=\"https://doi.org/10.1111/bcp.13246\">doi:10.1111/bcp.13246</a>) — PANSS score [score] against total active moiety (AM) (risperidone + 9-hydroxy-risperidone) ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        5.4 %        maximal effect term (Placebo-corrected maximum relative decrease in PANSS, Q323)
  EC50  =        4.6 ng ml-1  exposure at half of the maximal effect term (Concentration for half-maximal effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of total active moiety (AM) (risperidone + 9-hydroxy-risperidone) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.6 ng ml-1)  response -0.027
  exposure -> infinity  response -0.054</pre></body></html>"));
end Risperidone_Ivaturi2017_PD_panss;
