function p = Risperidone_Huang2024_PD_prolactin_params()
% Risperidone_Huang2024_PD_prolactin_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risperidone Huang_2024::Prolactin: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response Prolactin in ng/mL. Driver: risperidone (dose_only).
p.E0 = 1.4999999999999999e-05;
p.Emax = 3.4e-05;
p.EC50 = 1.1574074074074074e-12;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1.0;
p.form = 'E0 + Emax*frac';
end
