model Risperidone_Huang2024_PD_prolactin
  "emax exposure-response sweep — Huang_2024 :: Prolactin (Prolactin)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.5e-05,      // [kg/m3; ng/mL × 1e-06]
    Emax = 3.4e-05,  // [kg/m3; ng/mL × 1e-06]
    EC50 = 1.15740740741e-12,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1, Interval = 0.002),
    Documentation(info = "<html><body><h4>Risperidone_Huang2024_PD_prolactin</h4><p>The steady-state exposure-response curve of Huang Z et al., <i>Pharmaceuticals (Basel, Switzerland) 17(2):148</i> 2024 (<a href=\"https://doi.org/10.3390/ph17020148\">doi:10.3390/ph17020148</a>) — Prolactin [ng/mL] against risperidone mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         15 ng/mL    drug-free response (baseline) (E0, Q324)
  Emax  =         34 ng/mL    maximal effect term (Emax, Q320)
  EC50  =        0.1 mg/day   exposure at half of the maximal effect term (ET50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of risperidone per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.5e-05   (drug-free)
  exposure = EC50 (0.1 mg/day)  response 3.2e-05
  exposure -> infinity  response 4.9e-05</pre></body></html>"));
end Risperidone_Huang2024_PD_prolactin;
