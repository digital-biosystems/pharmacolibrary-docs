model Risperidone_Kloosterboer2021_PD_bmi_z_score
  "linear exposure-response sweep — Kloosterboer_2021 :: BMI z-score (BMI z-score)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 42000,  // [1]
    exposure_per_s = 1e-06);   // 1 μg/L per second
  // slope_unit_assumed: slope unit '(none)' read as response per μg/L
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Risperidone_Kloosterboer2021_PD_bmi_z_score</h4><p>The steady-state exposure-response curve of Kloosterboer SM et al., <i>British journal of clinical pharmacology 87(3):1069-1081</i> 2021 (<a href=\"https://doi.org/10.1111/bcp.14465\">doi:10.1111/bcp.14465</a>) — BMI z-score against risperidone + 9-hydroxyrisperidone (sum C trough) μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.042          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/L of risperidone + 9-hydroxyrisperidone (sum C trough) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Risperidone_Kloosterboer2021_PD_bmi_z_score;
