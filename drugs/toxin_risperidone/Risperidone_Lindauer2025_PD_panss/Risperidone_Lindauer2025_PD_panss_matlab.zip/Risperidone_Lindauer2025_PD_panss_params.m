function p = Risperidone_Lindauer2025_PD_panss_params()
% Risperidone_Lindauer2025_PD_panss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risperidone Lindauer_2025::PANSS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PANSS in its own unit. Driver: active moiety (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 4.599999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 46.0;
p.form = 'E0 + Emax*frac';
end
