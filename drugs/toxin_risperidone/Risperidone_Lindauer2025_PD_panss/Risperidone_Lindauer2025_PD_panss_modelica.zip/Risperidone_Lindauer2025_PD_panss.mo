model Risperidone_Lindauer2025_PD_panss
  "emax exposure-response sweep — Lindauer_2025 :: PANSS (Positive and Negative Syndrome Scale (PANSS) total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0,  // [fractional reduction]
    EC50 = 4.6e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><h4>Risperidone_Lindauer2025_PD_panss</h4><p>The steady-state exposure-response curve of Lindauer A et al., <i>Journal of clinical pharmacology 65(3):350–360</i> 2025 (<a href=\"https://doi.org/10.1002/jcph.6152\">doi:10.1002/jcph.6152</a>) — Positive and Negative Syndrome Scale (PANSS) total score against active moiety ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          0          drug-free response (baseline) (BL, Q324)
  Emax  =          0 fractional reduction maximal effect term (EMAX, Q323)
  EC50  =        4.6 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of active moiety per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.6 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Risperidone_Lindauer2025_PD_panss;
