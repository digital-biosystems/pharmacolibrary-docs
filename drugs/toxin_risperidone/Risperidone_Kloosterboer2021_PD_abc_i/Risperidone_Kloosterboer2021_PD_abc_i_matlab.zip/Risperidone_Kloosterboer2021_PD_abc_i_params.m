function p = Risperidone_Kloosterboer2021_PD_abc_i_params()
% Risperidone_Kloosterboer2021_PD_abc_i_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risperidone Kloosterboer_2021::ABC_I: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response ABC-I in points. Driver: risperidone + 9-hydroxyrisperidone (sum C trough) (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -281000.0000000001;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
