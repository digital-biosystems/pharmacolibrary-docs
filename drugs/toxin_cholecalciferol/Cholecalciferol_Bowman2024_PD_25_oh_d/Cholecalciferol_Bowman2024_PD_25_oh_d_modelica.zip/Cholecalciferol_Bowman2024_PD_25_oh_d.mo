model Cholecalciferol_Bowman2024_PD_25_oh_d
  "linear exposure-response sweep — Bowman_2024 :: 25(OH)D (25-hydrodroxyvitamin D [25(OH)D])"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 5.1,  // [ng/ml ± 3.9 per 1000 IU/d]
    exposure_per_s = 1);   // 1 IU/d per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Cholecalciferol_Bowman2024_PD_25_oh_d</h4><p>The steady-state exposure-response curve of Bowman CA et al., <i>Digestive diseases and sciences 69(3):1015–1024</i> 2024 (<a href=\"https://doi.org/10.1007/s10620-023-08224-5\">doi:10.1007/s10620-023-08224-5</a>) — 25-hydrodroxyvitamin D [25(OH)D] [ng/mL] against vitamin D3 IU/d — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        5.1 ng/ml ± 3.9 per 1000 IU/d change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one IU/d of vitamin D3 per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Cholecalciferol_Bowman2024_PD_25_oh_d;
