function p = Salmeterol_Thoueille2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salmeterol   source: Thoueille_2026 / reference   route: oral
  p.name  = 'Salmeterol_Thoueille2026_reference_params';
  p.drug  = 'salmeterol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 446.0;                % central volume [L]
  p.CL = 193.0;                % clearance [L/h]
  p.Vp = [871.0];             % peripheral volumes [L]
  p.Q  = [1490.0];             % inter-compartmental clearances [L/h]
  p.ka = -0.89;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.1;             % dose [mg]
end
