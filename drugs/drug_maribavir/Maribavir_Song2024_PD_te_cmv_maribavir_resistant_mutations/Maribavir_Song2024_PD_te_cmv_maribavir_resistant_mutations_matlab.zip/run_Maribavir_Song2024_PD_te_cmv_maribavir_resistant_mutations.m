% run_Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*log(exposure);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [µg/mL]'); ylabel('response []'); title('Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations.csv');
