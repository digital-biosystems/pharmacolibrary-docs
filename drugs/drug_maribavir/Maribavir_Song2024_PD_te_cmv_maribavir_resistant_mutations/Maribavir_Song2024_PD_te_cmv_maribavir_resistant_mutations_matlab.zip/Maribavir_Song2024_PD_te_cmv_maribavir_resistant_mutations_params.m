function p = Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations_params()
% Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% maribavir Song_2024::TE_CMV_maribavir_resistant_mutations: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response TE CMV maribavir-resistant mutations in its own unit. Driver: maribavir (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.21;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
