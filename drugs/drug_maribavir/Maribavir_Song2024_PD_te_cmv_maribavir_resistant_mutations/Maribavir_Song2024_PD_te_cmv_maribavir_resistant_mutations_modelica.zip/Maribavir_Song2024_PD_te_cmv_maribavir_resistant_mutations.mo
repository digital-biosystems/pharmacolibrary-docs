model Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations
  "log_linear exposure-response sweep — Song_2024 :: TE CMV maribavir-resistant mutations (Development of treatment-emergent mutations conferring resistance to maribavir)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.21   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About maribavir</h4><p>Maribavir is an antiviral medicine used to treat cytomegalovirus infections. It is an approved antiviral and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6762512\">Wikidata Q6762512</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations</h4><p>The steady-state exposure-response curve of Song IH et al., <i>Journal of pharmacokinetics and pharmacodynamics 51(6):887–904</i> 2024 (<a href=\"https://doi.org/10.1007/s10928-024-09939-2\">doi:10.1007/s10928-024-09939-2</a>) — Development of treatment-emergent mutations conferring resistance to maribavir against maribavir µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.21          change in response per unit of exposure (Ctrough.ss of maribavir – increment of 2.5 µg/mL, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one µg/mL of maribavir per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Maribavir_Song2024_PD_te_cmv_maribavir_resistant_mutations;
