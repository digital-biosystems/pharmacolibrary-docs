function p = Maribavir_Song2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: maribavir   source: Song_2024 / reference   route: oral
  p.name  = 'Maribavir_Song2024_reference_params';
  p.drug  = 'maribavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.0;                % central volume [L]
  p.CL = 52.5;                % clearance [L/h]
  p.Vp = [103.0];             % peripheral volumes [L]
  p.Q  = [90.7];             % inter-compartmental clearances [L/h]
  p.ka = 152.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 44.1;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
