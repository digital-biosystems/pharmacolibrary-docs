model Maribavir_Song2024_reference
  parameter Real Cl_ref = 1.4583333333333333e-05 "Cl [m3/s]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  parameter Real Vd_ref = 0.034 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_weight/1.0)^(0.75),
    Vd = Vd_ref*(cov_weight/1.0)^(1.0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37623,
    adminMass = 0.0001,
    ka = 0.042222222222222223,
    Tlag = 158760.0,
    k12 = 0.0007410130718954248,
    k21 = 0.0002446062567421791
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About maribavir</h4><p>Maribavir is an antiviral medicine used to treat cytomegalovirus infections. It is an approved antiviral and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6762512\">Wikidata Q6762512</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>maribavir</td></tr><tr><td>population:</td><td>transplant recipients with CMV infection (pooled phase 1-3 incl. healthy volunteers and hepatic/renal impairment)</td></tr><tr><td>source_paper:</td><td>Song_2024</td></tr><tr><td>measured_compound:</td><td>maribavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>maribavir 376.23 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F ~ CYP3A strong inhibitors', value '1.98') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F ~ CYP3A strong inducers', value '2.95') — already have one for this compound</li><li>dropped duplicate Q49 ('Ka ~ dose', value '6.49') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F ~ transplant patients with CMV', value '4.63') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=maribavir</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Maribavir_Song2024_reference;
