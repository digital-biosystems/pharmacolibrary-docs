model Maribavir_Sun2025_estimates
  parameter Real Cl_ref = 1.0944444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0178 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37623,
    adminMass = 0.0004,
    ka = 0.0001936111111111111,
    Tlag = 763.1999999999999,
    k12 = 1.9350811485642947e-05,
    k21 = 4.85133020344288e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About maribavir</h4><p>Maribavir is an antiviral medicine used to treat cytomegalovirus infections. It is an approved antiviral and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6762512\">Wikidata Q6762512</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>maribavir</td></tr><tr><td>population:</td><td>transplant recipients with CMV infection and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Sun_2025</td></tr><tr><td>measured_compound:</td><td>maribavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470054-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>maribavir 376.23 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ 2add' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ 2prop Phase 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ 2prop Phase 2 & 3' routed out of structural estimates ('Residual error')</li><li>dropped duplicate Q49 ('Effect of dose on Ka', value None) — already have one for this compound</li><li>NIL: refused to back-fill base 'V2/F' from footnote/prose loose number None (source ['psp470054-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'kabs' from footnote/prose loose number None (source ['psp470054-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'tlag' from footnote/prose loose number 0.212 (source ['psp470054-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'Ka (1/h)' → 1/h (from the popPK convention: 'The paper does not state a unit for Ka. Ka is a first-order absorption rate constant; by population PK convention rate c')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=maribavir</li><li>population split: 'estimates' subgroup of Sun_2025 (paper reports 5 populations: all individuals a, all transplant recipients with cmv, estimates, healthy volunteers, transplant recipients with cmv (aurora study only))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Maribavir_Sun2025_estimates;
