% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Maribavir_Sun2025_estimates_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
