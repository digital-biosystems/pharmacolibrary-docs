function p = Maribavir_Sun2025_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: maribavir   source: Sun_2025 / estimates   route: oral
  p.name  = 'Maribavir_Sun2025_estimates_params';
  p.drug  = 'maribavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.8;                % central volume [L]
  p.CL = 3.94;                % clearance [L/h]
  p.Vp = [7.1];             % peripheral volumes [L]
  p.Q  = [1.24];             % inter-compartmental clearances [L/h]
  p.ka = 0.697;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.212;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
