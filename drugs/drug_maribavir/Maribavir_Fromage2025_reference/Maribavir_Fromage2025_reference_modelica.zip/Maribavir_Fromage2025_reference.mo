model Maribavir_Fromage2025_reference
  parameter Real Cl_ref = 1.0833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37623,
    adminMass = 0.0004,
    ka = 8.333333333333333e-05,
    Tlag = 936.0,
    k12 = 1.2134502923976608e-05,
    k21 = 2.7124183006535947e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About maribavir</h4><p>Maribavir is an antiviral medicine used to treat cytomegalovirus infections. It is an approved antiviral and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6762512\">Wikidata Q6762512</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>maribavir</td></tr><tr><td>population:</td><td>patients treated for CMV infection</td></tr><tr><td>source_paper:</td><td>Fromage_2025</td></tr><tr><td>measured_compound:</td><td>maribavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone.0321180.t001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>maribavir 376.23 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L.h − 1' (CL/F)</li><li>routed 'Original ε prop' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'ε add used' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'ε prop used' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>implicit units: 'Cl/F (L.h − 1)' → L/h (from the paper text: &quot;Table 1 caption/footnote states 'Cl/F mean apparent clearance' and the parameter listing itself shows 'Cl/F (L.h − 1) = &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=maribavir</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Maribavir_Fromage2025_reference;
