function p = Maribavir_Fromage2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: maribavir   source: Fromage_2025 / reference   route: oral
  p.name  = 'Maribavir_Fromage2025_reference_params';
  p.drug  = 'maribavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.0;                % central volume [L]
  p.CL = 3.9;                % clearance [L/h]
  p.Vp = [8.5];             % peripheral volumes [L]
  p.Q  = [0.83];             % inter-compartmental clearances [L/h]
  p.ka = 0.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.26;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
