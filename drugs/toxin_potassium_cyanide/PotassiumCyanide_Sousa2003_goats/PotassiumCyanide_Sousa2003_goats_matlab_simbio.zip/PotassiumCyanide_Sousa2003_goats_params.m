function p = PotassiumCyanide_Sousa2003_goats_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium_cyanide   source: Sousa_2003 / goats   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'PotassiumCyanide_Sousa2003_goats_params';
  p.drug  = 'potassium_cyanide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 28.7;                % central volume [L]
  p.CL = 0.924;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 210.0;             % dose [mg]
end
