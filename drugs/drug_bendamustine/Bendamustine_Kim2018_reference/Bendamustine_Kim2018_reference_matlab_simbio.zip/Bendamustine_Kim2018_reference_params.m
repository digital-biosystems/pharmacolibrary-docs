function p = Bendamustine_Kim2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bendamustine   source: Kim_2018 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Bendamustine_Kim2018_reference_params';
  p.drug  = 'bendamustine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 20.7;                % central volume [L]
  p.CL = 39.2;                % clearance [L/h]
  p.Vp = [0.846];             % peripheral volumes [L]
  p.Q  = [0.66];             % inter-compartmental clearances [L/h]
  p.ka = 6.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
