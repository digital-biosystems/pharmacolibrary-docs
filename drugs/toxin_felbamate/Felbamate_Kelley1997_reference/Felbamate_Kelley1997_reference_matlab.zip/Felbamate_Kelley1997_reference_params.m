function p = Felbamate_Kelley1997_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: felbamate   source: Kelley_1997 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Felbamate_Kelley1997_reference_params';
  p.drug  = 'felbamate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 63.56;                % central volume [L]
  p.CL = 2.877;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
