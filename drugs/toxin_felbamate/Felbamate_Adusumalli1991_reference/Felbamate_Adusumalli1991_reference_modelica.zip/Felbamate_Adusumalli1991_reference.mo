model Felbamate_Adusumalli1991_reference
  parameter Real Cl_ref = 6.358333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.131 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23824299999999998,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>felbamate</td></tr><tr><td>population:</td><td>Rats, rabbits, and dogs</td></tr><tr><td>source_paper:</td><td>Adusumalli_1991</td></tr><tr><td>measured_compound:</td><td>Felbamate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>felbamate 238.243 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '% of body weight' (V)</li><li>implicit units: 'volume of distribution' → L (from the popPK convention: 'Volume of distribution (Vd) is conventionally reported in Liters (L). The value 131 is consistent with typical volumes o')</li><li>implicit units: 'Renal clearance of unchanged drug' → L/h (from the popPK convention: 'Clearance (including renal clearance) is conventionally reported in Liters per hour (L/h). The value 20 is a physiologic')</li><li>implicit units: 'hepatic clearance' → L/h (from the popPK convention: 'Clearance (including hepatic clearance) is conventionally reported in Liters per hour (L/h). The value 65 is a physiolog')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Felbamate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Felbamate_Adusumalli1991_reference;
