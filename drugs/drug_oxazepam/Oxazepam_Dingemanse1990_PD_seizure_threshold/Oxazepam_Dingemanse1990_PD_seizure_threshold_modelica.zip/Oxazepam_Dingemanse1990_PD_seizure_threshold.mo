model Oxazepam_Dingemanse1990_PD_seizure_threshold
  "log_linear exposure-response sweep — Dingemanse_1990 :: seizure threshold (seizure threshold)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 7668.4968   "[second; microA × 31.5576]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxazepam</h4><p>Oxazepam is a benzodiazepine used to treat anxiety disorders and focal epilepsy. It is given orally in various forms such as tablets, capsules, and liquid solutions. The drug is widely used in clinical practice.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q412299\">Wikidata Q412299</a>, <a href=\"https://en.wikipedia.org/wiki/Oxazepam?oldid=1369619112\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxazepam_Dingemanse1990_PD_seizure_threshold</h4><p>The steady-state exposure-response curve of Dingemanse J et al., <i>British journal of pharmacology 99(1):53–58</i> 1990 (<a href=\"https://doi.org/10.1111/j.1476-5381.1990.tb14653.x\">doi:10.1111/j.1476-5381.1990.tb14653.x</a>) — seizure threshold against oxazepam mg l-1 — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        243 microA   change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one mg l-1 of oxazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Oxazepam_Dingemanse1990_PD_seizure_threshold;
