function p = Oxazepam_Dingemanse1990_PD_seizure_threshold_params()
% Oxazepam_Dingemanse1990_PD_seizure_threshold_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxazepam Dingemanse_1990::seizure_threshold: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l-1 per second, in SI inside (kg/m3, s). Response seizure threshold in its own unit. Driver: oxazepam (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 7668.496799999999;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
