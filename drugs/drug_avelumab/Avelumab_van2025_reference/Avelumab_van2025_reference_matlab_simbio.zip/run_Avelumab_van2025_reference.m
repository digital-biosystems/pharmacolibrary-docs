% Run (SimBiology): build model + dose, simulate 0..456.0 h, plot.
p = Avelumab_van2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 456.0);
