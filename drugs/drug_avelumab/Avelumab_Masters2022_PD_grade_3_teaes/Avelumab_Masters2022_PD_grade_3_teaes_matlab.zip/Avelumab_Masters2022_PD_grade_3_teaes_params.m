function p = Avelumab_Masters2022_PD_grade_3_teaes_params()
% Avelumab_Masters2022_PD_grade_3_teaes_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% avelumab Masters_2022::Grade_3_TEAEs: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response Grade ≥3 TEAEs in its own unit. Driver: avelumab (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 970.0000000000001;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
