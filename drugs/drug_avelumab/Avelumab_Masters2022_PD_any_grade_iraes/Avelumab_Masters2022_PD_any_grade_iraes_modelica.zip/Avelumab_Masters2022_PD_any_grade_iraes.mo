model Avelumab_Masters2022_PD_any_grade_iraes
  "linear exposure-response sweep — Masters_2022 :: Any-grade irAEs (Any-grade irAEs)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1000,  // [(1)/(kg/m3); per µg/ml × 1000]
    exposure_per_s = 0.001);   // 1 µg/ml per second
  // slope_unit_assumed: slope unit 'per µg/ml' read as response per µg/ml
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About avelumab</h4><p>Avelumab is a fully human monoclonal antibody medication that acts as a PD-L1 inhibitor to treat several forms of cancer. It is administered intravenously.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q21083261\">Wikidata Q21083261</a>, <a href=\"https://en.wikipedia.org/wiki/Avelumab?oldid=1292952219\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Avelumab_Masters2022_PD_any_grade_iraes</h4><p>The steady-state exposure-response curve of Masters JC et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(4):458–468</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12771\">doi:10.1002/psp4.12771</a>) — Any-grade irAEs against avelumab µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =          1 per µg/ml change in response per unit of exposure (Odds Ratio, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µg/ml of avelumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Avelumab_Masters2022_PD_any_grade_iraes;
