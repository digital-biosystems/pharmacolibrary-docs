function p = Avelumab_Masters2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: avelumab   source: Masters_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Avelumab_Masters2022_reference_params';
  p.drug  = 'avelumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.196;                % central volume [L]
  p.CL = 0.0269;                % clearance [L/h]
  p.Vp = [0.7278];             % peripheral volumes [L]
  p.Q  = [0.3352];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
