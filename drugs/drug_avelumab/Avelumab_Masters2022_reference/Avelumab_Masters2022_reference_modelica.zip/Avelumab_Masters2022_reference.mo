model Avelumab_Masters2022_reference
  parameter Real Cl_ref = 7.472222222222222e-09 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real Vd_ref = 0.003196 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.4714)*cov_weight_0),
    Vd = Vd_ref*(1 + (0.4694)*cov_weight_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    k12 = 2.9133639271311363e-05,
    k21 = 0.00012793502488473636
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About avelumab</h4><p>Avelumab is a fully human monoclonal antibody medication that acts as a PD-L1 inhibitor to treat several forms of cancer. It is administered intravenously.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q21083261\">Wikidata Q21083261</a>, <a href=\"https://en.wikipedia.org/wiki/Avelumab?oldid=1292952219\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>avelumab</td></tr><tr><td>population:</td><td>patients with advanced renal cell carcinoma</td></tr><tr><td>source_paper:</td><td>Masters_2022</td></tr><tr><td>measured_compound:</td><td>avelumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412771-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'θImax' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412771-tbl-0001:row5:col1'])</li><li>dropped unlinked row (NIL): 'θT50, days' — extend the ontology if this is a real PK parameter (source ['psp412771-tbl-0001:row6:col1'])</li><li>dropped unlinked row (NIL): 'θγ' — extend the ontology if this is a real PK parameter (source ['psp412771-tbl-0001:row7:col1'])</li><li>dropped duplicate Q63 ('covCL‐V1', value '0.03048') — already have one for this compound</li><li>routed 'covCL‐V2' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'covV1‐V2' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=avelumab</li><li>molar mass: none found for 'avelumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 1));
end Avelumab_Masters2022_reference;
