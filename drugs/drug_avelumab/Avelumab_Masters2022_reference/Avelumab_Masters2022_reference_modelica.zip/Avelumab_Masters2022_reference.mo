model Avelumab_Masters2022_reference
  parameter Real Cl_ref = 7.472222222222222e-09 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real Vd_ref = 0.003196 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.5826)*cov_weight_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    k12 = 2.9133639271311363e-05,
    k21 = 0.00012793502488473636
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About avelumab</h4><p>Avelumab is a fully human anti-PD-L1 monoclonal antibody used as cancer immunotherapy, studied for tumours including Merkel cell carcinoma, bladder, ovarian, stomach, kidney, head and neck, and lung cancers, and mesothelioma. It is an approved anticancer medicine, with additional uses still under investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21083261\">Wikidata Q21083261</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>avelumab</td></tr><tr><td>population:</td><td>patients with advanced renal cell carcinoma receiving avelumab plus axitinib</td></tr><tr><td>source_paper:</td><td>Masters_2022</td></tr><tr><td>measured_compound:</td><td>avelumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412771-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'θImax' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412771-tbl-0001:row5:col1', 'psp412771-tbl-0001:row5:col2'])</li><li>dropped PD-category row 'θγ' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412771-tbl-0001:row7:col1', 'psp412771-tbl-0001:row7:col2', 'psp412771-tbl-0001:row7:col3'])</li><li>covariate level 'θ weight on V2' → Q900:weight_on_v2 = 0.5826 (linear_fractional on Q22)</li><li>routed 'covCL‐V1' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'covCL‐V2' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'covV1‐V2' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>unit inherited for weight_on_v2 (Q900): 'days' from a same-Q-code sibling (this row's label had no unit)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=avelumab</li><li>molar mass: none found for 'avelumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 1));
end Avelumab_Masters2022_reference;
