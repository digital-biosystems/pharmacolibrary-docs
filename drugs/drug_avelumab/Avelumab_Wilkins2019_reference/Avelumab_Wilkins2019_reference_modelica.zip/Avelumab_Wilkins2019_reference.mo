model Avelumab_Wilkins2019_reference
  parameter Real Cl_ref = 8.555555555555557e-09 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Real cov_age_1 = 0 "age covariate";
  parameter Real cov_albumin_2 = 0 "albumin covariate";
  parameter Real cov_sex_3 = 0 "sex covariate";
  parameter Real cov_race_4 = 0 "race covariate";
  parameter Real cov_egfr_5 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.00342 "Vd [m3]";
  parameter Real cov_albumin_0 = 0 "albumin covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.12)*cov_age_1)*(1 + (-0.438)*cov_albumin_2)*(1 + (-0.15)*cov_sex_3)*(1 + (-0.12)*cov_race_4)*(1 + (0.0579)*cov_egfr_5) + (1.9000000000000004e-05)*(if cov_category_0 then 1 else 0),
    Vd = Vd_ref*(1 + (-0.278)*cov_albumin_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    k12 = 2.5422352176738144e-06,
    k21 = 9.471072379569111e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About avelumab</h4><p>Avelumab is a fully human anti-PD-L1 monoclonal antibody used as cancer immunotherapy, studied for tumours including Merkel cell carcinoma, bladder, ovarian, stomach, kidney, head and neck, and lung cancers, and mesothelioma. It is an approved anticancer medicine, with additional uses still under investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21083261\">Wikidata Q21083261</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>avelumab</td></tr><tr><td>population:</td><td>patients with Merkel cell carcinoma and urothelial carcinoma</td></tr><tr><td>source_paper:</td><td>Wilkins_2019</td></tr><tr><td>measured_compound:</td><td>avelumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412406-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV on CL (ωCL2, variance)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'cov(CL,V 1) (ωCL,V1, covariance)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'IIV on V 1 (ωV12, variance)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'cov(V 1,V 2) (ωCL,V1, covariance)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'cov(CL,V 2) (ωCL,V1, covariance)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'IIV on V 2 (ωV22, variance)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'IIV on Imax (ωImax2, variance)' routed out of structural estimates ('IIV')</li><li>table section residual_error: 'Proportional residual error (σadd)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive residual error (σadd), μg/mL' routed out of structural estimates ('Residual variability')</li><li>dropped PD-category row 'Imax SCCHN' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412406-tbl-0002:row5:col1'])</li><li>dropped unlinked row (NIL): 'Imax mMCC' — extend the ontology if this is a real PK parameter (source ['psp412406-tbl-0002:row6:col1'])</li><li>dropped unlinked row (NIL): 'T 50 mMCC' — extend the ontology if this is a real PK parameter (source ['psp412406-tbl-0002:row8:col1'])</li><li>covariate level 'T 50, for all other tumor types' → Q900:t_50_for_all_other_tumor_types = 68.4 (additive_shift on Q22)</li><li>covariate level 'Age on CL (θCL,Age)1' → Q900:age_on_cl_cl_age_1 = -0.12 (linear_fractional on Q22)</li><li>covariate level 'Albumin on CL (θCL,Alb)1' → Q900:albumin_on_cl_cl_alb_1 = -0.438 (linear_fractional on Q22)</li><li>dropped unlinked row (NIL): 'Tumor burden on CL (θCL,TS)1' — extend the ontology if this is a real PK parameter (source ['psp412406-tbl-0002:row20:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end Avelumab_Wilkins2019_reference;
