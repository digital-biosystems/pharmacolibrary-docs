% Run (SimBiology): build model + dose, simulate 0..408.0 h, plot.
p = Avelumab_Wilkins2019_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 408.0);
