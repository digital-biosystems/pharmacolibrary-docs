function p = Avelumab_Wilkins2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: avelumab   source: Wilkins_2019 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Avelumab_Wilkins2019_reference_params';
  p.drug  = 'avelumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.42;                % central volume [L]
  p.CL = 0.0308;                % clearance [L/h]
  p.Vp = [0.918];             % peripheral volumes [L]
  p.Q  = [0.0313];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
