model Avelumab_van2025_PD_01
  "sigmoid_emax exposure-response sweep — van_2025 :: λ01 (Rate constant ADA− to ADA+)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0001125,  // [1/s; /h × 0.000277778]
    EC50 = 0.387,  // [kg/m3; µg/mL × 0.001]
    gamma = 2.75,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 3900, Interval = 7.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About avelumab</h4><p>Avelumab is a fully human monoclonal antibody medication that acts as a PD-L1 inhibitor to treat several forms of cancer. It is administered intravenously.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q21083261\">Wikidata Q21083261</a>, <a href=\"https://en.wikipedia.org/wiki/Avelumab?oldid=1292952219\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Avelumab_van2025_PD_01</h4><p>The steady-state exposure-response curve of van der Walt JS et al., <i>Journal of pharmacokinetics and pharmacodynamics 52(3):33</i> 2025 (<a href=\"https://doi.org/10.1007/s10928-025-09971-w\">doi:10.1007/s10928-025-09971-w</a>) — Rate constant ADA− to ADA+ [/h] against avelumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     -0.405 /h       maximal effect term (Maximum change, Q323)
  EC50  =        387 µg/mL    exposure at half of the maximal effect term (50% of maximum change, Q321)
  gamma =       2.75          Hill coefficient (Shape of effect curve, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of avelumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (387 µg/mL)  response -5.625e-05
  exposure -> infinity  response -0.0001125</pre></body></html>"));
end Avelumab_van2025_PD_01;
