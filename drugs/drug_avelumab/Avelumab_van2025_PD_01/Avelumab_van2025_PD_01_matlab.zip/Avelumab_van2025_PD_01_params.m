function p = Avelumab_van2025_PD_01_params()
% Avelumab_van2025_PD_01_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% avelumab van_2025::01: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response λ01 in /h. Driver: avelumab (pk_record).
p.E0 = 0.0;
p.Emax = -0.00011250000000000001;
p.EC50 = 0.3869999999999999;
p.gamma = 2.75;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3900.0;
p.form = 'E0 + Emax*frac';
end
