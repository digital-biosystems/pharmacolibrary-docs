function p = Avelumab_Vugmeyster2022_adult_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: avelumab   source: Vugmeyster_2022 / adult_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Avelumab_Vugmeyster2022_adult_model_params';
  p.drug  = 'avelumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.15;                % central volume [L]
  p.CL = 0.0274;                % clearance [L/h]
  p.Vp = [0.91];             % peripheral volumes [L]
  p.Q  = [0.0299];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
