% Run: build params, simulate 0..4320.0 h, plot + save Avelumab_Vugmeyster2022_adult_model.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Avelumab_Vugmeyster2022_adult_model.m
here = fileparts(mfilename('fullpath'));
p = Avelumab_Vugmeyster2022_adult_model_params();
out = simulate_pk(p, 0:0.05:4320.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('avelumab — Vugmeyster_2022 (iv_bolus)');
print(fig, fullfile(here, 'Avelumab_Vugmeyster2022_adult_model.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Avelumab_Vugmeyster2022_adult_model.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Avelumab_Vugmeyster2022_adult_model.json'), 'w');
try
  s.model = 'Avelumab_Vugmeyster2022_adult_model'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Avelumab_Vugmeyster2022_adult_model","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Avelumab_Vugmeyster2022_adult_model.png, Avelumab_Vugmeyster2022_adult_model.csv, Avelumab_Vugmeyster2022_adult_model.json\n');
