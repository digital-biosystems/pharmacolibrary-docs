model Avelumab_Vugmeyster2022_adult_model
  parameter Real Cl_ref = 7.611111111111112e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00315 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    k12 = 2.6366843033509702e-06,
    k21 = 9.126984126984129e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About avelumab</h4><p>Avelumab is a fully human anti-PD-L1 monoclonal antibody used as cancer immunotherapy, studied for tumours including Merkel cell carcinoma, bladder, ovarian, stomach, kidney, head and neck, and lung cancers, and mesothelioma. It is an approved anticancer medicine, with additional uses still under investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21083261\">Wikidata Q21083261</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>avelumab</td></tr><tr><td>population:</td><td>pediatric patients with solid tumors</td></tr><tr><td>source_paper:</td><td>Vugmeyster_2022</td></tr><tr><td>measured_compound:</td><td>avelumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Imax a' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Vugmeyster_2022_table_p6_1:row4:col2'])</li><li>unit_dimension_unknown: 'days b' (t1/2z)</li><li>dropped unlinked row (NIL): 'Curve shape factor, γ^a' — extend the ontology if this is a real PK parameter (source ['Vugmeyster_2022_table_p6_1:row6:col2'])</li><li>dropped unlinked row (NIL): 'Weight on CL' — extend the ontology if this is a real PK parameter (source ['Vugmeyster_2022_table_p6_1:row7:col2'])</li><li>dropped unlinked row (NIL): 'Weight on Q' — extend the ontology if this is a real PK parameter (source ['Vugmeyster_2022_table_p6_1:row10:col2'])</li><li>implicit units: 'V2, La' → L (from the paper text: &quot;The text states: 'Other pediatric parameters, which were informed by prior estimates, were similar to adult values, incl&quot;)</li><li>implicit units: 'Q, L/h^a' → L/h (from the paper text: &quot;The text states: '...an intercompartmental clearance of 0.0323 L/h and 0.0299 L/h, respectively...'&quot;)</li><li>implicit units: 'T50, days b' → days (from the paper text: &quot;The parameter definition provided in the prompt explicitly lists the unit as 'days b' (T50, days b = 79), indicating the&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=avelumab</li><li>population split: 'adult model' subgroup of Vugmeyster_2022 (paper reports 2 populations: adult model, final pediatric model)</li><li>molar mass: none found for 'avelumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Avelumab_Vugmeyster2022_adult_model;
