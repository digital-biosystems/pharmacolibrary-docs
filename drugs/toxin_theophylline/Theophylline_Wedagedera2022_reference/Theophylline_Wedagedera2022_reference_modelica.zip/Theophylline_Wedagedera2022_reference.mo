model Theophylline_Wedagedera2022_reference
  parameter Real Cl_ref = 1.3611111111111113e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0027 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.00019,
    ka = 0.000738888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>theophylline</td></tr><tr><td>population:</td><td>18 male human subjects</td></tr><tr><td>source_paper:</td><td>Wedagedera_2022</td></tr><tr><td>measured_compound:</td><td>Theophylline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tables S8-S11 (Supplementary Material)</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>theophylline 180.167 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'ka' → 1/h (from the paper text: 'The absorption rate constant (ka; 1/h)')</li><li>implicit units: 'Vss' → L/kg (from the paper text: 'the volume of distribution of the drug at steady state (Vss; L/kg)')</li><li>implicit units: 'Vmax' — the LLM proposed 'pmol/min/pmol', whose dimension does not fit Q66; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Theophylline</li><li>gap-filled Q22 (CL) from Frymoyer_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Frymoyer_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q66 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Theophylline_Wedagedera2022_reference;
