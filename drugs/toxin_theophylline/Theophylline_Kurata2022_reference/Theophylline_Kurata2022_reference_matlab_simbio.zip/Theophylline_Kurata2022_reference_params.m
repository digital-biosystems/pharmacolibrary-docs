function p = Theophylline_Kurata2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: theophylline   source: Kurata_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Theophylline_Kurata2022_reference_params';
  p.drug  = 'theophylline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.7;                % central volume [L]
  p.CL = 0.0472;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.5082;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.825;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
