model Theophylline_Kurata2022_reference
  parameter Real Cl_ref = 1.3111111111111112e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0027 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0004,
    ka = 0.00041894444444444444,
    Tlag = 2970.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>theophylline</td></tr><tr><td>population:</td><td>Japanese bronchial asthma patients with and without chronic liver diseases</td></tr><tr><td>source_paper:</td><td>Kurata_2022</td></tr><tr><td>measured_compound:</td><td>Theophylline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>theophylline 180.167 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h kg<sup>-1</sup>' (CL)</li><li>dropped unlinked row (NIL): 'CH patients' — extend the ontology if this is a real PK parameter (source ['Kurata_2022:abstract'])</li><li>dropped unlinked row (NIL): 'LC patients with MELD scores of <10' — extend the ontology if this is a real PK parameter (source ['Kurata_2022:abstract'])</li><li>dropped unlinked row (NIL): 'LC patients with MELD scores of 10-14' — extend the ontology if this is a real PK parameter (source ['Kurata_2022:abstract'])</li><li>dropped unlinked row (NIL): 'LC patients with MELD scores of 15-19' — extend the ontology if this is a real PK parameter (source ['Kurata_2022:abstract'])</li><li>dropped unlinked row (NIL): 'LC patients with MELD scores of 20-24' — extend the ontology if this is a real PK parameter (source ['Kurata_2022:abstract'])</li><li>dropped unlinked row (NIL): 'LC patients with MELD scores of ≥25' — extend the ontology if this is a real PK parameter (source ['Kurata_2022:abstract'])</li><li>implicit units: 'patients without CLDs' → L/h (from the popPK convention: 'Parameter is defined as Total clearance. Priority 2 convention for clearances is L/h. The magnitude (0.0472) is consiste')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Theophylline</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Frymoyer_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kong_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kwack_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Frymoyer_2020, Kong_2026, Kwack_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Theophylline_Kurata2022_reference;
