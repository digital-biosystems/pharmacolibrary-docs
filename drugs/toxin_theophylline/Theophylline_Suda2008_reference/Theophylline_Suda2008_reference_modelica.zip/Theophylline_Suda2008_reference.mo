model Theophylline_Suda2008_reference
  parameter Real Cl_ref = 6.9166666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0903 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0004,
    ka = 0.00041894444444444444,
    Tlag = 2970.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>theophylline</td></tr><tr><td>population:</td><td>Premature neonates and infants with apnea</td></tr><tr><td>source_paper:</td><td>Suda_2008</td></tr><tr><td>measured_compound:</td><td>Theophylline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>theophylline 180.167 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'mean±s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean±s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean±s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean±s.d.' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>dropped unlinked row (NIL): 'Postnatal age (d)' — extend the ontology if this is a real PK parameter (source ['Suda_2008_table_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Body weight (g)' — extend the ontology if this is a real PK parameter (source ['Suda_2008_table_1:row2:col1'])</li><li>dropped unlinked row (NIL): 'Birth weight (g)' — extend the ontology if this is a real PK parameter (source ['Suda_2008_table_1:row3:col1'])</li><li>dropped unlinked row (NIL): 'PCA (week)' — extend the ontology if this is a real PK parameter (source ['Suda_2008_table_1:row4:col1'])</li><li>table mostly unlinked (4/4 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q27 ('The mean oral clearance was'=0.0249) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Theophylline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q76 (V/F) from Kwack_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Theophylline_Suda2008_reference;
