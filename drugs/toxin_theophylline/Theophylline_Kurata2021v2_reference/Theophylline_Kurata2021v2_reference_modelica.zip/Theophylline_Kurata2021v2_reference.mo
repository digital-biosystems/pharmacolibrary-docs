model Theophylline_Kurata2021v2_reference
  parameter Real Cl_ref = 1.313888888888889e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0903 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0004,
    ka = 0.00041894444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>theophylline</td></tr><tr><td>population:</td><td>Japanese bronchial asthma patients</td></tr><tr><td>source_paper:</td><td>Kurata_2021_2</td></tr><tr><td>measured_compound:</td><td>Theophylline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>theophylline 180.167 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '0.697CPA' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.441CPC' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.876CH' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.687MELD < 10' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.568MELD 10-14' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.487MELD 15-19' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.417MELD 20-24' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>dropped unlinked row (NIL): '0.328MELD ≥ 25' — extend the ontology if this is a real PK parameter (source ['Kurata_2021_2:abstract'])</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'No unit stated in text. CL/F represents clearance. Priority 2 conventions specify clearances in L/h. The value 0.0473 L/')</li><li>implicit units: '0.874CH' → L/h (from the popPK convention: &quot;No unit stated in text. The parameter description identifies it as 'intercompartmental clearance' (Q). Priority 2 conven&quot;)</li><li>implicit units: '0.592CPB' → 1/h (from the popPK convention: &quot;No unit stated in text. The parameter description identifies it as a 'First-order rate constant' (kfm). Priority 2 conve&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Theophylline</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q76 (V/F) from Kwack_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Theophylline_Kurata2021v2_reference;
