function p = Theophylline_Kurata2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: theophylline   source: Kurata_2021_2 / reference   route: oral
  p.name  = 'Theophylline_Kurata2021v2_reference_params';
  p.drug  = 'theophylline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 90.3;                % central volume [L]
  p.CL = 0.0473;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.5082;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
