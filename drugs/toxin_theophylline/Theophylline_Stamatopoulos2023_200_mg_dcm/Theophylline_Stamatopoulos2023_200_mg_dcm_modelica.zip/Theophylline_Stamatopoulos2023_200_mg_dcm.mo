model Theophylline_Stamatopoulos2023_200_mg_dcm
  parameter Real Cl_ref = 1.3611111111111113e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0027 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180167,
    adminMass = 0.0002,
    ka = 0.00041894444444444444,
    Tlag = 2970.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>theophylline</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Stamatopoulos_2023</td></tr><tr><td>measured_compound:</td><td>Theophylline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-00882-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>theophylline 180.167 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'Cmax' → mg mL−1 (from the paper text: 'Table 1. Mean simulated and observed pharmacokinetic parameters (Cmax (mg mL−1)...')</li><li>implicit units: 'AUC' — the LLM proposed 'mg mL−1 h−1', whose dimension does not fit Q88; left unset</li><li>implicit units: 'Tmax' → h (from the paper text: 'Table 1. Mean simulated and observed pharmacokinetic parameters (... and Tmax (h))...')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Theophylline</li><li>population split: '200 mg dcm' subgroup of Stamatopoulos_2023 (paper reports 6 populations: 200 mg dcm, 200 mg usp ii, 400 mg dcm, 400 mg usp ii, mean dcm, mean usp ii)</li><li>gap-filled Q22 (CL) from Frymoyer_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Frymoyer_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kong_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kwack_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Frymoyer_2020, Kong_2026, Kwack_2026 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q88 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Theophylline_Stamatopoulos2023_200_mg_dcm;
