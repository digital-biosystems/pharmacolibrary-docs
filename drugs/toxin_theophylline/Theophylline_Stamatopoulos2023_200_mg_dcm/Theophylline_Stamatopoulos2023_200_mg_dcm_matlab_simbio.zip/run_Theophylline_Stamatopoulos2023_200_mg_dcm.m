% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Theophylline_Stamatopoulos2023_200_mg_dcm_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
