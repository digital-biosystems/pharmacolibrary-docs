% Run: build params, simulate 0..216.0 h, plot + save Theophylline_Stamatopoulos2023_400_mg_dcm.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Theophylline_Stamatopoulos2023_400_mg_dcm.m
here = fileparts(mfilename('fullpath'));
p = Theophylline_Stamatopoulos2023_400_mg_dcm_params();
out = simulate_pk(p, 0:0.05:216.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('theophylline — Stamatopoulos_2023 (oral)');
print(fig, fullfile(here, 'Theophylline_Stamatopoulos2023_400_mg_dcm.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Theophylline_Stamatopoulos2023_400_mg_dcm.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Theophylline_Stamatopoulos2023_400_mg_dcm.json'), 'w');
try
  s.model = 'Theophylline_Stamatopoulos2023_400_mg_dcm'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Theophylline_Stamatopoulos2023_400_mg_dcm","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Theophylline_Stamatopoulos2023_400_mg_dcm.png, Theophylline_Stamatopoulos2023_400_mg_dcm.csv, Theophylline_Stamatopoulos2023_400_mg_dcm.json\n');
