function p = Albendazole_Shah2023_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: albendazole   source: Shah_2023 / value   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Albendazole_Shah2023_value_params';
  p.drug  = 'albendazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 161.0;                % central volume [L]
  p.CL = 2.09;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7082;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
