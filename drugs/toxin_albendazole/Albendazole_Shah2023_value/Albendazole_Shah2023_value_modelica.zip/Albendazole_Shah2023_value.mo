model Albendazole_Shah2023_value
  parameter Real Cl_ref = 5.805555555555555e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0004,
    ka = 0.00019672222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>albendazole</td></tr><tr><td>population:</td><td>healthy human volunteers</td></tr><tr><td>source_paper:</td><td>Shah_2023</td></tr><tr><td>measured_compound:</td><td>Albendazole sulfoxide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-01040-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Albendazole 265.331 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'fuGut'; source reconciliation required</li><li>table representations disagree for 'Peff,man (10–4 cm/s)'; source reconciliation required</li><li>table representations disagree for 'Minimal PBPK Vss (L/kg)'; source reconciliation required</li><li>table representations disagree for 'Oral clearance (L/h)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Peff,man (10–4 cm/s)' — extend the ontology if this is a real PK parameter (source ['Shah_2023_table_2:row2:col1'])</li><li>dropped value-less row: 'B/P: blood to plasma ratio'</li><li>dropped value-less row: 'fu: fraction unbound in plasma'</li><li>dropped value-less row: 'fuGut: fraction unbound in enterocyte'</li><li>dropped value-less row: 'Peff,man: effective permeability in humans'</li><li>dropped value-less row: 'Clint: intrinsic clearance'</li><li>metabolite albendazole sulfoxide: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Albendazole sulfoxide</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model (site presystemic: 'Developing a Formulation Strategy Coupled with PBPK Modeling and Simulation for the Weakly Basic Drug Albendazole Abstra')</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Albendazole_Shah2023_value;
