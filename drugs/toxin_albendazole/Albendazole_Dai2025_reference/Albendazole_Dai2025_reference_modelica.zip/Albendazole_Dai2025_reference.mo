// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Albendazole_Dai2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {136512.0},
    MM = 0.26533100000000004,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>albendazole</td></tr><tr><td>population:</td><td>Yellow River carp (Cyprinus carpio haematopterus)</td></tr><tr><td>source_paper:</td><td>Dai_2025</td></tr><tr><td>measured_compound:</td><td>Albendazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Albendazole 265.331 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('t1/2λZ liver', value 32.07) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2λZ gills', value 31.92) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2λZ bile', value 31.51) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2λZ kidney', value 26.96) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2λZ intestine', value 20.81) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2λZ plasma', value 19.86) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Albendazole</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/7 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Albendazole sulfoxide (ABZSO)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Fimbo_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1555.2));
end Albendazole_Dai2025_reference;
