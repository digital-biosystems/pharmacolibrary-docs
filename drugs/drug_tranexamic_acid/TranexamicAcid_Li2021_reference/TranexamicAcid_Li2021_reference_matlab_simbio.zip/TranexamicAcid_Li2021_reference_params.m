function p = TranexamicAcid_Li2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tranexamic_acid   source: Li_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'TranexamicAcid_Li2021_reference_params';
  p.drug  = 'tranexamic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.1;                % central volume [L]
  p.CL = 9.4;                % clearance [L/h]
  p.Vp = [14.0];             % peripheral volumes [L]
  p.Q  = [22.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
