function p = TranexamicAcid_Gilliot2022_original_dataset_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tranexamic_acid   source: Gilliot_2022 / original_dataset   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'TranexamicAcid_Gilliot2022_original_dataset_params';
  p.drug  = 'tranexamic_acid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9.25;                % central volume [L]
  p.CL = 4.62;                % clearance [L/h]
  p.Vp = [9.49];             % peripheral volumes [L]
  p.Q  = [19.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
