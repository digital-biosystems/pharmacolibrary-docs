model Topiramate_Wei2023_reference
  parameter Real Cl_ref = 1.2222222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0066 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33935899999999997,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>topiramate</td></tr><tr><td>population:</td><td>Chinese pediatric patients with epilepsy</td></tr><tr><td>source_paper:</td><td>Wei_2023</td></tr><tr><td>measured_compound:</td><td>Topiramate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>topiramate 339.359 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'BW⁄11.7' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Wei_2023:abstract', 'Wei_2023:abstract', 'Wei_2023:abstract'])</li><li>dropped unlinked row (NIL): 'eOXC' — extend the ontology if this is a real PK parameter (source ['Wei_2023:abstract', 'Wei_2023:abstract'])</li><li>dropped unlinked row (NIL): '0.81' — extend the ontology if this is a real PK parameter (source ['Wei_2023:abstract'])</li><li>dropped unlinked row (NIL): 'eGRIK1-UGT' — extend the ontology if this is a real PK parameter (source ['Wei_2023:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Topiramate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Topiramate_Wei2023_reference;
