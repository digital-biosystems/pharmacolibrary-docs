function p = Topiramate_Wei2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: topiramate   source: Wei_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Topiramate_Wei2023_reference_params';
  p.drug  = 'topiramate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.6;                % central volume [L]
  p.CL = 0.44;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
