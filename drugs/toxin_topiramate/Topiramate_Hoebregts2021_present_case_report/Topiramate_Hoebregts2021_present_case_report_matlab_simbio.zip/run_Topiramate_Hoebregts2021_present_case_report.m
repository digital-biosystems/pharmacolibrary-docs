% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Topiramate_Hoebregts2021_present_case_report_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
