function p = Topiramate_Hoebregts2021_present_case_report_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: topiramate   source: Hoebregts_2021 / present_case_report   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Topiramate_Hoebregts2021_present_case_report_params';
  p.drug  = 'topiramate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 48.3;                % central volume [L]
  p.CL = 2.39;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
