model Topiramate_Hoebregts2021_present_case_report
  parameter Real Cl_ref = 6.638888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.048299999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33935899999999997,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>topiramate</td></tr><tr><td>population:</td><td>adult patients (case series including one acute overdose)</td></tr><tr><td>source_paper:</td><td>Hoebregts_2021</td></tr><tr><td>measured_compound:</td><td>Topiramate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>topiramate 339.359 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Topiramate</li><li>population split: 'present case report' subgroup of Hoebregts_2021 (paper reports 3 populations: general population, patient by brandt et al. [2], present case report)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Topiramate_Hoebregts2021_present_case_report;
