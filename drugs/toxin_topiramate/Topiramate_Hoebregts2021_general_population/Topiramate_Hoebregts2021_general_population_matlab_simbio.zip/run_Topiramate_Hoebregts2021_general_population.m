% Run (SimBiology): build model + dose, simulate 0..168.0 h, plot.
p = Topiramate_Hoebregts2021_general_population_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 168.0);
