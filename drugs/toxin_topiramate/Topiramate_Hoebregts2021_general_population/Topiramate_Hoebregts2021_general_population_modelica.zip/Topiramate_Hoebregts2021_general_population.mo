model Topiramate_Hoebregts2021_general_population
  parameter Real Cl_ref = 3.638888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.056 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33935899999999997,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>topiramate</td></tr><tr><td>population:</td><td>adult patients (case series including one acute overdose)</td></tr><tr><td>source_paper:</td><td>Hoebregts_2021</td></tr><tr><td>measured_compound:</td><td>Topiramate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>topiramate 339.359 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Ingested dose (mg)' — extend the ontology if this is a real PK parameter (source ['Table1:row1:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Topiramate</li><li>population split: 'general population' subgroup of Hoebregts_2021 (paper reports 3 populations: general population, patient by brandt et al. [2], present case report)</li><li>gap-filled Q22 (CL) from Bamgboye_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Donovan_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bamgboye_2026, Donovan_2016 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Topiramate_Hoebregts2021_general_population;
