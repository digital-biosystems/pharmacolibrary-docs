model Topiramate_Callisto2020_PD_accuracy
  "linear exposure-response sweep — Callisto_2020 :: accuracy (accuracy in modified Sternberg working memory task)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -36,  // [meter ** 3 / kilogram; %/(μg/mL) × 10]
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Topiramate_Callisto2020_PD_accuracy</h4><p>The steady-state exposure-response curve of Callisto SP et al., <i>Journal of clinical pharmacology 60(9):1166-1176</i> 2020 (<a href=\"https://doi.org/10.1002/jcph.1611\">doi:10.1002/jcph.1611</a>) — accuracy in modified Sternberg working memory task [%] against topiramate μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -3.6 %/(μg/mL) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of topiramate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Topiramate_Callisto2020_PD_accuracy;
