function p = Topiramate_Callisto2020_PD_accuracy_params()
% Topiramate_Callisto2020_PD_accuracy_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% topiramate Callisto_2020::accuracy: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response accuracy in %. Driver: topiramate (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -36.000000000000014;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
