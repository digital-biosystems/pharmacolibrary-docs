% Run (SimBiology): build model + dose, simulate 0..35.0 h, plot.
p = Brivaracetam_Pressler2024_individual_patient_data_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 35.0);
