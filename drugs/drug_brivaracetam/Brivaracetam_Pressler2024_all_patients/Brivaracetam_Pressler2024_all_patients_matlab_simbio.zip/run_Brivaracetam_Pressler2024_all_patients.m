% Run (SimBiology): build model + dose, simulate 0..39.0 h, plot.
p = Brivaracetam_Pressler2024_all_patients_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 39.0);
