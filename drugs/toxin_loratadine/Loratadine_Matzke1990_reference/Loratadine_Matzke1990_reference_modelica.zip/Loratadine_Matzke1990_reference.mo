// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Loratadine_Matzke1990_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {31319.999999999996},
    MM = 0.38288799999999995,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>loratadine</td></tr><tr><td>population:</td><td>adult volunteers with normal renal function, patients with chronic renal failure, and chronic hemodialysis patients</td></tr><tr><td>source_paper:</td><td>Matzke_1990</td></tr><tr><td>measured_compound:</td><td>Loratadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Loratadine 382.888 g/mol (pubchem); descarboethoxyloratadine 310.825 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'Hemodialysis augmented endogenous clearance' → L/h (from the popPK convention: 'No unit was stated in the text or table. For population pharmacokinetics, drug clearance parameters (including hemodialy')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Loratadine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 0 linked by role; re-tagged Loratadine→descarboethoxyloratadine ×3</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 316.8));
end Loratadine_Matzke1990_reference;
