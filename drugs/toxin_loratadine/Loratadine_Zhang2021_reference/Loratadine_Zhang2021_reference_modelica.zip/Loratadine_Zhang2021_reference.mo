model Loratadine_Zhang2021_reference
  parameter Real Cl_ref = 8.294444444444446e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.028392 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38288799999999995,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>loratadine</td></tr><tr><td>population:</td><td>male beagles</td></tr><tr><td>source_paper:</td><td>Zhang_2021</td></tr><tr><td>measured_compound:</td><td>Loratadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Desloratadine 310.825 g/mol (pubchem); Loratadine 382.888 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'mean ± sd / r' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>table representations disagree for 'LTD'; source reconciliation required</li><li>column 'mean ± sd / ta' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± sd / tb' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>table representations disagree for 'LTD'; source reconciliation required</li><li>table representations disagree for 'LTD'; source reconciliation required</li><li>column 'key pharmacokinetic parameters' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'AUC0-t (ng. h/mL)'; source reconciliation required</li><li>column 'mean ± sd / r' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± sd / ta' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± sd / tb' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'key pharmacokinetic parameters' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'AUC0-∞ (ng. h/mL)'; source reconciliation required</li><li>column 'mean ± sd / r' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± sd / ta' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li><li>column 'mean ± sd / tb' classified 'ci' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Loratadine_Zhang2021_reference;
