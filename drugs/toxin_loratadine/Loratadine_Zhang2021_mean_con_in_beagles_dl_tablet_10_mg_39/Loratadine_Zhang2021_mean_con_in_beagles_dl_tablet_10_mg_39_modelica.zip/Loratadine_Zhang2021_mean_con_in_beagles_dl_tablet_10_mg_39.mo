// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Loratadine_Zhang2021_mean_con_in_beagles_dl_tablet_10_mg_39
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {40284.0},
    MM = 0.38288799999999995,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>loratadine</td></tr><tr><td>population:</td><td>male beagles</td></tr><tr><td>source_paper:</td><td>Zhang_2021</td></tr><tr><td>measured_compound:</td><td>Loratadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t0005</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Desloratadine 310.825 g/mol (pubchem); Loratadine 382.888 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Loratadine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'mean con. in beagles / dl tablet (10 mg)39' subgroup of Zhang_2021 (paper reports 4 populations: mean con. in beagles / dl tablet (10 mg)39, mean con. in beagles / ltd tablet (10 mg), mean con. in humans / dl tablet (10 mg)41, mean con. in humans / ltd tablet (10 mg)40)</li><li>row roles (LLM): model_class=noncompartmental; 13/13 row label(s) assigned, 8 linked by role; re-tagged parent→Desloratadine ×5</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Loratadine_Zhang2021_mean_con_in_beagles_dl_tablet_10_mg_39;
