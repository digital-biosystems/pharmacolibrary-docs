function p = Sapropterin_Feillet2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sapropterin   source: Feillet_2008 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Sapropterin_Feillet2008_reference_params';
  p.drug  = 'sapropterin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8350.0;                % central volume [L]
  p.CL = 2100.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
