% Run: build params, simulate 0..31.0 h, plot + save Gabapentin_Qin2025_po_600_mg_bid.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Gabapentin_Qin2025_po_600_mg_bid.m
here = fileparts(mfilename('fullpath'));
p = Gabapentin_Qin2025_po_600_mg_bid_params();
out = simulate_pk(p, 0:0.05:31.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('gabapentin — Qin_2025 (oral)');
print(fig, fullfile(here, 'Gabapentin_Qin2025_po_600_mg_bid.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Gabapentin_Qin2025_po_600_mg_bid.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Gabapentin_Qin2025_po_600_mg_bid.json'), 'w');
try
  s.model = 'Gabapentin_Qin2025_po_600_mg_bid'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Gabapentin_Qin2025_po_600_mg_bid","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Gabapentin_Qin2025_po_600_mg_bid.png, Gabapentin_Qin2025_po_600_mg_bid.csv, Gabapentin_Qin2025_po_600_mg_bid.json\n');
