model Gabapentin_Oggianu2023_reference
  parameter Real Cl_ref = 1.8423999999999997e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.059219999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17124,
    adminMass = 0.0018,
    ka = 0.00021611111111111112,
    Tlag = 1116.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gabapentin</td></tr><tr><td>population:</td><td>mice (with human trazodone PK as secondary)</td></tr><tr><td>source_paper:</td><td>Oggianu_2023</td></tr><tr><td>measured_compound:</td><td>Gabapentin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13472-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gabapentin 171.24 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'k'; source reconciliation required</li><li>table representations disagree for 'k'; source reconciliation required</li><li>table representations disagree for 'V 1/F'; source reconciliation required</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'V 1/F'; source reconciliation required</li><li>table representations disagree for 'k 12'; source reconciliation required</li><li>table representations disagree for 'k 12'; source reconciliation required</li><li>table representations disagree for 'k 21'; source reconciliation required</li><li>table representations disagree for 'k 21'; source reconciliation required</li><li>table representations disagree for 'D 1'; source reconciliation required</li><li>table representations disagree for 'D 1'; source reconciliation required</li><li>table representations disagree for 'ω¯v2'; source reconciliation required</li><li>table representations disagree for 'ω¯v2'; source reconciliation required</li><li>table representations disagree for 'ω¯k2'; source reconciliation required</li><li>table representations disagree for 'ω¯k2'; source reconciliation required</li><li>table representations disagree for 'ω¯k122'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Gabapentin_Oggianu2023_reference;
