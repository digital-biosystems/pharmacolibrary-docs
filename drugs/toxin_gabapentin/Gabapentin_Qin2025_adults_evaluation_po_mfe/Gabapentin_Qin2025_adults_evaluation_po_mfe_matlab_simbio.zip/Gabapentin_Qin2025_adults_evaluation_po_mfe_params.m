function p = Gabapentin_Qin2025_adults_evaluation_po_mfe_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gabapentin   source: Qin_2025 / adults_evaluation_po_mfe   route: oral
  % estimated (absent from source): F
  p.name  = 'Gabapentin_Qin2025_adults_evaluation_po_mfe_params';
  p.drug  = 'gabapentin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 44.61;                % central volume [L]
  p.CL = 5.73;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.778;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.31;             % absorption lag [h]
  p.dose = 1800.0;             % dose [mg]
end
