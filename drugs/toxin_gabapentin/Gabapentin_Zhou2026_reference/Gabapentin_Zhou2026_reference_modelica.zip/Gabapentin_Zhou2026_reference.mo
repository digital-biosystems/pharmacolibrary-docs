model Gabapentin_Zhou2026_reference
  parameter Real Cl_ref = 2.8222222222222223e-06 "Cl [m3/s]";
  parameter Real cov_egfr = 1.0 "egfr covariate (reference 1.0)";
  parameter Real Vd_ref = 0.01816 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_egfr/1.0)^(1.34),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17124,
    adminMass = 0.0002,
    ka = 3.888888888888889e-05,
    Tlag = 1224.0,
    k12 = 0.00010064855604503181,
    k21 = 5.110235070813257e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gabapentin</td></tr><tr><td>population:</td><td>patients with chronic neuropathic pain (Brazilian clinical studies)</td></tr><tr><td>source_paper:</td><td>Zhou_2026</td></tr><tr><td>measured_compound:</td><td>Gabapentin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gabapentin 171.24 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Additive (a)' routed out of structural estimates ('Residual error model for PK')</li><li>table section residual_error: 'Additive (a)' routed out of structural estimates ('Residual error model for PD')</li><li>table section residual_error: 'Proportional (b)' routed out of structural estimates ('Residual error model for PD')</li><li>table representations disagree for 'tlag (h)'; source reconciliation required</li><li>table representations disagree for 'ka (h-1)'; source reconciliation required</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'logt (eGFR/84.85) on CL/F'; source reconciliation required</li><li>table representations disagree for 'V1/F (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>table representations disagree for 'V2/F (L)'; source reconciliation required</li><li>table representations disagree for 'ke1 (h-1)'; source reconciliation required</li><li>table representations disagree for 'OCT2 on ke1'; source reconciliation required</li><li>table representations disagree for 'E0'; source reconciliation required</li><li>table representations disagree for 'IC50 (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'ke2 (h-1)'; source reconciliation required</li><li>table representations disagree for 'Imax'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Gabapentin_Zhou2026_reference;
