function p = Gabapentin_Zhou2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gabapentin   source: Zhou_2026 / reference   route: oral
  p.name  = 'Gabapentin_Zhou2026_reference_params';
  p.drug  = 'gabapentin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.16;                % central volume [L]
  p.CL = 10.16;                % clearance [L/h]
  p.Vp = [357.67];             % peripheral volumes [L]
  p.Q  = [6.58];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.34;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
