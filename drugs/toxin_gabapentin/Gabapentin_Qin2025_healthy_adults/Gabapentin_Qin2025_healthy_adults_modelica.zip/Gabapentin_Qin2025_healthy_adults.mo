model Gabapentin_Qin2025_healthy_adults
  parameter Real Cl_ref = 1.591666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.044610000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17124,
    adminMass = 0.0018,
    ka = 0.00021611111111111112,
    Tlag = 1116.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gabapentin</td></tr><tr><td>population:</td><td>healthy and renally impaired adults and pediatric subjects aged 1 month to 17 years, various ethnicities</td></tr><tr><td>source_paper:</td><td>Qin_2025</td></tr><tr><td>measured_compound:</td><td>Gabapentin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gabapentin 171.24 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'AUC0- ∞ (µg·h/mL)'; source reconciliation required</li><li>table representations disagree for 'Cmax (µg/mL)'; source reconciliation required</li><li>table representations disagree for 'tmax (h)'; source reconciliation required</li><li>table representations disagree for 'Method'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Method' — extend the ontology if this is a real PK parameter (source ['T3:row110:col2'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['T3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['T3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Qd' from footnote/prose loose number None (source ['T3:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Gabapentin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: 'healthy adults' subgroup of Qin_2025 (paper reports 21 populations: 1m-3 y po single 10 mg/kg, 3-15 years po 5.7 mg/kg tid, adults evaluation, adults evaluation gmfe, adults evaluation po. mfe, caucasian po 600 + 1200 mg bid, healthy adults, observed mean, pediatric patients, po 1200 mg tid, po 1600 mg tid, po 1800 mg qd, po 400 mg tid, po 600 mg bid, po 600 mg qd, po singe 400 mg (mild ri), po singe 400 mg (severe ri), po single 300 mg, po single 600 mg, predicted mean, ri adults)</li><li>gap-filled Q22 (CL) from Al-Zubaydi_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Al-Zubaydi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Gabapentin_Qin2025_healthy_adults;
