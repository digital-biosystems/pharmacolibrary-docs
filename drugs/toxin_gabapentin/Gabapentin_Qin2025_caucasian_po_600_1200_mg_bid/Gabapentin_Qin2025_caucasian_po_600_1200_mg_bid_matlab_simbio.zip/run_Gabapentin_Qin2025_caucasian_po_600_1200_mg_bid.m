% Run (SimBiology): build model + dose, simulate 0..31.0 h, plot.
p = Gabapentin_Qin2025_caucasian_po_600_1200_mg_bid_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 31.0);
