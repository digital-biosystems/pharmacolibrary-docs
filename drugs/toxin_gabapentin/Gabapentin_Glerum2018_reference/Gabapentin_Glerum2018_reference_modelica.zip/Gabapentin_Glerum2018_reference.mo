model Gabapentin_Glerum2018_reference
  parameter Real Cl_ref = 2e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.044610000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17124,
    adminMass = 0.0008,
    ka = 0.00021611111111111112,
    Tlag = 1116.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gabapentin</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Glerum_2018</td></tr><tr><td>measured_compound:</td><td>Gabapentin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt1023-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gabapentin 171.24 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iov: 'Ka (h−1)' routed out of structural estimates ('BOV')</li><li>table section iov: 'Tlag (h)' routed out of structural estimates ('BOV')</li><li>table section iov: 'V (l)' routed out of structural estimates ('BOV')</li><li>table section iov: 'KCP (h−1)' routed out of structural estimates ('BOV')</li><li>table section iov: 'KPC (h−1)' routed out of structural estimates ('BOV')</li><li>table section iov: 'Ke (h−1)' routed out of structural estimates ('BOV')</li><li>salvaged Q22 ('creatinine clearance (mean'=120) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Gabapentin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Al-Zubaydi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Al-Zubaydi_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Al-Zubaydi_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Al-Zubaydi_2024 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Gabapentin_Glerum2018_reference;
