function p = Imdevimab_Lin2024_estimate_imdevimab_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imdevimab   source: Lin_2024 / estimate_imdevimab   route: oral
  p.name  = 'Imdevimab_Lin2024_estimate_imdevimab_params';
  p.drug  = 'imdevimab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.823;                % central volume [L]
  p.CL = 0.009829;                % clearance [L/h]
  p.Vp = [3.199];             % peripheral volumes [L]
  p.Q  = [0.016788];             % inter-compartmental clearances [L/h]
  p.ka = 0.009808;                % absorption rate [1/h]
  p.F  = 0.6617;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
