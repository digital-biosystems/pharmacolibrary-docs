function p = Imdevimab_Lin2024_estimate_casirivimab_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imdevimab   source: Lin_2024 / estimate_casirivimab   route: oral
  p.name  = 'Imdevimab_Lin2024_estimate_casirivimab_params';
  p.drug  = 'imdevimab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.917;                % central volume [L]
  p.CL = 0.008025;                % clearance [L/h]
  p.Vp = [3.065];             % peripheral volumes [L]
  p.Q  = [0.017213];             % inter-compartmental clearances [L/h]
  p.ka = 0.009096;                % absorption rate [1/h]
  p.F  = 0.72;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
