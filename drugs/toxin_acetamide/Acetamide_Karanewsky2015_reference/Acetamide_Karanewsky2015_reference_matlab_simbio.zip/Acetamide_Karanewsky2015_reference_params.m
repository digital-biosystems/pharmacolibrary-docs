function p = Acetamide_Karanewsky2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: acetamide   source: Karanewsky_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Acetamide_Karanewsky2015_reference_params';
  p.drug  = 'acetamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.872868;                % central volume [L]
  p.CL = 77.28;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
