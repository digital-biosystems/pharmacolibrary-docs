// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cladribine_AlessiSeverini1995_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1080.0},
    adminMass = 6.3e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cladribine</td></tr><tr><td>population:</td><td>leukemia cells from patients with chronic lymphocytic leukemia (CLL)</td></tr><tr><td>source_paper:</td><td>Alessi-Severini_1995</td></tr><tr><td>measured_compound:</td><td>2-chlorodeoxyadenosine (cladribine)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cladribine 285.688 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'mean half-life, initial rate of 2-CdA efflux with 0.5 microM nitrobenzylthioinosine (NBMPR)' Q328 → Q59: a half-life by its label (the unit decides, not the label)</li><li>dropped duplicate Q59 ('mean half-life, initial rate of 2-CdA efflux with 0.5 microM nitrobenzylthioinosine (NBMPR)', value 0.43) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2-chlorodeoxyadenosine (cladribine)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for '2-chlorodeoxyadenosine (cladribine)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Lindemalm_2005's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Lindemalm_2005's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG from Savic_2017: its label names a different analyte ('phase') — 'Lag time for phase III, h'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Cladribine_AlessiSeverini1995_reference;
