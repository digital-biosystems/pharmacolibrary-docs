% Run: build params, simulate 0..72.0 h, plot every molecule + save Cladribine_Liliemark1997_reference.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Cladribine_Liliemark1997_reference.m
here = fileparts(mfilename('fullpath'));
p = Cladribine_Liliemark1997_reference_params();
out = simulate_network(p, 0:0.05:72.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('cladribine — Liliemark_1997 (retention function)');
print(fig, fullfile(here, 'Cladribine_Liliemark1997_reference.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Cladribine_Liliemark1997_reference.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Cladribine_Liliemark1997_reference.json'), 'w');
try
  s.model = 'Cladribine_Liliemark1997_reference'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Cladribine_Liliemark1997_reference"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Cladribine_Liliemark1997_reference.png, Cladribine_Liliemark1997_reference.csv, Cladribine_Liliemark1997_reference.json\n');
