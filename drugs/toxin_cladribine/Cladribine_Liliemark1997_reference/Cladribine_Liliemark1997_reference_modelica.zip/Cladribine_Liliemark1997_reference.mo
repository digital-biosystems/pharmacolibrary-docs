// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cladribine_Liliemark1997_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {45720.0},
    MM = 0.285688,
    adminMass = 6.3e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cladribine</td></tr><tr><td>population:</td><td>patients with low-grade lymphoproliferative disorders, childhood AML and multiple sclerosis</td></tr><tr><td>source_paper:</td><td>Liliemark_1997</td></tr><tr><td>measured_compound:</td><td>Cladribine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cladribine 285.688 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cladribine</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: terminal half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Lindemalm_2005's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG from Savic_2017: its label names a different analyte ('phase') — 'Lag time for phase III, h'</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint; C5 dimensioned parameter(s) without a unit: Q26 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Cladribine_Liliemark1997_reference;
