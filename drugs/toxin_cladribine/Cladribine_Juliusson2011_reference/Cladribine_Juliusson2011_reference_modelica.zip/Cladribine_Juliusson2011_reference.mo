// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cladribine_Juliusson2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {46800.0},
    adminMass = 6.3e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cladribine</td></tr><tr><td>population:</td><td>patients with hairy cell leukemia</td></tr><tr><td>source_paper:</td><td>Juliusson_2011</td></tr><tr><td>measured_compound:</td><td>Cladribine (intracellular active metabolite)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cladribine 285.688 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'intracellular initial half-life' Q334 → Q59: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cladribine (intracellular active metabolite)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'Cladribine (intracellular active metabolite)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Cladribine (intracellular active metabolite)', not cladribine — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Cladribine_Juliusson2011_reference;
