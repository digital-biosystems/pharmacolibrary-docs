function p = Sumatriptan_Bax1993_PD_contractions_of_the_isolated_human_co_params()
% Sumatriptan_Bax1993_PD_contractions_of_the_isolated_human_co_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sumatriptan Bax_1993::contractions_of_the_isolated_human_coronary_artery: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response contractions of the isolated human coronary artery in mN. Driver: sumatriptan (cited_pk).
p.E0 = 0.0;
p.Emax = 10.7;
p.EC50 = 6.2;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 62.0;
p.form = 'E0 + Emax*frac';
end
