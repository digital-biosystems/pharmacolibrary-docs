model Sumatriptan_Bax1993_PD_contractions_of_the_isolated_human_co
  "emax exposure-response sweep — Bax_1993 :: contractions of the isolated human coronary artery (contractions of the isolated human coronary artery)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 10.7,  // [mN]
    EC50 = 6.2,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 62, Interval = 0.124),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sumatriptan</h4><p>Sumatriptan is a serotonin 5-HT1 receptor agonist used to treat migraine, including migraine with or without aura, and has also been used for giant cell arteritis. It is an approved antimigraine medicine, widely used, with products authorised across the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416978\">Wikidata Q416978</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Sumatriptan_Bax1993_PD_contractions_of_the_isolated_human_co</h4><p>The steady-state exposure-response curve of Bax WA et al., <i>European journal of pharmacology 239(1-3):203–210</i> 1993 (<a href=\"https://doi.org/10.1016/0014-2999(93)90995-t\">doi:10.1016/0014-2999(93)90995-t</a>) — contractions of the isolated human coronary artery [mN] against sumatriptan M — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       10.7 mN       maximal effect term (Emax, Q320)
  EC50  =        6.2 M        exposure at half of the maximal effect term (pD2, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of sumatriptan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.2 M)  response 5.35
  exposure -> infinity  response 10.7</pre></body></html>"));
end Sumatriptan_Bax1993_PD_contractions_of_the_isolated_human_co;
