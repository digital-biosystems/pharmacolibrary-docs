model Sumatriptan_Cosson1999_reference
  parameter Real Cl_ref = 1.9777777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0945 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2954,
    adminMass = 6e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sumatriptan</h4><p>Sumatriptan is a serotonin 5-HT1 receptor agonist used to treat migraine, including migraine with or without aura, and has also been used for giant cell arteritis. It is an approved antimigraine medicine, widely used, with products authorised across the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416978\">Wikidata Q416978</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sumatriptan</td></tr><tr><td>population:</td><td>healthy subjects and migraine patients</td></tr><tr><td>source_paper:</td><td>Cosson_1999</td></tr><tr><td>measured_compound:</td><td>sumatriptan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sumatriptan 295.4 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sumatriptan</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sumatriptan_Cosson1999_reference;
