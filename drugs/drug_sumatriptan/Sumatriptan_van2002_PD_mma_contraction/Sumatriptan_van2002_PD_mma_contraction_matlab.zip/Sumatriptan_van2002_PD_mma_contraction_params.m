function p = Sumatriptan_van2002_PD_mma_contraction_params()
% Sumatriptan_van2002_PD_mma_contraction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sumatriptan van_2002::MMA_contraction: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response MMA contraction in %. Driver: sumatriptan (cited_pk).
p.E0 = 0.0;
p.Emax = 1.1;
p.EC50 = 7.41;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 75.0;
p.form = 'E0 + Emax*frac';
end
