model Sumatriptan_van2002_PD_mma_contraction
  "emax exposure-response sweep — van_2002 :: MMA contraction (contraction of human middle meningeal artery)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.1,  // [1; % × 0.01]
    EC50 = 7.41,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 75, Interval = 0.15),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sumatriptan</h4><p>Sumatriptan is a serotonin 5-HT1 receptor agonist used to treat migraine, including migraine with or without aura, and has also been used for giant cell arteritis. It is an approved antimigraine medicine, widely used, with products authorised across the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416978\">Wikidata Q416978</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Sumatriptan_van2002_PD_mma_contraction</h4><p>The steady-state exposure-response curve of van den Broek RW et al., <i>European journal of pharmacology 443(1-3):125–132</i> 2002 (<a href=\"https://doi.org/10.1016/s0014-2999(02)01576-5\">doi:10.1016/s0014-2999(02)01576-5</a>) — contraction of human middle meningeal artery [%] against sumatriptan — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        110 %        maximal effect term (E(max), Q320)
  EC50  =       7.41          exposure at half of the maximal effect term (pEC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of sumatriptan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.41 )  response 0.55
  exposure -> infinity  response 1.1</pre></body></html>"));
end Sumatriptan_van2002_PD_mma_contraction;
