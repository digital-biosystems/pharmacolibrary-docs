model Morphine_Yalcin2022_mulla_et_al_37_uk
  parameter Real Cl_ref = 6.111111111111112e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.35000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.285343,
    adminMass = 0.0001,
    ka = 0.00024694444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>critically ill neonates and infants undergoing ECMO</td></tr><tr><td>source_paper:</td><td>Yalcin_2022</td></tr><tr><td>measured_compound:</td><td>Morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T12</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>morphine 285.343 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Administered dose' — extend the ontology if this is a real PK parameter (source ['T12:row1:col8'])</li><li>dropped unlinked row (NIL): 'Recommended dose' — extend the ontology if this is a real PK parameter (source ['T12:row1:col12'])</li><li>salvaged Q57 ('t1/2'=6.8) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('morphine Cl'=2.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Morphine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'mulla et al,37 uk' subgroup of Yalcin_2022 (paper reports 2 populations: mulla et al,37 uk, peters et al,33 the netherlands)</li><li>gap-filled Q61 (V) from Hernández-Gago_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Tang_2025's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Hernández-Gago_2026, Tang_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Morphine_Yalcin2022_mulla_et_al_37_uk;
