% Run (SimBiology): build model + dose, simulate 0..38.0 h, plot.
p = Morphine_Yalcin2022_mulla_et_al_37_uk_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 38.0);
