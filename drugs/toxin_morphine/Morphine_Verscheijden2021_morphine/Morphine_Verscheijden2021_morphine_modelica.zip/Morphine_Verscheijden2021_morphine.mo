model Morphine_Verscheijden2021_morphine
  parameter Real Cl_ref = 8.333333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.35000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.285343,
    adminMass = 0.0001,
    ka = 0.00024694444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>predominantly term and preterm neonates, children (1 day-16 years) and adults; PBPK/PD model scaled for age</td></tr><tr><td>source_paper:</td><td>Verscheijden_2021</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pcbi.1008786.t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>morphine 285.343 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '-' (MW)</li><li>unit_dimension_unknown: '-' (equation variable)</li><li>dropped PD-category row 'EP' → Q326 (ke0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['pcbi.1008786.t001:row4:col2'])</li><li>unit_dimension_unknown: '-' (fu)</li><li>unit_dimension_unknown: '-' (fu)</li><li>dropped duplicate Q46 ('Fupl', value '0.64') — already have one for this compound</li><li>unit_dimension_unknown: '-' (fu)</li><li>dropped duplicate Q46 ('FuCSF', value '1') — already have one for this compound</li><li>dropped duplicate Q22 ('CLiv (adult)', value None) — already have one for this compound</li><li>dropped duplicate Q22 ('CLiv (2-18y)', value None) — already have one for this compound</li><li>dropped duplicate Q22 ('CLiv (neonates)', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'Net in vitro ER' — extend the ontology if this is a real PK parameter (source ['pcbi.1008786.t001:row15:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=morphine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Morphine_Verscheijden2021_morphine;
