function p = Morphine_Verscheijden2021_morphine_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: morphine   source: Verscheijden_2021 / morphine   route: oral
  % estimated (absent from source): F
  p.name  = 'Morphine_Verscheijden2021_morphine_params';
  p.drug  = 'morphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 350.0;                % central volume [L]
  p.CL = 300.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.889;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
