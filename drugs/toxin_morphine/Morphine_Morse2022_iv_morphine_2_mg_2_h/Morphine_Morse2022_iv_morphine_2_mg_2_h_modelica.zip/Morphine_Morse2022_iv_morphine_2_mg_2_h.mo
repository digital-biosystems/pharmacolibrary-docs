// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Morphine_Morse2022_iv_morphine_2_mg_2_h
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {960.0},
    MM = 0.285343,
    adminMass = 3e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>neonates, children and adolescents (models scaled from adult diamorphine and paediatric morphine data)</td></tr><tr><td>source_paper:</td><td>Morse_2022</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>morphine 285.343 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'TABS'</li><li>documentation only: 'KA' → Q49 (kabs) comes from ['fig_6:caption'], not from a located parameter table — not emitted as a model parameter</li><li>dropped duplicate Q40 ('FIN', value 0.5) — already have one for this compound</li><li>'F6MAM' → Q40: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q40 ('F6MAM', value 2) — already have one for this compound</li><li>dropped duplicate Q40 ('BETAV', value 0.391) — already have one for this compound</li><li>documentation only: 'TVOL' → Q61 (V) comes from ['fig_6:caption'], not from a located parameter table — not emitted as a model parameter</li><li>dropped duplicate Q40 ('FVOL', value None) — already have one for this compound</li><li>documentation only: 'VDIAM' → Q76 (V/F) comes from ['fig_6:caption'], not from a located parameter table — not emitted as a model parameter</li><li>dropped duplicate Q40 ('V6MAM', value None) — already have one for this compound</li><li>documentation only: 'VM' → Q66 (Vmax) comes from ['fig_6:caption'], not from a located parameter table — not emitted as a model parameter</li><li>documentation only: 'VM3G' → Q61 (V) comes from ['fig_6:caption'], not from a located parameter table — not emitted as a model parameter</li><li>dropped duplicate Q40 ('VM6G', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'dose' — extend the ontology if this is a real PK parameter (source ['fig_6:caption'])</li><li>salvaged Q57 ('T 1/2 keo MOR'=16) from results prose — parameter table was unreadable</li><li>implicit units: LLM call failed (JSONDecodeError: Extra data: line 1 column 210 (char 209)) — units left missing</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Morphine_Morse2022_iv_morphine_2_mg_2_h;
