// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Morphine_Glave2023_m3g
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {0.09012445463008001},
    MM = 0.285343,
    adminMass = 2.5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>morphine</td></tr><tr><td>population:</td><td>virtual human PBPK simulation population</td></tr><tr><td>source_paper:</td><td>Gülave_2023</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>morphine 285.343 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'plasma PK (Oosten et al., 2017)' — extend the ontology if this is a real PK parameter (source ['Gülave_2023_table_1:row0:col3', 'Gülave_2023_table_1:row1:col3', 'Gülave_2023_table_1:row4:col3', 'Gülave_2023_table_1:row5:col3', 'Gülave_2023_table_1:row6:col3', 'Gülave_2023_table_1:row7:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=morphine</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model (site presystemic: 'Fraction unbound plasma 0.65 --fAFBBB 0.21815 1 1 Kp,uu,BBB 5.4902*Css,u,plasma -0.552 0.1 c 0.25 d a fraction of metabo')</li><li>population split: 'm3g' subgroup of Gülave_2023 (paper reports 3 populations: m3g, m6g, morphine)</li><li>row roles (LLM): model_class=pbpk; 0/2 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'morphine-3-glucuronide' — its concentrations stay mass-only</li><li>molar mass: none found for 'morphine-6-glucuronide' — its concentrations stay mass-only</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Hernández-Gago_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Tang_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Morphine_Glave2023_m3g;
