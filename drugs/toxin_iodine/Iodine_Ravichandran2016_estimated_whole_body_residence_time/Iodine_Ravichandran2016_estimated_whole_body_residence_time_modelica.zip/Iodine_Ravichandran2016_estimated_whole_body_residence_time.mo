// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Iodine_Ravichandran2016_estimated_whole_body_residence_time
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {77544.0},
    MM = 0.1269,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>iodine</td></tr><tr><td>population:</td><td>thyroid cancer patients</td></tr><tr><td>source_paper:</td><td>Ravichandran_2016</td></tr><tr><td>measured_compound:</td><td>Iodine-131</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Iodine-131 126.9 g/mol (pubchem); iodine 253.8 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'recombinant TSH (rhTSH) n=17' — extend the ontology if this is a real PK parameter (source ['Ravichandran_2016_table_4:row1:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Iodine-131</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'estimated whole body residence time (h)' subgroup of Ravichandran_2016 (paper reports 3 populations: estimated retention factor at 48 h, estimated retention factor at 72 h, estimated whole body residence time (h))</li><li>gap-filled Q22 (CL) from Karim_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Iodine_Ravichandran2016_estimated_whole_body_residence_time;
