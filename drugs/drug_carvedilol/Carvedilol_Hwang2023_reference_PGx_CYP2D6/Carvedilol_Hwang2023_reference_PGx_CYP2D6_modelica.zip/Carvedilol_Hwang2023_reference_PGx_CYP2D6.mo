model Carvedilol_Hwang2023_reference_PGx_CYP2D6
  "Carvedilol_Hwang2023_reference with the CYP2D6 phenotype as a parameter (Hwang_2023)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2D6 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {4.25e-05, 4.25e-05, 5.89980313223e-05, 4.25e-05, 4.25e-05, 4.25e-05};
  extends Carvedilol_Hwang2023_reference(Cl = Cl_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Carvedilol_Hwang2023_reference_PGx_CYP2D6;
