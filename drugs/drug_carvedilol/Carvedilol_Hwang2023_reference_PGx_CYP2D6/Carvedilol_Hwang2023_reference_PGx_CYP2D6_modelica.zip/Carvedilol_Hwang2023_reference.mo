model Carvedilol_Hwang2023_reference
  parameter Real Cl_ref = 4.2499999999999996e-05 "Cl [m3/s]";
  parameter Real cov_im_0 = 0 "im covariate";
  parameter Real Vd_ref = 0.44 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.328)*cov_im_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4064742,
    adminMass = 1.25e-05,
    ka = 0.0001388888888888889,
    Tlag = 774.0,
    k12 = 2.607323232323232e-05,
    k21 = 1.521514883583849e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carvedilol</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Hwang_2023</td></tr><tr><td>measured_compound:</td><td>carvedilol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>carvedilol 406.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωTlag' routed out of structural estimates ('Interindividual variability (coefficient of variation, CV%) [η shrinkage]')</li><li>table section iiv: 'ωCL/F (%)' routed out of structural estimates ('Interindividual variability (coefficient of variation, CV%) [η shrinkage]')</li><li>table section iiv: 'ωVc (%)' routed out of structural estimates ('Interindividual variability (coefficient of variation, CV%) [η shrinkage]')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=carvedilol</li><li>pharmacogenetic covariate 'theta_cl_f_im' (im) — PGx domain</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carvedilol_Hwang2023_reference;
