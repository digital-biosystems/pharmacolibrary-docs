function p = Carvedilol_Hwang2023_PD_hr_params()
% Carvedilol_Hwang2023_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carvedilol Hwang_2023::HR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HR in bpm. Driver: carvedilol (pk_record).
p.E0 = 60.4;
p.Emax = -30.7;
p.EC50 = 1.6499999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 170.0;
p.form = 'E0 + Emax*frac';
end
