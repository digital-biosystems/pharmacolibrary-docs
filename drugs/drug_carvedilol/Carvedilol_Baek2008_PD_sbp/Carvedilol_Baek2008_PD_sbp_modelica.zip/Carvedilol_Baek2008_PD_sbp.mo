model Carvedilol_Baek2008_PD_sbp
  "sigmoid_emax exposure-response sweep — Baek_2008 :: SBP (Systolic Blood Pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.1505,  // [1; % × 0.01]
    EC50 = 2.588e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 34.72,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 260, Interval = 0.52),
    Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Carvedilol_Baek2008_PD_sbp</h4><p>The steady-state exposure-response curve of Baek IH et al., <i>Archives of pharmacal research 31(6):814–821</i> 2008 (<a href=\"https://doi.org/10.1007/s12272-001-1231-4\">doi:10.1007/s12272-001-1231-4</a>) — Systolic Blood Pressure [%] against carvedilol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      15.05 %        maximal effect term (E max, Q323)
  EC50  =      25.88 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =      34.72          Hill coefficient (Γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of carvedilol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (25.88 ng/mL)  response -0.07525
  exposure -> infinity  response -0.1505</pre></body></html>"));
end Carvedilol_Baek2008_PD_sbp;
