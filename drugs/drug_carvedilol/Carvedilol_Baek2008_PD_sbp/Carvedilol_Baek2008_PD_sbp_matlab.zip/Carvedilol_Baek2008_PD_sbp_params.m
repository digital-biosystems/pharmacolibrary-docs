function p = Carvedilol_Baek2008_PD_sbp_params()
% Carvedilol_Baek2008_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carvedilol Baek_2008::SBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response SBP in %. Driver: carvedilol (pk_record).
p.E0 = 0.0;
p.Emax = -0.15050000000000002;
p.EC50 = 2.5879999999999996e-05;
p.gamma = 34.72;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 260.0;
p.form = 'E0 + Emax*frac';
end
