function p = Carvedilol_Baek2008_PD_dbp_params()
% Carvedilol_Baek2008_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carvedilol Baek_2008::DBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response DBP in %. Driver: carvedilol (pk_record).
p.E0 = 0.0;
p.Emax = -0.2799;
p.EC50 = 1.081e-05;
p.gamma = 44.1;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 110.0;
p.form = 'E0 + Emax*frac';
end
