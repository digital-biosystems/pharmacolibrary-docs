function p = Carvedilol_Hwang2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carvedilol   source: Hwang_2023 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Carvedilol_Hwang2023_reference_params';
  p.drug  = 'carvedilol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 440.0;                % central volume [L]
  p.CL = 153.0;                % clearance [L/h]
  p.Vp = [754.0];             % peripheral volumes [L]
  p.Q  = [41.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.215;             % absorption lag [h]
  p.dose = 12.5;             % dose [mg]
end
