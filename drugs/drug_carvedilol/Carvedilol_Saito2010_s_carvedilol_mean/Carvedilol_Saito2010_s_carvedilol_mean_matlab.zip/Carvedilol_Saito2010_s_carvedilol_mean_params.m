function p = Carvedilol_Saito2010_s_carvedilol_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carvedilol   source: Saito_2010 / s_carvedilol_mean   route: oral
  p.name  = 'Carvedilol_Saito2010_s_carvedilol_mean_params';
  p.drug  = 'carvedilol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1050.0;                % central volume [L]
  p.CL = 161.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.08;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.25;             % dose [mg]
end
