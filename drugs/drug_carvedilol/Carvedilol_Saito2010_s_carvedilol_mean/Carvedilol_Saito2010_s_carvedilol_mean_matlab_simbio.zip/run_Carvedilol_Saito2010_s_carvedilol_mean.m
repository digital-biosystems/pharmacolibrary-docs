% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Carvedilol_Saito2010_s_carvedilol_mean_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
