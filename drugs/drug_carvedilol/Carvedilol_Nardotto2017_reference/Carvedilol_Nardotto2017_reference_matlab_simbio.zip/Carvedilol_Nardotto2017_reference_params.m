function p = Carvedilol_Nardotto2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carvedilol   source: Nardotto_2017 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Carvedilol_Nardotto2017_reference_params';
  p.drug  = 'carvedilol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.67;                % central volume [L]
  p.CL = 4.85;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 10.63;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.5;             % dose [mg]
end
