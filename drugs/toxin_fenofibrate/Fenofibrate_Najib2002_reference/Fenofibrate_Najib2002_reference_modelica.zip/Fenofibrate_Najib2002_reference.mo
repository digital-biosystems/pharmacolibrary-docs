model Fenofibrate_Najib2002_reference
  parameter Real Cl_ref = 5.997648520678416e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0623 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.360834,
    adminMass = 0.0002,
    ka = 0.0001388888888888889,
    Tlag = 28800.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fenofibrate</td></tr><tr><td>population:</td><td>healthy volunteers and hyperlipidemic patients</td></tr><tr><td>source_paper:</td><td>Najib_2002</td></tr><tr><td>measured_compound:</td><td>Fenofibrate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Fenofibrate 360.834 g/mol (pubchem); Fenofibric acid 360.834 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>'protein binding' → Q46: printed without a unit and above 1 — read as a percentage</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Fenofibrate</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 0 linked by role</li><li>molar mass: none of 2 PubChem candidate(s) is 'Fenofibric acid glucuronide' (LLM) — left in mass units</li><li>molar mass: none found for 'Fenofibric acid glucuronide' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Li_2019_2's review values (primary lacked it)</li><li>derived CL/F=2.15915 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Fenofibrate_Najib2002_reference;
