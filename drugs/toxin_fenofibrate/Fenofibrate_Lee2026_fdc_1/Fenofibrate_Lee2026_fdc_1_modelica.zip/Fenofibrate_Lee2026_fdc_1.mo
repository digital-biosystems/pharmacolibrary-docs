// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Fenofibrate_Lee2026_fdc_1
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {26676.0},
    MM = 0.360834,
    adminMass = 2e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fenofibrate</td></tr><tr><td>population:</td><td>Healthy Korean participants</td></tr><tr><td>source_paper:</td><td>Lee_2026</td></tr><tr><td>measured_compound:</td><td>Fenofibric acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>cpdd70043-tbl-0001</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Fenofibrate 360.834 g/mol (pubchem); Fenofibric acid 360.834 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h•µg/L' (AUClast)</li><li>unit_dimension_unknown: 'h•µg/L' (AUC∞)</li><li>unit_dimension_unknown: 'h•µg/L' (AUClast)</li><li>unit_dimension_unknown: 'h•µg/L' (AUC∞)</li><li>dropped duplicate Q57 ('MR', value '1.18') — already have one for this compound</li><li>implicit units: 'AUClast (h•µg/L)' — the LLM proposed 'h•µg/L', whose dimension does not fit Q74; left unset</li><li>implicit units: 'AUCinf (h•µg/L)' — the LLM proposed 'h•µg/L', whose dimension does not fit Q17; left unset</li><li>implicit units: 'AUClast (h•µg/L)' — the LLM proposed 'h•µg/L', whose dimension does not fit Q74; left unset</li><li>implicit units: 'AUCinf (h•µg/L)' — the LLM proposed 'h•µg/L', whose dimension does not fit Q17; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fenofibric acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'fdc 1 (n = 36)' subgroup of Lee_2026 (paper reports 4 populations: fdc 1 (n = 36), fdc 2 (n = 36), loose combination 1 (n = 36), loose combination 2 (n = 36))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 273.6));
end Fenofibrate_Lee2026_fdc_1;
