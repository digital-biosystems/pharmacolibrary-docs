// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Fenofibrate_Younis2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {76680.0},
    MM = 0.360834,
    adminMass = 4.8e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fenofibrate</td></tr><tr><td>population:</td><td>Participants with mild hepatic impairment, healthy controls, or advanced fibrosis due to MAFLD</td></tr><tr><td>source_paper:</td><td>Younis_2025</td></tr><tr><td>measured_compound:</td><td>Fenofibric acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>jcph70005-tbl-0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Fenofibrate 360.834 g/mol (pubchem); Fenofibric acid 360.834 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Pharmacokinetic Parameter' — extend the ontology if this is a real PK parameter (source ['jcph70005-tbl-0002:row1:col1', 'jcph70005-tbl-0002:row1:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fenofibric acid</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role</li><li>gap-filled Q22 (CL) from Uppalapati_2014's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Li_2019_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 864.0));
end Fenofibrate_Younis2025_reference;
