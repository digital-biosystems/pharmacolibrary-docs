% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Atogepant_Schlachter2026_phase_2_modela_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
