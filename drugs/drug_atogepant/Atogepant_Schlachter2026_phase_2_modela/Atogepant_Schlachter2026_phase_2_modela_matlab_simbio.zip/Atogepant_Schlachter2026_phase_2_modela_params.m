function p = Atogepant_Schlachter2026_phase_2_modela_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atogepant   source: Schlachter_2026 / phase_2_modela   route: oral
  p.name  = 'Atogepant_Schlachter2026_phase_2_modela_params';
  p.drug  = 'atogepant';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 72.9;                % central volume [L]
  p.CL = 18.2;                % clearance [L/h]
  p.Vp = [91.7];             % peripheral volumes [L]
  p.Q  = [0.771];             % inter-compartmental clearances [L/h]
  p.ka = 1.31;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.298;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
