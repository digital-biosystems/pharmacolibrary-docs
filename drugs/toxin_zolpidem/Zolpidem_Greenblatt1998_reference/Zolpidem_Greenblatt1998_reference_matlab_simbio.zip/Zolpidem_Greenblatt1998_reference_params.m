function p = Zolpidem_Greenblatt1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zolpidem   source: Greenblatt_1998 / reference   route: oral
  p.name  = 'Zolpidem_Greenblatt1998_reference_params';
  p.drug  = 'zolpidem';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 74.8;                % central volume [L]
  p.CL = 258.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.41;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.394;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
