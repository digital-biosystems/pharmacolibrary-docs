model Zolpidem_Greenblatt1998_reference
  parameter Real Cl_ref = 7.166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0748 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.307397,
    adminMass = 1e-05,
    ka = 0.0015027777777777778,
    Tlag = 1418.4
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zolpidem</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Greenblatt_1998</td></tr><tr><td>measured_compound:</td><td>Zolpidem</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zolpidem 307.397 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('zolpidem t1/2', value None) — already have one for this compound</li><li>dropped duplicate Q27 ('zolpidem apparent oral clearance', value None) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2', value '2.1') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Zolpidem</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q76 (V/F) from Cha_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Cha_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Cha_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Cha_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zolpidem_Greenblatt1998_reference;
