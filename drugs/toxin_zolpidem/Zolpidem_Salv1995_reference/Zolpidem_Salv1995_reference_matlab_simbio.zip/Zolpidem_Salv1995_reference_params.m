function p = Zolpidem_Salv1995_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zolpidem   source: Salvà_1995 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Zolpidem_Salv1995_reference_params';
  p.drug  = 'zolpidem';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 63.6;                % central volume [L]
  p.CL = 1.008;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.41;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.394;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
