model Doxycycline_Toutain2025_bsv
  parameter Real Cl_ref = 5.833333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0553 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>pigs</td></tr><tr><td>source_paper:</td><td>Toutain_2025</td></tr><tr><td>measured_compound:</td><td>doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp13511-tbl-0006</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Vc'</li><li>dropped value-less row: 'V2'</li><li>dropped value-less row: 'V3'</li><li>dropped value-less row: 'Clearance'</li><li>dropped value-less row: 'Cld2'</li><li>dropped value-less row: 'Cld3'</li><li>dropped value-less row: 'KaOR_FEED_TLS'</li><li>dropped value-less row: 'F_FEED_TLS'</li><li>dropped value-less row: 'KaOR_FEED_OTHERS'</li><li>dropped value-less row: 'F_FEED_OTHERS'</li><li>dropped value-less row: 'KaOR_SOLTUBING'</li><li>dropped value-less row: 'F_SOLTUBING'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxycycline_Toutain2025_bsv;
