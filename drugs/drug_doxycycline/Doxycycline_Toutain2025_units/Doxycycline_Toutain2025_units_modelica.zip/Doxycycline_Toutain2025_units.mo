model Doxycycline_Toutain2025_units
  parameter Real Cl_ref = 5.833333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0553 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>pigs</td></tr><tr><td>source_paper:</td><td>Toutain_2025</td></tr><tr><td>measured_compound:</td><td>doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp13511-tbl-0006</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'KaOR_FEED_TLS' — extend the ontology if this is a real PK parameter (source ['jvp13511-tbl-0006:row14:col2'])</li><li>dropped unlinked row (NIL): 'KaOR_FEED_OTHERS' — extend the ontology if this is a real PK parameter (source ['jvp13511-tbl-0006:row20:col2'])</li><li>dropped unlinked row (NIL): 'KaOR_SOLTUBING' — extend the ontology if this is a real PK parameter (source ['jvp13511-tbl-0006:row26:col2'])</li><li>dropped unlinked row (NIL): 'KaOR_SOL_DW' — extend the ontology if this is a real PK parameter (source ['jvp13511-tbl-0006:row32:col2'])</li><li>table mostly unlinked (4/4 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxycycline</li><li>status held at route_to_review — not promoted</li><li>population split: 'units' subgroup of Toutain_2025 (paper reports 3 populations: bsv%, estimate, units)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxycycline_Toutain2025_units;
