model Doxycycline_Mileva2021_estimates
  parameter Real Cl_ref = 5.833333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0553 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>mature and immature rabbits</td></tr><tr><td>source_paper:</td><td>Mileva_2021</td></tr><tr><td>measured_compound:</td><td>doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-10-00310-t001</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Thetas (typical value)' — extend the ontology if this is a real PK parameter (source ['antibiotics-10-00310-t001:row1:col2'])</li><li>dropped unlinked row (NIL): 'Secondary parameters' — extend the ontology if this is a real PK parameter (source ['antibiotics-10-00310-t001:row5:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxycycline</li><li>population split: 'estimates' subgroup of Mileva_2021 (paper reports 3 populations: estimates, parameter name, units)</li><li>gap-filled Q22 (CL) from Altan_2024's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Altan_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxycycline_Mileva2021_estimates;
