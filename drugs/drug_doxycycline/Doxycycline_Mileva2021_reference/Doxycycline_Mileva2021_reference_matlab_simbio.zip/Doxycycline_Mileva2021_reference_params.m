function p = Doxycycline_Mileva2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxycycline   source: Mileva_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doxycycline_Mileva2021_reference_params';
  p.drug  = 'doxycycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 310.03;                % central volume [L]
  p.CL = 103.11;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
