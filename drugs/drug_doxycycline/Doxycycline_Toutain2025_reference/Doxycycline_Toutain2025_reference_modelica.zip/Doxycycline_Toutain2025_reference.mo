model Doxycycline_Toutain2025_reference
  parameter Real Cl_ref = 5.036111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01344 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4444346,
    adminMass = 0.0014,
    k12 = 0.0017057291666666668,
    k21 = 0.000550420168067227
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxycycline</h4><p>Doxycycline is a tetracycline antibiotic used to treat many bacterial infections, including pneumonia, acne, Lyme disease, and chlamydia, and to prevent malaria. It is widely used in human medicine and is also approved for veterinary use, and it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422442\">Wikidata Q422442</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>pigs</td></tr><tr><td>source_paper:</td><td>Toutain_2025</td></tr><tr><td>measured_compound:</td><td>doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp13511-tbl-0006</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxycycline 444.435 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Vc' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'V2' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'V3' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'Clearance' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'Cld2' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'Cld3' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'KaOR_FEED_TLS' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'F_FEED_TLS' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'KaOR_FEED_OTHERS' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'F_FEED_OTHERS' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'KaOR_SOLTUBING' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'F_SOLTUBING' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'KaOR_SOL_DW' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'F_SOL_DW' routed out of structural estimates ('BSV%')</li><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxycycline_Toutain2025_reference;
