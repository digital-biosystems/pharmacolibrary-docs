function p = Teprotumumab_Xin2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: teprotumumab   source: Xin_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Teprotumumab_Xin2021_reference_params';
  p.drug  = 'teprotumumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.94;                % central volume [L]
  p.CL = 0.013917;                % clearance [L/h]
  p.Vp = [4.21];             % peripheral volumes [L]
  p.Q  = [0.035792];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
