model Teprotumumab_Xin2021_reference
  parameter Real Cl_ref = 3.865740740740741e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00394 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    k12 = 2.5233831547283322e-06,
    k21 = 2.3615509809096503e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About teprotumumab</h4><p>Teprotumumab is a monoclonal antibody used to treat Graves ophthalmopathy. It is an approved medicine, with one product authorised in the European Union, and remains investigational for other uses.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>teprotumumab</td></tr><tr><td>population:</td><td>patients with thyroid eye disease and oncology</td></tr><tr><td>source_paper:</td><td>Xin_2021</td></tr><tr><td>measured_compound:</td><td>teprotumumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=teprotumumab</li><li>molar mass: none found for 'teprotumumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Teprotumumab_Xin2021_reference;
