model Fluticasone_Mllmann1998_PD_granulocytes
  "indirect_response_iii exposure-response sweep — Möllmann_1998 :: granulocytes (granulocyte induction)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type III effect term
    EC50 = 3e-08,  // [kg/m3; pg.ml(-1) × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg.ml(-1) per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 300, Interval = 0.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluticasone</h4><p>Fluticasone is a corticosteroid used to treat inflammatory conditions such as rhinitis, sinusitis, and other respiratory diseases, and is also applied to the skin. It is widely used, available as nasal, inhaled, and dermatological preparations, though some products have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1002165\">Wikidata Q1002165</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluticasone_Mllmann1998_PD_granulocytes</h4><p>The steady-state exposure-response curve of Möllmann H et al., <i>European journal of clinical pharmacology 53(6):459–467</i> 1998 (<a href=\"https://doi.org/10.1007/s002280050407\">doi:10.1007/s002280050407</a>) — granulocyte induction against fluticasone propionate pg.ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =         30 pg.ml(-1) exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one pg.ml(-1) of fluticasone propionate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (30 pg.ml(-1))  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Fluticasone_Mllmann1998_PD_granulocytes;
