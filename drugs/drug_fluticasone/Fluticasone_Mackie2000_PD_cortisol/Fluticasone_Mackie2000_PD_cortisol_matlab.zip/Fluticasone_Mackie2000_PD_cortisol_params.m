function p = Fluticasone_Mackie2000_PD_cortisol_params()
% Fluticasone_Mackie2000_PD_cortisol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluticasone Mackie_2000::cortisol: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/L x h per second, in SI inside (kg/m3, s). Response cortisol in %. Driver: fluticasone propionate (dose_only).
p.E0 = -0.005;
p.Emax = -0.72;
p.EC50 = 3.2;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 32.0;
p.form = 'E0 + Emax*frac';
end
