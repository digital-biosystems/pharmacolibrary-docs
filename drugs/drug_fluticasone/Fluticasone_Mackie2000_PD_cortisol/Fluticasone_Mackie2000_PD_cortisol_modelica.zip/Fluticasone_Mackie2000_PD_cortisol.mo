model Fluticasone_Mackie2000_PD_cortisol
  "emax exposure-response sweep — Mackie_2000 :: cortisol (plasma cortisol level)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -0.005,      // [1; % × 0.01]
    Emax = -0.72,  // [1; % × 0.01]
    EC50 = 3.2,  // [microg/L x h]
    gamma = 1,
    exposure_per_s = 1);   // 1 microg/L x h per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'microg/L x h' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 32, Interval = 0.064),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluticasone</h4><p>Fluticasone is a corticosteroid used to treat inflammatory conditions such as rhinitis, sinusitis, and other respiratory diseases, and is also applied to the skin. It is widely used, available as nasal, inhaled, and dermatological preparations, though some products have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1002165\">Wikidata Q1002165</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluticasone_Mackie2000_PD_cortisol</h4><p>The steady-state exposure-response curve of Mackie AE et al., <i>Clinical pharmacokinetics 39 Suppl 1:47–54</i> 2000 (<a href=\"https://doi.org/10.2165/00003088-200039001-00007\">doi:10.2165/00003088-200039001-00007</a>) — plasma cortisol level [%] against fluticasone propionate microg/L x h — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       -0.5 %        drug-free response (baseline) (intercept in the absence of drug, Q324)
  Emax  =         72 %        maximal effect term (maximum drug-induced reduction in mean plasma cortisol levels, Q323)
  EC50  =        3.2 microg/L x h exposure at half of the maximal effect term (systemic exposure to FP that resulted in half the maximum possible reduction in plasma cortisol levels, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg/L x h of fluticasone propionate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -0.005   (drug-free)
  exposure = EC50 (3.2 microg/L x h)  response -0.365
  exposure -> infinity  response -0.725</pre></body></html>"));
end Fluticasone_Mackie2000_PD_cortisol;
