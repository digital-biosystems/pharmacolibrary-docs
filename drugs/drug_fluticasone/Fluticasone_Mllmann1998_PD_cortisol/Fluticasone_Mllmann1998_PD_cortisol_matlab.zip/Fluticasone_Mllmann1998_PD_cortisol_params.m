function p = Fluticasone_Mllmann1998_PD_cortisol_params()
% Fluticasone_Mllmann1998_PD_cortisol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluticasone Möllmann_1998::cortisol: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg.ml(-1) per second, in SI inside (kg/m3, s). Response cortisol in its own unit. Driver: fluticasone propionate (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 7.3e-09;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 73.0;
p.form = 'E0*(1 - Emax*frac)';
end
