function p = Fluticasone_Rebello2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluticasone   source: Rebello_2026 / reference   route: oral
  p.name  = 'Fluticasone_Rebello2026_reference_params';
  p.drug  = 'fluticasone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.3;                % central volume [L]
  p.CL = 27.0;                % clearance [L/h]
  p.Vp = [84.4];             % peripheral volumes [L]
  p.Q  = [60.2];             % inter-compartmental clearances [L/h]
  p.ka = 46.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 31.6;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
