function p = Risedronate_Yates2013_PD_bmd_params()
% Risedronate_Yates2013_PD_bmd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risedronate Yates_2013::BMD: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response BMD in %. Driver: risedronate (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.01;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
