model Risedronate_Yates2013_PD_bmd
  "log_linear exposure-response sweep — Yates_2013 :: BMD (spine BMD)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1.15740740741e-11);
  parameter Real slope = 0.01   "[dimensionless; % × 0.01]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Risedronate_Yates2013_PD_bmd</h4><p>The steady-state exposure-response curve of Yates J, <i>Osteoporosis international : a journal established as result of cooperation between the European Foundation for Osteoporosis and the National Osteoporosis Foundation of the USA 24(1):253–262</i> 2013 (<a href=\"https://doi.org/10.1007/s00198-012-2179-3\">doi:10.1007/s00198-012-2179-3</a>) — spine BMD [%] against risedronate mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =          1 %        change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one mg/day of risedronate per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Risedronate_Yates2013_PD_bmd;
