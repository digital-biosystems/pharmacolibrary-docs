% Run: build params, simulate 0..47.0 h, plot every molecule + save Risedronate_Namazi2025_test_formulation_xr5.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Risedronate_Namazi2025_test_formulation_xr5.m
here = fileparts(mfilename('fullpath'));
p = Risedronate_Namazi2025_test_formulation_xr5_params();
out = simulate_network(p, 0:0.05:47.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('risedronate — Namazi_2025 (retention function)');
print(fig, fullfile(here, 'Risedronate_Namazi2025_test_formulation_xr5.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Risedronate_Namazi2025_test_formulation_xr5.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Risedronate_Namazi2025_test_formulation_xr5.json'), 'w');
try
  s.model = 'Risedronate_Namazi2025_test_formulation_xr5'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Risedronate_Namazi2025_test_formulation_xr5"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Risedronate_Namazi2025_test_formulation_xr5.png, Risedronate_Namazi2025_test_formulation_xr5.csv, Risedronate_Namazi2025_test_formulation_xr5.json\n');
