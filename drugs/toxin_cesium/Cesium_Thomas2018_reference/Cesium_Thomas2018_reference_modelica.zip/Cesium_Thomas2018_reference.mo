// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cesium_Thomas2018_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {149719.79100094817},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cesium</td></tr><tr><td>population:</td><td>freshwater and marine plankton (daphnids, copepods) and planktivorous fish</td></tr><tr><td>source_paper:</td><td>Thomas_2018</td></tr><tr><td>measured_compound:</td><td>137Cs (cesium-137)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cesium 132.91 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Rate constants of 137Cs loss from fish (aqueous exposure, marine)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Thomas_2018:abstract'])</li><li>relinked 'Rate constants of 137Cs loss from fish (dietary exposure, marine)' Q50 → Q47: a pool's clearance rate constant, not excretion into urine or faeces (the unit decides, not the label)</li><li>dropped duplicate Q47 ('Rate constants of 137Cs loss from fish (dietary exposure, marine)', value 0.06) — already have one for this compound</li><li>dropped duplicate Q47 ('Rate constants of 137Cs loss from fish (dietary exposure, freshwater)', value 0.3) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=137Cs (cesium-137)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for '137Cs (cesium-137)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1555.2));
end Cesium_Thomas2018_reference;
