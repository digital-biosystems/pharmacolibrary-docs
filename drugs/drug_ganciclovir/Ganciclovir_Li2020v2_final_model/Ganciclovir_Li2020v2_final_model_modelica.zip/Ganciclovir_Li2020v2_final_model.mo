model Ganciclovir_Li2020v2_final_model
  parameter Real Cl_ref = 1.4527777777777779e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01135 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25523060000000003,
    adminMass = 0.0005
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ganciclovir</h4><p>Ganciclovir is an antiviral drug used to treat cytomegalovirus infections, especially cytomegalovirus retinitis in people with HIV, and also eye infections such as herpes simplex virus keratitis. It is an approved medicine used in hospital settings for serious infections, and it carries a boxed warning because it can be toxic.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417640\">Wikidata Q417640</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ganciclovir</td></tr><tr><td>population:</td><td>critically ill children with cytomegalovirus infection</td></tr><tr><td>source_paper:</td><td>Li_2020_2</td></tr><tr><td>measured_compound:</td><td>ganciclovir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T5</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ganciclovir 255.231 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω Vd (%)' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω Vd (%)' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω CL (%)' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω CL (%)' routed out of structural estimates ('Inter-individual')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q900 ('θ3', value '1.02') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ganciclovir</li><li>population split: 'final model' subgroup of Li_2020_2 (paper reports 8 populations: final model, model i: the 3/4 allometric model, model ii: the simplest wt-based exponent model, model iii: the simplest bsa-based exponent model, model iv: the maturation model, model v: the wt-dependent exponent model, model vi: the age-dependent exponent model, model vii: the bsa-dependent exponent model)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ganciclovir_Li2020v2_final_model;
