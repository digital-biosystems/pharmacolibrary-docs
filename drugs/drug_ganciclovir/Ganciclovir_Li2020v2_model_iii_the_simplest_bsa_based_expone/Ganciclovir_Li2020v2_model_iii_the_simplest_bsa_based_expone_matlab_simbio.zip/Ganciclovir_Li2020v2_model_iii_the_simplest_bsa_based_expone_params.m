function p = Ganciclovir_Li2020v2_model_iii_the_simplest_bsa_based_expone_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ganciclovir   source: Li_2020_2 / model_iii_the_simplest_bsa_based_exponent_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ganciclovir_Li2020v2_model_iii_the_simplest_bsa_based_expone_params';
  p.drug  = 'ganciclovir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.99;                % central volume [L]
  p.CL = 4.68;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
