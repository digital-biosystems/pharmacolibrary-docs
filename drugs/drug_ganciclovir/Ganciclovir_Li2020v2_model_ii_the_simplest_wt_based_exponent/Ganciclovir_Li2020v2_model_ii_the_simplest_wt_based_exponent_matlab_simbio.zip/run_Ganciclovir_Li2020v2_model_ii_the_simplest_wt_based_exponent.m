% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Ganciclovir_Li2020v2_model_ii_the_simplest_wt_based_exponent_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
