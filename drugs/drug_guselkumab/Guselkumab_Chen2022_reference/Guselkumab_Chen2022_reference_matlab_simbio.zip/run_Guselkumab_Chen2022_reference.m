% Run (SimBiology): build model + dose, simulate 0..2184.0 h, plot.
p = Guselkumab_Chen2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2184.0);
