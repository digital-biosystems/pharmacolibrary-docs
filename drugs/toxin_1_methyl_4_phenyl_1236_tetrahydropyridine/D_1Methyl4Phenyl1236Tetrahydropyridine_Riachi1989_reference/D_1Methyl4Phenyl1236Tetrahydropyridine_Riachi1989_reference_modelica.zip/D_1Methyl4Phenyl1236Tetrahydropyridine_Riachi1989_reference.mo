// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_1Methyl4Phenyl1236Tetrahydropyridine_Riachi1989_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {415.88830833596717},
    MM = 0.173259,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>1_methyl_4_phenyl_1236_tetrahydropyridine</td></tr><tr><td>population:</td><td>anesthetized rats</td></tr><tr><td>source_paper:</td><td>Riachi_1989</td></tr><tr><td>measured_compound:</td><td>1-Methyl-4-phenyl-1,2,3,6-tetrahydropyridine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>1-Methyl-4-phenyl-1,2,3,6-tetrahydropyridine 173.259 g/mol (pubchem); 1-methyl-4-phenylpyridinium 170.235 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate weight for λ1 from footnote/prose kept as documentation only (['Riachi_1989:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1-Methyl-4-phenyl-1,2,3,6-tetrahydropyridine</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=other; 2/2 row label(s) assigned, 2 linked by role; re-tagged 1-Methyl-4-phenyl-1,2,3,6-tetrahydropyridine→butanol ×1, 1-Methyl-4-phenyl-1,2,3,6-tetrahydropyridine→parent ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end D_1Methyl4Phenyl1236Tetrahydropyridine_Riachi1989_reference;
