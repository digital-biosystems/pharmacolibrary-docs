function p = Bemarituzumab_Xiang2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bemarituzumab   source: Xiang_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Bemarituzumab_Xiang2020_reference_params';
  p.drug  = 'bemarituzumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.7;                % central volume [L]
  p.CL = 0.013792;                % clearance [L/h]
  p.Vp = [2.05];             % peripheral volumes [L]
  p.Q  = [0.032833];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 21.0;             % dose [mg]
end
