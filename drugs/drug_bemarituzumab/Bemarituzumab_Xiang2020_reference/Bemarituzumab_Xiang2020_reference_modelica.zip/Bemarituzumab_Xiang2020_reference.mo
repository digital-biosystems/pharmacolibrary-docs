model Bemarituzumab_Xiang2020_reference
  parameter Real Cl_ref = 3.831018518518519e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0037 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.1e-05,
    k12 = 2.464964964964965e-06,
    k21 = 4.44896115627823e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bemarituzumab</h4><p>Bemarituzumab is an investigational monoclonal antibody being studied as an anticancer treatment. It is not yet approved and remains in clinical development.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bemarituzumab</td></tr><tr><td>population:</td><td>patients with gastric and gastroesophageal junction adenocarcinoma</td></tr><tr><td>source_paper:</td><td>Xiang_2020</td></tr><tr><td>measured_compound:</td><td>bemarituzumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('Linear clearance, CL (L/day)'=0.331) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('Volume of central compartment, Vc (L)'=3.7) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Distribution clearance, Q (L/day)'=0.788) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('Volume of peripheral compartment, Vp (L)'=2.05) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bemarituzumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>model equation 'CLi = exp(theta)' not bound — neither LHS nor base term 'theta' linked to an ontology parameter</li><li>model equation 'VCi = exp(theta)' not bound — neither LHS nor base term 'theta' linked to an ontology parameter</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'bemarituzumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Bemarituzumab_Xiang2020_reference;
