model Pyridoxine_Huang2023_PD_fvc
  "linear exposure-response sweep — Huang_2023 :: FVC (FVC)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 38.97,  // [meter ** 3 / kilogram; mL/mg × 1]
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Pyridoxine_Huang2023_PD_fvc</h4><p>The steady-state exposure-response curve of Huang AA et al., <i>Current developments in nutrition 7(8):100078</i> 2023 (<a href=\"https://doi.org/10.1016/j.cdnut.2023.100078\">doi:10.1016/j.cdnut.2023.100078</a>) — FVC [mL] against pyridoxine mg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      38.97 mL/mg    change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg of pyridoxine per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Pyridoxine_Huang2023_PD_fvc;
