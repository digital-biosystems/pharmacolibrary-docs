% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Heroin_Gastine2024_barrett_1996_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
