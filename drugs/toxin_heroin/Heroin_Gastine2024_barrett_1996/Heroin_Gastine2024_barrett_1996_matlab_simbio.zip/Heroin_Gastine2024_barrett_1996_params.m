function p = Heroin_Gastine2024_barrett_1996_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: heroin   source: Gastine_2024 / barrett_1996   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Heroin_Gastine2024_barrett_1996_params';
  p.drug  = 'heroin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 38.5;                % central volume [L]
  p.CL = 19.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
