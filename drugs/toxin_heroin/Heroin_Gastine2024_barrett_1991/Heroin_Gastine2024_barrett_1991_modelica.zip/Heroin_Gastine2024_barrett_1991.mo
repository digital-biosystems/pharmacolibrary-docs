model Heroin_Gastine2024_barrett_1991
  parameter Real Cl_ref = 4.2e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.189 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heroin</td></tr><tr><td>population:</td><td>neonates, children and adults receiving diamorphine</td></tr><tr><td>source_paper:</td><td>Gastine_2024</td></tr><tr><td>measured_compound:</td><td>diamorphine (heroin)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>heroin 369.417 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Participants (n)' — extend the ontology if this is a real PK parameter (source ['Gastine_2024_table_1:row1:col2'])</li><li>dropped unlinked row (NIL): 'Gestational age (weeks)' — extend the ontology if this is a real PK parameter (source ['Gastine_2024_table_1:row1:col3'])</li><li>dropped unlinked row (NIL): 'Weight (kg)' — extend the ontology if this is a real PK parameter (source ['Gastine_2024_table_1:row1:col4'])</li><li>dropped unlinked row (NIL): 'DAM dose (g/kg)' — extend the ontology if this is a real PK parameter (source ['Gastine_2024_table_1:row1:col6'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=diamorphine (heroin)</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'barrett 1991' subgroup of Gastine_2024 (paper reports 2 populations: barrett 1991, barrett 1996)</li><li>row roles (LLM): model_class=noncompartmental; 0/8 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'diamorphine (heroin)' — its concentrations stay mass-only</li><li>molar mass: none found for 'morphine' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Heroin_Gastine2024_barrett_1991;
