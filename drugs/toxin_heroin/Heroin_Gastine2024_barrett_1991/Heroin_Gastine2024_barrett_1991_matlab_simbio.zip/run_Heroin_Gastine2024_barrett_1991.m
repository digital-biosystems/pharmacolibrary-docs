% Run (SimBiology): build model + dose, simulate 0..45.0 h, plot.
p = Heroin_Gastine2024_barrett_1991_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 45.0);
