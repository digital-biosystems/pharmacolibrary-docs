model Heroin_Guessoum2025_reference
  parameter Real Cl_ref = 2.2166666666666662e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369417,
    adminMass = 0.00019
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heroin</td></tr><tr><td>population:</td><td>adults with severe opioid use disorder on intranasal heroin-assisted treatment</td></tr><tr><td>source_paper:</td><td>Guessoum_2025</td></tr><tr><td>measured_compound:</td><td>diacetylmorphine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diacetylmorphine 369.417 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '03' — extend the ontology if this is a real PK parameter (source ['Guessoum_2025_table_S1:row2:col2'])</li><li>dropped duplicate Q900 ('04', value '540') — already have one for this compound</li><li>dropped duplicate Q415 ('05', value '2200') — already have one for this compound</li><li>dropped duplicate Q415 ('06', value '1420') — already have one for this compound</li><li>dropped duplicate Q415 ('07', value '1480') — already have one for this compound</li><li>dropped duplicate Q415 ('08', value '1940') — already have one for this compound</li><li>dropped duplicate Q415 ('09', value '1740') — already have one for this compound</li><li>dropped duplicate Q900 ('11', value '1550') — already have one for this compound</li><li>dropped duplicate Q900 ('12', value '3130') — already have one for this compound</li><li>dropped duplicate Q415 ('13', value '590') — already have one for this compound</li><li>dropped unlinked row (NIL): '14' — extend the ontology if this is a real PK parameter (source ['Guessoum_2025_table_S1:row13:col2'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 141 (source ['Tab1:footnote', 'Tab1:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=diacetylmorphine</li><li>toxin: 4 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 0/15 row label(s) assigned, 0 linked by role</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Heroin_Guessoum2025_reference;
