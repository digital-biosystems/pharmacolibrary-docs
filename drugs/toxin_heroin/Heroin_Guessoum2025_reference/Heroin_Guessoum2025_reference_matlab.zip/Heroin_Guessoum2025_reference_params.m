function p = Heroin_Guessoum2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: heroin   source: Guessoum_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Heroin_Guessoum2025_reference_params';
  p.drug  = 'heroin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 200.0;                % central volume [L]
  p.CL = 79.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 190.0;             % dose [mg]
end
