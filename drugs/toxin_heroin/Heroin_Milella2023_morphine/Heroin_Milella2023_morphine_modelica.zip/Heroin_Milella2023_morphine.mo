// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Heroin_Milella2023_morphine
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {720.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heroin</td></tr><tr><td>population:</td><td>humans (and rats in cited studies)</td></tr><tr><td>source_paper:</td><td>Milella_2023</td></tr><tr><td>measured_compound:</td><td>Heroin and metabolites (6-MAM, morphine, M6G)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Heroin 369.417 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>compound tags: 1 row(s) → 6-MAM, 1 row(s) → Morphine (name 2)</li><li>dropped PD-category row 'potency (Heroin)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Milella_2023_table_2:row1:col3'])</li><li>dropped PD-category row 'potency (6-MAM)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Milella_2023_table_2:row1:col6'])</li><li>unit_dimension_unknown: 'Morphine' (KD)</li><li>dropped PD-category row 'affinity (M6G)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Milella_2023_table_2:row1:col10'])</li><li>unit_dimension_unknown: '% of dose' (fe)</li><li>salvaged Q57 ('striatal t1/2 (dopamine)'=12) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Heroin and metabolites (6-MAM, morphine, M6G)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'morphine' subgroup of Milella_2023 (paper reports 1 populations: morphine)</li><li>row roles (LLM): model_class=noncompartmental; 0/10 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Heroin_Milella2023_morphine;
