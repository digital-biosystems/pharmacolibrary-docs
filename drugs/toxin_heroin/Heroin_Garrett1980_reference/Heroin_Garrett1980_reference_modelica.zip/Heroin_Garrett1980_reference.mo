model Heroin_Garrett1980_reference
  parameter Real Cl_ref = 4.8599999999999995e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.34400000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369417,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heroin</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Garrett_1980</td></tr><tr><td>measured_compound:</td><td>heroin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>heroin 369.417 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is heroin; the compartment is heroin. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is heroin, not heroin</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>heroin's own concentration-time course is not produced by this model</li><li>unit_dimension_unknown: '% of the dose' (fe)</li><li>dropped duplicate Q61 ('overall volumes of distribution', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=heroin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>toxin: terminal half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/7 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for '6-O-monoacetylmorphine' — its concentrations stay mass-only</li><li>molar mass: none found for 'morphine' — its concentrations stay mass-only</li><li>molar mass: none found for 'morphine-3-glucuronide / morphine glucuronide conjugates' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Heroin_Garrett1980_reference;
