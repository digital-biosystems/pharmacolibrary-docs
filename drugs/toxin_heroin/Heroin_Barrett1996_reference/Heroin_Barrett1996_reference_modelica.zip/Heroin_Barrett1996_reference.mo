// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Heroin_Barrett1996_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0385},
    CLelim = {5.366666666666666e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heroin</td></tr><tr><td>population:</td><td>ventilated newborn infants (24-41 weeks gestation)</td></tr><tr><td>source_paper:</td><td>Barrett_1996</td></tr><tr><td>measured_compound:</td><td>morphine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>heroin 369.417 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q34 ('mean steady-state plasma concentration of M3G', value 703) — already have one for this compound</li><li>dropped duplicate Q34 ('mean steady-state plasma concentration of M6G', value 48) — already have one for this compound</li><li>dropped duplicate Q370 ('formation clearance of M6G', value 0.46) — already have one for this compound</li><li>conflicting Q370 for morphine: 'formation clearance of M6G' = 0.46 vs 'M3G formation clearance' = 2.5 — route to review</li><li>relinked 'M3G metabolite clearance' Q370 → Q22 for morphine: a metabolite's own clearance is its elimination, not its formation</li><li>dropped duplicate Q57 ('M6G elimination half-life', value 18.2) — already have one for this compound</li><li>dropped duplicate Q61 ('M6G volume of distribution', value 1.03) — already have one for this compound</li><li>metabolite morphine: Q351→Q22 — the model states fm, so its CL/V are not fm-divided</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=morphine</li><li>topology: 3 first-order transfer(s) across 3 compounds → general_linear</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/12 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'diamorphine (heroin)' — its concentrations stay mass-only</li><li>molar mass: none found for 'morphine' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Heroin_Barrett1996_reference;
