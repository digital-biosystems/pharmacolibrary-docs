model Lead_Ettinger2014_PD_m_p_ratio
  "linear exposure-response sweep — Ettinger_2014 :: M/P ratio (Milk-to-Plasma Lead Ratio)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -16600000,  // [(1)/(kg/m3); per 0.1 μg/L × 1e+06]
    exposure_per_s = 1e-06);   // 1 μg/L per second
  // family_inferred: the record's model family is unknown; read from the parameters: a slope and no Emax — linear
  // slope_unit_assumed: slope unit 'per 0.1 μg/L' read as response per μg/L
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Lead_Ettinger2014_PD_m_p_ratio</h4><p>The steady-state exposure-response curve of Ettinger AS et al., <i>Environmental health perspectives 122(1):87–92</i> 2014 (<a href=\"https://doi.org/10.1289/ehp.1307187\">doi:10.1289/ehp.1307187</a>) — Milk-to-Plasma Lead Ratio against Lead μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -16.6 per 0.1 μg/L change in response per unit of exposure (slope_low, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/L of Lead per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Lead_Ettinger2014_PD_m_p_ratio;
