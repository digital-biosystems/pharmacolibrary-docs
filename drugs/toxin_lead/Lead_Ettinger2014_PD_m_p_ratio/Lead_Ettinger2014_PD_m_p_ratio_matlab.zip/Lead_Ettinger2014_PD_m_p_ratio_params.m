function p = Lead_Ettinger2014_PD_m_p_ratio_params()
% Lead_Ettinger2014_PD_m_p_ratio_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lead Ettinger_2014::M_P_ratio: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response M/P ratio in its own unit. Driver: Lead (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -16600000.000000006;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
