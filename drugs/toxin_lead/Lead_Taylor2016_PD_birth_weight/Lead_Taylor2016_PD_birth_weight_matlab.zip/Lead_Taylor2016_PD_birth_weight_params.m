function p = Lead_Taylor2016_PD_birth_weight_params()
% Lead_Taylor2016_PD_birth_weight_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lead Taylor_2016::birth_weight: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/dl per second, in SI inside (kg/m3, s). Response birth weight in g. Driver: lead (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.00993;
p.exposure_per_s = 1e-05;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
