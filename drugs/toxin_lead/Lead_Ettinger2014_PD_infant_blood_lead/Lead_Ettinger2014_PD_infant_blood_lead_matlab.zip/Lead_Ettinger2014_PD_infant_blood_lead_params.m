function p = Lead_Ettinger2014_PD_infant_blood_lead_params()
% Lead_Ettinger2014_PD_infant_blood_lead_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lead Ettinger_2014::Infant_Blood_Lead: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response Infant Blood Lead in μg/dL. Driver: Lead (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 17999999.999999993;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
