model Lead_Janus2025_reference
  parameter Real Cl_ref = 0.00039347222222222225 "Cl [m3/s]";
  parameter Real Vd_ref = 0.5955 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.207,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lead</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Janus_2025</td></tr><tr><td>measured_compound:</td><td>lead</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lead 207 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Janus_2025) — secondary source</li><li>volume reported by review</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lead_Janus2025_reference;
