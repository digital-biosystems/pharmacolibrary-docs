model Lead_Ettinger2014_PD_maternal_breast_milk_lead
  "linear exposure-response sweep — Ettinger_2014 :: Maternal Breast Milk Lead (Maternal Breast Milk Lead)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1000000,  // [1 / meter ** 6; μg/L/μg/dL × 1e+07]
    exposure_per_s = 1e-05);   // 1 μg/dL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Lead_Ettinger2014_PD_maternal_breast_milk_lead</h4><p>The steady-state exposure-response curve of Ettinger AS et al., <i>Environmental health perspectives 122(1):87–92</i> 2014 (<a href=\"https://doi.org/10.1289/ehp.1307187\">doi:10.1289/ehp.1307187</a>) — Maternal Breast Milk Lead [μg/L] against Lead μg/dL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        0.1 μg/L/μg/dL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/dL of Lead per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Lead_Ettinger2014_PD_maternal_breast_milk_lead;
