function p = Lead_Ettinger2014_PD_maternal_breast_milk_lead_params()
% Lead_Ettinger2014_PD_maternal_breast_milk_lead_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lead Ettinger_2014::Maternal_Breast_Milk_Lead: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/dL per second, in SI inside (kg/m3, s). Response Maternal Breast Milk Lead in μg/L. Driver: Lead (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 999999.9999999997;
p.exposure_per_s = 1e-05;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
