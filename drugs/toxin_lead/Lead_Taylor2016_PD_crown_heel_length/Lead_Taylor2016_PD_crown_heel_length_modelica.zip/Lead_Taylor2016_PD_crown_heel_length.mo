model Lead_Taylor2016_PD_crown_heel_length
  "linear exposure-response sweep — Taylor_2016 :: crown–heel length (crown–heel length)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -0.0005,  // [meter; cm × 0.01]
    exposure_per_s = 1e-05);   // 1 µg/dl per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Lead_Taylor2016_PD_crown_heel_length</h4><p>The steady-state exposure-response curve of Taylor CM et al., <i>BMC research notes 9:291</i> 2016 (<a href=\"https://doi.org/10.1186/s13104-016-2092-5\">doi:10.1186/s13104-016-2092-5</a>) — crown–heel length [cm] against lead µg/dl — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -0.05 cm       change in response per unit of exposure (Unstandardised B regression coefficient, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µg/dl of lead per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Lead_Taylor2016_PD_crown_heel_length;
