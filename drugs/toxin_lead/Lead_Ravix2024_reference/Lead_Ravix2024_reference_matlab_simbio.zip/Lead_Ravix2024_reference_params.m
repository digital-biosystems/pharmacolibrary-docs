function p = Lead_Ravix2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lead   source: Ravix_2024 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Lead_Ravix2024_reference_params';
  p.drug  = 'lead';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 4.2;                % clearance [L/h]
  p.Vp = [338.0];             % peripheral volumes [L]
  p.Q  = [35.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.913;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
