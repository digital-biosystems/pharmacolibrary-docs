model Lead_Ettinger2014_PD_maternal_plasma_lead
  "log_linear exposure-response sweep — Ettinger_2014 :: Maternal Plasma Lead (Maternal Plasma Lead)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-05);
  parameter Real slope = 11000   "[(1)/(kg/m3); ln(μg/L)/μg/dL × 100000]";
equation
  response = E0 + slope*log(exposure);
  // slope_unit_assumed: slope unit 'ln(μg/L)/μg/dL' read as response per μg/dL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Lead_Ettinger2014_PD_maternal_plasma_lead</h4><p>The steady-state exposure-response curve of Ettinger AS et al., <i>Environmental health perspectives 122(1):87–92</i> 2014 (<a href=\"https://doi.org/10.1289/ehp.1307187\">doi:10.1289/ehp.1307187</a>) — Maternal Plasma Lead [ln(μg/L)] against Lead μg/dL — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.11 ln(μg/L)/μg/dL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one μg/dL of Lead per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Lead_Ettinger2014_PD_maternal_plasma_lead;
