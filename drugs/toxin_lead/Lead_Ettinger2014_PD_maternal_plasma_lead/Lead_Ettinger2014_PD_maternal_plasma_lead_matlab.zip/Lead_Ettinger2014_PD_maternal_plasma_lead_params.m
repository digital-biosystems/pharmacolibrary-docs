function p = Lead_Ettinger2014_PD_maternal_plasma_lead_params()
% Lead_Ettinger2014_PD_maternal_plasma_lead_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lead Ettinger_2014::Maternal_Plasma_Lead: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/dL per second, in SI inside (kg/m3, s). Response Maternal Plasma Lead in ln(μg/L). Driver: Lead (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 11000.000000000002;
p.exposure_per_s = 1e-05;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
