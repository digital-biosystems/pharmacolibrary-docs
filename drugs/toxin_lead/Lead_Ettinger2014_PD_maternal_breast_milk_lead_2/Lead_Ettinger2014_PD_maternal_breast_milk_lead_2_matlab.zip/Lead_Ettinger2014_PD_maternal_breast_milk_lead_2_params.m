function p = Lead_Ettinger2014_PD_maternal_breast_milk_lead_2_params()
% Lead_Ettinger2014_PD_maternal_breast_milk_lead_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lead Ettinger_2014::Maternal_Breast_Milk_Lead::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response Maternal Breast Milk Lead in μg/L. Driver: Lead (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2299999.999999999;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
