model ZincSulfate_Zhang2014_znso4
  parameter Real Cl_ref = 2.3702777777777776e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09666999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zinc_sulfate</td></tr><tr><td>population:</td><td>male rats</td></tr><tr><td>source_paper:</td><td>Zhang_2014</td></tr><tr><td>measured_compound:</td><td>Zinc (element measured by ICP-OES)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zinc_sulfate 161.436 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q53 ('MRT0–∞', value '11.09') — already have one for this compound</li><li>dropped value-less row: 't1/2,λz'</li><li>dropped value-less row: 'AUC0–24 h'</li><li>dropped value-less row: 'AUC0–∞'</li><li>dropped value-less row: 'Cls'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'MRT0–24 h'</li><li>dropped value-less row: 'MRT0–∞'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zinc (element measured by ICP-OES)</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'znso4' subgroup of Zhang_2014 (paper reports 2 populations: znso4, zny)</li><li>molar mass: none found for 'Zinc (element measured by ICP-OES)' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Zinc (element measured by ICP-OES)', not zinc_sulfate — the review values are the parent's</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end ZincSulfate_Zhang2014_znso4;
