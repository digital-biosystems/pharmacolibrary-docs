function p = Etravirine_Green2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: etravirine   source: Green_2017 / reference   route: oral
  p.name  = 'Etravirine_Green2017_reference_params';
  p.drug  = 'etravirine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 972.0;                % central volume [L]
  p.CL = 41.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.455;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.32;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
