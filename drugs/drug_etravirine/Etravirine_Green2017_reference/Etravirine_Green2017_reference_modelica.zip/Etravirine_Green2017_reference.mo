model Etravirine_Green2017_reference
  parameter Real Cl_ref = 1.1583333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.972 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43527699999999997,
    adminMass = 0.0004,
    ka = 0.00012638888888888888,
    Tlag = 4752.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etravirine</h4><p>Etravirine is a non-nucleoside reverse transcriptase inhibitor used to treat HIV infection. It is an approved antiviral, authorised in the European Union for HIV infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414762\">Wikidata Q414762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etravirine</td></tr><tr><td>population:</td><td>adult subjects with HIV</td></tr><tr><td>source_paper:</td><td>Green_2017</td></tr><tr><td>measured_compound:</td><td>etravirine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>etravirine 435.277 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>routed 'between-subject variability on CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'between-subject variability on V c/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=etravirine</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'apparent central volume of distribution (V c/F)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Brochot_2015's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Etravirine_Green2017_reference;
