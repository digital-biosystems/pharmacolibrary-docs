model Etravirine_Lubomirov2013_reference
  parameter Real Cl_ref = 1.138888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.325 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43527699999999997,
    adminMass = 0.0004,
    ka = 0.00012638888888888888,
    Tlag = 3132.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etravirine</h4><p>Etravirine is a non-nucleoside reverse transcriptase inhibitor used to treat HIV infection. It is an approved antiviral, authorised in the European Union for HIV infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414762\">Wikidata Q414762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etravirine</td></tr><tr><td>population:</td><td>HIV-1 infected individuals</td></tr><tr><td>source_paper:</td><td>Lubomirov_2013</td></tr><tr><td>measured_compound:</td><td>etravirine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>etravirine 435.277 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'tenofovir' — extend the ontology if this is a real PK parameter (source ['Lubomirov_2013:abstract'])</li><li>dropped unlinked row (NIL): 'rs4244285 (CYP2C19*2)' — extend the ontology if this is a real PK parameter (source ['Lubomirov_2013:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=etravirine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Brochot_2015's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Courlet_2021_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Etravirine_Lubomirov2013_reference;
