function p = Etravirine_Han2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: etravirine   source: Han_2024 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Etravirine_Han2024_reference_params';
  p.drug  = 'etravirine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.5;                % central volume [L]
  p.CL = 6.46;                % clearance [L/h]
  p.Vp = [293.0];             % peripheral volumes [L]
  p.Q  = [17.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.208;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
