model Etravirine_Han2024_reference
  parameter Real Cl_ref = 1.7944444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43527699999999997,
    adminMass = 0.0004,
    ka = 0.0001388888888888889,
    Tlag = 748.8,
    k12 = 0.00042512077294685997,
    k21 = 1.6685627607129316e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etravirine</h4><p>Etravirine is a non-nucleoside reverse transcriptase inhibitor used to treat HIV infection. It is an approved antiviral, authorised in the European Union for HIV infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414762\">Wikidata Q414762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etravirine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Han_2024</td></tr><tr><td>measured_compound:</td><td>etravirine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>etravirine 435.277 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Han_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Etravirine_Han2024_reference;
