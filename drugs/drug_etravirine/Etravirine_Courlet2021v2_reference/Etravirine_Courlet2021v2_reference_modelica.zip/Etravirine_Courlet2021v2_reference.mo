model Etravirine_Courlet2021v2_reference
  parameter Real Cl_ref = 4.722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43527699999999997,
    adminMass = 0.0004,
    ka = 0.00019166666666666665,
    Tlag = 3132.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etravirine</h4><p>Etravirine is a non-nucleoside reverse transcriptase inhibitor used to treat HIV infection. It is an approved antiviral, authorised in the European Union for HIV infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414762\">Wikidata Q414762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etravirine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Courlet_2021_2</td></tr><tr><td>measured_compound:</td><td>etravirine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>etravirine 435.277 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Courlet_2021_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Etravirine_Courlet2021v2_reference;
