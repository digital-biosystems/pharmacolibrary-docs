% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Etravirine_Courlet2021v2_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
