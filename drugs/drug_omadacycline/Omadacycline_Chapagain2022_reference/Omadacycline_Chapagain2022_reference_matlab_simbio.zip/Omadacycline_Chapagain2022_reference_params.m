function p = Omadacycline_Chapagain2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: omadacycline   source: Chapagain_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Omadacycline_Chapagain2022_reference_params';
  p.drug  = 'omadacycline';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.1;                % central volume [L]
  p.CL = 10.3;                % clearance [L/h]
  p.Vp = [79.9];             % peripheral volumes [L]
  p.Q  = [0.0072];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
