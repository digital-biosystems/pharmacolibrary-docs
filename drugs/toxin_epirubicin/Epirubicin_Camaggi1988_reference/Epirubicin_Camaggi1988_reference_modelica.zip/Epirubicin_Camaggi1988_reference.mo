model Epirubicin_Camaggi1988_reference
  parameter Real Cl_ref = 2.0833333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.226 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>cancer patients</td></tr><tr><td>source_paper:</td><td>Camaggi_1988</td></tr><tr><td>measured_compound:</td><td>Epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.525 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'vs.' (t1/2α)</li><li>implicit units: 't/2 alpha' → h (from the popPK convention: 'No units provided in text or table. The parameter is a half-life (t1/2), which describes time. In population pharmacokin')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Epirubicin</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Camaggi1988_reference;
