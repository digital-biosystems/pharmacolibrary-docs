model Epirubicin_Janssen2023_reference
  parameter Real Cl_ref = 2.8888888888888894e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00426 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 1e-05,
    k12 = 0.00039775691184141886,
    k21 = 0.0003659707223422126
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>pregnant patients</td></tr><tr><td>source_paper:</td><td>Janssen_2023</td></tr><tr><td>measured_compound:</td><td>Epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.525 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('CL (L/h)'=10.4) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V1 (L)'=4.26) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V2 (L)'=4.63) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q1'=6.1) from results prose — parameter table was unreadable</li><li>implicit units: 'CL (L/h)' → L/h (from the paper text: &quot;Table 1 explicitly lists CL units as L/h in the paper text excerpt: 'ECL = 44.1 L/h (29.4%)'.&quot;)</li><li>implicit units: 'V1 (L)' → L (from the paper text: &quot;Table 1 explicitly lists V1 units as L in the paper text excerpt: 'V1 = 8.9 L (37.8%)'.&quot;)</li><li>implicit units: 'V2 (L)' → L (from the paper text: &quot;Table 1 explicitly lists V2 units as L in the paper text excerpt: 'V2 = 7.3 L'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Epirubicin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Janssen2023_reference;
