function p = Epirubicin_Janssen2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: epirubicin   source: Janssen_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Epirubicin_Janssen2023_reference_params';
  p.drug  = 'epirubicin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.26;                % central volume [L]
  p.CL = 10.4;                % clearance [L/h]
  p.Vp = [4.63];             % peripheral volumes [L]
  p.Q  = [6.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
