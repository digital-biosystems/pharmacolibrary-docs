model Epirubicin_Twelves1992_group_2
  parameter Real Cl_ref = 4.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.232 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>women with advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Twelves_1992</td></tr><tr><td>measured_compound:</td><td>Epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.525 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'Median clearance' → L/h (from the popPK convention: 'No unit specified in text or table captions. Epirubicin clearance is typically in L/h for adult population PK. Value 17.')</li><li>implicit units: 'Median α-t½' → h (from the popPK convention: 'No unit specified. Half-lives are expressed in time units. Alpha half-life of 0.056 h (~3.4 min) is consistent with rapi')</li><li>implicit units: 'Median β-t½' → h (from the popPK convention: 'No unit specified. Beta half-life of 1.17 h is consistent with intermediate/elimination phase in hours.')</li><li>implicit units: 'Median γ-t½' → h (from the popPK convention: 'No unit specified. Gamma half-life of 31.5 h is consistent with terminal elimination phase in hours.')</li><li>implicit units: 'Median Vd' → L (from the popPK convention: 'No unit specified. Volume of distribution of 1232 L is typical for epirubicin, which has a large Vd due to tissue bindin')</li><li>implicit units: 'Median MRT' → h (from the popPK convention: 'No unit specified. MRT (Mean Residence Time) is a time parameter, expressed in hours. 36.0 h is consistent with long ter')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Epirubicin</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>population split: 'group 2' subgroup of Twelves_1992 (paper reports 3 populations: group 1, group 2, group 3)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Twelves1992_group_2;
