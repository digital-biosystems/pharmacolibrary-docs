model Epirubicin_Twelves1992_group_1
  parameter Real Cl_ref = 6.944444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.602 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>women with advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Twelves_1992</td></tr><tr><td>measured_compound:</td><td>Epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.525 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'Median clearance' → L/h (from the popPK convention: 'For clearance in population PK, L/h is the standard unit when not specified. The value 25.0 is consistent with typical e')</li><li>implicit units: 'Median α-t½' → h (from the popPK convention: 'Half-life is measured in time. The value 0.049 is very small, consistent with the alpha (distribution) half-life in hour')</li><li>implicit units: 'Median β-t½' → h (from the popPK convention: 'Half-life is measured in time. The value 1.28 is consistent with a beta (distribution/redistribution) half-life in hours')</li><li>implicit units: 'Median γ-t½' → h (from the popPK convention: 'Half-life is measured in time. The value 22.7 is consistent with a terminal elimination half-life in hours for epirubici')</li><li>implicit units: 'Median Vd' → L (from the popPK convention: 'Volume of distribution (Vd) is a volume. The value 1602 is consistent with the large volume of distribution for anthracy')</li><li>implicit units: 'Median MRT' → h (from the popPK convention: 'Mean Residence Time (MRT) is a time parameter. The value 24.4 is consistent with hours, aligning with the terminal half-')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Epirubicin</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>population split: 'group 1' subgroup of Twelves_1992 (paper reports 3 populations: group 1, group 2, group 3)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Twelves1992_group_1;
