model Epirubicin_Twelves1992_group_3
  parameter Real Cl_ref = 3.3888888888888884e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.302 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435249999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>women with advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Twelves_1992</td></tr><tr><td>measured_compound:</td><td>Epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.525 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'Median clearance' → L/h (from the popPK convention: 'The paper does not state the unit for clearance. In population pharmacokinetics, total clearance is conventionally repor')</li><li>implicit units: 'Median α-t½' → h (from the popPK convention: 'The paper does not state the unit for half-life. Half-lives are conventionally reported in hours (h) in PK studies. The ')</li><li>implicit units: 'Median β-t½' → h (from the popPK convention: 'The paper does not state the unit for half-life. Half-lives are conventionally reported in hours (h). The value 0.33 h (')</li><li>implicit units: 'Median γ-t½' → h (from the popPK convention: 'The paper does not state the unit for half-life. Half-lives are conventionally reported in hours (h). The value 49.8 h i')</li><li>implicit units: 'Median Vd' → L (from the popPK convention: 'The paper does not state the unit for volume of distribution. Vd is conventionally reported in Liters (L). The value 130')</li><li>implicit units: 'Median MRT' → h (from the popPK convention: 'The paper does not state the unit for MRT. Mean Residence Time is conventionally reported in hours (h) when derived from')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Epirubicin</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>population split: 'group 3' subgroup of Twelves_1992 (paper reports 3 populations: group 1, group 2, group 3)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Twelves1992_group_3;
