function p = Busulfan_Choi2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: busulfan   source: Choi_2026 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Busulfan_Choi2026_reference_params';
  p.drug  = 'busulfan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 33.5;                % central volume [L]
  p.CL = 62.25;                % clearance [L/h]
  p.Vp = [18.425];             % peripheral volumes [L]
  p.Q  = [14.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
