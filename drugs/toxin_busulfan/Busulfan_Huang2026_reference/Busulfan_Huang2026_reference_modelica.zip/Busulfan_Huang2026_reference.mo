model Busulfan_Huang2026_reference
  parameter Real Cl_ref = 3e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016100000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Huang_2026</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Ffat_CL' — extend the ontology if this is a real PK parameter (source ['t0001:row3:col1', 't0001:row3:col2', 't0001:row3:col3', 't0001:row3:col4'])</li><li>dropped unlinked row (NIL): 'Ffat_V' — extend the ontology if this is a real PK parameter (source ['t0001:row4:col1', 't0001:row4:col2', 't0001:row4:col3', 't0001:row4:col4'])</li><li>dropped duplicate Q354 ('FGSTA1_CL', value '0.863') — already have one for this compound</li><li>dropped unlinked row (NIL): 'TM50' — extend the ontology if this is a real PK parameter (source ['t0001:row6:col1', 't0001:row6:col2', 't0001:row6:col3', 't0001:row6:col4'])</li><li>dropped PD-category row 'HILL' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0001:row7:col1', 't0001:row7:col2', 't0001:row7:col3', 't0001:row7:col4'])</li><li>dropped value-less row: 'Clearance (CL_STD)' (captured trailing unit 'CL_STD' for child rows)</li><li>dropped value-less row: 'distribution volume (V_STD)' (captured trailing unit 'V_STD' for child rows)</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 56.1 (source ['t0001:footnote', 't0001:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q22 ('CL and V values for Bu'=10.8) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Alsultan_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Alsultan_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Huang2026_reference;
