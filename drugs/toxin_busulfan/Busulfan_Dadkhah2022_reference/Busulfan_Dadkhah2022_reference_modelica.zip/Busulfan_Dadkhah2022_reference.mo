// parent + metabolites (Sulfolane): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Busulfan_Dadkhah2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0615,
    q1_m11 = 3.187555555555556e-07,
    CL1 = 4.209022222222223e-06,
    Vd1m1 = 0.048799999999999996,
    CLm1 = 4.4722222222222223e-07,
    MW = 0.246292,
    MW_m1 = 0.120166,
    F = 1,
    adminMass = 0,
    infusionMass = 5.6e-05,
    infusionDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>Patients with myelofibrosis undergoing hematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>Dadkhah_2022</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-01145-t002</td></tr><tr><td>input:</td><td>PK_3M_9C: IV / parenteral into the parent central compartment; formation of Sulfolane: fm=0.0704 × CL; dose 56 mg (paper)</td></tr><tr><td>molar_masses:</td><td>Busulfan 246.292 g/mol (pubchem); Sulfolane 120.166 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>linked 'VBu [L]' as 'Vc' → Q63 (V1) for  — compound marker removed</li><li>dropped unlinked row (NIL): 'COV_VBu_TBW [kg]' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-01145-t002:row7:col1'])</li><li>dropped unlinked row (NIL): 'COV_CLSu_GSTA1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-01145-t002:row8:col1'])</li><li>routed 'Prop. σBu [CV%]' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'Prop. σSu [CV%]' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>metabolite volume: 'VSu [L]' Q63→Q61 for Sulfolane — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>topology: 1 first-order transfer(s) across 2 compounds → general_linear</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [1]</li><li>model equation 'VBu = VBu-typ * (BW/70)^0.75' not bound — neither LHS nor base term 'VBu' linked to an ontology parameter</li><li>model equation 'CLSu = CLSu-typ * (PNA/6.8)^θPNA' not bound — neither LHS nor base term 'CLSu' linked to an ontology parameter</li><li>row roles (LLM): model_class=compartmental; 14/14 row label(s) assigned, 5 linked by role; re-tagged parent→Sulfolane ×7</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Dadkhah2022_reference;
