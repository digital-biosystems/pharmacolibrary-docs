function p = Busulfan_Dadkhah2022_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: busulfan   source: Dadkhah_2022 / reference   PK_3M_9C parent + 1 metabolite(s), 2 compartments, IV bolus
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=246.292 g/mol C_M1=120.166 g/mol
  p.name  = 'Busulfan_Dadkhah2022_reference_params';
  p.drug  = 'busulfan';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1'};
  p.V = [61.5, 48.8];          % compartment volumes [L]
  p.K = [-0.2650406504065041, 0.0;
         0.009103668757779617, -0.03299180327868853];
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;
  p.dose_into = 1;   % central
  p.ka = 60.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 56.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'Busulfan', 'Sulfolane'};
end
