model Busulfan_Alsultan2022_base
  parameter Real Cl_ref = 1.3277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01517 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 5.6e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>Pediatric patients undergoing hematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>Alsultan_2022</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'V' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>model-stage split: 'base model' is the base model of Alsultan_2022 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C1_half_life_beta failed (ratio 0.6471))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Alsultan2022_base;
