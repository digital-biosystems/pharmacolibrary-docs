// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Busulfan_Bae2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {61765.59034692582},
    MM = 0.246292,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>pediatric and young adult patients</td></tr><tr><td>source_paper:</td><td>Bae_2026</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>cpt70337-tbl-0003</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV for V (%)' routed out of structural estimates ('Inter‐individual variability (IIV)')</li><li>table section iiv: 'IIV for CL (%)' routed out of structural estimates ('Inter‐individual variability (IIV)')</li><li>table section iiv: 'Correlation between IIV on CL and V' routed out of structural estimates ('Inter‐individual variability (IIV)')</li><li>table section residual_error: 'Proportional residual error' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'θ4; Age reaching 50% of adult maturation' — extend the ontology if this is a real PK parameter (source ['cpt70337-tbl-0003:row8:col1'])</li><li>relinked 'K ENZ; Enzyme turnover rate (h−1)' Q100 → Q47: a rate constant in 'h−1' (the unit decides, not the label)</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['cpt70337-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['cpt70337-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>dropped value-less row: 'RSE'</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>bound model equation to Q61 (V): V = θ * BW^0.75 * (PNA/6.8)^θPNA</li><li>bound model equation to Q22 (CL): CL = θ * BW^0.75 * (PNA/6.8)^θPNA</li><li>Q61 (V) is equation-defined: value moved to equation-variable 'θ1; typical V value with BSA 1.73 m2'; equation kept verbatim</li><li>Q22 (CL) is equation-defined: value moved to equation-variable 'CL'; equation kept verbatim</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Busulfan_Bae2026_reference;
