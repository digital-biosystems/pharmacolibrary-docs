model Busulfan_Neroutsos2022_reference
  parameter Real Cl_ref = 2.972222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0395 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 5.6e-05,
    k12 = 3.2911392405063295e-05,
    k21 = 7.428571428571429e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>paediatric patients undergoing bone marrow transplantation</td></tr><tr><td>source_paper:</td><td>Neroutsos_2022</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00647-t003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'RE' routed out of structural estimates ('* RE = residual error.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Neroutsos2022_reference;
