function p = Busulfan_Neroutsos2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: busulfan   source: Neroutsos_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Busulfan_Neroutsos2022_reference_params';
  p.drug  = 'busulfan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 39.5;                % central volume [L]
  p.CL = 10.7;                % clearance [L/h]
  p.Vp = [17.5];             % peripheral volumes [L]
  p.Q  = [4.68];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 56.0;             % dose [mg]
end
