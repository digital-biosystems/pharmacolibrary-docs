model Busulfan_Zhang2026_46
  parameter Real Cl_ref = 8.88888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016100000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 7.7e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>pediatric hematopoietic stem cell transplantation recipients</td></tr><tr><td>source_paper:</td><td>Zhang_2026</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-01154-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Age (Years)' — extend the ontology if this is a real PK parameter (source ['Zhang_2026_table_2:row16:col2'])</li><li>dropped unlinked row (NIL): 'Weight (kg)' — extend the ontology if this is a real PK parameter (source ['Zhang_2026_table_2:row16:col3'])</li><li>dropped unlinked row (NIL): 'TDM Schedule (Dose No.)' — extend the ontology if this is a real PK parameter (source ['Zhang_2026_table_2:row16:col5'])</li><li>dropped unlinked row (NIL): 'Sampling Time (h)' — extend the ontology if this is a real PK parameter (source ['Zhang_2026_table_2:row16:col6'])</li><li>table mostly unlinked (4/4 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q57 ('elimination half-life of Bu'=2) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('posterior clearance'=3.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: '[46]' subgroup of Zhang_2026 (paper reports 15 populations: [31], [32], [33], [34], [35], [36], [37], [38], [39], [41], [42], [44], [45], [46], [47])</li><li>gap-filled Q61 (V) from Alsultan_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Alsultan_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Zhang2026_46;
