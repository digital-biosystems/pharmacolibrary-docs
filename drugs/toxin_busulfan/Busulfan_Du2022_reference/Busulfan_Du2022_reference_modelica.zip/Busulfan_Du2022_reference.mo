model Busulfan_Du2022_reference
  parameter Real Cl_ref = 2.1416666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0424 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 5.6e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>Chinese pediatric patients undergoing hematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>Du_2022</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL_STD (L h−1)'; source reconciliation required</li><li>table representations disagree for 'V_STD (L)'; source reconciliation required</li><li>table representations disagree for 'RUV_PROP'; source reconciliation required</li><li>table representations disagree for 'RUV_ADD (mg L−1)'; source reconciliation required</li><li>table representations disagree for 'Ffat_CL'; source reconciliation required</li><li>table representations disagree for 'TM50 (weeks)'; source reconciliation required</li><li>table representations disagree for 'HILL'; source reconciliation required</li><li>table representations disagree for 'BSV_CL'; source reconciliation required</li><li>table representations disagree for 'BSV_V'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Ffat_CL' — extend the ontology if this is a real PK parameter (source ['T2:row5:col1', 'T2:row5:col2', 'T2:row5:col3', 'T2:row5:col4', 'T2:footnote'])</li><li>dropped PD-category row 'TM50 (weeks)' → Q340 (alpha_progression, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row6:col1', 'T2:row6:col2', 'T2:row6:col3', 'T2:row6:col4'])</li><li>dropped PD-category row 'HILL' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row7:col1', 'T2:row7:col2', 'T2:row7:col3', 'T2:row7:col4', 'T2:footnote'])</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'Clearance (CL_STD)' (captured trailing unit 'CL_STD' for child rows)</li><li>dropped value-less row: 'distribution volume (V_STD)' (captured trailing unit 'V_STD' for child rows)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Du2022_reference;
