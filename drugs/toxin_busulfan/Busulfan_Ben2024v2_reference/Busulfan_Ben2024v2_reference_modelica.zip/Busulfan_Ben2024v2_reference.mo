// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Busulfan_Ben2024v2_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {9000.0},
    MM = 0.246292,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>Pediatric patients undergoing hematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>Ben_2024_2</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iov: 'IIV CL (%)' routed out of structural estimates ('Updated parameters without IOV')</li><li>table section iov: 'IIV V1 (%)' routed out of structural estimates ('Updated parameters without IOV')</li><li>table section iov: 'IIV Q (%)' routed out of structural estimates ('Updated parameters without IOV')</li><li>table section iov: 'IIV V2 (%)' routed out of structural estimates ('Updated parameters without IOV')</li><li>table section iov: 'Proportional residual error (%)' routed out of structural estimates ('Updated parameters without IOV')</li><li>dropped unlinked row (NIL): 'Original model' — extend the ontology if this is a real PK parameter (source ['T1:row2:col1', 'T1:row2:col2', 'T1:row2:col3', 'T1:row2:col4', 'T1:row2:col5', 'T1:row2:col6'])</li><li>dropped unlinked row (NIL): 'Shukla et al' — extend the ontology if this is a real PK parameter (source ['T1:row5:col1', 'T1:row5:col2', 'T1:row5:col3', 'T1:row5:col4', 'T1:row5:col5', 'T1:row5:col6'])</li><li>salvaged Q57 ('Bu elimination half-life'=2.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Alsultan_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Alsultan_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Busulfan_Ben2024v2_reference;
