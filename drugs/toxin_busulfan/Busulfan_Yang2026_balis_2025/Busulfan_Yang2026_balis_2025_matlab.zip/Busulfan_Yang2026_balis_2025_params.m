function p = Busulfan_Yang2026_balis_2025_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: busulfan   source: Yang_2026 / balis_2025   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Busulfan_Yang2026_balis_2025_params';
  p.drug  = 'busulfan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 46.76;                % central volume [L]
  p.CL = 14.35;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 224.0;             % dose [mg]
end
