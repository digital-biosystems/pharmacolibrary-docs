model Busulfan_Ben2024_reference
  parameter Real Cl_ref = 3.858333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0298 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 5.6e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>Adult patients undergoing myeloablative conditioning for HSCT</td></tr><tr><td>source_paper:</td><td>Ben_2024</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'proportional' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'proportional' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'tvVp in Vp = tvVp £ Vc' — extend the ontology if this is a real PK parameter (source ['tab_1:row5:col1', 'tab_1:row5:col3'])</li><li>routed 'CL-Vc correlation' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'tv'</li><li>dropped value-less row: 'Vc'</li><li>dropped value-less row: 'Vp'</li><li>implicit units: 'tvCL in CL = tvCL £ (ABW/70) 0.75' → L/h (from the popPK convention: 'The parameter is total clearance (CL). The paper states the target exposure AUC is in mg.h/L and concentrations are mg/L')</li><li>implicit units: 'tvVc in Vc = tvVc £ ABW/70' → L (from the popPK convention: 'The parameter is volume of distribution of the central compartment (Vc). The paper reports AUC in mg.h/L and concentrati')</li><li>implicit units: 'tvQ in Q = tvQ £ (ABW/70) 0.75' → L/h (from the popPK convention: 'The parameter is intercompartmental clearance (Q). As a clearance parameter analogous to CL, it is typically expressed i')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'tvVc in Vc = tvVc £ ABW/70' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Ben2024_reference;
