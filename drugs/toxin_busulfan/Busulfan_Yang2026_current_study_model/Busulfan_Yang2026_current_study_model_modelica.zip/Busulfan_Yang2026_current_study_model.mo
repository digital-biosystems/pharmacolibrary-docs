model Busulfan_Yang2026_current_study_model
  parameter Real Cl_ref = 3.874999999999999e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.047920000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.246292,
    adminMass = 0.000224
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>busulfan</td></tr><tr><td>population:</td><td>Paediatric patients undergoing haematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>Yang_2026</td></tr><tr><td>measured_compound:</td><td>Busulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>busulfan 246.292 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'WT'</li><li>NIL: refused to back-fill base 'IIV' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Busulfan</li><li>population split: 'current study model' subgroup of Yang_2026 (paper reports 3 populations: balis 2025, current study model, estimate (rse%))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Busulfan_Yang2026_current_study_model;
