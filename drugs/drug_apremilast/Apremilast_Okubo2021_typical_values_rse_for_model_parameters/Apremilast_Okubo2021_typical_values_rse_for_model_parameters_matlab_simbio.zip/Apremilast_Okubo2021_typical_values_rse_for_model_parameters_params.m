function p = Apremilast_Okubo2021_typical_values_rse_for_model_parameters_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: apremilast   source: Okubo_2021 / typical_values_rse_for_model_parameters_and_covariate_effects   route: oral
  p.name  = 'Apremilast_Okubo2021_typical_values_rse_for_model_parameters_params';
  p.drug  = 'apremilast';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 115.0;                % central volume [L]
  p.CL = 9.25;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.83;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.29;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
