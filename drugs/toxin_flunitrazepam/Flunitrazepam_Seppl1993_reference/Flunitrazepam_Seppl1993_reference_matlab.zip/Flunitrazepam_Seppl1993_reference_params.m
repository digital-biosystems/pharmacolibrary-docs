function p = Flunitrazepam_Seppl1993_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flunitrazepam   source: Seppälä_1993 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Flunitrazepam_Seppl1993_reference_params';
  p.drug  = 'flunitrazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 300.0;                % central volume [L]
  p.CL = 385.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.372;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
