model Flunitrazepam_Boxenbaum1978_reference
  parameter Real Cl_ref = 0.00010694444444444445 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.313288,
    adminMass = 1e-06,
    ka = 0.00010333333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flunitrazepam</td></tr><tr><td>population:</td><td>healthy human subjects</td></tr><tr><td>source_paper:</td><td>Boxenbaum_1978</td></tr><tr><td>measured_compound:</td><td>Flunitrazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>flunitrazepam 313.288 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate weight for t1/2z from footnote/prose kept as documentation only (['Boxenbaum_1978:abstract'])</li><li>covariate weight for t1/2z from footnote/prose kept as documentation only (['Boxenbaum_1978:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flunitrazepam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Adachi_2021's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Vikingsson_2017's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Adachi_2021's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Adachi_2021, Vikingsson_2017 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flunitrazepam_Boxenbaum1978_reference;
