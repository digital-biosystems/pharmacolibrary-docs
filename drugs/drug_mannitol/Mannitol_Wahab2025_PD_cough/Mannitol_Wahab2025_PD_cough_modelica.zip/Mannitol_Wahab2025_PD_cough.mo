model Mannitol_Wahab2025_PD_cough
  "emax exposure-response sweep — Wahab_2025 :: cough (cough)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -11.22,  // [coughs]
    EC50 = 0.00011376,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1200, Interval = 2.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mannitol</h4><p>Mannitol is an osmotic diuretic used for conditions such as anuria, oliguria, cerebral edema, and ocular hypertension, and is also used as a laxative, irrigating solution, mucolytic in cystic fibrosis, and diagnostic agent. It remains widely used and is included on the WHO essential medicines list, with an authorised product in the European Union for cystic fibrosis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407646\">Wikidata Q407646</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Mannitol_Wahab2025_PD_cough</h4><p>The steady-state exposure-response curve of Wahab M et al., <i>ERJ open research 11(2)</i> 2025 (<a href=\"https://doi.org/10.1183/23120541.00815-2024\">doi:10.1183/23120541.00815-2024</a>) — cough [coughs] against mannitol mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      11.22 coughs   maximal effect term (Emax, Q323)
  EC50  =     113.76 mg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of mannitol per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (113.76 mg)  response -5.61
  exposure -> infinity  response -11.22</pre></body></html>"));
end Mannitol_Wahab2025_PD_cough;
