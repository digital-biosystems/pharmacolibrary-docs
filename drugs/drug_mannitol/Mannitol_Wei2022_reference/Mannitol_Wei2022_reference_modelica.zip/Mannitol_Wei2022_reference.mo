model Mannitol_Wei2022_reference
  parameter Real Cl_ref = 2.216666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.060200000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1821718,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mannitol</h4><p>Mannitol is an osmotic diuretic used for conditions such as anuria, oliguria, cerebral edema, and ocular hypertension, and is also used as a laxative, irrigating solution, mucolytic in cystic fibrosis, and diagnostic agent. It remains widely used and is included on the WHO essential medicines list, with an authorised product in the European Union for cystic fibrosis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407646\">Wikidata Q407646</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mannitol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wei_2022</td></tr><tr><td>measured_compound:</td><td>mannitol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mannitol 182.172 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wei_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Mannitol_Wei2022_reference;
