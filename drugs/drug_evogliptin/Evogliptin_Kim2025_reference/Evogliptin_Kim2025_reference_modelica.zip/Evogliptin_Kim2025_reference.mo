model Evogliptin_Kim2025_reference
  parameter Real Cl_ref = 6.138888888888889e-06 "Cl [m3/s]";
  parameter Real cov_wt = 1.0 "wt covariate (reference 1.0)";
  parameter Real Vd_ref = 0.8290000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_wt/1.0)^(0.75),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40143,
    adminMass = 5e-06,
    ka = 0.00035,
    Tlag = 0.0,
    k12 = 1.551400616539338e-05,
    k21 = 2.7658303464755076e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About evogliptin</h4><p>Evogliptin is a DPP-4 inhibitor studied for lowering blood glucose in diabetes. It is considered investigational and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25103700\">Wikidata Q25103700</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>evogliptin</td></tr><tr><td>population:</td><td>patients with varying degrees of renal disease and healthy subjects</td></tr><tr><td>source_paper:</td><td>Kim_2025</td></tr><tr><td>measured_compound:</td><td>evogliptin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413263-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>evogliptin 401.43 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'CL/F (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'Vc/F (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'Vc/F (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'Ka (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'Ka (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'F1 (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'F1 (%)' routed out of structural estimates ('PK IIV')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('PK residual variability')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('PK residual variability')</li><li>table section iiv: 'EC50 (%)' routed out of structural estimates ('PD IIV')</li><li>table section iiv: 'EC50 (%)' routed out of structural estimates ('PD IIV')</li><li>table section residual_error: 'Additive error (%inhibition)e' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error (%inhibition)e' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Amyl~F1' — extend the ontology if this is a real PK parameter (source ['psp413263-tbl-0001:row13:col1', 'psp413263-tbl-0001:row13:col2'])</li><li>dropped unlinked row (NIL): 'TG ~ F1' — extend the ontology if this is a real PK parameter (source ['psp413263-tbl-0001:row14:col1', 'psp413263-tbl-0001:row14:col2'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Evogliptin_Kim2025_reference;
