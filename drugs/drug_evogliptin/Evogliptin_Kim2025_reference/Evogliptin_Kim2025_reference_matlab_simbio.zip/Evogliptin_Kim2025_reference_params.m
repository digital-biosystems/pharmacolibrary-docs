function p = Evogliptin_Kim2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: evogliptin   source: Kim_2025 / reference   route: oral
  p.name  = 'Evogliptin_Kim2025_reference_params';
  p.drug  = 'evogliptin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 829.0;                % central volume [L]
  p.CL = 22.1;                % clearance [L/h]
  p.Vp = [465.0];             % peripheral volumes [L]
  p.Q  = [46.3];             % inter-compartmental clearances [L/h]
  p.ka = 1.26;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
