function p = Epinephrine_Yoo2015_PD_se_perf_params()
% Epinephrine_Yoo2015_PD_se_perf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% epinephrine Yoo_2015::SE_Perf: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response SE_Perf in mm. Driver: norepinephrine (conc_no_pk).
p.E0 = 7.1;
p.Emax = -86.8;
p.EC50 = 3.2999999999999997e-06;
p.gamma = 4.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 33.0;
p.form = 'E0 + Emax*frac';
end
