function p = Epinephrine_Yoo2015_PD_se_drug_params()
% Epinephrine_Yoo2015_PD_se_drug_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% epinephrine Yoo_2015::SE_Drug: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response SE_Drug in mm. Driver: norepinephrine (conc_no_pk).
p.E0 = 20.7;
p.Emax = -78.5;
p.EC50 = 3.5e-06;
p.gamma = 4.1;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 35.0;
p.form = 'E0 + Emax*frac';
end
