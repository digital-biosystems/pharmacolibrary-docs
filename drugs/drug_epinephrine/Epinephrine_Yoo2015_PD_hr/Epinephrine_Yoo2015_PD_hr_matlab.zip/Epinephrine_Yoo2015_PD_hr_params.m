function p = Epinephrine_Yoo2015_PD_hr_params()
% Epinephrine_Yoo2015_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% epinephrine Yoo_2015::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response HR in beats/min. Driver: norepinephrine (conc_no_pk).
p.E0 = 50.5;
p.Emax = 191.0;
p.EC50 = 3.06e-05;
p.gamma = 1.7;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 310.0;
p.form = 'E0 + Emax*frac';
end
