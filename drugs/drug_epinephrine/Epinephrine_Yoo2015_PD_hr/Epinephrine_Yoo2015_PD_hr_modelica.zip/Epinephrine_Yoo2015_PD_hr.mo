model Epinephrine_Yoo2015_PD_hr
  "sigmoid_emax exposure-response sweep — Yoo_2015 :: HR (Heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 50.5,      // [beats/min]
    Emax = 191,  // [beats/min]
    EC50 = 3.06e-05,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1.7,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  annotation(experiment(StartTime = 0, StopTime = 310, Interval = 0.62),
    Documentation(info = "<html><body><!-- drug-about --><h4>About epinephrine</h4><p>Epinephrine (adrenaline) is used for emergencies and conditions such as anaphylaxis, cardiac arrest, severe low blood pressure, airway obstruction, and glaucoma. It is widely used in human medicine and also approved for veterinary use, with an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q132621\">Wikidata Q132621</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Epinephrine_Yoo2015_PD_hr</h4><p>The steady-state exposure-response curve of Yoo H et al., <i>European journal of clinical pharmacology 71(10):1197–1207</i> 2015 (<a href=\"https://doi.org/10.1007/s00228-015-1913-0\">doi:10.1007/s00228-015-1913-0</a>) — Heart rate [beats/min] against norepinephrine nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       50.5 beats/min drug-free response (baseline) (Emin, Q324)
  Emax  =        191 beats/min maximal effect term (Emax, Q320)
  EC50  =       30.6 nmol/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.7          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of norepinephrine per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 50.5   (drug-free)
  exposure = EC50 (30.6 nmol/L)  response 146
  exposure -> infinity  response 241.5</pre></body></html>"));
end Epinephrine_Yoo2015_PD_hr;
