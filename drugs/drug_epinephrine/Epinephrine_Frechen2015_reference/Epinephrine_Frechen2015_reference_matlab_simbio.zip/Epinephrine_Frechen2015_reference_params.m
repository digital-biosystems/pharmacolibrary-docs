function p = Epinephrine_Frechen2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: epinephrine   source: Frechen_2015 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Epinephrine_Frechen2015_reference_params';
  p.drug  = 'epinephrine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 410.4;                % central volume [L]
  p.CL = 0.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.92;                % absorption rate [1/h]
  p.F  = 4.7;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
