// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model CaprylicAcid_Nahab2011_cel
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {27018.0},
    MM = 0.13023099999999999,
    adminMass = 7e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>caprylic_acid</td></tr><tr><td>population:</td><td>patients with essential tremor</td></tr><tr><td>source_paper:</td><td>Nahab_2011</td></tr><tr><td>measured_compound:</td><td>1-octanol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>1-octanol 130.231 g/mol (pubchem); caprylic_acid 144.214 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'C max (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'T max (min)'; source reconciliation required</li><li>table representations disagree for 'AUC 6h (ng min/mL)'; source reconciliation required</li><li>table representations disagree for 'λ z (1/min)'; source reconciliation required</li><li>table representations disagree for 'T 1/2 (min)'; source reconciliation required</li><li>table representations disagree for 'AUC ∞ (ng min/mL)'; source reconciliation required</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1-octanol</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'cel' subgroup of Nahab_2011 (paper reports 2 populations: cel, soy)</li><li>review gap-fill skipped: this record measures '1-octanol', not caprylic_acid — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 273.6));
end CaprylicAcid_Nahab2011_cel;
