model Benzatropine_Raje2003_reference
  parameter Real Cl_ref = 2.4755256448569475e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.063 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>benzatropine</td></tr><tr><td>population:</td><td>Male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Raje_2003</td></tr><tr><td>measured_compound:</td><td>Benztropine analogs (AHN 2-003, AHN 1-055, AHN 2-005, JHW 007) and Cocaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>benzatropine 307.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Benztropine analogs (AHN 2-003, AHN 1-055, AHN 2-005, JHW 007) and Cocaine</li><li>molar mass: none found for 'Benztropine analogs (AHN 2-003, AHN 1-055, AHN 2-005, JHW 007) and Cocaine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>derived CL=89.1189 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Benzatropine_Raje2003_reference;
