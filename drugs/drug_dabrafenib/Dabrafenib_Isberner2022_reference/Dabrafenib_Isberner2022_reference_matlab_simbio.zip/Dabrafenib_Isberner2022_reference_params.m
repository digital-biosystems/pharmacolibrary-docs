function p = Dabrafenib_Isberner2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dabrafenib   source: Isberner_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Dabrafenib_Isberner2022_reference_params';
  p.drug  = 'dabrafenib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 30.8;                % central volume [L]
  p.CL = 13.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
