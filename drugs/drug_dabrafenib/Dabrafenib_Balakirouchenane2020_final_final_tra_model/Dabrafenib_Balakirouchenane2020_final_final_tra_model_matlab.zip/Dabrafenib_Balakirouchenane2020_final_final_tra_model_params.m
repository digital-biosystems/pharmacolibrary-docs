function p = Dabrafenib_Balakirouchenane2020_final_final_tra_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dabrafenib   source: Balakirouchenane_2020 / final_final_tra_model   route: oral
  % estimated (absent from source): dose
  p.name  = 'Dabrafenib_Balakirouchenane2020_final_final_tra_model_params';
  p.drug  = 'dabrafenib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 61.9;                % central volume [L]
  p.CL = 5.83;                % clearance [L/h]
  p.Vp = [417.0];             % peripheral volumes [L]
  p.Q  = [64.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.913;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
