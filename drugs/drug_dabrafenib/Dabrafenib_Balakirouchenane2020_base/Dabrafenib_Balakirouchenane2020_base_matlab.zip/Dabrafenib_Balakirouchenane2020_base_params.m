function p = Dabrafenib_Balakirouchenane2020_base_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: dabrafenib   source: Balakirouchenane_2020 / base   PK_3M_9C parent + 1 metabolite(s), 4 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=519.562 g/mol C_M1=535.559 g/mol
  p.name  = 'Dabrafenib_Balakirouchenane2020_base_params';
  p.drug  = 'dabrafenib';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'central_M1', 'peripheral_M1'};
  p.V = [39.5, 5.23, 19.6, 25.7];          % compartment volumes [L]
  p.K = [-0.5455696202531646, 0.7361376673040153, 0.0, 0.0;
         0.09746835443037975, -0.7361376673040153, 0.0, 0.0;
         0.4618980330023844, 0.0, -1.5403061224489796, 0.2875486381322957;
         0.0, 0.0, 0.3770408163265306, -0.2875486381322957];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 1.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h] (in dose_start)
  p.dose = 100.0;             % dose [mg]
  p.dose_start = 0.5166666666666667;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'dabrafenib', 'hydroxy-dabrafenib'};
end
