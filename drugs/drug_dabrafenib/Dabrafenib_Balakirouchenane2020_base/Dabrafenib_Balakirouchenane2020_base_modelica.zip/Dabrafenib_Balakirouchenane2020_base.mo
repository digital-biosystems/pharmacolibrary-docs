// parent + metabolites (hydroxy-dabrafenib): PK_3M_9C — formed from central; parent 2, metabolites [2]
model Dabrafenib_Balakirouchenane2020_base
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0395,
    Vd2 = 0.00523,
    q12 = 1.0694444444444445e-06,
    q21 = 1.0694444444444445e-06,
    q1_m11 = 4.9166666666666665e-06,
    CL1 = 0.0,
    Vd1m1 = 0.019600000000000003,
    CLm1 = 6.333333333333333e-06,
    Vd2m1 = 0.0257,
    qm11_m12 = 2.0527777777777777e-06,
    qm12_m11 = 2.0527777777777777e-06,
    MW = 0.519562,
    MW_m1 = 0.535559,
    F = 1,
    ka = 0.0005,
    Tlag = 1800.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dabrafenib</td></tr><tr><td>population:</td><td>adults with BRAF-mutated metastatic melanoma</td></tr><tr><td>source_paper:</td><td>Balakirouchenane_2020</td></tr><tr><td>measured_compound:</td><td>dabrafenib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cancers-12-00931-t003</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of hydroxy-dabrafenib: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it</td></tr><tr><td>molar_masses:</td><td>dabrafenib 519.562 g/mol (drugbank); hydroxy-dabrafenib 535.559 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'ka (1/h)' → 1/h (from the paper text: &quot;The parameter list provided in the prompt explicitly includes the unit in parentheses: 'ka (1/h) = 1.8'. Additionally, t&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dabrafenib</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [2]</li><li>model-stage split: 'base dab/ohd model' is the base model of Balakirouchenane_2020 (paper reports 3 stages: base dab/ohd model, final dab/ohd model, final tra model); same population, different model-building step</li><li>row roles (LLM): model_class=compartmental; 24/24 row label(s) assigned, 84 linked by role; re-tagged trametinib→parent ×105, trametinib→hydroxy-dabrafenib ×39</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dabrafenib_Balakirouchenane2020_base;
