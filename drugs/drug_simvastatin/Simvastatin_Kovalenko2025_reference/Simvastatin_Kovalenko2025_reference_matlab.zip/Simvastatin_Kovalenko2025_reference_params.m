function p = Simvastatin_Kovalenko2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Kovalenko_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Simvastatin_Kovalenko2025_reference_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.64;                % central volume [L]
  p.CL = 0.005458;                % clearance [L/h]
  p.Vp = [1.14];             % peripheral volumes [L]
  p.Q  = [0.01325];             % inter-compartmental clearances [L/h]
  p.ka = 0.013875;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
