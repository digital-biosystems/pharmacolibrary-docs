function p = Simvastatin_Lohitnavy2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Lohitnavy_2015 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Simvastatin_Lohitnavy2015_reference_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 228.0;                % central volume [L]
  p.CL = 12.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.212;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
