model Simvastatin_Kim2021_reference
  parameter Real Cl_ref = 8.11111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.056 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0005083333333333334,
    Tlag = 0.0,
    k12 = 1.9255050505050504e-05,
    k21 = 1.916431039899466e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>simvastatin</td></tr><tr><td>population:</td><td>beagle dogs</td></tr><tr><td>source_paper:</td><td>Kim_2021</td></tr><tr><td>measured_compound:</td><td>simvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CovCL/F-Vc/F (CV%)' — extend the ontology if this is a real PK parameter (source ['Kim_2021_table_p4_2:row11:col1', 'Kim_2021_table_p4_2:row11:col2', 'Kim_2021_table_p4_2:row11:col4', 'Kim_2021_table_p4_2:row11:col5'])</li><li>dropped unlinked row (NIL): 'Proportional (%)' — extend the ontology if this is a real PK parameter (source ['Kim_2021_table_p4_2:row13:col1', 'Kim_2021_table_p4_2:row13:col2', 'Kim_2021_table_p4_2:row13:col3', 'Kim_2021_table_p4_2:row13:col4', 'Kim_2021_table_p4_2:row13:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=simvastatin</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Simvastatin_Kim2021_reference;
