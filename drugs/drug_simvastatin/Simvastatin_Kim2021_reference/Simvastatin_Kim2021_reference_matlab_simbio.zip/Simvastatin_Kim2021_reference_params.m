function p = Simvastatin_Kim2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Kim_2021 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Simvastatin_Kim2021_reference_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1056.0;                % central volume [L]
  p.CL = 292.0;                % clearance [L/h]
  p.Vp = [1061.0];             % peripheral volumes [L]
  p.Q  = [73.2];             % inter-compartmental clearances [L/h]
  p.ka = 1.83;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
