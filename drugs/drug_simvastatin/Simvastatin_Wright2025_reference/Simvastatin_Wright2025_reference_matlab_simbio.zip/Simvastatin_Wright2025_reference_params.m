function p = Simvastatin_Wright2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Wright_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Simvastatin_Wright2025_reference_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17185.0;                % central volume [L]
  p.CL = 4.86;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
