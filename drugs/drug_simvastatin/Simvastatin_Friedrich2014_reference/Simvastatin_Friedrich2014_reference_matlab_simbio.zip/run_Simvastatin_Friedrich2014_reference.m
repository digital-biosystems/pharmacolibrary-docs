% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Simvastatin_Friedrich2014_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
