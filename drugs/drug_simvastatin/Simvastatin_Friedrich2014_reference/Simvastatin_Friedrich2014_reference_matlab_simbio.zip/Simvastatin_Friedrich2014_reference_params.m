function p = Simvastatin_Friedrich2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Friedrich_2014 / reference   route: oral
  p.name  = 'Simvastatin_Friedrich2014_reference_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 228.0;                % central volume [L]
  p.CL = 15.3;                % clearance [L/h]
  p.Vp = [827.0];             % peripheral volumes [L]
  p.Q  = [9.79];             % inter-compartmental clearances [L/h]
  p.ka = 0.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
