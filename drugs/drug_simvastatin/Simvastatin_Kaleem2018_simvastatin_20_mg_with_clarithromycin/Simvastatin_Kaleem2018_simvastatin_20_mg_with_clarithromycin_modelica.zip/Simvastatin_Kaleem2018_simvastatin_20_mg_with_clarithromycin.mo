model Simvastatin_Kaleem2018_simvastatin_20_mg_with_clarithromycin
  parameter Real Cl_ref = 0.00019027166666666666 "Cl [m3/s]";
  parameter Real Vd_ref = 1.4574 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4185662,
    adminMass = 2e-05,
    ka = 0.00013055555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About simvastatin</h4><p>Simvastatin is a statin used to lower blood lipids in conditions such as hyperlipidemia, hypertriglyceridemia, arteriosclerosis and coronary artery disease. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q670131\">Wikidata Q670131</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>simvastatin</td></tr><tr><td>population:</td><td>healthy adult male subjects</td></tr><tr><td>source_paper:</td><td>Kaleem_2018</td></tr><tr><td>measured_compound:</td><td>simvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>simvastatin 418.566 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>conflicting source units for 'AUC (0-10)': [{'unit': 'ng hr mL -1', 'source': 'tab_1:row10:col1', 'scope': 'unit_column'}, {'unit': '0-10', 'source': 'tab_1:row10:col0', 'scope': 'label'}]</li><li>dropped unlinked row (NIL): 'B' — extend the ontology if this is a real PK parameter (source ['tab_1:row5:col3'])</li><li>unit_dimension_unknown: 'L hr -1 kg -1' (CLb)</li><li>implicit units: 'Cl B' → L/h (from the popPK convention: 'The paper states plasma concentrations in ng/mL but does not explicitly state the unit for CLb (Total body clearance) in')</li><li>implicit units: 'AUC (0-10)' → ng.h/mL (from the paper text: &quot;The abstract and results section explicitly state: 'The mean area under the curve of simvastatin concentration versus ti&quot;)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (V d)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=simvastatin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: 'simvastatin 20 mg with clarithromycin 250 mg' subgroup of Kaleem_2018 (paper reports 2 populations: simvastatin 20 mg alone, simvastatin 20 mg with clarithromycin 250 mg)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=684.978 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Simvastatin_Kaleem2018_simvastatin_20_mg_with_clarithromycin;
