% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Simvastatin_Kaleem2018_simvastatin_20_mg_with_clarithromycin_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
