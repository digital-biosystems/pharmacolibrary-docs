function p = Simvastatin_Kaleem2018_simvastatin_20_mg_with_clarithromycin_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: simvastatin   source: Kaleem_2018 / simvastatin_20_mg_with_clarithromycin_250_mg   route: oral
  % estimated (absent from source): F
  p.name  = 'Simvastatin_Kaleem2018_simvastatin_20_mg_with_clarithromycin_params';
  p.drug  = 'simvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1457.4;                % central volume [L]
  p.CL = 10.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.47;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
