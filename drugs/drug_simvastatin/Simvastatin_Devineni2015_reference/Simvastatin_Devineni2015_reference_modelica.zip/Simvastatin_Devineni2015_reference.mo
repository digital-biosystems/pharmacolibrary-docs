model Simvastatin_Devineni2015_reference
  parameter Real Cl_ref = 3.3888888888888884e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.18656932268776075 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>simvastatin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Devineni_2015</td></tr><tr><td>measured_compound:</td><td>simvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Devineni_2015) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Simvastatin_Devineni2015_reference;
