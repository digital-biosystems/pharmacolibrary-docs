model Simvastatin_Wei2014_PD_ldl_c
  "emax exposure-response sweep — Wei_2014 :: LDL-C (LDL-C)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.61,  // [kg/m3; mg/dl × 0.01]
    EC50 = 8.56481481481e-11,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 74, Interval = 0.148),
    Documentation(info = "<html><body><h4>Simvastatin_Wei2014_PD_ldl_c</h4><p>The steady-state exposure-response curve of Wei WQ et al., <i>Clinical pharmacology and therapeutics 95(3):331–338</i> 2014 (<a href=\"https://doi.org/10.1038/clpt.2013.202\">doi:10.1038/clpt.2013.202</a>) — LDL-C [mg/dl] against simvastatin mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         61 mg/dl    maximal effect term (E max, Q320)
  EC50  =        7.4 mg/day   exposure at half of the maximal effect term (ED 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of simvastatin per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.4 mg/day)  response -0.305
  exposure -> infinity  response -0.61</pre></body></html>"));
end Simvastatin_Wei2014_PD_ldl_c;
