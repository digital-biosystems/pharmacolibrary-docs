model SilverSulfide_Hsu2019_reference
  parameter Real Cl_ref = 1.0833333333333333e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24780000000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>silver_sulfide</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Hsu_2019</td></tr><tr><td>measured_compound:</td><td>Silver sulfide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Silver sulfide 247.8 g/mol (pubchem); silver_sulfide 139.94 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Size' — extend the ontology if this is a real PK parameter (source ['Hsu_2019:abstract'])</li><li>unit_dimension_unknown: 'ID' (Ae )</li><li>implicit units: 'Excretion within 24 hours of intravenous injection' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Silver sulfide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Bahri_2023's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kian_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bahri_2023, Kian_2026 — borrowed values do not complete its disposition core; C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end SilverSulfide_Hsu2019_reference;
