model Envafolimab_Cui2024_reference
  parameter Real Cl_ref = 1.3277777777777778e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0155 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 4.083333333333333e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About envafolimab</h4><p>Envafolimab is an investigational anticancer monoclonal antibody that blocks the PD-1/PD-L1 pathway. It is not yet an approved medicine and remains under investigation, with no marketing authorisation in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q123499516\">Wikidata Q123499516</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>envafolimab</td></tr><tr><td>population:</td><td>adults with advanced solid tumors</td></tr><tr><td>source_paper:</td><td>Cui_2024</td></tr><tr><td>measured_compound:</td><td>envafolimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'E max' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Cui_2024_table_1:row0:col2', 'Cui_2024_table_1:row0:col5'])</li><li>dropped unlinked row (NIL): 'T 50' — extend the ontology if this is a real PK parameter (source ['Cui_2024_table_1:row1:col2', 'Cui_2024_table_1:row1:col5'])</li><li>dropped unlinked row (NIL): 'CL-CRCL' — extend the ontology if this is a real PK parameter (source ['Cui_2024_table_1:row5:col2'])</li><li>unit_dimension_mismatch: 'CL-AMERICAN' → Q22 (unit '[time]' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('CL-AMERICAN', value '0.891') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CL-JAPANESE' — extend the ontology if this is a real PK parameter (source ['Cui_2024_table_1:row7:col2'])</li><li>dropped unlinked row (NIL): 'Epsilon' — extend the ontology if this is a real PK parameter (source ['Cui_2024_table_1:row8:col2', 'Cui_2024_table_1:row8:col5'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL); Q61 (V)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=envafolimab</li><li>molar mass: none found for 'envafolimab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Envafolimab_Cui2024_reference;
