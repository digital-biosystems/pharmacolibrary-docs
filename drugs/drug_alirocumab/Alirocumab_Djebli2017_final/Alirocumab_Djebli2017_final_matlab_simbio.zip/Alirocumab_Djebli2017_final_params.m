function p = Alirocumab_Djebli2017_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alirocumab   source: Djebli_2017 / final   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Alirocumab_Djebli2017_final_params';
  p.drug  = 'alirocumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.67;                % central volume [L]
  p.CL = 0.007333;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.012792;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
