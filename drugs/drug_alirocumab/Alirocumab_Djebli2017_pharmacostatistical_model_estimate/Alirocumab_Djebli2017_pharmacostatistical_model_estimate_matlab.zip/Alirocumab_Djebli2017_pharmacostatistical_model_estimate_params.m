function p = Alirocumab_Djebli2017_pharmacostatistical_model_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alirocumab   source: Djebli_2017 / pharmacostatistical_model_estimate   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Alirocumab_Djebli2017_pharmacostatistical_model_estimate_params';
  p.drug  = 'alirocumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.99;                % central volume [L]
  p.CL = 0.006958;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.029042;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
