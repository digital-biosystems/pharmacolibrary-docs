function p = Pomalidomide_Ogasawara2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pomalidomide   source: Ogasawara_2021 / reference   route: oral
  p.name  = 'Pomalidomide_Ogasawara2021_reference_params';
  p.drug  = 'pomalidomide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.7;                % central volume [L]
  p.CL = 3.92;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.759;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
