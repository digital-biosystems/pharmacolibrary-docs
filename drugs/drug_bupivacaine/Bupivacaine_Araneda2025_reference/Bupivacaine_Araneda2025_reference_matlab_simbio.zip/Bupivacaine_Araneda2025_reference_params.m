function p = Bupivacaine_Araneda2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bupivacaine   source: Araneda_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Bupivacaine_Araneda2025_reference_params';
  p.drug  = 'bupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 41.9;                % central volume [L]
  p.CL = 17.28;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = -0.254;                % absorption rate [1/h]
  p.F  = 0.543;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
