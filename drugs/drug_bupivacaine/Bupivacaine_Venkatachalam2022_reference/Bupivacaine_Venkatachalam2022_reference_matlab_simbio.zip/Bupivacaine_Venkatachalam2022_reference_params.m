function p = Bupivacaine_Venkatachalam2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bupivacaine   source: Venkatachalam_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Bupivacaine_Venkatachalam2022_reference_params';
  p.drug  = 'bupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.676716;                % central volume [L]
  p.CL = 0.12;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
