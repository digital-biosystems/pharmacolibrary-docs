function p = Procyclidine_Moon2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: procyclidine   source: Moon_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Procyclidine_Moon2025_reference_params';
  p.drug  = 'procyclidine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1869.732773;                % central volume [L]
  p.CL = 108.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
