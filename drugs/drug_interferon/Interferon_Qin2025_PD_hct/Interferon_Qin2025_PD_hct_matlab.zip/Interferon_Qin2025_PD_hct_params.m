function p = Interferon_Qin2025_PD_hct_params()
% Interferon_Qin2025_PD_hct_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% interferon Qin_2025::HCT: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL−1 per second, in SI inside (kg/m3, s). Response HCT in %. Driver: ropeginterferon alfa-2b (not_resolved).
p.E0 = 0.00489;
p.Emax = 0.592;
p.EC50 = 0.000137;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1400.0;
p.form = 'E0*(1 - Emax*frac)';
end
