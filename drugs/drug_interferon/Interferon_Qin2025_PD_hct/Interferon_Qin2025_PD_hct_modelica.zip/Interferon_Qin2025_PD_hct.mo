model Interferon_Qin2025_PD_hct
  "indirect_response_i exposure-response sweep — Qin_2025 :: HCT (hematocrit)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.00489,      // [1; % × 0.01]
    Emax = 0.592,  // type I effect term
    EC50 = 0.000137,  // [kg/m3; ng mL−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1400, Interval = 2.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About interferon</h4><p>Interferons are proteins released by host cells in response to pathogens and are used as antiviral and anticancer agents. They remain in use, including as ophthalmological antivirals, though this entry describes a class of proteins rather than a single authorised product.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q188269\">Wikidata Q188269</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Interferon_Qin2025_PD_hct</h4><p>The steady-state exposure-response curve of Qin A et al., <i>Pharmacology research &amp; perspectives 13(3):e70109</i> 2025 (<a href=\"https://doi.org/10.1002/prp2.70109\">doi:10.1002/prp2.70109</a>) — hematocrit [%] against ropeginterferon alfa-2b ng mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.489 %        drug-free response (baseline) (HCTss, Q324)
  Emax  =      0.592          maximal effect term (I max, Q323)
  EC50  =        137 ng mL−1  exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng mL−1 of ropeginterferon alfa-2b per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.00489   (drug-free)
  exposure = EC50 (137 ng mL−1)  response 0.003443
  exposure -> infinity  response 0.001995</pre></body></html>"));
end Interferon_Qin2025_PD_hct;
