model Interferon_Qin2025_PD_ast
  "linear exposure-response sweep — Qin_2025 :: AST (aspartate aminotransferase increase)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.143564,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About interferon</h4><p>Interferons are proteins released by host cells in response to pathogens and are used as antiviral and anticancer agents. They remain in use, including as ophthalmological antivirals, though this entry describes a class of proteins rather than a single authorised product.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q188269\">Wikidata Q188269</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Interferon_Qin2025_PD_ast</h4><p>The steady-state exposure-response curve of Qin A et al., <i>Pharmacology research &amp; perspectives 13(3):e70109</i> 2025 (<a href=\"https://doi.org/10.1002/prp2.70109\">doi:10.1002/prp2.70109</a>) — aspartate aminotransferase increase against ropeginterferon alfa-2b — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =   0.143564          change in response per unit of exposure (exposure β, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of ropeginterferon alfa-2b per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Interferon_Qin2025_PD_ast;
