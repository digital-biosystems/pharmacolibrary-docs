model Interferon_Qin2025_PD_plt
  "indirect_response_i exposure-response sweep — Qin_2025 :: PLT (platelet)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 332,      // [109 L−1 day−1]
    Emax = 1,  // type I effect term
    EC50 = 7.24e-05,  // [kg/m3; ng mL−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 730, Interval = 1.46),
    Documentation(info = "<html><body><!-- drug-about --><h4>About interferon</h4><p>Interferons are proteins released by host cells in response to pathogens and are used as antiviral and anticancer agents. They remain in use, including as ophthalmological antivirals, though this entry describes a class of proteins rather than a single authorised product.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q188269\">Wikidata Q188269</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Interferon_Qin2025_PD_plt</h4><p>The steady-state exposure-response curve of Qin A et al., <i>Pharmacology research &amp; perspectives 13(3):e70109</i> 2025 (<a href=\"https://doi.org/10.1002/prp2.70109\">doi:10.1002/prp2.70109</a>) — platelet [109 L−1 day−1] against ropeginterferon alfa-2b ng mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        332 109 L−1 day−1 drug-free response (baseline) (PLTss, Q324)
  Emax  =          1          maximal effect term (I max,P, Q323)
  EC50  =       72.4 ng mL−1  exposure at half of the maximal effect term (IC 50,P, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng mL−1 of ropeginterferon alfa-2b per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 332   (drug-free)
  exposure = EC50 (72.4 ng mL−1)  response 166
  exposure -> infinity  response 0</pre></body></html>"));
end Interferon_Qin2025_PD_plt;
