function p = Interferon_Qin2025_PD_jak2v617f_params()
% Interferon_Qin2025_PD_jak2v617f_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% interferon Qin_2025::JAK2V617F: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response JAK2V617F in its own unit. Driver: ropeginterferon alfa-2b (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.51;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
