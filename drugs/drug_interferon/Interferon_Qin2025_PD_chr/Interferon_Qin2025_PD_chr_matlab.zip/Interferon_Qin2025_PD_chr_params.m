function p = Interferon_Qin2025_PD_chr_params()
% Interferon_Qin2025_PD_chr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% interferon Qin_2025::CHR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response CHR in its own unit. Driver: ropeginterferon alfa-2b (dose_only).
p.E0 = 0.0;
p.Emax = 8.397;
p.EC50 = 1.98;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 20.0;
p.form = 'E0 + Emax*frac';
end
