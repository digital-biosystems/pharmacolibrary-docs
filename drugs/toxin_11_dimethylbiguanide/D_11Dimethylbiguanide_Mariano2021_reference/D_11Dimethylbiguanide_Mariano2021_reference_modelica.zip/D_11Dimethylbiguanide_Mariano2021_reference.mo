model D_11Dimethylbiguanide_Mariano2021_reference
  parameter Real Cl_ref = 1.8999999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.276 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.12916999999999998,
    adminMass = 0.0005
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>11_dimethylbiguanide</td></tr><tr><td>population:</td><td>normal subjects and chronic renal failure patients</td></tr><tr><td>source_paper:</td><td>Mariano_2021</td></tr><tr><td>measured_compound:</td><td>1,1-Dimethylbiguanide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>1,1-Dimethylbiguanide 129.17 g/mol (paper); 11_dimethylbiguanide 129.167 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Toxic threshold plasma level (mg/L)c' — extend the ontology if this is a real PK parameter (source ['Mariano_2021_table_1:row4:col2'])</li><li>dropped unlinked row (NIL): 'BCrC 30 ml/min' — extend the ontology if this is a real PK parameter (source ['Mariano_2021_table_1:row7:col2'])</li><li>dropped unlinked row (NIL): 'BCrC 15 ml/min' — extend the ontology if this is a real PK parameter (source ['Mariano_2021_table_1:row8:col2'])</li><li>table mostly unlinked (3/4 table-cell rows NIL) — likely the wrong table was located, not 1 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q22 ('apparent total clearance (Clear/F)'=1140) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1,1-Dimethylbiguanide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Froldi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Froldi_2024 — borrowed values do not complete its disposition core; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_11Dimethylbiguanide_Mariano2021_reference;
