function p = D_11Dimethylbiguanide_Mariano2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 11_dimethylbiguanide   source: Mariano_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'D_11Dimethylbiguanide_Mariano2021_reference_params';
  p.drug  = '11_dimethylbiguanide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 276.0;                % central volume [L]
  p.CL = 68.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
