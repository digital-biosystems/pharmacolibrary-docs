model D_11Dimethylbiguanide_Jeong2021_estimate_cv_rabbit
  parameter Real Cl_ref = 4.333333333333334e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.276 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.334,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129167,
    adminMass = 0.002,
    ka = 0.00011777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>11_dimethylbiguanide</td></tr><tr><td>population:</td><td>mouse, rat, rabbit, cat, monkey, minipig, dog, man, and horse</td></tr><tr><td>source_paper:</td><td>Jeong_2021</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-14-00545-t005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>11_dimethylbiguanide 129.167 g/mol (pubchem); metformin 129.167 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Kp2' — extend the ontology if this is a real PK parameter (source ['pharmaceuticals-14-00545-t005:row3:col3'])</li><li>dropped unlinked row (NIL): 'fd1' — extend the ontology if this is a real PK parameter (source ['pharmaceuticals-14-00545-t005:row4:col3'])</li><li>NIL: refused to back-fill base 'Vss' from footnote/prose loose number None (source ['pharmaceuticals-14-00545-t005:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=metformin</li><li>population split: 'estimate (cv%) / rabbit' subgroup of Jeong_2021 (paper reports 9 populations: estimate (cv%) / cat, estimate (cv%) / dog, estimate (cv%) / horse, estimate (cv%) / man, estimate (cv%) / minipig, estimate (cv%) / monkey, estimate (cv%) / mouse, estimate (cv%) / rabbit, estimate (cv%) / rat)</li><li>gap-filled Q61 (V) from Froldi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end D_11Dimethylbiguanide_Jeong2021_estimate_cv_rabbit;
