function p = D_11Dimethylbiguanide_Jeong2021_estimate_cv_rabbit_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 11_dimethylbiguanide   source: Jeong_2021 / estimate_cv_rabbit   route: oral
  p.name  = 'D_11Dimethylbiguanide_Jeong2021_estimate_cv_rabbit_params';
  p.drug  = '11_dimethylbiguanide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 276.0;                % central volume [L]
  p.CL = 0.156;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.424;                % absorption rate [1/h]
  p.F  = 0.334;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
