function p = D_11Dimethylbiguanide_Correia2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 11_dimethylbiguanide   source: Correia_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'D_11Dimethylbiguanide_Correia2022_reference_params';
  p.drug  = '11_dimethylbiguanide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 276.0;                % central volume [L]
  p.CL = 2.34;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
