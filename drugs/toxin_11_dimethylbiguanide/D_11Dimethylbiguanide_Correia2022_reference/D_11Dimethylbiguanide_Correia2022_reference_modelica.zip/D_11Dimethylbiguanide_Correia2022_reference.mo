model D_11Dimethylbiguanide_Correia2022_reference
  parameter Real Cl_ref = 6.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.276 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129167,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>11_dimethylbiguanide</td></tr><tr><td>population:</td><td>patients with metformin poisoning treated with continuous renal replacement therapy</td></tr><tr><td>source_paper:</td><td>Correia_2022</td></tr><tr><td>measured_compound:</td><td>1,1-Dimethylbiguanide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>1,1-Dimethylbiguanide 129.167 g/mol (pubchem); 11_dimethylbiguanide 129.167 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'survival' — extend the ontology if this is a real PK parameter (source ['Correia_2022:abstract', 'Correia_2022:abstract'])</li><li>dropped duplicate Q32 ('median peak metformin concentrations', value 41.9) — already have one for this compound</li><li>dropped duplicate Q57 ('median elimination half-life parameters', value 23.0) — already have one for this compound</li><li>dropped duplicate Q57 ('Elimination half-life ranged from', value 7) — already have one for this compound</li><li>dropped unlinked row (NIL): 'to' — extend the ontology if this is a real PK parameter (source ['Correia_2022:abstract'])</li><li>dropped unlinked row (NIL): 'concentrations (over' — extend the ontology if this is a real PK parameter (source ['Correia_2022:abstract'])</li><li>dropped duplicate Q57 ('half-life below', value 20) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=1,1-Dimethylbiguanide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Froldi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Froldi_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end D_11Dimethylbiguanide_Correia2022_reference;
