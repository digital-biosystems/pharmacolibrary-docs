model D_11Dimethylbiguanide_Jang2016_reference
  parameter Real Cl_ref = 3.15e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.276 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.129167,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>11_dimethylbiguanide</td></tr><tr><td>population:</td><td>Healthy elderly subjects and younger healthy volunteers</td></tr><tr><td>source_paper:</td><td>Jang_2016</td></tr><tr><td>measured_compound:</td><td>Metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>11_dimethylbiguanide 129.167 g/mol (pubchem); Metformin 129.167 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'times higher' (Cmax_ratio)</li><li>unit_dimension_unknown: 'times higher' (AUC ratio)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Metformin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from McCreight_2020's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Froldi_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Froldi_2024, McCreight_2020 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end D_11Dimethylbiguanide_Jang2016_reference;
