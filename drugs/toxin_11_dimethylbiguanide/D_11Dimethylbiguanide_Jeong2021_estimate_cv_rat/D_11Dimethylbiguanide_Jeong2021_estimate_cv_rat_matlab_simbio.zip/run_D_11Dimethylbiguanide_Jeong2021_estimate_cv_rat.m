% Run (SimBiology): build model + dose, simulate 0..408.0 h, plot.
p = D_11Dimethylbiguanide_Jeong2021_estimate_cv_rat_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 408.0);
