% Run: build params, simulate 0..4320.0 h, plot + save D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.m
here = fileparts(mfilename('fullpath'));
p = D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse_params();
out = simulate_pk(p, 0:0.05:4320.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('11_dimethylbiguanide — Jeong_2021 (oral)');
print(fig, fullfile(here, 'D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.json'), 'w');
try
  s.model = 'D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.png, D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.csv, D_11Dimethylbiguanide_Jeong2021_estimate_cv_mouse.json\n');
