% Run (SimBiology): build model + dose, simulate 0..38.0 h, plot.
p = D_11Dimethylbiguanide_Jeong2021_estimate_cv_dog_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 38.0);
