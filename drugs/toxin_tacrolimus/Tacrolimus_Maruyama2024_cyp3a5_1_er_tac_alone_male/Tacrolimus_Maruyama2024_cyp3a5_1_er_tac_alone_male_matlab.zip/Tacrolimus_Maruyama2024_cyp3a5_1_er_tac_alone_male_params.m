function p = Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_alone_male_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Maruyama_2024 / cyp3a5_1_er_tac_alone_male   route: oral
  % estimated (absent from source): F
  p.name  = 'Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_alone_male_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 767.0;                % central volume [L]
  p.CL = 25.16;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.354;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.346;             % absorption lag [h]
  p.dose = 480.0;             % dose [mg]
end
