% Run: build params, simulate 0..120.0 h, plot + save Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.m
here = fileparts(mfilename('fullpath'));
p = Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone_params();
out = simulate_pk(p, 0:0.05:120.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('tacrolimus — Maruyama_2024 (oral)');
print(fig, fullfile(here, 'Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.json'), 'w');
try
  s.model = 'Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.png, Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.csv, Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone.json\n');
