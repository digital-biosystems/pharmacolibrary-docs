% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_er_tac_alone_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
