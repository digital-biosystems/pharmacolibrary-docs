% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Tacrolimus_Maruyama2024_no_stratified_ir_tac_let_ir_tac_alon_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
