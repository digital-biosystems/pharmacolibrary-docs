model Tacrolimus_Chen2023_base
  parameter Real Cl_ref = 6.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.68 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 0.00013944444444444445,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>myasthenia gravis patients</td></tr><tr><td>source_paper:</td><td>Chen_2023</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412966-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'k a (h−1)'; source reconciliation required</li><li>table representations disagree for 'T lag (h)'; source reconciliation required</li><li>table representations disagree for 'IIV CL/F (%)'; source reconciliation required</li><li>table representations disagree for 'IIV V/F (%)'; source reconciliation required</li><li>table representations disagree for 'TS0'; source reconciliation required</li><li>table representations disagree for 'E max'; source reconciliation required</li><li>table representations disagree for 'EcAUC50 (ng*h/mL)'; source reconciliation required</li><li>table representations disagree for 'IIV TS0 (%)'; source reconciliation required</li><li>table representations disagree for 'IIV EcAUC50 (%)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'TS0' — extend the ontology if this is a real PK parameter (source ['psp412966-tbl-0002:row15:col1'])</li><li>dropped PD-category row 'E max' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412966-tbl-0002:row19:col1', 'psp412966-tbl-0002:footnote'])</li><li>dropped PD-category row 'EcAUC50 (ng*h/mL)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412966-tbl-0002:row20:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Chen2023_base;
