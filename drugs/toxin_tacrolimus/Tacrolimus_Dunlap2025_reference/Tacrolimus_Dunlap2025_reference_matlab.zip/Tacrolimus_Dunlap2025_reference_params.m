function p = Tacrolimus_Dunlap2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Dunlap_2025 / reference   route: oral
  p.name  = 'Tacrolimus_Dunlap2025_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 76.3;                % central volume [L]
  p.CL = 49.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.354;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.346;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
