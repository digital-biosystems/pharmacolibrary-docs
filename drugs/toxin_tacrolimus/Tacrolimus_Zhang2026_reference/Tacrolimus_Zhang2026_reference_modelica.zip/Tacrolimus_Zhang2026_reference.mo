model Tacrolimus_Zhang2026_reference
  parameter Real Cl_ref = 5.63888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.92 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 7e-07,
    ka = 0.0012444444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>CTD-ILD patients (connective tissue disease-associated interstitial lung disease)</td></tr><tr><td>source_paper:</td><td>Zhang_2026</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Tacrolimus</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Zhang2026_reference;
