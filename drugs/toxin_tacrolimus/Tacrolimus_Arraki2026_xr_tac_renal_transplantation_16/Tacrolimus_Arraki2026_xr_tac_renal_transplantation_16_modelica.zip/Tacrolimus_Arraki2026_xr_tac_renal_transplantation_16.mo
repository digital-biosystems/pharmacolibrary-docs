model Tacrolimus_Arraki2026_xr_tac_renal_transplantation_16
  parameter Real Cl_ref = 5.888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.486 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-07,
    ka = 9.833333333333333e-05,
    Tlag = 1245.6,
    k21 = 8.097580975809757e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult stable kidney and liver transplant recipients on prolonged-release tacrolimus</td></tr><tr><td>source_paper:</td><td>Arraki_2026</td></tr><tr><td>measured_compound:</td><td>Tacrolimus (whole blood)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcpt70157-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIVCl' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVVc' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVQ' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVVp' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVKtr' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section residual_error: 'Original ε add (μg/L)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Original ε prop (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'ε add used (μg/L)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'ε prop used (%)' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tacrolimus (whole blood)</li><li>population split: 'xr‐tac, renal transplantation [16]' subgroup of Arraki_2026 (paper reports 3 populations: lcp‐tac, hepatic transplantation [18], xr‐tac, hepatic transplantation [17], xr‐tac, renal transplantation [16])</li><li>molar mass: none found for 'Tacrolimus (whole blood)' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Bai_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chen_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Arraki2026_xr_tac_renal_transplantation_16;
