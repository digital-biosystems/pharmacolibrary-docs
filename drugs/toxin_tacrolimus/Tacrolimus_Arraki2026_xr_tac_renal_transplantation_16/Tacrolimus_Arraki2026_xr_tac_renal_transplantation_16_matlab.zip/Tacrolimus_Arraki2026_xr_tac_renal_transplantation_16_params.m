function p = Tacrolimus_Arraki2026_xr_tac_renal_transplantation_16_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Arraki_2026 / xr_tac_renal_transplantation_16   route: oral
  % estimated (absent from source): F
  p.name  = 'Tacrolimus_Arraki2026_xr_tac_renal_transplantation_16_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 486.0;                % central volume [L]
  p.CL = 21.2;                % clearance [L/h]
  p.Vp = [271.0];             % peripheral volumes [L]
  p.Q  = [79.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.354;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.346;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
