function p = Tacrolimus_Brstilo2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Brstilo_2026 / reference   route: oral
  p.name  = 'Tacrolimus_Brstilo2026_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.3;                % central volume [L]
  p.CL = 1.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.354;                % absorption rate [1/h]
  p.F  = 0.4;                 % bioavailability [0-1]
  p.Tlag = 0.3;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
