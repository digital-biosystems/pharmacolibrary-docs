model Tacrolimus_Martischang2024_administration_route_po
  parameter Real Cl_ref = 7.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.767 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 9.833333333333333e-05,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>healthy volunteers and transplant donors/recipients with CYP3A5 polymorphism or CYP3A interactions</td></tr><tr><td>source_paper:</td><td>Martischang_2024</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Healthy volunteers' — extend the ontology if this is a real PK parameter (source ['Martischang_2024_table_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Clinical case (virtual twin)' — extend the ontology if this is a real PK parameter (source ['Martischang_2024_table_1:row2:col1'])</li><li>covariate level 'Both donor and recipient expressing CYP3A5 (*1/*1)' → Q900:both_donor_and_recipient_expressing_cyp3a5_1_1 = 1 (linear_fractional on the model)</li><li>covariate level 'Donor expressing CYP3A5 (*1/*1)' → Q900:donor_expressing_cyp3a5_1_1 = 1 (linear_fractional on the model)</li><li>covariate level 'Recipient expressing CYP3A5 (*1/*1)' → Q900:recipient_expressing_cyp3a5_1_1 = 1 (linear_fractional on the model)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tacrolimus</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>pharmacogenetic covariate 'both_donor_and_recipient_expressing_cyp3a5_1_1' (cyp3a5) — PGx domain</li><li>pharmacogenetic covariate 'donor_expressing_cyp3a5_1_1' (cyp3a5) — PGx domain</li><li>pharmacogenetic covariate 'recipient_expressing_cyp3a5_1_1' (cyp3a5) — PGx domain</li><li>population split: 'administration route po' subgroup of Martischang_2024 (paper reports 2 populations: administration route iv, administration route po)</li><li>gap-filled Q22 (CL) from Kuypers_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kuypers_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bai_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Martischang2024_administration_route_po;
