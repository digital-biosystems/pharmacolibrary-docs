model Tacrolimus_Chen2023_final
  parameter Real Cl_ref = 4.361111111111111e-06 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Real cov_cyp3a5_2 = 0 "cyp3a5 covariate";
  parameter Real Vd_ref = 1.41 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (2.05)*cov_cyp3a5_2) + (1.1333333333333334e-06)*(if cov_category_0 then 1 else 0) + (2.8888888888888894e-06)*(if cov_category_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 0.00013944444444444445,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>myasthenia gravis patients</td></tr><tr><td>source_paper:</td><td>Chen_2023</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412966-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'k a (h−1)'; source reconciliation required</li><li>table representations disagree for 'T lag (h)'; source reconciliation required</li><li>table representations disagree for 'CYP3A5*1/*1 and *1/*3 on CL/F'; source reconciliation required</li><li>table representations disagree for 'TP on V/F'; source reconciliation required</li><li>table representations disagree for 'IIV CL/F (%)'; source reconciliation required</li><li>table representations disagree for 'IIV V/F (%)'; source reconciliation required</li><li>table representations disagree for 'TS0 for Osserman I'; source reconciliation required</li><li>table representations disagree for 'TS0 for Osserman IIa/IIb'; source reconciliation required</li><li>table representations disagree for 'TS0 for Osserman III/IV'; source reconciliation required</li><li>table representations disagree for 'E max'; source reconciliation required</li><li>table representations disagree for 'EcAUC50 (ng*h/mL)'; source reconciliation required</li><li>table representations disagree for 'IIV TS0 (%)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Chen2023_final;
