model Tacrolimus_Hong2023_value
  parameter Real Cl_ref = 7.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.767 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 0.0010222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult cystic fibrosis lung transplant recipients (and simulated healthy/CF adults)</td></tr><tr><td>source_paper:</td><td>Hong_2023</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>manual_model_class</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-01438-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Molecular weight (g/mol)'; source reconciliation required</li><li>table representations disagree for 'Log Po:w'; source reconciliation required</li><li>table representations disagree for 'B/P'; source reconciliation required</li><li>table representations disagree for 'fup'; source reconciliation required</li><li>table representations disagree for 'Caco-2 permeability (10−6 cm/s)'; source reconciliation required</li><li>table representations disagree for 'Scalar'; source reconciliation required</li><li>table representations disagree for 'fugut'; source reconciliation required</li><li>table representations disagree for 'ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'f a'; source reconciliation required</li><li>table representations disagree for 'Lag time (h)'; source reconciliation required</li><li>table representations disagree for 'Qgut (L/h)'; source reconciliation required</li><li>table representations disagree for 'Peff,man (×10−4 cm/s)'; source reconciliation required</li><li>table representations disagree for 'kin (h−1)'; source reconciliation required</li><li>table representations disagree for 'kout (h−1)'; source reconciliation required</li><li>table representations disagree for 'Vsac (l/kg)'; source reconciliation required</li><li>table representations disagree for 'Vss (l/kg)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Hong2023_value;
