function p = Tacrolimus_Hong2023_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Hong_2023 / value   route: oral
  % estimated (absent from source): F
  p.name  = 'Tacrolimus_Hong2023_value_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 767.0;                % central volume [L]
  p.CL = 27.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.68;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
