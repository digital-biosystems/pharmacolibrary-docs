% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Tacrolimus_Maruyama2024_value_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
