function p = Tacrolimus_Arraki2026_xr_tac_hepatic_transplantation_17_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Arraki_2026 / xr_tac_hepatic_transplantation_17   route: oral
  p.name  = 'Tacrolimus_Arraki2026_xr_tac_hepatic_transplantation_17_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 88.3;                % central volume [L]
  p.CL = 4.21;                % clearance [L/h]
  p.Vp = [145.0];             % peripheral volumes [L]
  p.Q  = [14.0];             % inter-compartmental clearances [L/h]
  p.ka = 3.76;                % absorption rate [1/h]
  p.F  = 0.23;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
