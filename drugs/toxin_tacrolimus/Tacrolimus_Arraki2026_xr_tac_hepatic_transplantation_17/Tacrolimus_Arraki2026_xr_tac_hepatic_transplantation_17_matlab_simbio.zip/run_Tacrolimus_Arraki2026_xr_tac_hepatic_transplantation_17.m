% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Tacrolimus_Arraki2026_xr_tac_hepatic_transplantation_17_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
