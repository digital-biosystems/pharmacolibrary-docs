function p = Tacrolimus_Zhang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Zhang_2025 / reference   route: oral
  p.name  = 'Tacrolimus_Zhang2025_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.0;                % central volume [L]
  p.CL = 4.91;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.354;                % absorption rate [1/h]
  p.F  = 0.265;                 % bioavailability [0-1]
  p.Tlag = 0.346;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
