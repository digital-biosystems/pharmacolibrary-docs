model Tacrolimus_Arraki2026_lcp_tac_hepatic_transplantation_18
  parameter Real Cl_ref = 9.083333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09490000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.23,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-07,
    ka = 0.0008250000000000001,
    Tlag = 0.0,
    k21 = 5.344444444444445e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult stable kidney and liver transplant recipients on prolonged-release tacrolimus</td></tr><tr><td>source_paper:</td><td>Arraki_2026</td></tr><tr><td>measured_compound:</td><td>Tacrolimus (whole blood)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcpt70157-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIVF' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVCl' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVVc' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVQ' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section iiv: 'IIVKa' routed out of structural estimates ('Interindividual variability (Variance values)')</li><li>table section residual_error: 'Original ε prop (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'ε prop used (%)' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tacrolimus (whole blood)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'lcp‐tac, hepatic transplantation [18]' subgroup of Arraki_2026 (paper reports 3 populations: lcp‐tac, hepatic transplantation [18], xr‐tac, hepatic transplantation [17], xr‐tac, renal transplantation [16])</li><li>molar mass: none found for 'Tacrolimus (whole blood)' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Arraki2026_lcp_tac_hepatic_transplantation_18;
