function p = Tacrolimus_Arraki2026_lcp_tac_hepatic_transplantation_18_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Arraki_2026 / lcp_tac_hepatic_transplantation_18   route: oral
  p.name  = 'Tacrolimus_Arraki2026_lcp_tac_hepatic_transplantation_18_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 94.9;                % central volume [L]
  p.CL = 3.27;                % clearance [L/h]
  p.Vp = [500.0];             % peripheral volumes [L]
  p.Q  = [9.62];             % inter-compartmental clearances [L/h]
  p.ka = 2.97;                % absorption rate [1/h]
  p.F  = 0.23;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
