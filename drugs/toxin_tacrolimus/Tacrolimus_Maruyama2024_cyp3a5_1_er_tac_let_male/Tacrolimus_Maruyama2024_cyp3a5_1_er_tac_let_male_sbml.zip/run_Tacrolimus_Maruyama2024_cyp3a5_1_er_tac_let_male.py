#!/usr/bin/env python3
"""Simulate Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male.sbml (0..264.0 h) with Tellurium/libRoadRunner and write results.

Headless-friendly: writes Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male.csv, Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male.json and Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male.png next to this script
(no interactive window). Requires `tellurium` (bundles libRoadRunner + matplotlib).
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male")

r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 264.0, 500, ["time", "Cc"])   # Cc = central concentration [mg/L]
t = [float(x) for x in res[:, 0]]
Cc = [float(x) for x in res[:, 1]]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male", "stop_time_h": 264.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Tacrolimus_Maruyama2024_cyp3a5_1_er_tac_let_male"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
