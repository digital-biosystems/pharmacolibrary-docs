model Tacrolimus_Kuypers2026_reference
  parameter Real Cl_ref = 7.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.767 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 1.4e-05,
    ka = 9.833333333333333e-05,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>kidney allograft recipients</td></tr><tr><td>source_paper:</td><td>Kuypers_2026</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'MIPD' — extend the ontology if this is a real PK parameter (source ['Kuypers_2026_table_1:row1:col1', 'Kuypers_2026_table_1:row1:col2', 'Kuypers_2026_table_1:row4:col1', 'Kuypers_2026_table_1:row4:col2', 'Kuypers_2026_table_1:row7:col1', 'Kuypers_2026_table_1:row7:col2'])</li><li>dropped unlinked row (NIL): 'Physician' — extend the ontology if this is a real PK parameter (source ['Kuypers_2026_table_1:row2:col1', 'Kuypers_2026_table_1:row5:col1', 'Kuypers_2026_table_1:row8:col1'])</li><li>salvaged Q61 ('distribution volume'=767) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=27.6) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tacrolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bai_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chen_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Kuypers2026_reference;
