function p = Tacrolimus_Kuypers2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Kuypers_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Tacrolimus_Kuypers2026_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 767.0;                % central volume [L]
  p.CL = 27.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.354;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.346;             % absorption lag [h]
  p.dose = 14.0;             % dose [mg]
end
