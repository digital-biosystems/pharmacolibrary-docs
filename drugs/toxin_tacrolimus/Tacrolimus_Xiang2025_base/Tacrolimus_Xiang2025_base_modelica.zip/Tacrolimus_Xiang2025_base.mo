model Tacrolimus_Xiang2025_base
  parameter Real Cl_ref = 6.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.497 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 0.0008583333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>renal transplant recipients</td></tr><tr><td>source_paper:</td><td>Xiang_2025</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'IIV CL/F (%)'; source reconciliation required</li><li>table representations disagree for 'IIV V/F (%)'; source reconciliation required</li><li>table representations disagree for 'Residual errorAdditive (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'FPG0 (mmol/L)'; source reconciliation required</li><li>table representations disagree for 'β'; source reconciliation required</li><li>table representations disagree for 'IIV FPG0 ((%)'; source reconciliation required</li><li>table representations disagree for 'Residual errorProportional (%)'; source reconciliation required</li><li>table representations disagree for 'eGFR0 (mL/min/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'IC50 (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'Imax (mL/min/1.73 m2)'; source reconciliation required</li><li>table representations disagree for 'IIV eGFR0 (%)'; source reconciliation required</li><li>dropped PD-category row 'FPG0 (mmol/L)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0002:row13:col1'])</li><li>dropped PD-category row 'eGFR0 (mL/min/1.73 m2)' → Q336 (R0, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0002:row19:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Xiang2025_base;
