model Tacrolimus_Pei2023_reference
  parameter Real Cl_ref = 3.4305555555555554e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6567999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 8.333333333333333e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult heart transplant recipients</td></tr><tr><td>source_paper:</td><td>Pei_2023</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-02580-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Ka: first-order absorption rate; KD: the affinity constant; Bmax: the binding capacity; CLint: the hepatic intrinsic clearance.' routed out of structural estimates ('Table 3. Final parameter estimates and corresponding residual error based on the PBPK model.')</li><li>salvaged Q49 ('absorption rate constant (ka)'=0.3) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('apparent distribution volume (Vd/F)'=656.8) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('apparent clearance (CL/F)'=12.35) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('internal clearance (decreased)'=44.3) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Tacrolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Pei_2023:discussion_prose, Pei_2023:other_prose, Pei_2023:results_prose, pharmaceutics-15-02580-t003:footnote); populations external evaluation dataset(n = 100) / estimatevalue, healthy adult dataset (n = 5) / estimate value, model building dataset (n = 115) / estimate value, tacrolimus, 2.5 mg, q12h, tacrolimus, 2.5 mg, single dose kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q22 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Pei2023_reference;
