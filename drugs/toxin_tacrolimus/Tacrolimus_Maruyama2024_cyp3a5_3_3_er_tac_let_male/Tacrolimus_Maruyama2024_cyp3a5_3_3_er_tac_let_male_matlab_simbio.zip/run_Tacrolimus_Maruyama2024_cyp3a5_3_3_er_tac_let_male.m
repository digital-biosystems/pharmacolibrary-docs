% Run (SimBiology): build model + dose, simulate 0..384.0 h, plot.
p = Tacrolimus_Maruyama2024_cyp3a5_3_3_er_tac_let_male_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 384.0);
