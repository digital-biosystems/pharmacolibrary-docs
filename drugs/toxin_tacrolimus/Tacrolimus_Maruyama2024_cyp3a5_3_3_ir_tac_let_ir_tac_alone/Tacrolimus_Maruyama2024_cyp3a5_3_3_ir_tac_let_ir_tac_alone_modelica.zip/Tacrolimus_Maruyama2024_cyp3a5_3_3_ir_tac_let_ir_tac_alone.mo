model Tacrolimus_Maruyama2024_cyp3a5_3_3_ir_tac_let_ir_tac_alone
  parameter Real Cl_ref = 7.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.767 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 0.00048,
    ka = 9.833333333333333e-05,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>Japanese early post-renal transplant patients (virtual population)</td></tr><tr><td>source_paper:</td><td>Maruyama_2024</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab7</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'IR-TAC'</li><li>dropped value-less row: 'ER-TAC'</li><li>dropped value-less row: 'LET'</li><li>dropped value-less row: 'AUCinf'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'Tmax'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tacrolimus</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'cyp3a5*3/*3 / ir-tac + let/ ir-tac alone' subgroup of Maruyama_2024 (paper reports 22 populations: cyp3a5*1 / er-tac + let / female, cyp3a5*1 / er-tac + let / male, cyp3a5*1 / er-tac + let/ er-tac alone, cyp3a5*1 / er-tac + let/er-tac alone ratio / female, cyp3a5*1 / er-tac + let/er-tac alone ratio / male, cyp3a5*1 / er-tac alone / female, cyp3a5*1 / er-tac alone / male, cyp3a5*1 / er/ir ratio, cyp3a5*1 / ir-tac + let/ ir-tac alone, cyp3a5*3/*3 / er-tac + let / female, cyp3a5*3/*3 / er-tac + let / male, cyp3a5*3/*3 / er-tac + let/ er-tac alone, cyp3a5*3/*3 / er-tac + let/er-tac alone ratio / female, cyp3a5*3/*3 / er-tac + let/er-tac alone ratio / male, cyp3a5*3/*3 / er-tac alone / female, cyp3a5*3/*3 / er-tac alone / male, cyp3a5*3/*3 / er/ir ratio, cyp3a5*3/*3 / ir-tac + let/ ir-tac alone, no stratified / er-tac + let/ er-tac alone, no stratified / er/ir ratio, no stratified / ir-tac + let/ ir-tac alone, value)</li><li>gap-filled Q22 (CL) from Kuypers_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kuypers_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bai_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chen_2023's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Bai_2024, Chen_2023, Kuypers_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Maruyama2024_cyp3a5_3_3_ir_tac_let_ir_tac_alone;
