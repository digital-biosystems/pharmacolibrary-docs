model Tacrolimus_Zhao2021_reference
  parameter Real Cl_ref = 7.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.767 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 9.833333333333333e-05,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>paediatrics and adults (humans)</td></tr><tr><td>source_paper:</td><td>Zhao_2021</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>covariate category for Cmax_ratio from footnote/prose kept as documentation only (['Zhao_2021:abstract'])</li><li>covariate category for Cmax_ratio from footnote/prose kept as documentation only (['Zhao_2021:abstract'])</li><li>covariate category for Cmax_ratio from footnote/prose kept as documentation only (['Zhao_2021:abstract'])</li><li>covariate category for Cmax_ratio from footnote/prose kept as documentation only (['Zhao_2021:abstract'])</li><li>unit_dimension_unknown: 'p.o., paediatrics' (AUC ratio)</li><li>unit_dimension_unknown: 'i.v., paediatrics' (AUC ratio)</li><li>dropped duplicate Q21 ('ratios of the area under the concentration-time curve (AUC) (i.v., paediatrics)', value 0.18) — already have one for this compound</li><li>unit_dimension_unknown: 'p.o., adults' (AUC ratio)</li><li>dropped duplicate Q21 ('ratios of the area under the concentration-time curve (AUC) (p.o., adults)', value 0.46) — already have one for this compound</li><li>unit_dimension_unknown: 'i.v., adults' (AUC ratio)</li><li>dropped duplicate Q21 ('ratios of the area under the concentration-time curve (AUC) (i.v., adults)', value 0.53) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tacrolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Kuypers_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Zhao2021_reference;
