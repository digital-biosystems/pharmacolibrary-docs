// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Tacrolimus_Hong2023_pk_study_regimen
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {54000.0},
    MM = 0.804,
    adminMass = 5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adult cystic fibrosis lung transplant recipients (and simulated healthy/CF adults)</td></tr><tr><td>source_paper:</td><td>Hong_2023</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-01438-t001</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>routed 'SD' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'tacrolimus' — extend the ontology if this is a real PK parameter (source ['Hong_2023_table_2:row5:col1', 'Hong_2023_table_2:row8:col1'])</li><li>salvaged Q57 ('long half-life of ivacaftor'=15) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tacrolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'pk study / regimen' subgroup of Hong_2023 (paper reports 4 populations: pk parameters / observed, pk parameters / simulated, pk study / regimen, value)</li><li>gap-filled Q22 (CL) from Kuypers_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kuypers_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bai_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Chen_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Tacrolimus_Hong2023_pk_study_regimen;
