model Tacrolimus_Mohammed2025_reference
  parameter Real Cl_ref = 3.3055555555555558e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.078 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.804,
    adminMass = 5e-06,
    ka = 0.0001388888888888889,
    Tlag = 1674.0,
    k12 = 9.188034188034189e-05,
    k21 = 1.4333333333333334e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>stable Caucasian renal transplant recipients</td></tr><tr><td>source_paper:</td><td>Mohammed_2025</td></tr><tr><td>measured_compound:</td><td>Tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-01185-t003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIVCL/F' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'IIVVc/F' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'Vc/F/Ka IR-Tac Correlation' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'Vc/F/Ka LCP-Tac Correlation' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'IIVKa IR-Tac' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'Ka IR-Tac/Ka LCP-Tac Correlation' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'IIVKa LCP_Tac' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'IOVCL' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>table section iiv: 'IOVVc' routed out of structural estimates ('Interindividual patient variability Description CV% (RSE%)')</li><li>dropped duplicate Q49 ('Ka LCP_Tac', value '0.111') — already have one for this compound</li><li>dropped duplicate Q40 ('F IR-Tac_HM', value '0.427') — already have one for this compound</li><li>dropped duplicate Q83 ('Lag-Time LCP-Tac (h)', value '1.4') — already have one for this compound</li><li>dropped unlinked row (NIL): 'AcrophaseCL/F (h)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-01185-t003:row17:col2'])</li><li>dropped duplicate Q27 ('AmpCL/F', value '3.42') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Acrophaseka (h)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-01185-t003:row19:col2'])</li><li>dropped duplicate Q49 ('Ampka', value '1.55') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Mohammed2025_reference;
