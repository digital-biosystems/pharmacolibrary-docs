function p = Tacrolimus_Mohammed2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Mohammed_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Tacrolimus_Mohammed2025_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 78.0;                % central volume [L]
  p.CL = 11.9;                % clearance [L/h]
  p.Vp = [500.0];             % peripheral volumes [L]
  p.Q  = [25.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.465;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
