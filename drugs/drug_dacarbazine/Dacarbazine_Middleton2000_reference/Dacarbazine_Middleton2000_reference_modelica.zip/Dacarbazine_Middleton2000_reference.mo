model Dacarbazine_Middleton2000_reference
  parameter Real Cl_ref = 3.15e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0287 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.18218700000000002,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dacarbazine</h4><p>Dacarbazine is an alkylating anticancer drug used to treat cancers such as melanoma, Hodgkin's lymphoma, and several soft-tissue and other tumours. It remains in clinical use, is listed among WHO essential medicines, and is approved, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416975\">Wikidata Q416975</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dacarbazine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Middleton_2000</td></tr><tr><td>measured_compound:</td><td>dacarbazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>dacarbazine 182.187 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Middleton_2000) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dacarbazine_Middleton2000_reference;
