model Dacarbazine_Osieka1984_PD_gd
  "linear exposure-response sweep — Osieka_1984 :: GD (Growth delay (GD))"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 2670000,  // [1]
    exposure_per_s = 1e-06);   // 1 mg/kg per second
  // slope_unit_assumed: slope unit '(none)' read as response per mg/kg
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dacarbazine</h4><p>Dacarbazine is an alkylating anticancer drug used to treat cancers such as melanoma, Hodgkin's lymphoma, and several soft-tissue and other tumours. It remains in clinical use, is listed among WHO essential medicines, and is approved, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416975\">Wikidata Q416975</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Dacarbazine_Osieka1984_PD_gd</h4><p>The steady-state exposure-response curve of Osieka R, <i>Cancer 54(6 Suppl):1168–1174</i> 1984 (<a href=\"https://doi.org/10.1002/1097-0142(19840915)54:1+&lt;1168::aid-cncr2820541313&gt;3.0.co;2-z\">doi:10.1002/1097-0142(19840915)54:1+&lt;1168::aid-cncr2820541313&gt;3.0.co;2-z</a>) — Growth delay (GD) against dacarbazine mg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       2.67          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/kg of dacarbazine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Dacarbazine_Osieka1984_PD_gd;
