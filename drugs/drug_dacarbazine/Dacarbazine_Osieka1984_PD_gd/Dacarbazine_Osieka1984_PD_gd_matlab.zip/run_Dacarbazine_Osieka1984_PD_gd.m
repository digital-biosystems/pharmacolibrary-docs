% run_Dacarbazine_Osieka1984_PD_gd  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Dacarbazine_Osieka1984_PD_gd_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/kg]'); ylabel('response []'); title('Dacarbazine_Osieka1984_PD_gd', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Dacarbazine_Osieka1984_PD_gd.csv');
