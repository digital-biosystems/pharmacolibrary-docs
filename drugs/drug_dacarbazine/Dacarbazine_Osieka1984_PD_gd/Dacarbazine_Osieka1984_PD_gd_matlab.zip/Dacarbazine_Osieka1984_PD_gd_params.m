function p = Dacarbazine_Osieka1984_PD_gd_params()
% Dacarbazine_Osieka1984_PD_gd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dacarbazine Osieka_1984::GD: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg per second, in SI inside (kg/m3, s). Response GD in its own unit. Driver: dacarbazine (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.67;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
