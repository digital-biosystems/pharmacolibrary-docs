function p = Norepinephrine_Yoo2015_PD_se_drow_params()
% Norepinephrine_Yoo2015_PD_se_drow_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% norepinephrine Yoo_2015::SE_Drow: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response SE_Drow in mm. Driver: norepinephrine (cited_pk).
p.E0 = 9.5;
p.Emax = -71.3;
p.EC50 = 4.4e-06;
p.gamma = 4.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 44.0;
p.form = 'E0 + Emax*frac';
end
