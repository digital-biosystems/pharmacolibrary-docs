function p = Norepinephrine_Yoo2015_PD_sap_params()
% Norepinephrine_Yoo2015_PD_sap_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% norepinephrine Yoo_2015::SAP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response SAP in mmHg. Driver: norepinephrine (cited_pk).
p.E0 = 76.6;
p.Emax = 203.0;
p.EC50 = 8.2e-06;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 82.0;
p.form = 'E0 + Emax*frac';
end
