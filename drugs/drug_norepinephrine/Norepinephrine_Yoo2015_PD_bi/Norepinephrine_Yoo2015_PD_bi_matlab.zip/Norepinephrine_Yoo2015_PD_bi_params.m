function p = Norepinephrine_Yoo2015_PD_bi_params()
% Norepinephrine_Yoo2015_PD_bi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% norepinephrine Yoo_2015::BI: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response BI in %. Driver: norepinephrine (cited_pk).
p.E0 = 0.642;
p.Emax = 0.337;
p.EC50 = 3.9e-06;
p.gamma = 3.1;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 39.0;
p.form = 'E0 + Emax*frac';
end
