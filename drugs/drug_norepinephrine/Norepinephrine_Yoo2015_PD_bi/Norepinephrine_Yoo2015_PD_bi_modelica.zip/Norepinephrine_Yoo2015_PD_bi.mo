model Norepinephrine_Yoo2015_PD_bi
  "sigmoid_emax exposure-response sweep — Yoo_2015 :: BI (Bispectral index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.642,      // [1; % × 0.01]
    Emax = 0.337,  // [1; % × 0.01]
    EC50 = 3.9e-06,  // [mol/m3; nmol/L × 1e-06]
    gamma = 3.1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  annotation(experiment(StartTime = 0, StopTime = 39, Interval = 0.078),
    Documentation(info = "<html><body><!-- drug-about --><h4>About norepinephrine</h4><p>Norepinephrine is a sympathomimetic, vasoconstricting drug used to treat neurogenic shock. It is an approved medicine, classified under cardiac therapy as an adrenergic agent, and is used mainly in hospital settings for acute cardiovascular support.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q186242\">Wikidata Q186242</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Norepinephrine_Yoo2015_PD_bi</h4><p>The steady-state exposure-response curve of Yoo H et al., <i>European journal of clinical pharmacology 71(10):1197–1207</i> 2015 (<a href=\"https://doi.org/10.1007/s00228-015-1913-0\">doi:10.1007/s00228-015-1913-0</a>) — Bispectral index [%] against norepinephrine nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       64.2 %        drug-free response (baseline) (E0, Q324)
  Emax  =       33.7 %        maximal effect term (Emax, Q320)
  EC50  =        3.9 nmol/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma =        3.1          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of norepinephrine per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.642   (drug-free)
  exposure = EC50 (3.9 nmol/L)  response 0.8105
  exposure -> infinity  response 0.979</pre></body></html>"));
end Norepinephrine_Yoo2015_PD_bi;
