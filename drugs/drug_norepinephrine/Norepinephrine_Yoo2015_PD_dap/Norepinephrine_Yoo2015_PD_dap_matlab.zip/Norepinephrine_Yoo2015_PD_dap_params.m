function p = Norepinephrine_Yoo2015_PD_dap_params()
% Norepinephrine_Yoo2015_PD_dap_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% norepinephrine Yoo_2015::DAP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response DAP in mmHg. Driver: norepinephrine (cited_pk).
p.E0 = 47.3;
p.Emax = 140.0;
p.EC50 = 1.68e-05;
p.gamma = 1.9;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 170.0;
p.form = 'E0 + Emax*frac';
end
