model AminohippuricAcid_Kinowski1995_reference
  parameter Real Cl_ref = 8.527777777777779e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0106 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1941873,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminohippuric_acid</h4><p>Aminohippuric acid is a diagnostic agent used in tests of kidney function and for ureteral injuries. It is an approved diagnostic product, though some formulations have been withdrawn; it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q291271\">Wikidata Q291271</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminohippuric_acid</td></tr><tr><td>population:</td><td>patients with and without renal insufficiency</td></tr><tr><td>source_paper:</td><td>Kinowski_1995</td></tr><tr><td>measured_compound:</td><td>aminohippuric_acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aminohippuric_acid 194.187 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=aminohippuric_acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AminohippuricAcid_Kinowski1995_reference;
