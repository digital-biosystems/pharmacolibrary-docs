function p = Lenvatinib_Majid2024_PD_ang_2_params()
% Lenvatinib_Majid2024_PD_ang_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lenvatinib Majid_2024::Ang_2: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng*h/mL per second, in SI inside (kg/m3, s). Response Ang-2 in ng/L. Driver: lenvatinib (pk_record).
p.E0 = 3.36e-09;
p.Emax = 0.344;
p.EC50 = 930.0;
p.gamma = 4.27;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 9300.0;
p.form = 'E0*(1 - Emax*frac)';
end
