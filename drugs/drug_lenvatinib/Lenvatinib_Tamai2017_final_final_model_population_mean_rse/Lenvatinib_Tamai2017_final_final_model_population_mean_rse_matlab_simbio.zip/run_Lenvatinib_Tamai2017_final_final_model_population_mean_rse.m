% Run (SimBiology): build model + dose, simulate 0..29.0 h, plot.
p = Lenvatinib_Tamai2017_final_final_model_population_mean_rse_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 29.0);
