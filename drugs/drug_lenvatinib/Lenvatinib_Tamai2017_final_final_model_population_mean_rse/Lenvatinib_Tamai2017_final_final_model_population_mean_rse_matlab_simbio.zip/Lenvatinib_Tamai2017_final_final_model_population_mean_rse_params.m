function p = Lenvatinib_Tamai2017_final_final_model_population_mean_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lenvatinib   source: Tamai_2017 / final_final_model_population_mean_rse   route: oral
  p.name  = 'Lenvatinib_Tamai2017_final_final_model_population_mean_rse_params';
  p.drug  = 'lenvatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 47.0;                % central volume [L]
  p.CL = 6.43;                % clearance [L/h]
  p.Vp = [31.2];             % peripheral volumes [L]
  p.Q  = [3.96];             % inter-compartmental clearances [L/h]
  p.ka = 1.04;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 8.0;             % dose [mg]
end
