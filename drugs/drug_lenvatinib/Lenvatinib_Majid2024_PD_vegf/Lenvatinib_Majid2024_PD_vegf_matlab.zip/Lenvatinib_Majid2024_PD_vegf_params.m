function p = Lenvatinib_Majid2024_PD_vegf_params()
% Lenvatinib_Majid2024_PD_vegf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lenvatinib Majid_2024::VEGF: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng*h/mL per second, in SI inside (kg/m3, s). Response VEGF in ng/L. Driver: lenvatinib (pk_record).
p.E0 = 3.7e-10;
p.Emax = 0.344;
p.EC50 = 930.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 15000.0;
p.form = 'E0/(1 - Emax*frac)';
end
