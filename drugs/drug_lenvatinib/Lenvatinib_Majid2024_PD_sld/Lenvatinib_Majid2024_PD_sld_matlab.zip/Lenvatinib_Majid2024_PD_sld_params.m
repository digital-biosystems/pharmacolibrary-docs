function p = Lenvatinib_Majid2024_PD_sld_params()
% Lenvatinib_Majid2024_PD_sld_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lenvatinib Majid_2024::SLD: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng∙h/mL per second, in SI inside (kg/m3, s). Response SLD in mm. Driver: lenvatinib (pk_record).
p.E0 = 0.0;
p.Emax = -1.2483465608465606e-07;
p.EC50 = 1420.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 15000.0;
p.form = 'E0 + Emax*frac';
end
