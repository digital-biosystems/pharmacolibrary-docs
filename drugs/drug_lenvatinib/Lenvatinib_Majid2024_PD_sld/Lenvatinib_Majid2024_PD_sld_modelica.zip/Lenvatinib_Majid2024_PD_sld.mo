model Lenvatinib_Majid2024_PD_sld
  "emax exposure-response sweep — Majid_2024 :: SLD (Tumor size)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.24834656085e-07,  // [1/s; /week × 1.65344e-06]
    EC50 = 1420,  // [ng∙h/mL]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng∙h/mL per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'ng∙h/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 15000, Interval = 30),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lenvatinib</h4><p>Lenvatinib is a protein kinase inhibitor used to treat renal cell carcinoma and various forms of thyroid cancer. It is administered orally, typically in capsule form. The medication is authorised in the European Union and is used in other regions as well.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q6523413\">Wikidata Q6523413</a>, <a href=\"https://en.wikipedia.org/wiki/Lenvatinib?oldid=1376981185\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lenvatinib_Majid2024_PD_sld</h4><p>The steady-state exposure-response curve of Majid O et al., <i>CPT: pharmacometrics &amp; systems pharmacology 13(6):954–969</i> 2024 (<a href=\"https://doi.org/10.1002/psp4.13130\">doi:10.1002/psp4.13130</a>) — Tumor size [mm] against lenvatinib ng∙h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0755 /week    maximal effect term (E max (/week), Q323)
  EC50  =       1420 ng∙h/mL  exposure at half of the maximal effect term (EC50 (ng∙h/mL), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng∙h/mL of lenvatinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1420 ng∙h/mL)  response -6.242e-08
  exposure -> infinity  response -1.248e-07</pre></body></html>"));
end Lenvatinib_Majid2024_PD_sld;
