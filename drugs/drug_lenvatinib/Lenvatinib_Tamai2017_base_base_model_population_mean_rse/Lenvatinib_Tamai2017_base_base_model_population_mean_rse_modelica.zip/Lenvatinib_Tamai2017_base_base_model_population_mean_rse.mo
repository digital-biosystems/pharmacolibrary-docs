model Lenvatinib_Tamai2017_base_base_model_population_mean_rse
  parameter Real Cl_ref = 1.8055555555555557e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0456 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42686,
    adminMass = 8e-06,
    ka = 0.00028333333333333335,
    Tlag = 0.0,
    k12 = 2.3818226120857703e-05,
    k21 = 3.458952583156406e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lenvatinib</h4><p>Lenvatinib is a protein kinase inhibitor used to treat renal cell carcinoma and various forms of thyroid cancer. It is administered orally, typically in capsule form. The medication is authorised in the European Union and is used in other regions as well.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q6523413\">Wikidata Q6523413</a>, <a href=\"https://en.wikipedia.org/wiki/Lenvatinib?oldid=1376981185\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lenvatinib</td></tr><tr><td>population:</td><td>pooled population of healthy adults, patients with mixed tumor types, and patients with hepatocellular carcinoma</td></tr><tr><td>source_paper:</td><td>Tamai_2017</td></tr><tr><td>measured_compound:</td><td>lenvatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph917-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lenvatinib 426.86 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped diagnostic row 'Proportional (%CV) (Clinical pharmacology studies)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped diagnostic row 'Proportional (%CV) (Patient studies)' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped unlinked row (NIL): 'Proportional (%CV) (TAD ≤ 2 hours)' — extend the ontology if this is a real PK parameter (source ['Tamai_2017_table_p5_1:row23:col1'])</li><li>dropped unlinked row (NIL): 'Additional (ng/mL) (TAD ≤ 2 hours)' — extend the ontology if this is a real PK parameter (source ['Tamai_2017_table_p5_1:row24:col1'])</li><li>covariate effect for Q40 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lenvatinib</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>model-stage split: 'base model population mean (%rse)' is the base model of Tamai_2017 (paper reports 4 stages: base model interindividual variability (%cv), base model population mean (%rse), final model interindividual variability (%cv), final model population mean (%rse)); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Lenvatinib_Tamai2017_base_base_model_population_mean_rse;
