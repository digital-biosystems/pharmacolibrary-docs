% Run (SimBiology): build model + dose, simulate 0..28.0 h, plot.
p = Lenvatinib_Tamai2017_base_base_model_population_mean_rse_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 28.0);
