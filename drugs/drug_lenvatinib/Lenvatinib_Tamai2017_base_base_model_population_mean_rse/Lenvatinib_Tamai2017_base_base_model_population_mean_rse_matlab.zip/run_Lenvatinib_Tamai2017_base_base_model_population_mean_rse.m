% Run: build params, simulate 0..28.0 h, plot + save Lenvatinib_Tamai2017_base_base_model_population_mean_rse.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Lenvatinib_Tamai2017_base_base_model_population_mean_rse.m
here = fileparts(mfilename('fullpath'));
p = Lenvatinib_Tamai2017_base_base_model_population_mean_rse_params();
out = simulate_pk(p, 0:0.05:28.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('lenvatinib — Tamai_2017 (oral)');
print(fig, fullfile(here, 'Lenvatinib_Tamai2017_base_base_model_population_mean_rse.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Lenvatinib_Tamai2017_base_base_model_population_mean_rse.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Lenvatinib_Tamai2017_base_base_model_population_mean_rse.json'), 'w');
try
  s.model = 'Lenvatinib_Tamai2017_base_base_model_population_mean_rse'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Lenvatinib_Tamai2017_base_base_model_population_mean_rse","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Lenvatinib_Tamai2017_base_base_model_population_mean_rse.png, Lenvatinib_Tamai2017_base_base_model_population_mean_rse.csv, Lenvatinib_Tamai2017_base_base_model_population_mean_rse.json\n');
