function p = Lenvatinib_Tamai2017_base_base_model_population_mean_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lenvatinib   source: Tamai_2017 / base_base_model_population_mean_rse   route: oral
  p.name  = 'Lenvatinib_Tamai2017_base_base_model_population_mean_rse_params';
  p.drug  = 'lenvatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.6;                % central volume [L]
  p.CL = 6.5;                % clearance [L/h]
  p.Vp = [31.4];             % peripheral volumes [L]
  p.Q  = [3.91];             % inter-compartmental clearances [L/h]
  p.ka = 1.02;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 8.0;             % dose [mg]
end
