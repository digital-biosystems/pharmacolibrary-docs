model Lenvatinib_Hayato2018_PD_y
  "emax exposure-response sweep — Hayato_2018 :: y (sum of diameters of all target lesions)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.37896825397e-07,  // [1/s; /week × 1.65344e-06]
    EC50 = 2.03,  // [µg h/mL]
    gamma = 1,
    exposure_per_s = 1);   // 1 µg h/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'µg h/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 21, Interval = 0.042),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lenvatinib</h4><p>Lenvatinib is a protein kinase inhibitor used to treat renal cell carcinoma and various forms of thyroid cancer. It is administered orally, typically in capsule form. The medication is authorised in the European Union and is used in other regions as well.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q6523413\">Wikidata Q6523413</a>, <a href=\"https://en.wikipedia.org/wiki/Lenvatinib?oldid=1376981185\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lenvatinib_Hayato2018_PD_y</h4><p>The steady-state exposure-response curve of Hayato S et al., <i>Cancer chemotherapy and pharmacology 82(6):971–978</i> 2018 (<a href=\"https://doi.org/10.1007/s00280-018-3687-4\">doi:10.1007/s00280-018-3687-4</a>) — sum of diameters of all target lesions [mm] against lenvatinib µg h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0834 /week    maximal effect term (Emax, Q323)
  EC50  =       2.03 µg h/mL  exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg h/mL of lenvatinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.03 µg h/mL)  response -6.895e-08
  exposure -> infinity  response -1.379e-07</pre></body></html>"));
end Lenvatinib_Hayato2018_PD_y;
