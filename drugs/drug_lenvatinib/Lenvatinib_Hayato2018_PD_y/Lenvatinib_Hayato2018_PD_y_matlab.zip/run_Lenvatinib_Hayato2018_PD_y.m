% run_Lenvatinib_Hayato2018_PD_y  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Lenvatinib_Hayato2018_PD_y_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [µg h/mL]'); ylabel('response [mm]'); title('Lenvatinib_Hayato2018_PD_y', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Lenvatinib_Hayato2018_PD_y.csv');
