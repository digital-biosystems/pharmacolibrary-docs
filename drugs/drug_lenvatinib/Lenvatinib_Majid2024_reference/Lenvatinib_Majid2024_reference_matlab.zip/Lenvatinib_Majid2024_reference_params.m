function p = Lenvatinib_Majid2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lenvatinib   source: Majid_2024 / reference   route: oral
  p.name  = 'Lenvatinib_Majid2024_reference_params';
  p.drug  = 'lenvatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.0;                % central volume [L]
  p.CL = 6.28;                % clearance [L/h]
  p.Vp = [28.3];             % peripheral volumes [L]
  p.Q  = [3.57];             % inter-compartmental clearances [L/h]
  p.ka = 0.803;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
