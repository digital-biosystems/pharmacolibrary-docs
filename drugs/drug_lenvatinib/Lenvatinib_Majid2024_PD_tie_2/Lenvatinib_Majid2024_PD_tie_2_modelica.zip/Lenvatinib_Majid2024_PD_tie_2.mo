model Lenvatinib_Majid2024_PD_tie_2
  "indirect_response_i exposure-response sweep — Majid_2024 :: Tie-2 (Tie-2)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.46e-08,      // [kg/m3; ng/L × 1e-09]
    Emax = 0.344,  // type I effect term
    EC50 = 930,  // [ng*h/mL]
    gamma = 0.313,
    exposure_per_s = 1);   // 1 ng*h/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'ng*h/mL' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 9300, Interval = 18.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lenvatinib</h4><p>Lenvatinib is a protein kinase inhibitor used to treat renal cell carcinoma and various forms of thyroid cancer. It is administered orally, typically in capsule form. The medication is authorised in the European Union and is used in other regions as well.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q6523413\">Wikidata Q6523413</a>, <a href=\"https://en.wikipedia.org/wiki/Lenvatinib?oldid=1376981185\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lenvatinib_Majid2024_PD_tie_2</h4><p>The steady-state exposure-response curve of Majid O et al., <i>CPT: pharmacometrics &amp; systems pharmacology 13(6):954–969</i> 2024 (<a href=\"https://doi.org/10.1002/psp4.13130\">doi:10.1002/psp4.13130</a>) — Tie-2 [ng/L] against lenvatinib ng*h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       14.6 ng/L     drug-free response (baseline) (Baseline (ng/L), Q324)
  Emax  =      0.344          maximal effect term (E max, Q323)
  EC50  =        930 ng*h/mL  exposure at half of the maximal effect term (EC50 (ng*h/mL), Q321)
  gamma =      0.313          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng*h/mL of lenvatinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.46e-08   (drug-free)
  exposure = EC50 (930 ng*h/mL)  response 1.209e-08
  exposure -> infinity  response 9.578e-09</pre></body></html>"));
end Lenvatinib_Majid2024_PD_tie_2;
