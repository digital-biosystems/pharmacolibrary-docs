model Colistin_Boonyasiri2025_reference
  parameter Real Cl_ref = 4.694444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0502 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>colistin</td></tr><tr><td>population:</td><td>critically-ill patients on sustained low-efficiency dialysis</td></tr><tr><td>source_paper:</td><td>Boonyasiri_2025</td></tr><tr><td>measured_compound:</td><td>colistin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('apparent colistin SLED clearance', value 3.49) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=colistin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Colistin_Boonyasiri2025_reference;
