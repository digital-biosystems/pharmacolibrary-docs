model Rimegepant_Comisar2025_reference
  parameter Real Cl_ref = 7e-06 "Cl [m3/s]";
  parameter Real cov_hepatic_0 = 0 "hepatic covariate";
  parameter Real cov_formulation_1 = 0 "formulation covariate";
  parameter Real cov_hepatic_2 = 0 "hepatic covariate";
  parameter Real cov_body_weight_3 = 0 "body weight covariate";
  parameter Real cov_body_weight_4 = 0 "body weight covariate";
  parameter Real Vd_ref = 0.113 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.41)*cov_hepatic_0)*(1 + (2.19)*cov_formulation_1)*(1 + (-0.203)*cov_hepatic_2)*(1 + (0.575)*cov_body_weight_3)*(1 + (1.18)*cov_body_weight_4),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5345679999999999,
    adminMass = 1e-05,
    ka = 0.0008472222222222222,
    Tlag = 0.0,
    k12 = 1.0226155358898721e-05,
    k21 = 2.4691358024691357e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rimegepant</h4><p>Rimegepant is a calcitonin gene-related peptide receptor antagonist used to treat acute migraine attacks in adults. It is an approved medicine and is authorised in the European Union for migraine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27272184\">Wikidata Q27272184</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rimegepant</td></tr><tr><td>population:</td><td>pediatric and adult patients with migraine</td></tr><tr><td>source_paper:</td><td>Comisar_2025</td></tr><tr><td>measured_compound:</td><td>rimegepant</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70360-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rimegepant 534.568 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('IIV% (%RSE)')</li><li>table section iiv: 'V1/F, L' routed out of structural estimates ('IIV% (%RSE)')</li><li>table section iiv: 'V2/F, L' routed out of structural estimates ('IIV% (%RSE)')</li><li>table section iiv: 'k tr, 1/h' routed out of structural estimates ('IIV% (%RSE)')</li><li>table section iiv: 'ω1,2: CL/F:V1/F' routed out of structural estimates ('IIV% (%RSE)')</li><li>table section iiv: 'ω1,3: CL/F:V2/F' routed out of structural estimates ('IIV% (%RSE)')</li><li>table section iiv: 'ω2,3: V1/F:V2/F' routed out of structural estimates ('IIV% (%RSE)')</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'estimate (%rse)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rimegepant_Comisar2025_reference;
