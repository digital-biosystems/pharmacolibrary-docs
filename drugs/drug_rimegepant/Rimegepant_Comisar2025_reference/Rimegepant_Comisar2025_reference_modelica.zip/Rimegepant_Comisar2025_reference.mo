model Rimegepant_Comisar2025_reference
  parameter Real Cl_ref = 7e-06 "Cl [m3/s]";
  parameter Real cov_fed_0 = 0 "fed covariate";
  parameter Real cov_formulation_1 = 0 "formulation covariate";
  parameter Real cov_body_weight_2 = 0 "body weight covariate";
  parameter Real cov_body_weight_3 = 0 "body weight covariate";
  parameter Real cov_hepatic_4 = 0 "hepatic covariate";
  parameter Real cov_hepatic_5 = 0 "hepatic covariate";
  parameter Real Vd_ref = 0.113 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.331)*cov_fed_0)*(1 + (2.19)*cov_formulation_1)*(1 + (0.575)*cov_body_weight_2)*(1 + (1.18)*cov_body_weight_3)*(1 + (-0.41)*cov_hepatic_4)*(1 + (-0.203)*cov_hepatic_5),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0008472222222222222,
    Tlag = 0.0,
    k12 = 1.0226155358898721e-05,
    k21 = 2.4691358024691357e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rimegepant</td></tr><tr><td>population:</td><td>pediatric and adult patients with migraine</td></tr><tr><td>source_paper:</td><td>Comisar_2025</td></tr><tr><td>measured_compound:</td><td>rimegepant</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70360-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('Fluconazole use on CL/F', value '-0.429') — already have one for this compound</li><li>dropped duplicate Q27 ('Itraconazole use on CL/F', value '-0.744') — already have one for this compound</li><li>covariate level 'Fed on F1' → Q900:fed_on_f1 = -0.331 (linear_fractional on Q27)</li><li>relinked 'ODT on k tr' Q338 → Q306 — same-named PK parameter preferred over the PD code in a popPK record</li><li>dropped duplicate Q306 ('ODT on k tr', value '0.470') — already have one for this compound</li><li>covariate level 'Capsule formulation on k tr' → Q900:capsule_formulation_on_k_tr = 2.19 (linear_fractional on Q27)</li><li>relinked 'Itraconazole use on k tr' Q338 → Q306 — same-named PK parameter preferred over the PD code in a popPK record</li><li>dropped duplicate Q306 ('Itraconazole use on k tr', value '-0.361') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Dose effect on F1' — extend the ontology if this is a real PK parameter (source ['cts70360-tbl-0002:row16:col1'])</li><li>relinked '10/25 mg dose effect on k tr a' Q338 → Q306 — same-named PK parameter preferred over the PD code in a popPK record</li><li>dropped duplicate Q306 ('10/25 mg dose effect on k tr a', value '0.596') — already have one for this compound</li><li>covariate level 'Body weight effect on CL/F and Q/F' → Q900:body_weight_effect_on_cl_f_and_q_f = 0.575 (linear_fractional on Q27)</li><li>covariate level 'Body weight effect on V1/F and V2/F' → Q900:body_weight_effect_on_v1_f_and_v2_f = 1.18 (linear_fractional on Q27)</li><li>dropped value-less row: 'ω1,2: CL/F:V1/F'</li><li>dropped value-less row: 'ω1,3: CL/F:V2/F'</li><li>covariate effect for Q338 has no base parameter row (kept as unattached equation-variable)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rimegepant_Comisar2025_reference;
