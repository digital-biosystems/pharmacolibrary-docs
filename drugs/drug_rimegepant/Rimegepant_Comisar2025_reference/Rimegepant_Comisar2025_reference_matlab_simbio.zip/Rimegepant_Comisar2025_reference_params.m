function p = Rimegepant_Comisar2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rimegepant   source: Comisar_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rimegepant_Comisar2025_reference_params';
  p.drug  = 'rimegepant';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 113.0;                % central volume [L]
  p.CL = 25.2;                % clearance [L/h]
  p.Vp = [46.8];             % peripheral volumes [L]
  p.Q  = [4.16];             % inter-compartmental clearances [L/h]
  p.ka = 3.05;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
