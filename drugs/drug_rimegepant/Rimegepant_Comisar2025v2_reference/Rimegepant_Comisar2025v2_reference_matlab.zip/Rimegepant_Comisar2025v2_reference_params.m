function p = Rimegepant_Comisar2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rimegepant   source: Comisar_2025_2 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Rimegepant_Comisar2025v2_reference_params';
  p.drug  = 'rimegepant';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 114.0;                % central volume [L]
  p.CL = 24.1;                % clearance [L/h]
  p.Vp = [46.0];             % peripheral volumes [L]
  p.Q  = [3.94];             % inter-compartmental clearances [L/h]
  p.ka = 3.86;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
