function p = Lamivudine_Chandasana2024v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lamivudine   source: Chandasana_2024_2 / reference   route: oral
  p.name  = 'Lamivudine_Chandasana2024v2_reference_params';
  p.drug  = 'lamivudine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.7;                % central volume [L]
  p.CL = 0.858;                % clearance [L/h]
  p.Vp = [105.0];             % peripheral volumes [L]
  p.Q  = [2.97];             % inter-compartmental clearances [L/h]
  p.ka = 2.15;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
