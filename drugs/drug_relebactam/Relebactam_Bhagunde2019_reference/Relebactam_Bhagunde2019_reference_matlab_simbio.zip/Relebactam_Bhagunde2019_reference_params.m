function p = Relebactam_Bhagunde2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: relebactam   source: Bhagunde_2019 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Relebactam_Bhagunde2019_reference_params';
  p.drug  = 'relebactam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.08;                % central volume [L]
  p.CL = 7.02;                % clearance [L/h]
  p.Vp = [6.41];             % peripheral volumes [L]
  p.Q  = [10.45];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
