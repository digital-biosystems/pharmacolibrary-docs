model Relebactam_Patel2022_reference
  parameter Real Cl_ref = 2.0083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0112 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34837,
    adminMass = 0.00025,
    k12 = 0.00027033730158730157,
    k21 = 0.0004923215898825654
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About relebactam</h4><p>Relebactam is a beta-lactamase inhibitor used to treat serious bacterial infections, given alongside a carbapenem antibiotic. It is an approved medicine, used mainly in hospital settings for infections caused by resistant bacteria.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27252695\">Wikidata Q27252695</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>relebactam</td></tr><tr><td>population:</td><td>adults with hospital-acquired/ventilator-associated bacterial pneumonia</td></tr><tr><td>source_paper:</td><td>Patel_2022</td></tr><tr><td>measured_compound:</td><td>relebactam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13158-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>relebactam 348.37 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CrCl (power)' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row8:col5', 'cts13158-tbl-0003:row8:col7'])</li><li>dropped unlinked row (NIL): 'Pneumonia f' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row10:col5', 'cts13158-tbl-0003:row10:col7', 'cts13158-tbl-0003:row13:col5', 'cts13158-tbl-0003:row13:col7'])</li><li>dropped unlinked row (NIL): 'WT (power)' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row12:col5', 'cts13158-tbl-0003:row12:col7'])</li><li>dropped unlinked row (NIL): 'Ventilation g' — extend the ontology if this is a real PK parameter (source ['cts13158-tbl-0003:row14:col5', 'cts13158-tbl-0003:row14:col7'])</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V1' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V2' from footnote/prose loose number None (source ['cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Q' from footnote/prose loose number 10.93 (source ['cts13158-tbl-0003:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=relebactam</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Relebactam_Patel2022_reference;
