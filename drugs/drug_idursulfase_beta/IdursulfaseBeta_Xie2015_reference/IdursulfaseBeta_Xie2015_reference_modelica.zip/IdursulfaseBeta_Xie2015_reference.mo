model IdursulfaseBeta_Xie2015_reference
  parameter Real Cl_ref = 1.1180555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.024969444420185734 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About idursulfase_beta</h4><p>Idursulfase beta is an enzyme replacement therapy investigated for treating Hunter syndrome, a rare inherited metabolic disorder. It remains investigational and is not an approved treatment in the European Union.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>idursulfase_beta</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Xie_2015</td></tr><tr><td>measured_compound:</td><td>idursulfase_beta</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Xie_2015) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end IdursulfaseBeta_Xie2015_reference;
