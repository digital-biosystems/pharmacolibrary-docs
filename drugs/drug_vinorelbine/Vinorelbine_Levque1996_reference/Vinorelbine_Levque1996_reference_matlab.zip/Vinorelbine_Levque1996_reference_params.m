function p = Vinorelbine_Levque1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vinorelbine   source: Levêque_1996 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Vinorelbine_Levque1996_reference_params';
  p.drug  = 'vinorelbine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4900.0;                % central volume [L]
  p.CL = 46.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.27;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
