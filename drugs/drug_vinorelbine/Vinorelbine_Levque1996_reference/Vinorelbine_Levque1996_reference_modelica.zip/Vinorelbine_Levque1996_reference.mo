model Vinorelbine_Levque1996_reference
  parameter Real Cl_ref = 1.2833333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 4.9 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7789470000000001,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vinorelbine</h4><p>Vinorelbine is a vinca alkaloid chemotherapy agent used to treat breast cancer, ovarian cancer, non-small-cell lung carcinoma, and Hodgkin's lymphoma. It is administered intravenously or orally, with good absorption when taken by mouth.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q420532\">Wikidata Q420532</a>, <a href=\"https://en.wikipedia.org/wiki/Vinorelbine?oldid=1368466305\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinorelbine</td></tr><tr><td>population:</td><td>adults with cancer</td></tr><tr><td>source_paper:</td><td>Levêque_1996</td></tr><tr><td>measured_compound:</td><td>vinorelbine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vinorelbine 778.947 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'systemic clearance'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vinorelbine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Vinorelbine_Levque1996_reference;
