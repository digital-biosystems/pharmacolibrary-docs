model Rilpivirine_Thoueille2024_reference
  parameter Real Cl_ref = 1.8722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3664185,
    adminMass = 2.5e-05,
    ka = 5.944444444444445e-07,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rilpivirine</h4><p>It is authorised in the European Union for HIV and is used both alone and in combination antiviral products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421547\">Wikidata Q421547</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rilpivirine</td></tr><tr><td>population:</td><td>people with HIV in routine clinical care</td></tr><tr><td>source_paper:</td><td>Thoueille_2024</td></tr><tr><td>measured_compound:</td><td>rilpivirine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rilpivirine 366.418 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameters'</li><li>dropped duplicate Q87 ('Fi.m.fast (%)', value '27.6') — already have one for this compound</li><li>dropped duplicate Q49 ('kaslow (h−1)', value '0.000229') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V4 (L)' — extend the ontology if this is a real PK parameter (source ['T2:row12:col1'])</li><li>dropped value-less row: 'Foral'</li><li>dropped value-less row: 'Doral'</li><li>dropped value-less row: 'Fi.m.fast'</li><li>dropped value-less row: 'kafast'</li><li>dropped value-less row: 'kaslow'</li><li>dropped value-less row: 'V3'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'V4'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'ω'</li><li>NIL: refused to back-fill base 'prop_error' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Rilpivirine_Thoueille2024_reference;
