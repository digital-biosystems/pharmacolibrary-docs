function p = Rilpivirine_Aouri2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rilpivirine   source: Aouri_2017 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Rilpivirine_Aouri2017_reference_params';
  p.drug  = 'rilpivirine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 401.0;                % central volume [L]
  p.CL = 11.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.000215;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
