model Rilpivirine_Aouri2017_reference
  parameter Real Cl_ref = 3.2500000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.401 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3664185,
    adminMass = 1.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rilpivirine</h4><p>Rilpivirine belongs to the non-nucleoside reverse transcriptase inhibitor class and treats HIV infections. It is administered orally as a tablet or intramuscularly as an injection. This medication is authorised for HIV treatment in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421547\">Wikidata Q421547</a>, DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rilpivirine</td></tr><tr><td>population:</td><td>HIV-1-infected individuals</td></tr><tr><td>source_paper:</td><td>Aouri_2017</td></tr><tr><td>measured_compound:</td><td>rilpivirine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rilpivirine 366.418 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=rilpivirine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Rilpivirine_Aouri2017_reference;
