model SodiumNitrate_Veszelovsky1995_reference
  parameter Real Cl_ref = 8.88888888888889e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0497 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.062004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_nitrate</td></tr><tr><td>population:</td><td>C3H and BDF1 mice</td></tr><tr><td>source_paper:</td><td>Veszelovsky_1995</td></tr><tr><td>measured_compound:</td><td>Nitrate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Nitrate 62.004 g/mol (pubchem); sodium_nitrate 84.994 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l/h-1/kg-1' (CL)</li><li>implicit units: 'the clearance' → L/h (from the popPK convention: 'No unit stated in text. Clearance values in population PK are typically expressed in L/h, consistent with the magnitude ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Nitrate</li><li>toxin: 3 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Nitrate', not sodium_nitrate — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end SodiumNitrate_Veszelovsky1995_reference;
