function p = Prednisone_Bouazza2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: prednisone   source: Bouazza_2025 / reference   route: oral
  p.name  = 'Prednisone_Bouazza2025_reference_params';
  p.drug  = 'prednisone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16450.0;                % central volume [L]
  p.CL = 3801.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.19;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.17;             % absorption lag [h]
  p.dose = 80000.0;             % dose [mg]
end
