model Prednisone_Bouazza2025_reference
  parameter Real Cl_ref = 0.0010558333333333333 "Cl [m3/s]";
  parameter Real Vd_ref = 16.45 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.08,
    ka = 0.00033055555555555556,
    Tlag = 612.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>systemic lupus erythematosus patients</td></tr><tr><td>source_paper:</td><td>Bouazza_2025</td></tr><tr><td>measured_compound:</td><td>prednisolone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70103-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'covariate effect' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'covariate effect' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'covariate effect' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'βFdose' — extend the ontology if this is a real PK parameter (source ['bcp70103-tbl-0002:row4:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=prednisolone</li><li>review gap-fill skipped: this record measures 'prednisolone', not prednisone — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisone_Bouazza2025_reference;
