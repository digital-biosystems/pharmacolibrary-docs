model Prednisone_de2023_reference
  parameter Real Cl_ref = 7.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.101 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>paediatric kidney transplant recipients</td></tr><tr><td>source_paper:</td><td>de_2023</td></tr><tr><td>measured_compound:</td><td>prednisolone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=prednisolone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'prednisolone', not prednisone — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisone_de2023_reference;
