// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SelenicAcid_Jger20162_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {53280.0},
    adminMass = 1.0000000000000001e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>selenic_acid</td></tr><tr><td>population:</td><td>healthy human volunteers</td></tr><tr><td>source_paper:</td><td>Jäger_2016_2</td></tr><tr><td>measured_compound:</td><td>total selenium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>selenate 144.983 g/mol (pubchem); sodium selenite 172.948 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('elimination half-life'=14.8) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=total selenium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'SeSug1' ('no full name in the paper') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'SeSug3' ('no full name in the paper') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'TMSe' ('trimethylselenide') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'total selenium' ('total selenium') — left in mass units</li><li>molar mass: none found for 'SeSug1' — its concentrations stay mass-only</li><li>molar mass: none found for 'SeSug3' — its concentrations stay mass-only</li><li>molar mass: none found for 'TMSe' — its concentrations stay mass-only</li><li>molar mass: none found for 'total selenium' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'total selenium', not selenic_acid — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end SelenicAcid_Jger20162_reference;
