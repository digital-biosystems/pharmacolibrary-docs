// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SelenicAcid_Lanctt2017_seiv
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {185760.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>selenic_acid</td></tr><tr><td>population:</td><td>Limnodynastes peronii tadpoles</td></tr><tr><td>source_paper:</td><td>Lanctôt_2017</td></tr><tr><td>measured_compound:</td><td>Selenium (75Se)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>selenic_acid 144.983 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Iu' — extend the ontology if this is a real PK parameter (source ['Lanctôt_2017_table_1:row0:col1'])</li><li>dropped 'ku' → Q49: the uptake rate from the exposure medium (bioaccumulation), not a body toxicokinetic parameter</li><li>dropped unlinked row (NIL): 'RE' — extend the ontology if this is a real PK parameter (source ['Lanctôt_2017_table_1:row3:col1'])</li><li>implicit units: 'BCF' — the LLM proposed 'mL/g', whose dimension does not fit Q30; left unset</li><li>implicit units: 'ke' → d^-1 (from the paper text: &quot;Table 1 caption: 'elimination rate (ke, d -1)'&quot;)</li><li>implicit units: 't 1/2' → d (from the paper text: &quot;Table 1 caption: 'depuration curve half time (t 1/2 , d)'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Selenium (75Se)</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'seiv' subgroup of Lanctôt_2017 (paper reports 2 populations: seiv, sevi)</li><li>molar mass: no plausible PubChem entry for 'Selenium (75Se)' ('Selenium (75Se)') — left in mass units</li><li>molar mass: none found for 'Selenium (75Se)' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Selenium (75Se)', not selenic_acid — the review values are the parent's</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q30 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1900.8));
end SelenicAcid_Lanctt2017_seiv;
