// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SelenicAcid_Lanctt2017_sevi
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {198719.99999999997},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>selenic_acid</td></tr><tr><td>population:</td><td>Limnodynastes peronii tadpoles</td></tr><tr><td>source_paper:</td><td>Lanctôt_2017</td></tr><tr><td>measured_compound:</td><td>Selenium (75Se)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>selenic_acid 144.983 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Iu' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Lanctôt_2017_table_1:row0:col2'])</li><li>dropped 'ku' → Q349: the uptake rate from the exposure medium (bioaccumulation), not a body toxicokinetic parameter</li><li>dropped unlinked row (NIL): 'BCF' — extend the ontology if this is a real PK parameter (source ['Lanctôt_2017_table_1:row2:col2'])</li><li>dropped unlinked row (NIL): 'RE' — extend the ontology if this is a real PK parameter (source ['Lanctôt_2017_table_1:row3:col2'])</li><li>implicit units: 'ke' → 1/d (from the paper text: &quot;Table 1 caption states 'elimination rate (ke, d -1 )' and text excerpts define elimination rate contextually in days.&quot;)</li><li>implicit units: 't 1/2' → d (from the paper text: &quot;Table 1 caption states 'depuration curve half time (t 1/2 , d)'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Selenium (75Se)</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'sevi' subgroup of Lanctôt_2017 (paper reports 2 populations: seiv, sevi)</li><li>molar mass: no plausible PubChem entry for 'Selenium (75Se)' ('Selenium (75Se)') — left in mass units</li><li>molar mass: none found for 'Selenium (75Se)' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Selenium (75Se)', not selenic_acid — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end SelenicAcid_Lanctt2017_sevi;
