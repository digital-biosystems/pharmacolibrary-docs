model Captopril_Kiriyama2024_PD_qt
  "indirect_response_i exposure-response sweep — Kiriyama_2024 :: QT (QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0968,      // [s; ms × 0.001]
    Emax = 0.0117,  // type I effect term
    EC50 = 8.63e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.662,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 863, Interval = 1.726));
end Captopril_Kiriyama2024_PD_qt;
