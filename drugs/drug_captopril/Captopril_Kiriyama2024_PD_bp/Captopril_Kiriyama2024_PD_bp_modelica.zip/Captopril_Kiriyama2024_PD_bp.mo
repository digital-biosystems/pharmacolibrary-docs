model Captopril_Kiriyama2024_PD_bp
  "indirect_response_i exposure-response sweep — Kiriyama_2024 :: BP (blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 96.8,      // [mmHg]
    Emax = 0.0117,  // type I effect term
    EC50 = 8.63e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.662,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 863, Interval = 1.726));
end Captopril_Kiriyama2024_PD_bp;
