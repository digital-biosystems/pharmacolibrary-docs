model Mangafodipir_Toft1997_reference
  parameter Real Cl_ref = 8.086717106532696e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.757328,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mangafodipir</td></tr><tr><td>population:</td><td>beagle dogs</td></tr><tr><td>source_paper:</td><td>Toft_1997</td></tr><tr><td>measured_compound:</td><td>Mangafodipir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Mangafodipir 757.328 g/mol (pubchem); MnPLED 478.502 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Toft_1997:abstract', 'Toft_1997:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Toft_1997:abstract', 'Toft_1997:abstract'])</li><li>dropped duplicate Q57 ('half-life', value '52.5') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Mangafodipir</li><li>toxin: 5 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 0 linked by role</li><li>molar mass: no plausible PubChem entry for 'MnDPMP' ('MnDPMP') — left in mass units</li><li>molar mass: no plausible PubChem entry for 'ZnPLED' ('ZnPLED') — left in mass units</li><li>molar mass: none found for 'MnDPMP' — its concentrations stay mass-only</li><li>molar mass: none found for 'ZnPLED' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL/F=29.1122 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mangafodipir_Toft1997_reference;
