// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Metamizole_Blaser2021_4_aaa
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0116},
    CLelim = {3.333333333333333e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metamizole</td></tr><tr><td>population:</td><td>healthy salt-depleted adults</td></tr><tr><td>source_paper:</td><td>Blaser_2021</td></tr><tr><td>measured_compound:</td><td>4-methylaminoantipyrine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr></table><h4>Interpretation flags</h4><ul><li>column '4-aaa' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '4-aaa' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>salvaged Q22 ('average inulin clearance in our study was approximately'=20) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-methylaminoantipyrine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 4 first-order transfer(s) across 5 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>population split: '4-aaa' subgroup of Blaser_2021 (paper reports 6 populations: 4-aa, 4-aaa, 4-faa, 4-maa, metamizole (n = 8), naproxen (n = 7))</li><li>gap-filled Q61 (V) from Ekobena_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ekobena_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metamizole_Blaser2021_4_aaa;
