% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Metamizole_Blaser2021_4_maa_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
