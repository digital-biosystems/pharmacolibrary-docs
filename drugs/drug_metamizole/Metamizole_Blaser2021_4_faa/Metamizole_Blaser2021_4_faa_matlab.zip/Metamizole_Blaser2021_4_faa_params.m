function p = Metamizole_Blaser2021_4_faa_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metamizole   source: Blaser_2021 / 4_faa   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Metamizole_Blaser2021_4_faa_params';
  p.drug  = 'metamizole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.6;                % central volume [L]
  p.CL = 1.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.235;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
