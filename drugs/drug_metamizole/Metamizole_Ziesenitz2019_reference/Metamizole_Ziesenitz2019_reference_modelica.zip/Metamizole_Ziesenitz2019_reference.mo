// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Metamizole_Ziesenitz2019_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0116},
    CLelim = {1.277777777777778e-07},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = {}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metamizole</td></tr><tr><td>population:</td><td>infants and children</td></tr><tr><td>source_paper:</td><td>Ziesenitz_2019</td></tr><tr><td>measured_compound:</td><td>4-methylaminoantipyrine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=4-methylaminoantipyrine</li><li>topology: 4 first-order transfer(s) across 4 compounds → general_linear</li><li>gap-filled Q22 (CL) from Ekobena_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Ekobena_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ekobena_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Ekobena_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metamizole_Ziesenitz2019_reference;
