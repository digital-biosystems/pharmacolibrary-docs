function p = Pertuzumab_Sun2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pertuzumab   source: Sun_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pertuzumab_Sun2022_reference_params';
  p.drug  = 'pertuzumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.4409;                % central volume [L]
  p.CL = 0.00963;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
