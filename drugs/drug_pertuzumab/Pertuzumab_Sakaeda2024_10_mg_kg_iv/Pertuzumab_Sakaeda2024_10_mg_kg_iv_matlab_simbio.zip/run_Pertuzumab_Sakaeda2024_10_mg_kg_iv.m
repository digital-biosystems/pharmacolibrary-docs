% Run (SimBiology): build model + dose, simulate 0..3192.0 h, plot.
p = Pertuzumab_Sakaeda2024_10_mg_kg_iv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3192.0);
