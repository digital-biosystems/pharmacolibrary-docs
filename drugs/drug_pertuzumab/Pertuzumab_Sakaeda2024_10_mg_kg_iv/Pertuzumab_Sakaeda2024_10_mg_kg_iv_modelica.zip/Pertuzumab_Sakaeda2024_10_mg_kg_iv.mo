model Pertuzumab_Sakaeda2024_10_mg_kg_iv
  parameter Real Cl_ref = 1.8433333333333334e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004011 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pertuzumab</h4><p>Pertuzumab is a monoclonal antibody that blocks HER2 and is used to treat breast cancer. It is an approved medicine, authorised in the European Union for breast cancer, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1998021\">Wikidata Q1998021</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pertuzumab</td></tr><tr><td>population:</td><td>healthy adult males</td></tr><tr><td>source_paper:</td><td>Sakaeda_2024</td></tr><tr><td>measured_compound:</td><td>pertuzumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 4</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'μg・h/mL' (AUC∞)</li><li>unit_dimension_unknown: 'μg・h/mL' (AUCt)</li><li>implicit units: 'AUCinf (μg・h/mL)' → μg·h/mL (from the paper text: &quot;The parameter label in the input explicitly includes the unit: 'AUCinf (μg・h/mL)'. Additionally, the text describing Tab&quot;)</li><li>implicit units: 'AUC0-672h (μg・h/mL)' → μg·h/mL (from the paper text: &quot;The parameter label in the input explicitly includes the unit: 'AUC0-672h (μg・h/mL)'. The text for Table 3 also defines &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pertuzumab</li><li>population split: '投与グループ (n=5/グループ) 10 mg/kg ベルツスマブ (iv)' subgroup of Sakaeda_2024 (paper reports 7 populations: 108 mg/動物 トラスツズマブ 0 u rhuph20, 108 mg/動物 トラスツズマブ 2,000 u rhuph20, 108 mg/動物 トラスツズマブ 6,000 u rhuph20, 216 mg/動物 トラスツズマブ 4,000 u rhuph20, 投与グループ (n=5/グループ) 10 mg/kg ベルツスマブ (iv), 投与グループ (n=5/グループ) 120 mg/動物 ベルツスマブ+ 2,000 u rhuph20 (sc), 投与グループ (n=5/グループ) 120 mg/動物 ベルツスマブ+ 2,000 u rhuph20 及び 120 mg/動物 トラスツズマブ+ 2,000 u rhuph20 (sc))</li><li>molar mass: none found for 'pertuzumab' — its concentrations stay mass-only</li><li>gap-filled Q61 (V) from Luo_2017's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 11491200, Tolerance = 1e-9, Interval = 1));
end Pertuzumab_Sakaeda2024_10_mg_kg_iv;
