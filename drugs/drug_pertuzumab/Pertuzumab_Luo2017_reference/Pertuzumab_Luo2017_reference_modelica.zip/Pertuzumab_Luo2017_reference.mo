model Pertuzumab_Luo2017_reference
  parameter Real Cl_ref = 1.4664351851851851e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004011 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pertuzumab</h4><p>Pertuzumab is a monoclonal antibody that blocks HER2 and is used to treat breast cancer. It is an approved medicine, authorised in the European Union for breast cancer, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1998021\">Wikidata Q1998021</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pertuzumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Luo_2017</td></tr><tr><td>measured_compound:</td><td>pertuzumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Luo_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Pertuzumab_Luo2017_reference;
