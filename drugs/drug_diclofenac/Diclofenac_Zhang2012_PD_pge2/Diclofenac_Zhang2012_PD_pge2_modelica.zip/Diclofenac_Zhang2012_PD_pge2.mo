model Diclofenac_Zhang2012_PD_pge2
  "sigmoid_emax exposure-response sweep — Zhang_2012 :: PGE2 (prostaglandin E2)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.39e-05,      // [kg/m3; ng/mL × 1e-06]
    Emax = -5.48e-05,  // [kg/m3; ng/mL × 1e-06]
    EC50 = 0.0012999999999999997,  // [kg/m3; µg/mL × 0.001]
    gamma = 1.0,
    exposure_per_s = 0.0009999999999999998);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026));
end Diclofenac_Zhang2012_PD_pge2;
