function p = Diclofenac_Perez1995_PD_relaxation_params()
% Diclofenac_Perez1995_PD_relaxation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% diclofenac Perez_1995::relaxation: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pM per second, in SI inside (kg/m3, s). Response relaxation in %. Driver: diclofenac (cited_pk).
p.E0 = 0.0;
p.Emax = 0.951;
p.EC50 = 17.3;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 180.0;
p.form = 'E0 + Emax*frac';
end
