model Diclofenac_Perez1995_PD_relaxation
  "emax exposure-response sweep — Perez_1995 :: relaxation (relaxation of vanadate-induced contraction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.951,  // [1; % × 0.01]
    EC50 = 17.3,  // [pM]
    gamma = 1,
    exposure_per_s = 1);   // 1 pM per second
  // exposure_unit_unresolved: 'pM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 180, Interval = 0.36),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diclofenac</h4><p>Diclofenac is a non-steroidal anti-inflammatory drug and painkiller used for painful and inflammatory conditions such as osteoarthritis, rheumatoid arthritis, gout, migraine, and other musculoskeletal problems. It is widely used in human medicine in many forms, including tablets, skin preparations, and eye drops, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244408\">Wikidata Q244408</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diclofenac_Perez1995_PD_relaxation</h4><p>The steady-state exposure-response curve of Perez Vallina JR et al., <i>General pharmacology 26(6):1249–1253</i> 1995 (<a href=\"https://doi.org/10.1016/0306-3623(95)00018-v\">doi:10.1016/0306-3623(95)00018-v</a>) — relaxation of vanadate-induced contraction [%] against diclofenac pM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       95.1 %        maximal effect term (Emax, Q320)
  EC50  =       17.3 pM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pM of diclofenac per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (17.3 pM)  response 0.4755
  exposure -> infinity  response 0.951</pre></body></html>"));
end Diclofenac_Perez1995_PD_relaxation;
