function p = Diclofenac_Hannam2014_PD_vas_params()
% Diclofenac_Hannam2014_PD_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% diclofenac Hannam_2014::VAS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·l(-1) per second, in SI inside (kg/m3, s). Response VAS in VAS 0-10. Driver: diclofenac (with acetaminophen) (not_resolved).
p.E0 = 0.0;
p.Emax = -4.9;
p.EC50 = 0.0012299999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 13.0;
p.form = 'E0 + Emax*frac';
end
