model Diclofenac_Hannam2014_PD_vas
  "sigmoid_emax exposure-response sweep — Hannam_2014 :: VAS (postoperative pain (visual analogue score))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.9,  // [VAS 0-10]
    EC50 = 0.00123,  // [kg/m3; mg·l(-1) × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg·l(-1) per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><h4>Diclofenac_Hannam2014_PD_vas</h4><p>The steady-state exposure-response curve of Hannam JA et al., <i>Paediatric anaesthesia 24(9):953–961</i> 2014 (<a href=\"https://doi.org/10.1111/pan.12422\">doi:10.1111/pan.12422</a>) — postoperative pain (visual analogue score) [VAS 0-10] against diclofenac (with acetaminophen) mg·l(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        4.9 VAS 0-10 maximal effect term (maximum effect, Q320)
  EC50  =       1.23 mg·l(-1) exposure at half of the maximal effect term (concentration resulting in 50% of EMAX, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·l(-1) of diclofenac (with acetaminophen) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.23 mg·l(-1))  response -2.45
  exposure -> infinity  response -4.9</pre></body></html>"));
end Diclofenac_Hannam2014_PD_vas;
