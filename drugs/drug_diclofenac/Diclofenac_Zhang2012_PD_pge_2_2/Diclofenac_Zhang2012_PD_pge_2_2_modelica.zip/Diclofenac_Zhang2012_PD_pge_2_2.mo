model Diclofenac_Zhang2012_PD_pge_2_2
  "sigmoid_emax exposure-response sweep — Zhang_2012 :: PGE 2 (prostaglandin E 2)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.39e-05,      // [kg/m3; ng/mL × 1e-06]
    Emax = -5.48e-05,  // [kg/m3; ng/mL × 1e-06]
    EC50 = 0.0013,  // [kg/m3; µg/mL × 0.001]
    gamma = 2,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diclofenac</h4><p>Diclofenac is a non-steroidal anti-inflammatory drug and painkiller used for painful and inflammatory conditions such as osteoarthritis, rheumatoid arthritis, gout, migraine, and other musculoskeletal problems. It is widely used in human medicine in many forms, including tablets, skin preparations, and eye drops, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244408\">Wikidata Q244408</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diclofenac_Zhang2012_PD_pge_2_2</h4><p>The steady-state exposure-response curve of Zhang J et al., <i>Acta pharmacologica Sinica 33(11):1372–1378</i> 2012 (<a href=\"https://doi.org/10.1038/aps.2012.67\">doi:10.1038/aps.2012.67</a>) — prostaglandin E 2 [ng/mL] against diclofenac µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       63.9 ng/mL    drug-free response (baseline) (E 0, Q324)
  Emax  =       54.8 ng/mL    maximal effect term (I max, Q323)
  EC50  =        1.3 µg/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma =          2          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of diclofenac per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.39e-05   (drug-free)
  exposure = EC50 (1.3 µg/mL)  response 3.65e-05
  exposure -> infinity  response 9.1e-06</pre></body></html>"));
end Diclofenac_Zhang2012_PD_pge_2_2;
