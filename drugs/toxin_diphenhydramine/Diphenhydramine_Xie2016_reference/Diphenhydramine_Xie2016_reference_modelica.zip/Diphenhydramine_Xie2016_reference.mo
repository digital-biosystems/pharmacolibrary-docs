model Diphenhydramine_Xie2016_reference
  parameter Real Cl_ref = 5.109999999999999e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00574 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.255361,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diphenhydramine</td></tr><tr><td>population:</td><td>crucian carp (Carassius auratus)</td></tr><tr><td>source_paper:</td><td>Xie_2016</td></tr><tr><td>measured_compound:</td><td>Diphenhydramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diphenhydramine 255.361 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'maximum bioconcentration factor (liver)' — extend the ontology if this is a real PK parameter (source ['Xie_2016:abstract'])</li><li>unit_dimension_unknown: 'brain' (Kp)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Diphenhydramine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Gyawali_2019's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Gyawali_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Gyawali_2019 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diphenhydramine_Xie2016_reference;
