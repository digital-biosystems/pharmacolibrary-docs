function p = Diphenhydramine_Blyden1986_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diphenhydramine   source: Blyden_1986 / reference   route: iv_bolus
  p.name  = 'Diphenhydramine_Blyden1986_reference_params';
  p.drug  = 'diphenhydramine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 315.0;                % central volume [L]
  p.CL = 26.04;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.72;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
