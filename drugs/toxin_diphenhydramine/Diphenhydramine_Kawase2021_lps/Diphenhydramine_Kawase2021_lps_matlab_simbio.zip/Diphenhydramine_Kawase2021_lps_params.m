function p = Diphenhydramine_Kawase2021_lps_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diphenhydramine   source: Kawase_2021 / lps   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Diphenhydramine_Kawase2021_lps_params';
  p.drug  = 'diphenhydramine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.74;                % central volume [L]
  p.CL = 18.396;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
