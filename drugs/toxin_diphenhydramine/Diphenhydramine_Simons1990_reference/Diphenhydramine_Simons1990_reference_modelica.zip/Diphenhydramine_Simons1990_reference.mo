model Diphenhydramine_Simons1990_reference
  parameter Real Cl_ref = 1.3649999999999996e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00574 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.255361,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>diphenhydramine</td></tr><tr><td>population:</td><td>healthy fasting humans (elderly adults, young adults, and children)</td></tr><tr><td>source_paper:</td><td>Simons_1990</td></tr><tr><td>measured_compound:</td><td>Diphenhydramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diphenhydramine 255.361 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('serum elimination half-life in young adults', value 9.2) — already have one for this compound</li><li>dropped duplicate Q57 ('serum elimination half-life in children', value 5.4) — already have one for this compound</li><li>dropped duplicate Q354 ('clearance rate in children', value 49.2) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Diphenhydramine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Gyawali_2019's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Gyawali_2019 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Diphenhydramine_Simons1990_reference;
