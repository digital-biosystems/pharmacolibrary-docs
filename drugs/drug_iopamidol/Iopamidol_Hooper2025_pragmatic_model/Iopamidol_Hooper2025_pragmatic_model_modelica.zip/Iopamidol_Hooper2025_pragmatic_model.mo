model Iopamidol_Hooper2025_pragmatic_model
  parameter Real Cl_ref = 9.959999999999999e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005928739999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7770853,
    adminMass = 0.001618,
    k12 = 0.0003528012135237279,
    k21 = 0.0004893703305101929
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iopamidol</h4><p>Iopamidol is an iodinated, low-osmolar X-ray contrast agent used to improve visibility of body structures during imaging examinations. It is an approved contrast medium that is widely used in medical imaging, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424788\">Wikidata Q424788</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iopamidol</td></tr><tr><td>population:</td><td>healthy adults with varying kidney function</td></tr><tr><td>source_paper:</td><td>Hooper_2025</td></tr><tr><td>measured_compound:</td><td>iopamidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70046-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>iopamidol 777.085 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V1' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V1' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Parameter Interindividual Variability (C.V. %)')</li><li>dropped duplicate Q22 ('CL_β_eGFRcr', value '0.73') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V2_ β_Sex' — extend the ontology if this is a real PK parameter (source ['jcph70046-tbl-0003:row9:col2'])</li><li>dropped unlinked row (NIL): 'V1_ β_Sex' — extend the ontology if this is a real PK parameter (source ['Hooper_2025_table_2:row5:col2'])</li><li>routed 'V2_β_weight' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q22 ('Cl_pop', value '65.158') — already have one for this compound</li><li>routed 'beta_Cl_Sex_1' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q63 ('V1_pop', value '5091.933') — already have one for this compound</li><li>dropped unlinked row (NIL): 'beta_V1_Sex_1' — extend the ontology if this is a real PK parameter (source ['Hooper_2025_table_S25:row6:col4', 'Hooper_2025_table_S25:row6:col5'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Iopamidol_Hooper2025_pragmatic_model;
