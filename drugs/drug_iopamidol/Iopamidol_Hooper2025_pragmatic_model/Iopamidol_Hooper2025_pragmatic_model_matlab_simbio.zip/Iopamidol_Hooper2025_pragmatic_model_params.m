function p = Iopamidol_Hooper2025_pragmatic_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iopamidol   source: Hooper_2025 / pragmatic_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Iopamidol_Hooper2025_pragmatic_model_params';
  p.drug  = 'iopamidol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.92874;                % central volume [L]
  p.CL = 3.5856;                % clearance [L/h]
  p.Vp = [4.2742];             % peripheral volumes [L]
  p.Q  = [7.53];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1618.0;             % dose [mg]
end
