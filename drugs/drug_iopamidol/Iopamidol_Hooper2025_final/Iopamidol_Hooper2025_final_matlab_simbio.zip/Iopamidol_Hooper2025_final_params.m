function p = Iopamidol_Hooper2025_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iopamidol   source: Hooper_2025 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Iopamidol_Hooper2025_final_params';
  p.drug  = 'iopamidol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.03413;                % central volume [L]
  p.CL = 3.7038;                % clearance [L/h]
  p.Vp = [4.1546];             % peripheral volumes [L]
  p.Q  = [7.1142];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1618.0;             % dose [mg]
end
