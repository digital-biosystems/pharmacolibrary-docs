function p = AcetylsalicylicAcid_Koh2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: acetylsalicylic_acid   source: Koh_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'AcetylsalicylicAcid_Koh2025_reference_params';
  p.drug  = 'acetylsalicylic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.5;                % central volume [L]
  p.CL = 2.76;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 2.81;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
