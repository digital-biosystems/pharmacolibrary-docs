model AcetylsalicylicAcid_Koh2025_reference
  parameter Real Cl_ref = 7.666666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0075 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 2.9629629629629633e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acetylsalicylic_acid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Koh_2025</td></tr><tr><td>measured_compound:</td><td>acetylsalicylic_acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Koh_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AcetylsalicylicAcid_Koh2025_reference;
