function p = AcetylsalicylicAcid_CuestaGragera2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: acetylsalicylic_acid   source: Cuesta-Gragera_2015 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'AcetylsalicylicAcid_CuestaGragera2015_reference_params';
  p.drug  = 'acetylsalicylic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2390.0;                % central volume [L]
  p.CL = 48.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 7.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
