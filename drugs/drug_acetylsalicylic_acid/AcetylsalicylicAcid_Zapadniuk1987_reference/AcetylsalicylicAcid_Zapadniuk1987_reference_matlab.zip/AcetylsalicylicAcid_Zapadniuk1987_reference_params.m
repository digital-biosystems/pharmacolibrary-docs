function p = AcetylsalicylicAcid_Zapadniuk1987_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: acetylsalicylic_acid   source: Zapadniuk_1987 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'AcetylsalicylicAcid_Zapadniuk1987_reference_params';
  p.drug  = 'acetylsalicylic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2390.0;                % central volume [L]
  p.CL = 2.76;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.33;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.81;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
