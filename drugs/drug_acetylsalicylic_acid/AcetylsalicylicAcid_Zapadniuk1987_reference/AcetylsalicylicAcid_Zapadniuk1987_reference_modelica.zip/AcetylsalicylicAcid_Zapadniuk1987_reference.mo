model AcetylsalicylicAcid_Zapadniuk1987_reference
  parameter Real Cl_ref = 7.666666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 2.39 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.166666666666667e-05,
    Tlag = 10116.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acetylsalicylic_acid</td></tr><tr><td>population:</td><td>young, elderly and old patients</td></tr><tr><td>source_paper:</td><td>Zapadniuk_1987</td></tr><tr><td>measured_compound:</td><td>acetylsalicylic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('half-life in old patients', value 12.2) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life in young patients', value 4.47) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=acetylsalicylic acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Koh_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Thoueille_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bayoumy_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Koh_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AcetylsalicylicAcid_Zapadniuk1987_reference;
