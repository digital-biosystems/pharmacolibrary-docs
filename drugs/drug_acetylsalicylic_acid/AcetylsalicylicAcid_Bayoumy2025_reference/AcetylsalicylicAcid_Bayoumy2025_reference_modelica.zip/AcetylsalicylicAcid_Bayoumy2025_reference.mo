model AcetylsalicylicAcid_Bayoumy2025_reference
  parameter Real Cl_ref = 1.2777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2705 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1801574,
    adminMass = 0.003,
    ka = 9.166666666666667e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acetylsalicylic_acid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bayoumy_2025</td></tr><tr><td>measured_compound:</td><td>acetylsalicylic_acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>acetylsalicylic_acid 180.157 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bayoumy_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end AcetylsalicylicAcid_Bayoumy2025_reference;
