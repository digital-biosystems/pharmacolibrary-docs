model AcetylsalicylicAcid_Hong2008_PD_ex_vivo_platelet_aggregation
  "linear exposure-response sweep — Hong_2008 :: ex vivo platelet aggregation (ex vivo platelet aggregation)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.0156   "[(mg/L) -1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is tmdd; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>AcetylsalicylicAcid_Hong2008_PD_ex_vivo_platelet_aggregation</h4><p>The steady-state exposure-response curve of Hong Y et al., <i>Clinical pharmacokinetics 47(2):129–137</i> 2008 (<a href=\"https://doi.org/10.2165/00003088-200847020-00006\">doi:10.2165/00003088-200847020-00006</a>) — ex vivo platelet aggregation [ohms] against acetylsalicylic_acid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0156 (mg/L) -1 change in response per unit of exposure (β, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/L of acetylsalicylic_acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end AcetylsalicylicAcid_Hong2008_PD_ex_vivo_platelet_aggregation;
