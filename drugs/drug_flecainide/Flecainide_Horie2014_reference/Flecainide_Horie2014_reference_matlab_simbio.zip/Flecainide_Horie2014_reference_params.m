function p = Flecainide_Horie2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flecainide   source: Horie_2014 / reference   route: oral
  p.name  = 'Flecainide_Horie2014_reference_params';
  p.drug  = 'flecainide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 735.0;                % central volume [L]
  p.CL = 27.72;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.62;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
