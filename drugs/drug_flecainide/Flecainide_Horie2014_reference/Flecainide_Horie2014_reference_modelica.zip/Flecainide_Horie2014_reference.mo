model Flecainide_Horie2014_reference
  parameter Real Cl_ref = 7.7e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7350000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41434269999999995,
    adminMass = 0.0002,
    ka = 0.0001722222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flecainide</h4><p>Flecainide is a class Ic antiarrhythmic used to prevent and treat heart rhythm disorders such as atrial fibrillation. It remains an approved medicine, but it carries a boxed warning, so its use requires caution.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421381\">Wikidata Q421381</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flecainide</td></tr><tr><td>population:</td><td>Japanese patients</td></tr><tr><td>source_paper:</td><td>Horie_2014</td></tr><tr><td>measured_compound:</td><td>flecainide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>flecainide 414.343 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Bisoprolol (100 μM)' — extend the ontology if this is a real PK parameter (source ['Horie_2014_table_1:row2:col2', 'Horie_2014_table_1:row2:col3'])</li><li>salvaged Q27 ('(CL/F)/WT in group 1'=0.396) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('(V/F)/WT in 16 patients'=10.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=flecainide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Deneer_2004's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Flecainide_Horie2014_reference;
