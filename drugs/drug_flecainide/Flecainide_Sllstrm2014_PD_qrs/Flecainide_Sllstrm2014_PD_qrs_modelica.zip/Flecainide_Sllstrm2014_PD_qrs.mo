model Flecainide_Sllstrm2014_PD_qrs
  "linear exposure-response sweep — Sällström_2014 :: QRS (QRS interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0364,      // [s; ms × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 33000   "[1 / meter; %/μM × 10000]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About flecainide</h4><p>Flecainide is a class Ic antiarrhythmic used to prevent and treat heart rhythm disorders such as atrial fibrillation. It remains an approved medicine, but it carries a boxed warning, so its use requires caution.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421381\">Wikidata Q421381</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Flecainide_Sllstrm2014_PD_qrs</h4><p>The steady-state exposure-response curve of Sällström J et al., <i>Journal of pharmacological and toxicological methods 69(1):24–29</i> 2014 (<a href=\"https://doi.org/10.1016/j.vascn.2013.10.001\">doi:10.1016/j.vascn.2013.10.001</a>) — QRS interval [ms] against flecainide μM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       36.4 ms       drug-free response (baseline) (E 0, Q324)
  slope =        3.3 %/μM     change in response per unit of exposure (pEC100 (total, %/μM), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μM of flecainide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0364   (drug-free)</pre></body></html>"));
end Flecainide_Sllstrm2014_PD_qrs;
