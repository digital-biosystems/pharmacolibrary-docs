function p = Flecainide_Sllstrm2014_PD_qrs_params()
% Flecainide_Sllstrm2014_PD_qrs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% flecainide Sällström_2014::QRS: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response QRS in ms. Driver: flecainide (pk_record).
p.E0 = 0.0364;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 33000.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
