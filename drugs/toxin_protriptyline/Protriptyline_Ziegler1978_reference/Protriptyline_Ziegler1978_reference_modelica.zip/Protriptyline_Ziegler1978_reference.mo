model Protriptyline_Ziegler1978_reference
  parameter Real Cl_ref = 4.08145210625809e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.575 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.263384,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>protriptyline</td></tr><tr><td>population:</td><td>8 subjects</td></tr><tr><td>source_paper:</td><td>Ziegler_1978</td></tr><tr><td>measured_compound:</td><td>protriptyline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>protriptyline 263.384 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'of the oral dose' (kfm)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=protriptyline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL=14.6932 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 1));
end Protriptyline_Ziegler1978_reference;
