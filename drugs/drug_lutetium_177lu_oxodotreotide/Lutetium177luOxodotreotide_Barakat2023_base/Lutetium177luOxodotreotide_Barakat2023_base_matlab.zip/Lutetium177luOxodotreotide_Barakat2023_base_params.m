function p = Lutetium177luOxodotreotide_Barakat2023_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lutetium_177lu_oxodotreotide   source: Barakat_2023 / base   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Lutetium177luOxodotreotide_Barakat2023_base_params';
  p.drug  = 'lutetium_177lu_oxodotreotide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 77.9;                % central volume [L]
  p.CL = 2.68;                % clearance [L/h]
  p.Vp = [190.0];             % peripheral volumes [L]
  p.Q  = [6.78];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
