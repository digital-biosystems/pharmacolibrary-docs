model Lutetium177luOxodotreotide_Barakat2023_base
  parameter Real Cl_ref = 7.444444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07790000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 2.417629439452289e-05,
    k21 = 9.912280701754386e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>lutetium_177lu_oxodotreotide</td></tr><tr><td>population:</td><td>patients with gastroenteropancreatic neuroendocrine tumors</td></tr><tr><td>source_paper:</td><td>Barakat_2023</td></tr><tr><td>measured_compound:</td><td>lutetium_177lu_oxodotreotide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'structural model estimate value (cv, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'structural model estimate value (cv, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'structural model estimate value (cv, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'structural model estimate value (cv, %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lutetium_177lu_oxodotreotide</li><li>model-stage split: 'structural model estimate value (cv, %)' is the base model of Barakat_2023 (paper reports 3 stages: final model estimate value (cv, %), structural model % rse, structural model estimate value (cv, %)); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Lutetium177luOxodotreotide_Barakat2023_base;
