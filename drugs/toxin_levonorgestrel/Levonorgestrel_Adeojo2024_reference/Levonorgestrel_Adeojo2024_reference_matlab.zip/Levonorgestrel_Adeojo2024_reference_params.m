function p = Levonorgestrel_Adeojo2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levonorgestrel   source: Adeojo_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Levonorgestrel_Adeojo2024_reference_params';
  p.drug  = 'levonorgestrel';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 144.0;                % central volume [L]
  p.CL = 9.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.416667;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
