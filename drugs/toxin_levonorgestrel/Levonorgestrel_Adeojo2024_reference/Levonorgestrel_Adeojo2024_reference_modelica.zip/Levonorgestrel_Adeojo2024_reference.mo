model Levonorgestrel_Adeojo2024_reference
  parameter Real Cl_ref = 2.6944444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14400000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.312453,
    adminMass = 0.00015,
    ka = 0.00011574074074074073,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levonorgestrel</td></tr><tr><td>population:</td><td>women ages 18 to 45 years</td></tr><tr><td>source_paper:</td><td>Adeojo_2024</td></tr><tr><td>measured_compound:</td><td>Levonorgestrel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-01050-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levonorgestrel 312.453 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'μL/min/mg protein' (CLint)</li><li>dropped unlinked row (NIL): 'month 1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row9:col1'])</li><li>dropped unlinked row (NIL): 'month 3' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row10:col1'])</li><li>dropped unlinked row (NIL): 'month 6' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row11:col1'])</li><li>dropped unlinked row (NIL): 'month 12' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row12:col1'])</li><li>dropped unlinked row (NIL): 'month 24' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row13:col1'])</li><li>dropped unlinked row (NIL): 'month 36' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row14:col1'])</li><li>dropped unlinked row (NIL): 'month 60' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01050-t001:row15:col1'])</li><li>implicit units: 'HLM (μL/min/mg protein)' — the LLM proposed 'μL/min/mg protein', whose dimension does not fit Q3; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levonorgestrel</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>pharmacogenetic covariate 'theta_clint_cyp3a4' (cyp3a4) — PGx domain</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q22 (CL) from Carten_2012's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Carten_2012's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Levonorgestrel_Adeojo2024_reference;
