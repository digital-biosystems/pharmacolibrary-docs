function p = Levonorgestrel_Cole2024_PD_pi_params()
% Levonorgestrel_Cole2024_PD_pi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levonorgestrel Cole_2024::PI: indirect_response_ii exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/mL per second, in SI inside (kg/m3, s). Response PI in %. Driver: levonorgestrel (cited_pk).
p.E0 = 0.84;
p.Emax = 101.0;
p.EC50 = 5e-09;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 7.5;
p.form = 'E0/(1 + Emax*frac)';
end
