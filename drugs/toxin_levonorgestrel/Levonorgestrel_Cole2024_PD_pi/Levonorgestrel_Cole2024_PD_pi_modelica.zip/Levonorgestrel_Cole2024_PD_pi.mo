model Levonorgestrel_Cole2024_PD_pi
  "indirect_response_ii exposure-response sweep — Cole_2024 :: PI (Pearl Index)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0.84,      // [1; % × 0.01]
    Emax = 101,  // type IV effect term
    EC50 = 5e-09,  // [kg/m3; pg/mL × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg/mL per second
  // emax_not_a_fraction: type II needs Imax ≤ 1 but the record has 101; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7.5, Interval = 0.015),
    Documentation(info = "<html><body><h4>Levonorgestrel_Cole2024_PD_pi</h4><p>The steady-state exposure-response curve of Cole S et al., <i>Pharmaceuticals (Basel, Switzerland) 17(12)</i> 2024 (<a href=\"https://doi.org/10.3390/ph17121640\">doi:10.3390/ph17121640</a>) — Pearl Index [%] against levonorgestrel pg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         84 %        drug-free response (baseline) (E0, Q324)
  Emax  =        101          maximal effect term (Imax (Norplant), Q323)
  EC50  =          5 pg/mL    exposure at half of the maximal effect term (IC50 (Norplant), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one pg/mL of levonorgestrel per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.84   (drug-free)
  exposure = EC50 (5 pg/mL)  response 0.01631
  exposure -> infinity  response 0.008235</pre></body></html>"));
end Levonorgestrel_Cole2024_PD_pi;
