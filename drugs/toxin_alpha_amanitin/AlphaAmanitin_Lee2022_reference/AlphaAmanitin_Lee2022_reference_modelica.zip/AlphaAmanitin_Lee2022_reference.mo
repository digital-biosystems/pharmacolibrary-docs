model AlphaAmanitin_Lee2022_reference
  parameter Real Cl_ref = 1.633333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02863 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.919,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alpha_amanitin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Lee_2022</td></tr><tr><td>measured_compound:</td><td>alpha-Amanitin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>molecules-27-08612-t005</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alpha-Amanitin 919 g/mol (pubchem); alpha_amanitin 919 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 5. Metabolic stability parameters of α-amanitin in rat and human liver microsomes.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alpha-Amanitin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>base model from table(s) without population columns (Lee_2022:other_prose, Lee_2022_table_6, molecules-27-08612-t005:footnote); populations human, rat kept as separate records</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AlphaAmanitin_Lee2022_reference;
