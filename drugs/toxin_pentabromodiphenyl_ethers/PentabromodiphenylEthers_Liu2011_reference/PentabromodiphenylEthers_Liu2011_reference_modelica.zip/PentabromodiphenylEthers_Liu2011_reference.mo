// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model PentabromodiphenylEthers_Liu2011_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3024000.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentabromodiphenyl_ethers</td></tr><tr><td>population:</td><td>wild adult frogs (Rana limnocharis) from an e-waste recycling site in China</td></tr><tr><td>source_paper:</td><td>Liu_2011</td></tr><tr><td>measured_compound:</td><td>PBDE congeners including BDE-47, BDE-99, BDE-153</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>pentabromodiphenyl_ethers 564.7 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Liu_2011:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Liu_2011:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Liu_2011:abstract'])</li><li>dropped duplicate Q57 ('half-life', value '58.5') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=PBDE congeners including BDE-47, BDE-99, BDE-153</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'PBDE congeners including BDE-47, BDE-99, BDE-153' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'PBDE congeners including BDE-47, BDE-99, BDE-153', not pentabromodiphenyl_ethers — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15120000, Tolerance = 1e-9, Interval = 30240.0));
end PentabromodiphenylEthers_Liu2011_reference;
