// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model PentabromodiphenylEthers_Cary2013_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1494720.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentabromodiphenyl_ethers</td></tr><tr><td>population:</td><td>northern leopard frog tadpoles and juvenile frogs</td></tr><tr><td>source_paper:</td><td>Cary_2013</td></tr><tr><td>measured_compound:</td><td>PBDE congeners (BDE-47, BDE-99, BDE-100)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>pentabromodiphenyl_ethers 564.7 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('BDE-99 (t½)', value 63.0) — already have one for this compound</li><li>dropped duplicate Q57 ('BDE-100 (t½)', value 69.3) — already have one for this compound</li><li>dropped unlinked row (NIL): 'DE-71 ng/g wet mass' — extend the ontology if this is a real PK parameter (source ['Cary_2013:abstract', 'Cary_2013:abstract'])</li><li>dropped unlinked row (NIL): 'DE-71 ng/g wet mass (control)' — extend the ontology if this is a real PK parameter (source ['Cary_2013:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=PBDE congeners (BDE-47, BDE-99, BDE-100)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'PBDE congeners (BDE-47, BDE-99, BDE-100)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'PBDE congeners (BDE-47, BDE-99, BDE-100)', not pentabromodiphenyl_ethers — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 15724.8));
end PentabromodiphenylEthers_Cary2013_reference;
