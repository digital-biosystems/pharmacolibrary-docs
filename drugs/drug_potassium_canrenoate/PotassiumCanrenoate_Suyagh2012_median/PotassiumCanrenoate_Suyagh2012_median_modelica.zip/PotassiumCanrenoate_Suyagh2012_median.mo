model PotassiumCanrenoate_Suyagh2012_median
  parameter Real Cl_ref = 3.6944444444444447e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019620000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.340463,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>potassium_canrenoate</td></tr><tr><td>population:</td><td>paediatric patients</td></tr><tr><td>source_paper:</td><td>Suyagh_2012</td></tr><tr><td>measured_compound:</td><td>canrenone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>potassium canrenoate 358.478 g/mol (drugbank); canrenone 340.463 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F (L/hr/kg)*', value '0.32') — already have one for this compound</li><li>dropped duplicate Q290 ('V/F (L/kg)*', value '5.35') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=canrenone</li><li>template fit: PK_3M_9C — formed from central; parent 0, metabolites [1]</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V/F (L)' is the general volume)</li><li>population split: 'median' subgroup of Suyagh_2012 (paper reports 2 populations: median, two experimentally determined θs (one for each exponent) estimate)</li><li>row roles (LLM): model_class=compartmental; 14/14 row label(s) assigned, 38 linked by role</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end PotassiumCanrenoate_Suyagh2012_median;
