model Crizotinib_Gibson2021_reference
  parameter Real Cl_ref = 3.2053055555555564e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.12680900000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.450337,
    adminMass = 0.0005,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About crizotinib</h4><p>Crizotinib is a protein kinase inhibitor used to treat non-small-cell lung carcinoma. It is taken by mouth in capsule form. It is authorised in the European Union for this condition.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q5186964\">Wikidata Q5186964</a>, <a href=\"https://en.wikipedia.org/wiki/Crizotinib?oldid=1378272953\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>crizotinib</td></tr><tr><td>population:</td><td>children with progressive or recurrent high-grade and diffuse intrinsic pontine gliomas</td></tr><tr><td>source_paper:</td><td>Gibson_2021</td></tr><tr><td>measured_compound:</td><td>crizotinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>crizotinib 450.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'age range' — extend the ontology if this is a real PK parameter (source ['Gibson_2021:abstract'])</li><li>dropped unlinked row (NIL): 'crizotinib' — extend the ontology if this is a real PK parameter (source ['Gibson_2021:abstract'])</li><li>dropped unlinked row (NIL): 'dasatinib' — extend the ontology if this is a real PK parameter (source ['Gibson_2021:abstract'])</li><li>dropped unlinked row (NIL): 'clinically relevant impact' — extend the ontology if this is a real PK parameter (source ['Gibson_2021:abstract'])</li><li>dropped duplicate Q27 ('Overweight/obese patients crizotinib CL/F', value 46.2) — already have one for this compound</li><li>dropped duplicate Q27 ('other patients crizotinib CL/F', value 75.5) — already have one for this compound</li><li>dropped duplicate Q290 ('other patients crizotinib apparent volume V1/F', value 119.3) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=crizotinib</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Overweight/obese patients crizotinib apparent volume V1/F' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Crizotinib_Gibson2021_reference;
