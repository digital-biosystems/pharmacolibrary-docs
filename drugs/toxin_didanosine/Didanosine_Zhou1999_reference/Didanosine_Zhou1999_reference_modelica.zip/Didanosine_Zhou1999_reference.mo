model Didanosine_Zhou1999_reference
  parameter Real Cl_ref = 1.036388888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0819 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23623,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>didanosine</td></tr><tr><td>population:</td><td>human immunodeficiency virus-infected patients</td></tr><tr><td>source_paper:</td><td>Zhou_1999</td></tr><tr><td>measured_compound:</td><td>Didanosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>didanosine 236.23 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Individual mean oral CL ... of ZDV', value 1.84) — already have one for this compound</li><li>dropped duplicate Q61 ('V of ZDV', value 2.67) — already have one for this compound</li><li>dropped value-less row: 'body weight and age'</li><li>dropped value-less row: 'body weight'</li><li>dropped duplicate Q22 ('The average individual oral CL ... of ddI', value 1.64) — already have one for this compound</li><li>dropped duplicate Q65 ('VSS ... of ddI', value 3.56) — already have one for this compound</li><li>dropped duplicate Q61 ('V of ddI', value 2.74) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Didanosine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Didanosine_Zhou1999_reference;
