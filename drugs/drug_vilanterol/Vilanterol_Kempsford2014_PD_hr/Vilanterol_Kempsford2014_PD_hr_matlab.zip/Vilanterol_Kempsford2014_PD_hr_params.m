function p = Vilanterol_Kempsford2014_PD_hr_params()
% Vilanterol_Kempsford2014_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vilanterol Kempsford_2014::HR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg ml−1 per second, in SI inside (kg/m3, s). Response HR in beats min−1. Driver: VI (not_resolved).
p.E0 = 23.6;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0173;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
