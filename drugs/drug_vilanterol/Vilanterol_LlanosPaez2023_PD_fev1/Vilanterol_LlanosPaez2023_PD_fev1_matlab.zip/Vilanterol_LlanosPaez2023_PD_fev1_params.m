function p = Vilanterol_LlanosPaez2023_PD_fev1_params()
% Vilanterol_LlanosPaez2023_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vilanterol Llanos-Paez_2023::FEV1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ug per second, in SI inside (kg/m3, s). Response FEV1 in L. Driver: vilanterol (dose_only).
p.E0 = 8.930000000000002e-05;
p.Emax = 0.00012340000000000002;
p.EC50 = 2.02e-09;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 21.0;
p.form = 'E0 + Emax*frac';
end
