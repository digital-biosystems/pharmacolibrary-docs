model Vilanterol_LlanosPaez2023_PD_fev1
  "emax exposure-response sweep — Llanos-Paez_2023 :: FEV1 (forced expiratory volume in one second)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 8.93e-05,      // [m3; mL × 1e-06]
    Emax = 0.0001234,  // [m3; mL × 1e-06]
    EC50 = 2.02e-09,  // [kg; ug × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 ug per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 21, Interval = 0.042),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vilanterol</h4><p>Vilanterol is a long-acting inhaled beta-2 agonist used to treat obstructive airway diseases such as COPD and asthma, given in combination inhalers with corticosteroids or anticholinergics. It is an approved medicine, available in fixed-dose combination inhalers for respiratory conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15053666\">Wikidata Q15053666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Vilanterol_LlanosPaez2023_PD_fev1</h4><p>The steady-state exposure-response curve of Llanos-Paez C et al., <i>Journal of pharmacokinetics and pharmacodynamics 50(4):297-314</i> 2023 (<a href=\"https://doi.org/10.1007/s10928-023-09853-z\">doi:10.1007/s10928-023-09853-z</a>) — forced expiratory volume in one second [L] against vilanterol ug — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       89.3 mL       drug-free response (baseline) (Olodaterol Effref, Q324)
  Emax  =      123.4 mL       maximal effect term (Emax, Q320)
  EC50  =       2.02 ug       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ug of vilanterol per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8.93e-05   (drug-free)
  exposure = EC50 (2.02 ug)  response 0.000151
  exposure -> infinity  response 0.0002127</pre></body></html>"));
end Vilanterol_LlanosPaez2023_PD_fev1;
