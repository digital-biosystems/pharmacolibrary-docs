model Vilanterol_Kempsford2014_PD_qtcf
  "linear exposure-response sweep — Kempsford_2014 :: QTcF (maximal QTcF)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0746,      // [s; ms × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-09);
  parameter Real slope = 7510   "[meter ** 3 * second / kilogram; ms pg−1 ml × 1e+06]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vilanterol</h4><p>Vilanterol is a long-acting inhaled beta-2 agonist used to treat obstructive airway diseases such as COPD and asthma, given in combination inhalers with corticosteroids or anticholinergics. It is an approved medicine, available in fixed-dose combination inhalers for respiratory conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15053666\">Wikidata Q15053666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Vilanterol_Kempsford2014_PD_qtcf</h4><p>The steady-state exposure-response curve of Kempsford R et al., <i>British journal of clinical pharmacology 77(3):466-479</i> 2014 (<a href=\"https://doi.org/10.1111/bcp.12243\">doi:10.1111/bcp.12243</a>) — maximal QTcF [ms] against VI pg ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       74.6 ms       drug-free response (baseline) (Intercept, Q324)
  slope =    0.00751 ms pg−1 ml change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one pg ml−1 of VI per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0746   (drug-free)</pre></body></html>"));
end Vilanterol_Kempsford2014_PD_qtcf;
