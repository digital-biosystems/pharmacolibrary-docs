model Pyridostigmine_Seng2009_PD_ache_activity
  "indirect_response_i exposure-response sweep — Seng_2009 :: AChE activity (red blood cell acetylcholinesterase (AChE) activity)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 9.32,  // type IV effect term
    EC50 = 5.19e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 9.32; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 520, Interval = 1.04),
    Documentation(info = "<html><body><h4>Pyridostigmine_Seng2009_PD_ache_activity</h4><p>The steady-state exposure-response curve of Seng KY et al., <i>The Journal of pharmacy and pharmacology 61(9):1187-1196</i> 2009 (<a href=\"https://doi.org/10.1211/jpp/61.09.0008\">doi:10.1211/jpp/61.09.0008</a>) — red blood cell acetylcholinesterase (AChE) activity [AChE units per gram haemoglobin] against pyridostigmine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       9.32          maximal effect term (Emax, Q323)
  EC50  =       51.9 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of pyridostigmine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (51.9 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Pyridostigmine_Seng2009_PD_ache_activity;
