model Atezolizumab_Stroh2017_reference
  parameter Real Cl_ref = 2.3148148148148148e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00691 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5.71e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atezolizumab</h4><p>Atezolizumab is a monoclonal antibody used to treat bladder, lung, and other cancers. It is given by intravenous or subcutaneous injection. It is authorised in the European Union for several cancer types.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q20707748\">Wikidata Q20707748</a>, <a href=\"https://en.wikipedia.org/wiki/Atezolizumab?oldid=1347863837\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atezolizumab</td></tr><tr><td>population:</td><td>patients with metastatic urothelial carcinoma</td></tr><tr><td>source_paper:</td><td>Stroh_2017</td></tr><tr><td>measured_compound:</td><td>atezolizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atezolizumab</li><li>molar mass: none found for 'atezolizumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 12096000, Tolerance = 1e-9, Interval = 1));
end Atezolizumab_Stroh2017_reference;
