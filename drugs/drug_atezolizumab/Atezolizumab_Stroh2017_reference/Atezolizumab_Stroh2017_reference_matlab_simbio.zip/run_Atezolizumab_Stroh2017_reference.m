% Run (SimBiology): build model + dose, simulate 0..3360.0 h, plot.
p = Atezolizumab_Stroh2017_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3360.0);
