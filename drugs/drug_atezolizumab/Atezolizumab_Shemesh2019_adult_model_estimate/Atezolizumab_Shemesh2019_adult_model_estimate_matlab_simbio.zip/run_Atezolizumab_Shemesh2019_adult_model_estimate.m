% Run (SimBiology): build model + dose, simulate 0..1512.0 h, plot.
p = Atezolizumab_Shemesh2019_adult_model_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1512.0);
