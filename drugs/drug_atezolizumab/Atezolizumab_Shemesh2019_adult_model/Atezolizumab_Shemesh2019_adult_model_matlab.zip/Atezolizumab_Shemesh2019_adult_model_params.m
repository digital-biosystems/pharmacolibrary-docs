function p = Atezolizumab_Shemesh2019_adult_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atezolizumab   source: Shemesh_2019 / adult_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Atezolizumab_Shemesh2019_adult_model_params';
  p.drug  = 'atezolizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.28;                % central volume [L]
  p.CL = 0.008333;                % clearance [L/h]
  p.Vp = [3.63];             % peripheral volumes [L]
  p.Q  = [0.02275];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 57.1;             % dose [mg]
end
