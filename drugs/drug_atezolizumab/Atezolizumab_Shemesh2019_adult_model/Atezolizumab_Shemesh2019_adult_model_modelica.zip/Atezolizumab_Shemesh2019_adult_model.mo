model Atezolizumab_Shemesh2019_adult_model
  parameter Real Cl_ref = 2.3148148148148148e-09 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real Vd_ref = 0.00328 "Vd [m3]";
  parameter Real cov_albumin_0 = 0 "albumin covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (16.0)*cov_sex_0)*(1 + (-0.272)*cov_sex_1),
    Vd = Vd_ref*(1 + (-0.35)*cov_albumin_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5.71e-05,
    k12 = 1.9266598915989162e-06,
    k21 = 1.740893786348332e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atezolizumab</h4><p>Atezolizumab is a monoclonal antibody that blocks PD-L1 and is used to treat several cancers, including bladder, lung, breast, and colorectal cancers. It is approved and authorised in the European Union, where it is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20707748\">Wikidata Q20707748</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atezolizumab</td></tr><tr><td>population:</td><td>pediatric and young adult patients with cancer</td></tr><tr><td>source_paper:</td><td>Shemesh_2019</td></tr><tr><td>measured_compound:</td><td>atezolizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Tumor burden on CL', value '0.125') — already have one for this compound</li><li>covariate level 'Sex (female) on V1' → Q900:sex_female_on_v1 = 16 (linear_fractional on Q22)</li><li>covariate level 'Sex (female) on V2' → Q900:sex_female_on_v2 = -0.272 (linear_fractional on Q22)</li><li>dropped unlinked row (NIL): 'Objective function' — extend the ontology if this is a real PK parameter (source ['Tab2:row22:col4'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atezolizumab</li><li>population split: 'adult model' subgroup of Shemesh_2019 (paper reports 2 populations: adult model, pediatric/young adult model)</li><li>molar mass: none found for 'atezolizumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Atezolizumab_Shemesh2019_adult_model;
