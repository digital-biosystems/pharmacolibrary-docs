function p = Atezolizumab_Chan2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atezolizumab   source: Chan_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Atezolizumab_Chan2025_reference_params';
  p.drug  = 'atezolizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.28;                % central volume [L]
  p.CL = 0.008333;                % clearance [L/h]
  p.Vp = [3.63];             % peripheral volumes [L]
  p.Q  = [0.02275];             % inter-compartmental clearances [L/h]
  p.ka = 0.012667;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
