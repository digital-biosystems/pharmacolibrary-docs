model Atezolizumab_Chan2025_reference
  parameter Real Cl_ref = 2.3148148148148148e-09 "Cl [m3/s]";
  parameter Real cov_bodyweight_0 = 0 "bodyweight covariate";
  parameter Real Vd_ref = 0.00328 "Vd [m3]";
  parameter Boolean cov_sex_0 = false "sex level 0";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.808)*cov_bodyweight_0),
    Vd = Vd_ref + (-0.00012900000000000002)*(if cov_sex_0 then 1 else 0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0012,
    ka = 3.5185185185185183e-06,
    Tlag = 0.0,
    k12 = 1.9266598915989162e-06,
    k21 = 1.740893786348332e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atezolizumab</h4><p>Atezolizumab is a monoclonal antibody that blocks PD-L1 and is used to treat several cancers, including bladder, lung, breast, and colorectal cancers. It is approved and authorised in the European Union, where it is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20707748\">Wikidata Q20707748</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atezolizumab</td></tr><tr><td>population:</td><td>patients with non-small cell lung cancer</td></tr><tr><td>source_paper:</td><td>Chan_2025</td></tr><tr><td>measured_compound:</td><td>atezolizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413310-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'POPIIV CL' routed out of structural estimates ('Omega (standard deviation scale)—Between subject variability')</li><li>table section iiv: 'POPIIV Vc' routed out of structural estimates ('Omega (standard deviation scale)—Between subject variability')</li><li>table section iiv: 'POPIIV Vp' routed out of structural estimates ('Omega (standard deviation scale)—Between subject variability')</li><li>table section iiv: 'POPIIV KA' routed out of structural estimates ('Omega (standard deviation scale)—Between subject variability')</li><li>table section iiv: 'POPIIV F1' routed out of structural estimates ('Omega (standard deviation scale)—Between subject variability')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Sigma (residual error)')</li><li>table section residual_error: 'Additive error (μg/mL)' routed out of structural estimates ('Sigma (residual error)')</li><li>dropped unlinked row (NIL): 'Albumin on CL (ALB/40 in g/L)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row5:col1'])</li><li>dropped unlinked row (NIL): 'Tumor burden on CL (Tumor burden/63 mm)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row7:col1'])</li><li>dropped unlinked row (NIL): 'Albumin on Vc (ALB/40 in g/L)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row9:col1'])</li><li>dropped unlinked row (NIL): 'Bodyweight on Vc (BWT/77 in kg)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row10:col1'])</li><li>dropped unlinked row (NIL): 'Sex on Vp (additive effect for female)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row12:col1'])</li><li>dropped unlinked row (NIL): 'Albumin on KA (ALB/40 in g/L)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row15:col1'])</li><li>dropped unlinked row (NIL): 'Hemoglobin on F1 On logit scale (HGB/123 in g/L)' — extend the ontology if this is a real PK parameter (source ['psp413310-tbl-0002:row16:col1'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atezolizumab</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Atezolizumab_Chan2025_reference;
