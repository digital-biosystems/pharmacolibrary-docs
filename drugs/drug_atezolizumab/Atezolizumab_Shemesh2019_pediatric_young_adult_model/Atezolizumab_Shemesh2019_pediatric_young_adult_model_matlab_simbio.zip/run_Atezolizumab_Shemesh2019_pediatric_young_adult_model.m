% Run (SimBiology): build model + dose, simulate 0..1176.0 h, plot.
p = Atezolizumab_Shemesh2019_pediatric_young_adult_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1176.0);
