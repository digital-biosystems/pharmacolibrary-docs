function p = Trimipramine_Abernethy1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trimipramine   source: Abernethy_1984 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Trimipramine_Abernethy1984_reference_params';
  p.drug  = 'trimipramine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2163.0;                % central volume [L]
  p.CL = 66.78;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
