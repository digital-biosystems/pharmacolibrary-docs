function p = Oxaliplatin_Gao2021_cv_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxaliplatin   source: Gao_2021 / cv_estimate   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Oxaliplatin_Gao2021_cv_estimate_params';
  p.drug  = 'oxaliplatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.609;                % central volume [L]
  p.CL = 83.16;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 6.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
