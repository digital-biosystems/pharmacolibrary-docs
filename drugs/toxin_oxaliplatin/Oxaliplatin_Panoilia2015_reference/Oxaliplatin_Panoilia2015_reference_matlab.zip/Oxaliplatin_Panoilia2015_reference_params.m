function p = Oxaliplatin_Panoilia2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxaliplatin   source: Panoilia_2015 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Oxaliplatin_Panoilia2015_reference_params';
  p.drug  = 'oxaliplatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.14;                % central volume [L]
  p.CL = 0.0075;                % clearance [L/h]
  p.Vp = [2.63];             % peripheral volumes [L]
  p.Q  = [0.015];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
