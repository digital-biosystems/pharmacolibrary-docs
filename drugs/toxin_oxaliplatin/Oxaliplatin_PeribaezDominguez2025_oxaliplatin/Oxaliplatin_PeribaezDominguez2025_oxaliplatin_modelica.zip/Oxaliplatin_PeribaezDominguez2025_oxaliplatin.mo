model Oxaliplatin_PeribaezDominguez2025_oxaliplatin
  parameter Real Cl_ref = 1.967592592592593e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025046 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399306,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>virtual population of colorectal cancer patients, ages 25-80, 50% female</td></tr><tr><td>source_paper:</td><td>Peribañez-Dominguez_2025</td></tr><tr><td>measured_compound:</td><td>Oxaliplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-00057-t001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Oxaliplatin 399.306 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Brain' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row0:col3'])</li><li>dropped unlinked row (NIL): 'Kidney' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row2:col3'])</li><li>dropped unlinked row (NIL): 'Stomach' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row3:col3'])</li><li>dropped unlinked row (NIL): 'Small intestine' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row4:col3'])</li><li>dropped unlinked row (NIL): 'Large intestine' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row5:col3'])</li><li>dropped unlinked row (NIL): 'Lung' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row7:col3'])</li><li>dropped unlinked row (NIL): 'Muscle' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row8:col3'])</li><li>dropped unlinked row (NIL): 'Pancreas' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row9:col3'])</li><li>dropped unlinked row (NIL): 'Spleen' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row10:col3'])</li><li>dropped unlinked row (NIL): 'Skin' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row11:col3'])</li><li>dropped unlinked row (NIL): 'Bone' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row12:col3'])</li><li>dropped unlinked row (NIL): 'Saliva' — extend the ontology if this is a real PK parameter (source ['Peribañez-Dominguez_2025_table_4:row13:col3'])</li><li>dropped value-less row: '5-FU'</li><li>dropped value-less row: 'Ref-pH'</li><li>dropped value-less row: 'DPD'</li><li>dropped value-less row: 'Km'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Oxaliplatin_PeribaezDominguez2025_oxaliplatin;
