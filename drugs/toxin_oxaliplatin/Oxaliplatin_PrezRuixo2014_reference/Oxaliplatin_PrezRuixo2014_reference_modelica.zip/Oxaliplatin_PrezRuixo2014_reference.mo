model Oxaliplatin_PrezRuixo2014_reference
  parameter Real Cl_ref = 1.967592592592593e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025046 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399306,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>peritoneal carcinomatosis patients treated with CRS and HIO, pooled with solid tumor patients treated with IV oxaliplatin</td></tr><tr><td>source_paper:</td><td>Pérez-Ruixo_2014</td></tr><tr><td>measured_compound:</td><td>Oxaliplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>oxaliplatin 399.306 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('rate of oxaliplatin absorption (dextrose 5 %)', value None) — already have one for this compound</li><li>'extent of HIO absorption' → Q40: printed without a unit and above 1 — read as a percentage</li><li>dropped 'reduction in V a (dextrose 5 % relative to icodextrin 4 %)' → Q61: unit '-fold' is a statistic (%, CV, RSE, shrinkage or fold), not a volume — the row is a variability or a ratio, not the estimate</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Oxaliplatin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Panoilia_2015's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kobuchi_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Kobuchi_2020, Panoilia_2015 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Oxaliplatin_PrezRuixo2014_reference;
