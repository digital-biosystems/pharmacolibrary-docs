model Oxaliplatin_Elias2002_reference
  parameter Real Cl_ref = 1.967592592592593e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025046 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399306,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>patients with peritoneal carcinomatosis</td></tr><tr><td>source_paper:</td><td>Elias_2002</td></tr><tr><td>measured_compound:</td><td>Oxaliplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxaliplatin 399.306 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'mean duration of the entire procedure' — extend the ontology if this is a real PK parameter (source ['Elias_2002:abstract'])</li><li>unit_dimension_unknown: '-fold' (Kp)</li><li>dropped unlinked row (NIL): 'recommended oxaliplatin dose' — extend the ontology if this is a real PK parameter (source ['Elias_2002:abstract'])</li><li>unit_dimension_unknown: 'l/m2 of 5% dextrose' (Vnorm)</li><li>dropped duplicate Q352 ('recommended instillate volume', value 2) — already have one for this compound</li><li>dropped value-less row: 'temperature'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Oxaliplatin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Panoilia_2015's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kobuchi_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Hill_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Oxaliplatin_Elias2002_reference;
