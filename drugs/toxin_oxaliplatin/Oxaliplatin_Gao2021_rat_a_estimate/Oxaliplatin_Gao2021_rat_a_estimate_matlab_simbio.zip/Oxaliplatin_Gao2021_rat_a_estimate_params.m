function p = Oxaliplatin_Gao2021_rat_a_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxaliplatin   source: Gao_2021 / rat_a_estimate   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Oxaliplatin_Gao2021_rat_a_estimate_params';
  p.drug  = 'oxaliplatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 66.4937;                % central volume [L]
  p.CL = 658.728;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 6.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
