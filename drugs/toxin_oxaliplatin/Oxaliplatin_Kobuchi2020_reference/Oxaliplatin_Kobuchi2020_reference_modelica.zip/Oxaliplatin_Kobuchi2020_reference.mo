model Oxaliplatin_Kobuchi2020_reference
  parameter Real Cl_ref = 2.3654555555555553e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025046 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399306,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kobuchi_2020</td></tr><tr><td>measured_compound:</td><td>Oxaliplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-12-00125-t001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxaliplatin 399.306 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'V' routed out of structural estimates ('Inter-individual variability, ω')</li><li>table section iiv: 'ke' routed out of structural estimates ('Inter-individual variability, ω')</li><li>table section iiv: 'k 12' routed out of structural estimates ('Inter-individual variability, ω')</li><li>table section iiv: 'k 21' routed out of structural estimates ('Inter-individual variability, ω')</li><li>table section residual_error: 'C' routed out of structural estimates ('Residual variability, σ')</li><li>table representations disagree for 'V'; source reconciliation required</li><li>table representations disagree for 'ke'; source reconciliation required</li><li>table representations disagree for 'k 12'; source reconciliation required</li><li>table representations disagree for 'k 21'; source reconciliation required</li><li>dropped value-less row: 'k12'</li><li>dropped value-less row: 'k21'</li><li>dropped value-less row: 'C'</li><li>dropped value-less row: 'ω'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Oxaliplatin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxaliplatin_Kobuchi2020_reference;
