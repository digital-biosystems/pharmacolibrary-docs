model Oxaliplatin_Jeon2016_reference
  parameter Real Cl_ref = 1.967592592592593e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025046 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.399306,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>rats (Sprague-Dawley) and SCC7-bearing mice</td></tr><tr><td>source_paper:</td><td>Jeon_2016</td></tr><tr><td>measured_compound:</td><td>oxaliplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxaliplatin 399.306 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'solubility of OXA in water' — extend the ontology if this is a real PK parameter (source ['Jeon_2016:abstract'])</li><li>dropped unlinked row (NIL): 'water solubility of OXA/DCK' — extend the ontology if this is a real PK parameter (source ['Jeon_2016:abstract'])</li><li>unit_dimension_unknown: '-fold higher than that of OXA' (Kp)</li><li>dropped PD-category row 'maximally inhibited tumor volume' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeon_2016:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxaliplatin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Panoilia_2015's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kobuchi_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Hill_2020's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Hill_2020, Kobuchi_2020, Panoilia_2015 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Oxaliplatin_Jeon2016_reference;
