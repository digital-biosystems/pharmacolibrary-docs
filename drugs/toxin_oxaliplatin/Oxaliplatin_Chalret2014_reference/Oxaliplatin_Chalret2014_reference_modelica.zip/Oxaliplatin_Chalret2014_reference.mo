// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Oxaliplatin_Chalret2014_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1764.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>patients with disseminated peritoneal cancer treated with HIPEC after cytoreductive surgery</td></tr><tr><td>source_paper:</td><td>Chalret_2014</td></tr><tr><td>measured_compound:</td><td>oxaliplatin (ultrafiltrated and protein-bound platinum species)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>oxaliplatin 399.306 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'maximum fraction of dose absorbed' → Q40: printed without a unit and above 1 — read as a percentage</li><li>relinked 'elimination half-life from the peritoneum' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxaliplatin (ultrafiltrated and protein-bound platinum species)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'oxaliplatin (ultrafiltrated and protein-bound platinum species)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Panoilia_2015's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Kobuchi_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Hill_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Oxaliplatin_Chalret2014_reference;
