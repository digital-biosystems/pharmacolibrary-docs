function p = Daratumumab_Luo2022_PD_infections_and_infestations_params()
% Daratumumab_Luo2022_PD_infections_and_infestations_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% daratumumab Luo_2022::infections_and_infestations: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response infections and infestations in its own unit. Driver: daratumumab (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.000689;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
