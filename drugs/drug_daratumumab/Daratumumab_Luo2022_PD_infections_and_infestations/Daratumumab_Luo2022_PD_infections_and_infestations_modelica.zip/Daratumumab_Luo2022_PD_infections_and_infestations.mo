model Daratumumab_Luo2022_PD_infections_and_infestations
  "linear exposure-response sweep — Luo_2022 :: infections and infestations (infections and infestations)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.000689   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About daratumumab</h4><p>Daratumumab is a monoclonal antibody used to treat multiple myeloma. It is approved and authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5222113\">Wikidata Q5222113</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Daratumumab_Luo2022_PD_infections_and_infestations</h4><p>The steady-state exposure-response curve of Luo MM et al., <i>Journal of clinical pharmacology 62(5):656–669</i> 2022 (<a href=\"https://doi.org/10.1002/jcph.1994\">doi:10.1002/jcph.1994</a>) — infections and infestations against daratumumab — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =   0.000689          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of daratumumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Daratumumab_Luo2022_PD_infections_and_infestations;
