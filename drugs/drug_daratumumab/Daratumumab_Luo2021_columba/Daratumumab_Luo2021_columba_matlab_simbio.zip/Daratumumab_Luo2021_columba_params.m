function p = Daratumumab_Luo2021_columba_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daratumumab   source: Luo_2021 / columba   route: oral
  % estimated (absent from source): F
  p.name  = 'Daratumumab_Luo2021_columba_params';
  p.drug  = 'daratumumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.25;                % central volume [L]
  p.CL = 0.005;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.032208;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1800.0;             % dose [mg]
end
