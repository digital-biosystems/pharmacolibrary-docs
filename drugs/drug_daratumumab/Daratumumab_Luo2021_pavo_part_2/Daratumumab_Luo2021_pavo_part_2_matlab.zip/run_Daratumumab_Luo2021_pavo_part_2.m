% Run: build params, simulate 0..3864.0 h, plot + save Daratumumab_Luo2021_pavo_part_2.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Daratumumab_Luo2021_pavo_part_2.m
here = fileparts(mfilename('fullpath'));
p = Daratumumab_Luo2021_pavo_part_2_params();
out = simulate_pk(p, 0:0.05:3864.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('daratumumab — Luo_2021 (oral)');
print(fig, fullfile(here, 'Daratumumab_Luo2021_pavo_part_2.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Daratumumab_Luo2021_pavo_part_2.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Daratumumab_Luo2021_pavo_part_2.json'), 'w');
try
  s.model = 'Daratumumab_Luo2021_pavo_part_2'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Daratumumab_Luo2021_pavo_part_2","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Daratumumab_Luo2021_pavo_part_2.png, Daratumumab_Luo2021_pavo_part_2.csv, Daratumumab_Luo2021_pavo_part_2.json\n');
