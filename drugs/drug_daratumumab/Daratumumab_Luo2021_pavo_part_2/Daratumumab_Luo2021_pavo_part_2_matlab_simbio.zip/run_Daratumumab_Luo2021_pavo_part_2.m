% Run (SimBiology): build model + dose, simulate 0..3864.0 h, plot.
p = Daratumumab_Luo2021_pavo_part_2_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3864.0);
