// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Chromium_Santos2023_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2603822.4521904034},
    MM = 0.051996,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chromium</td></tr><tr><td>population:</td><td>Enchytraeus crypticus</td></tr><tr><td>source_paper:</td><td>Santos_2023</td></tr><tr><td>measured_compound:</td><td>Chromium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>chromium 51.996 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'kg soil/kg organism/day' (kuptake)</li><li>dropped unlinked row (NIL): 'exposure to' — extend the ontology if this is a real PK parameter (source ['Santos_2023:abstract'])</li><li>dropped unlinked row (NIL): 'at' — extend the ontology if this is a real PK parameter (source ['Santos_2023:abstract'])</li><li>implicit units: 'Uptake rate constant' → 1/h (from the popPK convention: 'Parameter is defined as a first-order rate constant; conventionally expressed in 1/h (or h^-1) unless specified otherwis')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chromium</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 13305600, Tolerance = 1e-9, Interval = 26611.2));
end Chromium_Santos2023_reference;
