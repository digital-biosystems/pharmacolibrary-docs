model Chromium_Zhang2023_PD_ifn_gamma
  "linear exposure-response sweep — Zhang_2023 :: IFN-gamma (IFN-gamma)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.0314,  // [dimensionless; % × 0.01]
    exposure_per_s = 1);   // 1 Ln-transformed blood Cr per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Chromium_Zhang2023_PD_ifn_gamma</h4><p>The steady-state exposure-response curve of Zhang Y et al., <i>Journal of hazardous materials 452:131294</i> 2023 (<a href=\"https://doi.org/10.1016/j.jhazmat.2023.131294\">doi:10.1016/j.jhazmat.2023.131294</a>) — IFN-gamma [%] against chromium Ln-transformed blood Cr — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       3.14 %        change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one Ln-transformed blood Cr of chromium per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Chromium_Zhang2023_PD_ifn_gamma;
