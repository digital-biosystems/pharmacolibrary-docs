function p = Chromium_Kauermann2018_PD_lung_cancer_cases_params()
% Chromium_Kauermann2018_PD_lung_cancer_cases_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% chromium Kauermann_2018::Lung_cancer_cases: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/m3 x years per second, in SI inside (kg/m3, s). Response Lung cancer cases in its own unit. Driver: Chromium (VI) (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.78;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
