% run_Chromium_Kauermann2018_PD_lung_cancer_cases  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Chromium_Kauermann2018_PD_lung_cancer_cases_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*log(exposure);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [μg/m3 x years]'); ylabel('response []'); title('Chromium_Kauermann2018_PD_lung_cancer_cases', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Chromium_Kauermann2018_PD_lung_cancer_cases.csv');
