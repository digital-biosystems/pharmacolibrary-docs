model Chromium_Kauermann2018_PD_lung_cancer_cases
  "log_linear exposure-response sweep — Kauermann_2018 :: Lung cancer cases (Lung cancer cases)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.78   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Chromium_Kauermann2018_PD_lung_cancer_cases</h4><p>The steady-state exposure-response curve of Kauermann G et al., <i>Journal of exposure science &amp; environmental epidemiology 28(1):69–75</i> 2018 (<a href=\"https://doi.org/10.1038/jes.2017.4\">doi:10.1038/jes.2017.4</a>) — Lung cancer cases against Chromium (VI) μg/m3 x years — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.78          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one μg/m3 x years of Chromium (VI) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Chromium_Kauermann2018_PD_lung_cancer_cases;
