function p = Chromium_Ling2025_PD_mmse_score_params()
% Chromium_Ling2025_PD_mmse_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% chromium Ling_2025::MMSE_score: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/m³ per second, in SI inside (kg/m3, s). Response MMSE score in points. Driver: chromium (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.0015839722222222223;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
