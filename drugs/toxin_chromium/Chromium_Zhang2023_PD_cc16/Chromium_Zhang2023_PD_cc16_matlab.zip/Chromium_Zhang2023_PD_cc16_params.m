function p = Chromium_Zhang2023_PD_cc16_params()
% Chromium_Zhang2023_PD_cc16_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% chromium Zhang_2023::CC16: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Ln-transformed blood Cr per second, in SI inside (kg/m3, s). Response CC16 in %. Driver: chromium (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0388;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
