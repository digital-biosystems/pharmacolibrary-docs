model Hydroquinone_Legathe1994_reference
  parameter Real Cl_ref = 2.472222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0301 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.110112,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroquinone</td></tr><tr><td>population:</td><td>B6C3F1 mice</td></tr><tr><td>source_paper:</td><td>Legathe_1994</td></tr><tr><td>measured_compound:</td><td>Hydroquinone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>hydroquinone 110.112 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml/min per kilogram' (CL)</li><li>implicit units: 'The clearance of phenol' → L/h (from the popPK convention: 'No units were provided in the paper. For population pharmacokinetics, total clearance is conventionally expressed in L/h')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hydroquinone</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Obakiro_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Gáborová_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Gáborová_2024, Obakiro_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroquinone_Legathe1994_reference;
