function p = Hydroquinone_Legathe1994_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroquinone   source: Legathe_1994 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Hydroquinone_Legathe1994_reference_params';
  p.drug  = 'hydroquinone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 30.1;                % central volume [L]
  p.CL = 89.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.316783;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
