model Esomeprazole_Shin2020_i_v_plasma
  parameter Real Cl_ref = 4.513799267905857e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0026425 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345417,
    adminMass = 0.0007
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>esomeprazole</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Shin_2020</td></tr><tr><td>measured_compound:</td><td>Omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>life-10-00115-t004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Omeprazole 345.417 g/mol (pubchem); esomeprazole 345.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 4. Pharmacokinetic parameters of omeprazole from i.v./p.o./i.p. pharmacokinetics (PK) study.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Omeprazole</li><li>toxin: 17 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'i.v.-plasma' subgroup of Shin_2020 (paper reports 6 populations: i.p.-brain, i.p.-plasma, i.v.-brain, i.v.-plasma, p.o.-brain, p.o.-plasma)</li><li>review gap-fill skipped: this record measures 'Omeprazole', not esomeprazole — the review values are the parent's</li><li>derived CL=0.00162497 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Esomeprazole_Shin2020_i_v_plasma;
