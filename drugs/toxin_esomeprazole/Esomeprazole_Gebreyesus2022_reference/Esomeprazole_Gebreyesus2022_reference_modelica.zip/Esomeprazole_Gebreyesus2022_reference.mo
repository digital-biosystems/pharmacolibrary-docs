model Esomeprazole_Gebreyesus2022_reference
  parameter Real Cl_ref = 1.1722222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 33.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3454,
    adminMass = 3e-05,
    ka = 0.00026388888888888886,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>esomeprazole</td></tr><tr><td>population:</td><td>pregnant participants with preterm preeclampsia and non-pregnant participants</td></tr><tr><td>source_paper:</td><td>Gebreyesus_2022</td></tr><tr><td>measured_compound:</td><td>Esomeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>esomeprazole 345.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'clearance' → L/h (from the popPK convention: 'The value 42.2 is consistent with total clearance. In population PK, clearance is most commonly reported in L/h unless s')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Esomeprazole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Fladung_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chung_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Bae_2021's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Bae_2021, Chung_2022, Fladung_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Esomeprazole_Gebreyesus2022_reference;
