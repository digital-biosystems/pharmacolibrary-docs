function p = Esomeprazole_Tian2018_hpag_34_82_3_05_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: esomeprazole   source: Tian_2018 / hpag_34_82_3_05   route: oral
  % estimated (absent from source): F
  p.name  = 'Esomeprazole_Tian2018_hpag_34_82_3_05_params';
  p.drug  = 'esomeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.17;                % central volume [L]
  p.CL = 6.85;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
