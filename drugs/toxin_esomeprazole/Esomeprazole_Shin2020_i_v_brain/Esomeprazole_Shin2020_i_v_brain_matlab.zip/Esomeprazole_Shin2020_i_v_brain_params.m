function p = Esomeprazole_Shin2020_i_v_brain_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: esomeprazole   source: Shin_2020 / i_v_brain   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Esomeprazole_Shin2020_i_v_brain_params';
  p.drug  = 'esomeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1245.5268;                % central volume [L]
  p.CL = 1069.992;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
