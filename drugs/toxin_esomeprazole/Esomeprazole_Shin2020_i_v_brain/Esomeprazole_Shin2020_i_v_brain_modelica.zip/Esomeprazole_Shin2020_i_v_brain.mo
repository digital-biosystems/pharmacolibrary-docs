model Esomeprazole_Shin2020_i_v_brain
  parameter Real Cl_ref = 0.00029721999999999995 "Cl [m3/s]";
  parameter Real Vd_ref = 1.2455268000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345417,
    adminMass = 0.0007
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>esomeprazole</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Shin_2020</td></tr><tr><td>measured_compound:</td><td>Omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>life-10-00115-t004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Omeprazole 345.417 g/mol (pubchem); esomeprazole 345.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PK Parameters of Omeprazole. / Brain/Plasma Ratio (%)' — extend the ontology if this is a real PK parameter (source ['life-10-00115-t004:row6:col7'])</li><li>dropped value-less row: 'Table 4. Pharmacokinetic parameters of omeprazole from i.v./p.o./i.p. pharmacokinetics (PK) study.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Omeprazole</li><li>toxin: 17 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'i.v.-brain' subgroup of Shin_2020 (paper reports 6 populations: i.p.-brain, i.p.-plasma, i.v.-brain, i.v.-plasma, p.o.-brain, p.o.-plasma)</li><li>review gap-fill skipped: this record measures 'Omeprazole', not esomeprazole — the review values are the parent's</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Esomeprazole_Shin2020_i_v_brain;
