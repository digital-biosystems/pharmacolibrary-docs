% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Esomeprazole_Shin2020_i_v_brain_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
