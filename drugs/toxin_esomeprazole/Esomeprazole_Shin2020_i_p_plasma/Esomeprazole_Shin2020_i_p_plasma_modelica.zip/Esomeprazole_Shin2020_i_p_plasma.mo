// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Esomeprazole_Shin2020_i_p_plasma
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {293149.19999999995},
    MM = 0.345417,
    adminMass = 0.0007,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>esomeprazole</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Shin_2020</td></tr><tr><td>measured_compound:</td><td>Omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>life-10-00115-t004</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Omeprazole 345.417 g/mol (pubchem); esomeprazole 345.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Table 4. Pharmacokinetic parameters of omeprazole from i.v./p.o./i.p. pharmacokinetics (PK) study.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Omeprazole</li><li>toxin: 17 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'i.p.-plasma' subgroup of Shin_2020 (paper reports 6 populations: i.p.-brain, i.p.-plasma, i.v.-brain, i.v.-plasma, p.o.-brain, p.o.-plasma)</li><li>review gap-fill skipped: this record measures 'Omeprazole', not esomeprazole — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 2937.6));
end Esomeprazole_Shin2020_i_p_plasma;
