function p = Esomeprazole_Kaur2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: esomeprazole   source: Kaur_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Esomeprazole_Kaur2022_reference_params';
  p.drug  = 'esomeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4137.0;                % central volume [L]
  p.CL = 567.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
