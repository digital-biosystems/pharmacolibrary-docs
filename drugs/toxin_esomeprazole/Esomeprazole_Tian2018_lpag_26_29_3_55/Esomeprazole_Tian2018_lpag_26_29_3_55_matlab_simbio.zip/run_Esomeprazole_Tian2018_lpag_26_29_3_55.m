% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Esomeprazole_Tian2018_lpag_26_29_3_55_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
