function p = Pantoprazole_Grafeneder2024_hdp_n_17_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pantoprazole   source: Grafeneder_2024 / hdp_n_17   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Pantoprazole_Grafeneder2024_hdp_n_17_params';
  p.drug  = 'pantoprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 226.0;                % central volume [L]
  p.CL = 6.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.325;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
