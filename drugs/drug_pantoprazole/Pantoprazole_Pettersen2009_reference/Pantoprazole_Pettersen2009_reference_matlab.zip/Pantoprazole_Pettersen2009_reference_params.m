function p = Pantoprazole_Pettersen2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pantoprazole   source: Pettersen_2009 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Pantoprazole_Pettersen2009_reference_params';
  p.drug  = 'pantoprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.2;                % central volume [L]
  p.CL = 5.08;                % clearance [L/h]
  p.Vp = [2.69];             % peripheral volumes [L]
  p.Q  = [1.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.325;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
