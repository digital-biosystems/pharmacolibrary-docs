function p = Methadone_SamieeZafarghandy2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methadone   source: Samiee-Zafarghandy_2021 / reference   route: oral
  p.name  = 'Methadone_SamieeZafarghandy2021_reference_params';
  p.drug  = 'methadone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26.9;                % central volume [L]
  p.CL = 0.244;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.72;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
