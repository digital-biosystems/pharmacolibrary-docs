model Methadone_Csajka2016_PD_qtc
  "linear exposure-response sweep — Csajka_2016 :: QTc (QTc Interval)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 9900000,  // [(1)/(kg/m3); ms per 1000 ng/ml × 1e+06]
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // slope_unit_assumed: slope unit 'ms per 1000 ng/ml' read as response per ng/ml
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Methadone_Csajka2016_PD_qtc</h4><p>The steady-state exposure-response curve of Csajka C et al., <i>Clinical pharmacokinetics 55(12):1521-1533</i> 2016 (<a href=\"https://doi.org/10.1007/s40262-016-0415-2\">doi:10.1007/s40262-016-0415-2</a>) — QTc Interval [ms] against (R)-methadone ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        9.9 ms per 1000 ng/ml change in response per unit of exposure (Slope (R-methadone), Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of (R)-methadone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Methadone_Csajka2016_PD_qtc;
