function p = Methadone_Csajka2016_PD_qtc_2_params()
% Methadone_Csajka2016_PD_qtc_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methadone Csajka_2016::QTc::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response QTc in ms. Driver: (S)-methadone (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 19200000.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
