function p = Methadone_Wang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methadone   source: Wang_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methadone_Wang2022_reference_params';
  p.drug  = 'methadone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 365.0;                % central volume [L]
  p.CL = 63.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.72;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
