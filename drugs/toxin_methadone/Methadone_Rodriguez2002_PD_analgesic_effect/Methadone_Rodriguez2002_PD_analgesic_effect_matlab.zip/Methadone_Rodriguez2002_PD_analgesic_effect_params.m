function p = Methadone_Rodriguez2002_PD_analgesic_effect_params()
% Methadone_Rodriguez2002_PD_analgesic_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methadone Rodriguez_2002::analgesic_effect: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/l per second, in SI inside (kg/m3, s). Response analgesic effect in %. Driver: methadone (pk_record).
p.E0 = 0.0;
p.Emax = 0.37;
p.EC50 = 2.4099999999999996e-05;
p.gamma = 6.3;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 250.0;
p.form = 'E0 + Emax*frac';
end
