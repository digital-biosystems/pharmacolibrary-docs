model Methadone_Rodriguez2002_PD_analgesic_effect
  "sigmoid_emax exposure-response sweep — Rodriguez_2002 :: analgesic effect (tail-flick analgesia)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.37,  // [1; % × 0.01]
    EC50 = 2.41e-05,  // [kg/m3; microg/l × 1e-06]
    gamma = 6.3,
    exposure_per_s = 1e-06);   // 1 microg/l per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 250, Interval = 0.5),
    Documentation(info = "<html><body><h4>Methadone_Rodriguez2002_PD_analgesic_effect</h4><p>The steady-state exposure-response curve of Rodriguez M et al., <i>Pharmaceutical research 19(6):858-867</i> 2002 (<a href=\"https://doi.org/10.1023/a:1016117218760\">doi:10.1023/a:1016117218760</a>) — tail-flick analgesia [%] against methadone microg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         37 %        maximal effect term (Emax, Q320)
  EC50  =       24.1 microg/l exposure at half of the maximal effect term (EC50, Q321)
  gamma =        6.3          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg/l of methadone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (24.1 microg/l)  response 0.185
  exposure -> infinity  response 0.37</pre></body></html>"));
end Methadone_Rodriguez2002_PD_analgesic_effect;
