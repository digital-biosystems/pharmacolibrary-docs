function p = Methadone_Wiles2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methadone   source: Wiles_2015 / reference   route: oral
  p.name  = 'Methadone_Wiles2015_reference_params';
  p.drug  = 'methadone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 177.0;                % central volume [L]
  p.CL = 8.94;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.72;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
