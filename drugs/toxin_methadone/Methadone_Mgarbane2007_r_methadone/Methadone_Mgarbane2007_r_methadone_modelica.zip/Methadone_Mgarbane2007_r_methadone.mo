model Methadone_Mgarbane2007_r_methadone
  parameter Real Cl_ref = 2.523361889202009e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00024,
    ka = 0.0007555555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methadone</td></tr><tr><td>population:</td><td>44-year-old man, methadone-maintained patient</td></tr><tr><td>source_paper:</td><td>Mégarbane_2007</td></tr><tr><td>measured_compound:</td><td>R-methadone and S-methadone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methadone 309.453 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'T1/2' → h (from the paper text: &quot;The paper explicitly defines T1/2 as 'half-life' in the Table 1 caption and reports elimination half-lives in hours in t&quot;)</li><li>implicit units: 'Maximal observed concentration' → ng/ml (from the paper text: &quot;The abstract states 'Initial plasma R,S-methadone concentration was 1,204 ng/ml' and the results section mentions 'maxim&quot;)</li><li>implicit units: 'Vz/F' → L (from the paper text: &quot;In the discussion section, the text compares values stating: 'The Vz/F values of R- and S-methadone (211 versus 170 l, r&quot;)</li><li>implicit units: 'Clt/F' → L/h (from the popPK convention: 'No unit is explicitly stated for Clt/F in the provided text or captions. For population pharmacokinetic parameters, tota')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=R-methadone and S-methadone</li><li>population split: 'r-methadone' subgroup of Mégarbane_2007 (paper reports 3 populations: r,s-methadone, r-methadone, s-methadone)</li><li>molar mass: no plausible PubChem entry for 'R-methadone and S-methadone' ('R-methadone and S-methadone') — left in mass units</li><li>molar mass: none found for 'R-methadone and S-methadone' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Watt_2026's review values (primary lacked it)</li><li>derived CL/F=9.0841 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Methadone_Mgarbane2007_r_methadone;
