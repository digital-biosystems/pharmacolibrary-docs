% Run: build params, simulate 0..72.0 h, plot + save Methadone_Mgarbane2007_s_methadone.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Methadone_Mgarbane2007_s_methadone.m
here = fileparts(mfilename('fullpath'));
p = Methadone_Mgarbane2007_s_methadone_params();
out = simulate_pk(p, 0:0.05:72.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('methadone — Mégarbane_2007 (oral)');
print(fig, fullfile(here, 'Methadone_Mgarbane2007_s_methadone.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Methadone_Mgarbane2007_s_methadone.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Methadone_Mgarbane2007_s_methadone.json'), 'w');
try
  s.model = 'Methadone_Mgarbane2007_s_methadone'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Methadone_Mgarbane2007_s_methadone","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Methadone_Mgarbane2007_s_methadone.png, Methadone_Mgarbane2007_s_methadone.csv, Methadone_Mgarbane2007_s_methadone.json\n');
