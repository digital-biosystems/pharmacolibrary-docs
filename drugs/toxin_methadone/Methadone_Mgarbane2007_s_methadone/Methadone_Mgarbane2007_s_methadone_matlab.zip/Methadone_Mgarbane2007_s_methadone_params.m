function p = Methadone_Mgarbane2007_s_methadone_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methadone   source: Mégarbane_2007 / s_methadone   route: oral
  p.name  = 'Methadone_Mgarbane2007_s_methadone_params';
  p.drug  = 'methadone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 170.0;                % central volume [L]
  p.CL = 9.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.72;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 240.0;             % dose [mg]
end
