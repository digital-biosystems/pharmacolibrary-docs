// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Methadone_Ward2014_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.021500000000000002, 0.0751},
    CLelim = {2.625e-06, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {9.027777777777779e-05, 9.027777777777779e-05}
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methadone</td></tr><tr><td>population:</td><td>neonates, infants, and children</td></tr><tr><td>source_paper:</td><td>Ward_2014</td></tr><tr><td>measured_compound:</td><td>Methadone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>2-ethyl-5-methyl-3,3-diphenylpyrroline 263.384 g/mol (pubchem); 2-ethylidine-1,5-dimethyl-3,3-diphenylpyrrolidine 277.411 g/mol (pubchem); Methadone 309.453 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for kcomp from footnote/prose kept as documentation only (['Ward_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methadone</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>template fit: none — a metabolite is formed from another metabolite (a chain)</li><li>row roles (LLM): model_class=compartmental; 10/10 row label(s) assigned, 9 linked by role; re-tagged Methadone→parent ×6, Methadone→2-ethylidine-1,5-dimethyl-3,3-diphenylpyrrolidine ×2, Methadone→2-ethyl-5-methyl-3,3-diphenylpyrroline ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Watt_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methadone_Ward2014_reference;
