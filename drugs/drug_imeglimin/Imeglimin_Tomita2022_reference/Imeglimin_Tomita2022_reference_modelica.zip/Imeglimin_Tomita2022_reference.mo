model Imeglimin_Tomita2022_reference
  parameter Real Cl_ref = 1.8583333333333332e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14200000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.155205,
    adminMass = 0.0005,
    ka = 3.9999999999999996e-05,
    Tlag = 824.4,
    k12 = 3.110328638497653e-05,
    k21 = 1.1809269162210339e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About imeglimin</h4><p>Imeglimin is a blood glucose lowering drug investigated for diabetes. It is classed as investigational and is not an approved medicine in major databases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6003719\">Wikidata Q6003719</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>imeglimin</td></tr><tr><td>population:</td><td>Japanese and Western patients with type 2 diabetes</td></tr><tr><td>source_paper:</td><td>Tomita_2022</td></tr><tr><td>measured_compound:</td><td>imeglimin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13221-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>imeglimin 155.205 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=imeglimin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Imeglimin_Tomita2022_reference;
