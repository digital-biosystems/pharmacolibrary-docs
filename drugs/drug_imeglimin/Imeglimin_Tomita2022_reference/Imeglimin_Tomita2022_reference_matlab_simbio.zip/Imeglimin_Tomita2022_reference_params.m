function p = Imeglimin_Tomita2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imeglimin   source: Tomita_2022 / reference   route: oral
  p.name  = 'Imeglimin_Tomita2022_reference_params';
  p.drug  = 'imeglimin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 142.0;                % central volume [L]
  p.CL = 66.9;                % clearance [L/h]
  p.Vp = [374.0];             % peripheral volumes [L]
  p.Q  = [15.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.144;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.229;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
