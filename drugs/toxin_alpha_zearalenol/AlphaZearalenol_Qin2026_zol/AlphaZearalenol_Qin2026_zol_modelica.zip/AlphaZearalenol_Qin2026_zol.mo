// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model AlphaZearalenol_Qin2026_zol
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {38160.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alpha_zearalenol</td></tr><tr><td>population:</td><td>male sheep</td></tr><tr><td>source_paper:</td><td>Qin_2026</td></tr><tr><td>measured_compound:</td><td>alpha-Zearalenol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>toxins-18-00364-t002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>alpha_zearalenol 320.385 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>conflicting source units for 'AUC(0–72h)': [{'unit': 'ng·mL−1·h', 'source': 'Qin_2026_table_3:row2:col1', 'scope': 'unit_column'}, {'unit': '0–72h', 'source': 'Qin_2026_table_3:row2:col0', 'scope': 'label'}]</li><li>dropped duplicate Q88 ('AUC(0–∞)', value '243.23') — already have one for this compound</li><li>dropped value-less row: 'Serum samples were determined for β-ZOL'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alpha-Zearalenol</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>population split: 'α-zol' subgroup of Qin_2026 (paper reports 1 populations: α-zol)</li><li>row roles (LLM): model_class=noncompartmental; 0/16 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'zearalenone-14-glucoside (Z14G)' — its concentrations stay mass-only</li><li>molar mass: none found for 'zearalenone (ZEN)' — its concentrations stay mass-only</li><li>molar mass: none found for 'beta-Zearalenol (β-ZOL)' — its concentrations stay mass-only</li><li>molar mass: none found for 'alpha-Zearalenol' — its concentrations stay mass-only</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end AlphaZearalenol_Qin2026_zol;
