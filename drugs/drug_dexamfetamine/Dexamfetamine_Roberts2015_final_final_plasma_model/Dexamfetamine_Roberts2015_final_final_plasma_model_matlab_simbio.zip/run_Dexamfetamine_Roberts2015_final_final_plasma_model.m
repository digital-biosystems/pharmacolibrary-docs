% Run (SimBiology): build model + dose, simulate 0..47.0 h, plot.
p = Dexamfetamine_Roberts2015_final_final_plasma_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 47.0);
