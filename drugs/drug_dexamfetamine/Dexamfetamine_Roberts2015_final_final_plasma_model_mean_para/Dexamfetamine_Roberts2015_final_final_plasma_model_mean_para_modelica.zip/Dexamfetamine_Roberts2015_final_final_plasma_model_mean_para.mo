model Dexamfetamine_Roberts2015_final_final_plasma_model_mean_para
  parameter Real Cl_ref = 7.861111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.377 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.13521,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dexamfetamine</h4><p>Dexamfetamine is a central nervous system stimulant used to treat attention deficit hyperactivity disorder and narcolepsy. The drug is widely used, though its illicit application for performance enhancement and recreational use is also common.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q1706418\">Wikidata Q1706418</a>, <a href=\"https://en.wikipedia.org/wiki/Dextroamphetamine?oldid=1383928500\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexamfetamine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Roberts_2015</td></tr><tr><td>measured_compound:</td><td>dextroamphetamine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>dexamfetamine 135.21 g/mol (pubchem); dextroamphetamine 135.21 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'K12' routed out of structural estimates ('ω2-BSV')</li><li>table section iiv: 'V1/F' routed out of structural estimates ('ω2-BSV')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('ω2-BSV')</li><li>table section residual_error: 'Additive (ng/mL)' routed out of structural estimates ('σ2-RUV')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('σ2-RUV')</li><li>dropped duplicate Q319 ('θ2', value '0.512') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dextroamphetamine</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F (L)' is the general volume)</li><li>model-stage split: 'final plasma model / mean parameter estimate' is the final model of Roberts_2015 (paper reports 2 stages: final linked model / mean parameter estimate, final plasma model / mean parameter estimate); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Dexamfetamine_Roberts2015_final_final_plasma_model_mean_para;
