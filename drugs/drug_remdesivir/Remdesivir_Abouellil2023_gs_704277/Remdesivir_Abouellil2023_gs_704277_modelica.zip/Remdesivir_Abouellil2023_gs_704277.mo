// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Remdesivir_Abouellil2023_gs_704277
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.09640000000000001, 0.00864},
    CLelim = {1.025e-05, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {3.3333333333333334e-08, 3.3333333333333334e-08}
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About remdesivir</h4><p>Remdesivir is an antiviral drug used to treat COVID-19 and was also studied for Ebola virus disease. It is authorised in the European Union for COVID-19 and remains an approved medicine, though it has also been used investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209496\">Wikidata Q28209496</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>remdesivir</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Abouellil_2023</td></tr><tr><td>measured_compound:</td><td>remdesivir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>molar_masses:</td><td>GS-441524 291.267 g/mol (pubchem); GS-704277 442.325 g/mol (pubchem); remdesivir 602.585 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q370 ('Peripheral formation clearance (L/h)', value '18.9') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=remdesivir</li><li>topology: 2 first-order transfer(s) across 3 compounds → general_linear</li><li>template fit: none — a metabolite is formed from another metabolite (a chain)</li><li>population split: 'gs‐704277' subgroup of Abouellil_2023 (paper reports 3 populations: gs‐441524, gs‐704277, remdesivir)</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 15 linked by role; re-tagged remdesivir→parent ×4, parent→GS-704277 ×3</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Remdesivir_Abouellil2023_gs_704277;
