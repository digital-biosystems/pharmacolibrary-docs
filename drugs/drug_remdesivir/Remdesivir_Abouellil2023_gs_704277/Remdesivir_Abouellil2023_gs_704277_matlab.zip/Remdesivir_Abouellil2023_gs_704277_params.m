function p = Remdesivir_Abouellil2023_gs_704277_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remdesivir   source: Abouellil_2023 / gs_704277   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Remdesivir_Abouellil2023_gs_704277_params';
  p.drug  = 'remdesivir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 96.4;                % central volume [L]
  p.CL = 36.9;                % clearance [L/h]
  p.Vp = [8.64];             % peripheral volumes [L]
  p.Q  = [0.12];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
