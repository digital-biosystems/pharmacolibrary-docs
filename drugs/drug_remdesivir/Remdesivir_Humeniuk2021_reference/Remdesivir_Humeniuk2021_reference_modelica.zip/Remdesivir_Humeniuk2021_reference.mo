model Remdesivir_Humeniuk2021_reference
  parameter Real Cl_ref = 1.808333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0926 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.602585,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About remdesivir</h4><p>Remdesivir is an antiviral drug used to treat COVID-19 and was also studied for Ebola virus disease. It is authorised in the European Union for COVID-19 and remains an approved medicine, though it has also been used investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209496\">Wikidata Q28209496</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>remdesivir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Humeniuk_2021</td></tr><tr><td>measured_compound:</td><td>remdesivir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>remdesivir 602.585 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Humeniuk_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Remdesivir_Humeniuk2021_reference;
