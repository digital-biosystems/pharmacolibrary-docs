model Remdesivir_Morrisette2020_reference
  parameter Real Cl_ref = 4.305555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.9682647766926279 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.602585,
    adminMass = 0.00012
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About remdesivir</h4><p>Remdesivir is an antiviral drug used to treat COVID-19 and was also studied for Ebola virus disease. It is authorised in the European Union for COVID-19 and remains an approved medicine, though it has also been used investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209496\">Wikidata Q28209496</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>remdesivir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Morrisette_2020</td></tr><tr><td>measured_compound:</td><td>remdesivir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>remdesivir 602.585 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Morrisette_2020) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Remdesivir_Morrisette2020_reference;
