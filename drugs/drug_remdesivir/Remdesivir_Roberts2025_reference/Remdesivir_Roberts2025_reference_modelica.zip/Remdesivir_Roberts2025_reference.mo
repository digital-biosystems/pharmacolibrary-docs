model Remdesivir_Roberts2025_reference
  parameter Real Cl_ref = 4.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.429 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29125999999999996,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About remdesivir</h4><p>Remdesivir is an antiviral drug used to treat COVID-19 and was also studied for Ebola virus disease. It is authorised in the European Union for COVID-19 and remains an approved medicine, though it has also been used investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209496\">Wikidata Q28209496</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>remdesivir</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Roberts_2025</td></tr><tr><td>measured_compound:</td><td>GS-441524</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>GS-441524 291.26 g/mol (paper); remdesivir 602.585 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is remdesivir; the compartment is GS-441524. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is GS-441524, not remdesivir</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>remdesivir's own concentration-time course is not produced by this model</li><li>table section iiv: 'Remdesivir CL' routed out of structural estimates ('Between subject variability (%)')</li><li>table section iiv: 'Remdesivir V' routed out of structural estimates ('Between subject variability (%)')</li><li>table section iiv: 'GS-441524 CL/fm' routed out of structural estimates ('Between subject variability (%)')</li><li>table section iiv: 'GS-441524 V/fm' routed out of structural estimates ('Between subject variability (%)')</li><li>covariate level 'eGFR effect on CL' → Q900:egfr_effect_on_cl = 1.12 (linear_fractional on Q22)</li><li>routed 'Remdesivir proportional error' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'GS-441524 proportional error' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=GS-441524</li><li>review gap-fill skipped: this record measures 'GS-441524', not remdesivir — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Remdesivir_Roberts2025_reference;
