% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Remdesivir_Abouellil2023_gs_441524_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
