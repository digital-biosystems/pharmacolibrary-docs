function p = Remdesivir_Abouellil2023_gs_441524_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remdesivir   source: Abouellil_2023 / gs_441524   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Remdesivir_Abouellil2023_gs_441524_params';
  p.drug  = 'remdesivir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 26.2;                % central volume [L]
  p.CL = 4.74;                % clearance [L/h]
  p.Vp = [66.2];             % peripheral volumes [L]
  p.Q  = [55.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
