model Zalcitabine_Klecker1988_reference
  parameter Real Cl_ref = 6.545166666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0378 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zalcitabine</td></tr><tr><td>population:</td><td>patients with AIDS or AIDS-related complex</td></tr><tr><td>source_paper:</td><td>Klecker_1988</td></tr><tr><td>measured_compound:</td><td>2',3'-dideoxycytidine (DDC)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zalcitabine 211.221 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2',3'-dideoxycytidine (DDC)</li><li>molar mass: none of 1 PubChem candidate(s) is &quot;2',3'-dideoxycytidine (DDC)&quot; (LLM) — left in mass units</li><li>molar mass: none found for &quot;2',3'-dideoxycytidine (DDC)&quot; — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zalcitabine_Klecker1988_reference;
