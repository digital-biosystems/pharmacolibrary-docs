// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Zalcitabine_Zeidner1989_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3600.0},
    MM = 0.211221,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zalcitabine</td></tr><tr><td>population:</td><td>cats</td></tr><tr><td>source_paper:</td><td>Zeidner_1989</td></tr><tr><td>measured_compound:</td><td>Zalcitabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>zalcitabine 211.221 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('average peak plasma concentration', value 17) — already have one for this compound</li><li>unit_dimension_unknown: 'bolus subcutaneous injection' (t1/2z)</li><li>dropped duplicate Q57 ('plasma half-life (bolus subcutaneous injection)', value 1.5) — already have one for this compound</li><li>dropped duplicate Q57 ('plasma half-life', value 20) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Zalcitabine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Zalcitabine_Zeidner1989_reference;
