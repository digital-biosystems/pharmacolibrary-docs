model Zalcitabine_Adams1998_reference
  parameter Real Cl_ref = 4.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0876 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211221,
    adminMass = 2.25e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>zalcitabine</td></tr><tr><td>population:</td><td>human immunodeficiency virus-infected patients</td></tr><tr><td>source_paper:</td><td>Adams_1998</td></tr><tr><td>measured_compound:</td><td>Zalcitabine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>zalcitabine 211.221 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'age' — extend the ontology if this is a real PK parameter (source ['Adams_1998:abstract'])</li><li>dropped unlinked row (NIL): 'weight' — extend the ontology if this is a real PK parameter (source ['Adams_1998:abstract'])</li><li>dropped unlinked row (NIL): 'estimated creatinine clearance' — extend the ontology if this is a real PK parameter (source ['Adams_1998:abstract'])</li><li>dropped duplicate Q27 ('individual estimates of oral clearance', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Zalcitabine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zalcitabine_Adams1998_reference;
