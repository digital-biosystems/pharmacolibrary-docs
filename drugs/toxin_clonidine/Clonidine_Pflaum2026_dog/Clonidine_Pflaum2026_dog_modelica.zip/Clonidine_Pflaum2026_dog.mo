// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Clonidine_Pflaum2026_dog
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2340.0},
    MM = 0.23009200000000002,
    adminMass = 3.5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonidine</td></tr><tr><td>population:</td><td>healthy laboratory beagles</td></tr><tr><td>source_paper:</td><td>Pflaum_2026</td></tr><tr><td>measured_compound:</td><td>Clonidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>clonidine 230.092 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Clonidine</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'dog' subgroup of Pflaum_2026 (paper reports 4 populations: dog, er dog 1, er dog 2, human)</li><li>gap-filled Q22 (CL) from Cloesmeijer_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Tang_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Clonidine_Pflaum2026_dog;
