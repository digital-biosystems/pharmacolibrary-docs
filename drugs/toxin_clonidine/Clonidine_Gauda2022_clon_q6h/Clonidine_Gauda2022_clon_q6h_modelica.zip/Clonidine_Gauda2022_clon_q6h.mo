model Clonidine_Gauda2022_clon_q6h
  parameter Real Cl_ref = 3.302777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23009200000000002,
    adminMass = 7e-08,
    ka = 0.00024694444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonidine</td></tr><tr><td>population:</td><td>infants with hypoxic ischemic encephalopathy undergoing therapeutic hypothermia</td></tr><tr><td>source_paper:</td><td>Gauda_2022</td></tr><tr><td>measured_compound:</td><td>Clonidine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clonidine 230.092 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'DOL 1 Total (mg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row0:col2'])</li><li>dropped unlinked row (NIL): 'DOL 2 Total (mg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row1:col2'])</li><li>dropped unlinked row (NIL): 'DOL 1, Q6h Total (mg/kg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row2:col2'])</li><li>dropped unlinked row (NIL): 'DOL 2, Q6h Total (mg/kg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row3:col2'])</li><li>dropped unlinked row (NIL): 'DOL 1, PRN Total (mg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row4:col2'])</li><li>dropped unlinked row (NIL): 'DOL 2, PRN Total (mg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row5:col2'])</li><li>dropped unlinked row (NIL): 'DOL 1, PRN Total (mg/kg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row6:col2'])</li><li>dropped unlinked row (NIL): 'DOL 2, PRN Total (mg/kg/24hr)' — extend the ontology if this is a real PK parameter (source ['Gauda_2022_table_2:row7:col2'])</li><li>table mostly unlinked (8/8 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q61 ('volume of distribution (Vd)'=280) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance (CL) of IV clonidine'=11.89) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F for infants receiving oral clonidine'=15.2) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Vd/F'=402) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Clonidine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Clonidine_Gauda2022_clon_q6h;
