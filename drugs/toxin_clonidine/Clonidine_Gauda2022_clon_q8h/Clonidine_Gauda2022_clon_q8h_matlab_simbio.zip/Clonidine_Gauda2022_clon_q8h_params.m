function p = Clonidine_Gauda2022_clon_q8h_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clonidine   source: Gauda_2022 / clon_q8h   route: oral
  p.name  = 'Clonidine_Gauda2022_clon_q8h_params';
  p.drug  = 'clonidine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 280.0;                % central volume [L]
  p.CL = 11.89;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.889;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.07;             % dose [mg]
end
