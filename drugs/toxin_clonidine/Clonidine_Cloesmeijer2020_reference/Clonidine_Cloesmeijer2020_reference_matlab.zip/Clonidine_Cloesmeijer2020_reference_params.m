function p = Clonidine_Cloesmeijer2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clonidine   source: Cloesmeijer_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Clonidine_Cloesmeijer2020_reference_params';
  p.drug  = 'clonidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 124.0;                % central volume [L]
  p.CL = 17.0;                % clearance [L/h]
  p.Vp = [178.0];             % peripheral volumes [L]
  p.Q  = [83.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.889;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.1;             % dose [mg]
end
