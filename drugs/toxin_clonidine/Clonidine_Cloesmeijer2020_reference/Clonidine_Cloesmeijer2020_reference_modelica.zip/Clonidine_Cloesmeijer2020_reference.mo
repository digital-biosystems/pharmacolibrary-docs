model Clonidine_Cloesmeijer2020_reference
  parameter Real Cl_ref = 4.722222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.124 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23009200000000002,
    adminMass = 1.0000000000000001e-07,
    ka = 0.00024694444444444444,
    Tlag = 0.0,
    k12 = 0.00018750000000000003,
    k21 = 0.0001306179775280899
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonidine</td></tr><tr><td>population:</td><td>adult mechanically ventilated sedated ICU patients</td></tr><tr><td>source_paper:</td><td>Cloesmeijer_2020</td></tr><tr><td>measured_compound:</td><td>Clonidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp14273-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clonidine 230.092 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V1 (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error (μg/L)' routed out of structural estimates ('Residual variability')</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Clonidine</li><li>model equation 'θpop = θpk×CovCovmedianθexp (6)θpop=θpk×1+Cov×θslope' not bound — neither LHS nor base term 'θpk' linked to an ontology parameter</li><li>gap-filled Q49 (kabs) from Tang_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Clonidine_Cloesmeijer2020_reference;
