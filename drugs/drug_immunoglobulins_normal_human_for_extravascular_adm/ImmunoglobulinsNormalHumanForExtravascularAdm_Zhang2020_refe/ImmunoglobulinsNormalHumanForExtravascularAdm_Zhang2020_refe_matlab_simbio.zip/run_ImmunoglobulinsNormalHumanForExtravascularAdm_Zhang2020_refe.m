% Run (SimBiology): build model + dose, simulate 0..2520.0 h, plot.
p = ImmunoglobulinsNormalHumanForExtravascularAdm_Zhang2020_refe_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2520.0);
