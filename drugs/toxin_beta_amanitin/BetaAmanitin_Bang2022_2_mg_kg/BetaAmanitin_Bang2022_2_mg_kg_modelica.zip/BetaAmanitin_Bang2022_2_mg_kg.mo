// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model BetaAmanitin_Bang2022_2_mg_kg
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6300.0},
    MM = 0.919961,
    adminMass = 1.4e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>beta_amanitin</td></tr><tr><td>population:</td><td>male ICR mice</td></tr><tr><td>source_paper:</td><td>Bang_2022</td></tr><tr><td>measured_compound:</td><td>beta-Amanitin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00774-t001</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>beta_amanitin 920 g/mol (pubchem); beta-Amanitin 919.961 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=beta-Amanitin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: '2 mg/kg (n = 7)' subgroup of Bang_2022 (paper reports 6 populations: 0.2 mg/kg (n = 8), 0.4 mg/kg (n = 6), 0.8 mg/kg (n = 7), 10 mg/kg (n = 7), 2 mg/kg (n = 7), 5 mg/kg (n = 9))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end BetaAmanitin_Bang2022_2_mg_kg;
