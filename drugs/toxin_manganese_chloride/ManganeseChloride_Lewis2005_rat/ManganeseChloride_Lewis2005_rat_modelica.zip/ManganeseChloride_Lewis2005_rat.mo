// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ManganeseChloride_Lewis2005_rat
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {712951.385718801},
    MM = 0.054938,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>manganese_chloride</td></tr><tr><td>population:</td><td>Fischer 344/N rats and FVB/N mice</td></tr><tr><td>source_paper:</td><td>Lewis_2005</td></tr><tr><td>measured_compound:</td><td>Manganese</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Manganese 54.938 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'C_controls_bar (mg/kg)' — extend the ontology if this is a real PK parameter (source ['Lewis_2005_table_p32_1:row1:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Manganese</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>population split: 'rat' subgroup of Lewis_2005 (paper reports 2 populations: mouse, rat)</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role; re-tagged parent→Manganese ×8</li><li>molar mass: no plausible PubChem entry for 'Manganese chloride' ('manganese chloride') — left in mass units</li><li>molar mass: none found for 'Manganese chloride' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Manganese', not manganese_chloride — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 7257.6));
end ManganeseChloride_Lewis2005_rat;
