function p = Noscapine_Chen2024_final_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: noscapine   source: Chen_2024 / final_model   route: oral
  p.name  = 'Noscapine_Chen2024_final_model_params';
  p.drug  = 'noscapine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.7;                % central volume [L]
  p.CL = 958.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 13.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
