model Noscapine_Chen2024_sir_with_m_m_ratio_of_5000_1000
  parameter Real Cl_ref = 0.00026083333333333335 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real Vd_ref = 0.049600000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.343)*cov_age_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4134205,
    adminMass = 5e-05,
    ka = 0.003611111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About noscapine</h4><p>Noscapine is an opium alkaloid used as a cough suppressant (antitussive). It is an approved medicine, classified among cough suppressants in respiratory preparations, and is not authorised centrally in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415619\">Wikidata Q415619</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>noscapine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Chen_2024</td></tr><tr><td>measured_compound:</td><td>noscapine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: transit-compartment absorption reported; transit absorption (ktr=0.003611/s, n=0) folded to first-order ka = ktr/(n+1) = 0.003611/s — same mean absorption time, no delay phase</td></tr><tr><td>molar_masses:</td><td>noscapine 413.421 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'D1' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'D1' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'Vc/F' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'Vc/F' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'F1' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iiv: 'F1' routed out of structural estimates ('Inter-individual variability (IIV, %)a')</li><li>table section iov: 'TR' routed out of structural estimates ('Inter-occasion variability (%)')</li><li>table section iov: 'TR' routed out of structural estimates ('Inter-occasion variability (%)')</li><li>table section iov: 'Qp1/F' routed out of structural estimates ('Inter-occasion variability (%)')</li><li>table section iov: 'Qp1/F' routed out of structural estimates ('Inter-occasion variability (%)')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['Tab4:row0:col3', 'Tab4:row0:col4'])</li><li>dropped duplicate Q27 ('CL/F_IM_1.5 (L/h)', value '549') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Noscapine_Chen2024_sir_with_m_m_ratio_of_5000_1000;
