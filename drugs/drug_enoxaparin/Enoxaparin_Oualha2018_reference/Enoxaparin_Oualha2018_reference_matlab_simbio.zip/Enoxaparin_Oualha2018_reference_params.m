function p = Enoxaparin_Oualha2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: enoxaparin   source: Oualha_2018 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Enoxaparin_Oualha2018_reference_params';
  p.drug  = 'enoxaparin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 14.6;                % central volume [L]
  p.CL = 1.23;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
