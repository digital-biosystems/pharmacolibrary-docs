function p = Atorvastatin_Langeskov2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atorvastatin   source: Langeskov_2022 / reference   route: oral
  p.name  = 'Atorvastatin_Langeskov2022_reference_params';
  p.drug  = 'atorvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1843.0;                % central volume [L]
  p.CL = 620.0;                % clearance [L/h]
  p.Vp = [4184.0];             % peripheral volumes [L]
  p.Q  = [873.0];             % inter-compartmental clearances [L/h]
  p.ka = 9.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.16;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
