model Atorvastatin_Langeskov2022_reference
  parameter Real Cl_ref = 0.0001722222222222222 "Cl [m3/s]";
  parameter Real Vd_ref = 1.843 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5586398,
    adminMass = 2.5e-07,
    ka = 0.0026111111111111114,
    Tlag = 576.0,
    k12 = 0.00013157894736842105,
    k21 = 5.795889101338432e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atorvastatin</h4><p>Atorvastatin is a statin used to lower blood lipids, treating conditions such as hypercholesterolemia, hypertriglyceridemia, arteriosclerosis, and coronary artery disease. It is an approved prescription medicine, widely used, and also available in combination lipid-modifying products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q668093\">Wikidata Q668093</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Langeskov_2022</td></tr><tr><td>measured_compound:</td><td>atorvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp2962-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.64 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 Ka' routed out of structural estimates ('Between subject variability (ω2)')</li><li>table section iiv: 'ω2 Ktr' routed out of structural estimates ('Between subject variability (ω2)')</li><li>table section iiv: 'ω2 V1/F' routed out of structural estimates ('Between subject variability (ω2)')</li><li>table section iiv: 'ω2 Cl/f' routed out of structural estimates ('Between subject variability (ω2)')</li><li>table section iiv: 'ω2 V2/F' routed out of structural estimates ('Between subject variability (ω2)')</li><li>table section iiv: 'Residual unexplained variability (Ceps)' routed out of structural estimates ('Between subject variability (ω2)')</li><li>table section iiv: 'ω2 Ka' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 V1/F' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 Cl/f' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 V2/F' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 Tlag' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'Residual unexplained variability (Ceps)' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>routed 'Θkacovariate' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Θktrcovariate' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q290 ('V1/F (L)', value '48.5') — already have one for this compound</li><li>dropped duplicate Q290 ('ΘV1/Fcovariate', value '0.0312') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Langeskov2022_reference;
