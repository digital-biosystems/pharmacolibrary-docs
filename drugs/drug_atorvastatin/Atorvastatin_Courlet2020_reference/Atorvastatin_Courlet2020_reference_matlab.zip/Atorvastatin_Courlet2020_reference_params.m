function p = Atorvastatin_Courlet2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atorvastatin   source: Courlet_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Atorvastatin_Courlet2020_reference_params';
  p.drug  = 'atorvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2910.0;                % central volume [L]
  p.CL = 230.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.59;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
