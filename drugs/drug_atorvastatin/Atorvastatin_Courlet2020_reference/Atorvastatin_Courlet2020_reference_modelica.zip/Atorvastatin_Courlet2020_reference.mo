model Atorvastatin_Courlet2020_reference
  parameter Real Cl_ref = 6.38888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.91 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5586398,
    adminMass = 5e-06,
    ka = 0.0007194444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atorvastatin</h4><p>Atorvastatin is a statin used to lower blood lipids, treating conditions such as hypercholesterolemia, hypertriglyceridemia, arteriosclerosis, and coronary artery disease. It is an approved prescription medicine, widely used, and also available in combination lipid-modifying products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q668093\">Wikidata Q668093</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>aging people living with HIV</td></tr><tr><td>source_paper:</td><td>Courlet_2020</td></tr><tr><td>measured_compound:</td><td>atorvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.64 g/mol (drugbank); o-OH-atorvastatin 574.649 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameters' — extend the ontology if this is a real PK parameter (source ['Tab2:row0:col3', 'Tab2:row0:col4'])</li><li>dropped unlinked row (NIL): 'θboosted ARVs' — extend the ontology if this is a real PK parameter (source ['Tab2:row6:col2', 'Tab2:row9:col2'])</li><li>dropped unlinked row (NIL): 'θCYP3A4 inducers' — extend the ontology if this is a real PK parameter (source ['Tab2:row10:col1', 'Tab2:row10:col2', 'Tab2:row10:col3'])</li><li>dropped duplicate Q61 ('Vpator (L)', value '617') — already have one for this compound</li><li>implicit units: 'ka (h−1)b' → 1/h (from the paper text: &quot;The paper text states: 'The ka was estimated at 2.59 h−1' and 'total ka was fixed to the value estimated during the anal&quot;)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CLator (L/h)); Q61 (Vcator=Vcmet (L)); Q30 (Q (L/h)); Q22 (CLo-OH-ator (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atorvastatin</li><li>template fit: PK_3M_3C — first-pass formation; parent 1 + hepatic, metabolites [0] (site presystemic: 'Metabolite concentrations were described by considering both linear metabolism from atorvastatin and presystemic metabol')</li><li>row roles (LLM): model_class=compartmental; 19/19 row label(s) assigned, 20 linked by role; re-tagged parent→o-OH-atorvastatin ×15</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Courlet2020_reference;
