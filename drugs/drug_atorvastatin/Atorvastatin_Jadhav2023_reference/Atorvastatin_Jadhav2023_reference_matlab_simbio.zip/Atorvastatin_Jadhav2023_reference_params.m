function p = Atorvastatin_Jadhav2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atorvastatin   source: Jadhav_2023 / reference   route: oral
  p.name  = 'Atorvastatin_Jadhav2023_reference_params';
  p.drug  = 'atorvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.1;                % central volume [L]
  p.CL = 0.755;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.41;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
