model Atorvastatin_Stillemans2022_shrinkage
  parameter Real Cl_ref = 0.00011518611111111112 "Cl [m3/s]";
  parameter Real Vd_ref = 1.46 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>ambulatory patients at risk of cardiovascular disease</td></tr><tr><td>source_paper:</td><td>Stillemans_2022</td></tr><tr><td>measured_compound:</td><td>atorvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13185-tbl-0003</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'ωCL investigation (SD)' (captured trailing unit 'SD' for child rows)</li><li>dropped value-less row: 'ωCL support (SD)' (captured trailing unit 'SD' for child rows)</li><li>dropped value-less row: 'ωQ (SD)' (captured trailing unit 'SD' for child rows)</li><li>dropped value-less row: 'ωVc (SD)' (captured trailing unit 'SD' for child rows)</li><li>dropped value-less row: 'ωVp (SD)' (captured trailing unit 'SD' for child rows)</li><li>salvaged Q27 ('CL/F threshold'=414.67) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=atorvastatin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'shrinkage (%)' subgroup of Stillemans_2022 (paper reports 2 populations: estimate, shrinkage (%))</li><li>gap-filled Q76 (V/F) from Chen_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Stillemans2022_shrinkage;
