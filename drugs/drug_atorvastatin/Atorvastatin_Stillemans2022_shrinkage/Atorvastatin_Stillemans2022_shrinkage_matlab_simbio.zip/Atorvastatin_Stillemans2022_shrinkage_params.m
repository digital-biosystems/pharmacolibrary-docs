function p = Atorvastatin_Stillemans2022_shrinkage_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atorvastatin   source: Stillemans_2022 / shrinkage   route: oral
  % estimated (absent from source): dose
  p.name  = 'Atorvastatin_Stillemans2022_shrinkage_params';
  p.drug  = 'atorvastatin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1460.0;                % central volume [L]
  p.CL = 414.67;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.46;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
