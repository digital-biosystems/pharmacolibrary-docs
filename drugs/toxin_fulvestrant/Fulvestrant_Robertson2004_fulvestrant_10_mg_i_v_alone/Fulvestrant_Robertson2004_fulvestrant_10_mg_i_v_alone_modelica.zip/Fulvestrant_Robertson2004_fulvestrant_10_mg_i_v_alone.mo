// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Fulvestrant_Robertson2004_fulvestrant_10_mg_i_v_alone
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3456000.0},
    MM = 0.606775,
    adminMass = 2e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fulvestrant</td></tr><tr><td>population:</td><td>healthy female postmenopausal volunteers and postmenopausal women with advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Robertson_2004</td></tr><tr><td>measured_compound:</td><td>Fulvestrant</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tbl1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>fulvestrant 606.775 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Fulvestrant 8 mg i.v.+ketoconazole 400 mg (n=18)' — extend the ontology if this is a real PK parameter (source ['Robertson_2004_table_2:row1:col1'])</li><li>dropped unlinked row (NIL): 'Midazolam 7.5 mg+fulvestrant 36 mg i.m. (n=7)' — extend the ontology if this is a real PK parameter (source ['Robertson_2004_table_2:row3:col1'])</li><li>dropped value-less row: 'gmean'</li><li>dropped value-less row: 'SD'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'AUC(0–28)' (captured trailing unit '0–28' for child rows)</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'tmax'</li><li>dropped value-less row: 'Cmin'</li><li>salvaged Q57 ('terminal elimination half-life (t1/2) of i.v. fulvestrant formulation in healthy postmenopausal female volunteers'=40) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fulvestrant</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'fulvestrant 10 mg i.v. alone (n=6)' subgroup of Robertson_2004 (paper reports 3 populations: breast cancer patients (study 0020), fulvestrant 10 mg i.v. alone (n=6), healthy volunteers)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 31104.0));
end Fulvestrant_Robertson2004_fulvestrant_10_mg_i_v_alone;
