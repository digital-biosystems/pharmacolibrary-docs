function p = Levomepromazine_ter2003_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levomepromazine   source: ter_2003 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Levomepromazine_ter2003_reference_params';
  p.drug  = 'levomepromazine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.1;                % central volume [L]
  p.CL = 309.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
