model Levomepromazine_ter2003_reference
  parameter Real Cl_ref = 8.583333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0040999999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.328474,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levomepromazine</h4><p>Levomepromazine is a phenothiazine antipsychotic used to treat pain and anxiety disorders. It is given orally in forms such as tablets and liquid solutions. The drug is approved and used in palliative care settings.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q417204\">Wikidata Q417204</a>, <a href=\"https://en.wikipedia.org/wiki/Levomepromazine?oldid=1360365557\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levomepromazine</td></tr><tr><td>population:</td><td>patients</td></tr><tr><td>source_paper:</td><td>ter_2003</td></tr><tr><td>measured_compound:</td><td>levomepromazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>levomepromazine 328.474 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l per kg lean body mass' (V/F)</li><li>implicit units: 'apparent volume of distribution' → L (from the popPK convention: 'Apparent volume of distribution (V/F) is a volume parameter. In population pharmacokinetics, the standard unit for this ')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=levomepromazine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levomepromazine_ter2003_reference;
