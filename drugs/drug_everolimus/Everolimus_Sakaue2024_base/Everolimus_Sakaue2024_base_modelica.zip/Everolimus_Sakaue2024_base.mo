model Everolimus_Sakaue2024_base
  parameter Real Cl_ref = 2.3916666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.24989999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.95824,
    adminMass = 1.5e-06,
    ka = 0.0020444444444444447,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About everolimus</h4><p>Everolimus is an immunosuppressant and mTOR inhibitor used to treat various cancers and prevent organ transplant rejection. The medication is administered orally in tablet forms. Routine blood level monitoring is performed to guide dosing. It is widely used and authorized in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421052\">Wikidata Q421052</a>, <a href=\"https://en.wikipedia.org/wiki/Everolimus?oldid=1385426500\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification, the EMA medicines list and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>everolimus</td></tr><tr><td>population:</td><td>renal transplant recipients receiving long-term multiple immunosuppressive therapy</td></tr><tr><td>source_paper:</td><td>Sakaue_2024</td></tr><tr><td>measured_compound:</td><td>everolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>everolimus 958.24 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Additive error (SD)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Objective function value' — extend the ontology if this is a real PK parameter (source ['Sakaue_2024_table_p30_1:row0:col1'])</li><li>documentation only: 'Ctrough' → Q37 (Ctrough) comes from ['fig_0:caption'], not from a located parameter table — not emitted as a model parameter</li><li>dropped value-less row: 'targeted concentration range'</li><li>dropped unlinked row (NIL): 'τ' — extend the ontology if this is a real PK parameter (source ['fig_0:caption'])</li><li>dropped unlinked row (NIL): 'everolimus dose' — extend the ontology if this is a real PK parameter (source ['fig_0:caption'])</li><li>documentation only: '𝑅𝑅𝑐𝑐𝑐𝑐𝑐𝑐𝑅𝑅𝑅𝑅𝑐𝑐𝑅𝑅𝑅𝑅𝑐𝑐𝑅𝑅 𝑅𝑅𝑐𝑐𝐷𝐷𝑐𝑐' → Q87 (Frel) comes from ['fig_0:caption'], not from a located parameter table — not emitted as a model parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=everolimus</li><li>model-stage split: 'base model: estimate' is the base model of Sakaue_2024 (paper reports 2 stages: base model: estimate, final model: estimate); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Everolimus_Sakaue2024_base;
