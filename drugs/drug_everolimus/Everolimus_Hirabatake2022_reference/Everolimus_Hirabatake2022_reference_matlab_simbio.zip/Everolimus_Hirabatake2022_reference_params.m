function p = Everolimus_Hirabatake2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: everolimus   source: Hirabatake_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Everolimus_Hirabatake2022_reference_params';
  p.drug  = 'everolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 54.0;                % central volume [L]
  p.CL = 11.7;                % clearance [L/h]
  p.Vp = [309.4];             % peripheral volumes [L]
  p.Q  = [42.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
