function p = Everolimus_Sakaue2024_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: everolimus   source: Sakaue_2024 / final   route: oral
  p.name  = 'Everolimus_Sakaue2024_final_params';
  p.drug  = 'everolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 284.9;                % central volume [L]
  p.CL = 8.92;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 7.36;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.5;             % dose [mg]
end
