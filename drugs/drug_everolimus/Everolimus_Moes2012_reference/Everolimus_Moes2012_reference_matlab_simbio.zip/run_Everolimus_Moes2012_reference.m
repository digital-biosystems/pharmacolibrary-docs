% Run (SimBiology): build model + dose, simulate 0..30.0 h, plot.
p = Everolimus_Moes2012_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 30.0);
