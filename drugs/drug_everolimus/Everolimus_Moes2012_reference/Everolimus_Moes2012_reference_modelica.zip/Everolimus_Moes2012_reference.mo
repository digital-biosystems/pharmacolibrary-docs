model Everolimus_Moes2012_reference
  parameter Real Cl_ref = 4.9722222222222224e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.148 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.95824,
    adminMass = 1.5e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About everolimus</h4><p>Everolimus is an immunosuppressant and mTOR inhibitor used to treat various cancers and prevent organ transplant rejection. The medication is administered orally in tablet forms. Routine blood level monitoring is performed to guide dosing. It is widely used and authorized in the European Union.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421052\">Wikidata Q421052</a>, <a href=\"https://en.wikipedia.org/wiki/Everolimus?oldid=1385426500\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification, the EMA medicines list and the Pharmacolibrary list of drugs whose blood levels are measured; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>everolimus</td></tr><tr><td>population:</td><td>renal transplant patients</td></tr><tr><td>source_paper:</td><td>Moes_2012</td></tr><tr><td>measured_compound:</td><td>everolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>everolimus 958.24 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=everolimus</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Everolimus_Moes2012_reference;
