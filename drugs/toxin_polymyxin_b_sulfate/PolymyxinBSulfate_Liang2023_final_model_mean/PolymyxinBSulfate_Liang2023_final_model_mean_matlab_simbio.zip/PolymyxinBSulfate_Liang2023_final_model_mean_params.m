function p = PolymyxinBSulfate_Liang2023_final_model_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: polymyxin_b_sulfate   source: Liang_2023 / final_model_mean   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'PolymyxinBSulfate_Liang2023_final_model_mean_params';
  p.drug  = 'polymyxin_b_sulfate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 16.64;                % central volume [L]
  p.CL = 1.24;                % clearance [L/h]
  p.Vp = [66.2];             % peripheral volumes [L]
  p.Q  = [3.04];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
