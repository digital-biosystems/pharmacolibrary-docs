model PolymyxinBSulfate_Chen2022v2_reference
  parameter Real Cl_ref = 6.750000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0134 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.203499,
    adminMass = 0.00015,
    k12 = 0.00018200663349917078,
    k21 = 4.7265288544358304e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b_sulfate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chen_2022_2</td></tr><tr><td>measured_compound:</td><td>polymyxin_b_sulfate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>polymyxin_b_sulfate 1203.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chen_2022_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end PolymyxinBSulfate_Chen2022v2_reference;
