function p = PolymyxinBSulfate_Chen2022v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: polymyxin_b_sulfate   source: Chen_2022_2 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'PolymyxinBSulfate_Chen2022v2_reference_params';
  p.drug  = 'polymyxin_b_sulfate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.4;                % central volume [L]
  p.CL = 2.43;                % clearance [L/h]
  p.Vp = [51.6];             % peripheral volumes [L]
  p.Q  = [8.78];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
