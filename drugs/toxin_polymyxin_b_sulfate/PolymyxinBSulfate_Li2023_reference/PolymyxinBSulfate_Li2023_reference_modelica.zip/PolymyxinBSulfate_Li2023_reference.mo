model PolymyxinBSulfate_Li2023_reference
  parameter Real Cl_ref = 6.750000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02311 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.203499,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b_sulfate</td></tr><tr><td>population:</td><td>136 adults with different levels of liver function</td></tr><tr><td>source_paper:</td><td>Li_2023</td></tr><tr><td>measured_compound:</td><td>Polymyxin B</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Polymyxin B 1203.5 g/mol (pubchem); polymyxin_b_sulfate 1203.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'the appropriate dose' — extend the ontology if this is a real PK parameter (source ['Li_2023:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Polymyxin B</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end PolymyxinBSulfate_Li2023_reference;
