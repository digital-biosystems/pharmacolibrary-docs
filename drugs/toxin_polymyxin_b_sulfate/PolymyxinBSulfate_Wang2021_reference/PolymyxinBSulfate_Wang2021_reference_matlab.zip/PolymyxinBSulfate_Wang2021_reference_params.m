function p = PolymyxinBSulfate_Wang2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: polymyxin_b_sulfate   source: Wang_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'PolymyxinBSulfate_Wang2021_reference_params';
  p.drug  = 'polymyxin_b_sulfate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.24;                % central volume [L]
  p.CL = 2.86;                % clearance [L/h]
  p.Vp = [39.7];             % peripheral volumes [L]
  p.Q  = [7.36];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
