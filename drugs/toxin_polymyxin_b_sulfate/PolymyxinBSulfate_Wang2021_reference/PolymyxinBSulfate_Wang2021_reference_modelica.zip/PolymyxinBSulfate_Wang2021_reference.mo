model PolymyxinBSulfate_Wang2021_reference
  parameter Real Cl_ref = 7.944444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01124 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.203499,
    adminMass = 5e-05,
    k12 = 0.00018189007512850932,
    k21 = 5.149734116988525e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b_sulfate</td></tr><tr><td>population:</td><td>Obese patients</td></tr><tr><td>source_paper:</td><td>Wang_2021</td></tr><tr><td>measured_compound:</td><td>Polymyxin B</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Polymyxin B 1203.5 g/mol (pubchem); polymyxin_b_sulfate 1203.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2CL' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω 2V2' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω 2Q' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability (σ)')</li><li>'tvV': unit 'V' is a parameter symbol — dropped</li><li>'tvV2': unit 'V' is a parameter symbol — dropped</li><li>'tvCL': unit 'V' is a parameter symbol — dropped</li><li>'tvQ': unit 'V' is a parameter symbol — dropped</li><li>implicit units: 'tvV' → L (from the paper text: &quot;The paper states: 'the typical V value (11.24 L, Table 2)'&quot;)</li><li>implicit units: 'tvV2' → L (from the paper text: &quot;The paper states: 'In particular, the V2 value (39.70 L) was triple to quadrupled that reported previously'&quot;)</li><li>implicit units: 'tvCL' → L/h (from the paper text: &quot;The paper states: 'The typical CL value was 2.86 L/h'&quot;)</li><li>implicit units: 'tvQ' → L/h (from the popPK convention: 'Q represents inter-compartmental clearance. The text does not explicitly state the unit for Q, but standard population P')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Polymyxin B</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end PolymyxinBSulfate_Wang2021_reference;
