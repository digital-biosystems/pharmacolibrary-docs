model PolymyxinBSulfate_Wang2026_reference
  parameter Real Cl_ref = 4.6666666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.203499,
    adminMass = 5e-05,
    k12 = 9.07148407148407e-05,
    k21 = 2.6560651560651556e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b_sulfate</td></tr><tr><td>population:</td><td>critically ill patients</td></tr><tr><td>source_paper:</td><td>Wang_2026</td></tr><tr><td>measured_compound:</td><td>Polymyxin B</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Polymyxin B 1203.5 g/mol (pubchem); polymyxin_b_sulfate 1203.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωV1 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωQ (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωV2 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability (RSV)')</li><li>table section residual_error: 'Additive error (mg/L)' routed out of structural estimates ('Residual variability (RSV)')</li><li>dropped unlinked row (NIL): 'θeGFR-CL' — extend the ontology if this is a real PK parameter (source ['t0002:row6:col1', 't0002:footnote'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Polymyxin B</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end PolymyxinBSulfate_Wang2026_reference;
