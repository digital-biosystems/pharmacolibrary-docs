% Run (SimBiology): build model + dose, simulate 0..48.0 h, plot.
p = PolymyxinBSulfate_Manchandani2018_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 48.0);
