% Run (SimBiology): build model + dose, simulate 0..47.0 h, plot.
p = PolymyxinBSulfate_Liang2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 47.0);
