model PolymyxinBSulfate_Liang2023_mean_value
  parameter Real Cl_ref = 3.4444444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016640000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.203499,
    adminMass = 5e-05,
    k12 = 5.074786324786325e-05,
    k21 = 1.2755958375293722e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b_sulfate</td></tr><tr><td>population:</td><td>critically ill patients</td></tr><tr><td>source_paper:</td><td>Liang_2023</td></tr><tr><td>measured_compound:</td><td>Polymyxin B</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Polymyxin B 1203.5 g/mol (pubchem); polymyxin_b_sulfate 1203.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'TABLE 3. PPK parameter estimates from model 6 for polymyxin B.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Polymyxin B</li><li>population split: 'mean value' subgroup of Liang_2023 (paper reports 2 populations: final model / mean, mean value)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end PolymyxinBSulfate_Liang2023_mean_value;
