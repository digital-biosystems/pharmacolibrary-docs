model PolymyxinBSulfate_Wang2022_reference
  parameter Real Cl_ref = 6.750000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0298 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.203499,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>polymyxin_b_sulfate</td></tr><tr><td>population:</td><td>critically ill patients receiving continuous venovenous haemofiltration</td></tr><tr><td>source_paper:</td><td>Wang_2022</td></tr><tr><td>measured_compound:</td><td>Polymyxin B Sulfate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Polymyxin B Sulfate 1203.5 g/mol (pubchem); polymyxin_b_sulfate 1203.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mg‧h/L' (AUCSS)</li><li>unit_dimension_unknown: 'mg‧h/L' (AUCSS)</li><li>dropped duplicate Q18 ('AUCss,24h of polymyxin B outside CVVH', value 77.89) — already have one for this compound</li><li>dropped unlinked row (NIL): 'P' — extend the ontology if this is a real PK parameter (source ['Wang_2022:abstract'])</li><li>dropped unlinked row (NIL): 'loading dose' — extend the ontology if this is a real PK parameter (source ['Wang_2022:abstract'])</li><li>dropped unlinked row (NIL): 'fixed maintenance dose' — extend the ontology if this is a real PK parameter (source ['Wang_2022:abstract'])</li><li>dropped unlinked row (NIL): 'maintenance dose interval' — extend the ontology if this is a real PK parameter (source ['Wang_2022:abstract'])</li><li>unit_dimension_unknown: 'mg•h/L' (AUCSS)</li><li>dropped duplicate Q18 ('AUCss,24h target', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'minimum inhibitory concentration' — extend the ontology if this is a real PK parameter (source ['Wang_2022:abstract'])</li><li>implicit units: 'AUCss,24h of polymyxin B during CVVH' → mg·h/L (from the popPK convention: 'The paper provides no explicit unit. For population pharmacokinetics, the Area Under the Curve (AUC) is most commonly ex')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Polymyxin B Sulfate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Chen_2022_2's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Chen_2022_2's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 154800, Tolerance = 1e-9, Interval = 1));
end PolymyxinBSulfate_Wang2022_reference;
