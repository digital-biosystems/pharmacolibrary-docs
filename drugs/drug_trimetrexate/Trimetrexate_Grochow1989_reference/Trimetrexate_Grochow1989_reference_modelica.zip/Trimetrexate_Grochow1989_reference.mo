model Trimetrexate_Grochow1989_reference
  parameter Real Cl_ref = 8.938333333333335e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022490000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3694176,
    adminMass = 8.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trimetrexate</h4><p>Trimetrexate is a folic acid antagonist used to treat pneumonia caused by Pneumocystis. It is given by intravenous injection. The drug is approved for clinical use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q126677485\">Wikidata Q126677485</a>, DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trimetrexate</td></tr><tr><td>population:</td><td>patients with advanced solid tumors</td></tr><tr><td>source_paper:</td><td>Grochow_1989</td></tr><tr><td>measured_compound:</td><td>trimetrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>trimetrexate 369.418 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trimetrexate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Trimetrexate_Grochow1989_reference;
