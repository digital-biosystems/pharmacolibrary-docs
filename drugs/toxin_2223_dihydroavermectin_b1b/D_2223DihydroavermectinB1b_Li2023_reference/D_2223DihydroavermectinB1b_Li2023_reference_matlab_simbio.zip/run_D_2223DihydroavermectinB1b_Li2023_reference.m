% Run (SimBiology): build model + dose, simulate 0..480.0 h, plot.
p = D_2223DihydroavermectinB1b_Li2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 480.0);
