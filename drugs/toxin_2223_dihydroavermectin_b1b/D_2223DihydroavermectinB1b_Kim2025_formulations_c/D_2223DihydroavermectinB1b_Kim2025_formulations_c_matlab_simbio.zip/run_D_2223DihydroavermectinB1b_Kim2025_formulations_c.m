% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = D_2223DihydroavermectinB1b_Kim2025_formulations_c_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
