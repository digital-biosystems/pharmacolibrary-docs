model D_2223DihydroavermectinB1b_Tan2022_reference
  parameter Real Cl_ref = 9.293981481481481e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 2.222 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8610789999999999,
    adminMass = 1.2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1b</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tan_2022</td></tr><tr><td>measured_compound:</td><td>2223_dihydroavermectin_b1b</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1b 861.079 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tan_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 8467200, Tolerance = 1e-9, Interval = 1));
end D_2223DihydroavermectinB1b_Tan2022_reference;
