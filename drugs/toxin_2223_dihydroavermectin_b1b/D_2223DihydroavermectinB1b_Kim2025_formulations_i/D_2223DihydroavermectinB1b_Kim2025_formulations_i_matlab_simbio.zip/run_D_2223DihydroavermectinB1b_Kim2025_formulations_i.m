% Run (SimBiology): build model + dose, simulate 0..42.0 h, plot.
p = D_2223DihydroavermectinB1b_Kim2025_formulations_i_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 42.0);
