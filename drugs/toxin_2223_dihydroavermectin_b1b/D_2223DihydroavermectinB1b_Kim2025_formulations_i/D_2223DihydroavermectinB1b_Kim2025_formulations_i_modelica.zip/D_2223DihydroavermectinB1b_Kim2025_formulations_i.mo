model D_2223DihydroavermectinB1b_Kim2025_formulations_i
  parameter Real Cl_ref = 7.777777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0322 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.2e-05,
    ka = 3.611111111111111e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1b</td></tr><tr><td>population:</td><td>healthy dogs</td></tr><tr><td>source_paper:</td><td>Kim_2025</td></tr><tr><td>measured_compound:</td><td>22,23-dihydroavermectin b1b (quantified as ivermectin total)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1b 861.079 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ng·h2/mL' (AUMC)</li><li>dropped value-less row: 'A'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'K10'</li><li>dropped value-less row: 'T1/2ka'</li><li>dropped value-less row: 'T1/2k10'</li><li>dropped value-less row: 'Vd'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'AUC0-t'</li><li>dropped value-less row: 'AUC0-inf'</li><li>dropped value-less row: 'AUMC'</li><li>dropped value-less row: 'MRT'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=22,23-dihydroavermectin b1b (quantified as ivermectin total)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end D_2223DihydroavermectinB1b_Kim2025_formulations_i;
