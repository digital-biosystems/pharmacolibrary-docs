% Run: build params, simulate 0..32.0 h, plot + save D_2223DihydroavermectinB1b_Kim2025_formulations_f.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_D_2223DihydroavermectinB1b_Kim2025_formulations_f.m
here = fileparts(mfilename('fullpath'));
p = D_2223DihydroavermectinB1b_Kim2025_formulations_f_params();
out = simulate_pk(p, 0:0.05:32.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('2223_dihydroavermectin_b1b — Kim_2025 (oral)');
print(fig, fullfile(here, 'D_2223DihydroavermectinB1b_Kim2025_formulations_f.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'D_2223DihydroavermectinB1b_Kim2025_formulations_f.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'D_2223DihydroavermectinB1b_Kim2025_formulations_f.json'), 'w');
try
  s.model = 'D_2223DihydroavermectinB1b_Kim2025_formulations_f'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"D_2223DihydroavermectinB1b_Kim2025_formulations_f","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote D_2223DihydroavermectinB1b_Kim2025_formulations_f.png, D_2223DihydroavermectinB1b_Kim2025_formulations_f.csv, D_2223DihydroavermectinB1b_Kim2025_formulations_f.json\n');
