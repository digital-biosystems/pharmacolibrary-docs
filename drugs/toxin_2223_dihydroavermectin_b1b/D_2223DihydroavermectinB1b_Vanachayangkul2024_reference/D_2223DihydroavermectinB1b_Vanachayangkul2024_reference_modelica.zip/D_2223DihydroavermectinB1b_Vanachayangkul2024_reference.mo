// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2223DihydroavermectinB1b_Vanachayangkul2024_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {95760.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1b</td></tr><tr><td>population:</td><td>Rhesus macaques</td></tr><tr><td>source_paper:</td><td>Vanachayangkul_2024</td></tr><tr><td>measured_compound:</td><td>ivermectin (22,23-dihydroavermectin B1a)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>ivermectin 861.079 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'hr×ng/ml' (AUC∞)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ivermectin (22,23-dihydroavermectin B1a)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 3 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/8 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for '3&quot;-O-demethyl ivermectin' — its concentrations stay mass-only</li><li>molar mass: none found for '5,6-orthoquinone tafenoquine' — its concentrations stay mass-only</li><li>molar mass: none found for 'desethylchloroquine' — its concentrations stay mass-only</li><li>molar mass: none found for 'ivermectin (22,23-dihydroavermectin B1a)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end D_2223DihydroavermectinB1b_Vanachayangkul2024_reference;
