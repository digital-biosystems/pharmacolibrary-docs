function p = D_2223DihydroavermectinB1b_Kim2025_formulations_of_ivermecti_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 2223_dihydroavermectin_b1b   source: Kim_2025 / formulations_of_ivermectin_i   route: oral
  p.name  = 'D_2223DihydroavermectinB1b_Kim2025_formulations_of_ivermecti_params';
  p.drug  = '2223_dihydroavermectin_b1b';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 231.8764;                % central volume [L]
  p.CL = 3.7576;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7082;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 12.0;             % dose [mg]
end
