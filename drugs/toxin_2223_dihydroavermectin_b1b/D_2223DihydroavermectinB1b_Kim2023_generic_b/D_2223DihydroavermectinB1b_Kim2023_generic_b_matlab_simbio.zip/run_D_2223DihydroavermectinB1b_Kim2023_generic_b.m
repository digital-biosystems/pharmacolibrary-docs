% Run (SimBiology): build model + dose, simulate 0..336.0 h, plot.
p = D_2223DihydroavermectinB1b_Kim2023_generic_b_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 336.0);
