model D_2223DihydroavermectinB1b_Kim2023_generic_b
  parameter Real Cl_ref = 1.986833333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6454797999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8610789999999999,
    adminMass = 7e-05,
    ka = 0.00019672222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1b</td></tr><tr><td>population:</td><td>clinically healthy Korean Hanwoo cattle</td></tr><tr><td>source_paper:</td><td>Kim_2023</td></tr><tr><td>measured_compound:</td><td>ivermectin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-13-00003-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1b 861.079 g/mol (pubchem); ivermectin 861.079 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ivermectin</li><li>population split: 'generic b' subgroup of Kim_2023 (paper reports 3 populations: generic a, generic b, innovator)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Fimbo_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end D_2223DihydroavermectinB1b_Kim2023_generic_b;
