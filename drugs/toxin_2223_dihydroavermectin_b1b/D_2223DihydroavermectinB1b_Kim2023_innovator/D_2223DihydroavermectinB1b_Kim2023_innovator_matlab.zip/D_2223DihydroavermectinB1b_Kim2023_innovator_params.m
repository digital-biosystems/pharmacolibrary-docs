function p = D_2223DihydroavermectinB1b_Kim2023_innovator_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 2223_dihydroavermectin_b1b   source: Kim_2023 / innovator   route: oral
  p.name  = 'D_2223DihydroavermectinB1b_Kim2023_innovator_params';
  p.drug  = '2223_dihydroavermectin_b1b';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 640.9697;                % central volume [L]
  p.CL = 6.7886;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7082;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
