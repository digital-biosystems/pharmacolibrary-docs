% Run (SimBiology): build model + dose, simulate 0..40.0 h, plot.
p = D_2223DihydroavermectinB1b_Kim2025_formulations_g_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 40.0);
