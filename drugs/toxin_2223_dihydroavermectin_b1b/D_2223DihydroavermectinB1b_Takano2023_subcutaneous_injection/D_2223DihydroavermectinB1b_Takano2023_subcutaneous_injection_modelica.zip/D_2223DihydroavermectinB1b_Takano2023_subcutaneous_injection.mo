// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model D_2223DihydroavermectinB1b_Takano2023_subcutaneous_injection
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {54000.0},
    adminMass = 1.4e-08,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>2223_dihydroavermectin_b1b</td></tr><tr><td>population:</td><td>selected wildlife and domestic species treated for sarcoptic mange (e.g. wombats, koalas, dogs, humans)</td></tr><tr><td>source_paper:</td><td>Takano_2023</td></tr><tr><td>measured_compound:</td><td>ivermectin (dominated by 22,23-dihydroavermectin B1a; B1b is a minor component)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tbl1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>2223_dihydroavermectin_b1b 861.079 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Host'; source reconciliation required</li><li>table representations disagree for 'Cmax (ng/ml)'; source reconciliation required</li><li>table representations disagree for 'Tmax (days)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'Host' — extend the ontology if this is a real PK parameter (source ['tbl1:row4:col1'])</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'AUC'</li><li>dropped value-less row: 'T1/2'</li><li>salvaged Q57 ('T1/2 (humans)'=15) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ivermectin (dominated by 22,23-dihydroavermectin B1a; B1b is a minor component)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'subcutaneous injectioni' subgroup of Takano_2023 (paper reports 6 populations: cattle, southern hairy-nosed wombat, subcutaneous injectioni, subcutaneous injectionl, topicalf, topicalk)</li><li>molar mass: none found for 'ivermectin (dominated by 22,23-dihydroavermectin B1a; B1b is a minor component)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end D_2223DihydroavermectinB1b_Takano2023_subcutaneous_injection;
