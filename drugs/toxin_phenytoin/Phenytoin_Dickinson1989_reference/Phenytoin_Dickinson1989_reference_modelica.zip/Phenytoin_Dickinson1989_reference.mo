model Phenytoin_Dickinson1989_reference
  parameter Real Cl_ref = 4.55e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07859999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25227299999999997,
    adminMass = 0.0003,
    ka = 0.0005527777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenytoin</td></tr><tr><td>population:</td><td>term placental lobules</td></tr><tr><td>source_paper:</td><td>Dickinson_1989</td></tr><tr><td>measured_compound:</td><td>Phenytoin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Phenytoin 252.273 g/mol (pubchem); p-hydroxy-phenytoin 268.272 g/mol (pubchem); p-hydroxy-phenytoin-glucuronide 444.396 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mean and s.e.m.' (CL_ratio)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Phenytoin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=other; 1/1 row label(s) assigned, 0 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Ku_2016's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Ku_2016's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ku_2016's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Ku_2016 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Phenytoin_Dickinson1989_reference;
