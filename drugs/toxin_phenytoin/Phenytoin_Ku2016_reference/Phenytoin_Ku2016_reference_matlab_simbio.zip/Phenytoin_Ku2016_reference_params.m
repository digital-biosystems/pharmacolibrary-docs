function p = Phenytoin_Ku2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenytoin   source: Ku_2016 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Phenytoin_Ku2016_reference_params';
  p.drug  = 'phenytoin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 78.6;                % central volume [L]
  p.CL = 1.638;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.99;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
