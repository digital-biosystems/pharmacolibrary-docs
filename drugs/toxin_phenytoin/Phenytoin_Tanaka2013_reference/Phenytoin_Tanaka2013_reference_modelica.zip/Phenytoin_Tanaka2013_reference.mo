model Phenytoin_Tanaka2013_reference
  parameter Real Cl_ref = 4.4722222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.020800000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25227299999999997,
    adminMass = 0.00105,
    ka = 0.0013944444444444442,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phenytoin</td></tr><tr><td>population:</td><td>pediatric patients, adult patients, and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Tanaka_2013</td></tr><tr><td>measured_compound:</td><td>phenytoin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fosphenytoin sodium 406.242 g/mol (pubchem); phenytoin 252.273 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is phenytoin; the compartment is phenytoin. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is phenytoin, not phenytoin</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>phenytoin's own concentration-time course is not produced by this model</li><li>unit_dimension_mismatch: 'ΘWT (CL)' → Q22 (unit '[length] ** 3' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('ΘWT (CL)', value '0.569') — already have one for this compound</li><li>dropped value-less row: 'aCL, V2, and V3'</li><li>metabolite phenytoin: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=phenytoin</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>row roles (LLM): model_class=compartmental; 15/15 row label(s) assigned, 5 linked by role; re-tagged parent→phenytoin ×12</li><li>gap-filled Q49 (kabs) from Ku_2016's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q77 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Phenytoin_Tanaka2013_reference;
