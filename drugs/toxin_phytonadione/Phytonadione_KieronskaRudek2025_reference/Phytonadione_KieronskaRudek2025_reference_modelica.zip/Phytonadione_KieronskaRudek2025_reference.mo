// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Phytonadione_KieronskaRudek2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {14400.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phytonadione</td></tr><tr><td>population:</td><td>8-week-old and 12-14-week-old male C57BL/6J mice</td></tr><tr><td>source_paper:</td><td>Kieronska-Rudek_2025</td></tr><tr><td>measured_compound:</td><td>phylloquinone (PK)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>phytonadione 450.707 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'NCA: Tmax'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'AUCINF pred'</li><li>dropped value-less row: 'T ½'</li><li>dropped value-less row: 'Vz_F'</li><li>dropped value-less row: 'Cl_F'</li><li>dropped value-less row: 'Cl'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'Tlag'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: '*F'</li><li>salvaged Q57 ('T ½ (PK-Oil-HyC12)'=4) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (PK-Oil formulation)'=37.98) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=phylloquinone (PK)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Phytonadione_KieronskaRudek2025_reference;
