// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Phytonadione_Park1984v2_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6120.0},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>phytonadione</td></tr><tr><td>population:</td><td>healthy male subjects (also brodifacoum-anticoagulated rabbits)</td></tr><tr><td>source_paper:</td><td>Park_1984_2</td></tr><tr><td>measured_compound:</td><td>Phytonadione (vitamin K1)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>phytonadione 450.707 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'duration of action' — extend the ontology if this is a real PK parameter (source ['Park_1984_2:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Phytonadione (vitamin K1)</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>molar mass: none found for 'Phytonadione (vitamin K1)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Hindley_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V from Hindley_2023: its label names a different analyte ('apixaban') — 'volume of distribution of apixaban'</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Phytonadione_Park1984v2_reference;
