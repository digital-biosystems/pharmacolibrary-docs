model Pralidoxime_Abbara2010_reference
  parameter Real Cl_ref = 3.89625e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3117 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1371592,
    adminMass = 0.00035,
    ka = 0.002797222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pralidoxime</h4><p>Pralidoxime is a cholinesterase reactivator and antidote used to treat organophosphate poisoning. It is administered by intramuscular, intravenous, or subcutaneous injection. It is approved for human use and for veterinary use.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q2735334\">Wikidata Q2735334</a>, <a href=\"https://en.wikipedia.org/wiki/Pralidoxime?oldid=1377012930\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pralidoxime</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Abbara_2010</td></tr><tr><td>measured_compound:</td><td>pralidoxime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pralidoxime 137.159 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Vc (L)'; source reconciliation required</li><li>table representations disagree for 'Vc (L)'; source reconciliation required</li><li>table representations disagree for 'Ka (h -1 )'; source reconciliation required</li><li>table representations disagree for 'Ke (h -1 )'; source reconciliation required</li><li>table representations disagree for 'Ke (h -1 )'; source reconciliation required</li><li>table representations disagree for 'K12 (h -1 )'; source reconciliation required</li><li>table representations disagree for 'K12 (h -1 )'; source reconciliation required</li><li>table representations disagree for 'K21 (h -1 )'; source reconciliation required</li><li>table representations disagree for 'K21 (h -1 )'; source reconciliation required</li><li>table representations disagree for 'Vc'; source reconciliation required</li><li>table representations disagree for 'Vc'; source reconciliation required</li><li>table representations disagree for 'Ka'; source reconciliation required</li><li>table representations disagree for 'Ke'; source reconciliation required</li><li>table representations disagree for 'Ke'; source reconciliation required</li><li>table representations disagree for 'K12'; source reconciliation required</li><li>table representations disagree for 'K12'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pralidoxime_Abbara2010_reference;
