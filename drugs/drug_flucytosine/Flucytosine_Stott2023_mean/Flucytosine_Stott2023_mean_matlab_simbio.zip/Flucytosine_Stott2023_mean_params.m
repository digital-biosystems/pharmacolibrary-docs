function p = Flucytosine_Stott2023_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flucytosine   source: Stott_2023 / mean   route: oral
  p.name  = 'Flucytosine_Stott2023_mean_params';
  p.drug  = 'flucytosine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 17.5;                % central volume [L]
  p.CL = 5.88;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.77;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1750.0;             % dose [mg]
end
