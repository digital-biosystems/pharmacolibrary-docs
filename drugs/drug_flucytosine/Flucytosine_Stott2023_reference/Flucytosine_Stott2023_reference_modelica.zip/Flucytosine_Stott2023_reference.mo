model Flucytosine_Stott2023_reference
  parameter Real Cl_ref = 1.581388888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05706000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.02835,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>adults with HIV-associated cryptococcal meningoencephalitis</td></tr><tr><td>source_paper:</td><td>Stott_2023</td></tr><tr><td>measured_compound:</td><td>flucytosine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q48 ('K32 (h -1 )', value '60.21') — already have one for this compound</li><li>dropped duplicate Q48 ('K24 (h -1 )', value '133.77') — already have one for this compound</li><li>dropped duplicate Q48 ('K42 (h -1 )', value '168.39') — already have one for this compound</li><li>dropped duplicate Q76 ('Vcns/F (L)', value '32.74') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=flucytosine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flucytosine_Stott2023_reference;
