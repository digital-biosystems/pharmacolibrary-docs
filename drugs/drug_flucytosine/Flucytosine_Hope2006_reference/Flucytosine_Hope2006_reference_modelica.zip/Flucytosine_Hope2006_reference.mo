model Flucytosine_Hope2006_reference
  parameter Real Cl_ref = 5.833333333333334e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 2.2e-05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>neutropenic CD1 mice with disseminated candidiasis</td></tr><tr><td>source_paper:</td><td>Hope_2006</td></tr><tr><td>measured_compound:</td><td>flucytosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Isolate' — extend the ontology if this is a real PK parameter (source ['tab_1:row0:col1'])</li><li>salvaged Q61 ('volume of the central compartment'=0.022) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=0.021) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka'=19.58) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flucytosine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>unit re-normalised: CL 'liter/h' now converts (value unchanged)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flucytosine_Hope2006_reference;
