// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Valaciclovir_de1994_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4680.0},
    MM = 0.32433999999999996,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valaciclovir</td></tr><tr><td>population:</td><td>male cynomolgus monkeys</td></tr><tr><td>source_paper:</td><td>de_1994</td></tr><tr><td>measured_compound:</td><td>Valaciclovir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>8-hydroxyacyclovir 241.207 g/mol (pubchem); 9-(carboxymethoxymethyl)guanine (CMMG) 239.191 g/mol (pubchem); Acyclovir 225.208 g/mol (pubchem); Valaciclovir 324.34 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'urinary metabolites of [8-14C]valaciclovir, administered orally (10 and 25 mg/kg) or intravenously (10 mg/kg) to male monkeys, were acyclovir' — extend the ontology if this is a real PK parameter (source ['de_1994:abstract'])</li><li>dropped unlinked row (NIL): '8-hydroxyacyclovir' — extend the ontology if this is a real PK parameter (source ['de_1994:abstract'])</li><li>dropped unlinked row (NIL): '9-(carboxymethoxymethyl)guanine (CMMG)' — extend the ontology if this is a real PK parameter (source ['de_1994:abstract'])</li><li>dropped unlinked row (NIL): 'prodrug' — extend the ontology if this is a real PK parameter (source ['de_1994:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Valaciclovir</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 7/7 row label(s) assigned, 0 linked by role; re-tagged Valaciclovir→Acyclovir ×3, Valaciclovir→8-hydroxyacyclovir ×1, Valaciclovir→9-(carboxymethoxymethyl)guanine (CMMG) ×1, Valaciclovir→parent ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Ohtsu_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Valaciclovir_de1994_reference;
