model Valaciclovir_Samies2025_reference
  parameter Real Cl_ref = 3.055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0036000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.225208,
    adminMass = 0.003,
    ka = 0.0009444444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>valaciclovir</td></tr><tr><td>population:</td><td>Seven infants with neonatal HSV disease</td></tr><tr><td>source_paper:</td><td>Samies_2025</td></tr><tr><td>measured_compound:</td><td>Acyclovir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Acyclovir 225.208 g/mol (pubchem); Valaciclovir 324.34 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is valaciclovir; the compartment is Acyclovir. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is Acyclovir, not valaciclovir</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>valaciclovir's own concentration-time course is not produced by this model</li><li>dropped duplicate Q61 ('apparent distribution volume', value 12.3) — already have one for this compound</li><li>metabolite acyclovir: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite acyclovir: Q61→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite acyclovir: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Acyclovir</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 7/7 row label(s) assigned, 0 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Acyclovir', not valaciclovir — the review values are the parent's</li><li>engineer: parent_metabolite composite downgraded to a 1C model of the measured compound — the paper reports the metabolite's own CL and V but neither the parent's disposition nor a formation rate, so the parent sub-component could not be populated; the parent's concentration-time course is NOT produced by this model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Valaciclovir_Samies2025_reference;
