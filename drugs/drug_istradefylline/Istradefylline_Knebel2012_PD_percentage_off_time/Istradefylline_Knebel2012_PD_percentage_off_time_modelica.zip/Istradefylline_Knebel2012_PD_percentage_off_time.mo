model Istradefylline_Knebel2012_PD_percentage_off_time
  "emax exposure-response sweep — Knebel_2012 :: percentage OFF time (percentage OFF time)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0579,  // [1; % × 0.01]
    EC50 = 1690,  // [ng × hr/mL]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng × hr/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'ng × hr/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 17000, Interval = 34),
    Documentation(info = "<html><body><!-- drug-about --><h4>About istradefylline</h4><p>Istradefylline is an antiparkinson drug that acts as an adenosine receptor antagonist. It is given as an oral tablet to adults experiencing off episodes alongside levodopa and carbidopa. It is an approved medication used for Parkinson's disease.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q905783\">Wikidata Q905783</a>, <a href=\"https://en.wikipedia.org/wiki/Istradefylline?oldid=1370506490\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Istradefylline_Knebel2012_PD_percentage_off_time</h4><p>The steady-state exposure-response curve of Knebel W et al., <i>Journal of clinical pharmacology 52(10):1468–1481</i> 2012 (<a href=\"https://doi.org/10.1177/0091270011420566\">doi:10.1177/0091270011420566</a>) — percentage OFF time against istradefylline AUCss ng × hr/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       5.79 %        maximal effect term (Emax, Q323)
  EC50  =       1690 ng × hr/mL exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng × hr/mL of istradefylline AUCss per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1690 ng × hr/mL)  response -0.02895
  exposure -> infinity  response -0.0579</pre></body></html>"));
end Istradefylline_Knebel2012_PD_percentage_off_time;
