function p = Istradefylline_Knebel2012_PD_percentage_off_time_params()
% Istradefylline_Knebel2012_PD_percentage_off_time_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% istradefylline Knebel_2012::percentage_OFF_time: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng × hr/mL per second, in SI inside (kg/m3, s). Response percentage OFF time in its own unit. Driver: istradefylline AUCss (dose_only).
p.E0 = 0.0;
p.Emax = -0.0579;
p.EC50 = 1690.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 17000.0;
p.form = 'E0 + Emax*frac';
end
