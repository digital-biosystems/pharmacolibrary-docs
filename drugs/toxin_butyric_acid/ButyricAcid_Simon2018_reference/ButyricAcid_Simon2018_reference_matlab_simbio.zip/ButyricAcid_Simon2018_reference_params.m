function p = ButyricAcid_Simon2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: butyric_acid   source: Simon_2018 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'ButyricAcid_Simon2018_reference_params';
  p.drug  = 'butyric_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 72.8;                % central volume [L]
  p.CL = 11.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.64;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
