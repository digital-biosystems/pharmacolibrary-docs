function p = Risdiplam_Cleary2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: risdiplam   source: Cleary_2023 / reference   route: oral
  p.name  = 'Risdiplam_Cleary2023_reference_params';
  p.drug  = 'risdiplam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 98.0;                % central volume [L]
  p.CL = 2.64;                % clearance [L/h]
  p.Vp = [92.9];             % peripheral volumes [L]
  p.Q  = [0.682];             % inter-compartmental clearances [L/h]
  p.ka = 5.18;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 14.0;             % dose [mg]
end
