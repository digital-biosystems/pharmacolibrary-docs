model Radon_Khan1995_PD_micronuclei_2
  "linear exposure-response sweep — Khan_1995 :: micronuclei (micronuclei)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 38.3,      // [micronuclei/1000 binucleated cells]
    slope = 0.8,  // [micronuclei/1000 binucleated cells/WLM]
    exposure_per_s = 1);   // 1 WLM per second
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Radon_Khan1995_PD_micronuclei_2</h4><p>The steady-state exposure-response curve of Khan MA et al., <i>Mutation research 334(2):131–137</i> 1995 (<a href=\"https://doi.org/10.1016/0165-1161(95)90003-9\">doi:10.1016/0165-1161(95)90003-9</a>) — micronuclei [1000 binucleated cells] against radon WLM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       38.3 micronuclei/1000 binucleated cells drug-free response (baseline) (baseline, Q324)
  slope =        0.8 micronuclei/1000 binucleated cells/WLM change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one WLM of radon per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 38.3   (drug-free)</pre></body></html>"));
end Radon_Khan1995_PD_micronuclei_2;
