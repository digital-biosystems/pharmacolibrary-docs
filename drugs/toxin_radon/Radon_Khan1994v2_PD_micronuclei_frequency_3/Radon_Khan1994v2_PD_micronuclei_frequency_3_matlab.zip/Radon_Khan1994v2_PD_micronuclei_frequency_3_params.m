function p = Radon_Khan1994v2_PD_micronuclei_frequency_3_params()
% Radon_Khan1994v2_PD_micronuclei_frequency_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% radon Khan_1994_2::micronuclei_frequency::3: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Gy per second, in SI inside (kg/m3, s). Response micronuclei frequency in micronuclei/1000 binucleated cells. Driver: radon and its progeny (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 757.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
