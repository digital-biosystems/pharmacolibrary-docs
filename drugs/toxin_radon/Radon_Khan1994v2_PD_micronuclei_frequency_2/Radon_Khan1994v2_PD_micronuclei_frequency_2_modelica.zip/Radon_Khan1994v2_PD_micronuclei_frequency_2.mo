model Radon_Khan1994v2_PD_micronuclei_frequency_2
  "linear exposure-response sweep — Khan_1994_2 :: micronuclei frequency (micronuclei frequency)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 593,  // [micronuclei/1000 binucleated cells/Gy]
    exposure_per_s = 1);   // 1 Gy per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Radon_Khan1994v2_PD_micronuclei_frequency_2</h4><p>The steady-state exposure-response curve of Khan MA et al., <i>Radiation research 139(1):53–59</i> 1994 — micronuclei frequency [micronuclei/1000 binucleated cells] against radon and its progeny Gy — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        593 micronuclei/1000 binucleated cells/Gy change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one Gy of radon and its progeny per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Radon_Khan1994v2_PD_micronuclei_frequency_2;
