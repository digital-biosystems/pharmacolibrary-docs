function p = Radon_Tirmarche1993_PD_smr_params()
% Radon_Tirmarche1993_PD_smr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% radon Tirmarche_1993::SMR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one WLM per second, in SI inside (kg/m3, s). Response SMR in its own unit. Driver: radon (dose_only).
p.E0 = 1.68;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0058;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
