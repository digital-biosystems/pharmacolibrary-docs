model Radon_Tirmarche1993_PD_smr
  "linear exposure-response sweep — Tirmarche_1993 :: SMR (SMR for lung cancer)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 1.68,      // [1]
    slope = 0.0058,  // [SMR/WLM]
    exposure_per_s = 1);   // 1 WLM per second
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Radon_Tirmarche1993_PD_smr</h4><p>The steady-state exposure-response curve of Tirmarche M et al., <i>British journal of cancer 67(5):1090–1097</i> 1993 (<a href=\"https://doi.org/10.1038/bjc.1993.200\">doi:10.1038/bjc.1993.200</a>) — SMR for lung cancer against radon WLM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.68          drug-free response (baseline) (intercept, Q324)
  slope =     0.0058 SMR/WLM  change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one WLM of radon per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.68   (drug-free)</pre></body></html>"));
end Radon_Tirmarche1993_PD_smr;
