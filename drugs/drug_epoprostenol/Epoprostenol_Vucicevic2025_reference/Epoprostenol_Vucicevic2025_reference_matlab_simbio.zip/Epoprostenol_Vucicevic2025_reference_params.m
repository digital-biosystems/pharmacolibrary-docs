function p = Epoprostenol_Vucicevic2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: epoprostenol   source: Vucicevic_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Epoprostenol_Vucicevic2025_reference_params';
  p.drug  = 'epoprostenol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 237.0;                % central volume [L]
  p.CL = 13.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
