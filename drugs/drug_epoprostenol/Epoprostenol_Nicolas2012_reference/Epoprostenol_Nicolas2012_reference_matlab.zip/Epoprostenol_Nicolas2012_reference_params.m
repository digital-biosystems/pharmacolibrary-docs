function p = Epoprostenol_Nicolas2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: epoprostenol   source: Nicolas_2012 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Epoprostenol_Nicolas2012_reference_params';
  p.drug  = 'epoprostenol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 23.74;                % central volume [L]
  p.CL = 84.92;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.688;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
