function p = Elagolix_Abbas2020_PD_bmd_params()
% Elagolix_Abbas2020_PD_bmd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% elagolix Abbas_2020::BMD: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BMD in g/cm2. Driver: elagolix (cited_pk).
p.E0 = 1.06;
p.Emax = 0.3;
p.EC50 = 0.00023999999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1900.0;
p.form = 'E0/(1 + Emax*frac)';
end
