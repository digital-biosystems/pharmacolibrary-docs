model Elagolix_Abbas2020_PD_bmd
  "indirect_response_iv exposure-response sweep — Abbas_2020 :: BMD (lumbar spine BMD)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 1.06,      // [g/cm3]
    Emax = 0.3,  // type IV effect term
    EC50 = 0.00024,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1900, Interval = 3.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About elagolix</h4><p>Elagolix is a hormone-lowering medicine used to treat endometriosis. It is an approved medicine, mainly used in the United States, and has also been studied for other conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21098999\">Wikidata Q21098999</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Elagolix_Abbas2020_PD_bmd</h4><p>The steady-state exposure-response curve of Abbas Suleiman A et al., <i>CPT: pharmacometrics &amp; systems pharmacology 9(11):639–648</i> 2020 (<a href=\"https://doi.org/10.1002/psp4.12560\">doi:10.1002/psp4.12560</a>) — lumbar spine BMD [g/cm2] against elagolix ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.06 g/cm3    drug-free response (baseline) (BLBMD (Hologic, g/cm3, Q324)
  Emax  =        0.3          maximal effect term (Emax, Q320)
  EC50  =        240 ng/mL    exposure at half of the maximal effect term (EC50, ng/mL, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of elagolix per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.06   (drug-free)
  exposure = EC50 (240 ng/mL)  response 0.9217
  exposure -> infinity  response 0.8154</pre></body></html>"));
end Elagolix_Abbas2020_PD_bmd;
