model Ipilimumab_Shang2022_reference
  parameter Real Cl_ref = 2.9745370370370374e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0068 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 4.238153594771242e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ipilimumab</h4><p>Ipilimumab is a monoclonal antibody used to treat several cancers, including melanoma, renal cell carcinoma, non-small-cell lung cancer, mesothelioma, and colorectal cancer. It is approved and authorised in the European Union, where it is used in the treatment of these cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2459042\">Wikidata Q2459042</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ipilimumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shang_2022</td></tr><tr><td>measured_compound:</td><td>ipilimumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shang_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 8467200, Tolerance = 1e-9, Interval = 1));
end Ipilimumab_Shang2022_reference;
