function p = Ipilimumab_Leven2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ipilimumab   source: Leven_2019 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ipilimumab_Leven2019_reference_params';
  p.drug  = 'ipilimumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.0;                % central volume [L]
  p.CL = 0.009167;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
