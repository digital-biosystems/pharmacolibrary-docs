model Guanfacine_Knebel2015_reference
  parameter Real Cl_ref = 9.194444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.804 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24609299999999998,
    adminMass = 1e-06,
    ka = 0.00015333333333333334,
    Tlag = 2343.6
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About guanfacine</h4><p>Guanfacine is used to treat high blood pressure and attention deficit hyperactivity disorder. It is an approved medicine, with products authorised in the European Union for ADHD, and it is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5613599\">Wikidata Q5613599</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>guanfacine</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Knebel_2015</td></tr><tr><td>measured_compound:</td><td>guanfacine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>guanfacine 246.093 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'X 1.1CL/F' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 1.1CL/F' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 1.2 COV CL/F-V/F' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 1.2 COV CL/F-V/F' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 2.2V/F' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 2.2V/F' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 1.3 COV CL/F-Ka' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 1.3 COV CL/F-Ka' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 2.4 COV V/F-Ka' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 2.4 COV V/F-Ka' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 3.3Ka' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>table section iiv: 'X 3.3Ka' routed out of structural estimates ('Interindividual variance (% SE)')</li><li>dropped unlinked row (NIL): 'r 2 pro' — extend the ontology if this is a real PK parameter (source ['tab_2:row19:col1', 'tab_2:row19:col2'])</li><li>routed 'r 2 add' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>salvaged Q27 ('CL/F'=33.1) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=804) from results prose — parameter table was unreadable</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Guanfacine_Knebel2015_reference;
