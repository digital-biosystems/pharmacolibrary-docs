model Guanfacine_Knebel2015v2_PD_adhd_rs_iv
  "linear exposure-response sweep — Knebel_2015_2 :: ADHD RS-IV (ADHD Rating Scale-IV (ADHD RS-IV) score)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 37.1   "[% per 0.1 mg/kg]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About guanfacine</h4><p>Guanfacine is used to treat high blood pressure and attention deficit hyperactivity disorder. It is an approved medicine, with products authorised in the European Union for ADHD, and it is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5613599\">Wikidata Q5613599</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Guanfacine_Knebel2015v2_PD_adhd_rs_iv</h4><p>The steady-state exposure-response curve of Knebel W et al., <i>Journal of pharmacokinetics and pharmacodynamics 42(1):45–65</i> 2015 (<a href=\"https://doi.org/10.1007/s10928-014-9397-6\">doi:10.1007/s10928-014-9397-6</a>) — ADHD Rating Scale-IV (ADHD RS-IV) score against guanfacine extended-release mg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       37.1 % per 0.1 mg/kg change in response per unit of exposure (decrease in ADHD RS-IV score from the placebo-response trajectory, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/kg of guanfacine extended-release per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Guanfacine_Knebel2015v2_PD_adhd_rs_iv;
