function p = Guanfacine_Knebel2015v2_PD_adhd_rs_iv_params()
% Guanfacine_Knebel2015v2_PD_adhd_rs_iv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% guanfacine Knebel_2015_2::ADHD_RS_IV: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg per second, in SI inside (kg/m3, s). Response ADHD RS-IV in its own unit. Driver: guanfacine extended-release (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 37.1;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
