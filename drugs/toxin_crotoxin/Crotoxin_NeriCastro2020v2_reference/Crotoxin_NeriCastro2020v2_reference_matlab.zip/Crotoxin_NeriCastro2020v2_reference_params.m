function p = Crotoxin_NeriCastro2020v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: crotoxin   source: Neri-Castro_2020_2 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Crotoxin_NeriCastro2020v2_reference_params';
  p.drug  = 'crotoxin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 268.15;                % central volume [L]
  p.CL = 23.35;                % clearance [L/h]
  p.Vp = [25.47];             % peripheral volumes [L]
  p.Q  = [43.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
