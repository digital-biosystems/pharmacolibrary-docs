function p = MetamizoleSodium_Nandy2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metamizole_sodium   source: Nandy_2010 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'MetamizoleSodium_Nandy2010_reference_params';
  p.drug  = 'metamizole_sodium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.5;                % central volume [L]
  p.CL = 13.6;                % clearance [L/h]
  p.Vp = [5.8];             % peripheral volumes [L]
  p.Q  = [4.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
