model MetamizoleSodium_Nandy2010_reference
  parameter Real Cl_ref = 3.7777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.0001111111111111111,
    k21 = 0.00022030651340996168
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metamizole_sodium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Nandy_2010</td></tr><tr><td>measured_compound:</td><td>metamizole_sodium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Nandy_2010) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MetamizoleSodium_Nandy2010_reference;
