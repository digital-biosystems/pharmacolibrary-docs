function p = MetamizoleSodium_Stoschus2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metamizole_sodium   source: Stoschus_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'MetamizoleSodium_Stoschus2025_reference_params';
  p.drug  = 'metamizole_sodium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.3;                % central volume [L]
  p.CL = 0.38;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.9;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
