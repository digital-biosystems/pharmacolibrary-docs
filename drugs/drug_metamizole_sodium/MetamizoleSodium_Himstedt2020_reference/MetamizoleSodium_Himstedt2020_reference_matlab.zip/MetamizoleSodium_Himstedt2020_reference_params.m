function p = MetamizoleSodium_Himstedt2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metamizole_sodium   source: Himstedt_2020 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'MetamizoleSodium_Himstedt2020_reference_params';
  p.drug  = 'metamizole_sodium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.61;                % central volume [L]
  p.CL = 270.2;                % clearance [L/h]
  p.Vp = [263.9];             % peripheral volumes [L]
  p.Q  = [226.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
