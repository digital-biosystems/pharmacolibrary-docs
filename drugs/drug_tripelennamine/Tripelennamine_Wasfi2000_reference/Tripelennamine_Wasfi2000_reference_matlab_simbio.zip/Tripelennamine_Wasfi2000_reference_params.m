function p = Tripelennamine_Wasfi2000_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tripelennamine   source: Wasfi_2000 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Tripelennamine_Wasfi2000_reference_params';
  p.drug  = 'tripelennamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 122.5;                % central volume [L]
  p.CL = 67.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
