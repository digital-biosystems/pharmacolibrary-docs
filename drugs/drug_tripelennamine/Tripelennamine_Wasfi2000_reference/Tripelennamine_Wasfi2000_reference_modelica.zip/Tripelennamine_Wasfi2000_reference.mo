model Tripelennamine_Wasfi2000_reference
  parameter Real Cl_ref = 9.868727291793736e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1225 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25535800000000003,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tripelennamine</h4><p>Tripelennamine is a first-generation antihistamine used to treat allergies such as hay fever, rhinitis, and urticaria. It is taken orally as tablets and is well absorbed. It can also be applied topically as a cream or stick or used vaginally.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q415203\">Wikidata Q415203</a>, <a href=\"https://en.wikipedia.org/wiki/Tripelennamine?oldid=1359017200\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tripelennamine</td></tr><tr><td>population:</td><td>horses and camels</td></tr><tr><td>source_paper:</td><td>Wasfi_2000</td></tr><tr><td>measured_compound:</td><td>tripelennamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tripelennamine 255.358 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'horses' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract'])</li><li>dropped unlinked row (NIL): 'camels' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract'])</li><li>dropped unlinked row (NIL): 'dose' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract'])</li><li>dropped unlinked row (NIL): 'extent of protein binding' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract', 'Wasfi_2000:abstract'])</li><li>dropped unlinked row (NIL): 'T itself could be detected for up to' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tripelennamine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volumes of the central compartment of the two compartment pharmacokinetic model' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL=35.5274 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tripelennamine_Wasfi2000_reference;
