model Cytarabine_Wang2019_estimate
  parameter Real Cl_ref = 4.0833333333333335e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00429 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.243219,
    adminMass = 1e-05,
    k12 = 1.9036519036519034e-06,
    k21 = 1.377178189994379e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cytarabine</td></tr><tr><td>population:</td><td>patients with hematologic malignancies</td></tr><tr><td>source_paper:</td><td>Wang_2019</td></tr><tr><td>measured_compound:</td><td>Cytarabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1366-tbl-0004</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cytarabine 243.219 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'BSA_CL' — extend the ontology if this is a real PK parameter (source ['Wang_2019_table_S2:row1:col1', 'Wang_2019_table_S3:row1:col1'])</li><li>dropped duplicate Q22 ('BILI_CL', value '0.0829') — already have one for this compound</li><li>dropped unlinked row (NIL): 'BSA_Vc' — extend the ontology if this is a real PK parameter (source ['Wang_2019_table_S2:row4:col1', 'Wang_2019_table_S3:row5:col1'])</li><li>dropped unlinked row (NIL): 'BSA_Q' — extend the ontology if this is a real PK parameter (source ['Wang_2019_table_S2:row6:col1', 'Wang_2019_table_S3:row8:col1'])</li><li>dropped unlinked row (NIL): 'LogErr' — extend the ontology if this is a real PK parameter (source ['Wang_2019_table_S2:row9:col1', 'Wang_2019_table_S3:row13:col1'])</li><li>dropped 'Form_CL' → Q22 = -0.275: a clearance of -0.275 is not a parameter value (source ['Wang_2019_table_S3:row3:col1'])</li><li>dropped 'Form_Vc' → Q63 = -0.221: a volume of -0.221 is not a parameter value (source ['Wang_2019_table_S3:row6:col1'])</li><li>routed 'Form_Q' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped 'Form_Vp' → Q61 = -0.686: a volume of -0.686 is not a parameter value (source ['Wang_2019_table_S3:row12:col1'])</li><li>implicit units: 'BSA_Vp' → L/kg (from the popPK convention: &quot;The paper defines BSA as body surface area in Table 1 and Table 2 footnotes. The parameter 'BSA_Vp' represents the volum&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cytarabine</li><li>population split: 'estimate' subgroup of Wang_2019 (paper reports 4 populations: cpx-351, estimate, non-liposomal, overall p‐value)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Cytarabine_Wang2019_estimate;
