% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Cytarabine_Zhang2018_intravenous_ara_c_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
