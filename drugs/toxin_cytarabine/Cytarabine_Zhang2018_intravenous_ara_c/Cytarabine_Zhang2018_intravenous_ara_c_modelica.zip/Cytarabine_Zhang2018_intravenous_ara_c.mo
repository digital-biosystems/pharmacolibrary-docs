model Cytarabine_Zhang2018_intravenous_ara_c
  parameter Real Cl_ref = 5.444444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.654 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.243219,
    adminMass = 0.0007
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cytarabine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Zhang_2018</td></tr><tr><td>measured_compound:</td><td>Ara-C (Cytarabine) and PA-Ara</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Ara-C (Cytarabine) and PA-Ara 243.219 g/mol (pubchem); cytarabine 243.219 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Cmax/(ng mL−1)b', value '2579.92') — already have one for this compound</li><li>dropped duplicate Q56 ('Tmax/(h)c', value '1') — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2/(h)d', value '11.46') — already have one for this compound</li><li>dropped duplicate Q53 ('MRT0-∞/(h)e', value '14.09') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ara-C (Cytarabine) and PA-Ara</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'intravenous ara-c' subgroup of Zhang_2018 (paper reports 5 populations: intravenous ara-c, oral suspension / ara-c, oral suspension / pa-ara, oral suspension ara-c, oral suspension pa-ara)</li><li>gap-filled Q61 (V) from Erba_2013's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Erba_2013 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Cytarabine_Zhang2018_intravenous_ara_c;
