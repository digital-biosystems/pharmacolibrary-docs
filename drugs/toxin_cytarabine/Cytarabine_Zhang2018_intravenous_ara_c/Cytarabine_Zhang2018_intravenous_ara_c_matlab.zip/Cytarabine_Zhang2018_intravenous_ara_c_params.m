function p = Cytarabine_Zhang2018_intravenous_ara_c_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cytarabine   source: Zhang_2018 / intravenous_ara_c   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cytarabine_Zhang2018_intravenous_ara_c_params';
  p.drug  = 'cytarabine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 654.0;                % central volume [L]
  p.CL = 19.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
