model Cytarabine_MegasVericat2019_PD_lpc_2
  "sigmoid_emax exposure-response sweep — Megías-Vericat_2019 :: LPC (Live pathological cells (LPC))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 8384,      // [cells]
    Emax = -1,  // [unitless]
    EC50 = 0.07,  // [μM]
    gamma = 1.04,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 0.7, Interval = 0.0014),
    Documentation(info = "<html><body><h4>Cytarabine_MegasVericat2019_PD_lpc_2</h4><p>The steady-state exposure-response curve of Megías-Vericat JE et al., <i>Mediterranean journal of hematology and infectious diseases 11(1):e2019016</i> 2019 (<a href=\"https://doi.org/10.4084/mjhid.2019.016\">doi:10.4084/mjhid.2019.016</a>) — Live pathological cells (LPC) [cells] against Cytarabine μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       8384 cells    drug-free response (baseline) (LPC0, Q324)
  Emax  =          1 unitless maximal effect term (Emax, Q323)
  EC50  =       0.07 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.04          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of Cytarabine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8384   (drug-free)
  exposure = EC50 (0.07 μM)  response 8384
  exposure -> infinity  response 8383</pre></body></html>"));
end Cytarabine_MegasVericat2019_PD_lpc_2;
