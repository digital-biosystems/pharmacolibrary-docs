function p = Cytarabine_Jost2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cytarabine   source: Jost_2019 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cytarabine_Jost2019_reference_params';
  p.drug  = 'cytarabine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 209.25;                % central volume [L]
  p.CL = 208.73;                % clearance [L/h]
  p.Vp = [7.7825];             % peripheral volumes [L]
  p.Q  = [13.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
