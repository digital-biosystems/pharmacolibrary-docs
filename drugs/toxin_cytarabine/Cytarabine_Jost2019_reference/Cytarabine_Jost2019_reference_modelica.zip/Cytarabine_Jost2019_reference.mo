model Cytarabine_Jost2019_reference
  parameter Real Cl_ref = 5.7980555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.20925 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.243219,
    adminMass = 1e-05,
    k12 = 1.81866454267888e-05,
    k21 = 0.0004889888282114431
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cytarabine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jost_2019</td></tr><tr><td>measured_compound:</td><td>cytarabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cytarabine 243.219 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jost_2019) — secondary source</li><li>volume reported by review</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cytarabine_Jost2019_reference;
