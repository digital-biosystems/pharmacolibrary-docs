model Duloxetine_Skinner2004_reference
  parameter Real Cl_ref = 1.4611111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.9540000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 7.138888888888889e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>women with urinary incontinence and healthy women</td></tr><tr><td>source_paper:</td><td>Skinner_2004</td></tr><tr><td>measured_compound:</td><td>duloxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number None (source ['tab_0:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q27 ('CL/F (l h -1 )'=52.6) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F (l)'=954) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (h -1 )'=0.257) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=duloxetine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Skinner2004_reference;
