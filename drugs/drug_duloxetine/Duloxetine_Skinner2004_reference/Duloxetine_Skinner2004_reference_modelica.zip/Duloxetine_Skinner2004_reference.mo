model Duloxetine_Skinner2004_reference
  parameter Real Cl_ref = 1.4611111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.994 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29741500000000004,
    adminMass = 2e-05,
    ka = 7.444444444444444e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About duloxetine</h4><p>Duloxetine is a serotonin–norepinephrine reuptake inhibitor used to treat major depressive disorder, anxiety disorders, and chronic pain conditions such as fibromyalgia and neuropathic pain. The medication is taken by mouth and is well absorbed in the gut. It is authorized in the European Union and is available as a generic medication in multiple regions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411932\">Wikidata Q411932</a>, <a href=\"https://en.wikipedia.org/wiki/Duloxetine?oldid=1385351307\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>women</td></tr><tr><td>source_paper:</td><td>Skinner_2004</td></tr><tr><td>measured_compound:</td><td>duloxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>duloxetine 297.415 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('CL/F (l h -1 )'=52.6) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F (l)'=994) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (h -1 )'=0.268) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=duloxetine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Skinner2004_reference;
