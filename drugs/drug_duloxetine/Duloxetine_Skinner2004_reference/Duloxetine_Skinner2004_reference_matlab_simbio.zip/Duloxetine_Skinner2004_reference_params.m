function p = Duloxetine_Skinner2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: duloxetine   source: Skinner_2004 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Duloxetine_Skinner2004_reference_params';
  p.drug  = 'duloxetine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 954.0;                % central volume [L]
  p.CL = 52.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.257;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
