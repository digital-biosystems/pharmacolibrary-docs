function p = Isoniazid_Abdelgawad2022_isoniazid_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: isoniazid   source: Abdelgawad_2022 / isoniazid   route: oral
  % estimated (absent from source): F
  p.name  = 'Isoniazid_Abdelgawad2022_isoniazid_params';
  p.drug  = 'isoniazid';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 59.0;                % central volume [L]
  p.CL = 25.5;                % clearance [L/h]
  p.Vp = [30.7];             % peripheral volumes [L]
  p.Q  = [1.43];             % inter-compartmental clearances [L/h]
  p.ka = 2.43;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
