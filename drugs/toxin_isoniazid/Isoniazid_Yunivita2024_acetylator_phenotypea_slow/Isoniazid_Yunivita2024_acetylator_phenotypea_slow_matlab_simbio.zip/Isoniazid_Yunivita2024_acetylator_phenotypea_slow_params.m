function p = Isoniazid_Yunivita2024_acetylator_phenotypea_slow_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: isoniazid   source: Yunivita_2024 / acetylator_phenotypea_slow   route: oral
  p.name  = 'Isoniazid_Yunivita2024_acetylator_phenotypea_slow_params';
  p.drug  = 'isoniazid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 41.5;                % central volume [L]
  p.CL = 7.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.23;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
