model Isoniazid_Yunivita2024_acetylator_phenotypea_slow
  parameter Real Cl_ref = 2.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0415 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.137142,
    adminMass = 0.0007,
    ka = 0.001175,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>isoniazid</td></tr><tr><td>population:</td><td>Indonesian adults aged 18-65 years treated for pulmonary RR/MDR-TB</td></tr><tr><td>source_paper:</td><td>Yunivita_2024</td></tr><tr><td>measured_compound:</td><td>Isoniazid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkae057-T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>isoniazid 137.142 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'T max, h, median (IQR)' — extend the ontology if this is a real PK parameter (source ['Yunivita_2024_table_2:row3:col2'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 0.117 (source ['dkae057-T4:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 0.546 (source ['dkae057-T4:footnote']); the table cell was unparseable — needs review</li><li>'Area under the receiver operating characteristic (ROC) curves: AUC0–24 model': unit 'AUC' is a parameter symbol — dropped</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 0.855 (source ['dkae057-T4:footnote']); the table cell was unparseable — needs review</li><li>'Area under the receiver operating characteristic (ROC) curves: Cmax model': unit 'AUC' is a parameter symbol — dropped</li><li>NIL: refused to back-fill base 'Cmax' from footnote/prose loose number 0.789 (source ['dkae057-T4:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'Ke' → 1/h (from the printed half-life: 'Ke = 0.2 and t ½, h = 3.7 h: λ·t½ = ln2 only in 1/h')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Isoniazid</li><li>population split: 'acetylator phenotypea / slow (n = 14)' subgroup of Yunivita_2024 (paper reports 4 populations: acetylator phenotypea / non-slow (n = 25), acetylator phenotypea / slow (n = 14), delayed culture conversion (n = 11), no delayed culture conversion (n = 22))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Thomas_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Isoniazid_Yunivita2024_acetylator_phenotypea_slow;
