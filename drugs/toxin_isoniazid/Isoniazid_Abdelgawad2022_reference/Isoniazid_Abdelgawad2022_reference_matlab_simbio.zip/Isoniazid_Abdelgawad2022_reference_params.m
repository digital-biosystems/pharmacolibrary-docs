function p = Isoniazid_Abdelgawad2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: isoniazid   source: Abdelgawad_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Isoniazid_Abdelgawad2022_reference_params';
  p.drug  = 'isoniazid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 56.8;                % central volume [L]
  p.CL = 8.82;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.23;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
