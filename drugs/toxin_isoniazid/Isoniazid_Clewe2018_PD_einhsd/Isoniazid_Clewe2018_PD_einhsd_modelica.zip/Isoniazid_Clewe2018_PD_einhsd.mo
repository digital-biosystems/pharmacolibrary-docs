model Isoniazid_Clewe2018_PD_einhsd
  "sigmoid_emax exposure-response sweep — Clewe_2018 :: EINHSD (slow-multiplying bacterial state kill rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -9.89583333333e-05,  // [1/s; days−1 × 1.15741e-05]
    EC50 = 3.29e-05,  // [kg/m3; mg·L−1 × 0.001]
    gamma = 1.74,
    exposure_per_s = 0.001);   // 1 mg·L−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.33, Interval = 0.00066),
    Documentation(info = "<html><body><h4>Isoniazid_Clewe2018_PD_einhsd</h4><p>The steady-state exposure-response curve of Clewe O et al., <i>The Journal of antimicrobial chemotherapy 73(2):437–447</i> 2018 (<a href=\"https://doi.org/10.1093/jac/dkx380\">doi:10.1093/jac/dkx380</a>) — slow-multiplying bacterial state kill rate [days−1] against isoniazid mg·L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       8.55 days−1   maximal effect term (EmaxINHSD, Q323)
  EC50  =     0.0329 mg·L−1   exposure at half of the maximal effect term (EC50INHSD, Q321)
  gamma =       1.74          Hill coefficient (γHSD, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L−1 of isoniazid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0329 mg·L−1)  response -4.948e-05
  exposure -> infinity  response -9.896e-05</pre></body></html>"));
end Isoniazid_Clewe2018_PD_einhsd;
