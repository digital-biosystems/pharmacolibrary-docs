function p = Isoniazid_Clewe2018_PD_einhsd_params()
% Isoniazid_Clewe2018_PD_einhsd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoniazid Clewe_2018::EINHSD: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L−1 per second, in SI inside (kg/m3, s). Response EINHSD in days−1. Driver: isoniazid (cited_pk).
p.E0 = 0.0;
p.Emax = -9.895833333333333e-05;
p.EC50 = 3.289999999999999e-05;
p.gamma = 1.74;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.33;
p.form = 'E0 + Emax*frac';
end
