function p = Isoniazid_van2020_PD_bac_params()
% Isoniazid_van2020_PD_bac_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoniazid van_2020::Bac: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response Bac in Fluorescence. Driver: isoniazid (cited_pk).
p.E0 = 16.3;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 9910.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
