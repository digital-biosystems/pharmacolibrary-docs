model Isoniazid_van2020_PD_bac
  "linear exposure-response sweep — van_2020 :: Bac (bacterial burden)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 16.3,      // [Fluorescence]
    slope = 9910,  // [1 / meter; µM−1 × 1e+06]
    exposure_per_s = 1);   // 1 µM per second
  // family_inferred: the record's model family is unknown; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Isoniazid_van2020_PD_bac</h4><p>The steady-state exposure-response curve of van Wijk RC et al., <i>British journal of pharmacology 177(24):5518–5533</i> 2020 (<a href=\"https://doi.org/10.1111/bph.15247\">doi:10.1111/bph.15247</a>) — bacterial burden [Fluorescence] against isoniazid µM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       16.3 Fluorescence drug-free response (baseline) (inoculum at treatment time point zero, Q324)
  slope =    0.00991 µM−1     change in response per unit of exposure (slope of drug effect, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µM of isoniazid per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 16.3   (drug-free)</pre></body></html>"));
end Isoniazid_van2020_PD_bac;
