function p = Isoniazid_Clewe2018_PD_einhfd_params()
% Isoniazid_Clewe2018_PD_einhfd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoniazid Clewe_2018::EINHFD: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L−1 per second, in SI inside (kg/m3, s). Response EINHFD in days−1. Driver: isoniazid (cited_pk).
p.E0 = 0.0;
p.Emax = -0.0002569444444444444;
p.EC50 = 0.000168;
p.gamma = 1.9;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 1.7;
p.form = 'E0 + Emax*frac';
end
