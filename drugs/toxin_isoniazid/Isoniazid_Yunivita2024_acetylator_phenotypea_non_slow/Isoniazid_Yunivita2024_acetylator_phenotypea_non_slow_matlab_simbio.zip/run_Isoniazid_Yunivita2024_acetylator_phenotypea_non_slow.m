% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Isoniazid_Yunivita2024_acetylator_phenotypea_non_slow_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
