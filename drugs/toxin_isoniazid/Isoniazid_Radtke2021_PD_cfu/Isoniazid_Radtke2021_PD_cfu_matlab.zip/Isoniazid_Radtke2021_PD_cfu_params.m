function p = Isoniazid_Radtke2021_PD_cfu_params()
% Isoniazid_Radtke2021_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoniazid Radtke_2021::CFU: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response CFU in log10. Driver: rifapentine and isoniazid (not_resolved).
p.E0 = 0.0;
p.Emax = 0.24;
p.EC50 = 0.0021199999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 22.0;
p.form = 'E0/(1 - Emax*frac)';
end
