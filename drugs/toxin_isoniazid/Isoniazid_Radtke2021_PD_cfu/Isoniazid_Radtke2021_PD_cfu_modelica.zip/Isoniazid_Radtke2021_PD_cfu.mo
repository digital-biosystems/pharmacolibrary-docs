model Isoniazid_Radtke2021_PD_cfu
  "indirect_response_ii exposure-response sweep — Radtke_2021 :: CFU (Lung CFU)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.24,  // type II effect term
    EC50 = 0.00212,  // [kg/m3; mg/liter × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/liter per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 22, Interval = 0.044),
    Documentation(info = "<html><body><h4>Isoniazid_Radtke2021_PD_cfu</h4><p>The steady-state exposure-response curve of Radtke KK et al., <i>Antimicrobial agents and chemotherapy 65(12):e0170521</i> 2021 (<a href=\"https://doi.org/10.1128/AAC.01705-21\">doi:10.1128/AAC.01705-21</a>) — Lung CFU [log10] against rifapentine and isoniazid mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.24          maximal effect term (Maximum regimen effect, Q320)
  EC50  =       2.12 mg/liter exposure at half of the maximal effect term (Regimen potency (3HP), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/liter of rifapentine and isoniazid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.12 mg/liter)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Isoniazid_Radtke2021_PD_cfu;
