function p = Isoniazid_Cordes2016_PD_n_params()
% Isoniazid_Cordes2016_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isoniazid Cordes_2016::N: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmol/liter per second, in SI inside (kg/m3, s). Response N in log10 CFU/liter. Driver: isoniazid (pk_record).
p.E0 = 0.0;
p.Emax = -6.180555555555556e-06;
p.EC50 = 0.025189999999999997;
p.gamma = 0.56;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 260.0;
p.form = 'E0 + Emax*frac';
end
