model Isoniazid_Cordes2016_PD_n
  "sigmoid_emax exposure-response sweep — Cordes_2016 :: N (mycobacterial growth)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -6.18055555556e-06,  // [1/s; day-1 × 1.15741e-05]
    EC50 = 0.02519,  // [mol/m3; μmol/liter × 0.001]
    gamma = 0.56,
    exposure_per_s = 0.001);   // 1 μmol/liter per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 260, Interval = 0.52),
    Documentation(info = "<html><body><h4>Isoniazid_Cordes2016_PD_n</h4><p>The steady-state exposure-response curve of Cordes H et al., <i>Antimicrobial agents and chemotherapy 60(10):6134–6145</i> 2016 (<a href=\"https://doi.org/10.1128/AAC.00508-16\">doi:10.1128/AAC.00508-16</a>) — mycobacterial growth [log10 CFU/liter] against isoniazid μmol/liter — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.534 day-1    maximal effect term (Emax, Q323)
  EC50  =      25.19 μmol/liter exposure at half of the maximal effect term (Km, Q321)
  gamma =       0.56          Hill coefficient (h, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μmol/liter of isoniazid per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (25.19 μmol/liter)  response -3.09e-06
  exposure -> infinity  response -6.181e-06</pre></body></html>"));
end Isoniazid_Cordes2016_PD_n;
