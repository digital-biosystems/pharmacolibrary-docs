// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Psilocin_LevyCooperman2026_any_teae
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5760.0},
    MM = 0.20427299999999998,
    adminMass = 5e-07,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>psilocin</td></tr><tr><td>population:</td><td>Healthy adults</td></tr><tr><td>source_paper:</td><td>Levy-Cooperman_2026</td></tr><tr><td>measured_compound:</td><td>Psilocin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 2</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Psilocin 204.273 g/mol (pubchem); Psilocybin 284.252 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Levy-Cooperman_2026_table_2: rows are variants (Any TEAE, Somnolence, Dizziness, Headache, Euphoric mood, Nausea), the parameters are the column headers (Placebo (n = 14)) — read one record per variant</li><li>dropped unlinked row (NIL): 'Placebo (n = 14)' — extend the ontology if this is a real PK parameter (source ['Levy-Cooperman_2026_table_2:row0:col7'])</li><li>salvaged Q57 ('median terminal elimination half-life (t½) at 0.5 mg'=1.6) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Psilocin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>estimate-method split: 'Any TEAE' is one of 13 estimates of Levy-Cooperman_2026's substance matrix (Any TEAE, Somnolence, Dizziness, Headache, Euphoric mood, Nausea, Vision blurred, Hallucination, Hypervigilance, Dry eye, Fatigue, Sluggishness, Rash); same population, different estimation method</li><li>row roles: 14 per-group rows of none summary_statistic but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=noncompartmental; 14/14 row label(s) assigned, 0 linked by role</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Psilocin_LevyCooperman2026_any_teae;
