model Ensitrelvir_Ishibashi2024_median
  parameter Real Cl_ref = 5.5e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0141 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.53188,
    adminMass = 2e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ensitrelvir</h4><p>Ensitrelvir is an investigational antiviral drug that works as a protease inhibitor. It is not yet an approved medicine in major regions such as the European Union and remains under investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q110798570\">Wikidata Q110798570</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ensitrelvir</td></tr><tr><td>population:</td><td>healthy participants and participants infected with SARS-CoV-2</td></tr><tr><td>source_paper:</td><td>Ishibashi_2024</td></tr><tr><td>measured_compound:</td><td>ensitrelvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ensitrelvir 531.88 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Cmax_d5 (μg/mL)', value '55.1') — already have one for this compound</li><li>dropped duplicate Q75 ('C24_d5 (μg/mL)', value '40.8') — already have one for this compound</li><li>dropped duplicate Q32 ('Entire Cmax (μg/mL)', value '55.1') — already have one for this compound</li><li>dropped duplicate Q88 ('Entire AUC (μg*h/mL)', value '5317') — already have one for this compound</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number '0.594' (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number '0.362' (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number '0.521' (source ['Tab3:footnote', 'Tab3:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ensitrelvir</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F (L)' is the general volume)</li><li>population split: 'median' subgroup of Ishibashi_2024 (paper reports 2 populations: mean, median)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Ensitrelvir_Ishibashi2024_median;
