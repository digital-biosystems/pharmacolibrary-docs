function p = Ensitrelvir_Ishibashi2024_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ensitrelvir   source: Ishibashi_2024 / mean   route: oral
  % estimated (absent from source): ka
  p.name  = 'Ensitrelvir_Ishibashi2024_mean_params';
  p.drug  = 'ensitrelvir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.5;                % central volume [L]
  p.CL = 0.201;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
