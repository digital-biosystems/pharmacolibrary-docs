model Toloxatone_Vistelle1992_reference
  parameter Real Cl_ref = 1.3166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0058 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.20722900000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About toloxatone</h4><p>Toloxatone is an antidepressant and selective reversible inhibitor of monoamine oxidase A, developed for the treatment of depression. The drug is currently considered experimental and is no longer used in clinical practice.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q3530618\">Wikidata Q3530618</a>, <a href=\"https://en.wikipedia.org/wiki/Toloxatone?oldid=1335576371\">Wikipedia</a> (CC BY-SA 4.0) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>toloxatone</td></tr><tr><td>population:</td><td>anaesthetized rabbits</td></tr><tr><td>source_paper:</td><td>Vistelle_1992</td></tr><tr><td>measured_compound:</td><td>toloxatone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>toloxatone 207.229 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=toloxatone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Toloxatone_Vistelle1992_reference;
