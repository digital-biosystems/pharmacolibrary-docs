function p = AcetylTributylCitrate_Kim2018_atbc_iv_10_mg_kg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: acetyl_tributyl_citrate   source: Kim_2018 / atbc_iv_10_mg_kg   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'AcetylTributylCitrate_Kim2018_atbc_iv_10_mg_kg_params';
  p.drug  = 'acetyl_tributyl_citrate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5628.0;                % central volume [L]
  p.CL = 5299.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
