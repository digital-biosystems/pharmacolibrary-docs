model AcetylTributylCitrate_Kim2018_atbc_iv_10_mg_kg
  parameter Real Cl_ref = 0.0014719444444444443 "Cl [m3/s]";
  parameter Real Vd_ref = 5.628000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>acetyl_tributyl_citrate</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Kim_2018</td></tr><tr><td>measured_compound:</td><td>Acetyl tributyl citrate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-10-00177-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>acetyl_tributyl_citrate 402.484 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Acetyl tributyl citrate</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'atbc / iv (10 mg/kg, n = 5)' subgroup of Kim_2018 (paper reports 2 populations: atbc / iv (10 mg/kg, n = 5), atbc / po (500 mg/kg, n = 6))</li><li>molar mass: none of 1 PubChem candidate(s) is 'Acetyl tributyl citrate' (LLM) — left in mass units</li><li>molar mass: none found for 'Acetyl tributyl citrate' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AcetylTributylCitrate_Kim2018_atbc_iv_10_mg_kg;
