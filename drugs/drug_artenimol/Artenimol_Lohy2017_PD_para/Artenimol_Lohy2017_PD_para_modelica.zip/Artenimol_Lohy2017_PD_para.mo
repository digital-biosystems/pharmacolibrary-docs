model Artenimol_Lohy2017_PD_para
  "sigmoid_emax exposure-response sweep — Lohy_2017 :: PARA (Total baseline circulating parasite biomass)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.19444444444e-05,  // [1/s; h -1 × 0.000277778]
    EC50 = 34.9,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 350, Interval = 0.7),
    Documentation(info = "<html><body><!-- drug-about --><h4>About artenimol</h4><p>Artenimol (dihydroartemisinin) is an antimalarial medicine used to treat malaria. It is used both alone and in combination with other antimalarials, and is approved in some regions while still being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5276420\">Wikidata Q5276420</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Artenimol_Lohy2017_PD_para</h4><p>The steady-state exposure-response curve of Lohy Das J et al., <i>The AAPS journal 19(6):1842–1854</i> 2017 (<a href=\"https://doi.org/10.1208/s12248-017-0141-1\">doi:10.1208/s12248-017-0141-1</a>) — Total baseline circulating parasite biomass [Log10] against Dihydroartemisinin nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.187 h -1     maximal effect term (Emax R, Q323)
  EC50  =       34.9 nM       exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of Dihydroartemisinin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (34.9 nM)  response -2.597e-05
  exposure -> infinity  response -5.194e-05</pre></body></html>"));
end Artenimol_Lohy2017_PD_para;
