function p = Artenimol_Lohy2017_PD_para_params()
% Artenimol_Lohy2017_PD_para_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artenimol Lohy_2017::PARA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response PARA in Log10. Driver: Dihydroartemisinin (cited_pk).
p.E0 = 0.0;
p.Emax = -5.1944444444444446e-05;
p.EC50 = 34.9;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 350.0;
p.form = 'E0 + Emax*frac';
end
