function p = Artenimol_Patel2014_PD_parasite_density_params()
% Artenimol_Patel2014_PD_parasite_density_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artenimol Patel_2014::parasite_density: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response parasite density in its own unit. Driver: dihydroartemisinin (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 7.469999999999998e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 7.5;
p.form = 'E0*(1 - Emax*frac)';
end
