model Artenimol_Patel2013_PD_parasitemia
  "indirect_response_i exposure-response sweep — Patel_2013 :: parasitemia (parasitemia)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.46e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><!-- drug-about --><h4>About artenimol</h4><p>Artenimol (dihydroartemisinin) is an antimalarial medicine used to treat malaria. It is used both alone and in combination with other antimalarials, and is approved in some regions while still being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5276420\">Wikidata Q5276420</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Artenimol_Patel2013_PD_parasitemia</h4><p>The steady-state exposure-response curve of Patel K et al., <i>Antimicrobial agents and chemotherapy 57(1):508–516</i> 2013 (<a href=\"https://doi.org/10.1128/AAC.01463-12\">doi:10.1128/AAC.01463-12</a>) — parasitemia against dihydroartemisinin ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       1.46 ng/ml    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of dihydroartemisinin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.46 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Artenimol_Patel2013_PD_parasitemia;
