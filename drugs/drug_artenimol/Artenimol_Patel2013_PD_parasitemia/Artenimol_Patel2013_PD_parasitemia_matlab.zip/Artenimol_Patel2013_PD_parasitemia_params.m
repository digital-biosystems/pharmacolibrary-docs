function p = Artenimol_Patel2013_PD_parasitemia_params()
% Artenimol_Patel2013_PD_parasitemia_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artenimol Patel_2013::parasitemia: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response parasitemia in its own unit. Driver: dihydroartemisinin (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.46e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 15.0;
p.form = 'E0*(1 - Emax*frac)';
end
