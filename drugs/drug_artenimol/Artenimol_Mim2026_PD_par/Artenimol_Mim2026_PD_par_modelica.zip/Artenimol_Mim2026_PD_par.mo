model Artenimol_Mim2026_PD_par
  "indirect_response_i exposure-response sweep — Mim_2026 :: PAR (parasitemia)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.178,      // [1; % × 0.01]
    Emax = 1,  // type I effect term
    EC50 = 10.93,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About artenimol</h4><p>Artenimol (dihydroartemisinin) is an antimalarial medicine used to treat malaria. It is used both alone and in combination with other antimalarials, and is approved in some regions while still being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5276420\">Wikidata Q5276420</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Artenimol_Mim2026_PD_par</h4><p>The steady-state exposure-response curve of Mim SR et al., <i>Antimicrobial agents and chemotherapy 70(3):e0171725</i> 2026 (<a href=\"https://doi.org/10.1128/aac.01717-25\">doi:10.1128/aac.01717-25</a>) — parasitemia [%] against artenimol nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       17.8 %        drug-free response (baseline) (Baseline response, R0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      10.93 nM       exposure at half of the maximal effect term (Half-maximal inhibitory concentration, IC50 (AS), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of artenimol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.178   (drug-free)
  exposure = EC50 (10.93 nM)  response 0.089
  exposure -> infinity  response 0</pre></body></html>"));
end Artenimol_Mim2026_PD_par;
