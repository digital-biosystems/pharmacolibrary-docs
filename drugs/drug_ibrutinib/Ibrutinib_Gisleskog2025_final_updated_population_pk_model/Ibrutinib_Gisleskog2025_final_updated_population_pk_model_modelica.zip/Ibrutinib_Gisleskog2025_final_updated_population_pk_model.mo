model Ibrutinib_Gisleskog2025_final_updated_population_pk_model
  parameter Real Cl_ref = 0.00031194444444444444 "Cl [m3/s]";
  parameter Real Vd_ref = 7.2860000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.440507,
    adminMass = 0.00056,
    ka = 0.0001997222222222222,
    Tlag = 601.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ibrutinib</h4><p>Ibrutinib is a protein kinase inhibitor used for cancers such as mantle cell lymphoma and chronic lymphocytic leukemia. The drug is taken orally in capsule or tablet form, and it is well absorbed from the gut. It is approved in the European Union and included in the World Health Organization's essential medicines list.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q5984881\">Wikidata Q5984881</a>, <a href=\"https://en.wikipedia.org/wiki/Ibrutinib?oldid=1383460976\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibrutinib</td></tr><tr><td>population:</td><td>patients with previously untreated mantle cell lymphoma</td></tr><tr><td>source_paper:</td><td>Gisleskog_2025</td></tr><tr><td>measured_compound:</td><td>ibrutinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470061-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ibrutinib 440.507 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate effect for Q87 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ibrutinib</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'final (updated) population pk model' subgroup of Gisleskog_2025 (paper reports 2 populations: final (updated) population pk model, previous population pk model)</li><li>gap-filled Q76 (V/F) from Gisleskog_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Ibrutinib_Gisleskog2025_final_updated_population_pk_model;
