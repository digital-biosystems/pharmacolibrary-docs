function p = Budesonide_Lnnebo2007_PD_acth_params()
% Budesonide_Lnnebo2007_PD_acth_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% budesonide Lönnebo_2007::ACTH: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l-1 per second, in SI inside (kg/m3, s). Response ACTH in pmol l-1. Driver: budesonide (pk_record).
p.E0 = 2.5799999999999998e-09;
p.Emax = 1.0;
p.EC50 = 0.00032499999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.3;
p.form = 'E0*(1 - Emax*frac)';
end
