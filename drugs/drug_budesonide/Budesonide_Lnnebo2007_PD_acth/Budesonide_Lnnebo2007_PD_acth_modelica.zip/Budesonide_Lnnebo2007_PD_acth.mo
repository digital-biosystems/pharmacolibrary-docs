model Budesonide_Lnnebo2007_PD_acth
  "indirect_response_i exposure-response sweep — Lönnebo_2007 :: ACTH (ACTH)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.58e-09,      // [mol/m3; pmol l-1 × 1e-09]
    Emax = 1,  // type I effect term
    EC50 = 0.000325,  // [kg/m3; mg l-1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg l-1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.3, Interval = 0.0066),
    Documentation(info = "<html><body><!-- drug-about --><h4>About budesonide</h4><p>Budesonide is a corticosteroid used for inflammatory conditions such as asthma, Crohn's disease, ulcerative colitis, and microscopic colitis. It is widely used and authorised in the European Union, where products cover areas such as IgA glomerulonephritis and esophageal diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422212\">Wikidata Q422212</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Budesonide_Lnnebo2007_PD_acth</h4><p>The steady-state exposure-response curve of Lönnebo A et al., <i>British journal of clinical pharmacology 64(2):125–132</i> 2007 (<a href=\"https://doi.org/10.1111/j.1365-2125.2007.02867.x\">doi:10.1111/j.1365-2125.2007.02867.x</a>) — ACTH [pmol l-1] against budesonide mg l-1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       2.58 pmol l-1 drug-free response (baseline) (Baseline ACTH, Q324)
  Emax  =          1          maximal effect term (I max, Q323)
  EC50  =      0.325 mg l-1   exposure at half of the maximal effect term (IC 50,1 and 2, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg l-1 of budesonide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.58e-09   (drug-free)
  exposure = EC50 (0.325 mg l-1)  response 1.29e-09
  exposure -> infinity  response 0</pre></body></html>"));
end Budesonide_Lnnebo2007_PD_acth;
