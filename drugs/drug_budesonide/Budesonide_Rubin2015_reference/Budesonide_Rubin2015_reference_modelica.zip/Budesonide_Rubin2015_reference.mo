model Budesonide_Rubin2015_reference
  parameter Real Cl_ref = 0.0001288888888888889 "Cl [m3/s]";
  parameter Real Vd_ref = 2.7 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 536.4
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>budesonide</td></tr><tr><td>population:</td><td>patients with mild-to-moderate ulcerative proctitis or proctosigmoiditis and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Rubin_2015</td></tr><tr><td>measured_compound:</td><td>budesonide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter, mean (CV)' — extend the ontology if this is a real PK parameter (source ['Tab4:row0:col1'])</li><li>unit_dimension_unknown: 'ng h/mL' (AUC)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=budesonide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Budesonide_Rubin2015_reference;
