function p = Budesonide_Back2020_PD_ecp_params()
% Budesonide_Back2020_PD_ecp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% budesonide Back_2020::ECP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·mL−1 per second, in SI inside (kg/m3, s). Response ECP in ng/mL. Driver: budesonide (pk_record).
p.E0 = 1.9699999999999998e-05;
p.Emax = 1.0;
p.EC50 = 2.5e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.25;
p.form = 'E0*(1 - Emax*frac)';
end
