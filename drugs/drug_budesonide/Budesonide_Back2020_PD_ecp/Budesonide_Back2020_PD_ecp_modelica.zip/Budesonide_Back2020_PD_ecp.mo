model Budesonide_Back2020_PD_ecp
  "indirect_response_i exposure-response sweep — Back_2020 :: ECP (sputum ECP)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.97e-05,      // [kg/m3; ng/mL × 1e-06]
    Emax = 1,  // type I effect term
    EC50 = 2.5e-08,  // [kg/m3; ng·mL−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng·mL−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.25, Interval = 0.0005),
    Documentation(info = "<html><body><!-- drug-about --><h4>About budesonide</h4><p>Budesonide is a corticosteroid used for inflammatory conditions such as asthma, Crohn's disease, ulcerative colitis, and microscopic colitis. It is widely used and authorised in the European Union, where products cover areas such as IgA glomerulonephritis and esophageal diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422212\">Wikidata Q422212</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Budesonide_Back2020_PD_ecp</h4><p>The steady-state exposure-response curve of Back HM et al., <i>Pharmaceutics 12(4)</i> 2020 (<a href=\"https://doi.org/10.3390/pharmaceutics12040336\">doi:10.3390/pharmaceutics12040336</a>) — sputum ECP [ng/mL] against budesonide ng·mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       19.7 ng/mL    drug-free response (baseline) (BASE, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      0.025 ng·mL−1  exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng·mL−1 of budesonide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.97e-05   (drug-free)
  exposure = EC50 (0.025 ng·mL−1)  response 9.85e-06
  exposure -> infinity  response 0</pre></body></html>"));
end Budesonide_Back2020_PD_ecp;
