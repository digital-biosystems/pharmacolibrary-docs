model Diphenhydramine_Wasfi2003_reference
  parameter Real Cl_ref = 1.3477861844221159e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1106 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2553547,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About diphenhydramine</h4><p>Diphenhydramine is a first-generation antihistamine with sedative properties, primarily used to treat allergies, insomnia, and urticaria. It is usually taken orally, but it can also be applied to the skin or administered via intravenous injection. It is a widely available generic medication used commonly for these indications.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q413486\">Wikidata Q413486</a>, <a href=\"https://en.wikipedia.org/wiki/Diphenhydramine?oldid=1384710294\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>diphenhydramine</td></tr><tr><td>population:</td><td>camels and horses</td></tr><tr><td>source_paper:</td><td>Wasfi_2003</td></tr><tr><td>measured_compound:</td><td>diphenhydramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diphenhydramine 255.355 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=diphenhydramine</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volumes of the central compartment of the two compartment pharmacokinetic model' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>derived CL=48.5203 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diphenhydramine_Wasfi2003_reference;
