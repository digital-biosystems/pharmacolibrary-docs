function p = Gemcitabine_Jiang2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gemcitabine   source: Jiang_2008 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Gemcitabine_Jiang2008_reference_params';
  p.drug  = 'gemcitabine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15.0;                % central volume [L]
  p.CL = 162.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
