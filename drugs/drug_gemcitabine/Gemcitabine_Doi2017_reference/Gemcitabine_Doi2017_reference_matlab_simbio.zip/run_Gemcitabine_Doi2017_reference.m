% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Gemcitabine_Doi2017_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
