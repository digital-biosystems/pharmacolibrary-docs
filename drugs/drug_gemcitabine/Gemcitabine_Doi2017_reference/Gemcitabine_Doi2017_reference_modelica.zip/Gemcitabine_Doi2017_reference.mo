model Gemcitabine_Doi2017_reference
  parameter Real Cl_ref = 1.9083333333333335e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00269 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 1.2081784386617098e-06,
    k21 = 8.312020460358054e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gemcitabine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Doi_2017</td></tr><tr><td>measured_compound:</td><td>gemcitabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Doi_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Gemcitabine_Doi2017_reference;
