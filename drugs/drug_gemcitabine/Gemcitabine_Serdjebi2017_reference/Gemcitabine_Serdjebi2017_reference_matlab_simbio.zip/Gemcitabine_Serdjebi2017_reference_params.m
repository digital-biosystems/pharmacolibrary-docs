function p = Gemcitabine_Serdjebi2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gemcitabine   source: Serdjebi_2017 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Gemcitabine_Serdjebi2017_reference_params';
  p.drug  = 'gemcitabine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 241.8;                % clearance [L/h]
  p.Vp = [36.0];             % peripheral volumes [L]
  p.Q  = [13.56];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
