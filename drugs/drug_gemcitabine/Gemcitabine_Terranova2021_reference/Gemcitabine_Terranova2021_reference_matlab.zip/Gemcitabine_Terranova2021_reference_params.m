function p = Gemcitabine_Terranova2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gemcitabine   source: Terranova_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Gemcitabine_Terranova2021_reference_params';
  p.drug  = 'gemcitabine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 118.0;                % central volume [L]
  p.CL = 65.0;                % clearance [L/h]
  p.Vp = [1030.0];             % peripheral volumes [L]
  p.Q  = [29.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
