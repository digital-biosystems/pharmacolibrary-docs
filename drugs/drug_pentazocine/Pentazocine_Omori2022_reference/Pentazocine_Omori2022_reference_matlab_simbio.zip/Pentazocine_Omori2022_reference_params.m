function p = Pentazocine_Omori2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pentazocine   source: Omori_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pentazocine_Omori2022_reference_params';
  p.drug  = 'pentazocine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 72.8;                % central volume [L]
  p.CL = 83.3;                % clearance [L/h]
  p.Vp = [211.4];             % peripheral volumes [L]
  p.Q  = [240.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
