// parent + metabolites (dihydroartemisinin): PK_3M_9C — formed from central; parent 2, metabolites [1]
model Artemether_Lohy2018_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.139,
    Vd2 = 0.111,
    q12 = 2.5666666666666666e-07,
    q21 = 2.5666666666666666e-07,
    q1_m11 = 1.2472222222222223e-06,
    CL1 = 0.0,
    Vd1m1 = 0.137,
    CLm1 = 0.00016972222222222223,
    MW = 0.2983746,
    MW_m1 = 0.284352,
    F = 1,
    ka = 1.6027777777777778e-05,
    Tlag = 4716.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 8e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About artemether</h4><p>Artemether is an antimalarial medicine of the artemisinin group, used to treat malaria, and is also reported to have activity against other protozoa and schistosomiasis. It is an approved medicine, appears on the WHO essential medicines list, and is used both alone and in combination antimalarial products worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416199\">Wikidata Q416199</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>artemether</td></tr><tr><td>population:</td><td>pregnant women</td></tr><tr><td>source_paper:</td><td>Lohy_2018</td></tr><tr><td>measured_compound:</td><td>artemether</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of dihydroartemisinin: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; dose 80 mg (paper)</td></tr><tr><td>molar_masses:</td><td>artemether 298.375 g/mol (drugbank); dihydroartemisinin 284.352 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'MTT (h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'Vc/F (liters)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'F' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'MTT (h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'CLARM/F (liters/h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'VARM/F (liters)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'CLDHA/F (liters/h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'VDHA/F (liters)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table representations disagree for 'F'; source reconciliation required</li><li>table representations disagree for 'Box-Cox shape parameter for BSV on F'; source reconciliation required</li><li>table representations disagree for 'MTT (h)'; source reconciliation required</li><li>table representations disagree for 'CL/F (liters/h)'; source reconciliation required</li><li>table representations disagree for 'Vc/F (liters)'; source reconciliation required</li><li>table representations disagree for 'Q/F (liters/h)'; source reconciliation required</li><li>table representations disagree for 'Vp/F (liters)'; source reconciliation required</li><li>table representations disagree for 'RUV (%)'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Artemether_Lohy2018_reference;
