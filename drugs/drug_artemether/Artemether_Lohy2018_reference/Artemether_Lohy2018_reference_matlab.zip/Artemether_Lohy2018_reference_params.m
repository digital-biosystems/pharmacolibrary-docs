function p = Artemether_Lohy2018_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: artemether   source: Lohy_2018 / reference   PK_3M_9C parent + 1 metabolite(s), 3 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=298.375 g/mol C_M1=284.352 g/mol
  p.name  = 'Artemether_Lohy2018_reference_params';
  p.drug  = 'artemether';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'central_M1'};
  p.V = [139.0, 111.0, 137.0];          % compartment volumes [L]
  p.K = [-0.03894964028776978, 0.008324324324324324, 0.0;
         0.006647482014388488, -0.008324324324324324, 0.0;
         0.030784065766162796, 0.0, -4.45985401459854];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 0.0577;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.31;             % absorption lag [h] (in dose_start)
  p.dose = 80.0;             % dose [mg]
  p.dose_start = 1.3266666666666667;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'artemether', 'dihydroartemisinin'};
end
