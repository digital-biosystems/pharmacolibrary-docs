function p = Omalizumab_Oh2023_PD_itch_severity_score_params()
% Omalizumab_Oh2023_PD_itch_severity_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omalizumab Oh_2023::itch_severity_score: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response itch severity score in its own unit. Driver: total omalizumab (not_resolved).
p.E0 = 13.5;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0172;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
