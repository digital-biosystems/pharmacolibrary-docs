model Omalizumab_Oh2023_PD_itch_severity_score
  "linear exposure-response sweep — Oh_2023 :: itch severity score (weekly itch severity score)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 13.5,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.0172   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About omalizumab</h4><p>Omalizumab, a monoclonal antibody, is used to treat allergic conditions such as asthma and chronic urticaria. It is authorised in the European Union for asthma, urticaria, and rhinitis, and is used in clinical practice for these allergic airway and skin conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415392\">Wikidata Q415392</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Omalizumab_Oh2023_PD_itch_severity_score</h4><p>The steady-state exposure-response curve of Oh E et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(6):795–807</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12953\">doi:10.1002/psp4.12953</a>) — weekly itch severity score against total omalizumab — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       13.5          drug-free response (baseline) (Baseline itch severity score, Q324)
  slope =     0.0172          change in response per unit of exposure (Slope term in linear drug effect model, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of total omalizumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 13.5   (drug-free)</pre></body></html>"));
end Omalizumab_Oh2023_PD_itch_severity_score;
