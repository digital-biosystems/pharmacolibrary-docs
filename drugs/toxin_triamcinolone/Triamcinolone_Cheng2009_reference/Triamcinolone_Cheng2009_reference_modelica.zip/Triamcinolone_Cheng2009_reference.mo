// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Triamcinolone_Cheng2009_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {2557440.0},
    MM = 0.39443900000000004,
    adminMass = 7.5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>triamcinolone</td></tr><tr><td>population:</td><td>patients receiving intravitreal injection</td></tr><tr><td>source_paper:</td><td>Cheng_2009</td></tr><tr><td>measured_compound:</td><td>Triamcinolone acetonide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Triamcinolone acetonide 394.439 g/mol (pubchem); triamcinolone 394.439 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'clearance coefficient' Q22 → Q47: a rate constant in '1/day' (the unit decides, not the label)</li><li>dropped unlinked row (NIL): 'injection dose' — extend the ontology if this is a real PK parameter (source ['Cheng_2009:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Triamcinolone acetonide</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 13305600, Tolerance = 1e-9, Interval = 26611.2));
end Triamcinolone_Cheng2009_reference;
