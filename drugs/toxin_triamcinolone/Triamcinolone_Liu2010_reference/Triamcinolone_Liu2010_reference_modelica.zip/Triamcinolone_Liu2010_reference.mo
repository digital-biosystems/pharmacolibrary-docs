// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Triamcinolone_Liu2010_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {28800.0},
    MM = 0.5144829999999999,
    adminMass = 7.5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>triamcinolone</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Liu_2010</td></tr><tr><td>measured_compound:</td><td>Triamcinolone acetonide phosphate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Triamcinolone acetonide phosphate 514.483 g/mol (pubchem); triamcinolone 394.439 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('The elimination half-lives of TAP in the eye after ... subconjunctival injections', value 0.5) — already have one for this compound</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Liu_2010:abstract'])</li><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Liu_2010:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Triamcinolone acetonide phosphate</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 288.0));
end Triamcinolone_Liu2010_reference;
