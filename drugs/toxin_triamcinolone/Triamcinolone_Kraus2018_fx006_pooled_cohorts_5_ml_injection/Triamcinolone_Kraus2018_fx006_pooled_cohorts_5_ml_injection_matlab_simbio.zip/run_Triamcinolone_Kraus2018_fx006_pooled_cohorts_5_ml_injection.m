% Run (SimBiology): build model + dose, simulate 0..168.0 h, plot.
p = Triamcinolone_Kraus2018_fx006_pooled_cohorts_5_ml_injection_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 168.0);
