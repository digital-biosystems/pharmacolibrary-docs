function p = Triamcinolone_Kraus2018_fx006_pooled_cohorts_5_ml_injection_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: triamcinolone   source: Kraus_2018 / fx006_pooled_cohorts_5_ml_injection_volume   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Triamcinolone_Kraus2018_fx006_pooled_cohorts_5_ml_injection_params';
  p.drug  = 'triamcinolone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.31;                % central volume [L]
  p.CL = 0.033;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 32.0;             % dose [mg]
end
