model Triamcinolone_Kraus2018_fx006_pooled_cohorts_5_ml_injection
  parameter Real Cl_ref = 9.166666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0023099999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.39443900000000004,
    adminMass = 3.2e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>triamcinolone</td></tr><tr><td>population:</td><td>patients with knee osteoarthritis</td></tr><tr><td>source_paper:</td><td>Kraus_2018</td></tr><tr><td>measured_compound:</td><td>Triamcinolone acetonide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Triamcinolone acetonide 394.439 g/mol (pubchem); triamcinolone 394.439 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q88 ('AUC0–6 weeks (h * pg/mL), GM', value '60') — already have one for this compound</li><li>dropped duplicate Q88 ('AUC0–12 weeks (h * pg/mL), GM', value '14') — already have one for this compound</li><li>dropped unlinked row (NIL): 'tlast (h), median' — extend the ontology if this is a real PK parameter (source ['Kraus_2018_table_2:row8:col1', 'Kraus_2018_table_2:row8:col2'])</li><li>unit_dimension_mismatch: 'Clast (pg/mL), GM' → Q74 (unit '[mass] / [length] ** 3' vs ontology '[mass] * [time] / [length] ** 3') — route to review</li><li>dropped duplicate Q74 ('Clast (pg/mL), GM', value '60') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Triamcinolone acetonide</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'fx006 pooled cohorts (5-ml injection volume)' subgroup of Kraus_2018 (paper reports 2 populations: fx006 pooled cohorts (5-ml injection volume), tacs cohort (1-ml injection volume))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Triamcinolone_Kraus2018_fx006_pooled_cohorts_5_ml_injection;
