// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Triamcinolone_Peng2010_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {63108.00000000001},
    MM = 0.434504,
    adminMass = 7.5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>triamcinolone</td></tr><tr><td>population:</td><td>rat plasma and liver homogenate (in vitro)</td></tr><tr><td>source_paper:</td><td>Peng_2010</td></tr><tr><td>measured_compound:</td><td>Triamcinolone acetonide (TAA)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Triamcinolone acetonide (TAA) 434.504 g/mol (pubchem); triamcinolone 394.439 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'The partition coefficient (log P) of TAP' — extend the ontology if this is a real PK parameter (source ['Peng_2010:abstract'])</li><li>relinked 'hydrolysis half-life of TAP in 100% rat plasma was' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>unit_dimension_unknown: 'hours at pH 7.4' (t1/2z)</li><li>implicit units: 'hydrolysis half-life of TAP in 100% rat plasma was' → h (from the popPK convention: 'The parameter is a half-life (t1/2). In population pharmacokinetics, half-lives are typically expressed in hours (h). Th')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Triamcinolone acetonide (TAA)</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Triamcinolone_Peng2010_reference;
