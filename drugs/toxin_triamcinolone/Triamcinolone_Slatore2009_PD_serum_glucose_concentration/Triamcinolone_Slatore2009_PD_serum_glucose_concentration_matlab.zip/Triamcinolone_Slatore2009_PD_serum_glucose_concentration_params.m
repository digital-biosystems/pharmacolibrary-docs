function p = Triamcinolone_Slatore2009_PD_serum_glucose_concentration_params()
% Triamcinolone_Slatore2009_PD_serum_glucose_concentration_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% triamcinolone Slatore_2009::serum_glucose_concentration: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg per second, in SI inside (kg/m3, s). Response serum glucose concentration in mg/dL. Driver: triamcinolone (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.018199999999999997;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
