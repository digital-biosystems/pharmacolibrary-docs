model Triamcinolone_Slatore2009_PD_serum_glucose_concentration
  "linear exposure-response sweep — Slatore_2009 :: serum glucose concentration (serum glucose concentration)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 0.0182,  // [kilogram / meter ** 3; mg/dL × 0.01]
    exposure_per_s = 1e-09);   // 1 microg per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Triamcinolone_Slatore2009_PD_serum_glucose_concentration</h4><p>The steady-state exposure-response curve of Slatore CG et al., <i>The American journal of medicine 122(5):472–478</i> 2009 (<a href=\"https://doi.org/10.1016/j.amjmed.2008.09.048\">doi:10.1016/j.amjmed.2008.09.048</a>) — serum glucose concentration [mg/dL] against triamcinolone microg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       1.82 mg/dL    change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one microg of triamcinolone per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Triamcinolone_Slatore2009_PD_serum_glucose_concentration;
