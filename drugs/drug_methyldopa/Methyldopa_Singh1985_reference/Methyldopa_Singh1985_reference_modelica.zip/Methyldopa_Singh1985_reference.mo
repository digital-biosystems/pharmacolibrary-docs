model Methyldopa_Singh1985_reference
  parameter Real Cl_ref = 1.025e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.112 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21121700000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methyldopa</h4><p>Methyldopa is a centrally acting antihypertensive drug used to treat high blood pressure. It is an approved medicine and is included on the WHO list of essential medicines, so it remains in use worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412621\">Wikidata Q412621</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methyldopa</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Singh_1985</td></tr><tr><td>measured_compound:</td><td>methyldopa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>methyldopa 211.217 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Singh_1985) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methyldopa_Singh1985_reference;
