// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Radium226_Arazi2010_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {319680.0},
    MM = 0.209216,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>radium_226</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Arazi_2010</td></tr><tr><td>measured_compound:</td><td>Lead-212</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Bismuth-212 208.98 g/mol (pubchem); Lead-212 209.216 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q57 ('3.7 days of half-life of 224 Ra'=3.7) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Lead-212</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 6 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'Polonium-216' ('Polonium-216') — left in mass units</li><li>molar mass: none found for 'Polonium-216' — its concentrations stay mass-only</li><li>review gap-fill skipped: this record measures 'Lead-212', not radium_226 — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1641600, Tolerance = 1e-9, Interval = 3283.2));
end Radium226_Arazi2010_reference;
