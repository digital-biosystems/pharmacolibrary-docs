// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Radium226_Donaher2023_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {38389.69000024313},
    MM = 0.226,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>radium_226</td></tr><tr><td>population:</td><td>Geukensia demissa</td></tr><tr><td>source_paper:</td><td>Donaher_2023</td></tr><tr><td>measured_compound:</td><td>Radium-226</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Radium-226 226 g/mol (pubchem); radium_226 226 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped 'average uptake rate constant' → Q349: a water-uptake rate in 'mL g-1 d-1' (bioaccumulation from the medium), not a body toxicokinetic parameter</li><li>dropped unlinked row (NIL): 'tissue-specific bioconcentration factors (BCFs)' — extend the ontology if this is a real PK parameter (source ['Donaher_2023:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Radium-226</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Radium226_Donaher2023_reference;
