function p = Radium226_Lundell1999_PD_breast_cancer_risk_params()
% Radium226_Lundell1999_PD_breast_cancer_risk_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% radium_226 Lundell_1999::breast_cancer_risk: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Gy per second, in SI inside (kg/m3, s). Response breast cancer risk in its own unit. Driver: radium_226 (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.35;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
