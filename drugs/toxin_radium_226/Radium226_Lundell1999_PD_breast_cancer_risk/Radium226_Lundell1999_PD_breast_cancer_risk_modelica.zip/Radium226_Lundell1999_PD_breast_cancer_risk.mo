model Radium226_Lundell1999_PD_breast_cancer_risk
  "linear exposure-response sweep — Lundell_1999 :: breast cancer risk (breast cancer risk)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.35   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Radium226_Lundell1999_PD_breast_cancer_risk</h4><p>The steady-state exposure-response curve of Lundell M et al., <i>Radiation research 151(5):626–632</i> 1999 — breast cancer risk against radium_226 Gy — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.35          change in response per unit of exposure (excess relative risk per gray, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one Gy of radium_226 per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Radium226_Lundell1999_PD_breast_cancer_risk;
