% Run (SimBiology): build model + dose, simulate 0..312.0 h, plot.
p = Cadmium_Sunnker2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 312.0);
