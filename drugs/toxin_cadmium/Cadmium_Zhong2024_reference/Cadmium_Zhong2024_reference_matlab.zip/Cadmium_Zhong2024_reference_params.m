function p = Cadmium_Zhong2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cadmium   source: Zhong_2024 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Cadmium_Zhong2024_reference_params';
  p.drug  = 'cadmium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.6;                % central volume [L]
  p.CL = 22.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.235;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
