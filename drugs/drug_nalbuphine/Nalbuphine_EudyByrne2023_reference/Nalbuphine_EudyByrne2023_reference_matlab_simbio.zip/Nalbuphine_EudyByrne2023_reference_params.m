function p = Nalbuphine_EudyByrne2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Eudy-Byrne_2023 / reference   route: oral
  p.name  = 'Nalbuphine_EudyByrne2023_reference_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2570.0;                % central volume [L]
  p.CL = 573.0;                % clearance [L/h]
  p.Vp = [4820.0];             % peripheral volumes [L]
  p.Q  = [106.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.826;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 27.0;             % dose [mg]
end
