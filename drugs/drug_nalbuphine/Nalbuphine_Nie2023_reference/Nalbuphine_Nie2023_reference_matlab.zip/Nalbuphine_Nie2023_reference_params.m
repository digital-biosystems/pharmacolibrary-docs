function p = Nalbuphine_Nie2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Nie_2023 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Nalbuphine_Nie2023_reference_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 32.5;                % central volume [L]
  p.CL = 33.42;                % clearance [L/h]
  p.Vp = [83.5];             % peripheral volumes [L]
  p.Q  = [245.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
