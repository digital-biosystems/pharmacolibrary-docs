model Mitomycin_den1983_reference
  parameter Real Cl_ref = 5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3343272,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mitomycin</h4><p>Mitomycin is a cytotoxic antibiotic chemotherapy drug used to treat various cancers, including bladder cancer, and glaucoma. It is administered intravenously or intravesically, typically as an injection or solution prepared from powder. The drug is approved for use and also has investigational applications.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q19856779\">Wikidata Q19856779</a>, <a href=\"https://en.wikipedia.org/wiki/Mitomycin_C?oldid=1375996590\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitomycin</td></tr><tr><td>population:</td><td>cancer patients</td></tr><tr><td>source_paper:</td><td>den_1983</td></tr><tr><td>measured_compound:</td><td>mitomycin C</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mitomycin 334.327 g/mol (drugbank); mitomycin C 334.327 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'The detection limit' — extend the ontology if this is a real PK parameter (source ['den_1983:abstract'])</li><li>unit_dimension_unknown: 'liters/sq m' (V)</li><li>unit_dimension_unknown: 'liters/hr/sq m' (CL)</li><li>implicit units: 'The volume of distribution' → L (from the popPK convention: 'Volumes of distribution are conventionally expressed in liters (L), and a value of 22 is consistent with this magnitude.')</li><li>implicit units: 'total body clearance' → L/h (from the popPK convention: 'Total clearance is conventionally expressed in liters per hour (L/h) in population PK modeling, and a value of 18 is con')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mitomycin C</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mitomycin_den1983_reference;
