function p = Propylthiouracil_Kampmann1981_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propylthiouracil   source: Kampmann_1981 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Propylthiouracil_Kampmann1981_reference_params';
  p.drug  = 'propylthiouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 40.0;                % central volume [L]
  p.CL = 12.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.95;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
