model Propylthiouracil_Kampmann1981_reference
  parameter Real Cl_ref = 3.333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17023,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propylthiouracil</td></tr><tr><td>population:</td><td>patients with thyrotoxicosis</td></tr><tr><td>source_paper:</td><td>Kampmann_1981</td></tr><tr><td>measured_compound:</td><td>Propylthiouracil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propylthiouracil 170.23 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'propylthiouracil ... protein-bound' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q57 ('Propylthiouracil ... half-life', value None) — already have one for this compound</li><li>dropped duplicate Q22 ('Propylthiouracil ... clearance', value 120) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life', value '4') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propylthiouracil</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propylthiouracil_Kampmann1981_reference;
