function p = Propylthiouracil_Shen2022_elderly_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propylthiouracil   source: Shen_2022 / elderly   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Propylthiouracil_Shen2022_elderly_params';
  p.drug  = 'propylthiouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.526261;                % central volume [L]
  p.CL = 45.12369;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
