model Propylthiouracil_Shen2022_adult
  parameter Real Cl_ref = 1.2534358333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.000526261 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17023,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propylthiouracil</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Shen_2022</td></tr><tr><td>measured_compound:</td><td>Propylthiouracil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T7</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propylthiouracil 170.23 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'AUC0-t (ng*h/mL)'; source reconciliation required</li><li>table representations disagree for '0.95'; source reconciliation required</li><li>table representations disagree for '1185.04'; source reconciliation required</li><li>dropped unlinked row (NIL): '0.95' — extend the ontology if this is a real PK parameter (source ['T7:row2:col2'])</li><li>dropped unlinked row (NIL): '1185.04' — extend the ontology if this is a real PK parameter (source ['T7:row3:col2'])</li><li>dropped value-less row: 'Pharmacokinetic parameters of 50 mg or 4 mg/kg PTU orally in healthy elderly and pediatric populations.'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Propylthiouracil</li><li>status held at route_to_review — not promoted</li><li>population split: 'adult' subgroup of Shen_2022 (paper reports 5 populations: adult, children, elderly, infant, term infant)</li><li>gap-filled Q22 (CL) from Marati_2025's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Marati_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Marati_2025 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propylthiouracil_Shen2022_adult;
