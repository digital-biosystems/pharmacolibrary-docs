model Propylthiouracil_Giles1981_reference
  parameter Real Cl_ref = 4.558333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.028 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17023,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propylthiouracil</td></tr><tr><td>population:</td><td>10 healthy, male volunteers</td></tr><tr><td>source_paper:</td><td>Giles_1981</td></tr><tr><td>measured_compound:</td><td>Propylthiouracil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>propylthiouracil 170.23 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q900 ('y', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): 'r' — extend the ontology if this is a real PK parameter (source ['Giles_1981:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Propylthiouracil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propylthiouracil_Giles1981_reference;
