function p = Cotinine_Brunst2012_PD_pef_params()
% Cotinine_Brunst2012_PD_pef_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cotinine Brunst_2012::PEF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response PEF in l/s. Driver: cotinine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -7.000000000000002e-05;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
