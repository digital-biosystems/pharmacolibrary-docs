// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cotinine_Dempsey2013_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {64439.99999999999},
    MM = 0.176219,
    adminMass = 3.5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cotinine</td></tr><tr><td>population:</td><td>Infants and Children (2 to 84 months)</td></tr><tr><td>source_paper:</td><td>Dempsey_2013</td></tr><tr><td>measured_compound:</td><td>cotinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>cotinine 176.219 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>substance matrix Dempsey_2013_table_3 ('Table 3. Half-Life Estimates by Sex, Race and Age'): no row names this substance — its 12 row(s) (All subjects, Sex Male, Female, White#, Black, Mixed, < 1 year old (y.o.), 1–1.9 y.o.) are other substances' values; none taken</li><li>substance matrix Dempsey_2013_table_4 ('Table 4 Half-Life Estimates by Genotype Activity'): no row names this substance — its 7 row(s) (Normal (*1/*1), Intermediate (*1/*9), Slow# (*1/*17, *1/*2, *1/*20, *9/*9, 17/*17), Intermediate/Slow#, Unknown, Normal vs. Intermediate vs Slow vs. Unknown, Normal vs. Intermediate/Slow vs. Unknown) are other substances' values; none taken</li><li>salvaged Q57 ('The estimate of the typical value of the half-life of cotinine,'=17.9) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cotinine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Cotinine_Dempsey2013_reference;
