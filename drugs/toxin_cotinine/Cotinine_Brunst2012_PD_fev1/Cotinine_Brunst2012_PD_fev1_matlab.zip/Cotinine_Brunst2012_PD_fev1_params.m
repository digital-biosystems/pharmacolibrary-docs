function p = Cotinine_Brunst2012_PD_fev1_params()
% Cotinine_Brunst2012_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cotinine Brunst_2012::FEV1: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response FEV1 in l. Driver: cotinine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -3.0000000000000008e-05;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
