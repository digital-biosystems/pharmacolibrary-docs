model Cotinine_Brunst2012_PD_fev1
  "linear exposure-response sweep — Brunst_2012 :: FEV1 (FEV(1))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -3e-05   "[meter ** 3; l × 0.001]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Cotinine_Brunst2012_PD_fev1</h4><p>The steady-state exposure-response curve of Brunst KJ et al., <i>Pediatric allergy and immunology : official publication of the European Society of Pediatric Allergy and Immunology 23(5):479–487</i> 2012 (<a href=\"https://doi.org/10.1111/j.1399-3038.2012.01292.x\">doi:10.1111/j.1399-3038.2012.01292.x</a>) — FEV(1) [l] against cotinine — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -0.03 l        change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of cotinine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Cotinine_Brunst2012_PD_fev1;
