// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Cotinine_Kovar2020_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {57600.0},
    MM = 0.176219,
    adminMass = 2e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cotinine</td></tr><tr><td>population:</td><td>healthy non-smoking and smoking adults</td></tr><tr><td>source_paper:</td><td>Kovar_2020</td></tr><tr><td>measured_compound:</td><td>Cotinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Cotinine 176.219 g/mol (pubchem); Nicotine 162.236 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'nicotine model: literature value [ref]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'amp' — extend the ontology if this is a real PK parameter (source ['Kovar_2020_table_2:row5:col2', 'Kovar_2020_table_2:row5:col3'])</li><li>salvaged Q57 ('half-life'=16) from results prose — parameter table was unreadable</li><li>salvaged Q47 ('Unspecific hepatic clearance'=0.3) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Cotinine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=pbpk; 1/1 row label(s) assigned, 0 linked by role; re-tagged Nicotine→parent ×2</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 691.2));
end Cotinine_Kovar2020_reference;
