model Pseudoephedrine_Palamanda2010_reference
  parameter Real Cl_ref = 9.1e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.21 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1652322,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pseudoephedrine</h4><p>Pseudoephedrine is a sympathomimetic decongestant used to treat nasal congestion, sinusitis, and asthma. It is administered orally in forms such as tablets and syrups. The drug is widely available over-the-counter, though its availability has been restricted due to its potential use in illicit drug synthesis.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q263958\">Wikidata Q263958</a>, <a href=\"https://en.wikipedia.org/wiki/Pseudoephedrine?oldid=1378286228\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pseudoephedrine</td></tr><tr><td>population:</td><td>rats, dogs, monkeys, and cats</td></tr><tr><td>source_paper:</td><td>Palamanda_2010</td></tr><tr><td>measured_compound:</td><td>pseudoephedrine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pseudoephedrine 165.232 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'LLOQ' — extend the ontology if this is a real PK parameter (source ['Palamanda_2010:abstract'])</li><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Palamanda_2010:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pseudoephedrine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pseudoephedrine_Palamanda2010_reference;
