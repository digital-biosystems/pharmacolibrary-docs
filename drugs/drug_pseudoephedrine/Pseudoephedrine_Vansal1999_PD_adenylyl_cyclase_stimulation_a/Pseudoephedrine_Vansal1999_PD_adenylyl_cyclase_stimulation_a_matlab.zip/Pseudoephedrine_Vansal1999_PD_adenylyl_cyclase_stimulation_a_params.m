function p = Pseudoephedrine_Vansal1999_PD_adenylyl_cyclase_stimulation_a_params()
% Pseudoephedrine_Vansal1999_PD_adenylyl_cyclase_stimulation_a_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pseudoephedrine Vansal_1999::adenylyl_cyclase_stimulation_associated_with_cyclic_AMP_accumulations: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microM per second, in SI inside (kg/m3, s). Response adenylyl cyclase stimulation associated with cyclic AMP accumulations in its own unit. Driver: 1S,2S-pseudoephedrine (not_resolved).
p.E0 = 0.0;
p.Emax = 0.53;
p.EC50 = 309.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3100.0;
p.form = 'E0 + Emax*frac';
end
