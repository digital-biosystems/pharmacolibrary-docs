model Pseudoephedrine_Vansal1999_PD_adenylyl_cyclase_stimulation_a
  "sigmoid_emax exposure-response sweep — Vansal_1999 :: adenylyl cyclase stimulation associated with cyclic AMP accumulations (adenylyl cyclase stimulation associated with cyclic AMP accumulations)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.53,  // [1; % × 0.01]
    EC50 = 309,  // [microM]
    gamma = 1,
    exposure_per_s = 1);   // 1 microM per second
  // exposure_unit_unresolved: 'microM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3100, Interval = 6.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pseudoephedrine</h4><p>Pseudoephedrine is a sympathomimetic decongestant used to treat nasal congestion, sinusitis, and asthma. It is administered orally in forms such as tablets and syrups. The drug is widely available over-the-counter, though its availability has been restricted due to its potential use in illicit drug synthesis.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q263958\">Wikidata Q263958</a>, <a href=\"https://en.wikipedia.org/wiki/Pseudoephedrine?oldid=1378286228\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pseudoephedrine_Vansal1999_PD_adenylyl_cyclase_stimulation_a</h4><p>The steady-state exposure-response curve of Vansal SS et al., <i>Biochemical pharmacology 58(5):807–810</i> 1999 (<a href=\"https://doi.org/10.1016/s0006-2952(99)00152-5\">doi:10.1016/s0006-2952(99)00152-5</a>) — adenylyl cyclase stimulation associated with cyclic AMP accumulations against 1S,2S-pseudoephedrine microM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         53 %        maximal effect term (maximal response relative to isoproterenol, Q320)
  EC50  =        309 microM   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microM of 1S,2S-pseudoephedrine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (309 microM)  response 0.265
  exposure -> infinity  response 0.53</pre></body></html>"));
end Pseudoephedrine_Vansal1999_PD_adenylyl_cyclase_stimulation_a;
