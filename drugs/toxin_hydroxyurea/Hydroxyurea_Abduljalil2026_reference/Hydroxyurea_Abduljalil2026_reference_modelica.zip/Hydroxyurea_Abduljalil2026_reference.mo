model Hydroxyurea_Abduljalil2026_reference
  parameter Real Cl_ref = 1.5555555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0453 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.07605500000000001,
    adminMass = 0.00105,
    ka = 0.0006944444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxyurea</td></tr><tr><td>population:</td><td>Patients with Sickle Cell Disease (adults, paediatrics, lactating women) and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Abduljalil_2026</td></tr><tr><td>measured_compound:</td><td>Hydroxyurea</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-19-00220-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxyurea 76.055 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'AUCinf (h·mg/L) / Obs.'; source reconciliation required</li><li>table representations disagree for 'AUCinf (h·mg/L) / Pred.'; source reconciliation required</li><li>table representations disagree for 'AUCinf (h·mg/L) / P/O'; source reconciliation required</li><li>table representations disagree for 'Cmax (mg/L) / Obs.'; source reconciliation required</li><li>table representations disagree for 'Cmax (mg/L) / Pred.'; source reconciliation required</li><li>table representations disagree for 'Cmax (mg/L) / P/O'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / Obs.'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / Pred.'; source reconciliation required</li><li>table representations disagree for 'CL (L/h) / P/O'; source reconciliation required</li><li>table representations disagree for 'Tmax (h) / Obs.'; source reconciliation required</li><li>table representations disagree for 'Tmax (h) / Pred.'; source reconciliation required</li><li>table representations disagree for 'Tmax (h) / P/O'; source reconciliation required</li><li>table representations disagree for 'AUCinf (h·mg/L) / Obs.'; source reconciliation required</li><li>table representations disagree for 'AUCinf (h·mg/L) / Pred.'; source reconciliation required</li><li>table representations disagree for 'AUCinf (h·mg/L) / P/O'; source reconciliation required</li><li>table representations disagree for 'Cmax (mg/L) / Obs.'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Hydroxyurea_Abduljalil2026_reference;
