function p = Hydroxyurea_Abduljalil2026_2_g_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxyurea   source: Abduljalil_2026 / 2_g   route: oral
  % estimated (absent from source): F
  p.name  = 'Hydroxyurea_Abduljalil2026_2_g_params';
  p.drug  = 'hydroxyurea';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.3;                % central volume [L]
  p.CL = 1.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
