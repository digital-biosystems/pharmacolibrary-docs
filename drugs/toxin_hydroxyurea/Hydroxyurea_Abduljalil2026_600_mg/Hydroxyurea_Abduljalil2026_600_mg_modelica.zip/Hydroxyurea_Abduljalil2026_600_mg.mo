model Hydroxyurea_Abduljalil2026_600_mg
  parameter Real Cl_ref = 3.055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0453 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.07605500000000001,
    adminMass = 0.00105,
    ka = 0.0006944444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxyurea</td></tr><tr><td>population:</td><td>Patients with Sickle Cell Disease (adults, paediatrics, lactating women) and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Abduljalil_2026</td></tr><tr><td>measured_compound:</td><td>Hydroxyurea</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-19-00220-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxyurea 76.055 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Scheme' — extend the ontology if this is a real PK parameter (source ['Abduljalil_2026_table_5:row6:col1', 'Abduljalil_2026_table_5:row7:col1', 'Abduljalil_2026_table_5:row8:col1'])</li><li>dropped unlinked row (NIL): 'Oral Dose' — extend the ontology if this is a real PK parameter (source ['Abduljalil_2026_table_5:row6:col2', 'Abduljalil_2026_table_5:row7:col2', 'Abduljalil_2026_table_5:row8:col2'])</li><li>dropped duplicate Q17 ('AUCinf (h·mg/L) / Pred.', value '16.2') — already have one for this compound</li><li>dropped duplicate Q17 ('AUCinf (h·mg/L) / P/O', value '13.0') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (mg/L) / Pred.', value '8.6') — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax (mg/L) / P/O', value '9.4') — already have one for this compound</li><li>dropped duplicate Q22 ('CLpo (L/h) / P/O', value '49.4') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Hydroxyurea</li><li>population split: '600 mg' subgroup of Abduljalil_2026 (paper reports 2 populations: 2 g, 600 mg)</li><li>gap-filled Q61 (V) from Hosawi_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Hosawi_2026's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — clearance/elimination from this paper; review-gap-filled from other paper(s): Hosawi_2026 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Hydroxyurea_Abduljalil2026_600_mg;
