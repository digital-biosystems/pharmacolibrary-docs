model Hydroxyurea_Sabo2026_paule_et_al_13
  parameter Real Cl_ref = 3.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.052000000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.07605500000000001,
    adminMass = 0.00105,
    ka = 0.0008388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxyurea</td></tr><tr><td>population:</td><td>patients with sickle cell disease (pediatric and adult)</td></tr><tr><td>source_paper:</td><td>Sabo_2026</td></tr><tr><td>measured_compound:</td><td>Hydroxyurea</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00654-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxyurea 76.055 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'paule et al. (2011) [13]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'paule et al. (2011) [13]' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Hydroxyurea</li><li>population split: 'paule et al. (2011) [13]' subgroup of Sabo_2026 (paper reports 3 populations: paule et al. (2011) [13], present model, wiczling et al. (2014) [9])</li><li>gap-filled Q76 (V/F) from Sabo_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxyurea_Sabo2026_paule_et_al_13;
