function p = Hydroxyurea_Sabo2026_paule_et_al_13_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxyurea   source: Sabo_2026 / paule_et_al_13   route: oral
  p.name  = 'Hydroxyurea_Sabo2026_paule_et_al_13_params';
  p.drug  = 'hydroxyurea';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 52.0;                % central volume [L]
  p.CL = 11.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.02;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
