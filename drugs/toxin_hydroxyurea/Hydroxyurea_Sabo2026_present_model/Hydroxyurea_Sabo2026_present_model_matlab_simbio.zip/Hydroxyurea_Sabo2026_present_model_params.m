function p = Hydroxyurea_Sabo2026_present_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxyurea   source: Sabo_2026 / present_model   route: oral
  p.name  = 'Hydroxyurea_Sabo2026_present_model_params';
  p.drug  = 'hydroxyurea';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.2;                % central volume [L]
  p.CL = 9.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.36;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
