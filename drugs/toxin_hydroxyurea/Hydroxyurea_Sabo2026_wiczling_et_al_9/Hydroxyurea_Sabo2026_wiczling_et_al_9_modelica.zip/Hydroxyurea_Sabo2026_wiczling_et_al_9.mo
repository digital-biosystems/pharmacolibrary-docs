model Hydroxyurea_Sabo2026_wiczling_et_al_9
  parameter Real Cl_ref = 1.9111111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0218 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.07605500000000001,
    adminMass = 0.00105,
    ka = 0.0006944444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxyurea</td></tr><tr><td>population:</td><td>patients with sickle cell disease (pediatric and adult)</td></tr><tr><td>source_paper:</td><td>Sabo_2026</td></tr><tr><td>measured_compound:</td><td>Hydroxyurea</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00654-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxyurea 76.055 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Hydroxyurea</li><li>population split: 'wiczling et al. (2014) [9]' subgroup of Sabo_2026 (paper reports 3 populations: paule et al. (2011) [13], present model, wiczling et al. (2014) [9])</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Hosawi_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxyurea_Sabo2026_wiczling_et_al_9;
