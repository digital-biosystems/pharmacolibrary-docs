% Run: build params, simulate 0..24.0 h, plot + save Hydroxyurea_Sabo2026_wiczling_et_al_9.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Hydroxyurea_Sabo2026_wiczling_et_al_9.m
here = fileparts(mfilename('fullpath'));
p = Hydroxyurea_Sabo2026_wiczling_et_al_9_params();
out = simulate_pk(p, 0:0.05:24.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('hydroxyurea — Sabo_2026 (oral)');
print(fig, fullfile(here, 'Hydroxyurea_Sabo2026_wiczling_et_al_9.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Hydroxyurea_Sabo2026_wiczling_et_al_9.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Hydroxyurea_Sabo2026_wiczling_et_al_9.json'), 'w');
try
  s.model = 'Hydroxyurea_Sabo2026_wiczling_et_al_9'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Hydroxyurea_Sabo2026_wiczling_et_al_9","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Hydroxyurea_Sabo2026_wiczling_et_al_9.png, Hydroxyurea_Sabo2026_wiczling_et_al_9.csv, Hydroxyurea_Sabo2026_wiczling_et_al_9.json\n');
