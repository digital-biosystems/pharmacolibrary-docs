function p = Hydroxyurea_Sabo2026_wiczling_et_al_9_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxyurea   source: Sabo_2026 / wiczling_et_al_9   route: oral
  p.name  = 'Hydroxyurea_Sabo2026_wiczling_et_al_9_params';
  p.drug  = 'hydroxyurea';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.8;                % central volume [L]
  p.CL = 6.88;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1050.0;             % dose [mg]
end
