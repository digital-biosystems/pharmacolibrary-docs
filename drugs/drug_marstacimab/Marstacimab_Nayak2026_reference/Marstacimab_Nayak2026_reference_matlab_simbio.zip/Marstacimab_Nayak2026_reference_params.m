function p = Marstacimab_Nayak2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: marstacimab   source: Nayak_2026 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Marstacimab_Nayak2026_reference_params';
  p.drug  = 'marstacimab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.61;                % central volume [L]
  p.CL = 0.0188;                % clearance [L/h]
  p.Vp = [4.99];             % peripheral volumes [L]
  p.Q  = [0.00489];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 2.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
