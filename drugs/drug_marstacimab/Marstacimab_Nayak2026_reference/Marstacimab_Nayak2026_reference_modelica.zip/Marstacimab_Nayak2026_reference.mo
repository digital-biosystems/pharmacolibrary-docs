model Marstacimab_Nayak2026_reference
  parameter Real Cl_ref = 5.222222222222222e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00361 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 3.7626962142197606e-07,
    k21 = 2.7221108884435537e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>marstacimab</td></tr><tr><td>population:</td><td>adolescent and adult participants with hemophilia and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Nayak_2026</td></tr><tr><td>measured_compound:</td><td>marstacimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_6</td></tr><tr><td>input:</td><td>PK_3C: IV (no input phase)</td></tr></table><p><b>Defaulted (base-class default used):</b> k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameter'</li><li>dropped PD-category row 'Baseline peak TGA, P BASE (nM) 37.8' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_6:row3:col1', 'tab_6:row3:col2', 'tab_6:row3:col3', 'tab_6:row3:col4'])</li><li>dropped PD-category row 'EC 50 (nM)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_6:row4:col1', 'tab_6:row4:col3', 'tab_6:row4:col4'])</li><li>dropped PD-category row 'Hill coefficient (fixed)' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_6:row6:col1', 'tab_6:row6:col2', 'tab_6:row6:col3', 'tab_6:row6:col4', 'tab_6:row6:col5'])</li><li>salvaged Q63 ('V c (L)'=3.61) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('-CL (L/h)'=0.0188) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('-Lag time (h)'=2) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V p'=4.99) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('total volume of distribution'=8.6) from results prose — parameter table was unreadable</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (V c (L)); Q22 (-CL (L/h)); Q64 (V p); Q61 (total volume of distribution)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=marstacimab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 3C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q30 (Q) from Nayak_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Marstacimab_Nayak2026_reference;
