// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Entacapone_Rouru1999_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {4680.0},
    MM = 0.30529,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>entacapone</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Rouru_1999</td></tr><tr><td>measured_compound:</td><td>Entacapone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>entacapone 305.29 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('t1/2 of entacapone (day 6)', value 1.8) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 of levodopa (days 1-2)', value 2.4) — already have one for this compound</li><li>dropped duplicate Q57 ('t1/2 of levodopa (days 6-7)', value 2.3) — already have one for this compound</li><li>dropped duplicate Q56 ('tmax of levodopa (day 6)', value 1.2) — already have one for this compound</li><li>unit_dimension_unknown: 'tmax, day 1 vs day 6, levodopa' (tmax_ratio)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Entacapone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Entacapone_Rouru1999_reference;
