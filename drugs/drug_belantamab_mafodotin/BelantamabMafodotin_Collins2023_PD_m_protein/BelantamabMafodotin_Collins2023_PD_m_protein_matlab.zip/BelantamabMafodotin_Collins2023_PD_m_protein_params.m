function p = BelantamabMafodotin_Collins2023_PD_m_protein_params()
% BelantamabMafodotin_Collins2023_PD_m_protein_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% belantamab_mafodotin Collins_2023::M_protein: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response M-protein in its own unit. Driver: belantamab mafodotin (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 619.0000000000001;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
