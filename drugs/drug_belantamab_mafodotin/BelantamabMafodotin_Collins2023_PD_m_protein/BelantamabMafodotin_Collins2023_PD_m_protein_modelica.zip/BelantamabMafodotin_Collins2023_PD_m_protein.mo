model BelantamabMafodotin_Collins2023_PD_m_protein
  "linear exposure-response sweep — Collins_2023 :: M-protein (serum M-protein concentration)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 619   "[meter ** 3 / kilogram; ml/μg × 1000]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About belantamab_mafodotin</h4><p>Belantamab mafodotin, a monoclonal antibody drug conjugate, was used to treat multiple myeloma. It is no longer in use: its marketing authorisation in the European Union has expired, and it is listed as withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q98139657\">Wikidata Q98139657</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>BelantamabMafodotin_Collins2023_PD_m_protein</h4><p>The steady-state exposure-response curve of Collins J et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(10):1411–1424</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.13016\">doi:10.1002/psp4.13016</a>) — serum M-protein concentration against belantamab mafodotin — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.619 ml/μg    change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of belantamab mafodotin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end BelantamabMafodotin_Collins2023_PD_m_protein;
