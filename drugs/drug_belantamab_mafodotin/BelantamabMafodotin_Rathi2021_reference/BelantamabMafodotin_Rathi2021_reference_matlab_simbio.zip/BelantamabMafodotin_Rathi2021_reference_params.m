function p = BelantamabMafodotin_Rathi2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: belantamab_mafodotin   source: Rathi_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'BelantamabMafodotin_Rathi2021_reference_params';
  p.drug  = 'belantamab_mafodotin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.47;                % central volume [L]
  p.CL = 0.039167;                % clearance [L/h]
  p.Vp = [5.96];             % peripheral volumes [L]
  p.Q  = [0.0325];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.1;             % dose [mg]
end
