% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = MaleicAcid_Hou2016_10_mg_kg_i_v_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
