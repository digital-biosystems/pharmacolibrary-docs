function p = MaleicAcid_Hou2016_10_mg_kg_i_v_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: maleic_acid   source: Hou_2016 / 10_mg_kg_i_v   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'MaleicAcid_Hou2016_10_mg_kg_i_v_params';
  p.drug  = 'maleic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 68.25;                % central volume [L]
  p.CL = 115.08;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
