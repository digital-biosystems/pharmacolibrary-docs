model MaleicAcid_Hou2016_30_mg_kg_i_v
  parameter Real Cl_ref = 2.9516666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0735 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.11607200000000001,
    adminMass = 0.0007
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>maleic_acid</td></tr><tr><td>population:</td><td>rat</td></tr><tr><td>source_paper:</td><td>Hou_2016</td></tr><tr><td>measured_compound:</td><td>Maleic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>molecules-21-00367-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Maleic acid 116.072 g/mol (pubchem); maleic_acid 116.072 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'AUC (min∙µg/mL)'; source reconciliation required</li><li>table representations disagree for 'Cmax (µg/mL)'; source reconciliation required</li><li>table representations disagree for 'T1/2 (min)'; source reconciliation required</li><li>table representations disagree for 'CL (mL/min/kg)'; source reconciliation required</li><li>table representations disagree for 'MRT (min)'; source reconciliation required</li><li>table representations disagree for 'Vd (mL/kg)'; source reconciliation required</li><li>table representations disagree for 'AUC/Dose'; source reconciliation required</li><li>table representations disagree for 'AUC ratio of (AUCkidney/AUCblood)'; source reconciliation required</li><li>unit_dimension_unknown: 'AUCkidney/AUCblood' (AUC ratio)</li><li>implicit units: 'AUC/Dose' — the LLM proposed 'h/kg', whose dimension does not fit Q189; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Maleic acid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: '30 mg/kg, i.v.' subgroup of Hou_2016 (paper reports 2 populations: 10 mg/kg, i.v., 30 mg/kg, i.v.)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MaleicAcid_Hou2016_30_mg_kg_i_v;
