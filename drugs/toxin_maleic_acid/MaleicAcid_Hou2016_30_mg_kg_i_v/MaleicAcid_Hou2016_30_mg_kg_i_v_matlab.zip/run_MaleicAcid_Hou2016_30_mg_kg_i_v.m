% Run: build params, simulate 0..24.0 h, plot + save MaleicAcid_Hou2016_30_mg_kg_i_v.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_MaleicAcid_Hou2016_30_mg_kg_i_v.m
here = fileparts(mfilename('fullpath'));
p = MaleicAcid_Hou2016_30_mg_kg_i_v_params();
out = simulate_pk(p, 0:0.05:24.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('maleic_acid — Hou_2016 (iv_bolus)');
print(fig, fullfile(here, 'MaleicAcid_Hou2016_30_mg_kg_i_v.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'MaleicAcid_Hou2016_30_mg_kg_i_v.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'MaleicAcid_Hou2016_30_mg_kg_i_v.json'), 'w');
try
  s.model = 'MaleicAcid_Hou2016_30_mg_kg_i_v'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"MaleicAcid_Hou2016_30_mg_kg_i_v","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote MaleicAcid_Hou2016_30_mg_kg_i_v.png, MaleicAcid_Hou2016_30_mg_kg_i_v.csv, MaleicAcid_Hou2016_30_mg_kg_i_v.json\n');
