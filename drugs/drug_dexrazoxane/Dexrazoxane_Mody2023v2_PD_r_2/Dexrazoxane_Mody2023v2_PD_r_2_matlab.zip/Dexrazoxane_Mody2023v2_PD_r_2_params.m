function p = Dexrazoxane_Mody2023v2_PD_r_2_params()
% Dexrazoxane_Mody2023v2_PD_r_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexrazoxane Mody_2023_2::R::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response R in %. Driver: dexrazoxane (cited_pk).
p.E0 = 0.0;
p.Emax = -1.736111111111111e-05;
p.EC50 = 39.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 390.0;
p.form = 'E0 + Emax*frac';
end
