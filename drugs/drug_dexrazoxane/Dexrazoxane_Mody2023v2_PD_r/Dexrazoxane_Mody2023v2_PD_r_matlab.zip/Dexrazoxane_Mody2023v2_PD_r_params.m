function p = Dexrazoxane_Mody2023v2_PD_r_params()
% Dexrazoxane_Mody2023v2_PD_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexrazoxane Mody_2023_2::R: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response R in %. Driver: dexrazoxane (cited_pk).
p.E0 = 1.01;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 9680.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
