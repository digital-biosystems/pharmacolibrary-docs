model Dexrazoxane_Mody2023v2_PD_r
  "linear exposure-response sweep — Mody_2023_2 :: R (AC16 cell viability)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.01,      // [1; % × 0.01]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 9680   "[1 / meter; µM−1 × 1e+06]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dexrazoxane</h4><p>Dexrazoxane is a detoxifying agent used to protect against tissue damage from anthracycline chemotherapy, notably in breast cancer patients, and to treat extravasation of certain drugs. It remains authorised in the European Union, though its approved status has been accompanied by investigational uses and some withdrawn indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q524995\">Wikidata Q524995</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dexrazoxane_Mody2023v2_PD_r</h4><p>The steady-state exposure-response curve of Mody H et al., <i>Scientific reports 13(1):3100</i> 2023 (<a href=\"https://doi.org/10.1038/s41598-023-29964-4\">doi:10.1038/s41598-023-29964-4</a>) — AC16 cell viability [%] against dexrazoxane µM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        101 %        drug-free response (baseline) (R0, Q324)
  slope =    0.00968 µM−1     change in response per unit of exposure (SDEX, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µM of dexrazoxane per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.01   (drug-free)</pre></body></html>"));
end Dexrazoxane_Mody2023v2_PD_r;
