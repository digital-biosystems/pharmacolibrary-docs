function p = Adenosine_Yu2018_ade_lncs_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: adenosine   source: Yu_2018 / ade_lncs   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Adenosine_Yu2018_ade_lncs_params';
  p.drug  = 'adenosine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3115.0;                % central volume [L]
  p.CL = 868.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
