function p = Adenosine_Yu2018_free_ade_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: adenosine   source: Yu_2018 / free_ade   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Adenosine_Yu2018_free_ade_params';
  p.drug  = 'adenosine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 392.0;                % central volume [L]
  p.CL = 112.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
