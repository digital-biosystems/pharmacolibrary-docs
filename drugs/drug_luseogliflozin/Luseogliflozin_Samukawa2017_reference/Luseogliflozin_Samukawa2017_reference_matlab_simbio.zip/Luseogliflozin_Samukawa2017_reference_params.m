function p = Luseogliflozin_Samukawa2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: luseogliflozin   source: Samukawa_2017 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Luseogliflozin_Samukawa2017_reference_params';
  p.drug  = 'luseogliflozin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.1;                % central volume [L]
  p.CL = 2.78;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 20.3;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
