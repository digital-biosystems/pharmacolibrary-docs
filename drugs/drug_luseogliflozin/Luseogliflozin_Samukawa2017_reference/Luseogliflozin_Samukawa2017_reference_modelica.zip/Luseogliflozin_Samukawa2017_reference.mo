model Luseogliflozin_Samukawa2017_reference
  parameter Real Cl_ref = 7.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0056388888888888895,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>luseogliflozin</td></tr><tr><td>population:</td><td>Japanese patients with type 2 diabetes mellitus</td></tr><tr><td>source_paper:</td><td>Samukawa_2017</td></tr><tr><td>measured_compound:</td><td>luseogliflozin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('oral clearance'=2.78) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution of central compartment'=21.1) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('inter-compartmental clearance'=3.69) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('absorption rate constant'=20.3) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=luseogliflozin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Luseogliflozin_Samukawa2017_reference;
