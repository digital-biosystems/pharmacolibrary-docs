function p = Belzutifan_Marathe2023_arithmetic_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: belzutifan   source: Marathe_2023 / arithmetic_mean   route: oral
  p.name  = 'Belzutifan_Marathe2023_arithmetic_mean_params';
  p.drug  = 'belzutifan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 137.62;                % central volume [L]
  p.CL = 8.15;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
