function p = Belzutifan_Marathe2023_geometric_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: belzutifan   source: Marathe_2023 / geometric_mean   route: oral
  p.name  = 'Belzutifan_Marathe2023_geometric_mean_params';
  p.drug  = 'belzutifan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 129.5;                % central volume [L]
  p.CL = 7.25;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.51;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
