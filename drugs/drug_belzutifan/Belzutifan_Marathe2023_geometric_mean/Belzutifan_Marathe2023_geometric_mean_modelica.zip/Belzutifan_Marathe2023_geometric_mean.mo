model Belzutifan_Marathe2023_geometric_mean
  parameter Real Cl_ref = 2.013888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1295 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38333999999999996,
    adminMass = 0.00012,
    ka = 0.0006972222222222221,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About belzutifan</h4><p>Belzutifan is an anticancer medicine used to treat von Hippel-Lindau disease, including kidney cancer associated with it. It is authorised in the European Union and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27456641\">Wikidata Q27456641</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>belzutifan</td></tr><tr><td>population:</td><td>patients with VHL disease-associated RCC, CNS hemangioblastomas, and pancreatic neuroendocrine tumors</td></tr><tr><td>source_paper:</td><td>Marathe_2023</td></tr><tr><td>measured_compound:</td><td>belzutifan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413028-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>belzutifan 383.34 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'FMF' — extend the ontology if this is a real PK parameter (source ['Marathe_2023_table_5:row3:col2', 'Marathe_2023_table_5:row3:col3', 'Marathe_2023_table_5:row6:col2', 'Marathe_2023_table_5:row6:col3', 'Marathe_2023_table_5:row8:col2', 'Marathe_2023_table_5:row8:col3', 'Marathe_2023_table_5:row10:col2', 'Marathe_2023_table_5:row10:col3', 'Marathe_2023_table_5:row15:col2', 'Marathe_2023_table_5:row15:col3'])</li><li>dropped duplicate Q57 ('t 1/2 abs (h)', value '0.28') — already have one for this compound</li><li>implicit units: 'KA (1/h)' → 1/h (from the popPK convention: 'The parameter is the absorption rate constant (KA). In population pharmacokinetic modeling, first-order rate constants a')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=belzutifan</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>bound model equation to Q40 (Fab): F = CL/Fpop * (WT/73.64)^</li><li>Q40 (Fab) is equation-defined: value moved to equation-variable 'F'; equation kept verbatim</li><li>population split: 'geometric mean' subgroup of Marathe_2023 (paper reports 4 populations: absolute parameter value, arithmetic mean, estimate, geometric mean)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Belzutifan_Marathe2023_geometric_mean;
