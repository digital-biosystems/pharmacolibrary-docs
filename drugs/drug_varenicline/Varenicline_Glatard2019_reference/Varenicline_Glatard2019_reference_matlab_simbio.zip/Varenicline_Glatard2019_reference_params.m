function p = Varenicline_Glatard2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: varenicline   source: Glatard_2019 / reference   route: oral
  p.name  = 'Varenicline_Glatard2019_reference_params';
  p.drug  = 'varenicline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 211.0;                % central volume [L]
  p.CL = 9.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.98;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
