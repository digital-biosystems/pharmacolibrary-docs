model Varenicline_Fediuk2021_reference
  parameter Real Cl_ref = 3.4722222222222224e-06 "Cl [m3/s]";
  parameter Real cov_body_weight = 1.0 "body weight covariate (reference 1.0)";
  parameter Real cov_race_1 = 0 "race covariate";
  parameter Real cov_race_2 = 0 "race covariate";
  parameter Real cov_sex_3 = 0 "sex covariate";
  parameter Real Vd_ref = 0.231 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_body_weight/1.0)^(0.872)*(1 + (0.757)*cov_race_1)*(1 + (0.854)*cov_race_2)*(1 + (0.861)*cov_sex_3),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211268,
    adminMass = 5e-07,
    ka = 0.00023888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About varenicline</h4><p>Varenicline is a nicotinic acetylcholine receptor partial agonist used to treat nicotine dependence and dry eye syndrome. It is administered orally as tablets. The drug is authorized in the European Union and available as a generic medication in other regions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q411330\">Wikidata Q411330</a>, <a href=\"https://en.wikipedia.org/wiki/Varenicline?oldid=1375978318\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>varenicline</td></tr><tr><td>population:</td><td>adolescent smokers</td></tr><tr><td>source_paper:</td><td>Fediuk_2021</td></tr><tr><td>measured_compound:</td><td>varenicline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412645-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>varenicline 211.268 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL/F (L/h)'; source reconciliation required</li><li>table representations disagree for 'Body weight'; source reconciliation required</li><li>table representations disagree for 'Black race'; source reconciliation required</li><li>table representations disagree for 'Other race'; source reconciliation required</li><li>table representations disagree for 'Female sex'; source reconciliation required</li><li>table representations disagree for 'V/F (L)'; source reconciliation required</li><li>table representations disagree for 'Body weight'; source reconciliation required</li><li>table representations disagree for 'Black race'; source reconciliation required</li><li>table representations disagree for 'Other race'; source reconciliation required</li><li>table representations disagree for 'Female sex'; source reconciliation required</li><li>table representations disagree for 'ka (h−1)'; source reconciliation required</li><li>table representations disagree for 'ω2 CL/F'; source reconciliation required</li><li>table representations disagree for 'ω2 V/F'; source reconciliation required</li><li>table representations disagree for 'ω2 ka'; source reconciliation required</li><li>table representations disagree for 'COVCL/F,V/F'; source reconciliation required</li><li>table representations disagree for 'COVCL/F,ka'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Varenicline_Fediuk2021_reference;
