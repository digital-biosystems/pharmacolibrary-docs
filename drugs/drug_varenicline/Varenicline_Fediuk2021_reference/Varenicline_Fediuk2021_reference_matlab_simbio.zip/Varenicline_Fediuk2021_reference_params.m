function p = Varenicline_Fediuk2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: varenicline   source: Fediuk_2021 / reference   route: oral
  p.name  = 'Varenicline_Fediuk2021_reference_params';
  p.drug  = 'varenicline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 231.0;                % central volume [L]
  p.CL = 12.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.86;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
