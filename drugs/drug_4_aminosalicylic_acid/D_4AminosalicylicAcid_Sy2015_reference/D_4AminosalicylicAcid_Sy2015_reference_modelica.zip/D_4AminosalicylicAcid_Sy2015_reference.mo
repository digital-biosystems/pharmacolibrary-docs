model D_4AminosalicylicAcid_Sy2015_reference
  parameter Real Cl_ref = 2.2611111111111117e-06 "Cl [m3/s]";
  parameter Real cov_gender_0 = 0 "gender covariate";
  parameter Real Vd_ref = 0.0489 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.315)*cov_gender_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4-aminosalicylic acid</td></tr><tr><td>population:</td><td>tuberculosis patients</td></tr><tr><td>source_paper:</td><td>Sy_2015</td></tr><tr><td>measured_compound:</td><td>para-aminosalicylic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F', value '32.2') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '25.2') — already have one for this compound</li><li>dropped duplicate Q306 ('Ktr', value '44.7') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Efavirenz on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_2:row18:col1'])</li><li>covariate level 'Gender on CL/F' → Q900:gender_on_cl_f = 0.315 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=para-aminosalicylic acid</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_4AminosalicylicAcid_Sy2015_reference;
