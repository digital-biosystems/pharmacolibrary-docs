function p = D_4AminosalicylicAcid_Sy2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: 4_aminosalicylic_acid   source: Sy_2015 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'D_4AminosalicylicAcid_Sy2015_reference_params';
  p.drug  = '4_aminosalicylic_acid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.9;                % central volume [L]
  p.CL = 8.14;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.15425;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
