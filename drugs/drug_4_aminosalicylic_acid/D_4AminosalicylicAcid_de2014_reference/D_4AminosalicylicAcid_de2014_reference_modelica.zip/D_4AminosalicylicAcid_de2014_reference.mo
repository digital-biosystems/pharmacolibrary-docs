model D_4AminosalicylicAcid_de2014_reference
  parameter Real Cl_ref = 2.6166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0518 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 4.5138888888888894e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>4-aminosalicylic acid</td></tr><tr><td>population:</td><td>tuberculosis patients with and without HIV coinfection receiving antiretroviral therapy</td></tr><tr><td>source_paper:</td><td>de_2014</td></tr><tr><td>measured_compound:</td><td>para-aminosalicylic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: transit-compartment absorption reported; transit absorption (ktr=0.0001806/s, n=3) folded to first-order ka = ktr/(n+1) = 4.514e-05/s — same mean absorption time, no delay phase</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: '% CV of CL/F (CL)' → Q27 (unit '[length] ** 3' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('% CV of CL/F (CL)', value '49.8') — already have one for this compound</li><li>unit_dimension_unknown: 'V' (V/F)</li><li>dropped duplicate Q76 ('% CV of V/F (V)', value '74.8') — already have one for this compound</li><li>routed '% CV of K tr (K tr )' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Efavirenz on CL/F b' — extend the ontology if this is a real PK parameter (source ['tab_2:row18:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=para-aminosalicylic acid</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_4AminosalicylicAcid_de2014_reference;
