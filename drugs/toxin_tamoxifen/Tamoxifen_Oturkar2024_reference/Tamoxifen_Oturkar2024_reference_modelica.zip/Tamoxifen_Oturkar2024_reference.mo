model Tamoxifen_Oturkar2024_reference
  parameter Real Cl_ref = 1.4166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.24 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.371524,
    adminMass = 2e-05,
    ka = 0.00025,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tamoxifen</td></tr><tr><td>population:</td><td>women with newly diagnosed stage I–III ESR1+/HER2-/wild-type p53 breast cancer</td></tr><tr><td>source_paper:</td><td>Oturkar_2024</td></tr><tr><td>measured_compound:</td><td>Tamoxifen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>undtbl1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tamoxifen 371.524 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωV (%) Plasma' routed out of structural estimates ('Between-subject variability (BSV) b')</li><li>table section iiv: 'ωk (%) TAM/4-OHTAM' routed out of structural estimates ('Between-subject variability (BSV) b')</li><li>table section iiv: 'ωk (%) TAM/TAM-NOX' routed out of structural estimates ('Between-subject variability (BSV) b')</li><li>table section iiv: 'ωk (%) TAM/NDT' routed out of structural estimates ('Between-subject variability (BSV) b')</li><li>table section iiv: 'ωk (%) e,END' routed out of structural estimates ('Between-subject variability (BSV) b')</li><li>table section iiv: 'ωk (%) e,TAM-NOX' routed out of structural estimates ('Between-subject variability (BSV) b')</li><li>column 'identifier' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Data deposition in GEO.GEO accession GSE263089' — extend the ontology if this is a real PK parameter (source ['undtbl1:row61:col2'])</li><li>routed 'proportional, σ Prop' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (V (L) TAM)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tamoxifen</li><li>gap-filled Q22 (CL) from Dilli_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Dilli_2022 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Tamoxifen_Oturkar2024_reference;
