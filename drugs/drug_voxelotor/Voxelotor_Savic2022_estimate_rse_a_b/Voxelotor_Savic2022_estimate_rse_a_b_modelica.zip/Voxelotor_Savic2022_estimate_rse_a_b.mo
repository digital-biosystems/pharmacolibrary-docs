model Voxelotor_Savic2022_estimate_rse_a_b
  parameter Real Cl_ref = 1.7055555555555554e-06 "Cl [m3/s]";
  parameter Real cov_cyp3a4_0 = 0 "cyp3a4 covariate";
  parameter Real Vd_ref = 0.333 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.39)*cov_cyp3a4_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.2532532532532534e-07,
    k21 = 1.4983863531581375e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>voxelotor</td></tr><tr><td>population:</td><td>adults and adolescents with sickle cell disease</td></tr><tr><td>source_paper:</td><td>Savic_2022</td></tr><tr><td>measured_compound:</td><td>voxelotor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412731-tbl-0002</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'R bp' — extend the ontology if this is a real PK parameter (source ['psp412731-tbl-0002:row6:col1'])</li><li>dropped unlinked row (NIL): 'Blood volume on V c/F, (BLV/3.89 c )TH' — extend the ontology if this is a real PK parameter (source ['psp412731-tbl-0002:row8:col1'])</li><li>dropped unlinked row (NIL): 'Hematocrit on R bp, (HCT/27.8)TH' — extend the ontology if this is a real PK parameter (source ['psp412731-tbl-0002:row9:col1'])</li><li>covariate level 'CYP3A4 inducer on CL/F, expTH' → Q900:cyp3a4_inducer_on_cl_f_expth = 0.39 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'Nominal dose on R bp, (dose/900)TH' — extend the ontology if this is a real PK parameter (source ['psp412731-tbl-0002:row11:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=voxelotor</li><li>population split: 'estimate (rse [%]) a , b' subgroup of Savic_2022 (paper reports 2 populations: estimate (rse [%]) a , b, shrinkage)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Voxelotor_Savic2022_estimate_rse_a_b;
