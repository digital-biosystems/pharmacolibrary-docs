function p = Voxelotor_Savic2022_estimate_rse_a_b_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: voxelotor   source: Savic_2022 / estimate_rse_a_b   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Voxelotor_Savic2022_estimate_rse_a_b_params';
  p.drug  = 'voxelotor';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 333.0;                % central volume [L]
  p.CL = 6.14;                % clearance [L/h]
  p.Vp = [72.3];             % peripheral volumes [L]
  p.Q  = [0.39];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
