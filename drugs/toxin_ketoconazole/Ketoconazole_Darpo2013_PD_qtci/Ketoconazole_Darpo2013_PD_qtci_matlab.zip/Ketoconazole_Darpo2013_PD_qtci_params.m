function p = Ketoconazole_Darpo2013_PD_qtci_params()
% Ketoconazole_Darpo2013_PD_qtci_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketoconazole Darpo_2013::QTcI: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response ΔQTcI in ms. Driver: ketoconazole (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.3000000000000003;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
