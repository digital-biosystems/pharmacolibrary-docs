model Ketoconazole_Darpo2013_PD_qtci
  "linear exposure-response sweep — Darpo_2013 :: ΔQTcI (change-from-baseline in QTc interval corrected by individual regression slope)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1.3,  // [meter ** 3 * second / kilogram; ms per μg/mL × 1]
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Ketoconazole_Darpo2013_PD_qtci</h4><p>The steady-state exposure-response curve of Darpo B et al., <i>Annals of noninvasive electrocardiology : the official journal of the International Society for Holter and Noninvasive Electrocardiology, Inc 18(6):577–589</i> 2013 (<a href=\"https://doi.org/10.1111/anec.12103\">doi:10.1111/anec.12103</a>) — change-from-baseline in QTc interval corrected by individual regression slope [ms] against ketoconazole μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        1.3 ms per μg/mL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of ketoconazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ketoconazole_Darpo2013_PD_qtci;
