function p = Ketoconazole_Johnson2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketoconazole   source: Johnson_2018 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Ketoconazole_Johnson2018_reference_params';
  p.drug  = 'ketoconazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 60.7;                % central volume [L]
  p.CL = 0.0175;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 18.5;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
