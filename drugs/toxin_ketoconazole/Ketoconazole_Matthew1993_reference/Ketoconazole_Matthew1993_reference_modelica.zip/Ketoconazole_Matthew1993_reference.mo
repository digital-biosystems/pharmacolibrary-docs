model Ketoconazole_Matthew1993_reference
  parameter Real Cl_ref = 2.9166666666666663e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.21 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.531434,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketoconazole</td></tr><tr><td>population:</td><td>rat</td></tr><tr><td>source_paper:</td><td>Matthew_1993</td></tr><tr><td>measured_compound:</td><td>Ketoconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ketoconazole 531.434 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'dose' — extend the ontology if this is a real PK parameter (source ['Matthew_1993:abstract'])</li><li>unit_dimension_unknown: 'null' (Kp)</li><li>unit_dimension_unknown: 'null' (Kp)</li><li>dropped duplicate Q410 ('Tissue-to-plasma partition coefficients (adrenals)', value 53) — already have one for this compound</li><li>unit_dimension_unknown: 'null' (Kp)</li><li>dropped duplicate Q410 ('kidney:plasma partition coefficient', value 1.8) — already have one for this compound</li><li>unit_dimension_unknown: 'null' (Kp)</li><li>dropped duplicate Q410 ('blood:plasma concentration ratio', value 0.6) — already have one for this compound</li><li>'plasma binding' → Q46: printed without a unit and above 1 — read as a percentage</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ketoconazole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Duthaler_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketoconazole_Matthew1993_reference;
