model Promethazine_Taylor1983_reference
  parameter Real Cl_ref = 0.037462833333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 1.97 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.284421,
    adminMass = 2.5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>promethazine</td></tr><tr><td>population:</td><td>seven healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Taylor_1983</td></tr><tr><td>measured_compound:</td><td>Promethazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Promethazine 284.421 g/mol (pubchem); Promethazine sulphoxide 300.42 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>relinked 'blood clearance' Q23 → Q47: a rate constant in 'min-1' (the unit decides, not the label)</li><li>'absorption' → Q40: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q40 ('absorption', value 80) — already have one for this compound</li><li>implicit units: 'volume of distribution' → L (from the popPK convention: 'No unit is stated in the provided text. A volume of distribution value of 1970 is consistent with a total body volume in')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Promethazine</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — other model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=other; 4/4 row label(s) assigned, 3 linked by role; re-tagged Promethazine→parent ×4</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=134866 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Promethazine_Taylor1983_reference;
