model Levobupivacaine_Sessler2025_reference
  parameter Real Cl_ref = 3.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.171 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.288435,
    adminMass = 0.000133,
    ka = 0.000975,
    Tlag = 0.0,
    k21 = 9.067827348567283e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levobupivacaine</td></tr><tr><td>population:</td><td>adults undergoing bunionectomy</td></tr><tr><td>source_paper:</td><td>Sessler_2025</td></tr><tr><td>measured_compound:</td><td>Bupivacaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph6159-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>Bupivacaine 288.435 g/mol (pubchem); levobupivacaine 288.435 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Fret' — extend the ontology if this is a real PK parameter (source ['Sessler_2025_table_S1:row5:col1', 'Sessler_2025_table_S5:row5:col1'])</li><li>dropped unlinked row (NIL): 'B' — extend the ontology if this is a real PK parameter (source ['Sessler_2025_table_S1:row6:col1', 'Sessler_2025_table_S5:row6:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Bupivacaine</li><li>review gap-fill skipped: this record measures 'Bupivacaine', not levobupivacaine — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Levobupivacaine_Sessler2025_reference;
