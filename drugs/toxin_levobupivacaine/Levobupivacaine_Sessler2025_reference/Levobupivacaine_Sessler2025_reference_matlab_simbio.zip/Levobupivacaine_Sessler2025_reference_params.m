function p = Levobupivacaine_Sessler2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levobupivacaine   source: Sessler_2025 / reference   route: oral
  p.name  = 'Levobupivacaine_Sessler2025_reference_params';
  p.drug  = 'levobupivacaine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 171.0;                % central volume [L]
  p.CL = 13.5;                % clearance [L/h]
  p.Vp = [91.9];             % peripheral volumes [L]
  p.Q  = [30.0];             % inter-compartmental clearances [L/h]
  p.ka = 3.51;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 133.0;             % dose [mg]
end
