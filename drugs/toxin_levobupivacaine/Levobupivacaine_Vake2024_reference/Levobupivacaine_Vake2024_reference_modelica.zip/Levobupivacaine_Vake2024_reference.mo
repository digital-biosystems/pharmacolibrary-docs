model Levobupivacaine_Vake2024_reference
  parameter Real Cl_ref = 1.225e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035570000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.288435,
    adminMass = 7e-05,
    ka = 0.003,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levobupivacaine</td></tr><tr><td>population:</td><td>female grower pigs</td></tr><tr><td>source_paper:</td><td>Vake_2024</td></tr><tr><td>measured_compound:</td><td>Levobupivacaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levobupivacaine 288.435 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q47 ('λz'=0.111) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('t1/2'=6.25) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Vz/F'=35.57) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=4.41) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=17.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Levobupivacaine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Vincent_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end Levobupivacaine_Vake2024_reference;
