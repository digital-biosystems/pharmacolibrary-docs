function p = Levobupivacaine_Chalkiadis2005_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levobupivacaine   source: Chalkiadis_2005 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Levobupivacaine_Chalkiadis2005_reference_params';
  p.drug  = 'levobupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 202.0;                % central volume [L]
  p.CL = 12.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 10.8;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
