model Levobupivacaine_Malinovsky1999_PD_duration
  "emax exposure-response sweep — Malinovsky_1999 :: duration (motor block duration)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 9120,  // [s; min × 60]
    EC50 = 4.49e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 45, Interval = 0.09),
    Documentation(info = "<html><body><h4>Levobupivacaine_Malinovsky1999_PD_duration</h4><p>The steady-state exposure-response curve of Malinovsky JM et al., <i>Journal of controlled release : official journal of the Controlled Release Society 60(1):111–119</i> 1999 (<a href=\"https://doi.org/10.1016/s0168-3659(99)00062-0\">doi:10.1016/s0168-3659(99)00062-0</a>) — motor block duration [min] against levobupivacaine mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        152 min      maximal effect term (Emax (Plain), Q320)
  EC50  =       4.49 mg       exposure at half of the maximal effect term (E50 (Plain), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of levobupivacaine per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.49 mg)  response 4560
  exposure -> infinity  response 9120</pre></body></html>"));
end Levobupivacaine_Malinovsky1999_PD_duration;
