function p = Levobupivacaine_Malinovsky1999_PD_duration_params()
% Levobupivacaine_Malinovsky1999_PD_duration_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levobupivacaine Malinovsky_1999::duration: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response duration in min. Driver: levobupivacaine (dose_only).
p.E0 = 0.0;
p.Emax = 9120.0;
p.EC50 = 4.49e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 45.0;
p.form = 'E0 + Emax*frac';
end
