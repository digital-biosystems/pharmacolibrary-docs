model Levobupivacaine_Frawley2021_reference
  parameter Real Cl_ref = 5.972222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.189 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.288435,
    adminMass = 0.0001,
    ka = 0.003,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levobupivacaine</td></tr><tr><td>population:</td><td>neonates and infants</td></tr><tr><td>source_paper:</td><td>Frawley_2021</td></tr><tr><td>measured_compound:</td><td>Levobupivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levobupivacaine 288.435 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>relinked 'maturation half-time' Q100 → Q57: a half-life by its label (the unit decides, not the label)</li><li>unit_dimension_unknown: 'weeks postnatal age' (t1/2z)</li><li>covariate category for t1/2ka  from footnote/prose kept as documentation only (['Frawley_2021:abstract'])</li><li>implicit units: 'maturation half-time' → h (from the popPK convention: 'The parameter is a half-life (t1/2). In population PK, time units are typically hours. A value of 11.5 is physiologicall')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Levobupivacaine</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Vincent_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Levobupivacaine_Frawley2021_reference;
