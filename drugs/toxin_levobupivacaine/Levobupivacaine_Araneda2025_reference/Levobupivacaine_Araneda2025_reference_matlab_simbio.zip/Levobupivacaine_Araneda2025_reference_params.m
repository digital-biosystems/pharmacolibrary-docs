function p = Levobupivacaine_Araneda2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levobupivacaine   source: Araneda_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Levobupivacaine_Araneda2025_reference_params';
  p.drug  = 'levobupivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 41.9;                % central volume [L]
  p.CL = 0.288;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 10.8;                % absorption rate [1/h]
  p.F  = 0.543;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
