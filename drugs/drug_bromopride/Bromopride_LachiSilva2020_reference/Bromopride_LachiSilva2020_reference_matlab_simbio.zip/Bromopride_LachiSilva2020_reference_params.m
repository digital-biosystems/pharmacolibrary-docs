function p = Bromopride_LachiSilva2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bromopride   source: Lachi-Silva_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Bromopride_LachiSilva2020_reference_params';
  p.drug  = 'bromopride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 230.0;                % central volume [L]
  p.CL = 46.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.08;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.47;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
