model Bromazepam_Ochs1987_reference
  parameter Real Cl_ref = 4.783333333333332e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0616 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.316158,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bromazepam</td></tr><tr><td>population:</td><td>volunteer subjects (young and elderly)</td></tr><tr><td>source_paper:</td><td>Ochs_1987</td></tr><tr><td>measured_compound:</td><td>Bromazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bromazepam 316.158 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('bromazepam half-life', value 28) — already have one for this compound</li><li>dropped duplicate Q22 ('clearance associated with propranolol', value 0.65) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life', value '25') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Bromazepam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Bromazepam_Ochs1987_reference;
