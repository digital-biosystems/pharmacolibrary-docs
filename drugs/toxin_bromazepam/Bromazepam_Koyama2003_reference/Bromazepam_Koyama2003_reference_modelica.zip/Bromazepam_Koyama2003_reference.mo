// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Bromazepam_Koyama2003_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {104400.0},
    MM = 0.316158,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bromazepam</td></tr><tr><td>population:</td><td>57 patients with acute drug intoxication</td></tr><tr><td>source_paper:</td><td>Koyama_2003</td></tr><tr><td>measured_compound:</td><td>Bromazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>bromazepam 316.158 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'serum bromazepam levels' — extend the ontology if this is a real PK parameter (source ['Koyama_2003:abstract'])</li><li>dropped unlinked row (NIL): 'bromazepam toxic sign threshold' — extend the ontology if this is a real PK parameter (source ['Koyama_2003:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Bromazepam</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end Bromazepam_Koyama2003_reference;
