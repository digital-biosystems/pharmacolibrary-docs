model Trastuzumab_Verma2025_rat
  parameter Real Cl_ref = 9.166666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02886 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.025,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.007,
    ka = 0.00021666666666666668,
    Tlag = 0.0,
    k12 = 0.00013532763532763534,
    k21 = 8.004827947439139e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trastuzumab</h4><p>Trastuzumab is a monoclonal antibody used to treat HER2-positive cancers, mainly breast cancer and gastric cancer. It is widely used and authorised in the European Union, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412616\">Wikidata Q412616</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trastuzumab</td></tr><tr><td>population:</td><td>mice and rats</td></tr><tr><td>source_paper:</td><td>Verma_2025</td></tr><tr><td>measured_compound:</td><td>trastuzumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00022-t002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'CL' → L/h (from the popPK convention: 'The paper does not explicitly state the unit for CL in the provided text or table captions. However, CL is a clearance p')</li><li>implicit units: 'CLd' → L/h (from the popPK convention: 'The paper does not explicitly state the unit for CLd (intercompartmental clearance). By convention, intercompartmental c')</li><li>implicit units: 'V1' → L (from the popPK convention: 'The paper does not explicitly state the unit for V1 (central volume of distribution). By convention, volumes of distribu')</li><li>implicit units: 'V2' → L (from the popPK convention: 'The paper does not explicitly state the unit for V2 (peripheral volume of distribution). By convention, volumes of distr')</li><li>implicit units: 'ka' → 1/h (from the paper text: &quot;The text explicitly states: 'Interestingly, the model estimated value for the rate of oral absorption of trastuzumab (i.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trastuzumab</li><li>population split: 'rat' subgroup of Verma_2025 (paper reports 2 populations: mouse, rat)</li><li>molar mass: none found for 'trastuzumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Trastuzumab_Verma2025_rat;
