function p = Trastuzumab_Verma2025_rat_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trastuzumab   source: Verma_2025 / rat   route: oral
  p.name  = 'Trastuzumab_Verma2025_rat_params';
  p.drug  = 'trastuzumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.86;                % central volume [L]
  p.CL = 0.33;                % clearance [L/h]
  p.Vp = [48.79];             % peripheral volumes [L]
  p.Q  = [14.06];             % inter-compartmental clearances [L/h]
  p.ka = 0.78;                % absorption rate [1/h]
  p.F  = 0.025;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7000.0;             % dose [mg]
end
