function p = Venetoclax_Zhao2024_gong_202316_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: venetoclax   source: Zhao_2024 / gong_202316   route: oral
  p.name  = 'Venetoclax_Zhao2024_gong_202316_params';
  p.drug  = 'venetoclax';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 181.0;                % central volume [L]
  p.CL = 15.0;                % clearance [L/h]
  p.Vp = [107.0];             % peripheral volumes [L]
  p.Q  = [6.583333];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
