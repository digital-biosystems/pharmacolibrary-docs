model Venetoclax_Dave2019_PD_b_lymphocytes
  "linear exposure-response sweep — Dave_2019 :: B-lymphocytes (B-lymphocytes)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 20.9,  // [1]
    exposure_per_s = 1);   // 1 unit per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About venetoclax</h4><p>Venetoclax is an anticancer medicine used to treat blood cancers such as chronic lymphocytic leukemia, acute myeloid leukemia, and certain B-cell lymphomas. It is an approved medicine and is authorised in the European Union for chronic lymphocytic leukemia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23671272\">Wikidata Q23671272</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Venetoclax_Dave2019_PD_b_lymphocytes</h4><p>The steady-state exposure-response curve of Dave N et al., <i>Clinical and translational science 12(6):625–632</i> 2019 (<a href=\"https://doi.org/10.1111/cts.12665\">doi:10.1111/cts.12665</a>) — B-lymphocytes against venetoclax — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       20.9          change in response per unit of exposure (Slope of drug effect, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one  of venetoclax per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Venetoclax_Dave2019_PD_b_lymphocytes;
