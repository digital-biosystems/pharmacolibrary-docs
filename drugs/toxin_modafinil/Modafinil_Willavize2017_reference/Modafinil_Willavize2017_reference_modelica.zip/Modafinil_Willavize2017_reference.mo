model Modafinil_Willavize2017_reference
  parameter Real Cl_ref = 5.583333333333332e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27335000000000004,
    adminMass = 0.0003,
    ka = 0.0008519508118976711,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>modafinil</td></tr><tr><td>population:</td><td>healthy subjects and patients with bipolar I disorder</td></tr><tr><td>source_paper:</td><td>Willavize_2017</td></tr><tr><td>measured_compound:</td><td>Armodafinil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption half-life reported</td></tr><tr><td>molar_masses:</td><td>Armodafinil 273.35 g/mol (pubchem); Modafinil sulfone 289.349 g/mol (pubchem); R-modafinil acid 274.334 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Armodafinil</li><li>toxin: 2 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0, 0]</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F' is the general volume)</li><li>row roles (LLM): model_class=compartmental; 3/3 row label(s) assigned, 3 linked by role; re-tagged Armodafinil→parent ×3</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Modafinil_Willavize2017_reference;
