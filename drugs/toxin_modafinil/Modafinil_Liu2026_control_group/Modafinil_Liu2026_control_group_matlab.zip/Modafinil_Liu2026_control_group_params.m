function p = Modafinil_Liu2026_control_group_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: modafinil   source: Liu_2026 / control_group   route: oral
  % estimated (absent from source): ka
  p.name  = 'Modafinil_Liu2026_control_group_params';
  p.drug  = 'modafinil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 169.89;                % central volume [L]
  p.CL = 91.07;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 8400.0;             % dose [mg]
end
