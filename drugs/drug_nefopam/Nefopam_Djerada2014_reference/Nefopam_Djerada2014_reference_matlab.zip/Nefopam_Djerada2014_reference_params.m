function p = Nefopam_Djerada2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nefopam   source: Djerada_2014 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Nefopam_Djerada2014_reference_params';
  p.drug  = 'nefopam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 114.0;                % central volume [L]
  p.CL = 17.3;                % clearance [L/h]
  p.Vp = [208.0];             % peripheral volumes [L]
  p.Q  = [80.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
