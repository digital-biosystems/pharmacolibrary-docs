model Nefopam_Djerada2014_reference
  parameter Real Cl_ref = 4.805555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.114 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 0.0001966374269005848,
    k21 = 0.0001077724358974359
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nefopam</td></tr><tr><td>population:</td><td>elderly patients with or without renal impairment</td></tr><tr><td>source_paper:</td><td>Djerada_2014</td></tr><tr><td>measured_compound:</td><td>nefopam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nefopam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nefopam_Djerada2014_reference;
