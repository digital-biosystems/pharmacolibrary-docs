// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Mitoxantrone_Gokhale2001_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {3456.0},
    MM = 0.444488,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitoxantrone</td></tr><tr><td>population:</td><td>CD2F1 mice</td></tr><tr><td>source_paper:</td><td>Gokhale_2001</td></tr><tr><td>measured_compound:</td><td>Mitoxantrone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>mitoxantrone 444.488 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'dose' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract'])</li><li>dropped unlinked row (NIL): 'mortality' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract', 'Gokhale_2001:abstract'])</li><li>dropped unlinked row (NIL): 'Day' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract', 'Gokhale_2001:abstract'])</li><li>dropped unlinked row (NIL): 'doses of MTO' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract'])</li><li>dropped unlinked row (NIL): 'daily' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract', 'Gokhale_2001:abstract'])</li><li>unit_dimension_unknown: 'null' (equation variable)</li><li>dropped unlinked row (NIL): 'single dose' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract'])</li><li>dropped unlinked row (NIL): 'doses of LEM' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract'])</li><li>dropped unlinked row (NIL): '5 mg/kg' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract'])</li><li>dropped duplicate Q57 ('plasma half-lives were 0.11 hours', value 0.11) — already have one for this compound</li><li>dropped unlinked row (NIL): 'LEM 2.5 mg/kg' — extend the ontology if this is a real PK parameter (source ['Gokhale_2001:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mitoxantrone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Mitoxantrone_Gokhale2001_reference;
