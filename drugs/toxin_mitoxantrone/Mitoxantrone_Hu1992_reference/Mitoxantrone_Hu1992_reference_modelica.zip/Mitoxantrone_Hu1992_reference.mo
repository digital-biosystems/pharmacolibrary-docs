model Mitoxantrone_Hu1992_reference
  parameter Real Cl_ref = 1.2383333333333332e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 5.037 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.444488,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitoxantrone</td></tr><tr><td>population:</td><td>patients with advanced nasopharyngeal carcinoma</td></tr><tr><td>source_paper:</td><td>Hu_1992</td></tr><tr><td>measured_compound:</td><td>Mitoxantrone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mitoxantrone 444.488 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>'unbound fraction (%) in plasma at time 0 minutes' → Q46: printed without a unit and above 1 — read as a percentage</li><li>'unbound fraction (%) in plasma at time 5 minutes' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q46 ('unbound fraction (%) in plasma at time 5 minutes', value 3.25) — already have one for this compound</li><li>'average unbound fraction (%) in plasma' → Q46: printed without a unit and above 1 — read as a percentage</li><li>dropped duplicate Q46 ('average unbound fraction (%) in plasma', value 3.04) — already have one for this compound</li><li>implicit units: '% of the administration dose was excreted in urine as mitoxantrone parent compound' — the LLM proposed '%', whose dimension does not fit Q91; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Mitoxantrone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q91 — no SI value to build from; C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1296000, Tolerance = 1e-9, Interval = 1));
end Mitoxantrone_Hu1992_reference;
