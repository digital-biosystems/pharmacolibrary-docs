function p = Zidovudine_Tang2026_PD_azt_dp_params()
% Zidovudine_Tang2026_PD_azt_dp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zidovudine Tang_2026::AZT_DP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response AZT-DP in ng/10^6 cells. Driver: AZT (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
