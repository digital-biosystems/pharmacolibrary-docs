% run_Zidovudine_Tang2026_PD_azt_dp  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Zidovudine_Tang2026_PD_azt_dp_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [µM]'); ylabel('response [ng/10^6 cells]'); title('Zidovudine_Tang2026_PD_azt_dp', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Zidovudine_Tang2026_PD_azt_dp.csv');
