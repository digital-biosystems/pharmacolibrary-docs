model Zidovudine_Tang2026_PD_azt_tp
  "linear exposure-response sweep — Tang_2026 :: AZT-TP (intracellular AZT-TP)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = 1,  // [1]
    exposure_per_s = 1);   // 1 µM per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zidovudine</h4><p>Zidovudine is a nucleoside reverse transcriptase inhibitor used to treat HIV infection and AIDS. It is typically taken by mouth or given as a slow intravenous injection. This medication is widely available and included on the World Health Organization list of essential medicines.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q198504\">Wikidata Q198504</a>, <a href=\"https://en.wikipedia.org/wiki/Zidovudine?oldid=1366106723\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Zidovudine_Tang2026_PD_azt_tp</h4><p>The steady-state exposure-response curve of Tang F et al., <i>Scientific reports 16(1)</i> 2026 (<a href=\"https://doi.org/10.1038/s41598-026-49905-1\">doi:10.1038/s41598-026-49905-1</a>) — intracellular AZT-TP [ng/10^6 cells] against AZT µM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =          1          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one µM of AZT per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Zidovudine_Tang2026_PD_azt_tp;
