model Amprenavir_Okusanya2007_reference
  parameter Real Cl_ref = 1.7830555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06909 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.505627,
    adminMass = 0.0006,
    ka = 0.0002763888888888889,
    Tlag = 46.8,
    k12 = 9.005966452774964e-05,
    k21 = 1.5844721727074666e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amprenavir</h4><p>This antiviral medication belongs to the protease inhibitor class and was developed for managing HIV infection. Patients take the drug by mouth in capsule or liquid forms, and it is well absorbed from the gastrointestinal tract. The drug has been withdrawn from the European Union market as the manufacturer discontinued production.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q422198\">Wikidata Q422198</a>, <a href=\"https://en.wikipedia.org/wiki/Amprenavir?oldid=1375448790\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amprenavir</td></tr><tr><td>population:</td><td>healthy HIV-seronegative adults</td></tr><tr><td>source_paper:</td><td>Okusanya_2007</td></tr><tr><td>measured_compound:</td><td>amprenavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amprenavir 505.627 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>competing summary columns for 'Vc/F (liters/kg)'; not population strata</li><li>competing summary columns for 'Vc/F (liters/kg)'; not population strata</li><li>competing summary columns for 'Vp/F (liters/kg)'; not population strata</li><li>competing summary columns for 'Vp/F (liters/kg)'; not population strata</li><li>competing summary columns for 'CLd (liters/h/kg)'; not population strata</li><li>competing summary columns for 'CLd (liters/h/kg)'; not population strata</li><li>competing summary columns for 'CLt/F (liters/h/kg)'; not population strata</li><li>competing summary columns for 'CLt/F (liters/h/kg)'; not population strata</li><li>competing summary columns for 'CLb/F (liters/h/kg)'; not population strata</li><li>competing summary columns for 'CLb/F (liters/h/kg)'; not population strata</li><li>competing summary columns for 'Fraction recycled'; not population strata</li><li>competing summary columns for 'Fraction recycled'; not population strata</li><li>competing summary columns for 'Recycling time (h)'; not population strata</li><li>competing summary columns for 'Recycling time (h)'; not population strata</li><li>competing summary columns for 'TLag (h)'; not population strata</li><li>competing summary columns for 'TLag (h)'; not population strata</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amprenavir_Okusanya2007_reference;
