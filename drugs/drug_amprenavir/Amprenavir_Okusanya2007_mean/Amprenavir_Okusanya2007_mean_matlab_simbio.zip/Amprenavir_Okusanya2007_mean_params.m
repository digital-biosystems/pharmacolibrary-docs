function p = Amprenavir_Okusanya2007_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amprenavir   source: Okusanya_2007 / mean   route: oral
  p.name  = 'Amprenavir_Okusanya2007_mean_params';
  p.drug  = 'amprenavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 74.9;                % central volume [L]
  p.CL = 7.42;                % clearance [L/h]
  p.Vp = [535.5];             % peripheral volumes [L]
  p.Q  = [29.82];             % inter-compartmental clearances [L/h]
  p.ka = 0.986;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.354;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
