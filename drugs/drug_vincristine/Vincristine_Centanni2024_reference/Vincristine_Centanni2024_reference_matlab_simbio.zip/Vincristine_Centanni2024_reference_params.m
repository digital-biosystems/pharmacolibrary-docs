function p = Vincristine_Centanni2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vincristine   source: Centanni_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Vincristine_Centanni2024_reference_params';
  p.drug  = 'vincristine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 23.3;                % central volume [L]
  p.CL = 45.2;                % clearance [L/h]
  p.Vp = [576.0];             % peripheral volumes [L]
  p.Q  = [114.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.058;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
