function p = Erythromycin_Gaohua2015_plasma_g_ml_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: erythromycin   source: Gaohua_2015 / plasma_g_ml   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Erythromycin_Gaohua2015_plasma_g_ml_params';
  p.drug  = 'erythromycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.6;                % central volume [L]
  p.CL = 8.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
