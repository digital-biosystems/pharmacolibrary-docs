% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Erythromycin_Gaohua2015_elf_g_ml_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
