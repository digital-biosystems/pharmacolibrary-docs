model Nemonoxacin_Chen2023_reference
  parameter Real Cl_ref = 2.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.497126 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.371437,
    adminMass = 0.0005,
    ka = 0.0006111111111111112,
    Tlag = 684.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nemonoxacin</h4><p>Nemonoxacin is a quinolone antibacterial developed as an antibiotic for bacterial infections. It is still investigational and has not been approved for general clinical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15425793\">Wikidata Q15425793</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nemonoxacin</td></tr><tr><td>population:</td><td>Chinese subjects (healthy and community-acquired pneumonia patients)</td></tr><tr><td>source_paper:</td><td>Chen_2023</td></tr><tr><td>measured_compound:</td><td>nemonoxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nemonoxacin 371.437 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CL'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'V2'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'Q'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'V3'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'unit / mean' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'KA'; source reconciliation required</li><li>table representations disagree for 'KA'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'TLAG'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>table representations disagree for 'CLcr (CL)'; source reconciliation required</li><li>column 'bias (%)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Nemonoxacin_Chen2023_reference;
