function p = Nemonoxacin_Chen2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nemonoxacin   source: Chen_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Nemonoxacin_Chen2023_reference_params';
  p.drug  = 'nemonoxacin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 497.126;                % central volume [L]
  p.CL = 10.3;                % clearance [L/h]
  p.Vp = [103.0];             % peripheral volumes [L]
  p.Q  = [2.0];             % inter-compartmental clearances [L/h]
  p.ka = 2.2;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.19;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
