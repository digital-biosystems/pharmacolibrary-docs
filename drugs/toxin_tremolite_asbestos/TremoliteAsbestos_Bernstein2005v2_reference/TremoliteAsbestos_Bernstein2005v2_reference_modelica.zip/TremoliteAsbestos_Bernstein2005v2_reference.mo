// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model TremoliteAsbestos_Bernstein2005v2_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {26784.0},
    MM = 0.812353,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tremolite_asbestos</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Bernstein_2005_2</td></tr><tr><td>measured_compound:</td><td>Tremolite Asbestos</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_5</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Tremolite Asbestos 812.353 g/mol (pubchem); tremolite_asbestos 812.353 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>substance matrix Bernstein_2005_2_table_7 ('TABLE 7 Comparative clearance half-times of fibers longer than 20 µm and fibers between 5 '): no row names this substance — its 22 row(s) (Calidria chrysotile, Brazilian chrysotile, Fiber B (B01.9), Fiber A, Fiber C, Fiber G, MMVF34 (HT), MMVF22) are other substances' values; none taken</li><li>substance matrix Bernstein_2005_2_table_4 ('TABLE 4 Clearance half-times of Canadian chrysotile and tremolite by length fraction'): no row names this substance — its 3 row(s) (>20 μm, 5–20 μm, <5 μm) are other substances' values; none taken</li><li>salvaged Q57 ('>20 µm Calidria chrysotile T 1/2'=0.31) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Tremolite Asbestos</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 273.6));
end TremoliteAsbestos_Bernstein2005v2_reference;
