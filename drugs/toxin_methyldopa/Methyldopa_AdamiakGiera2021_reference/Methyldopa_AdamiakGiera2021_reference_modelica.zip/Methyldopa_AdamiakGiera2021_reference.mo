model Methyldopa_AdamiakGiera2021_reference
  parameter Real Cl_ref = 1.36e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0324 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21121700000000002,
    adminMass = 0.0001,
    ka = 0.003,
    Tlag = 598.2
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methyldopa</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Adamiak-Giera_2021</td></tr><tr><td>measured_compound:</td><td>methyldopa</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methyldopa 211.217 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Adamiak-Giera_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methyldopa_AdamiakGiera2021_reference;
