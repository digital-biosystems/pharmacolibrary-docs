// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Methyldopa_van2022_haas_et_al_64
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {6048.0},
    MM = 0.21121700000000002,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>methyldopa</td></tr><tr><td>population:</td><td>pregnant women</td></tr><tr><td>source_paper:</td><td>van_2022</td></tr><tr><td>measured_compound:</td><td>Methyldopa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>Tab5</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>methyldopa 211.217 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Oral dose' — extend the ontology if this is a real PK parameter (source ['Tab5:row1:col6'])</li><li>dropped value-less row: 'Table 5. Pharmacokinetic parameters of nifedipine as tocolytic'</li><li>dropped value-less row: 'Given means are reported'</li><li>dropped value-less row: 'NA not applicable'</li><li>dropped value-less row: 'h hours'</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 4 (source ['Tab5:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['Tab5:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'Elimination half-life (t1/2)' → h (from the paper text: &quot;Elimination half-life (t1/2) = 1.68. The paper text explicitly states for nifedipine that t1/2 values were reported as '&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Methyldopa</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'haas et al. [64]' subgroup of van_2022 (paper reports 7 populations: ferguson et al. [63], haas et al. [60], haas et al. [64], marin et al. [67], papatsonis et al. [58], rogers et al. [48], ter laak et al. [56])</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Adamiak-Giera_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Adamiak-Giera_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Methyldopa_van2022_haas_et_al_64;
