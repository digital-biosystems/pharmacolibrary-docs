% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Methyldopa_Skerjanec1995_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
