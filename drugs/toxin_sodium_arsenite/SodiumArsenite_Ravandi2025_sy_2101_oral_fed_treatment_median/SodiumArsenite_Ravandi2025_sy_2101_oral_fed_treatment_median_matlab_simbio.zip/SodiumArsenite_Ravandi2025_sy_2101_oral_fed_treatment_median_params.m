function p = SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sodium_arsenite   source: Ravandi_2025 / sy_2101_oral_fed_treatment_median   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median_params';
  p.drug  = 'sodium_arsenite';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1231.41;                % central volume [L]
  p.CL = 38.31;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
