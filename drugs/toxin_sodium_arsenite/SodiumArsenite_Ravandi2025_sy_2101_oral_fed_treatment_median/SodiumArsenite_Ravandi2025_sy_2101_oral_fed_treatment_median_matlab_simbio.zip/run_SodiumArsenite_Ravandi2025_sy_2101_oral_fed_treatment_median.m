% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
