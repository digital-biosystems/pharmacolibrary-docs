% Run: build params, simulate 0..120.0 h, plot + save SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.m
here = fileparts(mfilename('fullpath'));
p = SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median_params();
out = simulate_pk(p, 0:0.05:120.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('sodium_arsenite — Ravandi_2025 (iv_bolus)');
print(fig, fullfile(here, 'SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.json'), 'w');
try
  s.model = 'SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.png, SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.csv, SodiumArsenite_Ravandi2025_sy_2101_oral_fed_treatment_median.json\n');
