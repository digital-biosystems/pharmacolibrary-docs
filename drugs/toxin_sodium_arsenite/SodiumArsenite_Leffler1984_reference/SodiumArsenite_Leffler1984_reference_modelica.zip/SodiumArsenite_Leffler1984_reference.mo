// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model SodiumArsenite_Leffler1984_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {1728000.0},
    MM = 0.074922,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sodium_arsenite</td></tr><tr><td>population:</td><td>hamsters</td></tr><tr><td>source_paper:</td><td>Leffler_1984</td></tr><tr><td>measured_compound:</td><td>Arsenic</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Arsenic 74.922 g/mol (pubchem); sodium_arsenite 129.91 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'volume median diameter' — extend the ontology if this is a real PK parameter (source ['Leffler_1984:abstract'])</li><li>dropped unlinked row (NIL): 'antimony (Sb)' — extend the ontology if this is a real PK parameter (source ['Leffler_1984:abstract'])</li><li>dropped unlinked row (NIL): 'arsenic (As)' — extend the ontology if this is a real PK parameter (source ['Leffler_1984:abstract'])</li><li>covariate category for t1/2α from footnote/prose kept as documentation only (['Leffler_1984:abstract', 'Leffler_1984:abstract', 'Leffler_1984:abstract', 'Leffler_1984:abstract', 'Leffler_1984:abstract', 'Leffler_1984:abstract', 'Leffler_1984:abstract', 'Leffler_1984:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Arsenic</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'Arsenic', not sodium_arsenite — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 18144.0));
end SodiumArsenite_Leffler1984_reference;
