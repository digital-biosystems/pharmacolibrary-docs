% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = SodiumArsenite_Ravandi2025_sy_2101_oral_fasted_treatment_med_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
