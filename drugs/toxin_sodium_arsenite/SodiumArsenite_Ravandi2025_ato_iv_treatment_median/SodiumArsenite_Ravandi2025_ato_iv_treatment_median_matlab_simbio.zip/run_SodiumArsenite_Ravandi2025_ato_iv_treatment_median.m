% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = SodiumArsenite_Ravandi2025_ato_iv_treatment_median_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
