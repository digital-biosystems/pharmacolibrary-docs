model NButylBenzenesulfonamide_Waidyanatha2020v2_reference
  parameter Real Cl_ref = 0.000505894391758442 "Cl [m3/s]";
  parameter Real Vd_ref = 3.731 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21329499999999998,
    adminMass = 0.0014,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>n_butyl_benzenesulfonamide</td></tr><tr><td>population:</td><td>HSD rats and B6C3F1 mice</td></tr><tr><td>source_paper:</td><td>Waidyanatha_2020_2</td></tr><tr><td>measured_compound:</td><td>N-Butyl-Benzenesulfonamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0020</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>n_butyl_benzenesulfonamide 213.295 g/mol (pubchem); N-Butyl-Benzenesulfonamide 213.295 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number None (source ['tbl0020:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q57 ('K10 half-Life (h)'=1.42) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V1_F (mL/kg)'=53300) from results prose — parameter table was unreadable</li><li>salvaged Q59 ('Alpha half-life'=0.119) from results prose — parameter table was unreadable</li><li>salvaged Q60 ('Beta half-life'=0.895) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=N-Butyl-Benzenesulfonamide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1_F (mL/kg)' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>derived CL/F=1821.22 L/h from ln2/t½z × V/F = CL/F (Q57 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end NButylBenzenesulfonamide_Waidyanatha2020v2_reference;
