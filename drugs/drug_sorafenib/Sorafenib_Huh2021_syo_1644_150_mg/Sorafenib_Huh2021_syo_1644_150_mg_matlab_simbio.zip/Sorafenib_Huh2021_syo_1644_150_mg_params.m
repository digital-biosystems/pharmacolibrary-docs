function p = Sorafenib_Huh2021_syo_1644_150_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sorafenib   source: Huh_2021 / syo_1644_150_mg   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Sorafenib_Huh2021_syo_1644_150_mg_params';
  p.drug  = 'sorafenib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.17;                % central volume [L]
  p.CL = 3.33;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
