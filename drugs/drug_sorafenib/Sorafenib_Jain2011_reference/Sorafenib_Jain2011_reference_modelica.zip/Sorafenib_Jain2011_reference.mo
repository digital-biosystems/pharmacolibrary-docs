model Sorafenib_Jain2011_reference
  parameter Real Cl_ref = 2.258333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.213 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.464825,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sorafenib</h4><p>Sorafenib is a protein kinase inhibitor used to treat hepatocellular carcinoma, renal cell carcinoma, and certain types of thyroid and blood cancers. It is given orally in tablet form. The medication is authorised in the European Union for these conditions.</p><p><small>Summary written by qwen3.8-27b from <a href=\"https://www.wikidata.org/wiki/Q421136\">Wikidata Q421136</a>, <a href=\"https://en.wikipedia.org/wiki/Sorafenib?oldid=1383067116\">Wikipedia</a> (CC BY-SA 4.0), DrugBank's routes and dosage forms, the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sorafenib</td></tr><tr><td>population:</td><td>patients with solid tumours</td></tr><tr><td>source_paper:</td><td>Jain_2011</td></tr><tr><td>measured_compound:</td><td>sorafenib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sorafenib 464.825 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'average time to gall bladder emptying' — extend the ontology if this is a real PK parameter (source ['Jain_2011:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sorafenib</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Sorafenib_Jain2011_reference;
