% Run (SimBiology): build model + dose, simulate 0..43.0 h, plot.
p = Sorafenib_Huh2021_parameter_estimates_relative_standard_erro_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 43.0);
