function p = Sorafenib_Huh2021_parameter_estimates_relative_standard_erro_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sorafenib   source: Huh_2021 / parameter_estimates_relative_standard_error   route: oral
  p.name  = 'Sorafenib_Huh2021_parameter_estimates_relative_standard_erro_params';
  p.drug  = 'sorafenib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.17;                % central volume [L]
  p.CL = 3.33;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.6;                % absorption rate [1/h]
  p.F  = 0.0162;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
