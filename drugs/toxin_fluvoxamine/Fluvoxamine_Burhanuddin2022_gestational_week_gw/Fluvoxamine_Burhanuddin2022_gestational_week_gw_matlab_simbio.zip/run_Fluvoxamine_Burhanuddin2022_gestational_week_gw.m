% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Fluvoxamine_Burhanuddin2022_gestational_week_gw_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
