function p = Fluvoxamine_Burhanuddin2022_gestational_week_gw_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluvoxamine   source: Burhanuddin_2022 / gestational_week_gw   route: oral
  % estimated (absent from source): F
  p.name  = 'Fluvoxamine_Burhanuddin2022_gestational_week_gw_params';
  p.drug  = 'fluvoxamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 160.0;                % central volume [L]
  p.CL = 101.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.46;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
