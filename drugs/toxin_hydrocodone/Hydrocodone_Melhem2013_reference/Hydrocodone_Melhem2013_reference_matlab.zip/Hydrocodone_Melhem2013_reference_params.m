function p = Hydrocodone_Melhem2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydrocodone   source: Melhem_2013 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Hydrocodone_Melhem2013_reference_params';
  p.drug  = 'hydrocodone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 714.0;                % central volume [L]
  p.CL = 64.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
