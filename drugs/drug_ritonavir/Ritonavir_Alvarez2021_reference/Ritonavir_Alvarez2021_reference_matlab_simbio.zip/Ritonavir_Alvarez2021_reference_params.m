function p = Ritonavir_Alvarez2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ritonavir   source: Alvarez_2021 / reference   route: oral
  p.name  = 'Ritonavir_Alvarez2021_reference_params';
  p.drug  = 'ritonavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 94.8;                % central volume [L]
  p.CL = 4.88;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.572;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
