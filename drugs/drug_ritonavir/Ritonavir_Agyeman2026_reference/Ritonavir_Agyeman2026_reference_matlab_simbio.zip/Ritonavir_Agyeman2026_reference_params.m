function p = Ritonavir_Agyeman2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ritonavir   source: Agyeman_2026 / reference   route: oral
  p.name  = 'Ritonavir_Agyeman2026_reference_params';
  p.drug  = 'ritonavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.1;                % central volume [L]
  p.CL = 1.73;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
