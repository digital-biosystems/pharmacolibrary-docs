model Ritonavir_Calderin2025_reference
  parameter Real Cl_ref = 3.638888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7209439999999999,
    adminMass = 0.0012,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ritonavir</h4><p>Ritonavir is an antiviral protease inhibitor used to treat HIV infection and, in combination, hepatitis C. It is widely used, is included on the WHO essential medicines list, and is authorised in the European Union for HIV infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422618\">Wikidata Q422618</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ritonavir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Calderin_2025</td></tr><tr><td>measured_compound:</td><td>ritonavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ritonavir 720.944 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Calderin_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ritonavir_Calderin2025_reference;
