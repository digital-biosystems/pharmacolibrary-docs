function p = Ritonavir_Tikiso2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ritonavir   source: Tikiso_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ritonavir_Tikiso2022_reference_params';
  p.drug  = 'ritonavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 44.3;                % central volume [L]
  p.CL = 15.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.4;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
