function p = Escitalopram_Weisskopf2020_final_covariate_model_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escitalopram   source: Weisskopf_2020 / final_covariate_model_estimate   route: oral
  p.name  = 'Escitalopram_Weisskopf2020_final_covariate_model_estimate_params';
  p.drug  = 'escitalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1590.0;                % central volume [L]
  p.CL = 32.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.87;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
