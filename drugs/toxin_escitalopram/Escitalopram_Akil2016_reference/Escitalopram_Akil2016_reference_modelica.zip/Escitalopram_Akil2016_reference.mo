model Escitalopram_Akil2016_reference
  parameter Real Cl_ref = 9.333333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.3900000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>elderly Alzheimer's disease patients with agitation</td></tr><tr><td>source_paper:</td><td>Akil_2016</td></tr><tr><td>measured_compound:</td><td>S-citalopram (escitalopram)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table representations disagree for 'CLRp/F for male, L/h'; source reconciliation required</li><li>table representations disagree for 'CLRp/F for female, L/h'; source reconciliation required</li><li>table representations disagree for 'V/F, L'; source reconciliation required</li><li>table representations disagree for 'Ka, h−1'; source reconciliation required</li><li>table representations disagree for 'CLRm/F, L/h'; source reconciliation required</li><li>table representations disagree for 'ωCLp, %'; source reconciliation required</li><li>table representations disagree for 'ωV, %'; source reconciliation required</li><li>table representations disagree for 'ωCLm, %'; source reconciliation required</li><li>table representations disagree for 'σ, ng/ml (additive)'; source reconciliation required</li><li>table representations disagree for 'σ, % (proportional)'; source reconciliation required</li><li>table representations disagree for 'CLSp/F for EM/RM, L/h'; source reconciliation required</li><li>table representations disagree for 'CLSp/F for IM/PM, L/h'; source reconciliation required</li><li>table representations disagree for 'CLSp/F for Missing, L/h'; source reconciliation required</li><li>table representations disagree for 'V/F, L'; source reconciliation required</li><li>table representations disagree for 'Ka, h−1'; source reconciliation required</li><li>table representations disagree for 'CLSm/F, L/h'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Akil2016_reference;
