function p = Escitalopram_Weisskopf2020_breast_milk_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escitalopram   source: Weisskopf_2020 / breast_milk   route: oral
  p.name  = 'Escitalopram_Weisskopf2020_breast_milk_params';
  p.drug  = 'escitalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 900.0;                % central volume [L]
  p.CL = 29.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.57;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
