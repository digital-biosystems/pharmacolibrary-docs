model Escitalopram_Liu2022_reference
  parameter Real Cl_ref = 4.527777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.8150000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.324399,
    adminMass = 5e-06,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>Chinese psychiatric patients (inpatients on escitalopram with therapeutic drug monitoring)</td></tr><tr><td>source_paper:</td><td>Liu_2022</td></tr><tr><td>measured_compound:</td><td>Escitalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'θ Age' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q27 ('CL/F', value '0.0877') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '0.235') — already have one for this compound</li><li>covariate effect for Q49 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q372 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Escitalopram</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>pharmacogenetic covariate 'theta_q49_im' (im) — PGx domain</li><li>pharmacogenetic covariate 'theta_q372_pm' (pm) — PGx domain</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Feng_2011's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C1_half_life_beta failed (ratio 0.6931))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Liu2022_reference;
