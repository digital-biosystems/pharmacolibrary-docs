model Escitalopram_Jin2009_reference
  parameter Real Cl_ref = 7.083333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.324399,
    adminMass = 1e-05,
    ka = 0.00020555555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>patients with diagnosed depression prescribed escitalopram</td></tr><tr><td>source_paper:</td><td>Jin_2009</td></tr><tr><td>measured_compound:</td><td>Escitalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('oral clearance (CL/F) patient reported', value 26.9) — already have one for this compound</li><li>dropped duplicate Q76 ('volume of distribution (V/F) patient reported', value 767) — already have one for this compound</li><li>dropped duplicate Q49 ('absorption rate constant K(a) patient reported', value 0.51) — already have one for this compound</li><li>covariate category for V/F from footnote/prose kept as documentation only (['Jin_2009:abstract'])</li><li>covariate category for kabs from footnote/prose kept as documentation only (['Jin_2009:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Escitalopram</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Jin2009_reference;
