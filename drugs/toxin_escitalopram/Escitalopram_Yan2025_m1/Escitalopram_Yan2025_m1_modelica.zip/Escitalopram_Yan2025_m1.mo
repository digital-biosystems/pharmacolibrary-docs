// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Escitalopram_Yan2025_m1
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {106200.0},
    MM = 0.324399,
    adminMass = 5e-06,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>Chinese patients treated with escitalopram (external validation cohort)</td></tr><tr><td>source_paper:</td><td>Yan_2025</td></tr><tr><td>measured_compound:</td><td>Escitalopram</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.399 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>transposed table Yan_2025_table_p6_1: rows are variants (M1, M2, M3, M4, M5, M6), the parameters are the column headers (Residual Unexplained Variability Prop% Add (mg/L)) — read one record per variant</li><li>table representations disagree for 'Residual Unexplained Variability Prop% Add (mg/L)'; source reconciliation required</li><li>table representations disagree for 'Residual Unexplained Variability Prop% Add (mg/L)'; source reconciliation required</li><li>table representations disagree for 'Residual Unexplained Variability Prop% Add (mg/L)'; source reconciliation required</li><li>table representations disagree for 'Residual Unexplained Variability Prop% Add (mg/L)'; source reconciliation required</li><li>dropped value-less row: 'BW'</li><li>dropped value-less row: 'BMI'</li><li>dropped value-less row: 'PMA'</li><li>dropped value-less row: 'FFM'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'AUC'</li><li>salvaged Q57 ('half-life'=29.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Escitalopram</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: half-life printed only as a range — the value is the range's midpoint; route to review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1209.6));
end Escitalopram_Yan2025_m1;
