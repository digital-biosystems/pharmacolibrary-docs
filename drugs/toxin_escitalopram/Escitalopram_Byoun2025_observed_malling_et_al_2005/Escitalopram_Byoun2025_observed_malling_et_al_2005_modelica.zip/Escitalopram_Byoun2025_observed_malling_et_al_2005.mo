// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Escitalopram_Byoun2025_observed_malling_et_al_2005
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {1.281},
    CLelim = {6.805555555555556e-06},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>young and geriatric adults (Healthy Volunteer and Geriatric North European Caucasian populations, incl. Korean subjects)</td></tr><tr><td>source_paper:</td><td>Byoun_2025</td></tr><tr><td>measured_compound:</td><td>Escitalopram (S-CIT)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.399 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table representations disagree for 'Cmax (ng/mL)'; source reconciliation required</li><li>table representations disagree for 'DDI'; source reconciliation required</li><li>table representations disagree for 'Ratio (DDI/control)'; source reconciliation required</li><li>table representations disagree for 'AUC0−∞ (h⋅ng/mL)'; source reconciliation required</li><li>dropped unlinked row (NIL): 'DDI' — extend the ontology if this is a real PK parameter (source ['T2:row2:col2', 'T2:row5:col2'])</li><li>unit_dimension_unknown: 'DDI/control' (equation variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Escitalopram (S-CIT)</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: 1 first-order transfer(s) across 6 compounds → general_linear</li><li>status held at route_to_review — not promoted</li><li>population split: 'observed (malling et al., 2005)' subgroup of Byoun_2025 (paper reports 5 populations: 2.5 (75% ↓), 5 (50% ↓), g-im, g-pm, observed (malling et al., 2005))</li><li>molar mass: none found for 'Escitalopram (S-CIT)' — its concentrations stay mass-only</li><li>gap-filled Q22 (CL) from Feng_2011's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Liu_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Byoun2025_observed_malling_et_al_2005;
