% Run: build params, simulate 0..216.0 h, plot + save Escitalopram_Byoun2025_observed_malling_et_al_2005.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Escitalopram_Byoun2025_observed_malling_et_al_2005.m
here = fileparts(mfilename('fullpath'));
p = Escitalopram_Byoun2025_observed_malling_et_al_2005_params();
out = simulate_pk(p, 0:0.05:216.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('escitalopram — Byoun_2025 (oral)');
print(fig, fullfile(here, 'Escitalopram_Byoun2025_observed_malling_et_al_2005.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Escitalopram_Byoun2025_observed_malling_et_al_2005.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Escitalopram_Byoun2025_observed_malling_et_al_2005.json'), 'w');
try
  s.model = 'Escitalopram_Byoun2025_observed_malling_et_al_2005'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Escitalopram_Byoun2025_observed_malling_et_al_2005","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Escitalopram_Byoun2025_observed_malling_et_al_2005.png, Escitalopram_Byoun2025_observed_malling_et_al_2005.csv, Escitalopram_Byoun2025_observed_malling_et_al_2005.json\n');
