function p = Escitalopram_Byoun2025_observed_malling_et_al_2005_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escitalopram   source: Byoun_2025 / observed_malling_et_al_2005   route: oral
  % estimated (absent from source): F
  p.name  = 'Escitalopram_Byoun2025_observed_malling_et_al_2005_params';
  p.drug  = 'escitalopram';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1281.0;                % central volume [L]
  p.CL = 24.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
