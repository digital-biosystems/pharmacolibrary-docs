% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Escitalopram_Byoun2025_observed_malling_et_al_2005_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
