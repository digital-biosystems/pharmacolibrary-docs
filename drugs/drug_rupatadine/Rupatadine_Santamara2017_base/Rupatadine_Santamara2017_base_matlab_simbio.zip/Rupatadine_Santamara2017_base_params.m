function p = Rupatadine_Santamara2017_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rupatadine   source: Santamaría_2017 / base   route: oral
  p.name  = 'Rupatadine_Santamara2017_base_params';
  p.drug  = 'rupatadine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 547.0;                % clearance [L/h]
  p.Vp = [1540.0];             % peripheral volumes [L]
  p.Q  = [208.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.53;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.22;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
