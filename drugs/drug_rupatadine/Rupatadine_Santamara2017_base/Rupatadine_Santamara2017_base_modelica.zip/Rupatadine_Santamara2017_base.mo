model Rupatadine_Santamara2017_base
  parameter Real Cl_ref = 0.00015194444444444446 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41597,
    adminMass = 2.5e-06,
    ka = 0.00014722222222222223,
    Tlag = 792.0,
    k12 = 0.0005664488017429194,
    k21 = 3.751803751803752e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rupatadine</h4><p>Rupatadine is an antihistamine used to relieve symptoms of allergic conditions such as allergic rhinitis and urticaria. It is approved and used in several countries, though it is not authorised by the European Medicines Agency.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423450\">Wikidata Q423450</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rupatadine</td></tr><tr><td>population:</td><td>6-11 year olds with allergic rhinitis</td></tr><tr><td>source_paper:</td><td>Santamaría_2017</td></tr><tr><td>measured_compound:</td><td>rupatadine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pone.0176091.t003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rupatadine 415.97 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rupatadine</li><li>model-stage split: 'base model' is the base model of Santamaría_2017 (paper reports 2 stages: base model, final model); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rupatadine_Santamara2017_base;
