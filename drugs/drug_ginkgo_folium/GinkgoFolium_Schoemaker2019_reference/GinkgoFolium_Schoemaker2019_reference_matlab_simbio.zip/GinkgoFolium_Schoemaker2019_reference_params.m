function p = GinkgoFolium_Schoemaker2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ginkgo_folium   source: Schoemaker_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'GinkgoFolium_Schoemaker2019_reference_params';
  p.drug  = 'ginkgo_folium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.0;                % central volume [L]
  p.CL = 4.0;                % clearance [L/h]
  p.Vp = [40.0];             % peripheral volumes [L]
  p.Q  = [4.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
