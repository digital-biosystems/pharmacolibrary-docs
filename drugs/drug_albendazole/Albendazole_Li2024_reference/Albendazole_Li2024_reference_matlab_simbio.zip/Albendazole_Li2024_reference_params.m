function p = Albendazole_Li2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: albendazole   source: Li_2024 / reference   route: oral
  p.name  = 'Albendazole_Li2024_reference_params';
  p.drug  = 'albendazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 764.4;                % central volume [L]
  p.CL = 41.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 525.0;             % dose [mg]
end
