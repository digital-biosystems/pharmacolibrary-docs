model Melphalan_Choi2026_reference
  parameter Real Cl_ref = 1.7291666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0335 "Vd [m3]";
  parameter Real cov_wt = 28.0 "wt covariate (reference 28.0)";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(cov_wt/28.0)^(0.872),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.305199,
    adminMass = 1e-05,
    k12 = 0.00012023217247097844,
    k21 = 0.00021860394994723353
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>melphalan</td></tr><tr><td>population:</td><td>pediatric patients undergoing autologous hematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>Choi_2026</td></tr><tr><td>measured_compound:</td><td>Melphalan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>melphalan 305.199 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section covariance: 'CL~V1' routed out of structural estimates ('Covariance')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'V1 (%)' routed out of structural estimates ('PK IIV')</li><li>table section iiv: 'V2 (%)' routed out of structural estimates ('PK IIV')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'CL~WT' — extend the ontology if this is a real PK parameter (source ['Tab2:row7:col1'])</li><li>unit_dimension_unknown: '27.6 kg' (CL)</li><li>dropped duplicate Q22 ('CL~RegimenB', value '0.846') — already have one for this compound</li><li>covariate effect for Q26 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Melphalan</li><li>bound model equation to Q23 (CLb): CLB = 0.846 * (BW/70)^0.75</li><li>Q23 (CLb) is equation-defined: value moved to equation-variable 'CLB'; equation kept verbatim</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Melphalan_Choi2026_reference;
