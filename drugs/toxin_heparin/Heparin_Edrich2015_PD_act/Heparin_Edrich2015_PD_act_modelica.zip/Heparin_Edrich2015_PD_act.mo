model Heparin_Edrich2015_PD_act
  "linear exposure-response sweep — Edrich_2015 :: ACT (activated clotting time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.23   "[s/L per units]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Heparin_Edrich2015_PD_act</h4><p>The steady-state exposure-response curve of Edrich T et al., <i>Clinical pharmacology : advances and applications 7:19-27</i> 2015 (<a href=\"https://doi.org/10.2147/cpaa.s72185\">doi:10.2147/cpaa.s72185</a>) — activated clotting time [seconds] against heparin — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.23 s/L per units change in response per unit of exposure (kACT, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of heparin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Heparin_Edrich2015_PD_act;
