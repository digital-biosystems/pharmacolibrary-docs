model Heparin_Edrich2015_male_only_subgroup_m
  parameter Real Cl_ref = 3.6458333333333324e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0049 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3403,
    adminMass = 0.0001,
    ka = 0.0001375,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>heparin</td></tr><tr><td>population:</td><td>patients undergoing atrial ablation</td></tr><tr><td>source_paper:</td><td>Edrich_2015</td></tr><tr><td>measured_compound:</td><td>Heparin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t3-cpaa-7-019</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>heparin 340.3 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Wlow' — extend the ontology if this is a real PK parameter (source ['Edrich_2015_table_3:row0:col2'])</li><li>dropped unlinked row (NIL): 'Whigh' — extend the ontology if this is a real PK parameter (source ['Edrich_2015_table_3:row1:col2'])</li><li>salvaged Q61 ('estimated blood volume'=70) from results prose — parameter table was unreadable</li><li>implicit units: 'D' → h (from the popPK convention: &quot;The parameter is identified as 'Duration of a zero-order input (infusion or zero-order absorption)'. In population pharm&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Heparin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'male only (subgroup m)' subgroup of Edrich_2015 (paper reports 2 populations: female only (subgroup f), male only (subgroup m))</li><li>gap-filled Q22 (CL) from Bumbaca_2020's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — volume from this paper; review-gap-filled from other paper(s): Bumbaca_2020, Chen_2024 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Heparin_Edrich2015_male_only_subgroup_m;
