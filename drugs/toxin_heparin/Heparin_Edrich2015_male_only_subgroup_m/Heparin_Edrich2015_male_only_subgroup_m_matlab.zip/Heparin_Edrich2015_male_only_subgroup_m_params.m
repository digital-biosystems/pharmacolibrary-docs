function p = Heparin_Edrich2015_male_only_subgroup_m_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: heparin   source: Edrich_2015 / male_only_subgroup_m   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Heparin_Edrich2015_male_only_subgroup_m_params';
  p.drug  = 'heparin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.9;                % central volume [L]
  p.CL = 0.13125;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.495;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
