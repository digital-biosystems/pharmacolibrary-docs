% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Heparin_Edrich2015_male_only_subgroup_m_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
