function p = Heparin_Jia2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: heparin   source: Jia_2015 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Heparin_Jia2015_reference_params';
  p.drug  = 'heparin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.01;                % central volume [L]
  p.CL = 1.18;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.495;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
