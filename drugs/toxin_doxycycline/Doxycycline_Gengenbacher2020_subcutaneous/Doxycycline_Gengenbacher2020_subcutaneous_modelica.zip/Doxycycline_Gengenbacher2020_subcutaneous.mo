model Doxycycline_Gengenbacher2020_subcutaneous
  parameter Real Cl_ref = 4.333333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 5.2,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.44439999999999996,
    adminMass = 0.00035,
    ka = 0.002861111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>rabbits and mice</td></tr><tr><td>source_paper:</td><td>Gengenbacher_2020</td></tr><tr><td>measured_compound:</td><td>Doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>doxycycline 444.4 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'Vss' from footnote/prose loose number None (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Vss' from footnote/prose loose number None (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q61 ('volume of distribution at steady state'=1) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=26) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Doxycycline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'subcutaneous' subgroup of Gengenbacher_2020 (paper reports 4 populations: intravenous bolus, oral gavage, oral gavage (tb-infected), subcutaneous)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chapuis_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Doxycycline_Gengenbacher2020_subcutaneous;
