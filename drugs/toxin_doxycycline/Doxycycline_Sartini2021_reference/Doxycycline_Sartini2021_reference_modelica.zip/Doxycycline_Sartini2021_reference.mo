// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Doxycycline_Sartini2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {50220.0},
    MM = 0.44439999999999996,
    adminMass = 0.0014,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>Ten geese</td></tr><tr><td>source_paper:</td><td>Sartini_2021</td></tr><tr><td>measured_compound:</td><td>Doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>jvp13002-tbl-0001</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>doxycycline 444.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'AUC(0-t)' (captured trailing unit '0-t' for child rows)</li><li>dropped value-less row: 'AUC(0-inf)' (captured trailing unit '0-inf' for child rows)</li><li>dropped value-less row: 'kel'</li><li>dropped value-less row: 't1/2'</li><li>dropped value-less row: 'Cmax'</li><li>dropped value-less row: 'Tmax'</li><li>dropped value-less row: 'Vss'</li><li>dropped value-less row: 'Cl'</li><li>salvaged Q57 ('elimination t1/2'=13.95) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Doxycycline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>base model from table(s) without population columns (Sartini_2021:other_prose, Sartini_2021:results_prose, jvp13002-tbl-0001:footnote); populations iv geometric mean, po geometric mean kept as separate records</li><li>skipped review gap-fill of CL from Chapuis_2021: its label names a different analyte ('dxc') — 'Clearance of DXC was estimated at'</li><li>gap-filled Q61 (V) from Nuvolone_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Doxycycline_Sartini2021_reference;
