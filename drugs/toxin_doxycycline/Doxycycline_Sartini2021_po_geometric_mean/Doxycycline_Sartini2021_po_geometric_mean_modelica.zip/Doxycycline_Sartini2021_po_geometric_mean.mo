// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Doxycycline_Sartini2021_po_geometric_mean
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {48060.0},
    MM = 0.44439999999999996,
    adminMass = 0.0014,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxycycline</td></tr><tr><td>population:</td><td>Ten geese</td></tr><tr><td>source_paper:</td><td>Sartini_2021</td></tr><tr><td>measured_compound:</td><td>Doxycycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>jvp13002-tbl-0001</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>doxycycline 444.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>conflicting source units for 'AUC(0-t)': [{'unit': 'μg h/ml', 'source': 'Sartini_2021_table_1:row0:col1', 'scope': 'unit_column'}, {'unit': '0-t', 'source': 'Sartini_2021_table_1:row0:col0', 'scope': 'label'}]</li><li>conflicting source units for 'AUC(0-inf)': [{'unit': 'μg h/ml', 'source': 'Sartini_2021_table_1:row1:col1', 'scope': 'unit_column'}, {'unit': '0-inf', 'source': 'Sartini_2021_table_1:row1:col0', 'scope': 'label'}]</li><li>dropped duplicate Q88 ('AUC(0-inf)', value '131.2') — already have one for this compound</li><li>dropped value-less row: 'Vss'</li><li>dropped value-less row: 'Cl'</li><li>implicit units: 'AUC(0-t)' → µg·h/mL (from the popPK convention: 'The paper reports clearance (Cl) in ml/g/h and volume of distribution (Vss) in ml/g for geese (a low body weight species')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Doxycycline</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'po geometric mean' subgroup of Sartini_2021 (paper reports 2 populations: iv geometric mean, po geometric mean)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q61 (V) from Nuvolone_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Chapuis_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 518.4));
end Doxycycline_Sartini2021_po_geometric_mean;
