model Topiramate_Ahmed2015_PD_cowa
  "linear exposure-response sweep — Ahmed_2015 :: COWA (phonemic generative fluency scores as measured by the Controlled Oral Word Association (COWA) test)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 14.5   "[% per mg l(-1)]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About topiramate</h4><p>Topiramate is an anticonvulsant used to treat epilepsy and seizures, and also migraine; it has additionally been used for pain, bipolar disorder, and other conditions. It is an approved medicine used widely for epilepsy and migraine prevention, and is also classed as a centrally acting antiobesity product.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q221174\">Wikidata Q221174</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Topiramate_Ahmed2015_PD_cowa</h4><p>The steady-state exposure-response curve of Ahmed GF et al., <i>British journal of clinical pharmacology 79(5):820–830</i> 2015 (<a href=\"https://doi.org/10.1111/bcp.12556\">doi:10.1111/bcp.12556</a>) — phonemic generative fluency scores as measured by the Controlled Oral Word Association (COWA) test against topiramate mg l(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       14.5 % per mg l(-1) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg l(-1) of topiramate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Topiramate_Ahmed2015_PD_cowa;
