model Topiramate_Lim2016_PD_sdmt
  "emax exposure-response sweep — Lim_2016 :: SDMT (Symbol-Digit Modalities Test score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.255,  // [1; % × 0.01]
    EC50 = 0.00285,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 29, Interval = 0.058),
    Documentation(info = "<html><body><!-- drug-about --><h4>About topiramate</h4><p>Topiramate is an anticonvulsant used to treat epilepsy and seizures, and also migraine; it has additionally been used for pain, bipolar disorder, and other conditions. It is an approved medicine used widely for epilepsy and migraine prevention, and is also classed as a centrally acting antiobesity product.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q221174\">Wikidata Q221174</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Topiramate_Lim2016_PD_sdmt</h4><p>The steady-state exposure-response curve of Lim CN et al., <i>Journal of clinical pharmacology 56(6):714–722</i> 2016 (<a href=\"https://doi.org/10.1002/jcph.646\">doi:10.1002/jcph.646</a>) — Symbol-Digit Modalities Test score against topiramate μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       25.5 %        maximal effect term (Imax, Q323)
  EC50  =       2.85 μg/mL    exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of topiramate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.85 μg/mL)  response -0.1275
  exposure -> infinity  response -0.255</pre></body></html>"));
end Topiramate_Lim2016_PD_sdmt;
