% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Meloxicam_Busch1995_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
