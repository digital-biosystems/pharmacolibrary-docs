// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Meloxicam_Coetzee2009_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {99144.0},
    MM = 0.3514,
    adminMass = 1.5e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>meloxicam</td></tr><tr><td>population:</td><td>Holstein calves</td></tr><tr><td>source_paper:</td><td>Coetzee_2009</td></tr><tr><td>measured_compound:</td><td>Meloxicam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>meloxicam 351.4 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'time' — extend the ontology if this is a real PK parameter (source ['Coetzee_2009:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Meloxicam</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL from Bekker_2018: its label names a different analyte ('oral') — 'The total clearance of oral meloxicam'</li><li>gap-filled Q61 (V) from Uslu_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end Meloxicam_Coetzee2009_reference;
