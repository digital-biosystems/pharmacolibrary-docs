function p = Clindamycin_Pfaffendorf2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clindamycin   source: Pfaffendorf_2026 / reference   route: oral
  p.name  = 'Clindamycin_Pfaffendorf2026_reference_params';
  p.drug  = 'clindamycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 248.0;                % central volume [L]
  p.CL = 58.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.698;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
