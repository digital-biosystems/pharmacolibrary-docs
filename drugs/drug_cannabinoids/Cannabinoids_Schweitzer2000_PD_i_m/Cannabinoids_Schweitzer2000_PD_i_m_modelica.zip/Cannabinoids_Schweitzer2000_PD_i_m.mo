model Cannabinoids_Schweitzer2000_PD_i_m
  "emax exposure-response sweep — Schweitzer_2000 :: I M (IM)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.45,  // [1; % × 0.01]
    EC50 = 0.6,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 6, Interval = 0.012),
    Documentation(info = "<html><body><h4>Cannabinoids_Schweitzer2000_PD_i_m</h4><p>The steady-state exposure-response curve of Schweitzer P, <i>The Journal of neuroscience : the official journal of the Society for Neuroscience 20(1):51–58</i> 2000 (<a href=\"https://doi.org/10.1523/JNEUROSCI.20-01-00051.2000\">doi:10.1523/JNEUROSCI.20-01-00051.2000</a>) — IM [% of control] against cannabinoids M — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         45 %        maximal effect term (maximum inhibition, Q323)
  EC50  =        0.6 M        exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of cannabinoids per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.6 M)  response -0.225
  exposure -> infinity  response -0.45</pre></body></html>"));
end Cannabinoids_Schweitzer2000_PD_i_m;
