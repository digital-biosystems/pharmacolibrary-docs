model Cannabinoids_Eichler2023_reference
  parameter Real Cl_ref = 2.9166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0581 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.00045180722891566266,
    k21 = 1.1974327042820194e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cannabinoids</td></tr><tr><td>population:</td><td>horses</td></tr><tr><td>source_paper:</td><td>Eichler_2023</td></tr><tr><td>measured_compound:</td><td>cannabidiol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab4</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Tk0 (h)' — extend the ontology if this is a real PK parameter (source ['tab4:row2:col1', 'tab4:row2:col2', 'tab4:row2:col3'])</li><li>dropped unlinked row (NIL): 'a' — extend the ontology if this is a real PK parameter (source ['tab4:row10:col1', 'tab4:row10:col2', 'tab4:row10:col3'])</li><li>dropped unlinked row (NIL): 'b' — extend the ontology if this is a real PK parameter (source ['tab4:row11:col1', 'tab4:row11:col2', 'tab4:row11:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cannabidiol</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>review gap-fill skipped: this record measures 'cannabidiol', not cannabinoids — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cannabinoids_Eichler2023_reference;
