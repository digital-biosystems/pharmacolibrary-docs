function p = Cannabinoids_Eichler2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cannabinoids   source: Eichler_2023 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Cannabinoids_Eichler2023_reference_params';
  p.drug  = 'cannabinoids';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 58.1;                % central volume [L]
  p.CL = 10.5;                % clearance [L/h]
  p.Vp = [21921.9];             % peripheral volumes [L]
  p.Q  = [94.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
