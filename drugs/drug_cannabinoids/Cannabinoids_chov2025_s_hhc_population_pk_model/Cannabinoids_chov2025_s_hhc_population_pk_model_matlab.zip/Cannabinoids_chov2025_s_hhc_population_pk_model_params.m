function p = Cannabinoids_chov2025_s_hhc_population_pk_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cannabinoids   source: Šíchová_2025 / s_hhc_population_pk_model   route: oral
  % estimated (absent from source): dose
  p.name  = 'Cannabinoids_chov2025_s_hhc_population_pk_model_params';
  p.drug  = 'cannabinoids';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.9259;                % central volume [L]
  p.CL = 3.7321;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.41;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.49;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
