model Cannabinoids_chov2025_s_hhc_population_pk_model
  parameter Real Cl_ref = 1.0366944444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0019259 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00011388888888888888,
    Tlag = 1764.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cannabinoids</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Šíchová_2025</td></tr><tr><td>measured_compound:</td><td>hexahydrocannabinol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>TB1</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hexahydrocannabinol</li><li>population split: 's-hhc population pk model' subgroup of Šíchová_2025 (paper reports 2 populations: r-hhc population pk model, s-hhc population pk model)</li><li>review gap-fill skipped: this record measures 'hexahydrocannabinol', not cannabinoids — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cannabinoids_chov2025_s_hhc_population_pk_model;
