model Cannabinoids_Noble2019_PD_cb1
  "sigmoid_emax exposure-response sweep — Noble_2019 :: CB1 (CB1 receptor activation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.988,  // [1; % × 0.01]
    EC50 = 74.1,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 750, Interval = 1.5),
    Documentation(info = "<html><body><h4>Cannabinoids_Noble2019_PD_cb1</h4><p>The steady-state exposure-response curve of Noble C et al., <i>Drug testing and analysis 11(3):501–511</i> 2019 (<a href=\"https://doi.org/10.1002/dta.2517\">doi:10.1002/dta.2517</a>) — CB1 receptor activation [%] against synthetic cannabinoids nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       98.8 %        maximal effect term (Emax, Q320)
  EC50  =       74.1 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of synthetic cannabinoids per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (74.1 nM)  response 0.494
  exposure -> infinity  response 0.988</pre></body></html>"));
end Cannabinoids_Noble2019_PD_cb1;
