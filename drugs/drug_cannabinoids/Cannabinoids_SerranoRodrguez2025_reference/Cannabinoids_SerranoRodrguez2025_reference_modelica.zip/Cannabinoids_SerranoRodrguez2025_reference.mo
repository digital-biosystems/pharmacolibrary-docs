model Cannabinoids_SerranoRodrguez2025_reference
  parameter Real Cl_ref = 3.247222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 4.927983689179257 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    k12 = 4.0584549912199385e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cannabinoids</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Serrano-Rodríguez_2025</td></tr><tr><td>measured_compound:</td><td>cannabinoids</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Serrano-Rodríguez_2025) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cannabinoids_SerranoRodrguez2025_reference;
