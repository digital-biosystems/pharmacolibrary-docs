function p = Cannabinoids_SerranoRodrguez2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cannabinoids   source: Serrano-Rodríguez_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Cannabinoids_SerranoRodrguez2025_reference_params';
  p.drug  = 'cannabinoids';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4927.983689;                % central volume [L]
  p.CL = 116.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
