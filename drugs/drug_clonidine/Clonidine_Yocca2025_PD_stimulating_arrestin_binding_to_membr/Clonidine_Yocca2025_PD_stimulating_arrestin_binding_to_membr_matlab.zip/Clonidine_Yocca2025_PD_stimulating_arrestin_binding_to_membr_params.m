function p = Clonidine_Yocca2025_PD_stimulating_arrestin_binding_to_membr_params()
% Clonidine_Yocca2025_PD_stimulating_arrestin_binding_to_membr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clonidine Yocca_2025::stimulating_arrestin_binding_to_membranes_expressing_human_2A_2B_or_2C_receptors: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response stimulating β-arrestin binding to membranes expressing human α2A, α2B or α2C receptors in its own unit. Driver: Clonidine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.93;
p.EC50 = 13.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
