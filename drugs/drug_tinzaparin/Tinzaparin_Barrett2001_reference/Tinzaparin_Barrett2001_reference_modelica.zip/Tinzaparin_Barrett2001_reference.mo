model Tinzaparin_Barrett2001_reference
  parameter Real Cl_ref = 3.4222222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006860000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tinzaparin</h4><p>Tinzaparin is a low molecular weight heparin used as an anticoagulant, including in the treatment of pulmonary embolism. It is an approved medication and remains in clinical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20817252\">Wikidata Q20817252</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tinzaparin</td></tr><tr><td>population:</td><td>patients receiving tinzaparin for the prevention and treatment of deep vein thrombosis</td></tr><tr><td>source_paper:</td><td>Barrett_2001</td></tr><tr><td>measured_compound:</td><td>anti-Xa activity</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Clearance decreased' — extend the ontology if this is a real PK parameter (source ['Barrett_2001:abstract', 'Barrett_2001:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=anti-Xa activity</li><li>molar mass: no plausible PubChem entry for 'anti-Xa activity' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'tinzaparin' — its concentrations stay mass-only</li><li>molar mass: none found for 'anti-Xa activity' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tinzaparin_Barrett2001_reference;
