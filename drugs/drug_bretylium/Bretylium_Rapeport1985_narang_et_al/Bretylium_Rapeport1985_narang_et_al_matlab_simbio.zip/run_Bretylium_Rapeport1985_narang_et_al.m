% Run (SimBiology): build model + dose, simulate 0..1680.0 h, plot.
p = Bretylium_Rapeport1985_narang_et_al_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1680.0);
