function p = Bretylium_Rapeport1985_anderson_et_al_1980b_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bretylium   source: Rapeport_1985 / anderson_et_al_1980b   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Bretylium_Rapeport1985_anderson_et_al_1980b_params';
  p.drug  = 'bretylium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 427.0;                % central volume [L]
  p.CL = 0.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
