model Bretylium_Rapeport1985_anderson_et_al_1980b
  parameter Real Cl_ref = 2.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.427 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.243168,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bretylium</h4><p>Bretylium is a class III antiarrhythmic agent used to treat ventricular fibrillation and heart conduction disease. It is an approved drug, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420026\">Wikidata Q420026</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bretylium</td></tr><tr><td>population:</td><td>adults with ventricular tachyarrhythmias</td></tr><tr><td>source_paper:</td><td>Rapeport_1985</td></tr><tr><td>measured_compound:</td><td>bretylium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table iii</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>bretylium 243.168 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'anderson et al. (1980b)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'anderson et al. (1980b)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'No. of subjects' — extend the ontology if this is a real PK parameter (source ['Rapeport_1985_table_p4_1:row0:col2'])</li><li>dropped unlinked row (NIL): 'Dose (mg/kg)' — extend the ontology if this is a real PK parameter (source ['Rapeport_1985_table_p4_1:row1:col2'])</li><li>salvaged Q22 ('Creatinine clearance (ml/min)'=15) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('apparent volume of distribution ofbretylium'=6.1) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bretylium</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'anderson et al. (1980b)' subgroup of Rapeport_1985 (paper reports 3 populations: anderson et al. (1980b), garret et al. (1982), narang et al. (1980))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Bretylium_Rapeport1985_anderson_et_al_1980b;
