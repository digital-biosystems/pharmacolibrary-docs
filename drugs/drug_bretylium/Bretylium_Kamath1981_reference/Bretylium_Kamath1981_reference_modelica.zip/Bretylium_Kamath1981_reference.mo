model Bretylium_Kamath1981_reference
  parameter Real Cl_ref = 3.752777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00014916666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bretylium</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kamath_1981</td></tr><tr><td>measured_compound:</td><td>bretylium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bretylium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Greenberg_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bretylium_Kamath1981_reference;
