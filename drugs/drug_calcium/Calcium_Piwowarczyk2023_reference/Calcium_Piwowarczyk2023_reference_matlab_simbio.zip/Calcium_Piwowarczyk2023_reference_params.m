function p = Calcium_Piwowarczyk2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: calcium   source: Piwowarczyk_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Calcium_Piwowarczyk2023_reference_params';
  p.drug  = 'calcium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.62;                % central volume [L]
  p.CL = 1.15;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.319;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
