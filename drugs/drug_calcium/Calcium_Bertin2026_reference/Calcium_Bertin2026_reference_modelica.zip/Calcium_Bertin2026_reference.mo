model Calcium_Bertin2026_reference
  parameter Real Cl_ref = 5.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0301 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.040078,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About calcium</h4><p>Calcium is used as a dietary mineral supplement, often combined with vitamins or with bone-disease medicines such as bisphosphonates. It is widely available, appears on the WHO essential medicines list, and is also classified as a nutraceutical.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q706\">Wikidata Q706</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>calcium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bertin_2026</td></tr><tr><td>measured_compound:</td><td>calcium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>calcium 40.078 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bertin_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Calcium_Bertin2026_reference;
