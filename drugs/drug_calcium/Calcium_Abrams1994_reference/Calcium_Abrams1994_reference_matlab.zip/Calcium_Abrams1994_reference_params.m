function p = Calcium_Abrams1994_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: calcium   source: Abrams_1994 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Calcium_Abrams1994_reference_params';
  p.drug  = 'calcium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 30.1;                % central volume [L]
  p.CL = 18.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.22;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.249;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
