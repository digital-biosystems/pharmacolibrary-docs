model Calcium_Abrams1994_reference
  parameter Real Cl_ref = 5.0555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0301 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 6.111111111111111e-05,
    Tlag = 896.4
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>calcium</td></tr><tr><td>population:</td><td>very-low-birth-weight infants</td></tr><tr><td>source_paper:</td><td>Abrams_1994</td></tr><tr><td>measured_compound:</td><td>calcium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Body weight (kg)' — extend the ontology if this is a real PK parameter (source ['Abrams_1994_table_1:row0:col1'])</li><li>dropped unlinked row (NIL): 'Total serum Ca (mg/dL)' — extend the ontology if this is a real PK parameter (source ['Abrams_1994_table_1:row1:col1'])</li><li>dropped unlinked row (NIL): 'Percent Ca absorption' — extend the ontology if this is a real PK parameter (source ['Abrams_1994_table_1:row3:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=calcium</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>gap-filled Q22 (CL) from Bertin_2026's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Bertin_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Cendrós_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Cendrós_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Calcium_Abrams1994_reference;
