// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model ChrysotileAsbestos_Bernstein2008_group_3_chrysotile_and_powd
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {190080.00000000003},
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>chrysotile_asbestos</td></tr><tr><td>population:</td><td>Wistar rats</td></tr><tr><td>source_paper:</td><td>Bernstein_2008</td></tr><tr><td>measured_compound:</td><td>Chrysotile asbestos fibers</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tbl4</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>chrysotile_asbestos 277.108 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '≤1 μm particles per cm3 air' — extend the ontology if this is a real PK parameter (source ['tbl4:row2:col2'])</li><li>dropped unlinked row (NIL): '>1 μm to ≤3 μm particles per cm3 air' — extend the ontology if this is a real PK parameter (source ['tbl4:row3:col2'])</li><li>dropped unlinked row (NIL): '>3 μm particles per cm3 air' — extend the ontology if this is a real PK parameter (source ['tbl4:row4:col2'])</li><li>salvaged Q57 ('clearance half-time of fibers L > 20 μm'=2.2) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Chrysotile asbestos fibers</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>status held at route_to_review — not promoted</li><li>population split: 'group 3, chrysotile and powderb' subgroup of Bernstein_2008 (paper reports 2 populations: group 2, chrysotile, group 3, chrysotile and powderb)</li><li>molar mass: no plausible PubChem entry for 'Chrysotile asbestos fibers' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'Chrysotile asbestos fibers' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 2073.6));
end ChrysotileAsbestos_Bernstein2008_group_3_chrysotile_and_powd;
