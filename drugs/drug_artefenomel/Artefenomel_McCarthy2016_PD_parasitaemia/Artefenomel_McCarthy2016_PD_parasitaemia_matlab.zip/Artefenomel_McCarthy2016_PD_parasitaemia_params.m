function p = Artefenomel_McCarthy2016_PD_parasitaemia_params()
% Artefenomel_McCarthy2016_PD_parasitaemia_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artefenomel McCarthy_2016::parasitaemia: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response parasitaemia in parasites/mL. Driver: artefenomel (pk_record).
p.E0 = 0.0;
p.Emax = -5.555555555555556e-05;
p.EC50 = 6.19e-06;
p.gamma = 2.03;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 62.0;
p.form = 'E0 + Emax*frac';
end
