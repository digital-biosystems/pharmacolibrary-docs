model Artefenomel_McCarthy2016_PD_parasitaemia
  "sigmoid_emax exposure-response sweep — McCarthy_2016 :: parasitaemia (parasitaemia)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.55555555556e-05,  // [1/s; 1/h × 0.000277778]
    EC50 = 6.19e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.03,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 62, Interval = 0.124),
    Documentation(info = "<html><body><h4>Artefenomel_McCarthy2016_PD_parasitaemia</h4><p>The steady-state exposure-response curve of McCarthy JS et al., <i>The Journal of antimicrobial chemotherapy 71(9):2620–2627</i> 2016 (<a href=\"https://doi.org/10.1093/jac/dkw174\">doi:10.1093/jac/dkw174</a>) — parasitaemia [parasites/mL] against artefenomel ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        0.2 1/h      maximal effect term (maximum parasite kill rate, Q323)
  EC50  =       6.19 ng/mL    exposure at half of the maximal effect term (artefenomel concentration resulting in 50% of the maximum parasite kill rate, Q321)
  gamma =       2.03          Hill coefficient (Hill coefficient (governing the sigmoidicity of the concentration–kill rate relationship), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of artefenomel per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.19 ng/mL)  response -2.778e-05
  exposure -> infinity  response -5.556e-05</pre></body></html>"));
end Artefenomel_McCarthy2016_PD_parasitaemia;
