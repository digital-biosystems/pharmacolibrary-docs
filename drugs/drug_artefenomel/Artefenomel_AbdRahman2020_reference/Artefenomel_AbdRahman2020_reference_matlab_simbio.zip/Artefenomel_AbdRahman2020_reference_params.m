function p = Artefenomel_AbdRahman2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: artefenomel   source: Abd-Rahman_2020 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Artefenomel_AbdRahman2020_reference_params';
  p.drug  = 'artefenomel';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2930.0;                % central volume [L]
  p.CL = 54.6;                % clearance [L/h]
  p.Vp = [4700.0];             % peripheral volumes [L]
  p.Q  = [47.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.943;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
