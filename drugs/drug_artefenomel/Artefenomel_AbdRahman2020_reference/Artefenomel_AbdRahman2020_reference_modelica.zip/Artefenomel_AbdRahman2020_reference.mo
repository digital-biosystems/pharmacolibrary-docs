model Artefenomel_AbdRahman2020_reference
  parameter Real Cl_ref = 1.5166666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.46962200000000004,
    adminMass = 0.0001,
    ka = 0.0002619444444444444,
    Tlag = 0.0,
    k12 = 0.0002520833333333333,
    k21 = 3.893178893178893e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>artefenomel</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Abd-Rahman_2020</td></tr><tr><td>measured_compound:</td><td>artefenomel</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>artefenomel 469.622 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Abd-Rahman_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Artefenomel_AbdRahman2020_reference;
