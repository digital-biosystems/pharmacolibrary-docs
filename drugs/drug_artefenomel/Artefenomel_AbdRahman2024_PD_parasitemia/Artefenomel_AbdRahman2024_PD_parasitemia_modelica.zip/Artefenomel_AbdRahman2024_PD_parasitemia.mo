model Artefenomel_AbdRahman2024_PD_parasitemia
  "sigmoid_emax exposure-response sweep — Abd-Rahman_2024 :: parasitemia (parasitemia)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.38888888889e-05,  // [1/s; 1/h × 0.000277778]
    EC50 = 2.89e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 29, Interval = 0.058),
    Documentation(info = "<html><body><h4>Artefenomel_AbdRahman2024_PD_parasitemia</h4><p>The steady-state exposure-response curve of Abd-Rahman AN et al., <i>BMC medicine 22(1):563</i> 2024 (<a href=\"https://doi.org/10.1186/s12916-024-03787-0\">doi:10.1186/s12916-024-03787-0</a>) — parasitemia against artefenomel ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.194 1/h      maximal effect term (Emax, Q323)
  EC50  =       2.89 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of artefenomel per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.89 ng/mL)  response -2.694e-05
  exposure -> infinity  response -5.389e-05</pre></body></html>"));
end Artefenomel_AbdRahman2024_PD_parasitemia;
