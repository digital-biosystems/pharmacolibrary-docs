function p = Artefenomel_AbdRahman2024_PD_parasitemia_params()
% Artefenomel_AbdRahman2024_PD_parasitemia_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artefenomel Abd-Rahman_2024::parasitemia: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response parasitemia in its own unit. Driver: artefenomel (cited_pk).
p.E0 = 0.0;
p.Emax = -5.388888888888889e-05;
p.EC50 = 2.89e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 29.0;
p.form = 'E0 + Emax*frac';
end
