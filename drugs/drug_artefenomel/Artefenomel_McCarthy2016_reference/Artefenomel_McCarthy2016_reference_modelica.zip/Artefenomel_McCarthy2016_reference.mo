model Artefenomel_McCarthy2016_reference
  parameter Real Cl_ref = 2.5833333333333332e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.189 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.46962200000000004,
    adminMass = 0.0001,
    ka = 4.9999999999999996e-05,
    Tlag = 0.0,
    k12 = 1.866549088771311e-05,
    k21 = 2.2427067881613333e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>artefenomel</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>McCarthy_2016</td></tr><tr><td>measured_compound:</td><td>artefenomel</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>artefenomel 469.622 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (McCarthy_2016) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Artefenomel_McCarthy2016_reference;
