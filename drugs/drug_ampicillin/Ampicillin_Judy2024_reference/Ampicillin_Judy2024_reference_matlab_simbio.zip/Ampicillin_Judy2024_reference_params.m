function p = Ampicillin_Judy2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ampicillin   source: Judy_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ampicillin_Judy2024_reference_params';
  p.drug  = 'ampicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 75.2;                % central volume [L]
  p.CL = 82.4;                % clearance [L/h]
  p.Vp = [61.1];             % peripheral volumes [L]
  p.Q  = [20.9];             % inter-compartmental clearances [L/h]
  p.ka = 6.45;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
