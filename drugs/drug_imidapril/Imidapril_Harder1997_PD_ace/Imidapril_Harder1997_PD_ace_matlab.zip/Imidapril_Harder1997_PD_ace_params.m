function p = Imidapril_Harder1997_PD_ace_params()
% Imidapril_Harder1997_PD_ace_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% imidapril Harder_1997::ACE: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml -1 per second, in SI inside (kg/m3, s). Response ACE in u.l -1. Driver: imidaprilat (not_resolved).
p.E0 = 1.0461396134195999e-22;
p.Emax = -7.306371903247999e-23;
p.EC50 = 2.7e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 27.0;
p.form = 'E0 + Emax*frac';
end
