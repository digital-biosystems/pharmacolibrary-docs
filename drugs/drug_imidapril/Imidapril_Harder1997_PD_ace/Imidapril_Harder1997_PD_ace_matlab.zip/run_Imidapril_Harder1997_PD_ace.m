% run_Imidapril_Harder1997_PD_ace  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Imidapril_Harder1997_PD_ace_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng ml -1]'); ylabel('response [u.l -1]'); title('Imidapril_Harder1997_PD_ace', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Imidapril_Harder1997_PD_ace.csv');
