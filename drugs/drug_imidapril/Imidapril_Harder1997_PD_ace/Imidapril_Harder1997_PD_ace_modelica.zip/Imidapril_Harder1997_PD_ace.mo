model Imidapril_Harder1997_PD_ace
  "emax exposure-response sweep — Harder_1997 :: ACE (ACE-activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.04613961342e-22,      // [kg/m3; u.l -1 × 1.66054e-24]
    Emax = -7.30637190325e-23,  // [kg/m3; u.l -1 × 1.66054e-24]
    EC50 = 2.7e-06,  // [kg/m3; ng ml -1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml -1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 27, Interval = 0.054),
    Documentation(info = "<html><body><!-- drug-about --><h4>About imidapril</h4><p>Imidapril is an ACE inhibitor used to treat arterial hypertension. It is not authorised in the European Union and is considered investigational in major drug databases, though it has been marketed in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1041804\">Wikidata Q1041804</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Imidapril_Harder1997_PD_ace</h4><p>The steady-state exposure-response curve of Harder S et al., <i>British journal of clinical pharmacology 43(5):475–480</i> 1997 (<a href=\"https://doi.org/10.1046/j.1365-2125.1997.00588.x\">doi:10.1046/j.1365-2125.1997.00588.x</a>) — ACE-activity [u.l -1] against imidaprilat ng ml -1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         63 u.l -1   drug-free response (baseline) (E0, Q324)
  Emax  =         44 u.l -1   maximal effect term (E max, Q323)
  EC50  =        2.7 ng ml -1 exposure at half of the maximal effect term (Ec 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml -1 of imidaprilat per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.046e-22   (drug-free)
  exposure = EC50 (2.7 ng ml -1)  response 6.808e-23
  exposure -> infinity  response 3.155e-23</pre></body></html>"));
end Imidapril_Harder1997_PD_ace;
