model Acotiamide_Yoshii2016_PD_acetylcholine
  "indirect_response_ii exposure-response sweep — Yoshii_2016 :: acetylcholine (name)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.756626506024,      // [1]
    Emax = 1,  // type II effect term
    EC50 = 1.79,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.00314/0.00415 = 0.7566) — the paper's stated baseline may differ
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 18, Interval = 0.036),
    Documentation(info = "<html><body><h4>Acotiamide_Yoshii2016_PD_acetylcholine</h4><p>The steady-state exposure-response curve of Yoshii K et al., <i>Pharmaceutical research 33(2):292–300</i> 2016 (<a href=\"https://doi.org/10.1007/s11095-015-1787-y\">doi:10.1007/s11095-015-1787-y</a>) — name against acotiamide μM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 0.756626506024          drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       1.79 μM       exposure at half of the maximal effect term (IC50 (μM) — Value, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μM of acotiamide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.7566   (drug-free)
  exposure = EC50 (1.79 μM)  response 1.513
  exposure -> infinity  response inf</pre></body></html>"));
end Acotiamide_Yoshii2016_PD_acetylcholine;
