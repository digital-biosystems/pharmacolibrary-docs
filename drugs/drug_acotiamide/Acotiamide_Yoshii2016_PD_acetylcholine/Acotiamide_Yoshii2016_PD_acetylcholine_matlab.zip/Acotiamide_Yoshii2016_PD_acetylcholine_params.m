function p = Acotiamide_Yoshii2016_PD_acetylcholine_params()
% Acotiamide_Yoshii2016_PD_acetylcholine_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% acotiamide Yoshii_2016::acetylcholine: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response acetylcholine in its own unit. Driver: acotiamide (conc_no_pk).
p.E0 = 0.7566265060240964;
p.Emax = 1.0;
p.EC50 = 1.79;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 18.0;
p.form = 'E0/(1 - Emax*frac)';
end
