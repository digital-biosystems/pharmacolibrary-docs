function p = AlphaTocopherol_Hidiroglou1994_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alpha_tocopherol   source: Hidiroglou_1994 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'AlphaTocopherol_Hidiroglou1994_reference_params';
  p.drug  = 'alpha_tocopherol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 635.6;                % central volume [L]
  p.CL = 570.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.04;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
