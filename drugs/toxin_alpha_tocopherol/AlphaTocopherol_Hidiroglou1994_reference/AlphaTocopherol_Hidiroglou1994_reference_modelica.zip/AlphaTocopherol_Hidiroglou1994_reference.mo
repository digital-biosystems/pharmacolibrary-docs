model AlphaTocopherol_Hidiroglou1994_reference
  parameter Real Cl_ref = 0.00015847222222222223 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6355999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alpha_tocopherol</td></tr><tr><td>population:</td><td>ruminally cannulated wethers</td></tr><tr><td>source_paper:</td><td>Hidiroglou_1994</td></tr><tr><td>measured_compound:</td><td>tritiated D-alpha-tocopherol and tritiated D-alpha-tocopheryl succinate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alpha_tocopherol 430.717 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tritiated D-alpha-tocopherol and tritiated D-alpha-tocopheryl succinate</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'tritiated D-alpha-tocopherol and tritiated D-alpha-tocopheryl succinate' ('tritiated D-alpha-tocopherol and tritiated D-alpha-tocopheryl succinate') — left in mass units</li><li>molar mass: none found for 'tritiated D-alpha-tocopherol and tritiated D-alpha-tocopheryl succinate' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Chen_2018's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Chen_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (disposition incomplete — no disposition parameter from this paper; review-gap-filled from other paper(s): Chen_2018 — borrowed values do not complete its disposition core)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AlphaTocopherol_Hidiroglou1994_reference;
