% Run: build params, simulate 0..4320.0 h, plot + save AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.m
here = fileparts(mfilename('fullpath'));
p = AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales_params();
out = simulate_pk(p, 0:0.05:4320.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('alpha_tocopherol — Saldanha_2023 (iv_bolus)');
print(fig, fullfile(here, 'AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.json'), 'w');
try
  s.model = 'AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.png, AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.csv, AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales.json\n');
