function p = AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alpha_tocopherol   source: Saldanha_2023 / step_1_admet_predictor_vales   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'AlphaTocopherol_Saldanha2023_step_1_admet_predictor_vales_params';
  p.drug  = 'alpha_tocopherol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 635.6;                % central volume [L]
  p.CL = 0.242;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 9548.944;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
