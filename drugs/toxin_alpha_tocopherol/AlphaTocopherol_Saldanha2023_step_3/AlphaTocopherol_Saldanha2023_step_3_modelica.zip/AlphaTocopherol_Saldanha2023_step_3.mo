model AlphaTocopherol_Saldanha2023_step_3
  parameter Real Cl_ref = 2.4083333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 2.298 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43071699999999996,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alpha_tocopherol</td></tr><tr><td>population:</td><td>30-year-old American man</td></tr><tr><td>source_paper:</td><td>Saldanha_2023</td></tr><tr><td>measured_compound:</td><td>Alpha-Tocopherol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-02313-t007</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Alpha-Tocopherol 430.717 g/mol (pubchem); alpha_tocopherol 430.717 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'FDp (%)' — extend the ontology if this is a real PK parameter (source ['Saldanha_2023_table_7:row3:col2', 'Saldanha_2023_table_7:row3:col3', 'Saldanha_2023_table_7:row3:col4', 'Saldanha_2023_table_7:row3:col5', 'Saldanha_2023_table_7:row3:col6'])</li><li>unit_dimension_unknown: 'ug-h/mL' (AUC∞)</li><li>unit_dimension_unknown: 'ug-h/mL' (AUCt)</li><li>dropped duplicate Q32 ('CMax Liver (µg/mL)', value '0.24477') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Total simulation time (h)' — extend the ontology if this is a real PK parameter (source ['Saldanha_2023_table_7:row10:col4'])</li><li>salvaged Q22 ('CL'=0.867) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=2298) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('T1/2'=1837) from results prose — parameter table was unreadable</li><li>implicit units: 'AUC0-inf (ug-h/mL)' — the LLM proposed 'ug-h/mL', whose dimension does not fit Q17; left unset</li><li>implicit units: 'AUC0-t (ug-h/mL)' — the LLM proposed 'ug-h/mL', whose dimension does not fit Q19; left unset</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Alpha-Tocopherol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>status held at route_to_review — not promoted</li><li>population split: 'step 3' subgroup of Saldanha_2023 (paper reports 3 populations: step 1 / admet predictor vales, step 2 / experimental data, step 3)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end AlphaTocopherol_Saldanha2023_step_3;
