function p = AlphaTocopherol_Saldanha2023_step_3_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alpha_tocopherol   source: Saldanha_2023 / step_3   route: iv_bolus
  p.name  = 'AlphaTocopherol_Saldanha2023_step_3_params';
  p.drug  = 'alpha_tocopherol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2298.0;                % central volume [L]
  p.CL = 0.867;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.0203;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
