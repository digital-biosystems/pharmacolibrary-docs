model AlphaTocopherol_Chen2015_PD_rr
  "linear exposure-response sweep — Chen_2015 :: RR (risk of bladder cancer)"
  extends Pharmacolibrary.Pharmacodynamic.LinearSweep(
    E0 = 0,      // [1]
    slope = -0.16,  // [(1)/(kg/m3); log(RR)/(mg/dL) × 100]
    exposure_per_s = 0.01);   // 1 mg/dL per second
  // slope_unit_assumed: slope unit 'log(RR)/(mg/dL)' read as response per mg/dL
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>AlphaTocopherol_Chen2015_PD_rr</h4><p>The steady-state exposure-response curve of Chen F et al., <i>Scientific reports 5:9599</i> 2015 (<a href=\"https://doi.org/10.1038/srep09599\">doi:10.1038/srep09599</a>) — risk of bladder cancer against α-Tocopherol mg/dL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    -0.0016 log(RR)/(mg/dL) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.LinearSweep\">LinearSweep</a>; this model only supplies the numbers. The x axis is one mg/dL of α-Tocopherol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end AlphaTocopherol_Chen2015_PD_rr;
