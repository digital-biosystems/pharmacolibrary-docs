function p = AlphaTocopherol_Chen2015_PD_rr_params()
% AlphaTocopherol_Chen2015_PD_rr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alpha_tocopherol Chen_2015::RR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/dL per second, in SI inside (kg/m3, s). Response RR in its own unit. Driver: α-Tocopherol (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.16000000000000003;
p.exposure_per_s = 0.01;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
