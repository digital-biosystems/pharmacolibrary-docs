% run_AlphaTocopherol_Chen2015_PD_rr  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = AlphaTocopherol_Chen2015_PD_rr_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/dL]'); ylabel('response []'); title('AlphaTocopherol_Chen2015_PD_rr', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'AlphaTocopherol_Chen2015_PD_rr.csv');
