model AlphaTocopherol_Saldanha2023_step_2_experimental_data
  parameter Real Cl_ref = 6.75e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6355999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43071699999999996,
    adminMass = 0.00015
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alpha_tocopherol</td></tr><tr><td>population:</td><td>30-year-old American man</td></tr><tr><td>source_paper:</td><td>Saldanha_2023</td></tr><tr><td>measured_compound:</td><td>Alpha-Tocopherol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-02313-t007</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>Alpha-Tocopherol 430.717 g/mol (pubchem); alpha_tocopherol 430.717 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '20 nm, Radius: 10 nm' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-15-02313-t007:row2:col2'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL(L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Alpha-Tocopherol</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>population split: 'step 2 / experimental data' subgroup of Saldanha_2023 (paper reports 3 populations: step 1 / admet predictor vales, step 2 / experimental data, step 3)</li><li>gap-filled Q61 (V) from Chen_2018's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end AlphaTocopherol_Saldanha2023_step_2_experimental_data;
