model AlphaTocopherol_Gao2019_reference
  parameter Real Cl_ref = 1.281388888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17654 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43071699999999996,
    adminMass = 1e-05,
    k12 = 3.77629243608625e-08
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>alpha_tocopherol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gao_2019</td></tr><tr><td>measured_compound:</td><td>alpha_tocopherol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alpha_tocopherol 430.717 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gao_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AlphaTocopherol_Gao2019_reference;
