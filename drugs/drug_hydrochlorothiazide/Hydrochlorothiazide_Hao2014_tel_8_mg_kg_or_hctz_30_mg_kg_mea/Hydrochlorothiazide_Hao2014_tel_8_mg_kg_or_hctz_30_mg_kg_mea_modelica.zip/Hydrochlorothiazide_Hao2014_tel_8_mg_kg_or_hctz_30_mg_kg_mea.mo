model Hydrochlorothiazide_Hao2014_tel_8_mg_kg_or_hctz_30_mg_kg_mea
  parameter Real Cl_ref = 3.952861111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.49069999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00014,
    ka = 0.0002916666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydrochlorothiazide</h4><p>Hydrochlorothiazide is a thiazide diuretic used to treat high blood pressure, heart failure, and fluid retention conditions such as nephrotic syndrome and nephrogenic diabetes insipidus. It is widely used, appears on the WHO list of essential medicines, and is available alone and in many fixed combinations with blood pressure drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423930\">Wikidata Q423930</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydrochlorothiazide</td></tr><tr><td>population:</td><td>spontaneously hypertensive rats</td></tr><tr><td>source_paper:</td><td>Hao_2014</td></tr><tr><td>measured_compound:</td><td>hydrochlorothiazide and telmisartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydrochlorothiazide 297.739 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hydrochlorothiazide and telmisartan</li><li>population split: 'tel (8 mg/kg) or hctz (30 mg/kg) mean' subgroup of Hao_2014 (paper reports 10 populations: hctz (30 mg/kg) mean, hctz (7.5 mg/kg) mean, tel (2 mg/kg) + hctz (7.5 mg/kg) mean, tel (2 mg/kg) and hctz (7.5 mg/kg) mean, tel (2 mg/kg) mean, tel (2 mg/kg) or hctz (7.5 mg/kg) mean, tel (8 mg/kg) + hctz (30 mg/kg) mean, tel (8 mg/kg) and hctz (30 mg/kg) mean, tel (8 mg/kg) mean, tel (8 mg/kg) or hctz (30 mg/kg) mean)</li><li>molar mass: none found for 'hydrochlorothiazide and telmisartan' — its concentrations stay mass-only</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=142.303 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydrochlorothiazide_Hao2014_tel_8_mg_kg_or_hctz_30_mg_kg_mea;
