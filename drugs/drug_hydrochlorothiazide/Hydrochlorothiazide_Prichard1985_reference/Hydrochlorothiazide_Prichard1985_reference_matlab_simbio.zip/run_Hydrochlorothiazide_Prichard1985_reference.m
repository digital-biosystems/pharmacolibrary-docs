% Run (SimBiology): build model + dose, simulate 0..35.0 h, plot.
p = Hydrochlorothiazide_Prichard1985_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 35.0);
