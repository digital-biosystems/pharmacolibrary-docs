model Hydrochlorothiazide_Kutumova2022_PD_pra
  "emax exposure-response sweep — Kutumova_2022 :: PRA (plasma renin activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -0.99,  // [1]
    EC50 = 1.9999999999999998e-05,  // [kg; mg × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 mg per second
  // off_target_driver: driver compound 'aliskiren' is not 'hydrochlorothiazide' nor one of its metabolites — the curve belongs to that compound's exposure (S12)
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 200, Interval = 0.4));
end Hydrochlorothiazide_Kutumova2022_PD_pra;
