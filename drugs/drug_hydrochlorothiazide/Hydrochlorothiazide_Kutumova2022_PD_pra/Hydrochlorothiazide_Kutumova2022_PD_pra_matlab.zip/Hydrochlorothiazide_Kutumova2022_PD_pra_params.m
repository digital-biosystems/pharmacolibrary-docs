function p = Hydrochlorothiazide_Kutumova2022_PD_pra_params()
% Hydrochlorothiazide_Kutumova2022_PD_pra_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hydrochlorothiazide Kutumova_2022::PRA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response PRA in its own unit. Driver: aliskiren (dose_only).
p.E0 = 0.0;
p.Emax = -0.99;
p.EC50 = 1.9999999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 200.0;
p.form = 'E0 + Emax*frac';
end
