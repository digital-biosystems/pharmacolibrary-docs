function p = Hydrochlorothiazide_Thoueille2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydrochlorothiazide   source: Thoueille_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Hydrochlorothiazide_Thoueille2023_reference_params';
  p.drug  = 'hydrochlorothiazide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2390.0;                % central volume [L]
  p.CL = 42.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
