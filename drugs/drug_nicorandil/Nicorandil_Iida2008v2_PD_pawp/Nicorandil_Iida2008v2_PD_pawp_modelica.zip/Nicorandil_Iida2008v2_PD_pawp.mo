model Nicorandil_Iida2008v2_PD_pawp
  "emax exposure-response sweep — Iida_2008_2 :: PAWP (pulmonary artery wedge pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 25.6,      // [mmHg]
    Emax = -11.7,  // [mmHg]
    EC50 = 0.423,  // [kg/m3; mg l -1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg l -1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4300, Interval = 8.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nicorandil</h4><p>Nicorandil is a vasodilator heart medicine used to treat angina (chest pain caused by reduced blood flow to the heart). It is not authorised in the European Union but remains in clinical use in some countries, where it is prescribed for cardiac patients.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q862989\">Wikidata Q862989</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Nicorandil_Iida2008v2_PD_pawp</h4><p>The steady-state exposure-response curve of Iida S et al., <i>British journal of clinical pharmacology 66(3):352–365</i> 2008 (<a href=\"https://doi.org/10.1111/j.1365-2125.2008.03257.x\">doi:10.1111/j.1365-2125.2008.03257.x</a>) — pulmonary artery wedge pressure [mmHg] against nicorandil mg l -1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       25.6 mmHg     drug-free response (baseline) (Baseline PAWP, Q324)
  Emax  =      -11.7 mmHg     maximal effect term (Maximum effect of nicorandil on PAWP, Q323)
  EC50  =        423 mg l -1  exposure at half of the maximal effect term (Nicorandil concentration at 50% of Emax, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg l -1 of nicorandil per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 25.6   (drug-free)
  exposure = EC50 (423 mg l -1)  response 19.75
  exposure -> infinity  response 13.9</pre></body></html>"));
end Nicorandil_Iida2008v2_PD_pawp;
