function p = Nicorandil_Iida2008v2_PD_pawp_params()
% Nicorandil_Iida2008v2_PD_pawp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nicorandil Iida_2008_2::PAWP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l -1 per second, in SI inside (kg/m3, s). Response PAWP in mmHg. Driver: nicorandil (pk_record).
p.E0 = 25.6;
p.Emax = -11.7;
p.EC50 = 0.42299999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4300.0;
p.form = 'E0 + Emax*frac';
end
