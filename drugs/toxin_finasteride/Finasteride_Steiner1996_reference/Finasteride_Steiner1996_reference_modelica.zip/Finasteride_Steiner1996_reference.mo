// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Finasteride_Steiner1996_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {21240.000000000004},
    MM = 0.372553,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>finasteride</td></tr><tr><td>population:</td><td>men treated for benign prostatic hyperplasia</td></tr><tr><td>source_paper:</td><td>Steiner_1996</td></tr><tr><td>measured_compound:</td><td>Finasteride</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>finasteride 372.553 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'prostate gland size reduction' — extend the ontology if this is a real PK parameter (source ['Steiner_1996:abstract'])</li><li>dropped value-less row: 'terminal elimination half-life (t1/2z)' (captured trailing unit 't1/2z' for child rows)</li><li>dropped unlinked row (NIL): 'serum DHT suppression duration' — extend the ontology if this is a real PK parameter (source ['Steiner_1996:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Finasteride</li><li>toxin: 1 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>toxin: elimination half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Villapalos-García_2023's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (a value printed only as a range — the record carries its midpoint)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 216.0));
end Finasteride_Steiner1996_reference;
