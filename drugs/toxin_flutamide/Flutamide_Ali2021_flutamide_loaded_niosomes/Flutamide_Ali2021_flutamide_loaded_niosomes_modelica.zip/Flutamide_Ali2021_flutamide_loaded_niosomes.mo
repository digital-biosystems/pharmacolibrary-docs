// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flutamide_Ali2021_flutamide_loaded_niosomes
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {9805.08},
    MM = 0.276214,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flutamide</td></tr><tr><td>population:</td><td>male rats</td></tr><tr><td>source_paper:</td><td>Ali_2021</td></tr><tr><td>measured_compound:</td><td>Flutamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-01741-t003</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>flutamide 276.214 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'X1'</li><li>dropped value-less row: 'X2'</li><li>dropped value-less row: 'X3'</li><li>dropped value-less row: 'X4'</li><li>dropped value-less row: 'X1X2, X1X3, X1X4, X2X3, X2X4 and X3X4'</li><li>dropped value-less row: 'X12, X22, X32 and X42'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flutamide</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>population split: 'flutamide loaded niosomes' subgroup of Ali_2021 (paper reports 2 populations: flutamide loaded niosomes, free flutamide suspension)</li><li>skipped review gap-fill of V2: primary is RETENTION (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is RETENTION (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Sharma_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Flutamide_Ali2021_flutamide_loaded_niosomes;
