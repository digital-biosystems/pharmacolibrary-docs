// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Flutamide_Sharma2020_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {5400.0},
    MM = 0.276214,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>flutamide</td></tr><tr><td>population:</td><td>rats and healthy adult human volunteers</td></tr><tr><td>source_paper:</td><td>Sharma_2020</td></tr><tr><td>measured_compound:</td><td>Flutamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>Flutamide 276.214 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'symbols' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: '–' (Kp)</li><li>unit_dimension_unknown: '–' (fu)</li><li>unit_dimension_unknown: '–' (fu)</li><li>dropped duplicate Q46 ('Unbound fraction in plasma (Flu-OH)', value '0.05') — already have one for this compound</li><li>dropped PD-category row 'Conc. at half maximum value' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Sharma_2020_table_1:row17:col3', 'Sharma_2020_table_1:row19:col3', 'Sharma_2020_table_1:row21:col3', 'Sharma_2020_table_1:row25:col3', 'Sharma_2020_table_1:row27:col3', 'Sharma_2020_table_1:row29:col3'])</li><li>salvaged Q57 ('half-life'=1.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Flutamide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — pbpk model — not a compartmental parent–metabolite model</li><li>toxin: half-life printed only as a range — the value is the range's midpoint; route to review</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=pbpk; 0/4 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Flutamide hydroxide (Flu-OH, M1)' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 172.8));
end Flutamide_Sharma2020_reference;
