model Tolbutamide_Shi2021_reference
  parameter Real Cl_ref = 2.3916666666666664e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1036 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27034800000000003,
    adminMass = 0.0015,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tolbutamide</h4><p>Tolbutamide is a sulfonylurea blood-glucose-lowering drug used to treat type 2 diabetes and maturity-onset diabetes of the young type 2, and it also serves as a diagnostic agent in tests for diabetes. It is an approved medication, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414275\">Wikidata Q414275</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolbutamide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shi_2021</td></tr><tr><td>measured_compound:</td><td>tolbutamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tolbutamide 270.348 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shi_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tolbutamide_Shi2021_reference;
