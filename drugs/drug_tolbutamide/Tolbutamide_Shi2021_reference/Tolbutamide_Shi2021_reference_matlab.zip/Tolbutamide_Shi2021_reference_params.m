function p = Tolbutamide_Shi2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tolbutamide   source: Shi_2021 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Tolbutamide_Shi2021_reference_params';
  p.drug  = 'tolbutamide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 103.6;                % central volume [L]
  p.CL = 86.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
