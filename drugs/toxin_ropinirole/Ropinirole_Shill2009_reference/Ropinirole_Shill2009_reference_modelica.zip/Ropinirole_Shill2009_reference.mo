model Ropinirole_Shill2009_reference
  parameter Real Cl_ref = 1.684732730527645e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.525 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.260381,
    adminMass = 2.5e-07,
    ka = 0.003,
    Tlag = 598.2
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ropinirole</td></tr><tr><td>population:</td><td>patients with Parkinson's disease</td></tr><tr><td>source_paper:</td><td>Shill_2009</td></tr><tr><td>measured_compound:</td><td>Ropinirole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ropinirole 260.381 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>salvaged Q61 ('Volume of distribution'=7.5) from results prose — parameter table was unreadable</li><li>salvaged Q57 ('Terminal half-life of ropinirole'=6) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Ropinirole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Adamiak-Giera_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Adamiak-Giera_2021's review values (primary lacked it)</li><li>derived CL=60.6504 L/h from ln2/t½z × V = CL (Q57 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Ropinirole_Shill2009_reference;
