function p = Ropinirole_AdamiakGiera2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ropinirole   source: Adamiak-Giera_2021 / reference   route: oral
  p.name  = 'Ropinirole_AdamiakGiera2021_reference_params';
  p.drug  = 'ropinirole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.4;                % central volume [L]
  p.CL = 48.96;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 10.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.166167;             % absorption lag [h]
  p.dose = 6.0;             % dose [mg]
end
