model Nivolumab_van2019_reference
  parameter Real Cl_ref = 2.194444444444445e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00747 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.7100000000000002e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nivolumab</h4><p>Nivolumab is an anti-PD-1 monoclonal antibody used to treat several cancers, including melanoma, lung, kidney, bladder, and head and neck cancers, Hodgkin lymphoma, and mesothelioma. It is widely used and authorised in the European Union, though one EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7041828\">Wikidata Q7041828</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nivolumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>van_2019</td></tr><tr><td>measured_compound:</td><td>nivolumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (van_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 12096000, Tolerance = 1e-9, Interval = 1));
end Nivolumab_van2019_reference;
