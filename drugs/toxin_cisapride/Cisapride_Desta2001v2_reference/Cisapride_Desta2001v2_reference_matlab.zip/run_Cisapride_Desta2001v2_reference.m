% Run: build params, simulate 0..24.0 h, plot every molecule + save Cisapride_Desta2001v2_reference.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Cisapride_Desta2001v2_reference.m
here = fileparts(mfilename('fullpath'));
p = Cisapride_Desta2001v2_reference_params();
out = simulate_network(p, 0:0.05:24.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('body burden [mg]');
title('cisapride — Desta_2001_2 (retention function)');
print(fig, fullfile(here, 'Cisapride_Desta2001v2_reference.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Cisapride_Desta2001v2_reference.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Cisapride_Desta2001v2_reference.json'), 'w');
try
  s.model = 'Cisapride_Desta2001v2_reference'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Cisapride_Desta2001v2_reference"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): peak=%.4g mg  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Cisapride_Desta2001v2_reference.png, Cisapride_Desta2001v2_reference.csv, Cisapride_Desta2001v2_reference.json\n');
