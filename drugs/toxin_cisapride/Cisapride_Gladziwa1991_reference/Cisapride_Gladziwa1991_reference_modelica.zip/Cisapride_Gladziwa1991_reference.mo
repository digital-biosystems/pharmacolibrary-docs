model Cisapride_Gladziwa1991_reference
  parameter Real Cl_ref = 6.3333333333333326e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.33599999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.46595,
    adminMass = 3e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisapride</td></tr><tr><td>population:</td><td>patients receiving hemodialysis</td></tr><tr><td>source_paper:</td><td>Gladziwa_1991</td></tr><tr><td>measured_compound:</td><td>Cisapride</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>Cisapride 465.95 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'before cisapride' (MRT)</li><li>unit_dimension_unknown: 'after cisapride' (MTT)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=Cisapride</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>toxin: 1 screen link(s) set aside — no transfer parameter and no metabolite row; one substance's kinetics</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 0/8 row label(s) assigned, 0 linked by role</li><li>molar mass: none found for 'Norcisapride' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C5 dimensioned parameter(s) without a unit: Q53, Q81 — no SI value to build from)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Cisapride_Gladziwa1991_reference;
