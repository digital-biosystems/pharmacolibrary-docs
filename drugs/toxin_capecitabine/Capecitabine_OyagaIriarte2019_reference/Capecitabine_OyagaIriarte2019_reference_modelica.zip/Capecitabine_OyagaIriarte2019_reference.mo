model Capecitabine_OyagaIriarte2019_reference
  parameter Real Cl_ref = 1.125e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.423 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.359354,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>capecitabine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Oyaga-Iriarte_2019</td></tr><tr><td>measured_compound:</td><td>capecitabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>capecitabine 359.354 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Oyaga-Iriarte_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 1));
end Capecitabine_OyagaIriarte2019_reference;
