// retention function (1 pool(s)) — R(t) = sum A_i exp(-ln2 t / Tb_i); burden, not
// concentration: the paper reports phases, no volume and no clearance.
model Capecitabine_Janssen2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.TK_Retention(
    nPool = 1,
    A = {1.0},
    Tb = {89118.92321485012},
    MM = 0.50213,
    adminMass = 1e-05,
    adminDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>capecitabine</td></tr><tr><td>population:</td><td>Patients with solid tumours</td></tr><tr><td>source_paper:</td><td>Janssen_2021</td></tr><tr><td>measured_compound:</td><td>5-fluorouridine 5'-triphosphate (FUTP)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>retention</td></tr><tr><td>result_var:</td><td>retainedFraction</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>retention, 1 pool(s): one pool, A = 1</td></tr><tr><td>molar_masses:</td><td>5-fluorouracil (5-FU) 130.078 g/mol (pubchem); 5-fluorouridine 5'-triphosphate (FUTP) 502.13 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=5-fluorouridine 5'-triphosphate (FUTP)</li><li>toxin: 2 screen link(s) set aside — the record holds only half-lives / rate constants, a retention function</li><li>topology: phase rates/half-lives with no volume or clearance — a retention function (TK_Retention)</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>row roles (LLM): model_class=compartmental; 1/1 row label(s) assigned, 1 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures &quot;5-fluorouridine 5'-triphosphate (FUTP)&quot;, not capecitabine — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1036.8));
end Capecitabine_Janssen2021_reference;
