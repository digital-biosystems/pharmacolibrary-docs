function p = Fluorouracil_Suthahar2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Suthahar_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fluorouracil_Suthahar2026_reference_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.0;                % central volume [L]
  p.CL = 79.0;                % clearance [L/h]
  p.Vp = [334.0];             % peripheral volumes [L]
  p.Q  = [19.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.551;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
