model Fluorouracil_Daryani2016_estimate_se
  parameter Real Cl_ref = 7.977222222222225e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0072660000000000025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.130078,
    adminMass = 0.0001,
    ka = 0.00015305555555555556,
    Tlag = 0.0,
    k12 = 0.00010582010582010582,
    k21 = 2.211166390270868e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorouracil</td></tr><tr><td>population:</td><td>children and young adults with recurrent/refractory ependymoma; mouse tumor-bearing CD1 nude mice</td></tr><tr><td>source_paper:</td><td>Daryani_2016</td></tr><tr><td>measured_compound:</td><td>Fluorouracil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412075-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluorouracil 130.078 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive' routed out of structural estimates ('Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fluorouracil</li><li>population split: 'estimate ± se' subgroup of Daryani_2016 (paper reports 2 populations: estimate ± se, terret)</li><li>gap-filled Q49 (kabs) from Booka_2016's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG from Hill_2020: its label names a different analyte ('tmax') — 'time shift of tmax of the free Pt'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fluorouracil_Daryani2016_estimate_se;
