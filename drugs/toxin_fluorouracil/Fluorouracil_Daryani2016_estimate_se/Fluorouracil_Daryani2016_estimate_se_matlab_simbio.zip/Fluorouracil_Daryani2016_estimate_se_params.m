function p = Fluorouracil_Daryani2016_estimate_se_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Daryani_2016 / estimate_se   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fluorouracil_Daryani2016_estimate_se_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.266;                % central volume [L]
  p.CL = 28.718;                % clearance [L/h]
  p.Vp = [34.773];             % peripheral volumes [L]
  p.Q  = [2.768];             % inter-compartmental clearances [L/h]
  p.ka = 0.551;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
