model Fluorouracil_Schmulenson2023_estimate
  parameter Real Cl_ref = 5.805555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0461 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00015305555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorouracil</td></tr><tr><td>population:</td><td>patients with cancer treated with fluorouracil-based chemotherapy</td></tr><tr><td>source_paper:</td><td>Schmulenson_2023</td></tr><tr><td>measured_compound:</td><td>Fluorouracil (5FU)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cam45118-tbl-0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluorouracil 130.078 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL5FU [%CV]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V5FU [%CV]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Residual variability [%CV]' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Additional error term [ng/ml]' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error term [%]' routed out of structural estimates ('Residual variability')</li><li>routed 'BSA effect on CL5FU' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fluorouracil (5FU)</li><li>population split: 'estimate' subgroup of Schmulenson_2023 (paper reports 2 populations: estimate, estimate (relative standard error, %))</li><li>molar mass: none found for 'Fluorouracil (5FU)' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Booka_2016's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG from Hill_2020: its label names a different analyte ('tmax') — 'time shift of tmax of the free Pt'</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fluorouracil_Schmulenson2023_estimate;
