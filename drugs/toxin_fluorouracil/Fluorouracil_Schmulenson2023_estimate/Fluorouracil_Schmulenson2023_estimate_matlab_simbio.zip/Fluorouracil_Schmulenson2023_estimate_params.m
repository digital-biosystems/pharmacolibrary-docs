function p = Fluorouracil_Schmulenson2023_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Schmulenson_2023 / estimate   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fluorouracil_Schmulenson2023_estimate_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.1;                % central volume [L]
  p.CL = 209.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.551;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
