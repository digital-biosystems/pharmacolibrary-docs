model Fluorouracil_Daher2014_final_model
  parameter Real Cl_ref = 5.9444444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.292 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.130078,
    adminMass = 0.0001,
    ka = 0.0005166666666666667,
    Tlag = 1116.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorouracil</td></tr><tr><td>population:</td><td>elderly patients (>=75 years) with breast or colorectal cancer, with younger adults (<75 years) as comparator</td></tr><tr><td>source_paper:</td><td>Daher_2014</td></tr><tr><td>measured_compound:</td><td>5-fluorouracil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5-fluorouracil 130.078 g/mol (pubchem); fluorouracil 130.078 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL 12 (L/h)', value '13.6') — already have one for this compound</li><li>dropped duplicate Q48 ('k 34 (h -1 )', value '6.0') — already have one for this compound</li><li>dropped duplicate Q47 ('θ 3', value '77.1') — already have one for this compound</li><li>dropped duplicate Q47 ('θ 4', value '0.77') — already have one for this compound</li><li>dropped 'ISV t lag (%)' → Q83: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a time — the row is a variability or a ratio, not the estimate</li><li>routed 'ISV V 1 (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'ISV CL 10 (%)' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>dropped 'ISV k 23 (%)' → Q302: unit '%' is a statistic (%, CV, RSE, shrinkage or fold), not a rate — the row is a variability or a ratio, not the estimate</li><li>routed 'ISV k 34 (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'ISV k 40 (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Capecitabine(µM)' — extend the ontology if this is a real PK parameter (source ['tab_2:row23:col1'])</li><li>dropped unlinked row (NIL): &quot;5' DFCR (µM)&quot; — extend the ontology if this is a real PK parameter (source ['tab_2:row24:col1'])</li><li>dropped unlinked row (NIL): &quot;5' DFUR (µM)&quot; — extend the ontology if this is a real PK parameter (source ['tab_2:row25:col1'])</li><li>dropped unlinked row (NIL): '5 FU (µM)' — extend the ontology if this is a real PK parameter (source ['tab_2:row26:col1'])</li><li>dropped unlinked row (NIL): '* agegroup=0 for <75 years patients and 1 for ≥75 years patients' — extend the ontology if this is a real PK parameter (source ['tab_2:row32:col0'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (V 1 (L)); Q22 (CL 10 (L/h))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fluorouracil_Daher2014_final_model;
