function p = Fluorouracil_Daher2014_final_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Daher_2014 / final_model   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Fluorouracil_Daher2014_final_model_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 292.0;                % central volume [L]
  p.CL = 214.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.86;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.31;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
