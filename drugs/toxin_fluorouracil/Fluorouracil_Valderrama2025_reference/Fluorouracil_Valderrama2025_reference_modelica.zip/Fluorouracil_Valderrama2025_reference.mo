// general-linear (1 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Fluorouracil_Valderrama2025_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 1, centralIdx = 1, F = 1,
    V = {0.0461},
    CLelim = {6.194444444444445e-05},
    nEdge = 0,
    edge = fill(0,0,2),
    CLedge = fill(0.0, 0)
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorouracil</td></tr><tr><td>population:</td><td>cancer patients (5-FU chemotherapy patients)</td></tr><tr><td>source_paper:</td><td>Valderrama_2025</td></tr><tr><td>measured_compound:</td><td>Fluorouracil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413313-tbl-0003</td></tr><tr><td>molar_masses:</td><td>Fluorouracil 130.078 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=Fluorouracil</li><li>topology: 1 first-order transfer(s) across 3 compounds → general_linear</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0] (site presystemic: 'Presystemic formation of SU12662 was modeled via a hypothetical enzyme compartment incorporated into the central compart')</li><li>row roles (LLM): model_class=compartmental; 0/20 row label(s) assigned, 0 linked by role</li><li>molar mass: LLM call failed (JSONDecodeError) — metabolites left in mass units</li><li>molar mass: none found for 'Sunitinib' — its concentrations stay mass-only</li><li>molar mass: none found for 'SU12662' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is GENERAL_LINEAR (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Booka_2016's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG from Hill_2020: its label names a different analyte ('tmax') — 'time shift of tmax of the free Pt'</li><li>engineer: built from a record validation left at needs_review (toxins) — not yet confirmed by a reviewer (C6_cl_magnitude failed (ratio None))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fluorouracil_Valderrama2025_reference;
