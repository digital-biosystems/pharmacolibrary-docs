model Artemisinin_Ali2022_reference
  parameter Real Cl_ref = 1.852777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.395 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00056,
    ka = 0.000586111111111111,
    Tlag = 0.0,
    k21 = 8.740546829552064e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About artemisinin</h4><p>Artemisinin is an antimalarial drug used to treat malaria. It is considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426921\">Wikidata Q426921</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>artemisinin</td></tr><tr><td>population:</td><td>Tanzanian children and adults with uncomplicated malaria</td></tr><tr><td>source_paper:</td><td>Ali_2022</td></tr><tr><td>measured_compound:</td><td>artemisinin and naphthoquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>artemisinin 282.336 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'Ka (1/h)' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'Ka (1/h)' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'MTT (h)' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'MTT (h)' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'F' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table section iiv: 'F' routed out of structural estimates ('Interindividual variability (% CV)d')</li><li>table representations disagree for 'CL (L/h)'; source reconciliation required</li><li>table representations disagree for 'V1 (L)'; source reconciliation required</li><li>table representations disagree for 'Q (L/h)'; source reconciliation required</li><li>table representations disagree for 'Vp (L)'; source reconciliation required</li><li>table representations disagree for 'Ka (1/h)'; source reconciliation required</li><li>table representations disagree for 'MTT (h)'; source reconciliation required</li><li>table representations disagree for 'NN'; source reconciliation required</li><li>table representations disagree for 'F'; source reconciliation required</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Artemisinin_Ali2022_reference;
