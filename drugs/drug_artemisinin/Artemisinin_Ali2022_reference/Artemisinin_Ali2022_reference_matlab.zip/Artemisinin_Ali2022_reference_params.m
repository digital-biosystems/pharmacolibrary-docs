function p = Artemisinin_Ali2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: artemisinin   source: Ali_2022 / reference   route: oral
  p.name  = 'Artemisinin_Ali2022_reference_params';
  p.drug  = 'artemisinin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 395.0;                % central volume [L]
  p.CL = 66.7;                % clearance [L/h]
  p.Vp = [19100.0];             % peripheral volumes [L]
  p.Q  = [601.0];             % inter-compartmental clearances [L/h]
  p.ka = 2.11;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 560.0;             % dose [mg]
end
